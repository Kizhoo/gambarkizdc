const { ChannelType, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getGuildConfig, updateGuildConfig } = require('../database/db');
const { successEmbed, errorEmbed } = require('./embeds');

async function handleTicketButton(interaction, client) {
  const cfg = getGuildConfig(interaction.guild.id);

  if (interaction.customId === 'ticket_create') {
    if (!cfg.ticketCategoryId) {
      return interaction.reply({ embeds: [errorEmbed('Sistem ticket belum di-setup admin. Pakai `/ticketsetup` dulu.')], ephemeral: true });
    }

    const existing = interaction.guild.channels.cache.find(
      c => c.topic === `ticket-owner-${interaction.user.id}` && c.parentId === cfg.ticketCategoryId
    );
    if (existing) {
      return interaction.reply({ embeds: [errorEmbed(`Kamu sudah punya ticket terbuka: ${existing}`)], ephemeral: true });
    }

    const ticketNumber = cfg.ticketCounter + 1;
    updateGuildConfig(interaction.guild.id, { ticketCounter: ticketNumber });

    const channel = await interaction.guild.channels.create({
      name: `ticket-${ticketNumber}`,
      type: ChannelType.GuildText,
      parent: cfg.ticketCategoryId,
      topic: `ticket-owner-${interaction.user.id}`,
      permissionOverwrites: [
        { id: interaction.guild.roles.everyone, deny: [PermissionFlagsBits.ViewChannel] },
        { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
        { id: client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
      ],
    });

    const embed = new EmbedBuilder()
      .setColor('#2b2d31')
      .setTitle(`Ticket #${ticketNumber}`)
      .setDescription(`Halo ${interaction.user}, ada admin/staff yang akan membantu kamu segera.\nJelaskan kendala/pertanyaan kamu di sini.`)
      .setTimestamp();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('ticket_close').setLabel('Tutup Ticket').setStyle(ButtonStyle.Danger)
    );

    await channel.send({ content: `${interaction.user}`, embeds: [embed], components: [row] });
    return interaction.reply({ embeds: [successEmbed(`Ticket kamu sudah dibuat: ${channel}`)], ephemeral: true });
  }

  if (interaction.customId === 'ticket_close') {
    await interaction.reply({ embeds: [successEmbed('Ticket akan ditutup dalam 5 detik...')] });

    if (cfg.ticketLogChannel) {
      const logChannel = interaction.guild.channels.cache.get(cfg.ticketLogChannel);
      if (logChannel) {
        logChannel.send({
          embeds: [new EmbedBuilder()
            .setColor('#ED4245')
            .setTitle('Ticket Ditutup')
            .setDescription(`Channel: **${interaction.channel.name}**\nDitutup oleh: ${interaction.user}`)
            .setTimestamp()],
        }).catch(() => {});
      }
    }

    setTimeout(() => {
      interaction.channel.delete().catch(() => {});
    }, 5000);
  }
}

module.exports = { handleTicketButton };
