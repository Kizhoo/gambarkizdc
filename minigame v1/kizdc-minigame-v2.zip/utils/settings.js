// ============================================================================
// PUSAT SETTING TERPADU + HOT RELOAD
// ----------------------------------------------------------------------------
// SEMUA setting global bot ada di config.json. Modul ini adalah satu-satunya
// sumber kebenaran. Ia memuat config.json SEKALI lalu memutasi objek yang sama
// secara in-place, sehingga semua file lain yang menulis `require('../config.json')`
// otomatis ikut melihat perubahan TANPA restart bot.
//
// Pakai get('ai.model') / set('ai.model', '...') dengan notasi titik. Setiap set
// langsung ditulis balik ke config.json (persist) dan memicu listener onChange
// (dipakai mis. untuk hot-add node musik).
// ============================================================================
const fs = require('fs');
const path = require('path');

const CONFIG_PATH = path.join(__dirname, '..', 'config.json');

// Objek config yang sama persis dengan yang dikembalikan require('../config.json').
const config = require('../config.json');

const listeners = new Set(); // fn(pathString, newValue, config)

function notify(changedPath, value) {
  for (const fn of listeners) {
    try { fn(changedPath, value, config); } catch (e) { console.error('[settings] listener error:', e.message); }
  }
}

function onChange(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

// Ambil nilai dengan notasi titik: get('ai.model')
function get(dotPath, fallback = undefined) {
  if (!dotPath) return config;
  const parts = dotPath.split('.');
  let cur = config;
  for (const p of parts) {
    if (cur == null || typeof cur !== 'object') return fallback;
    cur = cur[p];
  }
  return cur === undefined ? fallback : cur;
}

function saveToDisk() {
  const tmp = CONFIG_PATH + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(config, null, 2));
  fs.renameSync(tmp, CONFIG_PATH); // atomic
}

// Set nilai dengan notasi titik: set('ai.model', 'gpt-4o'). Membuat objek antara
// bila perlu, memutasi in-place, menyimpan ke disk, lalu memberi tahu listener.
function set(dotPath, value, { persist = true, silent = false } = {}) {
  const parts = dotPath.split('.');
  let cur = config;
  for (let i = 0; i < parts.length - 1; i++) {
    const p = parts[i];
    if (cur[p] == null || typeof cur[p] !== 'object') cur[p] = {};
    cur = cur[p];
  }
  cur[parts[parts.length - 1]] = value;
  if (persist) saveToDisk();
  if (!silent) notify(dotPath, value);
  return value;
}

// Muat ulang config.json dari disk (mis. kalau diedit manual di panel hosting)
// tanpa restart: mutasi in-place supaya referensi tetap sama.
function reloadFromDisk() {
  const fresh = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
  for (const k of Object.keys(config)) delete config[k];
  Object.assign(config, fresh);
  notify('*', config);
  return config;
}

// Toggle boolean cepat: toggle('isNsfw')
function toggle(dotPath) {
  const next = !get(dotPath);
  return set(dotPath, next);
}

// Set banyak nilai sekaligus, hanya SEKALI tulis ke disk (dipakai modal panel supaya
// respons cepat & tidak kena "Unknown interaction").
function setMany(entries) {
  for (const [dotPath, value] of Object.entries(entries)) {
    set(dotPath, value, { persist: false, silent: true });
  }
  saveToDisk();
  notify('*', config);
}

module.exports = { config, get, set, setMany, toggle, onChange, reloadFromDisk, saveToDisk, CONFIG_PATH };
