const { SlashCommandBuilder } = require('discord.js');
const { addReminder } = require('../../database/db');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

function parseDuration(input) {
  const match = input.match(/^(\d+)(d|h|m|s)$/i);
  if (!match) return null;
  const value = parseInt(match[1]);
  const unit = match[2].toLowerCase();
  const multipliers = { s: 1000, m: 60000, h: 3600000, d: 86400000 };
  return value * multipliers[unit];
}

module.exports = {
  subcommandOf: true,
  data: new SlashCommandBuilder()
    .setName('remindme')
    .setDescription('Ingatkan aku tentang sesuatu nanti')
    .addStringOption(o => o.setName('waktu').setDescription('Contoh: 10m, 2h, 1d, 30s').setRequired(true))
    .addStringOption(o => o.setName('pesan').setDescription('Isi pengingat').setRequired(true)),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const durationInput = interaction.options.getString('waktu');
    const message = interaction.options.getString('pesan');
    const ms = parseDuration(durationInput);

    if (!ms || ms <= 0) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'remind.invalid'))], ephemeral: true });
    }
    if (ms > 30 * 86400000) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'remind.max'))], ephemeral: true });
    }

    const remindAt = Date.now() + ms;
    addReminder(interaction.user.id, interaction.channel.id, interaction.guild?.id || null, message, remindAt);

    return interaction.reply({ embeds: [successEmbed(t(lang, 'remind.ok', { ts: Math.floor(remindAt / 1000), msg: message }))] });
  },
};
