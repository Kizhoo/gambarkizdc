const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban member dari server')
    .addUserOption(o => o.setName('target').setDescription('Member yang akan diban').setRequired(true))
    .addStringOption(o => o.setName('alasan').setDescription('Alasan ban').setRequired(false))
    .addIntegerOption(o => o.setName('hapus_pesan_hari').setDescription('Hapus pesan berapa hari terakhir (0-7)').setMinValue(0).setMaxValue(7))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const target = interaction.options.getUser('target');
    const reason = interaction.options.getString('alasan') || t(lang, 'mod.no_reason');
    const deleteDays = interaction.options.getInteger('hapus_pesan_hari') || 0;

    const member = interaction.guild.members.cache.get(target.id);
    if (member && !member.bannable) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'mod.cant_ban'))], ephemeral: true });
    }

    await target.send(t(lang, 'mod.banned_dm', { server: interaction.guild.name, reason, reason_label: t(lang, 'mod.reason') })).catch(() => {});
    await interaction.guild.members.ban(target.id, { reason, deleteMessageSeconds: deleteDays * 86400 });

    return interaction.reply({ embeds: [successEmbed(t(lang, 'mod.banned_ok', { user: target.tag, reason, reason_label: t(lang, 'mod.reason') }))] });
  },
};
