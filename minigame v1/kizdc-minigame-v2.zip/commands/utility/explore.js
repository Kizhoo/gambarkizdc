const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');
const { safeDefer } = require('../../utils/interactionHelpers');
const { fetchJson, truncate } = require('../../utils/publicApi');
const COUNTRIES = require('../../utils/countryData');

const textOpt = (name, description) => o => o.setName(name).setDescription(description).setRequired(true).setMaxLength(100);
const searchSub = (s, name, description, option = 'query') => s.setName(name).setDescription(description).addStringOption(textOpt(option, 'Kata pencarian'));

function embed(title, description) {
  return baseEmbed().setTitle(title).setDescription(truncate(description, 4000));
}

async function executeApi(sub, interaction, lang) {
  const q = interaction.options.getString('query');

  if (sub === 'pokemon') {
    const p = await fetchJson(`https://pokeapi.co/api/v2/pokemon/${encodeURIComponent(q.toLowerCase())}`, { ttl: 3600000 });
    return embed(`#${p.id} ${p.name.toUpperCase()}`, `**Tipe:** ${p.types.map(x => x.type.name).join(', ')}\n**Tinggi:** ${p.height / 10} m\n**Berat:** ${p.weight / 10} kg\n**Ability:** ${p.abilities.map(x => x.ability.name).join(', ')}\n**Base XP:** ${p.base_experience}`).setThumbnail(p.sprites.other?.['official-artwork']?.front_default || p.sprites.front_default);
  }
  if (['anime', 'manga', 'character'].includes(sub)) {
    const path = sub === 'character' ? 'characters' : sub;
    const filter = sub === 'character' ? 'name' : 'text';
    const d = await fetchJson(`https://kitsu.io/api/edge/${path}?filter[${filter}]=${encodeURIComponent(q)}&page[limit]=1`, { timeout: 15000, headers: { Accept: 'application/vnd.api+json' } });
    const x = d.data?.[0]?.attributes;
    if (!x) throw new Error(t(lang, 'explore.not_found'));
    if (sub === 'character') return embed(`👤 ${x.canonicalName || x.name}`, x.description || t(lang, 'explore.no_bio')).setThumbnail(x.image?.original || x.image?.large);
    const title = x.canonicalTitle || x.titles?.en || x.titles?.en_jp || x.slug;
    return embed(`${sub === 'anime' ? '🎌' : '📚'} ${title}`, `${x.titles?.en ? `**English:** ${x.titles.en}\n` : ''}**Skor:** ${x.averageRating || '—'}\n**Status:** ${x.status || '—'}\n**Mulai:** ${x.startDate || '—'}\n\n${x.synopsis || t(lang, 'explore.no_synopsis')}`).setThumbnail(x.posterImage?.large || x.posterImage?.original);
  }
  if (sub === 'country') {
    const qLower = q.toLowerCase();
    const c = COUNTRIES.find(x => x.name.toLowerCase() === qLower) || COUNTRIES.find(x => x.name.toLowerCase().includes(qLower));
    if (!c) throw new Error(`negara "${q}" tidak ditemukan di daftar (${COUNTRIES.length} negara umum yang didukung)`);
    return embed(`🌍 ${c.name}`, `**Ibu kota:** ${c.capital}\n**Wilayah:** ${c.region}\n**Kode negara:** ${c.code}`).setThumbnail(`https://flagcdn.com/w320/${c.code.toLowerCase()}.png`);
  }
  if (sub === 'weather') {
    const geo = await fetchJson(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=1&language=id&format=json`, { timeout: 12000 });
    const place = geo.results?.[0]; if (!place) throw new Error('lokasi tidak ditemukan');
    const w = await fetchJson(`https://api.open-meteo.com/v1/forecast?latitude=${place.latitude}&longitude=${place.longitude}&current=temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,wind_speed_10m,weather_code&timezone=auto`, { timeout: 12000 });
    const c = w.current;
    return embed(`🌤️ Cuaca ${place.name}`, `**Lokasi:** ${place.admin1 || ''}, ${place.country}\n**Suhu:** ${c.temperature_2m}°C (terasa ${c.apparent_temperature}°C)\n**Kelembapan:** ${c.relative_humidity_2m}%\n**Presipitasi:** ${c.precipitation} mm\n**Angin:** ${c.wind_speed_10m} km/j\n**Kode cuaca WMO:** ${c.weather_code}\n**Diperbarui:** ${c.time}`);
  }
  if (sub === 'github') {
    const x = await fetchJson(`https://api.github.com/users/${encodeURIComponent(q)}`, { headers: { Accept: 'application/vnd.github+json' } });
    return embed(`🐙 ${x.name || x.login}`, `**@${x.login}**\n${x.bio || t(lang, 'explore.no_bio2')}\n\n**Repositori:** ${x.public_repos}\n**Followers:** ${x.followers}\n**Following:** ${x.following}\n**Lokasi:** ${x.location || '—'}\n**Dibuat:** ${new Date(x.created_at).toLocaleDateString('id-ID')}`).setThumbnail(x.avatar_url);
  }
  if (sub === 'npm') {
    const x = await fetchJson(`https://registry.npmjs.org/${encodeURIComponent(q.toLowerCase())}/latest`);
    const license = typeof x.license === 'string' ? x.license : x.license?.type;
    return embed(`📦 ${x.name}@${x.version}`, `${x.description || t(lang, 'explore.no_desc')}\n\n**Lisensi:** ${license || '—'}\n**Author:** ${x.author?.name || x.author || '—'}\n**Keywords:** ${(x.keywords || []).slice(0, 12).join(', ') || '—'}\n**Dependencies:** ${Object.keys(x.dependencies || {}).length}`);
  }
  if (sub === 'dictionary') {
    const rows = await fetchJson(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(q.toLowerCase())}`);
    const x = rows?.[0]; const meaning = x?.meanings?.[0]; const def = meaning?.definitions?.[0];
    if (!def) throw new Error('kata tidak ditemukan di kamus Inggris');
    return embed(`📖 ${x.word}`, `**Fonetik:** ${x.phonetic || '—'}\n**Kelas kata:** ${meaning.partOfSpeech || '—'}\n**Definisi:** ${def.definition}\n**Contoh:** ${def.example || '—'}\n**Sinonim:** ${(def.synonyms || meaning.synonyms || []).slice(0, 8).join(', ') || '—'}`);
  }
  if (sub === 'crypto') {
    const search = await fetchJson(`https://api.coingecko.com/api/v3/search?query=${encodeURIComponent(q)}`, { timeout: 15000 });
    const coin = search.coins?.[0]; if (!coin) throw new Error('aset kripto tidak ditemukan');
    const d = await fetchJson(`https://api.coingecko.com/api/v3/simple/price?ids=${coin.id}&vs_currencies=usd,idr&include_24hr_change=true&include_market_cap=true`, { timeout: 15000 });
    const p = d[coin.id];
    return embed(`🪙 ${coin.name} (${coin.symbol})`, `**USD:** $${p.usd?.toLocaleString('en-US')}\n**IDR:** Rp${p.idr?.toLocaleString('id-ID')}\n**Perubahan 24j:** ${p.usd_24h_change?.toFixed(2)}%\n**Market cap:** $${p.usd_market_cap?.toLocaleString('en-US')}`).setThumbnail(coin.large);
  }
  if (sub === 'joke') {
    const x = await fetchJson('https://official-joke-api.appspot.com/random_joke');
    return embed('😂 Random Joke', `${x.setup}\n\n||${x.punchline}||`);
  }
  if (sub === 'quote') {
    const x = await fetchJson('https://dummyjson.com/quotes/random');
    return embed('💬 Quote', `“${x.quote}”\n\n— **${x.author}**`);
  }
  if (sub === 'fact') {
    const x = await fetchJson(`https://uselessfacts.jsph.pl/api/v2/facts/random?language=en&t=${Date.now()}`);
    return embed('🧠 Random Fact', x.text);
  }
  if (sub === 'dog') {
    const x = await fetchJson('https://dog.ceo/api/breeds/image/random');
    return embed('🐕 Random Dog', 'Foto anjing acak dari Dog CEO API.').setImage(x.message);
  }
  if (sub === 'cat') {
    const x = (await fetchJson(`https://api.thecatapi.com/v1/images/search?t=${Date.now()}`))?.[0];
    return embed('🐈 Random Cat', `Ukuran asli: ${x.width || '—'}×${x.height || '—'}`).setImage(x.url);
  }
  if (sub === 'fox') {
    const x = await fetchJson('https://randomfox.ca/floof/');
    return embed('🦊 Random Fox', 'Foto rubah acak dari RandomFox API.').setImage(x.image);
  }
  if (sub === 'duck') {
    const x = await fetchJson('https://random-d.uk/api/v2/random');
    return embed('🦆 Random Duck', 'Foto bebek acak dari Random-d.uk API.').setImage(x.url);
  }
  if (sub === 'meme') {
    const x = await fetchJson('https://meme-api.com/gimme');
    return embed(`🤣 ${x.title}`, `r/${x.subreddit} • 👍 ${x.ups || 0}`).setImage(x.url);
  }
  if (sub === 'space') {
    const x = (await fetchJson('https://api.spaceflightnewsapi.net/v4/articles/?limit=1'))?.results?.[0];
    if (!x) throw new Error('berita tidak tersedia');
    return embed(`🚀 ${x.title}`, `${x.summary}\n\n**Sumber:** ${x.news_site}\n**Terbit:** ${new Date(x.published_at).toLocaleString('id-ID')}`).setImage(x.image_url);
  }
  if (sub === 'activity') {
    const x = await fetchJson(`https://bored-api.appbrewery.com/random?t=${Date.now()}`);
    return embed('🎯 Ide Aktivitas', `${x.activity}\n\n**Tipe:** ${x.type || '—'}\n**Peserta:** ${x.participants || '—'}\n**Durasi:** ${x.duration || '—'}\n**Indoor:** ${x.kidFriendly === false ? 'Tidak selalu ramah anak' : 'Ya'}`);
  }
  throw new Error('fitur API tidak dikenal');
}

module.exports = {
  subcommandOf: true,
  data: new SlashCommandBuilder()
    .setName('explore').setDescription('20 fitur pencarian dan media berbasis public API')
    .addSubcommand(s => searchSub(s, 'pokemon', 'Cari informasi Pokémon'))
    .addSubcommand(s => searchSub(s, 'anime', 'Cari anime melalui Jikan API'))
    .addSubcommand(s => searchSub(s, 'manga', 'Cari manga melalui Jikan API'))
    .addSubcommand(s => searchSub(s, 'character', 'Cari karakter anime'))
    .addSubcommand(s => searchSub(s, 'country', 'Cari profil lengkap negara'))
    .addSubcommand(s => searchSub(s, 'weather', 'Cek cuaca kota secara real-time'))
    .addSubcommand(s => searchSub(s, 'github', 'Lihat profil publik GitHub'))
    .addSubcommand(s => searchSub(s, 'npm', 'Cari detail package npm'))
    .addSubcommand(s => searchSub(s, 'dictionary', 'Kamus bahasa Inggris'))
    .addSubcommand(s => searchSub(s, 'crypto', 'Cek harga aset kripto'))
    .addSubcommand(s => s.setName('joke').setDescription('Ambil joke acak dari API'))
    .addSubcommand(s => s.setName('quote').setDescription('Ambil quote inspiratif acak'))
    .addSubcommand(s => s.setName('fact').setDescription('Ambil fakta unik acak'))
    .addSubcommand(s => s.setName('dog').setDescription('Foto anjing acak'))
    .addSubcommand(s => s.setName('cat').setDescription('Foto kucing acak'))
    .addSubcommand(s => s.setName('fox').setDescription('Foto rubah acak'))
    .addSubcommand(s => s.setName('duck').setDescription('Foto bebek acak'))
    .addSubcommand(s => s.setName('meme').setDescription('Meme komunitas acak'))
    .addSubcommand(s => s.setName('space').setDescription('Berita antariksa terbaru'))
    .addSubcommand(s => s.setName('activity').setDescription('Rekomendasi aktivitas saat bosan')),

  cooldown: 5,
  async execute(interaction) {
    const lang = guildLang(interaction);
    if (!(await safeDefer(interaction))) return;
    const sub = interaction.options.getSubcommand();
    try {
      const result = await executeApi(sub, interaction, lang);
      return interaction.editReply({ embeds: [result] });
    } catch (error) {
      console.error(`[explore ${sub}]`, error);
      return interaction.editReply({ embeds: [errorEmbed(t(lang, 'explore.fail', { err: error.message }))] }).catch(() => {});
    }
  },
};
