const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

const NUMBER_EMOJIS = ['1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', ''];

module.exports = {
  subcommandOf: true,
  data: new SlashCommandBuilder()
    .setName('poll')
    .setDescription('Buat polling sederhana')
    .addStringOption(o => o.setName('pertanyaan').setDescription('Pertanyaan polling').setRequired(true))
    .addStringOption(o => o.setName('opsi').setDescription('Pisahkan dengan | contoh: A|B|C (kosongkan untuk polling Ya/Tidak)')),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const question = interaction.options.getString('pertanyaan');
    const optionsRaw = interaction.options.getString('opsi');

    let description;
    let emojisToUse;

    if (optionsRaw) {
      const options = optionsRaw.split('|').map(s => s.trim()).filter(Boolean).slice(0, 10);
      emojisToUse = NUMBER_EMOJIS.slice(0, options.length);
      description = options.map((opt, i) => `${emojisToUse[i]} ${opt}`).join('\n');
    } else {
      emojisToUse = ['', ''];
      description = `${t(lang, 'common.yes')}\n${t(lang, 'common.no')}`;
    }

    const embed = baseEmbed()
      .setTitle(`${question}`)
      .setDescription(description)
      .setFooter({ text: t(lang, 'poll.footer', { user: interaction.user.tag })});

    await interaction.reply({ embeds: [embed] });
    const sent = await interaction.fetchReply();
    for (const emoji of emojisToUse) {
      await sent.react(emoji);
    }
  },
};
