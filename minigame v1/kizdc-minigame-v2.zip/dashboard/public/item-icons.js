// ============================================================================
// ITEM ICONS v2 — ikon barang unik per item (bukan per kategori).
// ----------------------------------------------------------------------------
// v1 cuma 1 bentuk per kategori (semua "artifact" jadi kristal, semua "weapon"
// jadi pedang). v2 memetakan NOMINA dalam id/nama item ke bentuk spesifik
// (Pedang -> pedang, Belati -> belati, Patung -> patung, dst.) lalu sisanya
// di-fallback ke beberapa bentuk per kategori berdasarkan hash. Ditambah warna
// dari hash, tiap item jadi punya tampilan sendiri (ratusan variasi unik).
// ============================================================================
(function () {
  function hash(str) {
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0;
  }
  function hsla(h, s, l, a) { return `hsla(${h},${s}%,${l}%,${a})`; }

  function rr(ctx, x, y, w, h, r) {
    const rad = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + rad, y);
    ctx.arcTo(x + w, y, x + w, y + h, rad);
    ctx.arcTo(x + w, y + h, x, y + h, rad);
    ctx.arcTo(x, y + h, x, y, rad);
    ctx.arcTo(x, y, x + w, y, rad);
    ctx.closePath();
  }

  function shadow(ctx, fn) {
    ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,0.45)';
    ctx.shadowBlur = 8;
    ctx.shadowOffsetY = 3;
    fn();
    ctx.restore();
  }

  function star(ctx, cx, cy, r, points, rot) {
    ctx.beginPath();
    for (let i = 0; i < points * 2; i++) {
      const rad = i % 2 === 0 ? r : r * 0.45;
      const a = (Math.PI / points) * i - Math.PI / 2 + (rot || 0);
      const x = cx + Math.cos(a) * rad, y = cy + Math.sin(a) * rad;
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fill();
  }

  // ---------- PEMETAAN NOMINA -> BENTUK ----------
  // (kata kunci, bentuk). Kata multi-kata didahulukan.
  const NOUN_SHAPE = [
    ['biskuit naga', 'cookie'], ['daging panggang', 'meat'], ['ikan segar', 'fish'],
    ['buah beri', 'fruit'], ['roti madu', 'bread'], ['sup jamur', 'soup'],
    ['telur emas', 'egg'], ['susu hangat', 'milk'], ['sarung tangan', 'glove'],
    ['mahkota kecil', 'crown'],
    // Senjata baru (kata kunci Inggris dari ID item) -> bentuk valid
    ['sword', 'sword'], ['blade', 'sword'], ['fang', 'sword'], ['axe', 'axe'],
    ['hammer', 'hammer'], ['spear', 'spear'], ['staff', 'staff'], ['wand', 'staff'],
    ['scepter', 'staff'], ['archstaff', 'staff'], ['orb', 'orb'], ['tome', 'book'],
    ['book', 'book'], ['chalice', 'goblet'], ['dagger', 'dagger'], ['phantom', 'dagger'],
    ['katana', 'katana'], ['bow', 'bow'], ['claw', 'dagger'], ['venom', 'dagger'],
    ['pedang', 'sword'], ['belati', 'dagger'],
    ['busur', 'bow'], ['tongkat', 'staff'], ['perisai', 'shield'], ['kapak', 'axe'],
    ['palu', 'hammer'], ['tombak', 'spear'], ['cincin', 'ring'], ['kalung', 'necklace'],
    ['gelang', 'bracelet'], ['anting', 'earring'], ['mahkota', 'crown'], ['jimat', 'amulet'],
    ['patung', 'statue'], ['buku', 'book'], ['cermin', 'mirror'], ['piala', 'goblet'],
    ['topeng', 'mask'], ['lukisan', 'painting'], ['vas', 'vase'], ['prasasti', 'tablet'],
    ['relik', 'relic'], ['manik', 'bead'], ['peta', 'map'], ['fosil', 'fossil'],
    ['kerang', 'shell'], ['kartu', 'card'], ['prangko', 'stamp'], ['koin', 'coin'],
    ['berlian', 'diamond'], ['zamrud', 'gem'], ['ruby', 'gem'], ['safir', 'gem'],
    ['kristal', 'crystal'], ['obsidian', 'crystal'], ['mutiara', 'pearl'],
    ['emas', 'ingot'], ['perak', 'ingot'], ['mithril', 'ingot'], ['besi', 'ore'],
    ['kayu', 'wood'], ['batu', 'rock'], ['sutra', 'cloth'], ['tulang', 'bone'],
    ['topi', 'hat'], ['syal', 'scarf'], ['kacamata', 'glasses'], ['jas', 'coat'],
    ['gaun', 'dress'], ['sepatu', 'shoes'], ['tas', 'bag'], ['jam', 'watch'],
    ['cokelat', 'chocolate'], ['keju', 'cheese'], ['ramuan', 'potion'],
    ['gulungan', 'scroll'], ['tiket', 'ticket'], ['kontrak', 'scroll'], ['kunci', 'key'],
  ];

  const CATEGORY_SHAPES = {
    weapon: ['sword', 'axe', 'dagger', 'bow', 'staff', 'hammer', 'spear', 'katana'],
    armor: ['shield', 'helmet', 'chestplate', 'gauntlet'],
    accessory: ['ring', 'necklace', 'earring', 'bracelet', 'crown', 'amulet'],
    potion: ['potion', 'vial', 'elixir'],
    consumable: ['box', 'scroll', 'ticket', 'key', 'bag'],
    material: ['gem', 'crystal', 'diamond', 'ore', 'ingot', 'wood', 'rock', 'pearl'],
    artifact: ['crystal', 'statue', 'book', 'mirror', 'goblet', 'mask', 'orb', 'tablet', 'painting'],
    collectible: ['coin', 'fossil', 'shell', 'map', 'vase', 'relic', 'stamp', 'card', 'bead'],
    cosmetic: ['hat', 'glasses', 'scarf', 'watch', 'shoes', 'coat', 'dress', 'glove'],
    food: ['fruit', 'bread', 'meat', 'fish', 'cheese', 'egg', 'cookie', 'soup', 'chocolate', 'milk'],
    stock: ['bank'],
  };

  const HUE_BASE = {
    weapon: 0, armor: 218, accessory: 285, potion: 325, consumable: 32,
    material: 155, artifact: 262, collectible: 45, cosmetic: 198, food: 12, stock: 210,
  };

  function shapeFor(id, category) {
    const norm = ' ' + String(id || '').toLowerCase().replace(/_/g, ' ') + ' ';
    for (const [kw, shape] of NOUN_SHAPE) {
      if (norm.includes(' ' + kw + ' ')) return shape;
    }
    const list = CATEGORY_SHAPES[category] || ['box'];
    return list[hash(String(id)) % list.length];
  }

  // ==================== LATAR ====================
  function baseLayer(ctx, S, hue) {
    ctx.clearRect(0, 0, S, S);
    const grad = ctx.createRadialGradient(S * 0.5, S * 0.42, S * 0.05, S * 0.5, S * 0.5, S * 0.72);
    grad.addColorStop(0, hsla(hue, 42, 24, 1));
    grad.addColorStop(1, hsla(hue, 45, 11, 1));
    ctx.fillStyle = grad;
    rr(ctx, S * 0.04, S * 0.04, S * 0.92, S * 0.92, S * 0.16);
    ctx.fill();
    ctx.strokeStyle = hsla(hue, 55, 58, 0.35);
    ctx.lineWidth = Math.max(1, S * 0.015);
    rr(ctx, S * 0.055, S * 0.055, S * 0.89, S * 0.89, S * 0.14);
    ctx.stroke();
  }

  // ==================== SENJATA ====================
  function blade(ctx, S, h1, h2, bladeLen, tip, bw, angle, guardFn) {
    shadow(ctx, () => {
      ctx.save();
      ctx.translate(S * 0.5, S * 0.5);
      ctx.rotate(angle);
      const bl = S * bladeLen;
      const g = ctx.createLinearGradient(0, -bl, 0, bl);
      g.addColorStop(0, hsla(h1, 20, 90, 1));
      g.addColorStop(0.5, hsla(h1, 30, 74, 1));
      g.addColorStop(1, hsla(h1, 35, 58, 1));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(0, -bl - tip * S);
      ctx.lineTo(bw * S / 2, -bl);
      ctx.lineTo(bw * S / 2, bl);
      ctx.lineTo(-bw * S / 2, bl);
      ctx.lineTo(-bw * S / 2, -bl);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = hsla(h1, 15, 55, 0.6);
      ctx.lineWidth = S * 0.018;
      ctx.beginPath(); ctx.moveTo(0, -bl + S * 0.04); ctx.lineTo(0, bl - S * 0.04); ctx.stroke();
      guardFn && guardFn(ctx, S, h2, bl);
      ctx.restore();
    });
  }
  function drawSword(ctx, S, h1, h2) {
    blade(ctx, S, h1, h2, 0.46, 0.16, 0.14, -Math.PI / 4, (ctx, S, h2, bl) => {
      ctx.fillStyle = hsla(h2, 45, 48, 1); ctx.fillRect(-S * 0.15, bl - S * 0.05, S * 0.30, S * 0.10);
      ctx.fillStyle = hsla(h2, 40, 34, 1); ctx.fillRect(-S * 0.035, bl, S * 0.07, S * 0.16);
      ctx.beginPath(); ctx.arc(0, bl + S * 0.18, S * 0.05, 0, Math.PI * 2); ctx.fillStyle = hsla(h2, 45, 55, 1); ctx.fill();
    });
  }
  function drawDagger(ctx, S, h1, h2) {
    blade(ctx, S, h1, h2, 0.36, 0.22, 0.09, -Math.PI / 4, (ctx, S, h2, bl) => {
      ctx.fillStyle = hsla(h2, 45, 50, 1); ctx.fillRect(-S * 0.1, bl - S * 0.04, S * 0.2, S * 0.07);
      ctx.fillStyle = hsla(h2, 40, 34, 1); ctx.fillRect(-S * 0.03, bl, S * 0.06, S * 0.1);
    });
  }
  function drawKatana(ctx, S, h1, h2) {
    blade(ctx, S, h1, h2, 0.5, 0.18, 0.12, -Math.PI / 3.2, (ctx, S, h2, bl) => {
      ctx.fillStyle = hsla(h2, 45, 45, 1); ctx.fillRect(-S * 0.12, bl - S * 0.04, S * 0.24, S * 0.08);
      ctx.fillStyle = hsla(h2, 30, 30, 1); ctx.fillRect(-S * 0.03, bl, S * 0.06, S * 0.14);
    });
  }
  function drawAxe(ctx, S, h1, h2) {
    shadow(ctx, () => {
      ctx.save(); ctx.translate(S * 0.5, S * 0.5); ctx.rotate(-Math.PI / 6);
      ctx.fillStyle = hsla(h2, 30, 30, 1); ctx.fillRect(-S * 0.04, -S * 0.2, S * 0.08, S * 0.52);
      const g = ctx.createLinearGradient(0, -S * 0.34, 0, S * 0.02);
      g.addColorStop(0, hsla(h1, 20, 88, 1)); g.addColorStop(1, hsla(h1, 30, 60, 1));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(-S * 0.16, -S * 0.34);
      ctx.lineTo(S * 0.16, -S * 0.34);
      ctx.quadraticCurveTo(S * 0.26, -S * 0.18, S * 0.1, S * 0.0);
      ctx.quadraticCurveTo(0, S * 0.08, -S * 0.1, S * 0.0);
      ctx.quadraticCurveTo(-S * 0.26, -S * 0.18, -S * 0.16, -S * 0.34);
      ctx.closePath(); ctx.fill();
      ctx.restore();
    });
  }
  function drawBow(ctx, S, h1, h2) {
    shadow(ctx, () => {
      ctx.strokeStyle = hsla(h2, 40, 45, 1); ctx.lineWidth = S * 0.06; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(S * 0.28, S * 0.18); ctx.quadraticCurveTo(S * 0.72, S * 0.42, S * 0.28, S * 0.82); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.lineWidth = S * 0.02;
      ctx.beginPath(); ctx.moveTo(S * 0.28, S * 0.18); ctx.lineTo(S * 0.28, S * 0.82); ctx.stroke();
      // arrow
      ctx.strokeStyle = hsla(h1, 30, 60, 1); ctx.lineWidth = S * 0.04;
      ctx.beginPath(); ctx.moveTo(S * 0.24, S * 0.5); ctx.lineTo(S * 0.78, S * 0.5); ctx.stroke();
      ctx.fillStyle = hsla(h1, 20, 85, 1);
      ctx.beginPath(); ctx.moveTo(S * 0.82, S * 0.5); ctx.lineTo(S * 0.72, S * 0.44); ctx.lineTo(S * 0.72, S * 0.56); ctx.closePath(); ctx.fill();
    });
  }
  function drawStaff(ctx, S, h1, h2) {
    shadow(ctx, () => {
      ctx.save(); ctx.translate(S * 0.5, S * 0.5); ctx.rotate(-Math.PI / 5);
      const g = ctx.createLinearGradient(-S * 0.03, -S * 0.3, S * 0.03, S * 0.3);
      g.addColorStop(0, hsla(h2, 30, 45, 1)); g.addColorStop(1, hsla(h2, 35, 26, 1));
      ctx.fillStyle = g; rr(ctx, -S * 0.03, -S * 0.28, S * 0.06, S * 0.56, S * 0.02); ctx.fill();
      // orb
      const og = ctx.createRadialGradient(0, -S * 0.32, S * 0.02, 0, -S * 0.32, S * 0.14);
      og.addColorStop(0, hsla(h1, 70, 72, 1)); og.addColorStop(1, hsla(h1, 70, 40, 1));
      ctx.fillStyle = og; ctx.beginPath(); ctx.arc(0, -S * 0.32, S * 0.12, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.7)'; ctx.beginPath(); ctx.arc(-S * 0.04, -S * 0.35, S * 0.03, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
    });
  }
  function drawHammer(ctx, S, h1, h2) {
    shadow(ctx, () => {
      ctx.save(); ctx.translate(S * 0.5, S * 0.5); ctx.rotate(Math.PI / 6);
      ctx.fillStyle = hsla(h2, 30, 30, 1); ctx.fillRect(-S * 0.035, -S * 0.16, S * 0.07, S * 0.46);
      const g = ctx.createLinearGradient(0, -S * 0.34, 0, -S * 0.06);
      g.addColorStop(0, hsla(h1, 30, 66, 1)); g.addColorStop(1, hsla(h1, 32, 42, 1));
      ctx.fillStyle = g; rr(ctx, -S * 0.16, -S * 0.36, S * 0.32, S * 0.3, S * 0.05); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.3)'; rr(ctx, -S * 0.13, -S * 0.33, S * 0.2, S * 0.07, S * 0.02); ctx.fill();
      ctx.restore();
    });
  }
  function drawSpear(ctx, S, h1, h2) {
    shadow(ctx, () => {
      ctx.save(); ctx.translate(S * 0.5, S * 0.5); ctx.rotate(-Math.PI / 2.6);
      ctx.fillStyle = hsla(h2, 35, 30, 1); ctx.fillRect(-S * 0.03, -S * 0.24, S * 0.06, S * 0.5);
      const g = ctx.createLinearGradient(0, -S * 0.5, 0, -S * 0.24);
      g.addColorStop(0, hsla(h1, 20, 90, 1)); g.addColorStop(1, hsla(h1, 30, 60, 1));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.moveTo(0, -S * 0.52); ctx.lineTo(S * 0.1, -S * 0.26); ctx.lineTo(-S * 0.1, -S * 0.26); ctx.closePath(); ctx.fill();
      ctx.restore();
    });
  }

  // ==================== ARMOR ====================
  function drawShield(ctx, S, h1, h2) {
    const cx = S * 0.5, top = S * 0.2, bot = S * 0.82;
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(cx, top, cx, bot);
      g.addColorStop(0, hsla(h1, 35, 62, 1)); g.addColorStop(1, hsla(h1, 40, 40, 1));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(cx, top); ctx.lineTo(S * 0.78, S * 0.26); ctx.lineTo(S * 0.74, S * 0.5);
      ctx.quadraticCurveTo(S * 0.62, bot, cx, bot); ctx.quadraticCurveTo(S * 0.38, bot, S * 0.26, S * 0.5);
      ctx.lineTo(S * 0.22, S * 0.26); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = hsla(h2, 55, 55, 1); ctx.lineWidth = S * 0.03; ctx.stroke();
      ctx.beginPath(); ctx.arc(cx, S * 0.44, S * 0.09, 0, Math.PI * 2); ctx.fillStyle = hsla(h2, 45, 55, 1); ctx.fill();
    });
  }
  function drawHelmet(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.3, S * 0.2, S * 0.7, S * 0.7);
      g.addColorStop(0, hsla(h1, 30, 68, 1)); g.addColorStop(1, hsla(h1, 32, 42, 1));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(S * 0.5, S * 0.46, S * 0.26, Math.PI, 0); ctx.fill();
      rr(ctx, S * 0.24, S * 0.46, S * 0.52, S * 0.16, S * 0.03); ctx.fill();
      // visor slit
      ctx.fillStyle = hsla(h2, 20, 25, 1);
      rr(ctx, S * 0.38, S * 0.5, S * 0.24, S * 0.08, S * 0.02); ctx.fill();
      // plume
      ctx.fillStyle = hsla(h2, 70, 60, 1);
      ctx.beginPath(); ctx.moveTo(S * 0.5, S * 0.18); ctx.quadraticCurveTo(S * 0.56, S * 0.04, S * 0.7, S * 0.06); ctx.quadraticCurveTo(S * 0.6, S * 0.12, S * 0.56, S * 0.2); ctx.closePath(); ctx.fill();
    });
  }
  function drawChestplate(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.3, S * 0.24, S * 0.7, S * 0.76);
      g.addColorStop(0, hsla(h1, 30, 66, 1)); g.addColorStop(1, hsla(h1, 32, 40, 1));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(S * 0.32, S * 0.24);
      ctx.quadraticCurveTo(S * 0.5, S * 0.3, S * 0.68, S * 0.24);
      ctx.lineTo(S * 0.74, S * 0.72); ctx.quadraticCurveTo(S * 0.5, S * 0.82, S * 0.26, S * 0.72);
      ctx.closePath(); ctx.fill();
      ctx.strokeStyle = hsla(h2, 45, 50, 1); ctx.lineWidth = S * 0.025; ctx.stroke();
      ctx.beginPath(); ctx.moveTo(S * 0.5, S * 0.32); ctx.lineTo(S * 0.5, S * 0.74); ctx.stroke();
      ctx.fillStyle = hsla(h2, 55, 60, 1); ctx.beginPath(); ctx.arc(S * 0.5, S * 0.38, S * 0.04, 0, Math.PI * 2); ctx.fill();
    });
  }
  function drawGauntlet(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.3, S * 0.3, S * 0.7, S * 0.7);
      g.addColorStop(0, hsla(h1, 30, 64, 1)); g.addColorStop(1, hsla(h1, 32, 40, 1));
      ctx.fillStyle = g;
      rr(ctx, S * 0.26, S * 0.3, S * 0.48, S * 0.24, S * 0.08); ctx.fill(); // palm
      for (let i = 0; i < 3; i++) { rr(ctx, S * 0.26 + i * S * 0.17, S * 0.54, S * 0.12, S * 0.16, S * 0.05); ctx.fill(); }
      ctx.fillStyle = hsla(h2, 50, 50, 1);
      for (let i = 0; i < 3; i++) { rr(ctx, S * 0.3 + i * S * 0.17, S * 0.58, S * 0.04, S * 0.06, S * 0.02); ctx.fill(); }
    });
  }

  // ==================== PERHIASAN ====================
  function drawRing(ctx, S, h1, h2) {
    const cx = S * 0.5, cy = S * 0.5, r = S * 0.26;
    shadow(ctx, () => {
      ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.lineWidth = S * 0.12;
      const g = ctx.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
      g.addColorStop(0, hsla(h1, 50, 72, 1)); g.addColorStop(1, hsla(h1, 55, 45, 1)); ctx.strokeStyle = g; ctx.stroke();
      ctx.beginPath(); ctx.moveTo(cx, cy - S * 0.16); ctx.lineTo(cx + S * 0.12, cy); ctx.lineTo(cx, cy + S * 0.16); ctx.lineTo(cx - S * 0.12, cy); ctx.closePath();
      ctx.fillStyle = hsla(h2, 70, 60, 1); ctx.fill();
    });
  }
  function drawNecklace(ctx, S, h1, h2) {
    shadow(ctx, () => {
      ctx.strokeStyle = hsla(h1, 45, 60, 1); ctx.lineWidth = S * 0.04;
      ctx.beginPath(); ctx.moveTo(S * 0.3, S * 0.2); ctx.quadraticCurveTo(S * 0.5, S * 0.4, S * 0.7, S * 0.2); ctx.stroke();
      // pendant gem
      const g = ctx.createRadialGradient(S * 0.5, S * 0.6, S * 0.02, S * 0.5, S * 0.6, S * 0.16);
      g.addColorStop(0, hsla(h2, 70, 70, 1)); g.addColorStop(1, hsla(h2, 70, 40, 1));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.moveTo(S * 0.5, S * 0.44); ctx.lineTo(S * 0.64, S * 0.6); ctx.lineTo(S * 0.5, S * 0.78); ctx.lineTo(S * 0.36, S * 0.6); ctx.closePath(); ctx.fill();
    });
  }
  function drawEarring(ctx, S, h1, h2) {
    shadow(ctx, () => {
      ctx.strokeStyle = hsla(h1, 45, 62, 1); ctx.lineWidth = S * 0.05;
      ctx.beginPath(); ctx.arc(S * 0.5, S * 0.26, S * 0.09, 0, Math.PI * 2); ctx.stroke();
      const g = ctx.createRadialGradient(S * 0.5, S * 0.6, S * 0.02, S * 0.5, S * 0.6, S * 0.16);
      g.addColorStop(0, hsla(h2, 70, 72, 1)); g.addColorStop(1, hsla(h2, 70, 42, 1));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(S * 0.5, S * 0.6, S * 0.14, 0, Math.PI * 2); ctx.fill();
    });
  }
  function drawBracelet(ctx, S, h1, h2) {
    shadow(ctx, () => {
      ctx.beginPath(); ctx.arc(S * 0.5, S * 0.5, S * 0.28, 0, Math.PI * 2); ctx.lineWidth = S * 0.16;
      const g = ctx.createLinearGradient(S * 0.2, S * 0.2, S * 0.8, S * 0.8);
      g.addColorStop(0, hsla(h1, 50, 70, 1)); g.addColorStop(1, hsla(h1, 55, 44, 1)); ctx.strokeStyle = g; ctx.stroke();
      ctx.fillStyle = hsla(h2, 70, 60, 1); ctx.beginPath(); ctx.arc(S * 0.5, S * 0.22, S * 0.07, 0, Math.PI * 2); ctx.fill();
    });
  }
  function drawCrown(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.3, S * 0.3, S * 0.7, S * 0.7);
      g.addColorStop(0, hsla(h1, 60, 66, 1)); g.addColorStop(1, hsla(h1, 60, 40, 1));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(S * 0.24, S * 0.62); ctx.lineTo(S * 0.2, S * 0.32); ctx.lineTo(S * 0.34, S * 0.46);
      ctx.lineTo(S * 0.5, S * 0.24); ctx.lineTo(S * 0.66, S * 0.46); ctx.lineTo(S * 0.8, S * 0.32);
      ctx.lineTo(S * 0.76, S * 0.62); ctx.closePath(); ctx.fill();
      ctx.fillStyle = hsla(h2, 70, 62, 1);
      [[0.34, 0.5], [0.5, 0.34], [0.66, 0.5]].forEach(([px, py]) => { ctx.beginPath(); ctx.arc(px * S, py * S, S * 0.035, 0, Math.PI * 2); ctx.fill(); });
    });
  }
  function drawAmulet(ctx, S, h1, h2) {
    shadow(ctx, () => {
      ctx.strokeStyle = hsla(h1, 45, 60, 1); ctx.lineWidth = S * 0.03;
      ctx.beginPath(); ctx.moveTo(S * 0.5, S * 0.14); ctx.lineTo(S * 0.5, S * 0.3); ctx.stroke();
      const g = ctx.createRadialGradient(S * 0.5, S * 0.56, S * 0.02, S * 0.5, S * 0.56, S * 0.26);
      g.addColorStop(0, hsla(h1, 55, 68, 1)); g.addColorStop(1, hsla(h1, 55, 40, 1));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(S * 0.5, S * 0.56, S * 0.24, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = hsla(h2, 50, 50, 1); ctx.lineWidth = S * 0.03; ctx.stroke();
      ctx.fillStyle = hsla(h2, 70, 62, 1); ctx.beginPath(); ctx.arc(S * 0.5, S * 0.56, S * 0.1, 0, Math.PI * 2); ctx.fill();
    });
  }

  // ==================== RAMUAN ====================
  function drawPotion(ctx, S, h1, h2) {
    const cx = S * 0.5;
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(cx, S * 0.3, cx, S * 0.8);
      g.addColorStop(0, hsla(h1, 70, 62, 1)); g.addColorStop(1, hsla(h1, 75, 40, 1));
      ctx.fillStyle = g; rr(ctx, cx - S * 0.2, S * 0.34, S * 0.4, S * 0.44, S * 0.12); ctx.fill();
      ctx.fillStyle = hsla(h1, 25, 75, 1); ctx.fillRect(cx - S * 0.07, S * 0.2, S * 0.14, S * 0.16);
      ctx.fillStyle = hsla(28, 45, 42, 1); rr(ctx, cx - S * 0.075, S * 0.13, S * 0.15, S * 0.09, S * 0.02); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.35)'; rr(ctx, cx - S * 0.13, S * 0.4, S * 0.05, S * 0.26, S * 0.02); ctx.fill();
    });
  }
  function drawVial(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.5, S * 0.3, S * 0.5, S * 0.8);
      g.addColorStop(0, hsla(h1, 70, 64, 1)); g.addColorStop(1, hsla(h1, 75, 40, 1));
      ctx.fillStyle = g;
      rr(ctx, S * 0.36, S * 0.3, S * 0.28, S * 0.46, S * 0.1); ctx.fill();
      ctx.fillStyle = hsla(h1, 25, 78, 1); ctx.fillRect(S * 0.44, S * 0.2, S * 0.12, S * 0.14);
      ctx.fillStyle = 'rgba(255,255,255,0.4)'; rr(ctx, S * 0.42, S * 0.36, S * 0.05, S * 0.28, S * 0.02); ctx.fill();
    });
  }
  function drawElixir(ctx, S, h1, h2) {
    drawPotion(ctx, S, h1, h2);
    // aura
    ctx.save();
    const glow = ctx.createRadialGradient(S * 0.5, S * 0.5, S * 0.05, S * 0.5, S * 0.5, S * 0.4);
    glow.addColorStop(0, hsla(h2, 80, 70, 0.5)); glow.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = glow; ctx.fillRect(0, 0, S, S);
    ctx.restore();
  }

  // ==================== KONSUMSI ====================
  function drawBox(ctx, S, h1, h2) {
    const cx = S * 0.5;
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(cx, S * 0.34, cx, S * 0.78);
      g.addColorStop(0, hsla(h1, 35, 55, 1)); g.addColorStop(1, hsla(h1, 40, 36, 1));
      ctx.fillStyle = g; rr(ctx, S * 0.2, S * 0.34, S * 0.6, S * 0.44, S * 0.05); ctx.fill();
      ctx.fillStyle = hsla(h1, 35, 45, 1); rr(ctx, S * 0.2, S * 0.3, S * 0.6, S * 0.1, S * 0.03); ctx.fill();
      ctx.strokeStyle = hsla(h2, 45, 38, 1); ctx.lineWidth = S * 0.035;
      ctx.beginPath(); ctx.moveTo(S * 0.2, S * 0.42); ctx.lineTo(S * 0.8, S * 0.42); ctx.stroke();
      ctx.fillStyle = hsla(h2, 60, 60, 1); ctx.fillRect(cx - S * 0.05, S * 0.4, S * 0.1, S * 0.06);
    });
  }
  function drawScroll(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.2, S * 0.3, S * 0.8, S * 0.7);
      g.addColorStop(0, hsla(h1, 40, 80, 1)); g.addColorStop(1, hsla(h1, 42, 60, 1));
      ctx.fillStyle = g; rr(ctx, S * 0.22, S * 0.36, S * 0.56, S * 0.3, S * 0.04); ctx.fill();
      // rolls
      ctx.fillStyle = hsla(h2, 35, 40, 1); ctx.beginPath(); ctx.arc(S * 0.22, S * 0.36, S * 0.05, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(S * 0.22, S * 0.66, S * 0.05, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = hsla(h1, 35, 40, 0.7); ctx.lineWidth = S * 0.02;
      for (let i = 1; i <= 3; i++) { ctx.beginPath(); ctx.moveTo(S * 0.3, S * 0.36 + i * S * 0.07); ctx.lineTo(S * 0.72, S * 0.36 + i * S * 0.07); ctx.stroke(); }
    });
  }
  function drawTicket(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.3, S * 0.3, S * 0.7, S * 0.7);
      g.addColorStop(0, hsla(h1, 55, 60, 1)); g.addColorStop(1, hsla(h1, 58, 40, 1));
      ctx.fillStyle = g; rr(ctx, S * 0.2, S * 0.34, S * 0.6, S * 0.32, S * 0.05); ctx.fill();
      ctx.fillStyle = 'rgba(0,0,0,0.2)'; ctx.beginPath(); ctx.arc(S * 0.66, S * 0.5, S * 0.07, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,0.25)'; ctx.lineWidth = S * 0.02;
      ctx.beginPath(); ctx.moveTo(S * 0.66, S * 0.34); ctx.lineTo(S * 0.66, S * 0.66); ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,0.8)'; ctx.font = `700 ${S * 0.14}px sans-serif`; ctx.textAlign = 'center'; ctx.fillText('★', S * 0.42, S * 0.55);
    });
  }
  function drawKey(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.3, S * 0.3, S * 0.7, S * 0.7);
      g.addColorStop(0, hsla(h1, 45, 70, 1)); g.addColorStop(1, hsla(h1, 48, 44, 1));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(S * 0.34, S * 0.5, S * 0.14, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.arc(S * 0.34, S * 0.5, S * 0.07, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = hsla(h1, 45, 62, 1); ctx.fillRect(S * 0.34, S * 0.46, S * 0.44, S * 0.08);
      ctx.fillRect(S * 0.7, S * 0.5, S * 0.08, S * 0.05);
      ctx.fillRect(S * 0.6, S * 0.55, S * 0.08, S * 0.05);
    });
  }
  function drawBag(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.3, S * 0.3, S * 0.7, S * 0.8);
      g.addColorStop(0, hsla(h1, 35, 52, 1)); g.addColorStop(1, hsla(h1, 40, 34, 1));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.moveTo(S * 0.3, S * 0.3); ctx.quadraticCurveTo(S * 0.5, S * 0.16, S * 0.7, S * 0.3); ctx.lineTo(S * 0.72, S * 0.76); ctx.quadraticCurveTo(S * 0.5, S * 0.84, S * 0.28, S * 0.76); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = hsla(h2, 40, 40, 1); ctx.lineWidth = S * 0.03;
      ctx.beginPath(); ctx.moveTo(S * 0.36, S * 0.42); ctx.quadraticCurveTo(S * 0.5, S * 0.52, S * 0.64, S * 0.42); ctx.stroke();
    });
  }

  // ==================== MATERIAL ====================
  function drawGem(ctx, S, h1, h2) {
    const cx = S * 0.5, cy = S * 0.5;
    shadow(ctx, () => {
      ctx.beginPath();
      ctx.moveTo(cx, S * 0.2); ctx.lineTo(S * 0.74, S * 0.34); ctx.lineTo(S * 0.72, S * 0.72); ctx.lineTo(cx, S * 0.8); ctx.lineTo(S * 0.28, S * 0.72); ctx.lineTo(S * 0.26, S * 0.34); ctx.closePath();
      const g = ctx.createLinearGradient(cx, S * 0.2, cx, S * 0.8);
      g.addColorStop(0, hsla(h1, 60, 66, 1)); g.addColorStop(1, hsla(h1, 65, 42, 1)); ctx.fillStyle = g; ctx.fill();
      ctx.strokeStyle = hsla(h2, 20, 90, 0.5); ctx.lineWidth = S * 0.02;
      ctx.beginPath(); ctx.moveTo(cx, S * 0.2); ctx.lineTo(cx, S * 0.8); ctx.moveTo(S * 0.26, S * 0.34); ctx.lineTo(S * 0.72, S * 0.72); ctx.moveTo(S * 0.74, S * 0.34); ctx.lineTo(S * 0.28, S * 0.72); ctx.stroke();
    });
  }
  function drawDiamond(ctx, S, h1, h2) {
    const cx = S * 0.5;
    shadow(ctx, () => {
      ctx.beginPath();
      ctx.moveTo(cx, S * 0.16); ctx.lineTo(S * 0.72, S * 0.38); ctx.lineTo(cx, S * 0.82); ctx.lineTo(S * 0.28, S * 0.38); ctx.closePath();
      const g = ctx.createLinearGradient(cx, S * 0.16, cx, S * 0.82);
      g.addColorStop(0, hsla(h1, 60, 80, 1)); g.addColorStop(1, hsla(h1, 65, 46, 1)); ctx.fillStyle = g; ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.6)'; ctx.lineWidth = S * 0.02;
      ctx.beginPath(); ctx.moveTo(cx, S * 0.16); ctx.lineTo(cx, S * 0.82); ctx.moveTo(S * 0.28, S * 0.38); ctx.lineTo(S * 0.72, S * 0.38); ctx.stroke();
    });
  }
  function drawCrystal(ctx, S, h1, h2) {
    const cx = S * 0.5;
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(cx, S * 0.2, cx, S * 0.8);
      g.addColorStop(0, hsla(h1, 60, 70, 1)); g.addColorStop(1, hsla(h1, 65, 46, 1));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(S * 0.5, S * 0.14); ctx.lineTo(S * 0.6, S * 0.42); ctx.lineTo(S * 0.78, S * 0.82); ctx.lineTo(S * 0.52, S * 0.62); ctx.lineTo(S * 0.5, S * 0.84); ctx.lineTo(S * 0.3, S * 0.62); ctx.lineTo(S * 0.22, S * 0.82); ctx.lineTo(S * 0.4, S * 0.42); ctx.closePath(); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.55)';
      ctx.beginPath(); ctx.moveTo(S * 0.5, S * 0.14); ctx.lineTo(S * 0.6, S * 0.42); ctx.lineTo(S * 0.52, S * 0.46); ctx.closePath(); ctx.fill();
    });
  }
  function drawOre(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createRadialGradient(S * 0.42, S * 0.42, S * 0.05, S * 0.5, S * 0.52, S * 0.3);
      g.addColorStop(0, hsla(h1, 25, 48, 1)); g.addColorStop(1, hsla(h1, 28, 30, 1));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(S * 0.3, S * 0.62); ctx.lineTo(S * 0.22, S * 0.4); ctx.lineTo(S * 0.4, S * 0.26); ctx.lineTo(S * 0.62, S * 0.34); ctx.lineTo(S * 0.74, S * 0.56); ctx.lineTo(S * 0.56, S * 0.74); ctx.closePath(); ctx.fill();
      // ore veins
      ctx.fillStyle = hsla(h2, 60, 60, 1);
      [[0.42, 0.4], [0.56, 0.48], [0.36, 0.56]].forEach(([px, py]) => { ctx.beginPath(); ctx.arc(px * S, py * S, S * 0.05, 0, Math.PI * 2); ctx.fill(); });
    });
  }
  function drawIngot(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.3, S * 0.4, S * 0.7, S * 0.7);
      g.addColorStop(0, hsla(h1, 55, 72, 1)); g.addColorStop(1, hsla(h1, 58, 44, 1));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(S * 0.3, S * 0.4); ctx.lineTo(S * 0.38, S * 0.28); ctx.lineTo(S * 0.62, S * 0.28); ctx.lineTo(S * 0.7, S * 0.4); ctx.lineTo(S * 0.62, S * 0.7); ctx.lineTo(S * 0.38, S * 0.7); ctx.closePath(); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.4)'; rr(ctx, S * 0.4, S * 0.32, S * 0.2, S * 0.06, S * 0.02); ctx.fill();
    });
  }
  function drawWood(ctx, S, h1, h2) {
    shadow(ctx, () => {
      ctx.save(); ctx.translate(S * 0.5, S * 0.5); ctx.rotate(Math.PI / 5);
      const g = ctx.createLinearGradient(-S * 0.16, 0, S * 0.16, 0);
      g.addColorStop(0, hsla(h1, 40, 42, 1)); g.addColorStop(0.5, hsla(h1, 42, 54, 1)); g.addColorStop(1, hsla(h1, 40, 40, 1));
      ctx.fillStyle = g; rr(ctx, -S * 0.16, -S * 0.26, S * 0.32, S * 0.52, S * 0.07); ctx.fill();
      ctx.fillStyle = hsla(h2, 40, 30, 1); ctx.beginPath(); ctx.arc(0, 0, S * 0.07, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = hsla(h2, 40, 26, 0.6); ctx.lineWidth = S * 0.02;
      ctx.beginPath(); ctx.arc(0, 0, S * 0.1, 0, Math.PI * 2); ctx.stroke();
      ctx.restore();
    });
  }
  function drawRock(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createRadialGradient(S * 0.42, S * 0.4, S * 0.05, S * 0.5, S * 0.52, S * 0.3);
      g.addColorStop(0, hsla(h1, 20, 48, 1)); g.addColorStop(1, hsla(h1, 22, 30, 1));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(S * 0.3, S * 0.6); ctx.lineTo(S * 0.2, S * 0.36); ctx.lineTo(S * 0.42, S * 0.22); ctx.lineTo(S * 0.66, S * 0.28); ctx.lineTo(S * 0.76, S * 0.58); ctx.lineTo(S * 0.56, S * 0.74); ctx.closePath(); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.25)'; ctx.beginPath(); ctx.ellipse(S * 0.42, S * 0.34, S * 0.1, S * 0.05, -0.4, 0, Math.PI * 2); ctx.fill();
    });
  }
  function drawPearl(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createRadialGradient(S * 0.4, S * 0.4, S * 0.03, S * 0.5, S * 0.5, S * 0.3);
      g.addColorStop(0, hsla(h1, 40, 92, 1)); g.addColorStop(1, hsla(h1, 45, 70, 1));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(S * 0.5, S * 0.5, S * 0.28, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.7)'; ctx.beginPath(); ctx.arc(S * 0.4, S * 0.4, S * 0.08, 0, Math.PI * 2); ctx.fill();
    });
  }
  function drawCloth(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.3, S * 0.3, S * 0.7, S * 0.7);
      g.addColorStop(0, hsla(h1, 50, 60, 1)); g.addColorStop(1, hsla(h1, 52, 40, 1));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.moveTo(S * 0.3, S * 0.26); ctx.quadraticCurveTo(S * 0.2, S * 0.5, S * 0.3, S * 0.74); ctx.quadraticCurveTo(S * 0.5, S * 0.66, S * 0.7, S * 0.74); ctx.quadraticCurveTo(S * 0.8, S * 0.5, S * 0.7, S * 0.26); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = hsla(h2, 40, 50, 0.5); ctx.lineWidth = S * 0.02;
      for (let i = 1; i <= 3; i++) { ctx.beginPath(); ctx.moveTo(S * 0.28, S * 0.3 + i * S * 0.11); ctx.quadraticCurveTo(S * 0.5, S * 0.36 + i * S * 0.11, S * 0.72, S * 0.3 + i * S * 0.11); ctx.stroke(); }
    });
  }
  function drawBone(ctx, S, h1, h2) {
    shadow(ctx, () => {
      ctx.save(); ctx.translate(S * 0.5, S * 0.5); ctx.rotate(Math.PI / 4);
      const g = ctx.createLinearGradient(-S * 0.2, 0, S * 0.2, 0);
      g.addColorStop(0, hsla(h1, 35, 80, 1)); g.addColorStop(1, hsla(h1, 35, 62, 1));
      ctx.fillStyle = g; rr(ctx, -S * 0.2, -S * 0.06, S * 0.4, S * 0.12, S * 0.04); ctx.fill();
      ctx.fillStyle = hsla(h1, 35, 78, 1);
      ctx.beginPath(); ctx.arc(-S * 0.2, -S * 0.06, S * 0.07, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(-S * 0.2, S * 0.06, S * 0.07, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(S * 0.2, -S * 0.06, S * 0.07, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(S * 0.2, S * 0.06, S * 0.07, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
    });
  }

  // ==================== ARTEFAK ====================
  function drawStatue(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.3, S * 0.2, S * 0.7, S * 0.8);
      g.addColorStop(0, hsla(h1, 25, 55, 1)); g.addColorStop(1, hsla(h1, 28, 34, 1));
      ctx.fillStyle = g;
      // head
      ctx.beginPath(); ctx.arc(S * 0.5, S * 0.28, S * 0.1, 0, Math.PI * 2); ctx.fill();
      // body (bust)
      ctx.beginPath(); ctx.moveTo(S * 0.32, S * 0.76); ctx.lineTo(S * 0.32, S * 0.48); ctx.quadraticCurveTo(S * 0.32, S * 0.36, S * 0.42, S * 0.36); ctx.lineTo(S * 0.58, S * 0.36); ctx.quadraticCurveTo(S * 0.68, S * 0.36, S * 0.68, S * 0.48); ctx.lineTo(S * 0.68, S * 0.76); ctx.closePath(); ctx.fill();
      // pedestal
      ctx.fillStyle = hsla(h1, 25, 40, 1); rr(ctx, S * 0.24, S * 0.76, S * 0.52, S * 0.1, S * 0.02); ctx.fill();
    });
  }
  function drawBook(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.24, S * 0.3, S * 0.76, S * 0.7);
      g.addColorStop(0, hsla(h1, 35, 46, 1)); g.addColorStop(1, hsla(h1, 38, 30, 1));
      ctx.fillStyle = g; rr(ctx, S * 0.24, S * 0.28, S * 0.52, S * 0.46, S * 0.04); ctx.fill();
      ctx.strokeStyle = hsla(h2, 40, 50, 1); ctx.lineWidth = S * 0.025;
      ctx.beginPath(); ctx.moveTo(S * 0.5, S * 0.28); ctx.lineTo(S * 0.5, S * 0.74); ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,0.35)'; rr(ctx, S * 0.28, S * 0.34, S * 0.18, S * 0.06, S * 0.02); ctx.fill();
      rr(ctx, S * 0.54, S * 0.34, S * 0.18, S * 0.06, S * 0.02); ctx.fill();
    });
  }
  function drawMirror(ctx, S, h1, h2) {
    shadow(ctx, () => {
      ctx.strokeStyle = hsla(h1, 45, 62, 1); ctx.lineWidth = S * 0.06;
      ctx.beginPath(); ctx.ellipse(S * 0.5, S * 0.44, S * 0.2, S * 0.24, 0, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = 'rgba(160,200,255,0.35)'; ctx.beginPath(); ctx.ellipse(S * 0.5, S * 0.44, S * 0.17, S * 0.21, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = hsla(h1, 45, 58, 1); rr(ctx, S * 0.46, S * 0.66, S * 0.08, S * 0.16, S * 0.03); ctx.fill();
    });
  }
  function drawGoblet(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.5, S * 0.2, S * 0.5, S * 0.66);
      g.addColorStop(0, hsla(h1, 50, 62, 1)); g.addColorStop(1, hsla(h1, 55, 40, 1));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.moveTo(S * 0.34, S * 0.22); ctx.lineTo(S * 0.66, S * 0.22); ctx.quadraticCurveTo(S * 0.6, S * 0.66, S * 0.5, S * 0.66); ctx.quadraticCurveTo(S * 0.4, S * 0.66, S * 0.34, S * 0.22); ctx.closePath(); ctx.fill();
      ctx.fillStyle = hsla(h1, 50, 55, 1); ctx.fillRect(S * 0.46, S * 0.66, S * 0.08, S * 0.1);
      ctx.fillStyle = hsla(h1, 50, 48, 1); rr(ctx, S * 0.36, S * 0.76, S * 0.28, S * 0.06, S * 0.02); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.4)'; rr(ctx, S * 0.38, S * 0.26, S * 0.04, S * 0.18, S * 0.02); ctx.fill();
    });
  }
  function drawMask(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.3, S * 0.3, S * 0.7, S * 0.7);
      g.addColorStop(0, hsla(h1, 45, 55, 1)); g.addColorStop(1, hsla(h1, 48, 34, 1));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.ellipse(S * 0.5, S * 0.52, S * 0.24, S * 0.3, 0, 0, Math.PI * 2); ctx.fill();
      // eyes
      ctx.fillStyle = hsla(h2, 20, 20, 1);
      ctx.beginPath(); ctx.ellipse(S * 0.4, S * 0.44, S * 0.05, S * 0.08, 0.2, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.ellipse(S * 0.6, S * 0.44, S * 0.05, S * 0.08, -0.2, 0, Math.PI * 2); ctx.fill();
      // mouth
      ctx.strokeStyle = hsla(h2, 20, 20, 1); ctx.lineWidth = S * 0.03;
      ctx.beginPath(); ctx.arc(S * 0.5, S * 0.6, S * 0.1, 0.2, Math.PI - 0.2); ctx.stroke();
    });
  }
  function drawOrb(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createRadialGradient(S * 0.4, S * 0.38, S * 0.03, S * 0.5, S * 0.5, S * 0.32);
      g.addColorStop(0, hsla(h1, 65, 70, 1)); g.addColorStop(1, hsla(h1, 68, 40, 1));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(S * 0.5, S * 0.5, S * 0.3, 0, Math.PI * 2); ctx.fill();
      // ring orbit
      ctx.strokeStyle = hsla(h2, 60, 70, 0.7); ctx.lineWidth = S * 0.025;
      ctx.beginPath(); ctx.ellipse(S * 0.5, S * 0.5, S * 0.34, S * 0.12, -0.5, 0, Math.PI * 2); ctx.stroke();
    });
  }
  function drawTablet(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.3, S * 0.3, S * 0.7, S * 0.7);
      g.addColorStop(0, hsla(h1, 20, 55, 1)); g.addColorStop(1, hsla(h1, 22, 36, 1));
      ctx.fillStyle = g; rr(ctx, S * 0.24, S * 0.24, S * 0.52, S * 0.56, S * 0.06); ctx.fill();
      ctx.strokeStyle = hsla(h2, 20, 30, 0.8); ctx.lineWidth = S * 0.02;
      for (let i = 1; i <= 4; i++) { ctx.beginPath(); ctx.moveTo(S * 0.3, S * 0.28 + i * S * 0.1); ctx.lineTo(S * 0.7, S * 0.28 + i * S * 0.1); ctx.stroke(); }
    });
  }
  function drawPainting(ctx, S, h1, h2) {
    shadow(ctx, () => {
      ctx.fillStyle = hsla(h1, 40, 40, 1); rr(ctx, S * 0.18, S * 0.22, S * 0.64, S * 0.56, S * 0.03); ctx.fill();
      const g = ctx.createLinearGradient(S * 0.24, S * 0.3, S * 0.76, S * 0.7);
      g.addColorStop(0, hsla(h2, 60, 62, 1)); g.addColorStop(1, hsla(h2, 62, 36, 1));
      ctx.fillStyle = g; rr(ctx, S * 0.24, S * 0.28, S * 0.52, S * 0.44, S * 0.02); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.5)'; ctx.beginPath(); ctx.arc(S * 0.5, S * 0.42, S * 0.1, 0, Math.PI * 2); ctx.fill();
    });
  }

  // ==================== KOLEKSI ====================
  function drawCoin(ctx, S, h1, h2) {
    const cx = S * 0.5, cy = S * 0.5, r = S * 0.3;
    shadow(ctx, () => {
      const g = ctx.createRadialGradient(cx - r * 0.3, cy - r * 0.3, r * 0.2, cx, cy, r);
      g.addColorStop(0, hsla(h1, 80, 72, 1)); g.addColorStop(1, hsla(h1, 80, 46, 1));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = hsla(h1, 85, 32, 1); ctx.lineWidth = S * 0.025; ctx.stroke();
      ctx.fillStyle = hsla(h1, 90, 34, 1); star(ctx, cx, cy, r * 0.5, 5);
    });
  }
  function drawFossil(ctx, S, h1, h2) {
    shadow(ctx, () => {
      ctx.strokeStyle = hsla(h1, 25, 72, 1); ctx.lineWidth = S * 0.05; ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(S * 0.5, S * 0.5);
      for (let i = 0; i < 3; i++) {
        const a = -Math.PI / 2 + i * (Math.PI / 3);
        const ex = S * 0.5 + Math.cos(a) * S * 0.18, ey = S * 0.5 + Math.sin(a) * S * 0.18;
        ctx.lineTo(ex, ey);
        for (let j = 1; j <= 3; j++) { const ba = a - 0.5 + j * 0.25; const bx = ex + Math.cos(ba) * S * 0.09, by = ey + Math.sin(ba) * S * 0.09; ctx.lineTo(bx, by); ctx.moveTo(ex, ey); }
        ctx.moveTo(S * 0.5, S * 0.5);
      }
      ctx.stroke();
    });
  }
  function drawShell(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.3, S * 0.3, S * 0.7, S * 0.7);
      g.addColorStop(0, hsla(h1, 40, 66, 1)); g.addColorStop(1, hsla(h1, 45, 40, 1));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.moveTo(S * 0.28, S * 0.7); ctx.quadraticCurveTo(S * 0.2, S * 0.4, S * 0.5, S * 0.28); ctx.quadraticCurveTo(S * 0.8, S * 0.4, S * 0.72, S * 0.7); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = hsla(h2, 30, 40, 0.7); ctx.lineWidth = S * 0.02;
      for (let i = 1; i <= 3; i++) { ctx.beginPath(); ctx.moveTo(S * 0.3 + i * S * 0.06, S * 0.68); ctx.quadraticCurveTo(S * 0.5, S * 0.3 + i * S * 0.06, S * 0.7 - i * S * 0.06, S * 0.68); ctx.stroke(); }
    });
  }
  function drawMap(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.3, S * 0.3, S * 0.7, S * 0.7);
      g.addColorStop(0, hsla(h1, 40, 78, 1)); g.addColorStop(1, hsla(h1, 42, 58, 1));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.moveTo(S * 0.24, S * 0.34); ctx.lineTo(S * 0.6, S * 0.28); ctx.lineTo(S * 0.78, S * 0.34); ctx.lineTo(S * 0.7, S * 0.7); ctx.lineTo(S * 0.36, S * 0.76); ctx.lineTo(S * 0.24, S * 0.6); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = hsla(h2, 40, 30, 0.7); ctx.lineWidth = S * 0.02;
      ctx.beginPath(); ctx.moveTo(S * 0.32, S * 0.4); ctx.lineTo(S * 0.5, S * 0.48); ctx.lineTo(S * 0.46, S * 0.64); ctx.moveTo(S * 0.6, S * 0.36); ctx.lineTo(S * 0.68, S * 0.56); ctx.stroke();
      ctx.fillStyle = hsla(h2, 60, 55, 1); ctx.beginPath(); ctx.arc(S * 0.5, S * 0.48, S * 0.04, 0, Math.PI * 2); ctx.fill();
    });
  }
  function drawVase(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.5, S * 0.2, S * 0.5, S * 0.78);
      g.addColorStop(0, hsla(h1, 45, 58, 1)); g.addColorStop(1, hsla(h1, 48, 36, 1));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(S * 0.4, S * 0.22); ctx.lineTo(S * 0.6, S * 0.22);
      ctx.quadraticCurveTo(S * 0.68, S * 0.4, S * 0.6, S * 0.56);
      ctx.quadraticCurveTo(S * 0.5, S * 0.64, S * 0.4, S * 0.56);
      ctx.quadraticCurveTo(S * 0.32, S * 0.4, S * 0.4, S * 0.22); ctx.closePath(); ctx.fill();
      ctx.fillStyle = hsla(h1, 45, 52, 1); ctx.fillRect(S * 0.42, S * 0.56, S * 0.16, S * 0.08);
      ctx.fillStyle = hsla(h1, 45, 46, 1); rr(ctx, S * 0.36, S * 0.66, S * 0.28, S * 0.08, S * 0.03); ctx.fill();
    });
  }
  function drawRelic(ctx, S, h1, h2) {
    drawCrystal(ctx, S, h1, h2);
    ctx.fillStyle = hsla(h2, 70, 70, 0.8); ctx.beginPath(); ctx.arc(S * 0.5, S * 0.3, S * 0.03, 0, Math.PI * 2); ctx.fill();
  }
  function drawStamp(ctx, S, h1, h2) {
    shadow(ctx, () => {
      ctx.fillStyle = hsla(h1, 40, 66, 1); rr(ctx, S * 0.22, S * 0.26, S * 0.56, S * 0.52, S * 0.03); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.9)'; rr(ctx, S * 0.28, S * 0.32, S * 0.44, S * 0.4, S * 0.02); ctx.fill();
      ctx.fillStyle = hsla(h2, 55, 45, 1); ctx.beginPath(); ctx.arc(S * 0.5, S * 0.5, S * 0.1, 0, Math.PI * 2); ctx.fill();
      // perforations
      ctx.fillStyle = 'rgba(0,0,0,0.35)';
      for (let i = 0; i < 10; i++) { ctx.beginPath(); ctx.arc(S * 0.24 + i * S * 0.058, S * 0.26, S * 0.012, 0, Math.PI * 2); ctx.fill(); ctx.beginPath(); ctx.arc(S * 0.24 + i * S * 0.058, S * 0.78, S * 0.012, 0, Math.PI * 2); ctx.fill(); }
    });
  }
  function drawCard(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.3, S * 0.3, S * 0.7, S * 0.7);
      g.addColorStop(0, hsla(h1, 55, 60, 1)); g.addColorStop(1, hsla(h1, 58, 40, 1));
      ctx.fillStyle = g; rr(ctx, S * 0.34, S * 0.22, S * 0.32, S * 0.56, S * 0.04); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = S * 0.02; rr(ctx, S * 0.38, S * 0.26, S * 0.24, S * 0.48, S * 0.03); ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,0.85)'; ctx.font = `700 ${S * 0.16}px sans-serif`; ctx.textAlign = 'center'; ctx.fillText('A', S * 0.5, S * 0.56);
    });
  }
  function drawBead(ctx, S, h1, h2) {
    shadow(ctx, () => {
      for (let i = 0; i < 3; i++) {
        const g = ctx.createRadialGradient(S * 0.36 + i * S * 0.14, S * 0.42, S * 0.02, S * 0.42 + i * S * 0.14, S * 0.5, S * 0.12);
        g.addColorStop(0, hsla(h1, 60, 70, 1)); g.addColorStop(1, hsla(h1, 62, 44, 1));
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(S * 0.36 + i * S * 0.14, S * 0.5, S * 0.1, 0, Math.PI * 2); ctx.fill();
      }
      ctx.fillStyle = hsla(h2, 50, 50, 0.6); ctx.beginPath(); ctx.arc(S * 0.5, S * 0.72, S * 0.03, 0, Math.PI * 2); ctx.fill();
    });
  }

  // ==================== KOSMETIK ====================
  function drawHat(ctx, S, h1, h2) {
    const cx = S * 0.5;
    shadow(ctx, () => {
      ctx.fillStyle = hsla(h1, 45, 40, 1); ctx.beginPath(); ctx.ellipse(cx, S * 0.7, S * 0.3, S * 0.1, 0, 0, Math.PI * 2); ctx.fill();
      const g = ctx.createLinearGradient(cx, S * 0.14, cx, S * 0.7);
      g.addColorStop(0, hsla(h1, 50, 60, 1)); g.addColorStop(1, hsla(h1, 50, 38, 1));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.moveTo(cx, S * 0.14); ctx.lineTo(cx + S * 0.22, S * 0.62); ctx.quadraticCurveTo(cx, S * 0.72, cx - S * 0.22, S * 0.62); ctx.closePath(); ctx.fill();
      ctx.fillStyle = hsla(h2, 55, 50, 1); ctx.fillRect(cx - S * 0.2, S * 0.56, S * 0.4, S * 0.06);
    });
  }
  function drawGlasses(ctx, S, h1, h2) {
    shadow(ctx, () => {
      ctx.strokeStyle = hsla(h1, 45, 55, 1); ctx.lineWidth = S * 0.045;
      ctx.beginPath(); ctx.arc(S * 0.36, S * 0.46, S * 0.13, 0, Math.PI * 2); ctx.stroke();
      ctx.beginPath(); ctx.arc(S * 0.64, S * 0.46, S * 0.13, 0, Math.PI * 2); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(S * 0.49, S * 0.46); ctx.lineTo(S * 0.51, S * 0.46); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(S * 0.23, S * 0.46); ctx.lineTo(S * 0.14, S * 0.44); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(S * 0.77, S * 0.46); ctx.lineTo(S * 0.86, S * 0.44); ctx.stroke();
      ctx.fillStyle = hsla(h2, 60, 62, 0.35);
      ctx.beginPath(); ctx.arc(S * 0.36, S * 0.46, S * 0.11, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(S * 0.64, S * 0.46, S * 0.11, 0, Math.PI * 2); ctx.fill();
    });
  }
  function drawScarf(ctx, S, h1, h2) {
    shadow(ctx, () => {
      ctx.fillStyle = hsla(h1, 50, 58, 1);
      ctx.beginPath(); ctx.arc(S * 0.5, S * 0.3, S * 0.16, Math.PI, 0); ctx.fill();
      rr(ctx, S * 0.3, S * 0.28, S * 0.4, S * 0.14, S * 0.04); ctx.fill();
      const g = ctx.createLinearGradient(S * 0.3, S * 0.5, S * 0.7, S * 0.8);
      g.addColorStop(0, hsla(h1, 50, 58, 1)); g.addColorStop(1, hsla(h1, 52, 40, 1));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.moveTo(S * 0.36, S * 0.42); ctx.lineTo(S * 0.64, S * 0.42); ctx.lineTo(S * 0.56, S * 0.78); ctx.lineTo(S * 0.44, S * 0.78); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = hsla(h2, 40, 50, 0.6); ctx.lineWidth = S * 0.02;
      for (let i = 1; i <= 3; i++) { ctx.beginPath(); ctx.moveTo(S * 0.4, S * 0.48 + i * S * 0.08); ctx.lineTo(S * 0.6, S * 0.48 + i * S * 0.08); ctx.stroke(); }
    });
  }
  function drawWatch(ctx, S, h1, h2) {
    shadow(ctx, () => {
      ctx.strokeStyle = hsla(h2, 40, 40, 1); ctx.lineWidth = S * 0.05;
      ctx.beginPath(); ctx.moveTo(S * 0.32, S * 0.3); ctx.lineTo(S * 0.4, S * 0.4); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(S * 0.68, S * 0.3); ctx.lineTo(S * 0.6, S * 0.4); ctx.stroke();
      const g = ctx.createRadialGradient(S * 0.42, S * 0.46, S * 0.03, S * 0.5, S * 0.56, S * 0.24);
      g.addColorStop(0, hsla(h1, 45, 70, 1)); g.addColorStop(1, hsla(h1, 48, 44, 1));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(S * 0.5, S * 0.56, S * 0.22, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.9)'; ctx.beginPath(); ctx.arc(S * 0.5, S * 0.56, S * 0.15, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = hsla(h1, 40, 30, 1); ctx.lineWidth = S * 0.02;
      ctx.beginPath(); ctx.moveTo(S * 0.5, S * 0.56); ctx.lineTo(S * 0.5, S * 0.46); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(S * 0.5, S * 0.56); ctx.lineTo(S * 0.58, S * 0.6); ctx.stroke();
    });
  }
  function drawShoes(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.3, S * 0.5, S * 0.7, S * 0.7);
      g.addColorStop(0, hsla(h1, 35, 52, 1)); g.addColorStop(1, hsla(h1, 40, 34, 1));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.moveTo(S * 0.2, S * 0.62); ctx.lineTo(S * 0.42, S * 0.62); ctx.lineTo(S * 0.5, S * 0.76); ctx.lineTo(S * 0.2, S * 0.76); ctx.closePath(); ctx.fill();
      ctx.beginPath(); ctx.moveTo(S * 0.5, S * 0.62); ctx.lineTo(S * 0.8, S * 0.62); ctx.lineTo(S * 0.8, S * 0.76); ctx.lineTo(S * 0.5, S * 0.76); ctx.closePath(); ctx.fill();
      ctx.fillStyle = hsla(h2, 40, 45, 1); rr(ctx, S * 0.2, S * 0.66, S * 0.6, S * 0.04, S * 0.02); ctx.fill();
    });
  }
  function drawCoat(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.3, S * 0.3, S * 0.7, S * 0.7);
      g.addColorStop(0, hsla(h1, 40, 50, 1)); g.addColorStop(1, hsla(h1, 42, 32, 1));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.moveTo(S * 0.34, S * 0.26); ctx.lineTo(S * 0.66, S * 0.26); ctx.lineTo(S * 0.74, S * 0.78); ctx.lineTo(S * 0.26, S * 0.78); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = hsla(h2, 40, 44, 1); ctx.lineWidth = S * 0.02;
      ctx.beginPath(); ctx.moveTo(S * 0.5, S * 0.26); ctx.lineTo(S * 0.5, S * 0.78); ctx.stroke();
      ctx.fillStyle = hsla(h2, 50, 55, 1); ctx.fillRect(S * 0.4, S * 0.36, S * 0.04, S * 0.04); ctx.fillRect(S * 0.56, S * 0.36, S * 0.04, S * 0.04);
    });
  }
  function drawDress(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.3, S * 0.24, S * 0.7, S * 0.8);
      g.addColorStop(0, hsla(h1, 55, 60, 1)); g.addColorStop(1, hsla(h1, 58, 38, 1));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.moveTo(S * 0.4, S * 0.24); ctx.lineTo(S * 0.6, S * 0.24); ctx.lineTo(S * 0.76, S * 0.78); ctx.lineTo(S * 0.24, S * 0.78); ctx.closePath(); ctx.fill();
      ctx.fillStyle = hsla(h2, 50, 55, 1); ctx.fillRect(S * 0.4, S * 0.24, S * 0.2, S * 0.06);
    });
  }
  function drawGlove(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.3, S * 0.3, S * 0.7, S * 0.7);
      g.addColorStop(0, hsla(h1, 40, 55, 1)); g.addColorStop(1, hsla(h1, 42, 36, 1));
      ctx.fillStyle = g;
      rr(ctx, S * 0.3, S * 0.34, S * 0.4, S * 0.36, S * 0.08); ctx.fill();
      ctx.fillStyle = g; rr(ctx, S * 0.34, S * 0.68, S * 0.16, S * 0.12, S * 0.05); ctx.fill();
    });
  }

  // ==================== MAKANAN ====================
  function drawFruit(ctx, S, h1, h2) {
    const cx = S * 0.5, cy = S * 0.58, r = S * 0.24;
    shadow(ctx, () => {
      const g = ctx.createRadialGradient(cx - r * 0.3, cy - r * 0.3, r * 0.2, cx, cy, r);
      g.addColorStop(0, hsla(h1, 70, 66, 1)); g.addColorStop(1, hsla(h1, 72, 42, 1));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = hsla(h2, 40, 30, 1); ctx.lineWidth = S * 0.03;
      ctx.beginPath(); ctx.moveTo(cx, cy - r * 0.7); ctx.quadraticCurveTo(cx + S * 0.04, cy - r * 1.1, cx + S * 0.08, cy - r * 1.15); ctx.stroke();
      ctx.fillStyle = hsla(h2, 55, 45, 1); ctx.beginPath(); ctx.ellipse(cx + S * 0.1, cy - r * 1.05, S * 0.07, S * 0.035, -0.5, 0, Math.PI * 2); ctx.fill();
    });
  }
  function drawBread(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.3, S * 0.36, S * 0.7, S * 0.72);
      g.addColorStop(0, hsla(h1, 45, 62, 1)); g.addColorStop(1, hsla(h1, 48, 40, 1));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.ellipse(S * 0.5, S * 0.56, S * 0.26, S * 0.2, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = hsla(h2, 30, 38, 1);
      for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.arc(S * 0.36 + i * S * 0.13, S * 0.56, S * 0.025, 0, Math.PI * 2); ctx.fill(); }
    });
  }
  function drawMeat(ctx, S, h1, h2) {
    shadow(ctx, () => {
      ctx.save(); ctx.translate(S * 0.5, S * 0.5); ctx.rotate(Math.PI / 6);
      const g = ctx.createRadialGradient(0, -S * 0.06, S * 0.03, 0, 0, S * 0.26);
      g.addColorStop(0, hsla(h1, 45, 62, 1)); g.addColorStop(1, hsla(h1, 48, 40, 1));
      ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(0, 0, S * 0.2, S * 0.16, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = hsla(h2, 30, 28, 1); ctx.lineWidth = S * 0.05;
      ctx.beginPath(); ctx.moveTo(S * 0.1, S * 0.06); ctx.lineTo(S * 0.2, S * 0.2); ctx.stroke();
      ctx.restore();
    });
  }
  function drawFish(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.3, S * 0.3, S * 0.7, S * 0.7);
      g.addColorStop(0, hsla(h1, 55, 60, 1)); g.addColorStop(1, hsla(h1, 58, 38, 1));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.ellipse(S * 0.5, S * 0.5, S * 0.26, S * 0.16, 0, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.moveTo(S * 0.76, S * 0.5); ctx.lineTo(S * 0.88, S * 0.36); ctx.lineTo(S * 0.88, S * 0.64); ctx.closePath(); ctx.fill();
      ctx.fillStyle = hsla(h2, 20, 22, 1); ctx.beginPath(); ctx.arc(S * 0.36, S * 0.42, S * 0.03, 0, Math.PI * 2); ctx.fill();
    });
  }
  function drawCheese(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.3, S * 0.4, S * 0.7, S * 0.7);
      g.addColorStop(0, hsla(h1, 55, 66, 1)); g.addColorStop(1, hsla(h1, 58, 44, 1));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.moveTo(S * 0.3, S * 0.4); ctx.lineTo(S * 0.7, S * 0.4); ctx.lineTo(S * 0.7, S * 0.7); ctx.lineTo(S * 0.3, S * 0.7); ctx.closePath(); ctx.fill();
      ctx.fillStyle = hsla(h2, 45, 40, 0.7);
      [[0.42, 0.52], [0.56, 0.58], [0.48, 0.64]].forEach(([px, py]) => { ctx.beginPath(); ctx.arc(px * S, py * S, S * 0.035, 0, Math.PI * 2); ctx.fill(); });
    });
  }
  function drawEgg(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createRadialGradient(S * 0.42, S * 0.4, S * 0.03, S * 0.5, S * 0.52, S * 0.28);
      g.addColorStop(0, hsla(h1, 45, 82, 1)); g.addColorStop(1, hsla(h1, 48, 60, 1));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.ellipse(S * 0.5, S * 0.52, S * 0.2, S * 0.26, 0, 0, Math.PI * 2); ctx.fill();
    });
  }
  function drawCookie(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createRadialGradient(S * 0.42, S * 0.42, S * 0.03, S * 0.5, S * 0.52, S * 0.3);
      g.addColorStop(0, hsla(h1, 45, 58, 1)); g.addColorStop(1, hsla(h1, 48, 38, 1));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(S * 0.5, S * 0.52, S * 0.26, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = hsla(h2, 40, 34, 1);
      [[0.4, 0.44], [0.6, 0.42], [0.5, 0.6], [0.36, 0.58], [0.64, 0.58]].forEach(([px, py]) => { ctx.beginPath(); ctx.arc(px * S, py * S, S * 0.04, 0, Math.PI * 2); ctx.fill(); });
    });
  }
  function drawSoup(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.3, S * 0.44, S * 0.7, S * 0.66);
      g.addColorStop(0, hsla(h1, 40, 52, 1)); g.addColorStop(1, hsla(h1, 42, 34, 1));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(S * 0.5, S * 0.56, S * 0.24, Math.PI, 0); ctx.closePath(); ctx.fill();
      rr(ctx, S * 0.26, S * 0.54, S * 0.48, S * 0.14, S * 0.04); ctx.fill();
      ctx.fillStyle = hsla(h2, 60, 55, 1); ctx.beginPath(); ctx.ellipse(S * 0.5, S * 0.5, S * 0.18, S * 0.05, 0, 0, Math.PI * 2); ctx.fill();
      // steam
      ctx.strokeStyle = 'rgba(255,255,255,0.5)'; ctx.lineWidth = S * 0.02;
      ctx.beginPath(); ctx.moveTo(S * 0.42, S * 0.36); ctx.quadraticCurveTo(S * 0.4, S * 0.28, S * 0.44, S * 0.22); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(S * 0.58, S * 0.36); ctx.quadraticCurveTo(S * 0.6, S * 0.28, S * 0.56, S * 0.22); ctx.stroke();
    });
  }
  function drawChocolate(ctx, S, h1, h2) {
    shadow(ctx, () => {
      const g = ctx.createLinearGradient(S * 0.3, S * 0.3, S * 0.7, S * 0.7);
      g.addColorStop(0, hsla(h1, 45, 50, 1)); g.addColorStop(1, hsla(h1, 48, 32, 1));
      ctx.fillStyle = g; rr(ctx, S * 0.22, S * 0.34, S * 0.56, S * 0.4, S * 0.04); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.25)'; ctx.lineWidth = S * 0.02;
      for (let i = 1; i <= 3; i++) { ctx.beginPath(); ctx.moveTo(S * 0.22 + i * S * 0.14, S * 0.34); ctx.lineTo(S * 0.22 + i * S * 0.14, S * 0.74); ctx.stroke(); }
      ctx.beginPath(); ctx.moveTo(S * 0.22, S * 0.34 + S * 0.2); ctx.lineTo(S * 0.78, S * 0.34 + S * 0.2); ctx.stroke();
    });
  }
  function drawMilk(ctx, S, h1, h2) {
    shadow(ctx, () => {
      ctx.fillStyle = hsla(h1, 20, 60, 1); rr(ctx, S * 0.34, S * 0.34, S * 0.32, S * 0.42, S * 0.04); ctx.fill();
      ctx.fillStyle = hsla(h1, 20, 50, 1); rr(ctx, S * 0.4, S * 0.2, S * 0.2, S * 0.16, S * 0.03); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.5)'; rr(ctx, S * 0.38, S * 0.4, S * 0.05, S * 0.3, S * 0.02); ctx.fill();
      ctx.fillStyle = hsla(h2, 40, 60, 0.6); ctx.beginPath(); ctx.arc(S * 0.5, S * 0.24, S * 0.04, 0, Math.PI * 2); ctx.fill();
    });
  }

  // ==================== BANK ====================
  function drawBank(ctx, S, h1, h2) {
    const cx = S * 0.5;
    shadow(ctx, () => {
      ctx.fillStyle = hsla(h1, 30, 55, 1);
      ctx.beginPath(); ctx.moveTo(cx, S * 0.16); ctx.lineTo(S * 0.82, S * 0.3); ctx.lineTo(S * 0.18, S * 0.3); ctx.closePath(); ctx.fill();
      const g = ctx.createLinearGradient(cx, S * 0.3, cx, S * 0.84);
      g.addColorStop(0, hsla(h1, 25, 62, 1)); g.addColorStop(1, hsla(h1, 28, 40, 1));
      ctx.fillStyle = g; ctx.fillRect(S * 0.22, S * 0.3, S * 0.56, S * 0.54);
      ctx.fillStyle = hsla(h2, 15, 80, 1);
      ctx.fillRect(S * 0.3, S * 0.34, S * 0.07, S * 0.46);
      ctx.fillRect(S * 0.63, S * 0.34, S * 0.07, S * 0.46);
      ctx.fillStyle = hsla(h2, 45, 34, 1);
      ctx.beginPath(); ctx.moveTo(cx, S * 0.5); ctx.lineTo(cx + S * 0.1, S * 0.84); ctx.lineTo(cx - S * 0.1, S * 0.84); ctx.closePath(); ctx.fill();
    });
  }

  const DRAWERS = {
    sword: drawSword, dagger: drawDagger, katana: drawKatana, axe: drawAxe, bow: drawBow,
    staff: drawStaff, hammer: drawHammer, spear: drawSpear,
    shield: drawShield, helmet: drawHelmet, chestplate: drawChestplate, gauntlet: drawGauntlet,
    ring: drawRing, necklace: drawNecklace, earring: drawEarring, bracelet: drawBracelet,
    crown: drawCrown, amulet: drawAmulet,
    potion: drawPotion, vial: drawVial, elixir: drawElixir,
    box: drawBox, scroll: drawScroll, ticket: drawTicket, key: drawKey, bag: drawBag,
    gem: drawGem, diamond: drawDiamond, crystal: drawCrystal, ore: drawOre, ingot: drawIngot,
    wood: drawWood, rock: drawRock, pearl: drawPearl, cloth: drawCloth, bone: drawBone,
    statue: drawStatue, book: drawBook, mirror: drawMirror, goblet: drawGoblet, mask: drawMask,
    orb: drawOrb, tablet: drawTablet, painting: drawPainting,
    coin: drawCoin, fossil: drawFossil, shell: drawShell, map: drawMap, vase: drawVase,
    relic: drawRelic, stamp: drawStamp, card: drawCard, bead: drawBead,
    hat: drawHat, glasses: drawGlasses, scarf: drawScarf, watch: drawWatch, shoes: drawShoes,
    coat: drawCoat, dress: drawDress, glove: drawGlove,
    fruit: drawFruit, bread: drawBread, meat: drawMeat, fish: drawFish, cheese: drawCheese,
    egg: drawEgg, cookie: drawCookie, soup: drawSoup, chocolate: drawChocolate, milk: drawMilk,
    bank: drawBank,
  };

  // ---------- API ----------
  function draw(canvas, id, category, size) {
    size = size || 48;
    const dpr = (typeof window !== 'undefined' && window.devicePixelRatio) || 1;
    canvas.width = size * dpr;
    canvas.height = size * dpr;
    canvas.style.width = size + 'px';
    canvas.style.height = size + 'px';
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const h = hash(String(id || category || 'x'));
    const shape = shapeFor(String(id), category);
    const bgHue = (HUE_BASE[category] || 32) + (h % 30) - 15;
    const h1 = h % 360;            // warna utama bentuk (sangat bervariasi per item)
    const h2 = (h >>> 5) % 360;    // warna aksen
    baseLayer(ctx, size, (bgHue + 360) % 360);
    const drawer = DRAWERS[shape] || drawBox;
    drawer(ctx, size, h1, h2);
    return canvas;
  }

  function toCanvas(id, category, size) {
    const c = document.createElement('canvas');
    draw(c, id, category, size);
    return c;
  }

  window.ItemIcons = { draw, toCanvas, shapeFor };
})();
