const { SlashCommandBuilder } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { safeDefer } = require('../../utils/interactionHelpers');
const { fetchExternal } = require('../../utils/httpClient');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  subcommandOf: true,
  data: new SlashCommandBuilder()
    .setName('urlshorten')
    .setDescription('Perpendek link/URL panjang')
    .addStringOption(o => o.setName('url').setDescription('URL yang ingin diperpendek').setRequired(true)),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const url = interaction.options.getString('url');

    if (!/^https?:\/\//i.test(url)) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'url.invalid'))], ephemeral: true });
    }

    if (!(await safeDefer(interaction))) return;

    try {
      const res = await fetchExternal(`https://is.gd/create.php?format=simple&url=${encodeURIComponent(url)}`);
      if (!res.ok) throw new Error(`is.gd merespons status ${res.status}`);
      const shortUrl = (await res.text()).trim();

      if (!shortUrl.startsWith('http')) {
        return interaction.editReply({ embeds: [errorEmbed(t(lang, 'util.url_fail', { err: shortUrl }))] });
      }

      return interaction.editReply({ embeds: [successEmbed(t(lang, 'url.ok', { url: shortUrl }))] });
    } catch (err) {
      console.error('[urlshorten] Gagal memperpendek URL:', err.message);
      return interaction.editReply({ embeds: [errorEmbed(t(lang, 'url.fail'))] }).catch(() => {});
    }
  },
};
