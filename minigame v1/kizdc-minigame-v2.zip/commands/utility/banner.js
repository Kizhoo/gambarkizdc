const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  subcommandOf: true,
  data: new SlashCommandBuilder()
    .setName('banner')
    .setDescription('Lihat banner profil user')
    .addUserOption(o => o.setName('target').setDescription('User yang ingin dilihat bannernya')),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const userOption = interaction.options.getUser('target') || interaction.user;
    const user = await interaction.client.users.fetch(userOption.id, { force: true });

    if (!user.banner) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'util.no_banner'))], ephemeral: true });
    }

    const embed = baseEmbed()
      .setTitle(t(lang, 'banner.title', { user: user.username }))
      .setImage(user.bannerURL({ size: 1024 }));
    return interaction.reply({ embeds: [embed] });
  },
};
