// Harness QA: jalankan dashboard web dengan mock client Discord (tanpa bot asli),
// lalu biarkan browser menguji /minigame end-to-end.
// Jalankan: node scripts/minigame_qa_server.js [port]
process.env.KIZHOO_DB_PATH = process.env.KIZHOO_DB_PATH || '/tmp/kiz_mgqa.sqlite';
require('fs').rmSync(process.env.KIZHOO_DB_PATH, { force: true });
require('fs').rmSync(process.env.KIZHOO_DB_PATH + '-wal', { force: true });
require('fs').rmSync(process.env.KIZHOO_DB_PATH + '-shm', { force: true });
process.env.DASHBOARD_TOKEN = 'qa-token';
process.env.DASHBOARD_PORT = String(process.argv[2] || 8797);

const webDb = require('../database/webDb');

// Mock client Discord — pakai Collection asli discord.js supaya .map/.filter/.reduce
// di dashboard/server.js berperilaku persis produksi.
const { Collection } = require('discord.js');
const client = {
  guilds: {
    cache: new Collection([
      ['111', { id: '111', name: 'Server QA', iconURL: () => null, channels: { cache: new Collection() }, invites: { fetch: async () => null } }],
    ]),
  },
  users: { cache: new Collection(), fetch: async () => ({ username: 'Penguji', displayAvatarURL: () => null }) },
  on: function () {}, // no-op listener
  once: function () {},
  ws: { ping: 42 },
  user: { displayAvatarURL: () => null, tag: 'KizhooBot#0000' },
};

// Sesi login palsu utk user 777 (biar /api/me & /api/minigame/state jalan).
webDb.saveSession('qa-sid-777', { userId: '777', username: 'Penguji', avatar: null, guilds: [{ id: '111', name: 'Server QA' }] });
// Progress contoh biar state tidak kosong (format v2: slot huruf + tier 1-20).
webDb.saveProgress('777', { wave: 3, bestWave: 4, coins: 800, totalKills: 25, turrets: { B0: { tier: 3 }, B1: { tier: 2 }, G0: { tier: 2 }, G1: { tier: 1 } } });

const { startDashboard } = require('../dashboard/server');
try {
  const { server } = startDashboard(client);
  const port = server.address().port;
  console.log('[QA] dashboard siap di http://127.0.0.1:' + port);
  console.log('[QA] cookie login: kz_sid=qa-sid-777');
  console.log('[QA] tekan Ctrl+C untuk berhenti');
} catch (e) { console.error('[QA] gagal start:', e); process.exit(1); }
