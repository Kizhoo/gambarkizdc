const { SlashCommandBuilder } = require('discord.js');
const { getEdited } = require('../../utils/snipeCache');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  subcommandOf: true,
  data: new SlashCommandBuilder().setName('editsnipe').setDescription('Lihat pesan terakhir yang diedit di channel ini'),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const data = getEdited(interaction.channel.id);
    if (!data) return interaction.reply({ embeds: [errorEmbed(t(lang, 'editsnipe.none'))], ephemeral: true });

    const embed = baseEmbed()
      .setAuthor({ name: data.author.tag, iconURL: data.author.displayAvatarURL() })
      .addFields(
        { name: t(lang, 'util.before'), value: data.oldContent.slice(0, 1000) },
        { name: t(lang, 'util.after'), value: data.newContent.slice(0, 1000) },
      )
      .setFooter({ text: t(lang, 'util.edited_ago', { s: Math.floor((Date.now() - data.timestamp) / 1000) }) });

    return interaction.reply({ embeds: [embed] });
  },
};
