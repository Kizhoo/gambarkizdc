// OWNER_ID diisi di .env dengan Discord User ID pemilik bot. Command yang dibatasi
// khusus owner (misal /botadmin) memakai fungsi ini untuk verifikasi.
function isOwner(userId) {
  const ownerId = process.env.OWNER_ID;
  if (!ownerId) return false;
  return userId === ownerId;
}

module.exports = { isOwner };
