// ============================================================================
// LEVEL ENGINE — level & XP terunifikasi (pengganti rpgEngine pasca-RPG)
// ----------------------------------------------------------------------------
// Sumber kebenaran SATU-SATUNYA level & XP user adalah tabel web_users
// (global, satu level dipakai di semua server). Tabel `levels` per-guild
// hanyalah mirror (disinkronkan lewat syncLevel) supaya /rank, leaderboard,
// dan role-reward tetap jalan.
// Kurva XP identik dengan era sebelumnya: 50l^2 + 150l + 50, cap level 100 —
// progres lama (hasil migrasi webDb) tidak berubah maknanya.
// ============================================================================
const rdb = require('../database/webDb');
const { syncLevel } = require('../database/db');

const LEVEL_CAP = 100;
function xpForLevel(level) {
  if (level >= LEVEL_CAP) return Infinity;
  return Math.floor(50 * level * level + 150 * level + 50);
}

// Tambah XP. Menangani multi-level-up sekaligus. User otomatis dibuat kalau
// belum ada. Kalau guildId diberikan, mirror per-guild ikut disinkronkan.
function addExp(userId, amount, guildId) {
  let user = rdb.getUser(userId);
  if (!user) user = rdb.ensureUser(userId);
  if (user.level >= LEVEL_CAP) {
    return { leveledUp: false, levelsGained: 0, fromLevel: user.level, toLevel: user.level, xpIntoLevel: user.xp, xpForNext: xpForLevel(user.level) };
  }

  let xp = user.xp + Math.max(0, Math.floor(amount));
  let level = user.level;
  while (level < LEVEL_CAP && xp >= xpForLevel(level)) {
    xp -= xpForLevel(level);
    level += 1;
  }
  const levelsGained = level - user.level;
  rdb.updateUser(userId, { xp, level });
  if (guildId) { try { syncLevel(guildId, userId, level, xp); } catch (_) {} }
  return {
    leveledUp: levelsGained > 0, levelsGained,
    fromLevel: user.level, toLevel: level,
    xpIntoLevel: xp, xpForNext: xpForLevel(level),
  };
}

// Baca level terunifikasi (dipakai /rank, /profile, dashboard).
function getLevel(userId) {
  const user = rdb.getUser(userId);
  if (!user) return { level: 1, xp: 0, needed: xpForLevel(1) };
  return { level: user.level, xp: user.xp, needed: xpForLevel(user.level) };
}

// Set level terunifikasi (admin) — update web_users + sinkronkan mirror.
function setLevel(userId, level, guildId) {
  let user = rdb.getUser(userId);
  if (!user) user = rdb.ensureUser(userId);
  level = Math.max(0, Math.min(LEVEL_CAP, Math.floor(Number(level) || 0)));
  const updated = rdb.updateUser(userId, { level: Math.max(1, level), xp: 0 });
  if (guildId) { try { syncLevel(guildId, userId, updated.level, 0); } catch (_) {} }
  return { level: updated.level };
}

module.exports = { LEVEL_CAP, xpForLevel, addExp, getLevel, setLevel };
