// Parser ekspresi matematika sederhana (recursive descent) - sengaja tidak pakai eval()
// atau Function() sama sekali supaya tidak ada resiko code injection dari input user.
// Mendukung: + - * / ^ (pangkat), tanda kurung, angka desimal, minus di depan angka.

function evaluate(expression) {
  const tokens = tokenize(expression);
  let pos = 0;

  function peek() {
    return tokens[pos];
  }

  function consume() {
    return tokens[pos++];
  }

  function parseExpression() {
    let left = parseTerm();
    while (peek() === '+' || peek() === '-') {
      const op = consume();
      const right = parseTerm();
      left = op === '+' ? left + right : left - right;
    }
    return left;
  }

  function parseTerm() {
    let left = parseFactor();
    while (peek() === '*' || peek() === '/' || peek() === '%') {
      const op = consume();
      const right = parseFactor();
      if (op === '*') left *= right;
      else if (op === '/') {
        if (right === 0) throw new Error('Tidak bisa membagi dengan nol');
        left /= right;
      } else left %= right;
    }
    return left;
  }

  function parseFactor() {
    let left = parseUnary();
    while (peek() === '^') {
      consume();
      const right = parseUnary();
      left = Math.pow(left, right);
    }
    return left;
  }

  function parseUnary() {
    if (peek() === '-') {
      consume();
      return -parseUnary();
    }
    if (peek() === '+') {
      consume();
      return parseUnary();
    }
    return parsePrimary();
  }

  function parsePrimary() {
    const token = peek();
    if (token === '(') {
      consume();
      const value = parseExpression();
      if (peek() !== ')') throw new Error('Tanda kurung tidak seimbang');
      consume();
      return value;
    }
    if (typeof token === 'number') {
      consume();
      return token;
    }
    throw new Error(`Token tidak dikenal: ${token}`);
  }

  const result = parseExpression();
  if (pos !== tokens.length) throw new Error('Ekspresi tidak valid, ada karakter tersisa');
  return result;
}

function tokenize(expression) {
  const cleaned = expression.replace(/\s+/g, '');
  if (!/^[0-9+\-*/^%.()]+$/.test(cleaned)) {
    throw new Error('Ekspresi mengandung karakter yang tidak diizinkan (hanya boleh angka dan operator dasar)');
  }

  const tokens = [];
  let i = 0;
  while (i < cleaned.length) {
    const char = cleaned[i];
    if ('+-*/^%()'.includes(char)) {
      tokens.push(char);
      i++;
    } else if (/[0-9.]/.test(char)) {
      let num = '';
      while (i < cleaned.length && /[0-9.]/.test(cleaned[i])) {
        num += cleaned[i];
        i++;
      }
      tokens.push(parseFloat(num));
    } else {
      throw new Error(`Karakter tidak dikenal: ${char}`);
    }
  }
  return tokens;
}

module.exports = { evaluate };
