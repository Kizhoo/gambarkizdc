// ============================================================================
// WEB I18N (browser) — pengalih bahasa untuk halaman web KizhooBot.
// ----------------------------------------------------------------------------
// Sama konsepnya dengan utils/i18n.js (Node), tapi versi browser. Bahasa
// disimpan di cookie `kz_lang` (default Indonesia). Terapkan ke elemen yang
// punya atribut data-i18n / data-i18n-placeholder, lalu isi <select id="langSelect">.
// ============================================================================
(function () {
  const LANGUAGES = [
  { code: 'id', name: 'Indonesia', native: 'Bahasa Indonesia', flag: '🇮🇩' },
  { code: 'en', name: 'English', native: 'English', flag: '🇬🇧' },
  { code: 'ja', name: 'Japanese', native: '日本語', flag: '🇯🇵' },
  { code: 'es', name: 'Spanish', native: 'Español', flag: '🇪🇸' },
  { code: 'pt', name: 'Portuguese', native: 'Português', flag: '🇧🇷' },
  { code: 'fr', name: 'French', native: 'Français', flag: '🇫🇷' },
];

  const T = {
    'nav.fitur': { id: 'Fitur', en: 'Features', es: 'Funciones', pt: 'Recursos', fr: 'Fonctionnalités', ja: '機能' },
    'nav.command': { id: 'Command', en: 'Commands', es: 'Comandos', pt: 'Comandos', fr: 'Commandes', ja: 'コマンド' },
    'nav.faq': { id: 'FAQ', en: 'FAQ', es: 'FAQ', pt: 'FAQ', fr: 'FAQ', ja: 'FAQ' },
    'nav.social': { id: 'Sosmed', en: 'Social', es: 'Redes', pt: 'Redes', fr: 'Réseaux', ja: 'SNS' },
    'nav.vote': { id: 'Vote', en: 'Vote', es: 'Votar', pt: 'Votar', fr: 'Voter', ja: '投票' },
    'nav.beranda': { id: 'Beranda', en: 'Home', es: 'Inicio', pt: 'Início', fr: 'Accueil', ja: 'ホーム' },
    'nav.server': { id: 'Server', en: 'Servers', es: 'Servidores', pt: 'Servidores', fr: 'Serveurs', ja: 'サーバー' },
    'nav.market': { id: 'Market', en: 'Market', es: 'Mercado', pt: 'Mercado', fr: 'Marché', ja: 'マーケット' },
    'nav.profil': { id: 'Profil', en: 'Profile', es: 'Perfil', pt: 'Perfil', fr: 'Profil', ja: 'プロフィール' },
    'nav.trading': { id: 'Trading', en: 'Trading', es: 'Trading', pt: 'Trading', fr: 'Trading', ja: 'トレード' },
    'hero.badge': { id: 'Aktif di {n} server', en: 'Active in {n} servers', es: 'Activo en {n} servidores', pt: 'Ativo em {n} servidores', fr: 'Actif sur {n} serveurs', ja: '{n}サーバーで稼働中' },
    'hero.tagline': { id: 'Bot Discord dengan ekonomi yang benar-benar jalan.', en: 'A Discord bot with an economy that actually works.', es: 'Un bot de Discord con una economía que funciona de verdad.', pt: 'Um bot de Discord com uma economia que funciona de verdade.', fr: 'Un bot Discord avec une économie qui fonctionne vraiment.', ja: '経済が本当に動くDiscordボット。' },
    'hero.add': { id: 'Tambah ke server', en: 'Add to server', es: 'Añadir al servidor', pt: 'Adicionar ao servidor', fr: 'Ajouter au serveur', ja: 'サーバーに追加' },
    'hero.trading': { id: 'Web trading', en: 'Web trading', es: 'Web trading', pt: 'Web trading', fr: 'Web trading', ja: 'ウェブトレード' },
    'hero.market': { id: 'Market aset', en: 'Asset market', es: 'Mercado de activos', pt: 'Mercado de ativos', fr: 'Marché des actifs', ja: '資産マーケット' },
    'stat.server': { id: 'Server', en: 'Servers', es: 'Servidores', pt: 'Servidores', fr: 'Serveurs', ja: 'サーバー' },
    'stat.member': { id: 'Member', en: 'Members', es: 'Miembros', pt: 'Membros', fr: 'Membres', ja: 'メンバー' },
    'stat.command': { id: 'Command', en: 'Commands', es: 'Comandos', pt: 'Comandos', fr: 'Commandes', ja: 'コマンド' },
    'stat.uptime': { id: 'Uptime', en: 'Uptime', es: 'Tiempo activo', pt: 'Uptime', fr: 'Disponibilité', ja: '稼働時間' },
    'sec.fitur': { id: 'Yang bisa dilakukan bot ini', en: 'What this bot can do', es: 'Lo que puede hacer este bot', pt: 'O que este bot pode fazer', fr: 'Ce que ce bot peut faire', ja: 'このボットでできること' },
    'sec.fitur_sub': { id: 'Bukan daftar janji. Ini yang sudah benar-benar jalan.', en: 'Not a list of promises. This is what actually works.', es: 'No es una lista de promesas. Esto es lo que realmente funciona.', pt: 'Não é uma lista de promessas. É o que realmente funciona.', fr: 'Pas une liste de promesses. C\'est ce qui fonctionne vraiment.', ja: '約束のリストではありません。実際に動くものです。' },
    'sec.command': { id: 'Command yang sering dipakai', en: 'Frequently used commands', es: 'Comandos más usados', pt: 'Comandos mais usados', fr: 'Commandes fréquentes', ja: 'よく使うコマンド' },
    'sec.command_sub': { id: 'Semua pakai slash command. Ketik / lalu pilih.', en: 'All use slash commands. Type / and pick.', es: 'Todo usa comandos slash. Escribe / y elige.', pt: 'Tudo usa slash commands. Digite / e escolha.', fr: 'Tout utilise les slash commands. Tapez / puis choisissez.', ja: 'すべてスラッシュコマンドです。/を入力して選んでください。' },
    'sec.why': { id: 'Kenapa dibuat begini', en: 'Why it\'s built this way', es: 'Por qué está hecho así', pt: 'Por que foi feito assim', fr: 'Pourquoi c\'est fait ainsi', ja: 'なぜこの作りなのか' },
    'sec.faq': { id: 'Pertanyaan yang sering muncul', en: 'Frequently asked questions', es: 'Preguntas frecuentes', pt: 'Perguntas frequentes', fr: 'Questions fréquentes', ja: 'よくある質問' },
    'sec.social': { id: 'Ikuti kami', en: 'Follow us', es: 'Síguenos', pt: 'Siga-nos', fr: 'Suivez-nous', ja: 'フォローする' },
    'sec.social_sub': { id: 'Update rilis, giveaway, dan pengumuman ada di sini.', en: 'Release updates, giveaways, and announcements live here.', es: 'Novedades, sorteos y anuncios están aquí.', pt: 'Novidades, sorteios e anúncios ficam aqui.', fr: 'Les mises à jour, cadeaux et annonces sont ici.', ja: 'リリース情報やプレゼント企画、お知らせはこちらです。' },
    'feat.economy': { id: 'Ekonomi Kizco', en: 'Kizco economy', es: 'Economía Kizco', pt: 'Economia Kizco', fr: 'Économie Kizco', ja: 'Kizco経済' },
    'feat.trading': { id: 'Pasar dan trading', en: 'Market and trading', es: 'Mercado y trading', pt: 'Mercado e trading', fr: 'Marché et trading', ja: 'マーケットとトレード' },
    'feat.rpg': { id: 'RPG', en: 'RPG', es: 'RPG', pt: 'RPG', fr: 'RPG', ja: 'RPG' },
    'feat.music': { id: 'Musik', en: 'Music', es: 'Música', pt: 'Música', fr: 'Musique', ja: '音楽' },
    'feat.mod': { id: 'Moderasi dan keamanan', en: 'Moderation and safety', es: 'Moderación y seguridad', pt: 'Moderação e segurança', fr: 'Modération et sécurité', ja: 'モデレーションと安全' },
    'feat.dashboard': { id: 'Dashboard dan web', en: 'Dashboard and web', es: 'Dashboard y web', pt: 'Dashboard e web', fr: 'Dashboard et web', ja: 'ダッシュボードとウェブ' },
    'feat.game': { id: 'Game dan hiburan', en: 'Games and fun', es: 'Juegos y diversión', pt: 'Jogos e diversão', fr: 'Jeux et divertissement', ja: 'ゲームと娯楽' },
    'feat.community': { id: 'Komunitas', en: 'Community', es: 'Comunidad', pt: 'Comunidade', fr: 'Communauté', ja: 'コミュニティ' },
    'footer.note': { id: 'KizhooBot bukan layanan resmi. Nama dan konten dibuat untuk komunitas sendiri.', en: 'KizhooBot is not an official service. Its name and content are made for its own community.', es: 'KizhooBot no es un servicio oficial. Su nombre y contenido están hechos para su propia comunidad.', pt: 'KizhooBot não é um serviço oficial. Nome e conteúdo são feitos para a própria comunidade.', fr: 'KizhooBot n\'est pas un service officiel. Son nom et son contenu sont faits pour sa propre communauté.', ja: 'KizhooBotは公式サービスではありません。名前とコンテンツは独自コミュニティ向けです。' },
    'hero.desc': { id: 'KizhooBot punya mata uang sendiri bernama Kizco. Harganya naik dan turun karena inflasi, permintaan, dan kebijakan bank sentral. Ada pasar dengan order book dan grafik candlestick, RPG, musik, moderasi, plus dashboard yang bisa dibuka dari browser.', en: 'KizhooBot has its own currency called Kizco. Its price rises and falls with inflation, demand, and central bank policy. There is a market with an order book and candlestick charts, RPG, music, moderation, plus a dashboard you can open from your browser.', es: 'KizhooBot tiene su propia moneda llamada Kizco. Su precio sube y baja con la inflación, la demanda y la política del banco central. Hay un mercado con order book y gráficos de velas, RPG, música, moderación y un panel web.', pt: 'O KizhooBot tem sua própria moeda chamada Kizco. O preço sobe e desce com a inflação, a demanda e a política do banco central. Há mercado com order book e gráficos de velas, RPG, música, moderação e um painel web.', fr: 'KizhooBot a sa propre monnaie, le Kizco. Son prix monte et descend selon l\'inflation, la demande et la politique de la banque centrale. Il y a un marché avec carnet d\'ordres et graphiques en chandeliers, du RPG, de la musique, de la modération et un tableau de bord web.', ja: 'KizhooBotにはKizcoという独自通貨があります。価格はインフレ・需要・中央銀行の政策で上下します。オーダーブックとローソク足チャートのある市場、RPG、音楽、モデレーション、ブラウザで開けるダッシュボードがあります。' },
    'why.p1': { id: 'Kebanyakan bot ekonomi cuma menambah angka kalau kamu ketik /daily. Angkanya terus naik, barangnya tetap, dan lama-lama tidak ada yang peduli. KizhooBot mulai dari situ, lalu coba dibalik.', en: 'Most economy bots just add a number when you type /daily. It keeps going up, the items stay the same, and eventually nobody cares. KizhooBot started there, then tried to flip it.', es: 'La mayoría de los bots de economía solo suman un número con /daily. Sigue subiendo, los objetos no cambian y al final a nadie le importa. KizhooBot empezó ahí y lo invirtió.', pt: 'A maioria dos bots de economia só soma um número com /daily. Ele sobe, os itens não mudam e no fim ninguém liga. O KizhooBot começou aí e inverteu.', fr: 'La plupart des bots économiques ajoutent juste un nombre avec /daily. Ça monte, les objets ne changent pas, et à la fin personne ne s\'y intéresse. KizhooBot est parti de là et a inversé la logique.', ja: '多くの経済ボットは/dailyで数字を増やすだけです。数字は上がり続け、アイテムは変わらず、やがて誰も気にしなくなります。KizhooBotはそこから始めて、逆転させました。' },
    'why.p2': { id: 'Jadi sekarang ada inflasi. Kalau terlalu banyak uang dicetak, harga naik dan uangmu nilainya turun. Ada bank sentral yang bisa menarik pajak, menaikkan bunga, atau membakar uang untuk menahan inflasi. Ada pasar yang harganya bergerak karena orang benar-benar beli dan jual, bukan karena admin menentukan harganya.', en: 'So now there is inflation. If too much money is printed, prices rise and your money loses value. There is a central bank that can collect taxes, raise interest, or burn money to hold inflation. There is a market whose prices move because people really buy and sell, not because an admin sets the price.', es: 'Ahora hay inflación. Si se imprime demasiado dinero, los precios suben y tu dinero pierde valor. Hay un banco central que cobra impuestos, sube intereses o quema dinero para frenar la inflación. Hay un mercado cuyos precios se mueven porque la gente compra y vende de verdad.', pt: 'Agora existe inflação. Se muito dinheiro é impresso, os preços sobem e seu dinheiro perde valor. Há um banco central que cobra impostos, aumenta juros ou queima dinheiro para segurar a inflação. Há um mercado cujos preços se movem porque as pessoas compram e vendem de verdade.', fr: 'Maintenant il y a de l\'inflation. Si trop d\'argent est imprimé, les prix montent et votre argent perd de la valeur. Il y a une banque centrale qui peut taxer, monter les taux ou brûler de l\'argent pour contenir l\'inflation. Il y a un marché dont les prix bougent parce que les gens achètent et vendent vraiment.', ja: 'だから今はインフレがあります。お金を刷りすぎると物価が上がり、あなたのお金の価値が下がります。税金を取ったり、金利を上げたり、お金を燃やしてインフレを抑える中央銀行があります。管理者が値段を決めるのではなく、人々が実際に売買するから価格が動く市場があります。' },
    'why.p3': { id: 'Sisanya: RPG, musik, moderasi, dan dashboard web. Semuanya jalan di satu bot, satu database, dan satu mata uang.', en: 'The rest: RPG, music, moderation, and a web dashboard. Everything runs on one bot, one database, and one currency.', es: 'El resto: RPG, música, moderación y un panel web. Todo corre en un bot, una base de datos y una moneda.', pt: 'O resto: RPG, música, moderação e painel web. Tudo roda em um bot, um banco e uma moeda.', fr: 'Le reste : RPG, musique, modération et un tableau de bord web. Tout tourne sur un bot, une base de données et une monnaie.', ja: '残りはRPG、音楽、モデレーション、ウェブダッシュボードです。すべて1つのボット、1つのデータベース、1つの通貨で動いています。' },
    'faq.q1': { id: 'Kizco itu apa?', en: 'What is Kizco?', es: '¿Qué es Kizco?', pt: 'O que é Kizco?', fr: 'Qu\'est-ce que le Kizco ?', ja: 'Kizcoとは？' },
    'faq.a1': { id: 'Mata uang di dalam bot. Kamu pakai buat beli barang, trading, menabung di bank, dan bisa dapat dari kerja, daily, berburu, atau quest.', en: 'The currency inside the bot. You use it to buy items, trade, save in the bank, and earn it from work, daily, hunting, or quests.', es: 'La moneda dentro del bot. La usas para comprar, tradear, ahorrar en el banco y ganarla trabajando, con daily, cazando o en misiones.', pt: 'A moeda dentro do bot. Você usa para comprar, trocar, guardar no banco e ganhar com trabalho, daily, caça ou missões.', fr: 'La monnaie du bot. Vous l\'utilisez pour acheter, trader, épargner à la banque et la gagner via le travail, le daily, la chasse ou les quêtes.', ja: 'ボット内の通貨です。アイテムの購入、トレード、銀行への貯金に使い、仕事・デイリー・狩り・クエストで稼げます。' },
    'faq.q2': { id: 'Bagaimana cara dapat Kizco?', en: 'How do I earn Kizco?', es: '¿Cómo consigo Kizco?', pt: 'Como ganho Kizco?', fr: 'Comment gagner du Kizco ?', ja: 'Kizcoはどうやって稼ぐ？' },
    'faq.a2': { id: 'Klaim /daily, kerja lewat /work, berburu pakai /rpg hunt, atau selesaikan quest. Kamu juga bisa menang dari minigame dan jual-beli di pasar.', en: 'Claim /daily, work with /work, hunt with /rpg hunt, or complete quests. You can also win from minigames and buy/sell in the market.', es: 'Reclama /daily, trabaja con /work, caza con /rpg hunt o completa misiones. También ganas con minijuegos y comprando/vendiendo en el mercado.', pt: 'Pegue /daily, trabalhe com /work, cace com /rpg hunt ou complete missões. Também dá para ganhar em minijogos e comprar/vender no mercado.', fr: 'Récupérez /daily, travaillez avec /work, chassez avec /rpg hunt ou finissez des quêtes. Vous pouvez aussi gagner via les mini-jeux et le marché.', ja: '/daily、/work、/rpg hunt、またはクエストで稼げます。ミニゲームや市場での売買でも勝てます。' },
    'faq.q3': { id: 'Bagaimana cara trading?', en: 'How do I trade?', es: '¿Cómo hago trading?', pt: 'Como eu troco?', fr: 'Comment trader ?', ja: 'トレードはどうやる？' },
    'faq.a3': { id: 'Lewat Discord pakai /trade dan /market, atau buka web trading. Di sana ada grafik harga, order book, dan kamu bisa pasang order beli atau jual.', en: 'On Discord with /trade and /market, or open the web trading page. There you have price charts, an order book, and you can place buy or sell orders.', es: 'En Discord con /trade y /market, o abre el web trading. Ahí hay gráficos, order book y puedes poner órdenes de compra o venta.', pt: 'No Discord com /trade e /market, ou abra o web trading. Lá há gráficos, order book e você pode fazer ordens de compra ou venda.', fr: 'Sur Discord avec /trade et /market, ou ouvrez le web trading. Vous y trouverez des graphiques, un carnet d\'ordres et pourrez passer des ordres.', ja: 'Discordでは/tradeと/market、またはウェブトレードを開いてください。価格チャート、オーダーブックがあり、買い・売り注文を出せます。' },
    'faq.q4': { id: 'Kenapa harga barang naik-turun?', en: 'Why do prices go up and down?', es: '¿Por qué suben y bajan los precios?', pt: 'Por que os preços sobem e descem?', fr: 'Pourquoi les prix montent et descendent ?', ja: 'なぜ価格は上下する？' },
    'faq.a4': { id: 'Harganya mengikuti inflasi dan permintaan. Kalau banyak yang beli, harganya naik. Kalau bank sentral membakar uang atau menaikkan pajak, harga cenderung turun.', en: 'Prices follow inflation and demand. When many people buy, the price rises. When the central bank burns money or raises taxes, prices tend to fall.', es: 'Los precios siguen a la inflación y la demanda. Si muchos compran, suben. Si el banco central quema dinero o sube impuestos, tienden a bajar.', pt: 'Os preços seguem inflação e demanda. Se muita gente compra, sobem. Se o banco central queima dinheiro ou aumenta impostos, tendem a cair.', fr: 'Les prix suivent l\'inflation et la demande. Beaucoup d\'achats font monter le prix. Si la banque centrale brûle de l\'argent ou augmente les taxes, les prix baissent.', ja: '価格はインフレと需要に従います。買う人が多いと上がり、中央銀行がお金を燃やしたり増税すると下がります。' },
    'faq.q5': { id: 'Saham Bank Kizaria itu apa?', en: 'What is Bank Kizaria stock?', es: '¿Qué es la acción de Bank Kizaria?', pt: 'O que é a ação do Bank Kizaria?', fr: 'Qu\'est-ce que l\'action Bank Kizaria ?', ja: 'Bank Kizaria株とは？' },
    'faq.a5': { id: 'Instrumen di web trading yang harganya mengikuti suku bunga, cadangan bank, dan jumlah uang beredar. Kamu bisa beli atau jual seperti saham biasa.', en: 'An instrument in web trading whose price follows interest rates, bank reserves, and money supply. You can buy or sell it like a normal stock.', es: 'Un instrumento del web trading cuyo precio sigue tasas de interés, reservas del banco y oferta monetaria. Puedes comprarlo o venderlo como una acción.', pt: 'Um instrumento do web trading cujo preço segue juros, reservas do banco e oferta de moeda. Dá para comprar ou vender como uma ação.', fr: 'Un instrument du web trading dont le prix suit les taux, les réserves bancaires et la masse monétaire. Vous pouvez l\'acheter ou le vendre comme une action.', ja: 'ウェブトレードの商品で、金利・銀行準備・通貨供給量に価格が連動します。普通の株のように売買できます。' },
    'faq.q6': { id: 'Data saya disimpan di mana?', en: 'Where is my data stored?', es: '¿Dónde se guardan mis datos?', pt: 'Onde meus dados são guardados?', fr: 'Où sont stockées mes données ?', ja: 'データはどこに保存される？' },
    'faq.a6': { id: 'Di database server tempat bot ini jalan. Hanya admin server yang bisa mengaksesnya.', en: 'In the database on the server where this bot runs. Only the server admin can access it.', es: 'En la base de datos del servidor donde corre este bot. Solo el admin del servidor puede acceder.', pt: 'No banco de dados do servidor onde o bot roda. Só o admin do servidor pode acessar.', fr: 'Dans la base de données du serveur où tourne ce bot. Seul l\'admin du serveur peut y accéder.', ja: 'このボットが動いているサーバーのデータベースに保存されます。アクセスできるのはサーバー管理者だけです。' },

    // ---------- Daftar isi fitur (bullet list di kartu fitur) ----------
    'feat.economy.i1': { id: 'Mata uang sendiri (Kizco) buat semua fitur', en: 'Its own currency (Kizco) for every feature', es: 'Su propia moneda (Kizco) para todas las funciones', pt: 'Moeda própria (Kizco) para todos os recursos', fr: 'Sa propre monnaie (Kizco) pour toutes les fonctions', ja: 'すべての機能で使える独自通貨（Kizco）' },
    'feat.economy.i2': { id: 'Inflasi dan deflasi dihitung dari aktivitas server', en: 'Inflation and deflation calculated from server activity', es: 'Inflación y deflación calculadas según la actividad del servidor', pt: 'Inflação e deflação calculadas pela atividade do servidor', fr: 'Inflation et déflation calculées à partir de l\'activité du serveur', ja: 'サーバーの活動から算出されるインフレ／デフレ' },
    'feat.economy.i3': { id: 'Bank sentral yang bisa cetak atau bakar uang', en: 'A central bank that can mint or burn money', es: 'Un banco central que puede imprimir o quemar dinero', pt: 'Um banco central que pode imprimir ou queimar dinheiro', fr: 'Une banque centrale qui peut imprimer ou brûler de l\'argent', ja: 'お金を刷ったり燃やしたりできる中央銀行' },
    'feat.economy.i4': { id: 'Pajak penghasilan dan bunga bank majemuk', en: 'Income tax and compound bank interest', es: 'Impuesto a la renta e interés bancario compuesto', pt: 'Imposto de renda e juros bancários compostos', fr: 'Impôt sur le revenu et intérêts bancaires composés', ja: '所得税と複利の銀行金利' },
    'feat.economy.i5': { id: 'Fase ekonomi: ekspansi, puncak, resesi, pemulihan', en: 'Economic phases: expansion, peak, recession, recovery', es: 'Fases económicas: expansión, pico, recesión, recuperación', pt: 'Fases econômicas: expansão, pico, recessão, recuperação', fr: 'Phases économiques : expansion, pic, récession, reprise', ja: '景気局面：拡大、ピーク、後退、回復' },
    'feat.economy.i6': { id: 'Laporan AI Ekonom tiap siklus', en: 'An AI Economist report every cycle', es: 'Un informe del Economista IA cada ciclo', pt: 'Um relatório do Economista IA a cada ciclo', fr: 'Un rapport de l\'Économiste IA à chaque cycle', ja: '毎サイクルのAIエコノミストレポート' },
    'feat.trading.i1': { id: 'Harga barang mengikuti inflasi dan permintaan', en: 'Item prices follow inflation and demand', es: 'Los precios siguen la inflación y la demanda', pt: 'Preços dos itens seguem inflação e demanda', fr: 'Les prix suivent l\'inflation et la demande', ja: '物価はインフレと需要に連動' },
    'feat.trading.i2': { id: 'Order book dengan bid dan ask', en: 'An order book with bids and asks', es: 'Order book con ofertas de compra y venta', pt: 'Order book com ofertas de compra e venda', fr: 'Un carnet d\'ordres avec offres d\'achat et de vente', ja: '売買気配のあるオーダーブック' },
    'feat.trading.i3': { id: 'Order market dan limit', en: 'Market and limit orders', es: 'Órdenes de mercado y limitadas', pt: 'Ordens a mercado e limitadas', fr: 'Ordres au marché et à cours limité', ja: '成行注文と指値注文' },
    'feat.trading.i4': { id: 'Grafik candlestick 1m sampai 1d', en: 'Candlestick charts from 1m to 1d', es: 'Gráficos de velas de 1m a 1d', pt: 'Gráficos de velas de 1m a 1d', fr: 'Graphiques en chandeliers de 1m à 1d', ja: '1分足から1日足のローソク足チャート' },
    'feat.trading.i5': { id: 'Watchlist dan price alert', en: 'Watchlist and price alerts', es: 'Lista de seguimiento y alertas de precio', pt: 'Watchlist e alertas de preço', fr: 'Liste de suivi et alertes de prix', ja: 'ウォッチリストと価格アラート' },
    'feat.trading.i6': { id: 'Saham Bank Kizaria di web trading', en: 'Bank Kizaria stock in web trading', es: 'Acción de Bank Kizaria en el web trading', pt: 'Ação do Bank Kizaria no web trading', fr: 'Action Bank Kizaria dans le web trading', ja: 'ウェブトレードのBank Kizaria株' },
    'feat.rpg.i1': { id: 'Karakter dengan 4 class dan skill tree', en: 'Characters with 4 classes and a skill tree', es: 'Personajes con 4 clases y árbol de habilidades', pt: 'Personagens com 4 classes e árvore de habilidades', fr: 'Personnages avec 4 classes et arbre de compétences', ja: '4クラスとスキルツリーを持つキャラクター' },
    'feat.rpg.i2': { id: 'Berburu dan battle turn-based', en: 'Hunting and turn-based battles', es: 'Caza y combates por turnos', pt: 'Caça e batalhas por turnos', fr: 'Chasse et combats au tour par tour', ja: '狩りとターン制バトル' },
    'feat.rpg.i3': { id: 'Quest otomatis yang dibuat AI', en: 'AI-generated automatic quests', es: 'Misiones automáticas generadas por IA', pt: 'Missões automáticas geradas por IA', fr: 'Quêtes automatiques générées par l\'IA', ja: 'AIが自動生成するクエスト' },
    'feat.rpg.i4': { id: 'Party, rank, dan promosi', en: 'Parties, ranks, and promotions', es: 'Grupos, rangos y ascensos', pt: 'Grupos, ranks e promoções', fr: 'Groupes, rangs et promotions', ja: 'パーティ、ランク、昇進' },
    'feat.rpg.i5': { id: 'Inventory, equip, dan consumable', en: 'Inventory, equipment, and consumables', es: 'Inventario, equipamiento y consumibles', pt: 'Inventário, equipamento e consumíveis', fr: 'Inventaire, équipement et consommables', ja: 'インベントリ、装備、消費アイテム' },
    'feat.rpg.i6': { id: 'Asisten AI guild (Luna) buat tanya-jawab', en: 'A guild AI assistant (Luna) for Q&A', es: 'Un asistente IA de gremio (Luna) para preguntas', pt: 'Um assistente IA de guilda (Luna) para perguntas', fr: 'Un assistant IA de guilde (Luna) pour vos questions', ja: 'ギルドAIアシスタント（Luna）で質問応答' },
    'feat.music.i1': { id: 'Putar lagu dari YouTube', en: 'Play songs from YouTube', es: 'Reproduce canciones de YouTube', pt: 'Toque músicas do YouTube', fr: 'Jouez des morceaux depuis YouTube', ja: 'YouTubeから曲を再生' },
    'feat.music.i2': { id: 'Antrian, skip, loop, dan shuffle', en: 'Queue, skip, loop, and shuffle', es: 'Cola, saltar, bucle y aleatorio', pt: 'Fila, pular, repetir e embaralhar', fr: 'File d\'attente, passer, boucle et aléatoire', ja: 'キュー、スキップ、ループ、シャッフル' },
    'feat.music.i3': { id: 'Autoplay dan kontrol volume', en: 'Autoplay and volume control', es: 'Autoplay y control de volumen', pt: 'Autoplay e controle de volume', fr: 'Lecture auto et contrôle du volume', ja: 'オートプレイと音量コントロール' },
    'feat.music.i4': { id: 'Kartu now playing', en: 'A now playing card', es: 'Tarjeta de reproducción actual', pt: 'Cartão de tocando agora', fr: 'Une carte « en cours de lecture »', ja: '再生中のカード' },
    'feat.mod.i1': { id: 'Ban, kick, timeout, warn, dan purge', en: 'Ban, kick, timeout, warn, and purge', es: 'Ban, expulsión, timeout, advertencia y purga', pt: 'Ban, expulsar, timeout, avisar e limpar', fr: 'Bannissement, expulsion, timeout, avertissement et purge', ja: 'BAN、キック、タイムアウト、警告、一括削除' },
    'feat.mod.i2': { id: 'Anti-spam dan anti-link otomatis', en: 'Automatic anti-spam and anti-link', es: 'Anti-spam y anti-enlaces automáticos', pt: 'Anti-spam e anti-link automáticos', fr: 'Anti-spam et anti-liens automatiques', ja: '自動のスパム対策・リンク対策' },
    'feat.mod.i3': { id: 'Anti-raid dan verifikasi', en: 'Anti-raid and verification', es: 'Anti-raid y verificación', pt: 'Anti-raid e verificação', fr: 'Anti-raid et vérification', ja: 'レイド対策と認証' },
    'feat.mod.i4': { id: 'Log channel dan automod', en: 'Log channels and automod', es: 'Canales de registro y automod', pt: 'Canais de log e automod', fr: 'Canaux de journalisation et automod', ja: 'ログチャンネルとオートモデレーション' },
    'feat.dashboard.i1': { id: 'Landing page publik (yang kamu buka sekarang)', en: 'A public landing page (the one you\'re viewing)', es: 'Página de inicio pública (la que estás viendo)', pt: 'Landing page pública (a que você está vendo)', fr: 'Une page d\'accueil publique (celle que vous consultez)', ja: '公開ランディングページ（今見ているもの）' },
    'feat.dashboard.i2': { id: 'Dashboard admin dengan monitoring real-time', en: 'An admin dashboard with real-time monitoring', es: 'Panel de administración con monitoreo en tiempo real', pt: 'Painel administrativo com monitoramento em tempo real', fr: 'Un tableau de bord admin avec suivi en temps réel', ja: 'リアルタイム監視付きの管理ダッシュボード' },
    'feat.dashboard.i3': { id: 'Web trading dengan candlestick dan order book', en: 'Web trading with candlesticks and an order book', es: 'Web trading con velas y order book', pt: 'Web trading com velas e order book', fr: 'Web trading avec chandeliers et carnet d\'ordres', ja: 'ローソク足とオーダーブックのあるウェブトレード' },
    'feat.dashboard.i4': { id: 'Grafik ekonomi dan riwayat transaksi', en: 'Economy charts and transaction history', es: 'Gráficos de economía e historial de transacciones', pt: 'Gráficos de economia e histórico de transações', fr: 'Graphiques économiques et historique des transactions', ja: '経済チャートと取引履歴' },
    'feat.game.i1': { id: 'Blackjack, catur, tic-tac-toe, connect four', en: 'Blackjack, chess, tic-tac-toe, connect four', es: 'Blackjack, ajedrez, tres en raya, conecta cuatro', pt: 'Blackjack, xadrez, jogo da velha, liga quatro', fr: 'Blackjack, échecs, morpion, puissance 4', ja: 'ブラックジャック、チェス、三目並べ、コネクトフォー' },
    'feat.game.i2': { id: 'Werewolf, trivia, tebak kata, dan kuis', en: 'Werewolf, trivia, word guessing, and quizzes', es: 'Hombre lobo, trivia, adivinanza y concursos', pt: 'Lobisomem, trivia, adivinhação e quiz', fr: 'Loup-garou, trivia, devinettes et quiz', ja: '人狼、トリビア、言葉当て、クイズ' },
    'feat.game.i3': { id: 'Coinflip, dadu, 8-ball, dan ship', en: 'Coinflip, dice, 8-ball, and ship', es: 'Cara o cruz, dados, bola 8 y ship', pt: 'Cara ou coroa, dados, bola 8 e ship', fr: 'Pile ou face, dés, boule 8 et ship', ja: 'コイントス、サイコロ、8ボール、相性占い' },
    'feat.game.i4': { id: 'Meme, joke, quote, dan waifu', en: 'Memes, jokes, quotes, and waifus', es: 'Memes, chistes, citas y waifus', pt: 'Memes, piadas, citações e waifus', fr: 'Mèmes, blagues, citations et waifus', ja: 'ミーム、ジョーク、名言、嫁' },
    'feat.community.i1': { id: 'Giveaway dengan timer otomatis', en: 'Giveaways with automatic timers', es: 'Sorteos con temporizador automático', pt: 'Sorteios com cronômetro automático', fr: 'Giveaways avec minuteur automatique', ja: '自動タイマー付きギブアウェイ' },
    'feat.community.i2': { id: 'Leveling dengan leaderboard dan reward role', en: 'Leveling with a leaderboard and role rewards', es: 'Niveles con clasificación y recompensas de rol', pt: 'Leveling com ranking e recompensas de cargo', fr: 'Niveaux avec classement et récompenses de rôle', ja: 'ランキングとロール報酬のあるレベル制度' },
    'feat.community.i3': { id: 'Welcome dan goodbye dengan kartu custom', en: 'Welcome and goodbye with custom cards', es: 'Bienvenida y despedida con tarjetas personalizadas', pt: 'Boas-vindas e despedida com cartões personalizados', fr: 'Accueil et départ avec cartes personnalisées', ja: 'カスタムカード付きの歓迎・送別' },
    'feat.community.i4': { id: 'Tiket, saran, confession, dan starboard', en: 'Tickets, suggestions, confessions, and starboard', es: 'Tickets, sugerencias, confesiones y starboard', pt: 'Tickets, sugestões, confissões e starboard', fr: 'Tickets, suggestions, confessions et starboard', ja: 'チケット、提案、告白、スターボード' },
    'feat.community.i5': { id: 'Pernikahan, ulang tahun, dan AFK', en: 'Marriage, birthdays, and AFK', es: 'Matrimonio, cumpleaños y AFK', pt: 'Casamento, aniversários e AFK', fr: 'Mariage, anniversaires et AFK', ja: '結婚、誕生日、AFK' },

    // ---------- Deskripsi command di landing ----------
    'cmd.econ_status': { id: 'Cek inflasi, indeks harga, dan kebijakan bank sentral.', en: 'Check inflation, the price index, and central bank policy.', es: 'Consulta inflación, índice de precios y política del banco central.', pt: 'Veja inflação, índice de preços e política do banco central.', fr: 'Consultez l\'inflation, l\'indice des prix et la politique de la banque centrale.', ja: 'インフレ、物価指数、中央銀行の政策を確認。' },
    'cmd.econ_chart': { id: 'Grafik tren harga dan uang beredar.', en: 'Charts of price trends and money supply.', es: 'Gráficos de tendencia de precios y oferta monetaria.', pt: 'Gráficos de tendência de preços e oferta de moeda.', fr: 'Graphiques des tendances de prix et de la masse monétaire.', ja: '物価トレンドと通貨供給量のチャート。' },
    'cmd.market_view': { id: 'Buka pasar interaktif dengan tombol.', en: 'Open the interactive market with buttons.', es: 'Abre el mercado interactivo con botones.', pt: 'Abra o mercado interativo com botões.', fr: 'Ouvrez le marché interactif avec des boutons.', ja: 'ボタン付きのインタラクティブな市場を開く。' },
    'cmd.market_chart': { id: 'Grafik harga sebuah item.', en: 'Price chart of a single item.', es: 'Gráfico de precio de un artículo.', pt: 'Gráfico de preço de um item.', fr: 'Graphique de prix d\'un article.', ja: '1つのアイテムの価格チャート。' },
    'cmd.trade': { id: 'Trading P2P dan marketplace item.', en: 'P2P trading and an item marketplace.', es: 'Trading P2P y mercado de artículos.', pt: 'Trading P2P e marketplace de itens.', fr: 'Trading de pair à pair et marketplace d\'articles.', ja: 'P2P取引とアイテムのマーケットプレイス。' },
    'cmd.bank_statement': { id: 'Mutasi rekening di Bank Kizaria.', en: 'Account statements at Bank Kizaria.', es: 'Extracto de cuenta en Bank Kizaria.', pt: 'Extrato de conta no Bank Kizaria.', fr: 'Relevé de compte à la Bank Kizaria.', ja: 'Bank Kizariaの口座明細。' },
    'cmd.rpg_mulai': { id: 'Buat karakter RPG.', en: 'Create an RPG character.', es: 'Crea un personaje RPG.', pt: 'Crie um personagem de RPG.', fr: 'Créez un personnage RPG.', ja: 'RPGキャラクターを作成。' },
    'cmd.rpg_hunt': { id: 'Berburu monster buat XP dan Kizco.', en: 'Hunt monsters for XP and Kizco.', es: 'Caza monstruos por XP y Kizco.', pt: 'Cace monstros por XP e Kizco.', fr: 'Chassez des monstres pour de l\'XP et du Kizco.', ja: 'XPとKizcoを得るためにモンスターを狩る。' },
    'cmd.play': { id: 'Putar lagu dari YouTube.', en: 'Play songs from YouTube.', es: 'Reproduce canciones de YouTube.', pt: 'Toque músicas do YouTube.', fr: 'Jouez des morceaux depuis YouTube.', ja: 'YouTubeから曲を再生。' },
    'cmd.daily': { id: 'Klaim Kizco harian.', en: 'Claim your daily Kizco.', es: 'Reclama tu Kizco diario.', pt: 'Resgate seu Kizco diário.', fr: 'Récupérez votre Kizco quotidien.', ja: '毎日のKizcoを受け取る。' },
    'cmd.luna': { id: 'Ngobrol dengan asisten AI guild.', en: 'Chat with the guild AI assistant.', es: 'Chatea con el asistente IA del gremio.', pt: 'Converse com o assistente IA da guilda.', fr: 'Discutez avec l\'assistant IA de la guilde.', ja: 'ギルドAIアシスタントと会話。' },
    'cmd.help': { id: 'Lihat semua command per kategori.', en: 'See all commands by category.', es: 'Ve todos los comandos por categoría.', pt: 'Veja todos os comandos por categoria.', fr: 'Voyez toutes les commandes par catégorie.', ja: 'カテゴリ別に全コマンドを表示。' },

    // ---------- Halaman web trading & market (chrome statis) ----------
    'web.login_discord': { id: 'Login dengan Discord', en: 'Log in with Discord', es: 'Iniciar sesión con Discord', pt: 'Entrar com Discord', fr: 'Se connecter avec Discord', ja: 'Discordでログイン' },
    'web.beranda': { id: 'Beranda', en: 'Home', es: 'Inicio', pt: 'Início', fr: 'Accueil', ja: 'ホーム' },
    'web.search_asset': { id: 'Cari aset...', en: 'Search assets...', es: 'Buscar activos...', pt: 'Buscar ativos...', fr: 'Rechercher des actifs...', ja: '資産を検索...' },
    'web.price': { id: 'Harga', en: 'Price', es: 'Precio', pt: 'Preço', fr: 'Prix', ja: '価格' },
    'web.qty': { id: 'Jumlah', en: 'Amount', es: 'Cantidad', pt: 'Quantidade', fr: 'Quantité', ja: '数量' },
    'web.total': { id: 'Total', en: 'Total', es: 'Total', pt: 'Total', fr: 'Total', ja: '合計' },
    'web.buy': { id: 'Beli', en: 'Buy', es: 'Comprar', pt: 'Comprar', fr: 'Acheter', ja: '購入' },
    'web.sell': { id: 'Jual', en: 'Sell', es: 'Vender', pt: 'Vender', fr: 'Vendre', ja: '売却' },

    'trade.sub_login': { id: 'Terminal perdagangan Kizco', en: 'Kizco trading terminal', es: 'Terminal de trading Kizco', pt: 'Terminal de trading Kizco', fr: 'Terminal de trading Kizco', ja: 'Kizcoトレード端末' },
    'trade.sub_brand': { id: 'Terminal Perdagangan', en: 'Trading Terminal', es: 'Terminal de trading', pt: 'Terminal de trading', fr: 'Terminal de trading', ja: 'トレード端末' },
    'trade.value': { id: 'Nilai', en: 'Value', es: 'Valor', pt: 'Valor', fr: 'Valeur', ja: '価値' },
    'trade.asset': { id: 'Aset', en: 'Asset', es: 'Activo', pt: 'Ativo', fr: 'Actif', ja: '資産' },
    'trade.change24': { id: '24j', en: '24h', es: '24h', pt: '24h', fr: '24h', ja: '24h' },
    'trade.order_book': { id: 'Order Book', en: 'Order Book', es: 'Libro de órdenes', pt: 'Livro de ofertas', fr: 'Carnet d\'ordres', ja: 'オーダーブック' },
    'trade.create_order': { id: 'Buat Order', en: 'Create Order', es: 'Crear orden', pt: 'Criar ordem', fr: 'Créer un ordre', ja: '注文を作成' },
    'trade.limit': { id: 'Limit', en: 'Limit', es: 'Limitada', pt: 'Limitada', fr: 'Limite', ja: '指値' },
    'trade.market_order': { id: 'Market', en: 'Market', es: 'Mercado', pt: 'Mercado', fr: 'Marché', ja: '成行' },
    'trade.price_kzc': { id: 'Harga (KZC)', en: 'Price (KZC)', es: 'Precio (KZC)', pt: 'Preço (KZC)', fr: 'Prix (KZC)', ja: '価格（KZC）' },
    'trade.converter': { id: 'Konverter KZC → USD', en: 'KZC → USD converter', es: 'Conversor KZC → USD', pt: 'Conversor KZC → USD', fr: 'Convertisseur KZC → USD', ja: 'KZC → USD 換算' },
    'trade.conv_placeholder': { id: 'Jumlah KZC', en: 'KZC amount', es: 'Cantidad de KZC', pt: 'Quantidade de KZC', fr: 'Montant en KZC', ja: 'KZCの量' },
    'trade.submit': { id: 'Pasang Order', en: 'Place Order', es: 'Colocar orden', pt: 'Enviar ordem', fr: 'Placer l\'ordre', ja: '注文を出す' },
    'trade.tab_portfolio': { id: 'Portofolio', en: 'Portfolio', es: 'Cartera', pt: 'Portfólio', fr: 'Portefeuille', ja: 'ポートフォリオ' },
    'trade.tab_orders': { id: 'Order Aktif', en: 'Open Orders', es: 'Órdenes activas', pt: 'Ordens ativas', fr: 'Ordres actifs', ja: '未約定注文' },
    'trade.tab_trades': { id: 'Riwayat', en: 'History', es: 'Historial', pt: 'Histórico', fr: 'Historique', ja: '履歴' },
    'trade.tab_fills': { id: 'Trade Terbaru', en: 'Recent Trades', es: 'Trades recientes', pt: 'Trades recentes', fr: 'Trades récents', ja: '最近の約定' },
    'trade.tab_alerts': { id: 'Alert Harga', en: 'Price Alerts', es: 'Alertas de precio', pt: 'Alertas de preço', fr: 'Alertes de prix', ja: '価格アラート' },
    'trade.tab_leaderboard': { id: 'Papan Peringkat', en: 'Leaderboard', es: 'Clasificación', pt: 'Ranking', fr: 'Classement', ja: 'ランキング' },

    'market.sub_login': { id: 'Katalog aset & lelang', en: 'Asset catalog & auctions', es: 'Catálogo de activos y subastas', pt: 'Catálogo de ativos e leilões', fr: 'Catalogue d\'actifs et enchères', ja: '資産カタログ＆オークション' },
    'market.sub_brand': { id: 'Aset & Lelang', en: 'Assets & Auctions', es: 'Activos y subastas', pt: 'Ativos e leilões', fr: 'Actifs et enchères', ja: '資産＆オークション' },
    'market.tab_catalog': { id: 'Katalog Aset', en: 'Asset Catalog', es: 'Catálogo de activos', pt: 'Catálogo de ativos', fr: 'Catalogue d\'actifs', ja: '資産カタログ' },
    'market.tab_auction': { id: 'Lelang', en: 'Auctions', es: 'Subastas', pt: 'Leilões', fr: 'Enchères', ja: 'オークション' },
    'market.h1_assets': { id: 'Market Aset', en: 'Asset Market', es: 'Mercado de activos', pt: 'Mercado de ativos', fr: 'Marché des actifs', ja: '資産マーケット' },
    'market.all_categories': { id: 'Semua kategori', en: 'All categories', es: 'Todas las categorías', pt: 'Todas as categorias', fr: 'Toutes les catégories', ja: 'すべてのカテゴリ' },
    'market.h1_auction': { id: 'Lelang', en: 'Auctions', es: 'Subastas', pt: 'Leilões', fr: 'Enchères', ja: 'オークション' },
    'market.sell_panel_title': { id: 'Jual Aset Kamu', en: 'Sell Your Assets', es: 'Vende tus activos', pt: 'Venda seus ativos', fr: 'Vendez vos actifs', ja: '資産を売却' },
    'market.select_asset': { id: 'Pilih aset...', en: 'Select asset...', es: 'Elegir activo...', pt: 'Selecionar ativo...', fr: 'Choisir un actif...', ja: '資産を選択...' },
    'market.price_unit': { id: 'Harga/unit (KZC)', en: 'Price/unit (KZC)', es: 'Precio/unidad (KZC)', pt: 'Preço/unidade (KZC)', fr: 'Prix/unité (KZC)', ja: '価格/個（KZC）' },
    'market.list': { id: 'Pasang Listing', en: 'List Item', es: 'Publicar listado', pt: 'Publicar anúncio', fr: 'Publier l\'annonce', ja: '出品する' },
    'market.modal_close': { id: 'Tutup', en: 'Close', es: 'Cerrar', pt: 'Fechar', fr: 'Fermer', ja: '閉じる' },
    'market.kzc_unit': { id: 'KZC/unit', en: 'KZC/unit', es: 'KZC/unidad', pt: 'KZC/unidade', fr: 'KZC/unité', ja: 'KZC/個' },

    // ---------- Chrome bersama (nav / login / tindakan umum) ----------
    'nav.musik': { id: 'Musik', en: 'Music', es: 'Música', pt: 'Música', fr: 'Musique', ja: '音楽' },
    'nav.chat': { id: 'Chat', en: 'Chat', es: 'Chat', pt: 'Chat', fr: 'Chat', ja: 'チャット' },
    'nav.tts': { id: 'TTS', en: 'TTS', es: 'TTS', pt: 'TTS', fr: 'TTS', ja: 'TTS' },
    'nav.monitor': { id: 'Monitor', en: 'Monitor', es: 'Monitor', pt: 'Monitor', fr: 'Moniteur', ja: 'モニター' },
    'nav.ranking': { id: 'Ranking', en: 'Leaderboard', es: 'Clasificación', pt: 'Ranking', fr: 'Classement', ja: 'ランキング' },
    'nav.ekonomi': { id: 'Ekonomi', en: 'Economy', es: 'Economía', pt: 'Economia', fr: 'Économie', ja: '経済' },
    'nav.katalog': { id: 'Katalog', en: 'Catalog', es: 'Catálogo', pt: 'Catálogo', fr: 'Catalogue', ja: 'カタログ' },
    'nav.giveaway': { id: 'Giveaway', en: 'Giveaway', es: 'Sorteo', pt: 'Sorteio', fr: 'Concours', ja: 'ギブアウェイ' },
    'nav.moderasi': { id: 'Moderasi', en: 'Moderation', es: 'Moderación', pt: 'Moderação', fr: 'Modération', ja: 'モデレーション' },
    'nav.users': { id: 'Users', en: 'Users', es: 'Usuarios', pt: 'Usuários', fr: 'Utilisateurs', ja: 'ユーザー' },
    'nav.settings': { id: 'Settings', en: 'Settings', es: 'Ajustes', pt: 'Configurações', fr: 'Paramètres', ja: '設定' },
    'nav.keluar': { id: 'Keluar', en: 'Log out', es: 'Salir', pt: 'Sair', fr: 'Déconnexion', ja: 'ログアウト' },
    'nav.control_panel': { id: 'Control Panel', en: 'Control Panel', es: 'Panel de control', pt: 'Painel de controle', fr: 'Panneau de contrôle', ja: 'コントロールパネル' },
    'nav.or_token': { id: 'atau pakai token', en: 'or use a token', es: 'o usa un token', pt: 'ou use um token', fr: 'ou utilisez un jeton', ja: 'またはトークンを使用' },
    'nav.masuk': { id: 'Masuk', en: 'Log in', es: 'Entrar', pt: 'Entrar', fr: 'Se connecter', ja: 'ログイン' },
    'nav.simpan': { id: 'Simpan', en: 'Save', es: 'Guardar', pt: 'Salvar', fr: 'Enregistrer', ja: '保存' },
    'nav.muat': { id: 'Muat', en: 'Load', es: 'Cargar', pt: 'Carregar', fr: 'Charger', ja: '読み込む' },
    'nav.batal': { id: 'Batal', en: 'Cancel', es: 'Cancelar', pt: 'Cancelar', fr: 'Annuler', ja: 'キャンセル' },
    'nav.edit': { id: 'Edit', en: 'Edit', es: 'Editar', pt: 'Editar', fr: 'Modifier', ja: '編集' },
    'nav.loading': { id: 'Memuat...', en: 'Loading...', es: 'Cargando...', pt: 'Carregando...', fr: 'Chargement...', ja: '読み込み中...' },
    'nav.failed_load': { id: 'Gagal memuat data.', en: 'Failed to load data.', es: 'Error al cargar.', pt: 'Falha ao carregar.', fr: 'Échec du chargement.', ja: '読み込みに失敗しました。' },
    'nav.no_data': { id: 'Tidak ada server.', en: 'No servers.', es: 'No hay servidores.', pt: 'Sem servidores.', fr: 'Aucun serveur.', ja: 'サーバーがありません。' },
    'nav.member': { id: 'member', en: 'members', es: 'miembros', pt: 'membros', fr: 'membres', ja: 'メンバー' },

    // ---------- Halaman profil ----------
    'prof.title': { id: 'Profil', en: 'Profile', es: 'Perfil', pt: 'Perfil', fr: 'Profil', ja: 'プロフィール' },
    'prof.not_logged_title': { id: 'Kamu belum login', en: 'You are not logged in', es: 'No has iniciado sesión', pt: 'Você não está logado', fr: 'Vous n\'êtes pas connecté', ja: 'ログインしていません' },
    'prof.not_logged_desc': { id: 'Login dengan Discord untuk melihat profilmu.', en: 'Log in with Discord to view your profile.', es: 'Inicia sesión con Discord para ver tu perfil.', pt: 'Entre com Discord para ver seu perfil.', fr: 'Connectez-vous avec Discord pour voir votre profil.', ja: 'Discordでログインしてプロフィールを見てください。' },
    'prof.about': { id: 'Tentang Saya', en: 'About Me', es: 'Sobre mí', pt: 'Sobre mim', fr: 'À propos de moi', ja: '自己紹介' },
    'prof.no_bio': { id: 'Belum ada bio.', en: 'No bio yet.', es: 'Aún sin bio.', pt: 'Ainda sem bio.', fr: 'Pas encore de bio.', ja: 'まだ自己紹介がありません。' },
    'prof.pronouns': { id: 'Pronouns', en: 'Pronouns', es: 'Pronombres', pt: 'Pronomes', fr: 'Pronoms', ja: '代名詞' },
    'prof.location': { id: 'Lokasi', en: 'Location', es: 'Ubicación', pt: 'Localização', fr: 'Lieu', ja: '場所' },
    'prof.accent': { id: 'Warna aksen', en: 'Accent color', es: 'Color de acento', pt: 'Cor de destaque', fr: 'Couleur d\'accent', ja: 'アクセントカラー' },
    'prof.rpg': { id: 'Karakter RPG', en: 'RPG Character', es: 'Personaje RPG', pt: 'Personagem RPG', fr: 'Personnage RPG', ja: 'RPGキャラクター' },
    'prof.level': { id: 'Level', en: 'Level', es: 'Nivel', pt: 'Nível', fr: 'Niveau', ja: 'レベル' },
    'prof.rep': { id: 'Reputasi', en: 'Reputation', es: 'Reputación', pt: 'Reputação', fr: 'Réputation', ja: '評判' },
    'prof.monster': { id: 'Monster', en: 'Monsters', es: 'Monstruos', pt: 'Monstros', fr: 'Monstres', ja: 'モンスター' },
    'prof.quest': { id: 'Quest', en: 'Quests', es: 'Misiones', pt: 'Missões', fr: 'Quêtes', ja: 'クエスト' },
    'prof.eco_server': { id: 'Ekonomi per Server', en: 'Economy per Server', es: 'Economía por servidor', pt: 'Economia por servidor', fr: 'Économie par serveur', ja: 'サーバー別の経済' },
    'prof.total_kzc': { id: 'Total Kizco', en: 'Total Kizco', es: 'Kizco total', pt: 'Kizco total', fr: 'Kizco total', ja: '合計Kizco' },
    'prof.in_bank': { id: 'Di Bank', en: 'In Bank', es: 'En el banco', pt: 'No banco', fr: 'En banque', ja: '銀行残高' },
    'prof.age': { id: 'Umur', en: 'Age', es: 'Edad', pt: 'Idade', fr: 'Âge', ja: '年齢' },
    'prof.registered': { id: 'Terdaftar', en: 'Registered', es: 'Registrado', pt: 'Registrado', fr: 'Inscrit', ja: '登録済み' },
    'prof.banned': { id: 'Diblokir', en: 'Blocked', es: 'Bloqueado', pt: 'Bloqueado', fr: 'Bloqué', ja: 'ブロック済み' },
    'prof.item': { id: 'item', en: 'items', es: 'objetos', pt: 'itens', fr: 'objets', ja: 'アイテム' },

    // ---------- Halaman peringkat server ----------
    'srv.title': { id: 'Peringkat Server', en: 'Server Ranking', es: 'Ranking de servidores', pt: 'Ranking de servidores', fr: 'Classement des serveurs', ja: 'サーバーランキング' },
    'srv.subtitle': { id: 'Peringkat berdasarkan skor menyeluruh: stabilitas harga, aktivitas ekonomi, jumlah member, dan kematangan — bukan cuma angka kesehatan.', en: 'Ranked by an overall score: price stability, economic activity, member count, and maturity — not just the health number.', es: 'Ranking por un puntaje integral: estabilidad, actividad, miembros y madurez.', pt: 'Ranking por uma pontuação integral: estabilidade, atividade, membros e maturidade.', fr: 'Classement par un score global : stabilité, activité, membres et maturité.', ja: '安定性・経済活動・メンバー数・成熟度を組み合わせた総合スコアで順位付け。' },
    'srv.money_supply': { id: 'Uang Beredar', en: 'Money Supply', es: 'Oferta monetaria', pt: 'Oferta de moeda', fr: 'Masse monétaire', ja: '通貨供給量' },
    'srv.health': { id: 'Kesehatan', en: 'Health', es: 'Salud', pt: 'Saúde', fr: 'Santé', ja: '健全度' },
    'srv.score': { id: 'Skor', en: 'Score', es: 'Puntaje', pt: 'Pontuação', fr: 'Score', ja: 'スコア' },
    'srv.stability': { id: 'Stabilitas', en: 'Stability', es: 'Estabilidad', pt: 'Estabilidade', fr: 'Stabilité', ja: '安定性' },
    'srv.activity': { id: 'Aktivitas', en: 'Activity', es: 'Actividad', pt: 'Atividade', fr: 'Activité', ja: '活動' },
    'srv.community': { id: 'Komunitas', en: 'Community', es: 'Comunidad', pt: 'Comunidade', fr: 'Communauté', ja: 'コミュニティ' },
    'srv.maturity': { id: 'Kematangan', en: 'Maturity', es: 'Madurez', pt: 'Maturidade', fr: 'Maturité', ja: '成熟度' },
    'srv.inflation': { id: 'Inflasi', en: 'Inflation', es: 'Inflación', pt: 'Inflação', fr: 'Inflation', ja: 'インフレ' },
    'srv.price_index': { id: 'Indeks Harga', en: 'Price Index', es: 'Índice de precios', pt: 'Índice de preços', fr: 'Indice des prix', ja: '物価指数' },
    'srv.bank_interest': { id: 'Bunga Bank', en: 'Bank Interest', es: 'Interés bancario', pt: 'Juros bancários', fr: 'Intérêt bancaire', ja: '銀行金利' },
    'srv.tax': { id: 'Pajak', en: 'Tax', es: 'Impuesto', pt: 'Imposto', fr: 'Taxe', ja: '税' },
    'srv.join': { id: 'Gabung Server', en: 'Join Server', es: 'Unirse', pt: 'Entrar', fr: 'Rejoindre', ja: '参加' },
    'srv.close': { id: 'Tutup', en: 'Close', es: 'Cerrar', pt: 'Fechar', fr: 'Fermer', ja: '閉じる' },
    'srv.profile_fail': { id: 'Gagal memuat profil server.', en: 'Failed to load server profile.', es: 'Error al cargar el perfil.', pt: 'Falha ao carregar o perfil.', fr: 'Échec du chargement du profil.', ja: 'プロフィールの読み込みに失敗。' },
    'srv.not_logged': { id: 'Belum ada server.', en: 'No servers yet.', es: 'Aún no hay servidores.', pt: 'Ainda sem servidores.', fr: 'Aucun serveur pour l\'instant.', ja: 'まだサーバーがありません。' },

    // ---------- UI dinamis terminal trading & market (JS) ----------
    'ui.select_server': { id: 'Pilih server...', en: 'Select server...', es: 'Seleccionar servidor...', pt: 'Selecionar servidor...', fr: 'Sélectionner un serveur...', ja: 'サーバーを選択...' },
    'ui.buy': { id: 'Beli', en: 'Buy', es: 'Comprar', pt: 'Comprar', fr: 'Acheter', ja: '購入' },
    'ui.sell': { id: 'Jual', en: 'Sell', es: 'Vender', pt: 'Vender', fr: 'Vendre', ja: '売却' },
    'ui.cancel': { id: 'Batal', en: 'Cancel', es: 'Cancelar', pt: 'Cancelar', fr: 'Annuler', ja: 'キャンセル' },
    'ui.deposit': { id: 'Deposit', en: 'Deposit', es: 'Depositar', pt: 'Depositar', fr: 'Déposer', ja: '入金' },
    'ui.withdraw': { id: 'Withdraw', en: 'Withdraw', es: 'Retirar', pt: 'Retirar', fr: 'Retirer', ja: '出金' },
    'ui.failed': { id: 'Gagal: {err}', en: 'Failed: {err}', es: 'Error: {err}', pt: 'Falha: {err}', fr: 'Échec : {err}', ja: '失敗: {err}' },
    'ui.login_discord_first': { id: 'Login Discord dulu', en: 'Log in with Discord first', es: 'Inicia sesión con Discord primero', pt: 'Entre com Discord primeiro', fr: 'Connectez-vous d\'abord avec Discord', ja: '先にDiscordでログイン' },
    'ui.pick_server_first': { id: 'Pilih server dulu', en: 'Select a server first', es: 'Elige un servidor primero', pt: 'Selecione um servidor primeiro', fr: 'Choisissez d\'abord un serveur', ja: '先にサーバーを選択' },
    'trade.high24': { id: 'Tinggi 24j', en: '24h High', es: 'Máximo 24h', pt: 'Máxima 24h', fr: 'Plus haut 24h', ja: '24h高値' },
    'trade.low24': { id: 'Rendah 24j', en: '24h Low', es: 'Mínimo 24h', pt: 'Mínima 24h', fr: 'Plus bas 24h', ja: '24h安値' },
    'trade.vol24': { id: 'Volume 24j', en: '24h Volume', es: 'Volumen 24h', pt: 'Volume 24h', fr: 'Volume 24h', ja: '24h出来高' },
    'trade.spread': { id: '{n} spread', en: '{n} spread', es: '{n} spread', pt: '{n} spread', fr: '{n} spread', ja: '{n} スプレッド' },
    'trade.no_order_book': { id: 'Belum ada order', en: 'No orders yet', es: 'Aún no hay órdenes', pt: 'Ainda sem ordens', fr: 'Pas encore d\'ordres', ja: 'まだ注文がありません' },
    'trade.est_total': { id: 'Estimasi total', en: 'Estimated total', es: 'Total estimado', pt: 'Total estimado', fr: 'Total estimé', ja: '概算合計' },
    'trade.total': { id: 'Total', en: 'Total', es: 'Total', pt: 'Total', fr: 'Total', ja: '合計' },
    'trade.avail_buy': { id: 'Tersedia: {n} KZC', en: 'Available: {n} KZC', es: 'Disponible: {n} KZC', pt: 'Disponível: {n} KZC', fr: 'Disponible : {n} KZC', ja: '利用可能: {n} KZC' },
    'trade.avail_sell': { id: 'Kamu pegang: {n} unit', en: 'You hold: {n} units', es: 'Tienes: {n} unidades', pt: 'Você tem: {n} unidades', fr: 'Vous détenez : {n} unités', ja: '保有: {n}単位' },
    'trade.pick_server_asset': { id: 'Pilih server & aset dulu', en: 'Select a server and asset first', es: 'Elige servidor y activo', pt: 'Selecione servidor e ativo', fr: 'Choisissez serveur et actif', ja: '先にサーバーと資産を選択' },
    'trade.fill_price': { id: 'Isi harga untuk order limit', en: 'Enter a price for a limit order', es: 'Introduce un precio para la orden limitada', pt: 'Informe um preço para ordem limitada', fr: 'Saisissez un prix pour un ordre limite', ja: '指値注文には価格を入力' },
    'trade.fill_qty': { id: 'Isi jumlah lebih dari 0', en: 'Enter an amount greater than 0', es: 'Introduce una cantidad mayor que 0', pt: 'Informe uma quantidade maior que 0', fr: 'Saisissez une quantité supérieure à 0', ja: '0より大きい数量を入力' },
    'trade.sending': { id: 'Mengirim...', en: 'Sending...', es: 'Enviando...', pt: 'Enviando...', fr: 'Envoi...', ja: '送信中...' },
    'trade.order_placed': { id: 'Order #{id} terpasang', en: 'Order #{id} placed', es: 'Orden #{id} colocada', pt: 'Ordem #{id} enviada', fr: 'Ordre #{id} placé', ja: '注文#{id}を発注' },
    'trade.filled_n': { id: 'Terisi {n} transaksi', en: 'Filled {n} trades', es: '{n} operaciones ejecutadas', pt: '{n} negociações executadas', fr: '{n} transactions exécutées', ja: '{n}件約定' },
    'trade.idx': { id: 'Indeks {n}', en: 'Index {n}', es: 'Índice {n}', pt: 'Índice {n}', fr: 'Indice {n}', ja: '指数 {n}' },
    'trade.tab_asset': { id: 'Aset', en: 'Asset', es: 'Activo', pt: 'Ativo', fr: 'Actif', ja: '資産' },
    'trade.tab_qty': { id: 'Jumlah', en: 'Amount', es: 'Cantidad', pt: 'Quantidade', fr: 'Quantité', ja: '数量' },
    'trade.tab_price': { id: 'Harga', en: 'Price', es: 'Precio', pt: 'Preço', fr: 'Prix', ja: '価格' },
    'trade.tab_value': { id: 'Nilai', en: 'Value', es: 'Valor', pt: 'Valor', fr: 'Valeur', ja: '価値' },
    'trade.no_assets': { id: 'Belum punya aset. Beli di market atau pasang order.', en: 'No assets yet. Buy on the market or place an order.', es: 'Aún no tienes activos. Compra en el mercado o coloca una orden.', pt: 'Ainda sem ativos. Compre no mercado ou envie uma ordem.', fr: 'Pas encore d\'actifs. Achetez sur le marché ou passez un ordre.', ja: 'まだ資産がありません。マーケットで購入するか注文を出してください。' },
    'trade.cancel_all': { id: 'Batalkan semua order', en: 'Cancel all orders', es: 'Cancelar todas las órdenes', pt: 'Cancelar todas as ordens', fr: 'Annuler tous les ordres', ja: '全注文をキャンセル' },
    'trade.no_open_orders': { id: 'Tidak ada order aktif.', en: 'No open orders.', es: 'No hay órdenes activas.', pt: 'Sem ordens ativas.', fr: 'Aucun ordre actif.', ja: '未約定注文はありません。' },
    'trade.col_id': { id: 'ID', en: 'ID', es: 'ID', pt: 'ID', fr: 'ID', ja: 'ID' },
    'trade.col_side': { id: 'Sisi', en: 'Side', es: 'Lado', pt: 'Lado', fr: 'Côté', ja: '売買' },
    'trade.col_type': { id: 'Tipe', en: 'Type', es: 'Tipo', pt: 'Tipo', fr: 'Type', ja: 'タイプ' },
    'trade.col_remaining': { id: 'Sisa', en: 'Remaining', es: 'Restante', pt: 'Restante', fr: 'Restant', ja: '残量' },
    'trade.col_action': { id: 'Aksi', en: 'Action', es: 'Acción', pt: 'Ação', fr: 'Action', ja: '操作' },
    'trade.wallet': { id: 'Dompet', en: 'Wallet', es: 'Cartera', pt: 'Carteira', fr: 'Portefeuille', ja: 'ウォレット' },
    'trade.bank': { id: 'Bank', en: 'Bank', es: 'Banco', pt: 'Banco', fr: 'Banque', ja: '銀行' },
    'trade.assets_val': { id: 'Aset', en: 'Assets', es: 'Activos', pt: 'Ativos', fr: 'Actifs', ja: '資産' },
    'market.no_assets': { id: 'Tidak ada aset yang cocok.', en: 'No matching assets.', es: 'No hay activos que coincidan.', pt: 'Nenhum ativo correspondente.', fr: 'Aucun actif correspondant.', ja: '一致する資産がありません。' },
    'market.prev': { id: 'Sebelumnya', en: 'Previous', es: 'Anterior', pt: 'Anterior', fr: 'Précédent', ja: '前へ' },
    'market.next': { id: 'Berikutnya', en: 'Next', es: 'Siguiente', pt: 'Próximo', fr: 'Suivant', ja: '次へ' },
    'market.page': { id: 'Halaman {p} dari {t}', en: 'Page {p} of {t}', es: 'Página {p} de {t}', pt: 'Página {p} de {t}', fr: 'Page {p} sur {t}', ja: '{t}ページ中{p}ページ' },
    'market.no_listings': { id: 'Belum ada listing. Jadilah penjual pertama.', en: 'No listings yet. Be the first seller.', es: 'Aún no hay listados. Sé el primer vendedor.', pt: 'Ainda sem anúncios. Seja o primeiro vendedor.', fr: 'Pas encore d\'annonces. Soyez le premier vendeur.', ja: 'まだ出品がありません。最初の売り手になりましょう。' },
    'market.active_listings': { id: '{n} listing aktif', en: '{n} active listings', es: '{n} listados activos', pt: '{n} anúncios ativos', fr: '{n} annonces actives', ja: '出品 {n}件' },
    'market.seller': { id: 'penjual {id}', en: 'seller {id}', es: 'vendedor {id}', pt: 'vendedor {id}', fr: 'vendeur {id}', ja: '出品者 {id}' },
    'market.demand': { id: 'Permintaan', en: 'Demand', es: 'Demanda', pt: 'Demanda', fr: 'Demande', ja: '需要' },
    'market.24h': { id: '24 jam', en: '24h', es: '24h', pt: '24h', fr: '24h', ja: '24時間' },
    'market.no_desc': { id: 'Tidak ada deskripsi.', en: 'No description.', es: 'Sin descripción.', pt: 'Sem descrição.', fr: 'Pas de description.', ja: '説明なし。' },
    'market.processing': { id: 'Memproses...', en: 'Processing...', es: 'Procesando...', pt: 'Processando...', fr: 'Traitement...', ja: '処理中...' },
    'market.bought': { id: 'Berhasil membeli {n}x {name}', en: 'Bought {n}x {name}', es: 'Comprado {n}x {name}', pt: 'Comprado {n}x {name}', fr: 'Acheté {n}x {name}', ja: '{name}を{n}個購入' },
    'market.enter_token': { id: 'Isi token dulu', en: 'Enter the token first', es: 'Introduce el token primero', pt: 'Informe o token primeiro', fr: 'Saisissez d\'abord le jeton', ja: '先にトークンを入力' },

    // ===== HALAMAN VOTE =====
    'vote.badge': { id: 'Butuh 30 detik doang', en: 'Only takes 30 seconds', es: 'Solo toma 30 segundos', pt: 'Leva só 30 segundos', fr: 'Ça prend 30 secondes', ja: 'たった30秒です' },
    'vote.title': { id: 'Dukung KizhooBot', en: 'Support KizhooBot', es: 'Apoya a KizhooBot', pt: 'Apoie o KizhooBot', fr: 'Soutenez KizhooBot', ja: 'KizhooBotを応援しよう' },
    'vote.tagline': { id: 'Satu klik vote, bikin bot ini makin gampang ditemukan orang lain.', en: 'One vote click helps other people find this bot more easily.', es: 'Un clic de voto ayuda a que más gente encuentre este bot.', pt: 'Um clique de voto ajuda outras pessoas a encontrar este bot.', fr: 'Un clic de vote aide les autres à trouver ce bot plus facilement.', ja: '1回の投票が、他の人がこのボットを見つけやすくします。' },
    'vote.desc': { id: 'KizhooBot gratis dan gak pasang iklan. Cara kita berkembang cuma dari server yang sudah pakai cerita ke orang lain — dan dari vote di situs listing bot kayak di bawah ini.', en: 'KizhooBot is free and has no ads. The only way it grows is from servers that already use it telling others — and from votes on bot listing sites like below.', es: 'KizhooBot es gratis y sin anuncios. Solo crece cuando los servidores que ya lo usan lo recomiendan, y con votos en sitios de listado de bots como estos.', pt: 'O KizhooBot é grátis e sem anúncios. Ele só cresce quando servidores que já usam recomendam, e com votos em sites de listagem de bots como estes.', fr: 'KizhooBot est gratuit et sans publicité. Il ne grandit que grâce aux serveurs qui le recommandent, et aux votes sur des sites de listing comme ceux-ci.', ja: 'KizhooBotは無料で広告もありません。利用中のサーバーが他の人に伝えてくれること、そして下記のようなボット掲載サイトでの投票だけが成長の手段です。' },
    'vote.popular': { id: 'Paling banyak dipakai', en: 'Most widely used', es: 'El más usado', pt: 'O mais usado', fr: 'Le plus utilisé', ja: '最も利用者が多い' },
    'vote.topgg_title': { id: 'Vote di top.gg', en: 'Vote on top.gg', es: 'Vota en top.gg', pt: 'Vote no top.gg', fr: 'Votez sur top.gg', ja: 'top.ggで投票' },
    'vote.topgg_desc': { id: 'Direktori bot Discord terbesar. Makin banyak vote, makin tinggi posisi KizhooBot muncul saat orang cari bot ekonomi/RPG.', en: 'The biggest Discord bot directory. More votes means KizhooBot ranks higher when people search for economy/RPG bots.', es: 'El directorio de bots de Discord más grande. Más votos significa que KizhooBot aparece más arriba al buscar bots de economía/RPG.', pt: 'O maior diretório de bots do Discord. Mais votos fazem o KizhooBot aparecer mais alto nas buscas por bots de economia/RPG.', fr: 'Le plus grand annuaire de bots Discord. Plus de votes font remonter KizhooBot dans les recherches de bots économie/RPG.', ja: 'Discord最大のボットディレクトリです。投票が多いほど、経済/RPGボット検索でKizhooBotの表示順位が上がります。' },
    'vote.dbl_title': { id: 'Vote di DiscordBotList', en: 'Vote on DiscordBotList', es: 'Vota en DiscordBotList', pt: 'Vote no DiscordBotList', fr: 'Votez sur DiscordBotList', ja: 'DiscordBotListで投票' },
    'vote.dbl_desc': { id: 'Listing komunitas dengan statistik server live. Vote di sini juga bantu kredibilitas bot buat server baru yang lagi nyari.', en: 'A community listing with live server stats. Voting here also helps the bot look credible to new servers that are searching.', es: 'Un listado comunitario con estadísticas de servidores en vivo. Votar aquí también ayuda a que nuevos servidores confíen en el bot.', pt: 'Um listing comunitário com estatísticas de servidores ao vivo. Votar aqui também ajuda a credibilidade do bot para novos servidores.', fr: 'Un annuaire communautaire avec des stats serveur en direct. Voter ici aide aussi la crédibilité du bot pour les nouveaux serveurs.', ja: 'サーバーのライブ統計があるコミュニティ掲載サイトです。ここでの投票は、探している新しいサーバーへの信頼感にもつながります。' },
    'vote.btn': { id: 'Vote sekarang →', en: 'Vote now →', es: 'Vota ahora →', pt: 'Vote agora →', fr: 'Voter maintenant →', ja: '今すぐ投票 →' },
    'vote.unavailable': { id: 'Link vote belum diaktifkan owner bot.', en: 'The bot owner has not enabled this vote link yet.', es: 'El dueño del bot aún no activó este enlace de voto.', pt: 'O dono do bot ainda não ativou este link de voto.', fr: 'Le propriétaire du bot n\'a pas encore activé ce lien de vote.', ja: 'ボットのオーナーがこの投票リンクをまだ有効にしていません。' },
    'vote.why_title': { id: 'Kenapa vote itu penting', en: 'Why voting matters', es: 'Por qué votar importa', pt: 'Por que votar importa', fr: 'Pourquoi voter compte', ja: '投票が大切な理由' },
    'vote.why1_title': { id: 'Lebih gampang ditemukan', en: 'Easier to discover', es: 'Más fácil de descubrir', pt: 'Mais fácil de descobrir', fr: 'Plus facile à découvrir', ja: '見つけてもらいやすくなる' },
    'vote.why1_desc': { id: 'Situs listing naikin peringkat bot yang sering di-vote, jadi lebih sering muncul di pencarian dan halaman populer.', en: 'Listing sites rank frequently-voted bots higher, so they show up more in search and popular pages.', es: 'Los sitios de listado suben la posición de los bots más votados, así aparecen más en búsquedas y páginas populares.', pt: 'Sites de listagem sobem o ranking de bots mais votados, então aparecem mais em buscas e páginas populares.', fr: 'Les sites d\'annuaire classent plus haut les bots souvent votés, donc ils apparaissent plus en recherche et pages populaires.', ja: '掲載サイトは投票が多いボットの順位を上げるため、検索や人気ページに表示されやすくなります。' },
    'vote.why2_title': { id: 'Komunitas makin rame', en: 'A livelier community', es: 'Una comunidad más viva', pt: 'Uma comunidade mais viva', fr: 'Une communauté plus vivante', ja: 'コミュニティが賑やかに' },
    'vote.why2_desc': { id: 'Makin banyak server yang gabung, makin hidup ekonomi Kizco, market, dan fitur lain yang butuh banyak pemain.', en: 'The more servers join, the livelier the Kizco economy, market, and other features that need many players.', es: 'Cuantos más servidores se unan, más viva la economía de Kizco, el mercado y otras funciones que necesitan jugadores.', pt: 'Quanto mais servidores entram, mais viva fica a economia do Kizco, o mercado e outros recursos que precisam de jogadores.', fr: 'Plus de serveurs rejoignent, plus l\'économie Kizco, le marché et les autres fonctions qui ont besoin de joueurs sont vivants.', ja: '参加サーバーが増えるほど、多くのプレイヤーを必要とするKizco経済やマーケットなどの機能が活発になります。' },
    'vote.why3_title': { id: 'Gratis, gak ada biaya', en: 'Free, no cost', es: 'Gratis, sin costo', pt: 'Grátis, sem custo', fr: 'Gratuit, sans frais', ja: '無料でコストなし' },
    'vote.why3_desc': { id: 'Gak perlu login khusus atau bayar apa pun. Login Discord kamu di situsnya, klik vote, selesai.', en: 'No special login or payment needed. Log in with Discord on the site, click vote, done.', es: 'No necesitas iniciar sesión especial ni pagar nada. Inicia sesión con Discord en el sitio, haz clic en votar, listo.', pt: 'Não precisa de login especial nem pagar nada. Faça login com Discord no site, clique em votar, pronto.', fr: 'Pas besoin de connexion spéciale ni de paiement. Connectez-vous avec Discord sur le site, cliquez sur voter, terminé.', ja: '特別なログインや支払いは不要です。サイトでDiscordログインし、投票をクリックするだけです。' },
    'vote.note': { id: 'Biasanya kamu bisa vote ulang secara berkala di masing-masing situs — cek halaman vote-nya buat tahu kapan bisa vote lagi.', en: 'You can usually vote again periodically on each site — check the vote page there to see when you can vote again.', es: 'Normalmente puedes volver a votar periódicamente en cada sitio; revisa su página de voto para saber cuándo.', pt: 'Normalmente dá para votar de novo periodicamente em cada site; confira a página de voto para saber quando.', fr: 'Vous pouvez généralement revoter périodiquement sur chaque site — consultez sa page de vote pour savoir quand.', ja: '通常、各サイトで定期的に再投票できます。次にいつ投票できるかはそれぞれの投票ページでご確認ください。' },
    'market.wrong_token': { id: 'Token salah', en: 'Wrong token', es: 'Token incorrecto', pt: 'Token incorreto', fr: 'Jeton incorrect', ja: 'トークンが違います' },
    'market.listing_placed': { id: 'Listing terpasang', en: 'Listing placed', es: 'Listado publicado', pt: 'Anúncio publicado', fr: 'Annonce publiée', ja: '出品しました' },
  };

  const LANG_BY_CODE = Object.fromEntries(LANGUAGES.map((l) => [l.code, l]));

  function t(lang, key, params) {
    const dict = T[key];
    if (!dict) return key;
    let str = dict[lang] || dict.en || dict.id || key;
    params = params || {};
    for (const k of Object.keys(params)) {
      str = str.replace(new RegExp('\\{' + k + '\\}', 'g'), String(params[k]));
    }
    return str;
  }

  function currentLang() {
    const m = document.cookie.match(/(?:^|;\s*)kz_lang=([^;]+)/);
    return (m && LANG_BY_CODE[m[1]]) ? m[1] : 'id';
  }

  function setLang(code) {
    if (!LANG_BY_CODE[code]) return;
    document.cookie = 'kz_lang=' + code + '; path=/; max-age=31536000; SameSite=Lax';
  }

  function apply() {
    const lang = currentLang();
    document.querySelectorAll('[data-i18n]').forEach((el) => {
      const key = el.getAttribute('data-i18n');
      const txt = t(lang, key);
      if (txt && txt !== key) el.textContent = txt;
    });
    document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
      el.setAttribute('placeholder', t(lang, el.getAttribute('data-i18n-placeholder')));
    });
    document.documentElement.lang = lang;
    const sel = document.getElementById('langSelect');
    if (sel) {
      sel.innerHTML = LANGUAGES.map((l) => `<option value="${l.code}"${l.code === lang ? ' selected' : ''}>${l.flag} ${l.native}</option>`).join('');
    }
  }

  // Suffix angka ringkas per bahasa: [ribu, juta, miliar, triliun] (skala pendek/pajang sesuai bahasa).
  // Suffix angka ringkas PER BAHASA (skala pendek): [ribu, juta, miliar, triliun, ...].
  // Setiap bahasa punya istilah sendiri untuk bilangan besar.
  const COMPACT_SUFFIX = {
    id: ['rb', 'jt', 'M', 'T', 'Kd', 'Kn', 'Sx', 'Sp', 'Ok', 'No', 'De'],
    en: ['K', 'M', 'B', 'T', 'Qa', 'Qi', 'Sx', 'Sp', 'Oc', 'No', 'Dc'],
    es: ['K', 'M', 'B', 'T', 'Qa', 'Qi', 'Sx', 'Sp', 'Oc', 'No', 'Dc'],
    pt: ['K', 'M', 'B', 'T', 'Qa', 'Qi', 'Sx', 'Sp', 'Oc', 'No', 'Dc'],
    fr: ['k', 'M', 'Md', 'T', 'Qd', 'Qn', 'Sx', 'Sp', 'Oc', 'No', 'Dc'],
  };

  // Unit besar bahasa Jepang (pengelompokan 4 digit): 万/億/兆/京/垓/秭/穣/溝/澗.
  const JA_UNITS = ['万', '億', '兆', '京', '垓', '秭', '穣', '溝', '澗'];

  // Angka ringkas: 1.250 -> 1,25rb / 5.2M / 3.4T / 2.6T (sesuai bahasa aktif).
  // Tidak pernah memakai notasi eksponensial — selalu ada suffix yang enak dibaca.
  function compact(n) {
    const v = Number(n);
    if (!isFinite(v)) return '0';
    const abs = Math.abs(v);
    const sign = v < 0 ? '-' : '';
    const lang = currentLang();
    if (lang === 'ja') {
      // 4-digit grouping: 万(1e4), 億(1e8), 兆(1e12), 京(1e16), 垓(1e20), ...
      if (abs < 1e4) return sign + Math.round(abs);
      let idx = 0, base = 1e4;
      while (idx < JA_UNITS.length - 1 && abs >= base * 1e4) { idx++; base *= 1e4; }
      return sign + trimZeros((abs / base).toFixed(1)) + JA_UNITS[idx];
    }
    const sfx = COMPACT_SUFFIX[lang] || COMPACT_SUFFIX.en;
    if (abs < 1000) return sign + Math.round(abs);
    let idx = Math.min(sfx.length - 1, Math.floor(Math.log10(abs) / 3) - 1);
    if (idx < 0) idx = 0;
    return sign + trimZeros((abs / Math.pow(10, (idx + 1) * 3)).toFixed(1)) + sfx[idx];
  }
  function trimZeros(str) { return str.replace(/\.0+$/, ''); }

  window.WebI18n = { LANGUAGES, t, currentLang, setLang, apply, compact };
})();
