// ============================================================================
// DATA LAYER MARKET — penyimpanan candle OHLCV (rolling, multi-timeframe).
// ----------------------------------------------------------------------------
// Tabel BARU `econ_candles` (tidak menyentuh tabel lama). Candle 1m adalah raw
// series; timeframe lebih tinggi (5m/15m/30m/1h/4h/1d/1w) di-roll-up dari candle
// 1m saat bucket-nya tertutup (lihat utils/marketEngine.js), sehingga tiap
// timeframe mengakumulasi sejarahnya sendiri dan chart stabil antar-refresh.
//
// Pakai koneksi better-sqlite3 yang SAMA dari database/db.js.
// ============================================================================
const { db } = require('./db');

db.exec(`
CREATE TABLE IF NOT EXISTS econ_candles (
  guildId TEXT NOT NULL,
  instrumentId TEXT NOT NULL,
  timeframe TEXT NOT NULL,           -- 1m|5m|15m|30m|1h|4h|1d|1w
  bucketTs INTEGER NOT NULL,         -- waktu buka bucket (ms), aligned
  open REAL NOT NULL,
  high REAL NOT NULL,
  low REAL NOT NULL,
  close REAL NOT NULL,
  volume REAL NOT NULL DEFAULT 0,
  PRIMARY KEY (guildId, instrumentId, timeframe, bucketTs)
);
CREATE INDEX IF NOT EXISTS idx_econ_candles ON econ_candles (guildId, instrumentId, timeframe, bucketTs);
`);

// Upsert candle (delta volume pada langkah ini). Saat konflik: high=max, low=min,
// close=terbaru, volume=akumulasi. `open` tidak berubah.
function upsertCandle({ guildId, instrumentId, timeframe, bucketTs, open, high, low, close, volume }) {
  db.prepare(`
    INSERT INTO econ_candles (guildId, instrumentId, timeframe, bucketTs, open, high, low, close, volume)
    VALUES (@guildId, @instrumentId, @timeframe, @bucketTs, @open, @high, @low, @close, @volume)
    ON CONFLICT(guildId, instrumentId, timeframe, bucketTs) DO UPDATE SET
      high = MAX(econ_candles.high, excluded.high),
      low = MIN(econ_candles.low, excluded.low),
      close = excluded.close,
      volume = econ_candles.volume + excluded.volume
  `).run({ guildId, instrumentId, timeframe, bucketTs, open, high, low, close, volume });
}

function getCandles(guildId, instrumentId, timeframe, limit = 500) {
  return db.prepare(
    'SELECT bucketTs AS t, open, high, low, close, volume FROM econ_candles WHERE guildId = ? AND instrumentId = ? AND timeframe = ? ORDER BY bucketTs DESC LIMIT ?'
  ).all(guildId, instrumentId, timeframe, limit).reverse();
}

function getCandlesSince(guildId, instrumentId, timeframe, sinceTs, limit = 5000) {
  return db.prepare(
    'SELECT bucketTs AS t, open, high, low, close, volume FROM econ_candles WHERE guildId = ? AND instrumentId = ? AND timeframe = ? AND bucketTs >= ? ORDER BY bucketTs ASC LIMIT ?'
  ).all(guildId, instrumentId, timeframe, sinceTs, limit);
}

function pruneCandles(guildId, instrumentId, timeframe, olderThanTs) {
  return db.prepare('DELETE FROM econ_candles WHERE guildId = ? AND instrumentId = ? AND timeframe = ? AND bucketTs < ?')
    .run(guildId, instrumentId, timeframe, olderThanTs).changes;
}

// Transaction wrapper (buat insert batch bootstrap yang atomic & cepat).
function tx(fn) { return db.transaction(fn); }

module.exports = { upsertCandle, getCandles, getCandlesSince, pruneCandles, tx };
