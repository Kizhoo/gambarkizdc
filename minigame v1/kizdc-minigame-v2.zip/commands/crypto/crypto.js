const { SlashCommandBuilder } = require('discord.js');
const { normalizeSymbol, getTicker24h, getKlines, computeIndicators } = require('../../utils/cryptoApi');
const { priceEmbed, signalEmbed } = require('../../utils/cryptoFormat');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { safeDefer } = require('../../utils/interactionHelpers');
const { getCryptoConfig } = require('../../database/db');
const settings = require('../../utils/settings');
const { t, guildLang } = require('../../utils/i18n');

const VALID_INTERVALS = ['15m', '1h', '4h', '1d'];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('crypto')
    .setDescription('Info harga crypto dan pembacaan indikator teknikal')
    .addSubcommand(sub => sub.setName('price').setDescription('Harga & statistik 24 jam sebuah koin')
      .addStringOption(o => o.setName('simbol').setDescription('Kode koin, mis. BTC atau BTCUSDT').setRequired(true)))
    .addSubcommand(sub => sub.setName('signal').setDescription('Pembacaan indikator teknikal (RSI/EMA) - bukan saran beli/jual')
      .addStringOption(o => o.setName('simbol').setDescription('Kode koin, mis. BTC atau BTCUSDT').setRequired(true))
      .addStringOption(o => o.setName('timeframe').setDescription('Interval candle (default 1h)').addChoices(...VALID_INTERVALS.map(i => ({ name: i, value: i })))))
    .addSubcommand(sub => sub.setName('watchlist').setDescription('Lihat watchlist auto-sinyal server ini (atur lewat /panel)')),

  async execute(interaction) {
    const lang = guildLang(interaction);
    const sub = interaction.options.getSubcommand();

    if (sub === 'watchlist') {
      const cfg = getCryptoConfig(interaction.guild.id);
      const list = (cfg.watchlist || '').split(',').map(s => s.trim()).filter(Boolean);
      const embed = baseEmbed()
        .setTitle(`Watchlist Crypto: ${interaction.guild.name}`)
        .setDescription(list.length ? list.map(s => `\`${s}\``).join(', ') : t(lang, 'crypto.no_watchlist'))
        .addFields({ name: t(lang, 'crypto.auto_signal'), value: cfg.signalEnabled ? t(lang, 'crypto.enabled') : t(lang, 'crypto.disabled'), inline: true })
        .setFooter({ text: t(lang, 'crypto.footer') });
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const symbol = normalizeSymbol(interaction.options.getString('simbol'));
    if (!symbol) return interaction.reply({ embeds: [errorEmbed(t(lang, 'crypto.bad_symbol'))], ephemeral: true });
    if (!(await safeDefer(interaction))) return;

    try {
      if (sub === 'price') {
        const ticker = await getTicker24h(symbol);
        return interaction.editReply({ embeds: [priceEmbed(symbol, ticker)] });
      }
      if (sub === 'signal') {
        const interval = interaction.options.getString('timeframe') || settings.get('crypto.interval', '1h');
        const limit = settings.get('crypto.klineLimit', 100);
        const candles = await getKlines(symbol, interval, limit);
        if (candles.length < 20) return interaction.editReply({ embeds: [errorEmbed(t(lang, 'crypto.no_data'))] });
        const indicators = computeIndicators(candles);
        return interaction.editReply({ embeds: [signalEmbed(symbol, indicators, interval)] });
      }
    } catch (err) {
      console.error('[crypto] Gagal:', err.message);
      return interaction.editReply({ embeds: [errorEmbed(err.message)] }).catch(() => {});
    }
  },
};
