const { SlashCommandBuilder } = require('discord.js');
const trade = require('../../utils/tradeSystem');
const shop = require('../../utils/shopManager');
const econ = require('../../database/economyDb');
const kizco = require('../../utils/kizco');
const { renderItemChart } = require('../../utils/economyButtons');
const { baseEmbed, successEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

function tradeEmbed(tr, id, lang) {
  const items = tr.itemIds.map((it, i) => `\`${it}\` x${tr.itemQtys[i]}`).join(', ') || '—';
  return baseEmbed()
    .setTitle(`Trade #${id}`)
    .setDescription(`<@${tr.fromUserId}> → <@${tr.toUserId}>`)
    .addFields(
      { name: t(lang, 'trade.field_kzc'), value: kizco.format(tr.kizco), inline: true },
      { name: t(lang, 'trade.field_item'), value: items, inline: true },
      { name: t(lang, 'trade.field_status'), value: tr.status, inline: true },
    );
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('trade')
    .setDescription('Trading P2P: tawaran langsung & marketplace item RPG')
    .addSubcommand(sub => sub.setName('offer').setDescription('Tawarkan KZC + item ke seseorang')
      .addUserOption(o => o.setName('target').setDescription('Penerima').setRequired(true))
      .addIntegerOption(o => o.setName('kizco').setDescription('Jumlah KZC yang ditawarkan').setMinValue(0))
      .addStringOption(o => o.setName('item').setDescription('ID item RPG dari tasmu (opsional)'))
      .addIntegerOption(o => o.setName('jumlah_item').setDescription('Jumlah item (default 1)').setMinValue(1)))
    .addSubcommand(sub => sub.setName('list').setDescription('Lihat tawaran masuk & keluar yang masih pending'))
    .addSubcommand(sub => sub.setName('accept').setDescription('Terima tawaran masuk')
      .addIntegerOption(o => o.setName('id').setDescription('ID trade').setRequired(true)))
    .addSubcommand(sub => sub.setName('decline').setDescription('Tolak tawaran masuk')
      .addIntegerOption(o => o.setName('id').setDescription('ID trade').setRequired(true)))
    .addSubcommand(sub => sub.setName('cancel').setDescription('Batalkan tawaran keluarmu')
      .addIntegerOption(o => o.setName('id').setDescription('ID trade').setRequired(true)))
    .addSubcommand(sub => sub.setName('sell').setDescription('Jual item RPG di marketplace')
      .addStringOption(o => o.setName('item').setDescription('ID item dari tasmu').setRequired(true))
      .addIntegerOption(o => o.setName('harga').setDescription('Harga per unit (KZC)').setRequired(true).setMinValue(1))
      .addIntegerOption(o => o.setName('jumlah').setDescription('Jumlah (default 1)').setMinValue(1)))
    .addSubcommand(sub => sub.setName('listings').setDescription('Lihat daftar jualan (marketplace)'))
    .addSubcommand(sub => sub.setName('buy').setDescription('Beli dari marketplace')
      .addIntegerOption(o => o.setName('id').setDescription('ID listing').setRequired(true))
      .addIntegerOption(o => o.setName('jumlah').setDescription('Jumlah (default 1)').setMinValue(1)))
    .addSubcommand(sub => sub.setName('chart').setDescription('Grafik riwayat harga sebuah item (ala saham)')
      .addStringOption(o => o.setName('item').setDescription('ID item').setRequired(true))),

  async execute(interaction) {
    const lang = guildLang(interaction);
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    const userId = interaction.user.id;

    if (sub === 'offer') {
      const target = interaction.options.getUser('target');
      const kzc = interaction.options.getInteger('kizco') || 0;
      const item = interaction.options.getString('item');
      const qty = interaction.options.getInteger('jumlah_item') || 1;
      const ids = item ? [item.toLowerCase()] : [];
      const qtys = item ? [qty] : [];

      const res = trade.createOffer(guildId, userId, target.id, kzc, ids, qtys);
      if (!res.ok) return interaction.reply({ embeds: [errorEmbed(res.error)], ephemeral: true });

      const itemsTxt = ids.map((it, i) => `\`${it}\` x${qtys[i]}`).join(', ') || '—';
      const embed = successEmbed(t(lang, 'trade.offer_sent', { user: target.id, id: res.trade.id, kzc: kizco.format(kzc), items: itemsTxt }));
      embed.setTitle(t(lang, 'trade.offer_title'));
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'list') {
      const list = econ.listTradesForUser(guildId, userId);
      if (!list.length) return interaction.reply({ embeds: [errorEmbed(t(lang, 'trade.none_pending'))], ephemeral: true });
      const embeds = list.slice(0, 10).map(tr => tradeEmbed(tr, tr.id, lang));
      return interaction.reply({ embeds });
    }

    if (sub === 'accept') {
      const id = interaction.options.getInteger('id');
      const res = trade.acceptOffer(id, userId);
      if (!res.ok) return interaction.reply({ embeds: [errorEmbed(res.error)], ephemeral: true });
      return interaction.reply({ embeds: [successEmbed(t(lang, 'trade.accept_ok', { id }))] });
    }

    if (sub === 'decline') {
      const id = interaction.options.getInteger('id');
      const res = trade.declineOffer(id, userId);
      if (!res.ok) return interaction.reply({ embeds: [errorEmbed(res.error)], ephemeral: true });
      return interaction.reply({ embeds: [successEmbed(t(lang, 'trade.decline_ok', { id }))] });
    }

    if (sub === 'cancel') {
      const id = interaction.options.getInteger('id');
      const res = trade.cancelOffer(id, userId);
      if (!res.ok) return interaction.reply({ embeds: [errorEmbed(res.error)], ephemeral: true });
      return interaction.reply({ embeds: [successEmbed(t(lang, 'trade.cancel_ok', { id }))] });
    }

    if (sub === 'sell') {
      const itemId = interaction.options.getString('item').toLowerCase();
      const price = interaction.options.getInteger('harga');
      const qty = interaction.options.getInteger('jumlah') || 1;
      const res = trade.createListing(guildId, userId, itemId, qty, price);
      if (!res.ok) return interaction.reply({ embeds: [errorEmbed(res.error)], ephemeral: true });
      const it = shop.getItem(itemId);
      return interaction.reply({ embeds: [successEmbed(t(lang, 'trade.listing_created', { id: res.listing.id, qty, item: it.name, price: kizco.format(price) }))] });
    }

    if (sub === 'listings') {
      const list = econ.listOpenListings(guildId);
      if (!list.length) return interaction.reply({ embeds: [errorEmbed(t(lang, 'trade.mp_empty'))], ephemeral: true });

      // Rangkum per item (ala order book): best ask = harga termurah.
      const byItem = {};
      for (const l of list) {
        (byItem[l.itemId] ||= []).push(l);
      }
      const rows = Object.entries(byItem).map(([itemId, ls]) => {
        const it = shop.getItem(itemId);
        const best = ls.reduce((a, b) => (a.pricePerUnit < b.pricePerUnit ? a : b));
        const totalQty = ls.reduce((s, l) => s + l.qty, 0);
        const bestLine = `#${best.id} — ${kizco.format(best.pricePerUnit)}/unit (${best.qty} unit, oleh <@${best.sellerId}>)`;
        return `**${it?.name || itemId}** \`${itemId}\` • total ${totalQty} unit tersedia\n↳ Terbaik: ${bestLine}`;
      });

      return interaction.reply({ embeds: [baseEmbed().setTitle(t(lang, 'trade.orderbook_title')).setDescription(rows.join('\n\n')).setFooter({ text: t(lang, 'trade.orderbook_footer') })] });
    }

    if (sub === 'buy') {
      const id = interaction.options.getInteger('id');
      const qty = interaction.options.getInteger('jumlah') || 1;
      const res = trade.buyListing(guildId, userId, id, qty);
      if (!res.ok) return interaction.reply({ embeds: [errorEmbed(res.error)], ephemeral: true });
      return interaction.reply({ embeds: [successEmbed(t(lang, 'market.buy_ok', { qty: res.qty, item: res.item.name, price: kizco.format(res.total) }))] });
    }

    if (sub === 'chart') {
      const itemId = interaction.options.getString('item').toLowerCase();
      return interaction.reply(renderItemChart(guildId, itemId));
    }
  },
};
