// ============================================================================
// COMMAND /welcome — kelola pesan welcome & goodbye (v4)
// - Gaya & warna welcome + goodbye SINKRON (diatur sekali, bukan satu-satu).
// - /welcome warna-border → tombol preset ATAU hex custom (/welcome warna-border hex:#ff0000).
// ============================================================================
const {
  SlashCommandBuilder, PermissionFlagsBits, ChannelType,
  ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, EmbedBuilder,
} = require('discord.js');
const { getGuildConfig, updateGuildConfig } = require('../../database/db');
const { successEmbed, errorEmbed, warnEmbed } = require('../../utils/embeds');
const { buildPreviewPayloads, buildCardStylePayload } = require('../../utils/welcomeMessage');
const { saveCustomBackground, removeCustomBackground, hasCustomBackground, decodeBackgroundBuffer, ACCENT_PRESETS } = require('../../utils/welcomeCard');
const { fetchExternal } = require('../../utils/httpClient');
const emojis = require('../../utils/emojis');
const config = require('../../config.json');

const MAX_BACKGROUND_BYTES = 20 * 1024 * 1024;
const IMAGE_EXT_RE = /\.(png|jpe?g|webp|gif|bmp)$/i;

function isImageAttachment(att) {
  if (att.contentType && att.contentType.startsWith('image/')) return true;
  return IMAGE_EXT_RE.test(att.name || '');
}

// Warna → titik + label + style button yang PALING sesuai.
// Discord hanya punya 4 style: Success(hijau), Danger(merah), Primary(biru), Secondary(abu).
// Hijau/Merah/Biru dipetakan ke style yang pas; sisanya Secondary + titik warna.
const COLOR_BUTTONS = [
  { key: 'green',  label: 'Hijau', style: ButtonStyle.Success },
  { key: 'red',    label: 'Merah', style: ButtonStyle.Danger },
  { key: 'blue',   label: 'Biru', style: ButtonStyle.Primary },
  { key: 'purple', label: 'Ungu', style: ButtonStyle.Secondary },
  { key: 'gold',   label: 'Emas', style: ButtonStyle.Secondary },
  { key: 'pink',   label: 'Pink', style: ButtonStyle.Secondary },
  { key: 'orange', label: 'Oranye', style: ButtonStyle.Secondary },
  { key: 'cyan',   label: 'Cyan', style: ButtonStyle.Primary },
  { key: 'white',  label: 'Putih', style: ButtonStyle.Secondary },
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('welcome')
    .setDescription('Kelola pesan welcome & goodbye server')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub => sub.setName('set-welcome').setDescription('Atur channel & pesan welcome')
      .addChannelOption(o => o.setName('channel').setDescription('Channel untuk pesan welcome').addChannelTypes(ChannelType.GuildText).setRequired(true))
      .addStringOption(o => o.setName('pesan').setDescription('Pesan custom. Variabel: {user} {username} {server} {membercount}')))
    .addSubcommand(sub => sub.setName('set-goodbye').setDescription('Atur channel & pesan goodbye')
      .addChannelOption(o => o.setName('channel').setDescription('Channel untuk pesan goodbye').addChannelTypes(ChannelType.GuildText).setRequired(true))
      .addStringOption(o => o.setName('pesan').setDescription('Pesan custom. Variabel: {username} {server} {membercount}')))
    .addSubcommand(sub => sub.setName('toggle-welcome').setDescription('Nyalakan/matikan pesan welcome'))
    .addSubcommand(sub => sub.setName('toggle-goodbye').setDescription('Nyalakan/matikan pesan goodbye'))
    .addSubcommand(sub => sub.setName('pilih-gaya').setDescription('Pilih gaya tampilan welcome & goodbye (sinkron: Embed / Kartu gambar)'))
    .addSubcommand(sub => sub.setName('warna-border').setDescription('Ubah warna border kartu (tombol preset atau hex custom)')
      .addStringOption(o => o.setName('hex').setDescription('Warna hex custom, contoh: #ff0000 (opsional)')))
    .addSubcommand(sub => sub.setName('reset-background').setDescription('Hapus background kustom Gaya 2, kembali ke background default'))
    .addSubcommand(sub => sub.setName('test-welcome').setDescription('Tes tampilan pesan welcome dengan akunmu sendiri'))
    .addSubcommand(sub => sub.setName('test-goodbye').setDescription('Tes tampilan pesan goodbye dengan akunmu sendiri')),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    const cfg = getGuildConfig(interaction.guild.id);

    if (sub === 'set-welcome') {
      const channel = interaction.options.getChannel('channel');
      const message = interaction.options.getString('pesan');
      updateGuildConfig(interaction.guild.id, { welcomeChannel: channel.id, welcomeMessage: message || null, welcomeEnabled: 1 });
      return interaction.reply({ embeds: [successEmbed(`Welcome message diatur ke ${channel}.\nVariabel: \`{user}\` \`{username}\` \`{server}\` \`{membercount}\`\n\nMau ganti tampilan? Pakai \`/welcome pilih-gaya\`.\nMau ganti warna border? Pakai \`/welcome warna-border\`.`)] });
    }

    if (sub === 'set-goodbye') {
      const channel = interaction.options.getChannel('channel');
      const message = interaction.options.getString('pesan');
      updateGuildConfig(interaction.guild.id, { goodbyeChannel: channel.id, goodbyeMessage: message || null, goodbyeEnabled: 1 });
      return interaction.reply({ embeds: [successEmbed(`Goodbye message diatur ke ${channel}.\nVariabel: \`{username}\` \`{server}\` \`{membercount}\`\n\nMau ganti tampilan? Pakai \`/welcome pilih-gaya\` (sinkron dengan welcome).`)] });
    }

    if (sub === 'toggle-welcome') {
      if (!cfg.welcomeChannel) return interaction.reply({ embeds: [errorEmbed('Atur channel welcome dulu dengan `/welcome set-welcome`.')], ephemeral: true });
      const newState = cfg.welcomeEnabled ? 0 : 1;
      updateGuildConfig(interaction.guild.id, { welcomeEnabled: newState });
      return interaction.reply({ embeds: [successEmbed(`Pesan welcome sekarang **${newState ? 'AKTIF' : 'NONAKTIF'}**.`)] });
    }

    if (sub === 'toggle-goodbye') {
      if (!cfg.goodbyeChannel) return interaction.reply({ embeds: [errorEmbed('Atur channel goodbye dulu dengan `/welcome set-goodbye`.')], ephemeral: true });
      const newState = cfg.goodbyeEnabled ? 0 : 1;
      updateGuildConfig(interaction.guild.id, { goodbyeEnabled: newState });
      return interaction.reply({ embeds: [successEmbed(`Pesan goodbye sekarang **${newState ? 'AKTIF' : 'NONAKTIF'}**.`)] });
    }

    if (sub === 'reset-background') {
      if (!hasCustomBackground(interaction.guild.id)) {
        return interaction.reply({ embeds: [errorEmbed('Server ini belum punya background kustom - sudah pakai background default.')], ephemeral: true });
      }
      removeCustomBackground(interaction.guild.id);
      return interaction.reply({ embeds: [successEmbed('Background kustom Gaya 2 dihapus. Kembali ke background default (gradient otomatis).')] });
    }

    // ===== PILIH WARNA BORDER (tombol preset atau hex custom, sinkron welcome & goodbye) =====
    if (sub === 'warna-border') {
      await interaction.deferReply();
      const customHex = interaction.options.getString('hex');

      // --- Hex custom langsung ---
      if (customHex) {
        const normalized = customHex.startsWith('#') ? customHex : `#${customHex}`;
        if (!/^#[0-9a-f]{6}$/i.test(normalized)) {
          return interaction.editReply({ embeds: [errorEmbed('Format hex tidak valid. Contoh: `#ff0000` atau `ff0000`.')] }).catch(() => {});
        }
        updateGuildConfig(interaction.guild.id, { welcomeColor: normalized, goodbyeColor: normalized });
        let previewFiles = [];
        try {
          const payload = await buildCardStylePayload(interaction.member, getGuildConfig(interaction.guild.id));
          previewFiles = payload.files;
        } catch {}
        return interaction.editReply({
          embeds: [successEmbed(`Warna border (welcome & goodbye) diubah ke **${normalized}** (hex custom).`)],
          files: previewFiles.length ? previewFiles : undefined,
        }).catch(() => {});
      }

      const current = cfg.welcomeColor || 'green';

      // Susun tombol: 3 per baris, style sesuai warna
      const rows = [];
      let row = new ActionRowBuilder();
      COLOR_BUTTONS.forEach((c, i) => {
        row.addComponents(
          new ButtonBuilder()
            .setCustomId(`wcolor_${c.key}`)
            .setLabel(`${emojis.get('dot_' + c.key)} ${c.label}`)
            .setStyle(c.key === current ? ButtonStyle.Primary : c.style),
        );
        if ((i + 1) % 3 === 0) { rows.push(row); row = new ActionRowBuilder(); }
      });
      if (row.components.length) rows.push(row);

      await interaction.editReply({
        embeds: [new EmbedBuilder()
          .setColor(ACCENT_PRESETS[current] || config.successColor)
          .setTitle('Warna Border Kartu (welcome & goodbye)')
          .setDescription(`Warna sekarang: **${current}**\nKlik tombol preset di bawah, atau pakai \`/welcome warna-border hex:#ff0000\` untuk warna custom.`)],
        components: rows,
      });
      const msg = await interaction.fetchReply();

      const picked = await msg.awaitMessageComponent({
        componentType: ComponentType.Button, time: 120000,
        filter: i => i.user.id === interaction.user.id && i.customId.startsWith('wcolor_'),
      }).catch(() => null);

      if (!picked) {
        return interaction.editReply({ embeds: [warnEmbed('Waktu habis, warna tidak diubah.')], components: [] }).catch(() => {});
      }

      const colorKey = picked.customId.replace('wcolor_', '');
      updateGuildConfig(interaction.guild.id, { welcomeColor: colorKey, goodbyeColor: colorKey });

      // Preview kartu dengan warna baru
      let previewFiles = [];
      try {
        const payload = await buildCardStylePayload(interaction.member, getGuildConfig(interaction.guild.id));
        previewFiles = payload.files;
      } catch {}

      return picked.update({
        embeds: [successEmbed(`Warna border (welcome & goodbye) diubah ke **${colorKey}** (${ACCENT_PRESETS[colorKey] || colorKey}).`)],
        components: [], files: previewFiles.length ? previewFiles : undefined, attachments: [],
      }).catch(() => {});
    }

    // ===== PILIH GAYA WELCOME =====
    if (sub === 'pilih-gaya') {
      await interaction.deferReply();

      const { embedPayload, cardPayload } = await buildPreviewPayloads(interaction.member);
      const embedExample = embedPayload.embeds[0].setTitle(`Contoh Gaya 1 (Embed Klasik) — ${embedPayload.embeds[0].data.title.replace('Selamat datang di ', '')}`);
      const cardExample = new EmbedBuilder()
        .setColor(config.successColor)
        .setTitle('Contoh Gaya 2 (Kartu Gambar)')
        .setDescription('Border warna custom + tanpa kotak. Background diganti lewat upload, warna lewat `/welcome warna-border`.')
        .setImage('attachment://welcome.png')
        .setFooter({ text: config.footer });

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('wlcstyle_embed').setLabel('Gaya 1 (Embed)').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('wlcstyle_card').setLabel('Gaya 2 (Kartu Gambar)').setStyle(ButtonStyle.Primary),
      );

      await interaction.editReply({
        content: `**Pilih gaya tampilan welcome & goodbye untuk ${interaction.guild.name} (sinkron):**\nGaya aktif: **${cfg.welcomeStyle === 'card' ? 'Gaya 2 (Kartu Gambar)' : 'Gaya 1 (Embed)'}**`,
        embeds: [embedExample, cardExample],
        files: cardPayload.files,
        components: [row],
      });
      const message = await interaction.fetchReply();

      const picked = await message.awaitMessageComponent({
        componentType: ComponentType.Button, time: 120000, filter: i => i.user.id === interaction.user.id,
      }).catch(() => null);

      if (!picked) {
        return interaction.editReply({ content: 'Waktu habis, gaya welcome tidak diubah.', components: [] }).catch(() => {});
      }

      if (picked.customId === 'wlcstyle_embed') {
        updateGuildConfig(interaction.guild.id, { welcomeStyle: 'embed' });
        return picked.update({ content: null, embeds: [successEmbed('Gaya welcome & goodbye diatur ke **Gaya 1 (Embed Klasik)**.')], files: [], components: [], attachments: [] });
      }

      updateGuildConfig(interaction.guild.id, { welcomeStyle: 'card' });
      const hasExisting = hasCustomBackground(interaction.guild.id);
      await picked.update({
        content: null,
        embeds: [warnEmbed(
          `Gaya welcome & goodbye diatur ke **Gaya 2 (Kartu Gambar)**.\n\n📎 **Kirim gambar background di channel ini sekarang** (mendukung resolusi tinggi).\nAtau ketik \`skip\` untuk ${hasExisting ? 'tetap pakai background yang sudah ada' : 'pakai background default'}.\n\nWaktu: 2 menit.`,
        )],
        files: [], components: [], attachments: [],
      });

      const collected = await interaction.channel.awaitMessages({
        filter: m => m.author.id === interaction.user.id && (m.attachments.size > 0 || /^(skip|lewati)$/i.test(m.content.trim())),
        max: 1, time: 120000, errors: [],
      }).catch(() => null);

      const answer = collected?.first();
      if (!answer) {
        return interaction.followUp({ embeds: [errorEmbed('Waktu habis, background dibiarkan seperti sebelumnya.')] }).catch(() => {});
      }
      if (/^(skip|lewati)$/i.test(answer.content.trim())) {
        return interaction.followUp({ embeds: [successEmbed(`Oke, tetap pakai background ${hasExisting ? 'kustom yang sudah ada' : 'default'}.`)] }).catch(() => {});
      }

      const attachment = answer.attachments.first();
      if (!isImageAttachment(attachment)) {
        return interaction.followUp({ embeds: [errorEmbed('File bukan gambar (PNG/JPG/WEBP/GIF). Background tidak diubah.')] }).catch(() => {});
      }
      if (attachment.size > MAX_BACKGROUND_BYTES) {
        return interaction.followUp({ embeds: [errorEmbed(`File terlalu besar (${(attachment.size / 1024 / 1024).toFixed(1)}MB). Maksimal ${MAX_BACKGROUND_BYTES / 1024 / 1024}MB.`)] }).catch(() => {});
      }

      try {
        const res = await fetchExternal(attachment.url, {}, 1);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const buffer = Buffer.from(await res.arrayBuffer());
        const { width, height } = await decodeBackgroundBuffer(buffer);
        saveCustomBackground(interaction.guild.id, buffer);
        const previewPayload = await buildCardStylePayload(interaction.member, getGuildConfig(interaction.guild.id));
        await interaction.followUp({
          embeds: [successEmbed(`Background disimpan (resolusi **${width}x${height}px**). Ini contohnya:`)],
          files: previewPayload.files,
        });
      } catch (err) {
        console.error('[welcome] Gagal proses background:', err.message);
        return interaction.followUp({ embeds: [errorEmbed('Gagal memproses gambar. Background tidak diubah.')] }).catch(() => {});
      }
      return;
    }

    // (pilih-gaya-goodbye dihapus — gaya & warna goodbye sekarang SINKRON dengan welcome)

    if (sub === 'test-welcome') {
      const event = require('../../events/guildMemberAdd');
      await interaction.reply({ embeds: [successEmbed('Mengirim contoh pesan welcome...')], ephemeral: true });
      return event.execute(interaction.member, client);
    }

    if (sub === 'test-goodbye') {
      const event = require('../../events/guildMemberRemove');
      await interaction.reply({ embeds: [successEmbed('Mengirim contoh pesan goodbye...')], ephemeral: true });
      return event.execute(interaction.member, client);
    }
  },
};
