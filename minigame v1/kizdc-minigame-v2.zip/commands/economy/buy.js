const { SlashCommandBuilder } = require('discord.js');
const { getShopItem, getEconomy, updateBalance, addInventoryItem } = require('../../database/db');
const econ = require('../../database/economyDb');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const kizco = require('../../utils/kizco');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('buy')
    .setDescription('Beli item dari toko server')
    .addStringOption(o => o.setName('id').setDescription('ID item yang ingin dibeli').setRequired(true))
    .addIntegerOption(o => o.setName('jumlah').setDescription('Jumlah yang ingin dibeli (default 1)').setMinValue(1)),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const itemId = interaction.options.getString('id').toLowerCase();
    const quantity = interaction.options.getInteger('jumlah') || 1;

    const item = getShopItem(interaction.guild.id, itemId);
    if (!item) return interaction.reply({ embeds: [errorEmbed(t(lang, 'buy.not_found'))], ephemeral: true });

    const totalPrice = item.price * quantity;
    const eco = getEconomy(interaction.guild.id, interaction.user.id);

    if (eco.balance < totalPrice) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'buy.no_funds', { need: kizco.format(totalPrice), have: kizco.format(eco.balance) }))], ephemeral: true });
    }

    updateBalance(interaction.guild.id, interaction.user.id, -totalPrice);
    addInventoryItem(interaction.guild.id, interaction.user.id, itemId, quantity);
    econ.recordTransaction(interaction.guild.id, { type: 'purchase', actorId: interaction.user.id, amount: -totalPrice, note: `Beli ${quantity}x ${item.name} (toko server)` });

    if (item.roleId) {
      const role = interaction.guild.roles.cache.get(item.roleId);
      if (role) await interaction.member.roles.add(role).catch(() => {});
    }

    return interaction.reply({ embeds: [successEmbed(t(lang, 'buy.ok', { qty: quantity, item: item.name, price: kizco.format(totalPrice) }))] });
  },
};
