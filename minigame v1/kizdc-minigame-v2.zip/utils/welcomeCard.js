// ============================================================================
// KARTU WELCOME & GOODBYE (GAYA 2) — v2 BERSIH TANPA KOTAK
// ----------------------------------------------------------------------------
// Perubahan utama:
//   - HILANGKAN "pills"/kotak-kotak di bawah (Member ke-N, Akun berumur X) →
//     diganti TEKS polos yang menyatu dengan background, lebih modern.
//   - FRAME/border kaku dihilangkan, ganti garis aksen halus di tepi.
//   - WARNA BORDER/AKSEN bisa custom per-server (lewat /welcome warna-border).
//   - Satu renderer dipakai untuk WELCOME (join) DAN GOODBYE (leave), beda teks
//     & warna default, biar konsisten & tidak ada duplikasi kode.
// ============================================================================
const fs = require('fs');
const path = require('path');
const { createCanvas, loadImage } = require('@napi-rs/canvas');
const { roundedRect, fitText, clippedText, drawImageCover, downloadImage } = require('./canvasUtils');
const { t } = require('./i18n');

const CARD_WIDTH = 1200;
const CARD_HEIGHT = 630;

const BACKGROUND_DIR = path.join(__dirname, '..', 'database', 'welcome-backgrounds');
function ensureBackgroundDir() {
  if (!fs.existsSync(BACKGROUND_DIR)) fs.mkdirSync(BACKGROUND_DIR, { recursive: true });
}
function backgroundPathFor(guildId) {
  return path.join(BACKGROUND_DIR, `${guildId}.bg`);
}
function hasCustomBackground(guildId) {
  return fs.existsSync(backgroundPathFor(guildId));
}
function saveCustomBackground(guildId, buffer) {
  ensureBackgroundDir();
  fs.writeFileSync(backgroundPathFor(guildId), buffer);
  return backgroundPathFor(guildId);
}
function removeCustomBackground(guildId) {
  const p = backgroundPathFor(guildId);
  if (fs.existsSync(p)) fs.unlinkSync(p);
}
async function decodeBackgroundBuffer(buffer) {
  const img = await loadImage(buffer);
  return { img, width: img.width, height: img.height };
}

// === PALETTE WARNA BORDER/AKSEN (dipakai /welcome warna-border) ===
const ACCENT_PRESETS = {
  green: '#57F287',
  red: '#ED4245',
  blue: '#5865F2',
  purple: '#9B59B6',
  gold: '#F5C244',
  pink: '#EB459E',
  orange: '#F77F00',
  cyan: '#00E5FF',
  white: '#FFFFFF',
};

function resolveAccent(colorKey) {
  if (!colorKey) return null;
  if (ACCENT_PRESETS[colorKey]) return ACCENT_PRESETS[colorKey];
  if (/^#[0-9a-f]{6}$/i.test(colorKey)) return colorKey;
  return null;
}

function drawDefaultBackground(ctx, accent) {
  const gradient = ctx.createLinearGradient(0, 0, CARD_WIDTH, CARD_HEIGHT);
  gradient.addColorStop(0, '#0A0F1E');
  gradient.addColorStop(0.55, '#111827');
  gradient.addColorStop(1, '#05070F');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, CARD_WIDTH, CARD_HEIGHT);

  ctx.globalAlpha = 0.16;
  ctx.fillStyle = accent;
  ctx.beginPath(); ctx.arc(160, 60, 260, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc(1080, 560, 300, 0, Math.PI * 2); ctx.fill();
  ctx.globalAlpha = 0.08;
  ctx.beginPath(); ctx.arc(950, 100, 180, 0, Math.PI * 2); ctx.fill();
  ctx.globalAlpha = 1;

  // taburan bintang halus
  ctx.fillStyle = 'rgba(255,255,255,0.35)';
  let seed = 7;
  const rand = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
  for (let i = 0; i < 70; i++) {
    const x = rand() * CARD_WIDTH, y = rand() * CARD_HEIGHT, r = rand() * 1.6 + 0.3;
    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
  }
}

/**
 * Render kartu welcome/goodbye (Gaya 2) jadi PNG buffer.
 * @param {object} opts
 * @param {string} opts.type — 'welcome' | 'goodbye'
 * @param {import('discord.js').GuildMember} opts.member
 * @param {import('discord.js').Guild} opts.guild
 * @param {string|null} opts.backgroundPath
 * @param {number} opts.memberCount
 * @param {string} opts.accent — warna border/aksen (hex atau key preset)
 * @param {string} opts.subtitle — teks kecil opsional di bawah nama (default: "di server X")
 */
async function renderWelcomeCard({ member, guild, backgroundPath, memberCount, accent, type = 'welcome', subtitle, language = 'id' }) {
  const color = resolveAccent(accent) || (type === 'goodbye' ? '#ED4245' : '#57F287');
  const canvas = createCanvas(CARD_WIDTH, CARD_HEIGHT);
  const ctx = canvas.getContext('2d');

  // ===== BACKGROUND =====
  let bgImg = null;
  if (backgroundPath && fs.existsSync(backgroundPath)) {
    try { bgImg = await loadImage(fs.readFileSync(backgroundPath)); } catch { bgImg = null; }
  }
  if (bgImg) {
    drawImageCover(ctx, bgImg, 0, 0, CARD_WIDTH, CARD_HEIGHT);
    const overlay = ctx.createLinearGradient(0, 0, 0, CARD_HEIGHT);
    overlay.addColorStop(0, 'rgba(3,6,14,0.35)');
    overlay.addColorStop(0.55, 'rgba(3,6,14,0.55)');
    overlay.addColorStop(1, 'rgba(3,6,14,0.88)');
    ctx.fillStyle = overlay;
    ctx.fillRect(0, 0, CARD_WIDTH, CARD_HEIGHT);
  } else {
    drawDefaultBackground(ctx, color);
  }

  // ===== BORDER WARNA (custom, halus — bukan kotak kaku) =====
  // Garis aksen tipis di sekeliling + strip warna di kiri, warna sesuai pilihan.
  ctx.strokeStyle = color;
  ctx.lineWidth = 2.5;
  ctx.globalAlpha = 0.55;
  roundedRect(ctx, 16, 16, CARD_WIDTH - 32, CARD_HEIGHT - 32, 26);
  ctx.stroke();
  ctx.globalAlpha = 1;

  // ===== GUILD ICON + NAMA (kiri atas, konteks server) =====
  try {
    const gIcon = await downloadImage(guild.iconURL({ extension: 'png', size: 128 }));
    ctx.save();
    ctx.beginPath(); ctx.arc(74, 74, 36, 0, Math.PI * 2); ctx.clip();
    drawImageCover(ctx, gIcon, 38, 38, 72, 72);
    ctx.restore();
    ctx.strokeStyle = color; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(74, 74, 37, 0, Math.PI * 2); ctx.stroke();
  } catch (_) {
    ctx.fillStyle = '#1E293B';
    ctx.beginPath(); ctx.arc(74, 74, 36, 0, Math.PI * 2); ctx.fill();
  }
  ctx.textAlign = 'left';
  ctx.font = '700 25px sans-serif';
  ctx.fillStyle = '#F8FAFC';
  ctx.fillText(clippedText(ctx, guild.name, 320), 124, 84);
  ctx.textAlign = 'center';

  // ===== AVATAR (tengah, glow ring warna aksen) =====
  const cx = CARD_WIDTH / 2;
  const avatarY = 230;
  const avatarR = 108;

  const glow = ctx.createRadialGradient(cx, avatarY, avatarR * 0.6, cx, avatarY, avatarR * 2.1);
  glow.addColorStop(0, `${color}66`);
  glow.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = glow;
  ctx.beginPath(); ctx.arc(cx, avatarY, avatarR * 2.1, 0, Math.PI * 2); ctx.fill();

  try {
    const avatar = await downloadImage(member.user.displayAvatarURL({ extension: 'png', size: 512 }));
    ctx.save();
    ctx.beginPath(); ctx.arc(cx, avatarY, avatarR, 0, Math.PI * 2); ctx.clip();
    drawImageCover(ctx, avatar, cx - avatarR, avatarY - avatarR, avatarR * 2, avatarR * 2);
    ctx.restore();
  } catch {
    ctx.fillStyle = '#1E293B';
    ctx.beginPath(); ctx.arc(cx, avatarY, avatarR, 0, Math.PI * 2); ctx.fill();
  }
  ctx.strokeStyle = color; ctx.lineWidth = 7;
  ctx.beginPath(); ctx.arc(cx, avatarY, avatarR + 4, 0, Math.PI * 2); ctx.stroke();

  // ===== TEKS =====
  const displayName = member.displayName || member.user.globalName || member.user.username;
  ctx.textAlign = 'center';

  const kicker = t(language, type === 'goodbye' ? 'welcome.leave_kicker' : 'welcome.join_kicker');
  ctx.fillStyle = 'rgba(226,232,240,0.85)';
  ctx.font = '700 22px sans-serif';
  ctx.fillText(kicker, cx, 400);

  const nameSize = fitText(ctx, displayName, CARD_WIDTH - 160, 62, 800, 28);
  ctx.font = `800 ${nameSize}px sans-serif`;
  ctx.fillStyle = '#F8FAFC';
  ctx.shadowColor = 'rgba(0,0,0,0.6)'; ctx.shadowBlur = 18;
  ctx.fillText(displayName, cx, 460);
  ctx.shadowBlur = 0;

  ctx.font = '500 26px sans-serif';
  ctx.fillStyle = '#CBD5E1';
  const sub = subtitle || t(language, type === 'goodbye' ? 'welcome.leave_sub' : 'welcome.join_sub', { server: guild.name });
  ctx.fillText(clippedText(ctx, sub, CARD_WIDTH - 160), cx, 500);

  // ===== FOOTER TEKS POLOS (bukan kotak/pills) =====
  // Garis pemisah halus
  ctx.strokeStyle = 'rgba(255,255,255,0.14)'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(120, 545); ctx.lineTo(CARD_WIDTH - 120, 545); ctx.stroke();

  ctx.font = '600 21px sans-serif';
  ctx.fillStyle = color;
  const footerText = t(language, type === 'goodbye' ? 'welcome.remaining_n' : 'welcome.member_n', { n: memberCount.toLocaleString('id-ID') });

  // teks kiri + kanan (info tambahan) sebagai TEKS POLOS
  ctx.textAlign = 'left';
  ctx.fillText(footerText, 120, 585);
  ctx.textAlign = 'right';
  ctx.fillStyle = '#94A3B8';
  const accountAgeDays = Math.floor((Date.now() - member.user.createdTimestamp) / 86400000);
  const joinDays = member.joinedTimestamp ? Math.floor((Date.now() - member.joinedTimestamp) / 86400000) : null;
  const rightInfo = joinDays != null
    ? t(language, 'welcome.account_join', { days: accountAgeDays.toLocaleString('id-ID'), join: joinDays.toLocaleString('id-ID') })
    : t(language, 'welcome.account_age', { days: accountAgeDays.toLocaleString('id-ID') });
  ctx.fillText(clippedText(ctx, rightInfo, 640), CARD_WIDTH - 120, 585);
  ctx.textAlign = 'center';

  return canvas.toBuffer('image/png');
}

module.exports = {
  renderWelcomeCard,
  saveCustomBackground,
  removeCustomBackground,
  hasCustomBackground,
  backgroundPathFor,
  decodeBackgroundBuffer,
  resolveAccent,
  ACCENT_PRESETS,
  CARD_WIDTH,
  CARD_HEIGHT,
};
