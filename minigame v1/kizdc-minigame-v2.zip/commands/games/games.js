const { SlashCommandBuilder } = require('discord.js');
const { errorEmbed } = require('../../utils/embeds');

// Command induk: mengelompokkan semua game jadi sub-command (/games <game>) supaya
// hemat slot command. Logika tiap game ada di file terpisah (subcommandOf: 'games').
const HANDLERS = {
  blackjack: require('./blackjack'),
  slots: require('./slots'),
  tictactoe: require('./tictactoe'),
  connectfour: require('./connectfour'),
  chess: require('./chess'),
  suit: require('./suit'),
  bomkata: require('./bomkata'),
  trivia: require('./trivia'),
  wordscramble: require('./wordscramble'),
  wouldurather: require('./wouldurather'),
  tebakgambar: require('./guess'),
  tebakpokemon: require('./apiGames'),
  tebakitempokemon: require('./apiGames'),
  tebakbendera: require('./apiGames'),
  tebakibukota: require('./apiGames'),
  tebakanime: require('./apiGames'),
  tebakkarakter: require('./apiGames'),
  tebakrasanjing: require('./apiGames'),
  tebakraskucing: require('./apiGames'),
  'benar-salah': require('./apiGames'),
  werewolf: require('./werewolf'),
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('games')
    .setDescription('Kumpulan game seru')
    .addSubcommand(s => s.setName('blackjack').setDescription('Main blackjack melawan bot, pakai cash')
      .addIntegerOption(o => o.setName('taruhan').setDescription('Jumlah cash yang dipertaruhkan').setRequired(true).setMinValue(10)))
    .addSubcommand(s => s.setName('slots').setDescription('Main mesin slot pakai cash')
      .addIntegerOption(o => o.setName('taruhan').setDescription('Jumlah cash yang dipertaruhkan').setRequired(true).setMinValue(10)))
    .addSubcommand(s => s.setName('tictactoe').setDescription('Tic-Tac-Toe — lawan member lain atau lawan AI')
      .addUserOption(o => o.setName('lawan').setDescription('Member yang diajak main (kosongkan buat lawan AI)')))
    .addSubcommand(s => s.setName('connectfour').setDescription('Connect Four — lawan member lain atau lawan AI')
      .addUserOption(o => o.setName('lawan').setDescription('Member yang diajak main (kosongkan buat lawan AI)')))
    .addSubcommand(s => s.setName('chess').setDescription('Catur — lawan member lain atau lawan AI')
      .addUserOption(o => o.setName('lawan').setDescription('Member yang diajak main (kosongkan buat lawan AI)')))
    .addSubcommand(s => s.setName('suit').setDescription('Batu-Gunting-Kertas — duel first-to-3, lawan member lain atau lawan AI')
      .addUserOption(o => o.setName('lawan').setDescription('Member yang diajak main (kosongkan buat lawan AI)')))
    .addSubcommand(s => s.setName('bomkata').setDescription('Bom Kata - party game multiplayer: gantian cari kata sebelum bomnya meledak!'))
    .addSubcommand(s => s.setName('trivia').setDescription('Jawab pertanyaan trivia acak'))
    .addSubcommand(s => s.setName('wordscramble').setDescription('Tebak kata acak dari huruf yang diacak'))
    .addSubcommand(s => s.setName('wouldurather').setDescription('Would You Rather - voting rame-rame'))
    .addSubcommand(s => s.setName('tebakgambar').setDescription('Tebak rebus dari gambar asli via API'))
    .addSubcommand(s => s.setName('tebakpokemon').setDescription('Tebak Pokémon dari official artwork PokéAPI'))
    .addSubcommand(s => s.setName('tebakitempokemon').setDescription('Tebak item dari gambar PokéAPI'))
    .addSubcommand(s => s.setName('tebakbendera').setDescription('Tebak negara dari gambar bendera API'))
    .addSubcommand(s => s.setName('tebakibukota').setDescription('Tebak ibu kota negara acak'))
    .addSubcommand(s => s.setName('tebakanime').setDescription('Tebak anime dari poster Kitsu API'))
    .addSubcommand(s => s.setName('tebakkarakter').setDescription('Tebak karakter anime dari gambar Kitsu'))
    .addSubcommand(s => s.setName('tebakrasanjing').setDescription('Tebak ras anjing dari foto API'))
    .addSubcommand(s => s.setName('tebakraskucing').setDescription('Tebak ras kucing dari foto TheCatAPI'))
    .addSubcommand(s => s.setName('benar-salah').setDescription('Trivia benar atau salah dari OpenTDB'))
    .addSubcommand(s => s.setName('werewolf').setDescription('Buat arena Werewolf privat untuk 4–8 pemain')
      .addIntegerOption(o => o.setName('durasi').setDescription('Durasi setiap fase dalam detik (default 60)').setMinValue(30).setMaxValue(180))),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    const handler = HANDLERS[sub];
    if (!handler?.execute) {
      return interaction.reply({ embeds: [errorEmbed('Game tidak ditemukan.')], ephemeral: true });
    }
    return handler.execute(interaction, client);
  },
};
