const { fetchExternal } = require('./httpClient');

const cache = new Map();

function clone(value) {
  return value == null ? value : JSON.parse(JSON.stringify(value));
}

async function fetchJson(url, { ttl = 0, timeout = 10000, headers = {}, retries = 2 } = {}) {
  const key = String(url);
  const saved = cache.get(key);
  if (saved && saved.expiresAt > Date.now()) return clone(saved.value);

  const retryableStatuses = new Set([429, 502, 503, 504]);
  let lastError;
  for (let attempt = 0; attempt <= retries; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const response = await fetchExternal(key, { signal: controller.signal, headers }, 0);
      if (!response.ok) {
        const error = new Error(`API ${new URL(key).hostname} merespons HTTP ${response.status}`);
        error.retryable = retryableStatuses.has(response.status);
        if (!error.retryable || attempt === retries) throw error;
        lastError = error;
      } else {
        const value = await response.json();
        if (ttl > 0) cache.set(key, { value, expiresAt: Date.now() + ttl });
        return clone(value);
      }
    } catch (error) {
      lastError = error;
      if (attempt === retries || error.name === 'SyntaxError' || error.retryable === false) throw error;
    } finally {
      clearTimeout(timer);
    }
    await new Promise(resolve => setTimeout(resolve, 600 * (2 ** attempt)));
  }
  throw lastError || new Error('Request API gagal');
}

function randomItem(items) {
  if (!Array.isArray(items) || !items.length) return null;
  return items[Math.floor(Math.random() * items.length)];
}

function normalizeAnswer(value) {
  return String(value || '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function truncate(value, max = 1000) {
  const text = String(value ?? 'Tidak tersedia');
  return text.length <= max ? text : `${text.slice(0, max - 1)}…`;
}

module.exports = { fetchJson, randomItem, normalizeAnswer, truncate };
