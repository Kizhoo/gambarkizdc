const { SlashCommandBuilder } = require('discord.js');
const { getDeleted } = require('../../utils/snipeCache');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  subcommandOf: true,
  data: new SlashCommandBuilder().setName('snipe').setDescription('Lihat pesan terakhir yang dihapus di channel ini'),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const data = getDeleted(interaction.channel.id);
    if (!data) return interaction.reply({ embeds: [errorEmbed(t(lang, 'snipe.none'))], ephemeral: true });

    const embed = baseEmbed()
      .setAuthor({ name: data.author.tag, iconURL: data.author.displayAvatarURL() })
      .setDescription(data.content)
      .setFooter({ text: t(lang, 'util.deleted_ago', { s: Math.floor((Date.now() - data.timestamp) / 1000) }) });

    if (data.attachments.length > 0) embed.setImage(data.attachments[0]);

    return interaction.reply({ embeds: [embed] });
  },
};
