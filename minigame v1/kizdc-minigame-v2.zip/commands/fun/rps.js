const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

const CHOICES = ['batu', 'gunting', 'kertas'];
const CHOICE_KEY = { batu: 'rps.rock', gunting: 'rps.scissors', kertas: 'rps.paper' };
function decide(user, bot) {
  if (user === bot) return 'seri';
  if (
    (user === 'batu' && bot === 'gunting') ||
    (user === 'gunting' && bot === 'kertas') ||
    (user === 'kertas' && bot === 'batu')
  ) return 'menang';
  return 'kalah';
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rps')
    .setDescription('Main batu-gunting-kertas melawan bot')
    .addStringOption(o => o.setName('pilihan').setDescription('Pilihanmu').setRequired(true)
      .addChoices(
        { name: 'Batu', value: 'batu'},
        { name: 'Gunting', value: 'gunting'},
        { name: 'Kertas', value: 'kertas'},
      )),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const userChoice = interaction.options.getString('pilihan');
    const botChoice = CHOICES[Math.floor(Math.random() * CHOICES.length)];
    const result = decide(userChoice, botChoice);

    const resultText = t(lang, { menang: 'rps.win', kalah: 'rps.lose', seri: 'rps.draw' }[result]);

    const embed = baseEmbed()
      .setTitle(t(lang, 'rps.title'))
      .addFields(
        { name: t(lang, 'fun.your_choice'), value: t(lang, CHOICE_KEY[userChoice]), inline: true },
        { name: t(lang, 'fun.bot_choice'), value: t(lang, CHOICE_KEY[botChoice]), inline: true },
        { name: t(lang, 'fun.result'), value: resultText, inline: false },
      );
    return interaction.reply({ embeds: [embed] });
  },
};
