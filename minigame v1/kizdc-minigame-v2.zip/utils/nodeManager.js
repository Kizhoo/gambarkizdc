// ============================================================================
// MANAJEMEN NODE LAVALINK (musik)
// ----------------------------------------------------------------------------
// - Semua node tersimpan di config.json -> music.nodes (persisten, satu file).
// - add/remove HOT: langsung addNode/removeNode ke Shoukaku TANPA restart bot,
//   sekaligus disimpan ke config.json otomatis.
// - discoverOnlineNodes(): cari node Lavalink publik yang ONLINE dari internet
//   (beberapa sumber daftar komunitas), lalu bisa langsung di-hot-add.
// ============================================================================
const settings = require('./settings');
const { fetchExternal } = require('./httpClient');

// Sumber daftar node publik komunitas (dicoba berurutan). Masing-masing dinormalkan
// ke bentuk { name, url, auth, secure }. Makin banyak sumber makin besar peluang
// menemukan node yang benar-benar hidup.
const DISCOVERY_SOURCES = [
  'https://lavalink-list.ajieblogs.eu.org/SSL',
  'https://lavalink-list.ajieblogs.eu.org/v4/ssl',
  'https://lavalink-list.ajieblogs.eu.org/All',
  'https://lavalink-list.ajieblogs.eu.org/v4',
  'https://lavainfo.netlify.app/api/nodes/ssl',
  'https://lavainfo.netlify.app/api/nodes',
  'https://lavainfo-api.deno.dev/nodes/ssl',
  'https://lavainfo-api.deno.dev/nodes',
  'https://lavalink.darrennathanael.com/SSL/lavalink-ssl.json',
  'https://lavalink.darrennathanael.com/NoSSL/lavalink-nossl.json',
];

function getNodes() {
  return settings.get('music.nodes', []);
}

function nodeExists(name) {
  return getNodes().some(n => n.name === name);
}

// "Node aktif/prioritas" - dulu panel cuma punya tombol Hapus Node di detail node, tidak ada cara
// bilang "pakai node yang INI" (semua node yang ditambah cuma numpuk, dipilihnya otomatis sama
// Shoukaku pakai load-balancing sendiri). Sekarang disimpan namanya di config.json ->
// music.preferredNode, dan dipakai musicSetup.js sebagai nodeResolver custom (lihat musicSetup.js)
// supaya koneksi baru SELALU coba node ini dulu kalau dia hidup, baru fallback ke yang lain.
function getPreferredNode() {
  return settings.get('music.preferredNode', null);
}

function setPreferredNode(name) {
  settings.set('music.preferredNode', name);
  return name;
}

function clearPreferredNode() {
  settings.set('music.preferredNode', null);
}

// Dipanggil dari tombol panel "Pakai Node Ini": pastikan node itu tersambung (kalau belum,
// coba connect dulu), lalu jadikan dia node prioritas.
async function usePreferredNode(client, name) {
  const node = getNodes().find(n => n.name === name);
  if (!node) throw new Error(`Node "${name}" tidak ditemukan.`);
  const sk = client?.kazagumo?.shoukaku;
  // Cek keberadaannya di Shoukaku langsung (bukan nebak status koneksi lewat angka enum yang
  // gampang salah versi) - kalau sudah pernah ditambahkan ke Shoukaku, jangan tryConnect lagi
  // (addNode ulang bisa error "node already exists" tergantung versi Shoukaku).
  const alreadyAdded = sk && typeof sk.nodes?.has === 'function' && sk.nodes.has(name);
  let connected = alreadyAdded;
  if (!connected) connected = await tryConnect(client, node);
  setPreferredNode(name);
  return { node, connected: !!connected };
}

// Tambah node ke config + hot-add ke Shoukaku (tanpa restart).
function addNode(client, node) {
  if (!node.name || !node.url || !node.auth) throw new Error('Node butuh name, url, dan auth.');
  const nodes = getNodes();
  if (nodes.some(n => n.name === node.name)) throw new Error(`Node "${node.name}" sudah ada.`);

  const clean = { name: node.name, url: node.url, auth: node.auth, secure: node.secure !== false };
  nodes.push(clean);
  settings.set('music.nodes', nodes);

  if (client?.kazagumo?.shoukaku) {
    try { client.kazagumo.shoukaku.addNode(clean); } catch (e) {
      console.error('[nodeManager] Gagal hot-add node:', e.message);
    }
  }
  return clean;
}

// Hapus node dari config + hot-remove dari Shoukaku.
function removeNode(client, name) {
  const nodes = getNodes();
  const idx = nodes.findIndex(n => n.name === name);
  if (idx === -1) throw new Error(`Node "${name}" tidak ditemukan.`);
  nodes.splice(idx, 1);
  settings.set('music.nodes', nodes);
  if (settings.get('music.preferredNode') === name) settings.set('music.preferredNode', null);

  if (client?.kazagumo?.shoukaku) {
    try { client.kazagumo.shoukaku.removeNode(name); }
    catch (e) {
      // "The node name you specified doesn't exist" itu BUKAN kegagalan beneran - biasanya
      // artinya Shoukaku sendiri sudah nge-drop node ini duluan (mis. abis kehabisan
      // reconnectTries pas node itu mati berkali-kali) sebelum kita sempat hapus manual. Hasil
      // akhirnya tetap sama (node hilang dari Shoukaku), jadi ini race yang aman, tidak perlu
      // di-log sebagai error yang bikin khawatir/nyampah log.
      if (!/doesn't exist/i.test(e.message)) console.error('[nodeManager] Gagal hot-remove node:', e.message);
    }
  }
  return true;
}

function normalizeNode(raw, index = 0) {
  // Format ajieblogs: { host, port, password, secure, identifier }
  const host = raw.host || raw.url || raw.address;
  const port = raw.port || (raw.secure ? 443 : 80);
  if (!host) return null;
  const secure = raw.secure === true || String(port) === '443';
  const url = host.includes(':') ? host : `${host}:${port}`;
  return {
    name: raw.identifier || raw.name || `discovered-${host.split('.')[0]}-${index}`,
    url,
    auth: raw.password || raw.auth || 'youshallnotpass',
    secure,
  };
}

// Ambil daftar node publik online dari internet, digabung dari SEMUA sumber (dedup by url).
async function discoverOnlineNodes(limit = 15) {
  const seen = new Set();
  const merged = [];
  let usedSources = [];
  for (const src of DISCOVERY_SOURCES) {
    try {
      const res = await fetchExternal(src, {}, 1);
      if (!res || !res.ok) continue;
      const data = await res.json();
      const arr = Array.isArray(data) ? data : (data.nodes || []);
      let added = 0;
      arr.forEach((raw, i) => {
        const n = normalizeNode(raw, i);
        if (!n || seen.has(n.url)) return;
        // hormati flag online kalau ada
        if (raw.online === false || raw.isConnected === false) return;
        seen.add(n.url);
        merged.push(n);
        added++;
      });
      if (added) usedSources.push(src.replace('https://', ''));
    } catch (e) {
      console.warn(`[nodeManager] Sumber discovery gagal (${src}): ${e.message}`);
    }
    if (merged.length >= limit * 2) break;
  }
  return { source: usedSources.join(', ') || null, nodes: merged.slice(0, limit) };
}

// Probe cepat: node hidup kalau endpoint /version merespons (HTTP), tanpa perlu WS.
async function probeNode(node, timeoutMs = 4000) {
  const scheme = node.secure ? 'https' : 'http';
  const url = `${scheme}://${node.url}/version`;
  try {
    const controller = new AbortController();
    const t = setTimeout(() => controller.abort(), timeoutMs);
    const res = await fetchExternal(url, { signal: controller.signal, headers: { Authorization: node.auth } }, 0);
    clearTimeout(t);
    return !!res && res.status < 500;
  } catch {
    return false;
  }
}

// Coba connect satu node ke Shoukaku, resolve true kalau 'ready' dalam timeout.
function tryConnect(client, node, timeoutMs = 12000) {
  return new Promise((resolve) => {
    const sk = client.kazagumo?.shoukaku;
    if (!sk) return resolve(false);
    const t = setTimeout(() => { cleanup(); resolve(false); }, timeoutMs);
    function cleanup() { clearTimeout(t); sk.off('ready', onReady); sk.off('error', onErr); }
    function onReady(name) { if (name === node.name) { cleanup(); resolve(true); } }
    function onErr(name) { if (name === node.name) { cleanup(); resolve(false); } }
    sk.on('ready', onReady); sk.on('error', onErr);
    try { sk.addNode({ name: node.name, url: node.url, auth: node.auth, secure: node.secure }); }
    catch { cleanup(); resolve(false); }
  });
}

// Coba konek 1 node, dan kalau berhasil BENERAN simpan ke config.json (bukan cuma hot-add
// sementara ke Shoukaku doang seperti tryConnect() sendiri). Dipakai bareng oleh
// autoDiscoverAndConnect (pilih otomatis) dan tombol "pilih node ini" di panel (pilih manual).
async function connectAndSave(client, node) {
  const ok = await tryConnect(client, node);
  if (ok) {
    const list = getNodes();
    if (!list.some(n => n.name === node.name)) { list.push(node); settings.set('music.nodes', list); }
    return true;
  }
  try { client.kazagumo.shoukaku.removeNode(node.name); } catch {}
  return false;
}

// Discovery penuh + auto-connect: cari online, PROBE dulu (buang yang mati seperti
// node ECONNREFUSED), lalu coba connect yang hidup sampai ada yang berhasil, dan
// simpan yang berhasil ke config.json.
async function autoDiscoverAndConnect(client, maxTry = 8) {
  const { source, nodes } = await discoverOnlineNodes(20);
  if (!nodes.length) return { connected: null, tried: 0, source };

  const candidates = nodes.filter(n => !nodeExists(n.name));
  // Probe paralel: node yang lolos probe didahulukan.
  const probes = await Promise.all(candidates.map(async n => ({ n, alive: await probeNode(n) })));
  const ordered = [...probes.filter(p => p.alive), ...probes.filter(p => !p.alive)].map(p => p.n);

  let tried = 0;
  for (const node of ordered) {
    tried++;
    if (await connectAndSave(client, node)) return { connected: node, tried, source };
    if (tried >= maxTry) break;
  }
  return { connected: null, tried, source };
}

module.exports = {
  getNodes, nodeExists, addNode, removeNode, discoverOnlineNodes, autoDiscoverAndConnect, tryConnect, connectAndSave, probeNode,
  getPreferredNode, setPreferredNode, clearPreferredNode, usePreferredNode,
};
