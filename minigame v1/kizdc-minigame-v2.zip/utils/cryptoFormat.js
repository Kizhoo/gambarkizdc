const { baseEmbed } = require('./embeds');
const { formatPrice } = require('./cryptoApi');
const settings = require('./settings');

function disclaimer() {
  return settings.get('crypto.disclaimer', 'Bukan saran finansial. Selalu riset sendiri (DYOR) sebelum ambil keputusan trading.');
}

function priceEmbed(symbol, ticker) {
  const changePct = parseFloat(ticker.priceChangePercent);
  const arrow = changePct > 0 ? '▲' : changePct < 0 ? '▼' : '▬';
  return baseEmbed()
    .setTitle(`${symbol} — ${formatPrice(ticker.lastPrice)} USDT`)
    .addFields(
      { name: 'Perubahan 24 jam', value: `${arrow} ${changePct.toFixed(2)}%`, inline: true },
      { name: 'Tertinggi 24 jam', value: formatPrice(ticker.highPrice), inline: true },
      { name: 'Terendah 24 jam', value: formatPrice(ticker.lowPrice), inline: true },
      { name: 'Volume 24 jam', value: `${formatPrice(ticker.volume)} ${symbol.replace('USDT', '')}`, inline: true },
      { name: 'Volume (quote)', value: `${formatPrice(ticker.quoteVolume)} USDT`, inline: true },
    )
    .setFooter({ text: `Data real-time dari Binance • ${disclaimer()}` });
}

const ZONE_LABEL = { overbought: 'Overbought (jenuh beli)', oversold: 'Oversold (jenuh jual)', neutral: 'Netral' };
const TREND_LABEL = { bullish: 'Bullish (EMA cepat di atas EMA lambat)', bearish: 'Bearish (EMA cepat di bawah EMA lambat)', unknown: 'Belum cukup data' };

function signalEmbed(symbol, indicators, interval) {
  return baseEmbed()
    .setTitle(`Indikator Teknikal ${symbol} (timeframe ${interval})`)
    .setDescription(`Harga terakhir: **${formatPrice(indicators.lastPrice)} USDT** (${indicators.priceChangePctVsFirst >= 0 ? '+' : ''}${indicators.priceChangePctVsFirst}% dari awal periode yang dianalisis)`)
    .addFields(
      { name: `RSI (${indicators.rsiPeriod})`, value: `${indicators.rsi ?? '-'} — ${ZONE_LABEL[indicators.rsiZone] || indicators.rsiZone}`, inline: false },
      { name: `EMA${indicators.emaFastPeriod} vs EMA${indicators.emaSlowPeriod}`, value: `${formatPrice(indicators.emaFast)} vs ${formatPrice(indicators.emaSlow)} — ${TREND_LABEL[indicators.emaTrend] || indicators.emaTrend}`, inline: false },
    )
    .setFooter({ text: `Pembacaan indikator otomatis, bukan sinyal beli/jual. ${disclaimer()}` });
}

function autoSignalAlertEmbed(symbol, indicators, interval, previousState) {
  return baseEmbed()
    .setTitle(`Perubahan Kondisi Teknikal: ${symbol}`)
    .setDescription(`Kondisi indikator berubah dari \`${previousState || 'belum ada data'}\` menjadi \`${indicators.state}\` (timeframe ${interval}).`)
    .addFields(
      { name: 'Harga saat ini', value: `${formatPrice(indicators.lastPrice)} USDT`, inline: true },
      { name: 'RSI', value: `${indicators.rsi ?? '-'} (${ZONE_LABEL[indicators.rsiZone] || indicators.rsiZone})`, inline: true },
      { name: 'Tren EMA', value: TREND_LABEL[indicators.emaTrend] || indicators.emaTrend, inline: true },
    )
    .setFooter({ text: `Notifikasi otomatis berbasis indikator, bukan saran beli/jual. ${disclaimer()}` });
}

function signalBaselineEmbed(symbol, indicators, interval) {
  return baseEmbed()
    .setTitle(`Mulai Memantau: ${symbol}`)
    .setDescription(`Kondisi awal (timeframe ${interval}): \`${indicators.state}\`. Notifikasi berikutnya cuma dikirim kalau kondisi ini BERUBAH (misal netral jadi overbought, atau EMA golden/death cross) - jadi kalau pasarnya lagi anteng, wajar belum ada notif baru untuk sementara.`)
    .addFields(
      { name: 'Harga saat ini', value: `${formatPrice(indicators.lastPrice)} USDT`, inline: true },
      { name: 'RSI', value: `${indicators.rsi ?? '-'} (${ZONE_LABEL[indicators.rsiZone] || indicators.rsiZone})`, inline: true },
      { name: 'Tren EMA', value: TREND_LABEL[indicators.emaTrend] || indicators.emaTrend, inline: true },
    )
    .setFooter({ text: `Cek kondisi kapan saja lewat /crypto signal. ${disclaimer()}` });
}

module.exports = { priceEmbed, signalEmbed, autoSignalAlertEmbed, signalBaselineEmbed, disclaimer };
