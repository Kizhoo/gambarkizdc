const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');
const { formatDuration } = require('../../utils/musicFormat');

module.exports = {
  data: new SlashCommandBuilder().setName('queue').setDescription('Lihat antrian musik saat ini'),
  async execute(interaction, client) {
    const lang = guildLang(interaction);
    const player = client.kazagumo.players.get(interaction.guild.id);
    if (!player) return interaction.reply({ embeds: [errorEmbed(t(lang, 'queue.none'))], ephemeral: true });

    const current = player.queue.current;
    const upcoming = player.queue.slice(0, 10);

    const lines = [];
    if (current) lines.push(t(lang, 'queue.now', { title: current.title, dur: formatDuration(current.length) }));
    upcoming.forEach((track, i) => lines.push(`${i + 1}. **${track.title}** \`${formatDuration(track.length)}\``));

    if (lines.length === 0) lines.push(t(lang, 'queue.empty'));

    const embed = baseEmbed()
      .setTitle(t(lang, 'queue.title'))
      .setDescription(lines.join('\n'))
      .setFooter({ text: t(lang, 'queue.footer', { n: player.queue.length, vol: player.volume }) });

    return interaction.reply({ embeds: [embed] });
  },
};
