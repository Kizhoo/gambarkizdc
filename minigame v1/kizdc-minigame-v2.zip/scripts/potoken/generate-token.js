'use strict';

// Proses TERPISAH khusus buat generate PO Token (dijalankan sebagai child process
// oleh utils/poTokenScheduler.js, dengan --max-old-space-size yang lebih besar).
//
// Alasan dipisah: kalau proses ini kehabisan memori, V8 langsung abort proses
// (fatal error, BUKAN exception biasa yang bisa di-catch try/catch). Kalau ini
// jalan nyatu di proses utama bot, satu error OOM di sini bisa ikut menjatuhkan
// seluruh bot. Dengan dipisah, yang mati cuma proses child ini — bot utama
// tetap hidup dan poTokenScheduler.js bisa retry beneran di siklus berikutnya.

const fs = require('fs');
const { ProxyAgent, setGlobalDispatcher } = require('undici');

// PENTING: fetch bawaan Node (dipakai jsdom di dalam youtube-po-token-generator) TIDAK
// otomatis membaca HTTPS_PROXY/HTTP_PROXY dari env — sudah terbukti lewat percobaan di
// GitHub Actions (IP yang kepakai tetap IP asli walau HTTPS_PROXY di-set). Makanya proxy
// di sini dipasang eksplisit lewat undici ProxyAgent SEBELUM youtube-po-token-generator
// di-require, supaya semua request (termasuk yang dibuat jsdom di dalamnya) beneran lewat
// proxy itu, bukan cuma env var yang diabaikan.
if (process.env.PROXY_URL) {
  setGlobalDispatcher(new ProxyAgent(process.env.PROXY_URL));
}

const { generate } = require('youtube-po-token-generator');

const outFile = process.argv[2];

if (!outFile) {
  console.error('Usage: node generate-token.js <output-file>');
  process.exit(1);
}

(async () => {
  try {
    const { poToken, visitorData } = await generate();
    fs.writeFileSync(outFile, JSON.stringify({ poToken, visitorData }));
    process.exit(0);
  } catch (err) {
    process.stderr.write(String(err && err.stack ? err.stack : err));
    process.exit(1);
  }
})();
