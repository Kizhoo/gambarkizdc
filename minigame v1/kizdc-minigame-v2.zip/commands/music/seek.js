const { SlashCommandBuilder } = require('discord.js');
const { getValidPlayer, safePlayerAction } = require('../../utils/musicGuard');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('seek')
    .setDescription('Lompat ke detik tertentu di lagu yang sedang diputar')
    .addIntegerOption(o => o.setName('detik').setDescription('Posisi dalam detik dari awal lagu').setRequired(true).setMinValue(0)),
  async execute(interaction, client) {
    const lang = guildLang(interaction);
    const player = await getValidPlayer(interaction, client);
    if (!player) return;

    const track = player.queue.current;
    if (!track) return interaction.reply({ embeds: [errorEmbed(t(lang, 'music.nothing_playing'))], ephemeral: true });

    const seconds = interaction.options.getInteger('detik');
    const ms = seconds * 1000;

    if (track.length && ms > track.length) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'music.track_length', { d: Math.floor(track.length / 1000) }))], ephemeral: true });
    }

    if (typeof player.seek !== 'function') {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'music.seek_unavailable'))], ephemeral: true });
    }

    return safePlayerAction(interaction, () => player.seek(ms), { embeds: [successEmbed(t(lang, 'music.seeked', { s: seconds }))] });
  },
};
