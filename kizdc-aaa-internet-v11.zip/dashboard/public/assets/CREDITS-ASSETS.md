# KREDIT ASET PIHAK KETIGA (KizDC v11)

Semua aset di bawah adalah aset GRATIS dari OpenGameArt / GitHub yang diunduh,
dipotong, diskalakan, dan/atau direwarna untuk kebutuhan game KizDC.
Bentuk asli tersedia di sumber masing-masing. Terima kasih kepada semua senimannya.

## Hero (assets/hero/*.png)
- Basis: Universal LPC Spritesheet Character Generator — sanderfrenken dkk.
  https://github.com/sanderfrenken/Universal-LPC-Spritesheet-Character-Generator
  Lisensi: CC-BY-SA 3.0 / GPL 3.0 (sesuai komponen; lihat CREDITS.csv repo).
  Komposit via generator: body + celana + sepatu + armor plate/leather/kulit +
  rambut + topi penyihir/kerudung + senjata (arming sword, tongkat gnarled,
  belati, busur great) + quiver + jubah.

## Pet (assets/pets/*.png)
- Rubah, Anjing Shiba, Singa, Beruang, Rusa: "LPC animals 2022" (CC-BY 4.0)
  https://opengameart.org/content/lpc-bears-deer-lions-and-more — Matthew Kroehn dkk.
- Batu, Slime, Kelelawar, Golem, Golem Berlapis: "Enemy Galore I" (CC-BY 4.0)
  https://opengameart.org/content/enemy-galore-i — Justin Cyr (SketchyLab)
- Kucing: "Cat/Golden Cat" (CC-BY 4.0) https://opengameart.org/content/catgolden-cat
- Burung Hantu: "OWL" (CC-BY 3.0) https://opengameart.org/content/owl-0
- Katak: "Animated frog" (CC-BY-SA 3.0) https://opengameart.org/content/animated-frog
- Hell Hound (evolusi Bolt): "Hell Hound Character" (CC-BY 3.0)
  https://opengameart.org/content/hell-hound-character
- Kura-kura (evolusi Pebble): "Animated turtle" (CC0)
  https://opengameart.org/content/animated-turtle
- Naga (Nyx): "Dragon - Fully Animated" (CC0)
  https://opengameart.org/content/dragon-fully-animated
- Unicorn & Pegasus (Celeste): "LPC Horses rework" (CC-BY-SA 3.0)
  https://opengameart.org/content/lpc-horses-rework
- Phoenix (Solara): "Phoenix (reborn)" (CC0)
  https://opengameart.org/content/phoenix-reborn
- Rubah kecil alternatif: "Fox" (CC0) https://opengameart.org/content/fox-1
- Recolor (es/racun/bayang/listrik/cahaya) dilakukan via penggeseran hue +
  penerangan — turunan dari aset di atas dengan lisensi mengikuti sumbernya.

## VFX Skill (assets/fx/vfx_*.png)
- Ledakan api: "Fire spell explosion" (CC-BY 3.0)
  https://opengameart.org/content/fire-spell-explosion
- Es nova: "Ice nova" dari pak yang sama (CC-BY 3.0).
- Air: "Water magic effect" (CC-BY 3.0) https://opengameart.org/content/water-magic-effect
- Arcane: "Arcane magic effect" (CC-BY 3.0) https://opengameart.org/content/arcane-magic-effect
- Slash: "Weapon Slash Effect" (CC0) https://opengameart.org/content/weapon-slash-effect
- Lingkaran summon: "Teleporter circle" (CC-BY 3.0) https://opengameart.org/content/teleporter-circle
- Aura: "Auras" (CC0) https://opengameart.org/content/auras
- Magic pack (firelion/iceshield/lightningclaw/snake/tornado/spikes/tentakel):
  "Extended LPC Magic Pack" (CC-BY-SA 3.0) https://opengameart.org/content/extended-lpc-magic-pack
- Efek LPC umum: "LPC Items and game effects" (CC-BY 3.0)
  https://opengameart.org/content/lpc-items-and-game-effects

Catatan: game ini gratis. Aset CC-BY/CC-BY-SA tetap membawa atribusi di file ini;
modifikasi kami (potong/skala/rewarna) mengikuti lisensi asal masing-masing.
