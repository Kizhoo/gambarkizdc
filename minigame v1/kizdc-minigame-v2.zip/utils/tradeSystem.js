// ============================================================================
// SISTEM TRADING P2P — tawaran langsung + marketplace item RPG
// ----------------------------------------------------------------------------
// Dua mekanisme:
//   A) OFFER langsung: user A menawarkan KZC + item RPG ke user B (escrow).
//      B bisa accept (terima) / decline (tolak); A bisa cancel selama pending.
//   B) MARKETPLACE: jual item RPG dengan harga KZC; siapa pun bisa beli.
//
// Escrow = barang & KZC ditahan dulu saat offer dibuat (anti double-spend),
// dikembalikan otomatis kalau ditolak/dibatalkan.
// ============================================================================
const econ = require('../database/economyDb');
const { getEconomy, updateBalance } = require('../database/db');
const rdb = require('../database/webDb');
const shop = require('./shopManager');

// ---------------- OFFER ----------------
function createOffer(guildId, fromUserId, toUserId, kizcoAmount, itemIds = [], itemQtys = []) {
  if (fromUserId === toUserId) return { ok: false, error: 'Tidak bisa menawarkan trading ke diri sendiri.' };
  const amt = Math.max(0, Math.round(Number(kizcoAmount) || 0));
  const ids = (itemIds || []).map(String);
  const qtys = (itemQtys || []).map(n => Math.max(1, Math.round(Number(n) || 1)));

  const eco = getEconomy(guildId, fromUserId);
  if (eco.balance < amt) return { ok: false, error: `KZC kamu tidak cukup. Butuh ${amt}, punya ${eco.balance}.` };

  // Validasi & escrow item.
  for (let i = 0; i < ids.length; i++) {
    const item = shop.getItem(ids[i]);
    if (!item) return { ok: false, error: `Item \`${ids[i]}\` tidak dikenal.` };
    if (rdb.getItemQty(fromUserId, ids[i]) < qtys[i]) return { ok: false, error: `Kamu tidak punya cukup \`${item.name}\` (butuh ${qtys[i]}).` };
  }

  if (amt === 0 && ids.length === 0) return { ok: false, error: 'Tawaran harus berisi KZC atau item (atau keduanya).' };

  // Escrow.
  if (amt > 0) updateBalance(guildId, fromUserId, -amt);
  for (let i = 0; i < ids.length; i++) rdb.removeItem(fromUserId, ids[i], qtys[i]);

  const trade = econ.createTrade({ guildId, fromUserId, toUserId, kizco: amt, itemIds: ids, itemQtys: qtys });
  econ.recordTransaction(guildId, { type: 'trade', actorId: fromUserId, targetId: toUserId, amount: amt, note: `Escrow offer #${trade.id}` });
  return { ok: true, trade };
}

function acceptOffer(tradeId, byUserId) {
  const t = econ.getTrade(tradeId);
  if (!t || t.status !== 'pending') return { ok: false, error: 'Tawaran tidak ditemukan / sudah diproses.' };
  if (t.toUserId !== byUserId) return { ok: false, error: 'Hanya penerima yang bisa menerima tawaran ini.' };

  if (t.kizco > 0) updateBalance(t.guildId, t.toUserId, t.kizco);
  for (let i = 0; i < t.itemIds.length; i++) rdb.addItem(t.toUserId, t.itemIds[i], t.itemQtys[i]);
  econ.resolveTrade(tradeId, 'accepted');
  econ.recordTransaction(t.guildId, { type: 'trade', actorId: t.toUserId, targetId: t.fromUserId, amount: t.kizco, note: `Trade #${tradeId} diterima` });
  return { ok: true, trade: econ.getTrade(tradeId) };
}

function declineOffer(tradeId, byUserId) {
  return _refund(tradeId, byUserId, 'declined');
}
function cancelOffer(tradeId, byUserId) {
  return _refund(tradeId, byUserId, 'cancelled');
}
function _refund(tradeId, byUserId, status) {
  const t = econ.getTrade(tradeId);
  if (!t || t.status !== 'pending') return { ok: false, error: 'Tawaran tidak ditemukan / sudah diproses.' };
  const authorized = status === 'cancelled' ? t.fromUserId === byUserId : t.toUserId === byUserId;
  if (!authorized) return { ok: false, error: 'Kamu tidak berhak memproses tawaran ini.' };

  if (t.kizco > 0) updateBalance(t.guildId, t.fromUserId, t.kizco);
  for (let i = 0; i < t.itemIds.length; i++) rdb.addItem(t.fromUserId, t.itemIds[i], t.itemQtys[i]);
  econ.resolveTrade(tradeId, status);
  return { ok: true, trade: econ.getTrade(tradeId) };
}

// ---------------- MARKETPLACE ----------------
function createListing(guildId, sellerId, itemId, qty, pricePerUnit) {
  const item = shop.getItem(itemId);
  if (!item) return { ok: false, error: `Item \`${itemId}\` tidak dikenal.` };
  const q = Math.max(1, Math.round(Number(qty) || 1));
  const price = Math.max(1, Math.round(Number(pricePerUnit) || 0));
  if (rdb.getItemQty(sellerId, itemId) < q) return { ok: false, error: `Kamu tidak punya cukup \`${item.name}\` (butuh ${q}).` };
  rdb.removeItem(sellerId, itemId, q);
  const listing = econ.createListing({ guildId, sellerId, itemId, qty: q, pricePerUnit: price });
  return { ok: true, listing };
}

function buyListing(guildId, buyerId, listingId, qty = 1) {
  const l = econ.getListing(listingId);
  if (!l || l.status !== 'open' || l.guildId !== guildId) return { ok: false, error: 'Listing tidak ditemukan / sudah ditutup.' };
  if (l.sellerId === buyerId) return { ok: false, error: 'Kamu tidak bisa membeli listing milik sendiri.' };
  const q = Math.max(1, Math.min(qty, l.qty));
  const total = q * l.pricePerUnit;
  const eco = getEconomy(guildId, buyerId);
  if (eco.balance < total) return { ok: false, error: `KZC kamu tidak cukup. Butuh ${total}, punya ${eco.balance}.` };

  updateBalance(guildId, buyerId, -total);
  updateBalance(guildId, l.sellerId, total);
  rdb.addItem(buyerId, l.itemId, q);
  econ.removeListingQty(listingId, q);
  econ.recordItemPrice(guildId, l.itemId, l.pricePerUnit);
  econ.recordTransaction(guildId, { type: 'trade', actorId: buyerId, targetId: l.sellerId, amount: total, note: `Beli listing #${listingId} (${q}x ${l.itemId})` });
  return { ok: true, item: shop.getItem(l.itemId), qty: q, total };
}

function cancelListing(guildId, sellerId, listingId) {
  const l = econ.getListing(listingId);
  if (!l || l.status !== 'open' || l.guildId !== guildId) return { ok: false, error: 'Listing tidak ditemukan / sudah ditutup.' };
  if (l.sellerId !== sellerId) return { ok: false, error: 'Hanya penjual yang bisa membatalkan listing ini.' };
  rdb.addItem(sellerId, l.itemId, l.qty);
  econ.resolveListing(listingId, 'cancelled');
  return { ok: true, listing: econ.getListing(listingId) };
}

module.exports = {
  createOffer, acceptOffer, declineOffer, cancelOffer,
  createListing, buyListing, cancelListing,
};
