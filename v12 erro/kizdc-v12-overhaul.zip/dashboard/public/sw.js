/* ============================================================================
 * KizDC v12 — Service Worker (PWA-lite)
 * ----------------------------------------------------------------------------
 * STRATEGI AMAN:
 *  - Cache-first HANYA untuk aset statis game: /assets/*, /fonts/*,
 *    rpg.min.js, rpg.js, security-lock.js, manifest.
 *  - rpg.html TIDAK dicache: server menyuntik identitas user + nonce CSP
 *    per-request (Cache-Control: no-store) — mencache-nya = kebocoran sesi.
 *  - SEMUA permintaan lain (API /api/*, halaman dashboard, ws) diteruskan
 *    ke jaringan MURNI — ekonomi/trade tidak pernah disajikan dari cache.
 *  - Nama cache ber-stempel build: deploy baru = cache baru otomatis.
 * ========================================================================== */
const KZ_SW_CACHE = 'kz-rpg-2026.09.27-2';
const KZ_ALLOW = [
  /^\/assets\//,
  /^\/fonts\//,
  /^\/security-lock\.js/,
  /^\/rpg(\.min)?\.js/,
  /^\/manifest\.webmanifest/,
];
self.addEventListener('install', (e) => { self.skipWaiting(); });
self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== KZ_SW_CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});
self.addEventListener('fetch', (e) => {
  try {
    const url = new URL(e.request.url);
    if (e.request.method !== 'GET' || url.origin !== self.location.origin) return;
    if (!KZ_ALLOW.some((re) => re.test(url.pathname))) return; // API/dashboard: jaringan murni
    e.respondWith(
      caches.open(KZ_SW_CACHE).then((cache) =>
        cache.match(e.request).then((hit) => {
          const net = fetch(e.request).then((res) => {
            if (res && res.ok) cache.put(e.request, res.clone());
            return res;
          }).catch(() => hit);
          return hit || net;
        })
      )
    );
  } catch (_) {}
});
