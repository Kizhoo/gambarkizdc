// ============================================================================
// SISTEM BACKUP
// ----------------------------------------------------------------------------
// - createBackupArchive(): bikin arsip .tar.gz dari file penting (config.json +
//   database), disimpan ke folder ./backups.
// - sendBackupToOwner(client, reason): DM owner dengan file backup.
// - startAutoBackup(client): backup terjadwal tiap config.backup.intervalHours jam.
// - registerEmergencyBackup(client): saat proses mau MATI (SIGTERM/SIGINT/
//   uncaughtException), langsung kirim backup ke owner secepatnya.
//
// Semua diatur dari config.json bagian "backup".
// ============================================================================
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');
const { AttachmentBuilder } = require('discord.js');
const settings = require('./settings');

const ROOT = path.join(__dirname, '..');
const BACKUP_DIR = path.join(ROOT, 'backups');

function ensureDir() { if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true }); }

// ROTASI ARSIP (v6): simpan hanya N arsip terbaru. Tanpa ini, auto-backup tiap
// 12 jam + emergency backup di tiap stop/restart panel membuat folder backups/
// tumbuh tanpa batas -> disk quota hosting (2 GB) tercapai -> auto-suspend.
function pruneOldArchives() {
  try {
    const keep = Math.max(1, parseInt(settings.get('backup.keepArchives', 3), 10) || 3);
    const files = fs.readdirSync(BACKUP_DIR)
      .filter(f => f.startsWith('kizhoobot-backup-') && f.endsWith('.tar.gz'))
      .map(f => ({ f, t: fs.statSync(path.join(BACKUP_DIR, f)).mtimeMs }))
      .sort((a, b) => b.t - a.t);
    for (const old of files.slice(keep)) {
      fs.unlinkSync(path.join(BACKUP_DIR, old.f));
      console.log(`[backup] Rotasi: arsip lama dihapus (${old.f}) - keep ${keep}.`);
    }
  } catch (e) { console.warn('[backup] Rotasi arsip gagal:', e.message); }
}

function ts() {
  const d = new Date();
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

// Buat arsip tar.gz dari includeGlobs. Return path arsip (atau daftar file kalau tar gagal).
function createBackupArchive() {
  ensureDir();
  pruneOldArchives(); // v6: bersihkan arsip lama SEBELUM bikin yang baru
  const includes = settings.get('backup.includeGlobs', ['config.json', 'database/kizhoobot.sqlite']);
  const existing = includes.filter(f => fs.existsSync(path.join(ROOT, f)));
  // FIX BACKUP: hormati override lokasi DB lewat env KIZHOO_DB_PATH. Kalau DB dipindah keluar
  // dari path default, includeGlobs statis akan gagal menemukannya dan backup jadi kosong.
  const envDb = process.env.KIZHOO_DB_PATH ? path.resolve(process.env.KIZHOO_DB_PATH) : null;
  if (envDb && fs.existsSync(envDb) && !existing.some(f => path.resolve(ROOT, f) === envDb)) {
    existing.push(path.relative(ROOT, envDb));
    for (const ext of ['-wal', '-shm']) {
      if (fs.existsSync(envDb + ext)) existing.push(path.relative(ROOT, envDb + ext));
    }
  }
  // sertakan WAL/SHM sqlite kalau ada supaya konsisten
  for (const f of [...existing]) {
    for (const ext of ['-wal', '-shm']) {
      const wal = f + ext;
      if (fs.existsSync(path.join(ROOT, wal))) existing.push(wal);
    }
  }
  if (!existing.length) throw new Error('Tidak ada file untuk di-backup (cek backup.includeGlobs di config.json).');

  const archivePath = path.join(BACKUP_DIR, `kizhoobot-backup-${ts()}.tar.gz`);
  return new Promise((resolve) => {
    execFile('tar', ['-czf', archivePath, '-C', ROOT, ...existing], (err) => {
      if (err) {
        // Fallback: kembalikan daftar file mentah untuk dilampirkan satu-satu
        console.warn('[backup] tar gagal, fallback lampiran file mentah:', err.message);
        resolve({ archive: null, files: existing.map(f => path.join(ROOT, f)) });
      } else {
        resolve({ archive: archivePath, files: [archivePath] });
      }
    });
  });
}

async function sendBackupToOwner(client, reason = 'manual') {
  const ownerId = process.env.OWNER_ID;
  if (!ownerId) throw new Error('OWNER_ID belum diisi di .env.');
  const { archive, files } = await createBackupArchive();
  const owner = await client.users.fetch(ownerId);

  // FIX BACKUP: Discord membatasi ukuran lampiran (default 25MB untuk bot tanpa boost).
  // Kalau file backup lebih besar dari batas, owner.send() akan MELEMPAR error dan bikin
  // auto-backup gagal terus tanpa penjelasan. Cek ukuran dulu; kalau lewat batas, kirim
  // pesan peringatan yang jelas (backup tetap tersimpan di ./backups) alih-alih crash.
  const LIMIT = 25 * 1024 * 1024; // 25 MB
  const sized = files.map(f => ({ f, size: fs.existsSync(f) ? fs.statSync(f).size : 0 }));
  const tooBig = sized.filter(x => x.size > LIMIT);
  if (tooBig.length) {
    const human = n => `${(n / 1024 / 1024).toFixed(1)} MB`;
    await owner.send({
      content: `⚠️ Backup KizhooBot (${reason}) TIDAK bisa dikirim via DM: ukuran file melebihi batas Discord (25MB).\n`
        + tooBig.map(x => `• \`${path.basename(x.f)}\` = ${human(x.size)}`).join('\n')
        + `\n\nBackup tetap **tersimpan aman di server** pada folder \`./backups\`. Untuk file sebesar ini, ambil langsung dari host / panel, atau atur backup ke storage eksternal.`,
    }).catch(e => console.error('[backup] Gagal kirim peringatan ukuran:', e.message));
    return { archive, files, skippedDM: true };
  }

  const attachments = files.map(f => new AttachmentBuilder(f));
  await owner.send({
    content: `Backup KizhooBot (${reason})\nWaktu: ${new Date().toLocaleString('id-ID')}\n${archive ? 'Format: arsip .tar.gz' : 'Format: file mentah (tar tidak tersedia)'}`,
    files: attachments,
  });
  return { archive, files };
}

// Backup cepat & sinkron untuk keadaan darurat (proses mau mati). Tidak async-await
// panjang; kirim langsung lalu beri sedikit waktu event loop untuk flush.
let emergencyFired = false;
function registerEmergencyBackup(client) {
  const doEmergency = (label) => {
    if (emergencyFired) return;
    if (!settings.get('backup.emergencyOnShutdown', true)) return;
    emergencyFired = true;
    // DEBOUNCE (v6): stop/restart server di panel memicu sinyal ini; tanpa debounce,
    // deploy ulang berkali-kali = tumpukan arsip baru terus-menerus. Maks 1x / 6 jam.
    const DEBOUNCE_MS = 6 * 3600 * 1000;
    const marker = path.join(BACKUP_DIR, '.last-emergency');
    try {
      ensureDir();
      const last = fs.existsSync(marker) ? (parseInt(fs.readFileSync(marker, 'utf8'), 10) || 0) : 0;
      if (Date.now() - last < DEBOUNCE_MS) {
        console.log('[backup] Emergency backup dilewati (backup terakhir < 6 jam lalu) - anti penumpukan disk.');
        return;
      }
      fs.writeFileSync(marker, String(Date.now()));
    } catch (_) {}
    console.warn(`[backup] ${label} terdeteksi — mengirim emergency backup ke owner...`);
    sendBackupToOwner(client, `EMERGENCY (${label})`)
      .then(() => console.log('[backup] Emergency backup terkirim.'))
      .catch(e => console.error('[backup] Emergency backup gagal:', e.message))
      .finally(() => { setTimeout(() => process.exit(0), 3000); });
  };

  process.on('SIGTERM', () => doEmergency('SIGTERM (server dimatikan)'));
  process.on('SIGINT', () => doEmergency('SIGINT (Ctrl+C / restart)'));
  process.on('SIGHUP', () => doEmergency('SIGHUP'));
}

function startAutoBackup(client) {
  if (!settings.get('backup.enabled', true)) return;
  const hours = settings.get('backup.intervalHours', 12);
  const intervalMs = Math.max(1, hours) * 3600 * 1000;
  setInterval(() => {
    if (!settings.get('backup.enabled', true)) return;
    if (settings.get('backup.sendToOwnerDM', true)) {
      sendBackupToOwner(client, 'auto terjadwal').catch(e => console.error('[backup] Auto backup gagal:', e.message));
    } else {
      createBackupArchive().catch(e => console.error('[backup] Auto backup (lokal) gagal:', e.message));
    }
  }, intervalMs);
  console.log(`[backup] Auto-backup aktif tiap ${hours} jam.`);
}

module.exports = { createBackupArchive, sendBackupToOwner, registerEmergencyBackup, startAutoBackup, BACKUP_DIR };
