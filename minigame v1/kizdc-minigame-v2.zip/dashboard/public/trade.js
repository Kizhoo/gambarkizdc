// ============================================================================
// KIZCO EXCHANGE — frontend terminal perdagangan
// ----------------------------------------------------------------------------
// Candle chart digambar manual di canvas, order book + depth chart live,
// dan data aset yang sedang dipilih di-refresh setiap 1.5 detik supaya grafik
// bergerak seperti terminal trading profesional. Saham Bank Kizaria (BKZ)
// mendapat feed harga sintetis yang berubah tiap detik.
// ============================================================================
const $ = (id) => document.getElementById(id);

// Identitas user diambil dari session OAuth (cookie) via /api/me, bukan localStorage.
// Tidak ada lagi penyimpanan token/uid/watchlist di browser — semuanya di server/DB.
let TOKEN = '';
let MY_USER_ID = '';
let ws = null;
let guilds = [];
let guildId = '';
let marketItems = [];
let currentItem = null;
let currentSide = 'buy';
let currentType = 'limit';
let activeTab = 'portfolio';
let tf = '5m';
let candles = [];
let watchlist = [];
let watchOnly = false;
let tickCounter = 0;
let ticking = false;
let convKzcVal = 0;

const KIND_ICON = { forex: 'coin', crypto: 'gem', index: 'crystal', stock: 'bank' };
const TF_MS = { '1m': 60000, '5m': 300000, '15m': 900000, '30m': 1800000, '1h': 3600000, '4h': 14400000, '1d': 86400000, '1w': 604800000 };

function authHeaders() { return { 'Authorization': `Bearer ${TOKEN}`, 'Content-Type': 'application/json' }; }
function fmtFull(n) { return (Math.round(Number(n) || 0)).toLocaleString('id-ID'); }
function fmtCompact(n) {
  if (window.WebI18n && window.WebI18n.compact) return window.WebI18n.compact(n);
  const v = Number(n) || 0; const abs = Math.abs(v); const s = v < 0 ? '-' : '';
  if (abs >= 1e12) return s + (abs / 1e12).toFixed(2) + 'T';
  if (abs >= 1e9) return s + (abs / 1e9).toFixed(2) + 'M';
  if (abs >= 1e6) return s + (abs / 1e6).toFixed(2) + 'Jt';
  if (abs >= 1e3) return s + (abs / 1e3).toFixed(1) + 'K';
  return s + Math.round(abs);
}
function fmtPct(n) { const v = Number(n) || 0; return (v > 0 ? '+' : '') + v.toFixed(2) + '%'; }
function t(key, params) { return window.WebI18n ? window.WebI18n.t(window.WebI18n.currentLang(), key, params) : key; }
function setStatus(id, text, cls) { const el = $(id); el.textContent = text; el.className = 'status ' + (cls || ''); }
async function loadWatchlist() {
  if (!MY_USER_ID) return;
  try {
    const res = await fetch('/api/trade/watchlist', { headers: authHeaders() });
    const d = await res.json();
    if (res.ok && Array.isArray(d.items)) { watchlist = d.items; renderMarket(); }
  } catch {}
}
async function saveWatchlist(id) {
  if (!MY_USER_ID) return;
  try {
    const res = await fetch('/api/trade/watchlist/toggle', { method: 'POST', headers: authHeaders(), body: JSON.stringify({ itemId: id }) });
    const d = await res.json();
    if (res.ok && Array.isArray(d.items)) watchlist = d.items;
  } catch {}
}
function starIcon(on) {
  return '<svg viewBox="0 0 24 24" width="13" height="13" fill="' + (on ? 'var(--gold)' : 'none') + '" stroke="' + (on ? 'var(--gold)' : '#3a455e') + '" stroke-width="2" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
}
function mountIcon(parent, id, category, size) {
  if (!parent || !window.ItemIcons) return;
  const c = document.createElement('canvas');
  window.ItemIcons.draw(c, id, category, size);
  parent.appendChild(c);
  return c;
}
function iconCat(it) {
  if (it && it.kind) return KIND_ICON[it.kind] || 'coin';
  return (it && it.category) || 'consumable';
}
function iconCatOf(id) {
  const it = marketItems.find(i => i.id === id);
  return iconCat(it);
}
let lastPrice = null;
function flashPrice(el, chg) {
  el.classList.remove('flash-up', 'flash-down');
  void el.offsetWidth;
  el.classList.add(chg >= 0 ? 'flash-up' : 'flash-down');
}
function usdRate() {
  const k = marketItems.find(i => i.id === 'kzc_usd');
  if (!k || !k.price) return 0;
  return 1000 / k.price;
}
function renderUsdRate() {
  const el = $('usdRate');
  if (!el) return;
  const r = usdRate();
  el.innerHTML = r > 0 ? `1 KZC ≈ <b>$${r.toFixed(4)}</b>` : '';
  syncConverter();
}
// Konverter KZC → USD ikut di-refresh tiap tick (sebelumnya cuma update saat user mengetik,
// jadi angka "dolar" terlihat membeku padahal harga KZC/USD bergerak tiap detik di server).
function syncConverter() {
  const kzcEl = $('convKzc');
  const usdEl = $('convUsd');
  if (!kzcEl || !usdEl) return;
  const r = usdRate();
  usdEl.textContent = r > 0 ? '$' + (convKzcVal * r).toFixed(4) : '$0.0000';
}

// ---------- LOGIN (hanya via Discord; input token sudah dihapus dari UI publik) ----------
if ($('btnLogin')) {
  $('btnLogin').addEventListener('click', async () => {
    const token = ($('token') ? $('token').value : '').trim();
    if (!token) return setStatus('loginError', t('market.enter_token'), 'err');
    const res = await fetch('/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token }) });
    if (res.ok) {
      TOKEN = token; // hanya di memori, tidak disimpan di localStorage
      showApp();
    } else setStatus('loginError', t('market.wrong_token'), 'err');
  });
}

async function init() {
  // Selalu cek session Discord dulu (dapat userId asli), baru fallback ke token.
  // Identitas user sekarang murni dari session OAuth / api, tidak lagi dari localStorage.
  let me = null;
  for (let i = 0; i < 6; i++) {
    try { me = await (await fetch('/api/me')).json(); } catch {}
    if (me && me.userId) break;
    await new Promise(r => setTimeout(r, 400));
  }
  if (me && me.userId) { MY_USER_ID = me.userId; showApp(); return; }
  if (TOKEN) showApp();
}

function showApp() {
  $('login').classList.add('hidden');
  $('app').classList.remove('hidden');
  loadWatchlist(); loadGuilds(); connectWs(); startTicker();
}

// ---------- GUILDS ----------
async function loadGuilds() {
  const res = await fetch('/api/guilds', { headers: authHeaders() });
  guilds = await res.json();
  fillGuilds();
}
function fillGuilds() {
  $('guildSelect').innerHTML = '<option value="">' + t('ui.select_server') + '</option>' + guilds.map(g => `<option value="${g.id}">${g.name}</option>`).join('');
}
$('guildSelect').addEventListener('change', () => {
  guildId = $('guildSelect').value;
  if (guildId) { loadMarketList(); refreshPortfolio(); }
});

// ---------- MARKET ----------
async function loadMarketList() {
  if (!guildId) return;
  try {
    const res = await fetch(`/api/trade/items?guildId=${guildId}`, { headers: authHeaders() });
    const d = await res.json();
    marketItems = d.items || [];
    if (d.state) $('mktIdx').textContent = t('trade.idx', { n: Number(d.state.priceIndex).toFixed(1) });
    renderMarket();
    renderUsdRate();
    if (marketItems.length && !currentItem) selectItem(marketItems[0].id);
    else if (currentItem && !marketItems.some(i => i.id === currentItem)) selectItem(marketItems[0].id);
  } catch {}
}

function renderMarket() {
  const list = $('marketList');
  const q = ($('marketSearch').value || '').trim().toLowerCase();
  let items = watchOnly ? marketItems.filter(i => watchlist.includes(i.id)) : marketItems;
  if (q) items = items.filter(i => (i.name || '').toLowerCase().includes(q) || (i.ticker || '').toLowerCase().includes(q) || i.id.includes(q));
  list.innerHTML = items.map(it => {
    const watched = watchlist.includes(it.id);
    const chg = it.change24hPct || 0;
    const cls = chg >= 0 ? 'up' : 'down';
    const ticker = it.ticker ? `<span class="ticker-badge">${it.ticker}</span>` : '';
    return `<div class="market-item ${currentItem === it.id ? 'active' : ''}" data-id="${it.id}">
      <div class="sym"><span class="star" data-watch="${it.id}">${starIcon(watched)}</span><span class="item-ic" data-ic="${it.id}" data-cat="${iconCat(it)}"></span>${ticker}<span class="name">${escapeHtml(it.name)}</span></div>
      <div class="px num">${fmtCompact(it.price)}</div>
      <div class="chg num ${cls}">${fmtPct(chg)}</div>
    </div>`;
  }).join('');
  list.querySelectorAll('.item-ic').forEach(el => mountIcon(el, el.dataset.ic, el.dataset.cat, 26));
  list.querySelectorAll('.market-item').forEach(el => el.addEventListener('click', async (e) => {
    if (e.target.closest('.star')) {
      const id = e.target.closest('.star').dataset.watch;
      await saveWatchlist(id);
      renderMarket();
      return;
    }
    selectItem(el.dataset.id);
  }));
}
$('marketSearch').addEventListener('input', renderMarket);

// ---------- ITEM SELECT ----------
async function selectItem(id) {
  currentItem = id;
  renderMarket();
  updateOrderTypeUI();
  await refreshDetail(true);
}

// ---------- DETAIL (chart + book + price) ----------
async function refreshDetail(forceRender) {
  if (!guildId || !currentItem) return;
  try {
    const url = `/api/trade/${guildId}/item/${currentItem}?tf=${tf}`;
    const res = await fetch(url, { headers: authHeaders() });
    const d = await res.json();
    if (d.error) return;

    const it = d.item;
    const price = it.price;
    const stats = d.stats || {};
    const chg = stats.change24hPct || 0;

    $('assetName').textContent = it.name;
    const ticker = it.ticker || '';
    $('assetTicker').textContent = ticker;
    $('assetTicker').style.display = ticker ? 'inline-block' : 'none';
    window.ItemIcons.draw($('assetIcon'), currentItem, iconCatOf(currentItem), 44);
    $('assetPrice').textContent = fmtFull(price);
    $('assetPrice').className = 'asset-price num ' + (chg < 0 ? 'down' : 'up');
    if (lastPrice != null && price !== lastPrice) flashPrice($('assetPrice'), price - lastPrice);
    lastPrice = price;
    $('assetChange').textContent = fmtPct(chg);
    $('assetChange').className = 'asset-change num ' + (chg < 0 ? 'down' : 'up');
    $('assetStats').innerHTML =
      `<div class="stat"><span class="k">${t('trade.high24')}</span><span class="v">${fmtCompact(stats.high24h)}</span></div>` +
      `<div class="stat"><span class="k">${t('trade.low24')}</span><span class="v">${fmtCompact(stats.low24h)}</span></div>` +
      `<div class="stat"><span class="k">${t('trade.vol24')}</span><span class="v">${fmtCompact(stats.volume24h)}</span></div>`;

    candles = (d.candles || []).map(c => ({ t: c.t, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume || 0 }));
    lastAnalysis = d.analysis || null;
    renderBook(d.orderbook || d.book);
    renderCandles();
    if (forceRender || activeTab === 'fills') { window._fills = d.fills || []; if (activeTab === 'fills') renderBottom(); }
    updateOrderTotal();
  } catch {}
}

function renderBook(book) {
  const asks = (book?.asks || []).slice(0, 9).reverse();
  const bids = (book?.bids || []).slice(0, 9);
  const maxQty = Math.max(1, ...asks.map(a => a.qty), ...bids.map(b => b.qty));
  $('asks').innerHTML = asks.map(a => `<div class="book-row" data-price="${a.price}"><div class="depth ask" style="width:${(a.qty / maxQty) * 100}%"></div><span class="p ask num">${fmtCompact(a.price)}</span><span class="q num">${a.qty}</span></div>`).join('');
  $('bids').innerHTML = bids.map(b => `<div class="book-row" data-price="${b.price}"><div class="depth bid" style="width:${(b.qty / maxQty) * 100}%"></div><span class="p bid num">${fmtCompact(b.price)}</span><span class="q num">${b.qty}</span></div>`).join('');
  const bestAsk = asks[0]?.price, bestBid = bids[0]?.price;
  $('spread').textContent = bestBid && bestAsk ? t('trade.spread', { n: fmtCompact(bestAsk - bestBid) }) : t('trade.no_order_book');
  document.querySelectorAll('.book-row').forEach(el => el.addEventListener('click', () => { $('orderPrice').value = el.dataset.price; updateOrderTotal(); }));
  renderDepthChart(book);
}

function renderDepthChart(book) {
  try {
    const canvas = $('depthChart');
    const rect = canvas.getBoundingClientRect();
    const W = Math.floor(rect.width) || 100, H = Math.floor(rect.height) || 60;
    if (W <= 20 || H <= 20) return;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = W * dpr; canvas.height = H * dpr;
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#07090f'; ctx.fillRect(0, 0, W, H);
    const bids = (book?.bids || []).slice(0, 12).sort((a, b) => b.price - a.price);
    const asks = (book?.asks || []).slice(0, 12).sort((a, b) => a.price - b.price);
    if (!bids.length && !asks.length) return;
    let cb = 0, ca = 0; const cumBid = [], cumAsk = [];
    for (const x of bids) { cb += x.qty; cumBid.push(cb); }
    for (const x of asks) { ca += x.qty; cumAsk.push(ca); }
    const maxQty = Math.max(cb, ca, 1);
    const mid = W / 2;
    const y = q => H - 4 - (q / maxQty) * (H - 8);
    ctx.fillStyle = 'rgba(22,199,132,0.45)';
    ctx.beginPath(); ctx.moveTo(mid, H - 4);
    cumBid.forEach((q, i) => ctx.lineTo(mid - (mid * (i + 1)) / (bids.length + 1), y(q)));
    ctx.lineTo(mid, H - 4); ctx.closePath(); ctx.fill();
    ctx.fillStyle = 'rgba(239,68,68,0.45)';
    ctx.beginPath(); ctx.moveTo(mid, H - 4);
    cumAsk.forEach((q, i) => ctx.lineTo(mid + (mid * (i + 1)) / (asks.length + 1), y(q)));
    ctx.lineTo(mid, H - 4); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = '#28324a'; ctx.beginPath(); ctx.moveTo(mid, 0); ctx.lineTo(mid, H); ctx.stroke();
  } catch (e) {}
}

// ---------- CANDLE CHART ----------
function aggregate(data, bucketMs) {
  const map = new Map();
  for (const c of data) {
    const t = Math.floor(c.t / bucketMs) * bucketMs;
    if (!map.has(t)) map.set(t, { t, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume || 0 });
    else { const b = map.get(t); b.high = Math.max(b.high, c.high); b.low = Math.min(b.low, c.low); b.close = c.close; b.volume += c.volume || 0; }
  }
  return Array.from(map.values()).sort((a, b) => a.t - b.t);
}

let chartHover = null;
let viewCount = 150;
let viewEnd = 0;
let dragging = false;
let dragStartX = 0, dragStartEnd = 0;
let aggCandles = [];
let lastAnalysis = null;
function clampN(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
// Step grid yang "rapi" (1/2/5 × 10^n) supaya label harga tidak numpuk / duplikat.
function niceStep(raw) {
  if (!(raw > 0)) return 1;
  const pow = Math.pow(10, Math.floor(Math.log10(raw)));
  const n = raw / pow;
  const m = n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10;
  return m * pow;
}
function emaSeries(arr, period) {
  const out = new Array(arr.length).fill(null);
  if (!arr.length) return out;
  const k = 2 / (period + 1);
  let prev = arr[0].close;
  out[0] = prev;
  for (let i = 1; i < arr.length; i++) {
    prev = arr[i].close * k + prev * (1 - k);
    out[i] = prev;
  }
  return out;
}
function renderCandles() {
  try {
    const canvas = $('candleChart');
    const wrap = canvas.parentElement;
    if (!wrap) return;
    const rect = wrap.getBoundingClientRect();
    const W = Math.floor(rect.width), H = Math.floor(rect.height);
    if (W <= 40 || H <= 40) return;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = W * dpr; canvas.height = H * dpr;
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#07090f'; ctx.fillRect(0, 0, W, H);

    const all = candles || [];
    aggCandles = all;
    const end = Math.max(1, all.length - viewEnd);
    const start = Math.max(0, end - viewCount);
    const data = all.slice(start, end);
    const empty = $('chartEmpty');
    if (data.length < 2) { if (empty) empty.style.display = 'flex'; return; }
    if (empty) empty.style.display = 'none';

    const min = Math.min(...data.map(c => c.low));
    const max = Math.max(...data.map(c => c.high));
    const range = (max - min) || 1;
    // Padding sumbu harga supaya candle tidak menempel tepi & wick tidak tampak
    // berlebihan — mendekati tampilan terminal trading sungguhan.
    const yMin = min - range * 0.08;
    const yMax = max + range * 0.08;

    // Layout: area harga + area volume (bawah) + label waktu.
    const pad = { l: 8, r: 64, t: 10, b: 18 };
    const volH = 28, gap = 6;
    const pw = W - pad.l - pad.r;
    const ph = H - pad.t - pad.b - volH - gap;
    const x = i => pad.l + (i / Math.max(1, data.length - 1)) * pw;
    const y = v => pad.t + (1 - (v - yMin) / (yMax - yMin)) * ph;
    const volTop = pad.t + ph + gap;

    // EMA (dihitung dari seluruh seri supaya akurat, bukan cuma window tampil).
    const ema9 = emaSeries(all, 9), ema21 = emaSeries(all, 21);
    const ema20 = emaSeries(all, 20), ema50 = emaSeries(all, 50);

    // grid + label harga (kanan) dengan step "rapi" supaya label tidak numpuk/duplikat.
    ctx.font = '10px ' + getComputedStyle(document.body).fontFamily;
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    const GRID = 5;
    const step = niceStep((yMax - yMin) / GRID);
    const gridStart = Math.ceil(yMin / step) * step;
    for (let g = 0; g <= GRID; g++) {
      const val = gridStart + g * step;
      const gy = y(val);
      if (gy < pad.t - 4 || gy > pad.t + ph + 4) continue;
      ctx.strokeStyle = 'rgba(255,255,255,0.045)';
      ctx.beginPath(); ctx.moveTo(pad.l, gy); ctx.lineTo(W - pad.r, gy); ctx.stroke();
      ctx.fillStyle = '#5f6b82';
      ctx.fillText(fmtCompact(val), W - pad.r + 8, gy);
    }

    // volume bars (bawah)
    const maxVol = Math.max(1, ...data.map(c => c.volume || 0));
    const bw = Math.max(1, (pw / data.length) * 0.62);
    data.forEach((c, i) => {
      const cx = x(i);
      const vh = ((c.volume || 0) / maxVol) * volH;
      ctx.fillStyle = c.close >= c.open ? 'rgba(22,199,132,0.4)' : 'rgba(239,68,68,0.4)';
      ctx.fillRect(cx - bw / 2, volTop + volH - vh, bw, vh);
    });

    // label waktu (bawah)
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    const labelEvery = Math.max(1, Math.floor(data.length / 6));
    for (let i = 0; i < data.length; i += labelEvery) {
      ctx.fillStyle = '#5f6b82';
      ctx.fillText(fmtTime(data[i].t, tf), x(i), volTop + volH + 5);
    }

    // candles
    const cw = Math.min(14, Math.max(1, (pw / data.length) * 0.62));
    data.forEach((c, i) => {
      const cx = x(i);
      const up = c.close >= c.open;
      const col = up ? '#16c784' : '#ef4444';
      ctx.strokeStyle = col;
      ctx.beginPath(); ctx.moveTo(cx, y(c.high)); ctx.lineTo(cx, y(c.low)); ctx.stroke();
      const yO = y(c.open), yC = y(c.close);
      const top = Math.min(yO, yC), h = Math.max(1, Math.abs(yC - yO));
      ctx.fillStyle = col; ctx.fillRect(cx - cw / 2, top, cw, h);
    });

    // EMA lines
    const drawEma = (series, color) => {
      ctx.strokeStyle = color; ctx.lineWidth = 1.5;
      ctx.beginPath();
      let started = false;
      for (let i = 0; i < data.length; i++) {
        const v = series[start + i];
        if (v == null) continue;
        const px = x(i), py = y(v);
        if (!started) { ctx.moveTo(px, py); started = true; } else ctx.lineTo(px, py);
      }
      ctx.stroke();
    };
    drawEma(ema9, '#f5b544');   // EMA 9
    drawEma(ema21, '#a78bfa');  // EMA 21
    drawEma(ema20, '#22d3ee');  // EMA 20
    drawEma(ema50, '#f472b6');  // EMA 50

    // Support / resistance (dari technical analysis) — garis putus-putus, label di KIRI
    // supaya tidak menabrak label harga di sumbu kanan.
    const drawLevel = (price, color) => {
      if (price == null || !(price > 0)) return;
      const ly = y(price);
      ctx.strokeStyle = color; ctx.setLineDash([4, 4]); ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(pad.l, ly); ctx.lineTo(W - pad.r, ly); ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = color; ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
      ctx.font = '9px ' + getComputedStyle(document.body).fontFamily;
      ctx.fillText(fmtCompact(price), pad.l + 4, ly - 2);
      ctx.font = '10px ' + getComputedStyle(document.body).fontFamily;
      ctx.textBaseline = 'middle';
    };
    if (lastAnalysis?.ready) {
      drawLevel(lastAnalysis.resistance, '#ef4444');
      drawLevel(lastAnalysis.support, '#16c784');
    }

    // legend EMA (kompak, font kecil, berhenti sebelum menabrak label harga kanan)
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.font = '9px ' + getComputedStyle(document.body).fontFamily;
    const legendItems = [
      ['#f5b544', 'EMA9'], ['#22d3ee', 'EMA20'], ['#a78bfa', 'EMA21'], ['#f472b6', 'EMA50'],
    ];
    if (lastAnalysis?.ready && lastAnalysis.indicators?.rsi != null) {
      legendItems.push(['#94a3b8', 'RSI' + Number(lastAnalysis.indicators.rsi).toFixed(1)]);
    }
    let lx = pad.l + 4;
    const legendMax = W - pad.r - 70;
    for (const [color, label] of legendItems) {
      ctx.fillStyle = color;
      const tw = ctx.measureText(label).width + 14;
      if (lx + tw > legendMax) break;
      ctx.fillText(label, lx, pad.t + 4);
      lx += tw;
    }
    ctx.font = '10px ' + getComputedStyle(document.body).fontFamily;

    // harga terakhir (garis putus + badge di KIRI supaya tidak menabrak sumbu kanan)
    const last = data[data.length - 1];
    const ly = y(last.close);
    ctx.strokeStyle = '#3b82f6'; ctx.setLineDash([3, 3]);
    ctx.beginPath(); ctx.moveTo(pad.l, ly); ctx.lineTo(W - pad.r, ly); ctx.stroke(); ctx.setLineDash([]);
    ctx.fillStyle = '#3b82f6'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    const lastTxt = fmtCompact(last.close);
    const lastW = ctx.measureText(lastTxt).width + 12;
    ctx.fillStyle = 'rgba(59,130,246,0.92)';
    ctx.fillRect(pad.l, ly - 9, lastW, 18);
    ctx.fillStyle = '#fff';
    ctx.fillText(lastTxt, pad.l + 6, ly);

    // crosshair saat hover
    if (chartHover) {
      const idx = Math.round((chartHover - pad.l) / pw * (data.length - 1));
      if (idx >= 0 && idx < data.length) {
        const cx = x(idx), c = data[idx];
        ctx.strokeStyle = 'rgba(255,255,255,0.15)';
        ctx.beginPath(); ctx.moveTo(cx, pad.t); ctx.lineTo(cx, volTop + volH); ctx.stroke();
        drawTooltip(ctx, c, cx, W, H);
      }
    }
  } catch (e) {}
}

function fmtTime(t, tf) {
  const d = new Date(t);
  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  if (tf === '1d') return `${d.getDate()}/${d.getMonth() + 1}`;
  if (tf === '4h') return `${d.getDate()}/${d.getMonth() + 1} ${hh}:${mm}`;
  return `${hh}:${mm}`;
}

function drawTooltip(ctx, c, cx, W, H) {
  const lines = [
    'O ' + fmtFull(c.open),
    'H ' + fmtFull(c.high),
    'L ' + fmtFull(c.low),
    'C ' + fmtFull(c.close),
    'V ' + fmtCompact(c.volume),
  ];
  ctx.font = '10.5px ' + getComputedStyle(document.body).fontFamily;
  const w = 92, h = lines.length * 15 + 10;
  let bx = cx + 10; if (bx + w > W - 60) bx = cx - w - 10;
  const by = 10;
  ctx.fillStyle = 'rgba(19,26,39,0.95)'; ctx.strokeStyle = '#28324a';
  ctx.beginPath(); ctx.roundRect(bx, by, w, h, 5); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#a7b0c2'; ctx.textAlign = 'left'; ctx.textBaseline = 'top';
  lines.forEach((ln, i) => ctx.fillText(ln, bx + 8, by + 6 + i * 15));
}

$('candleChart').addEventListener('mousemove', (e) => {
  const r = e.currentTarget.getBoundingClientRect();
  chartHover = e.clientX - r.left;
  if (dragging) {
    const candleW = r.width / viewCount;
    const dx = e.clientX - dragStartX;
    viewEnd = clampN(Math.round(dragStartEnd - dx / candleW), 0, Math.max(0, aggCandles.length - viewCount));
  }
  renderCandles();
});
$('candleChart').addEventListener('mouseleave', () => { chartHover = null; if (!dragging) renderCandles(); });
$('candleChart').addEventListener('mousedown', (e) => { dragging = true; dragStartX = e.clientX; dragStartEnd = viewEnd; });
window.addEventListener('mouseup', () => { dragging = false; });
$('candleChart').addEventListener('wheel', (e) => {
  e.preventDefault();
  const f = e.deltaY > 0 ? 1.2 : 0.83;
  viewCount = clampN(Math.round(viewCount * f), 15, Math.max(15, aggCandles.length));
  viewEnd = clampN(viewEnd, 0, Math.max(0, aggCandles.length - viewCount));
  renderCandles();
}, { passive: false });
$('candleChart').addEventListener('dblclick', () => { viewCount = 150; viewEnd = 0; renderCandles(); });

// Touch: geser untuk pan, pinch untuk zoom.
let pinchDist = 0, pinchStartCount = 0;
$('candleChart').addEventListener('touchstart', (e) => {
  if (e.touches.length === 1) { dragging = true; dragStartX = e.touches[0].clientX; dragStartEnd = viewEnd; }
  else if (e.touches.length === 2) { dragging = false; pinchDist = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY); pinchStartCount = viewCount; }
}, { passive: true });
$('candleChart').addEventListener('touchmove', (e) => {
  if (e.touches.length === 1 && dragging) {
    const r = e.currentTarget.getBoundingClientRect();
    const candleW = r.width / viewCount;
    const dx = e.touches[0].clientX - dragStartX;
    viewEnd = clampN(Math.round(dragStartEnd - dx / candleW), 0, Math.max(0, aggCandles.length - viewCount));
    renderCandles();
  } else if (e.touches.length === 2 && pinchDist > 0) {
    const d = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
    viewCount = clampN(Math.round(pinchStartCount * (pinchDist / d)), 15, Math.max(15, aggCandles.length));
    renderCandles();
  }
}, { passive: true });
$('candleChart').addEventListener('touchend', () => { dragging = false; pinchDist = 0; });

document.querySelectorAll('.chip[data-tf]').forEach(c => c.addEventListener('click', () => {
  tf = c.dataset.tf;
  viewCount = 150; viewEnd = 0;
  document.querySelectorAll('.chip[data-tf]').forEach(x => x.classList.toggle('active', x === c));
  refreshDetail(true);
}));

// ---------- ORDER FORM ----------
$('btnBuy').addEventListener('click', () => { currentSide = 'buy'; syncSideButtons(); });
$('btnSell').addEventListener('click', () => { currentSide = 'sell'; syncSideButtons(); });
$('btnLimit').addEventListener('click', () => { currentType = 'limit'; syncTypeButtons(); });
$('btnMarket').addEventListener('click', () => { currentType = 'market'; syncTypeButtons(); });
function currentInstrumentPrice() {
  if (lastPrice) return lastPrice;
  const it = marketItems.find(i => i.id === currentItem);
  return (it && it.price) || 0;
}
function availableAmount() {
  const p = window._portfolio || {};
  if (currentSide === 'buy') return p.balance || 0;
  const h = (p.holdings || []).find(x => x.itemId === currentItem);
  return h ? h.qty : 0;
}
function syncSideButtons() {
  $('btnBuy').classList.toggle('active', currentSide === 'buy');
  $('btnSell').classList.toggle('active', currentSide === 'sell');
  $('btnSubmit').textContent = currentSide === 'buy' ? t('ui.buy') : t('ui.sell');
  $('btnSubmit').className = 'btn block ' + (currentSide === 'buy' ? 'buy' : 'sell');
  updateOrderTotal();
}
function syncTypeButtons() { $('btnLimit').classList.toggle('active', currentType === 'limit'); $('btnMarket').classList.toggle('active', currentType === 'market'); updateOrderTypeUI(); updateOrderTotal(); }
function updateOrderTypeUI() {
  $('orderPrice').disabled = currentType === 'market';
  if (currentType === 'market') { $('orderPrice').value = ''; }
}
$('orderPrice').addEventListener('input', updateOrderTotal);
$('orderQty').addEventListener('input', updateOrderTotal);
document.querySelectorAll('.pct').forEach(b => b.addEventListener('click', () => {
  const pct = Number(b.dataset.pct) || 0;
  const price = currentType === 'market' ? currentInstrumentPrice() : (Number($('orderPrice').value) || 0);
  const avail = availableAmount();
  if (currentSide === 'buy') {
    if (!price) return setStatus('orderStatus', 'Isi harga dulu (atau pilih Market)', 'err');
    $('orderQty').value = Math.max(1, Math.floor(avail * pct / price));
  } else {
    $('orderQty').value = Math.max(1, Math.floor(avail * pct));
  }
  updateOrderTotal();
}));
if ($('convKzc')) {
  $('convKzc').addEventListener('input', () => {
    convKzcVal = Number($('convKzc').value) || 0;
    syncConverter();
  });
}
function updateOrderTotal() {
  const p = currentType === 'market' ? currentInstrumentPrice() : (Number($('orderPrice').value) || 0);
  const q = Number($('orderQty').value) || 0;
  const total = p * q;
  const avail = availableAmount();
  $('orderTotalLabel').textContent = currentType === 'market' ? t('trade.est_total') : t('trade.total');
  $('orderTotal').textContent = total ? fmtFull(total) + ' KZC' : '—';
  $('orderAvail').textContent = currentSide === 'buy'
    ? t('trade.avail_buy', { n: fmtFull(avail) })
    : t('trade.avail_sell', { n: fmtFull(avail) });
  if (total > 0 && currentSide === 'buy' && total > avail) $('orderTotal').style.color = 'var(--red)';
  else $('orderTotal').style.color = '';
}
$('btnSubmit').addEventListener('click', async () => {
  if (!guildId || !currentItem) return setStatus('orderStatus', t('trade.pick_server_asset'), 'err');
  if (!MY_USER_ID) return setStatus('orderStatus', t('ui.login_discord_first'), 'err');
  const price = Number($('orderPrice').value) || 0, qty = Number($('orderQty').value) || 0;
  if (currentType === 'limit' && price <= 0) return setStatus('orderStatus', t('trade.fill_price'), 'err');
  if (qty <= 0) return setStatus('orderStatus', t('trade.fill_qty'), 'err');
  setStatus('orderStatus', t('trade.sending'), '');
  const res = await fetch(`/api/trade/${guildId}/order`, { method: 'POST', headers: authHeaders(), body: JSON.stringify({ userId: MY_USER_ID, itemId: currentItem, side: currentSide, type: currentType, price, qty }) });
  const d = await res.json();
  if (res.ok) {
    setStatus('orderStatus', d.status === 'open' || d.status === 'partial' ? t('trade.order_placed', { id: d.orderId || '-' }) : t('trade.filled_n', { n: (d.fills || []).length }), 'ok');
    refreshDetail(); refreshPortfolio();
  } else setStatus('orderStatus', t('ui.failed', { err: d.error }), 'err');
});

// ---------- TABS ----------
document.querySelectorAll('.tab').forEach(t => t.addEventListener('click', () => {
  activeTab = t.dataset.tab;
  document.querySelectorAll('.tab').forEach(x => x.classList.toggle('active', x === t));
  if (t.dataset.tab === 'alerts' && MY_USER_ID) loadAlerts().then(renderBottom);
  if (t.dataset.tab === 'leaderboard') loadLeaderboard().then(renderBottom);
  if (t.dataset.tab === 'fills') refreshDetail();
  renderBottom();
}));

async function refreshPortfolio() { if (guildId && MY_USER_ID) { await fetchPortfolio(); if (activeTab === 'portfolio' || activeTab === 'orders' || activeTab === 'trades') renderBottom(); } }
async function fetchPortfolio() {
  const res = await fetch(`/api/trade/${guildId}/portfolio?userId=${MY_USER_ID}`, { headers: authHeaders() });
  const d = await res.json();
  if (d.balance != null) {
    const holdingsValue = (d.holdings || []).reduce((s, h) => s + (h.price * h.qty), 0);
    d.totalValue = (d.total || 0) + holdingsValue;
    $('balancePill').textContent = fmtCompact(d.totalValue) + ' KZC';
  }
  window._portfolio = d; return d;
}
async function loadAlerts() {
  const res = await fetch(`/api/trade/${guildId}/alerts?userId=${MY_USER_ID}`, { headers: authHeaders() });
  window._alerts = await res.json();
}
async function loadLeaderboard() {
  const res = await fetch(`/api/trade/${guildId}/stats`, { headers: authHeaders() });
  window._lb = await res.json();
}

function shortId(id) { const s = String(id || ''); return s.length > 10 ? s.slice(0, 6) + '...' + s.slice(-4) : s; }

function renderBottom() {
  const c = $('bottomContent');
  const p = window._portfolio || {};
  if (activeTab === 'portfolio') {
    const holds = (p.holdings || []).filter(h => h.qty > 0);
    const holdingsValue = (p.holdings || []).reduce((s, h) => s + (h.price * h.qty), 0);
    c.innerHTML =
      `<div class="bank-controls"><span class="small muted">${t('trade.total')} ${fmtFull(p.totalValue || 0)} KZC &bull; ${t('trade.wallet')} ${fmtFull(p.balance || 0)} &bull; ${t('trade.bank')} ${fmtFull(p.bank || 0)} &bull; ${t('trade.assets_val')} ${fmtFull(holdingsValue)}</span></div>` +
      `<div class="bank-controls"><input type="number" id="bankAmt" class="input" placeholder="${t('trade.conv_placeholder')}" /><button class="btn" data-bank="deposit">${t('ui.deposit')}</button><button class="btn" data-bank="withdraw">${t('ui.withdraw')}</button></div>` +
      `<table class="tbl"><thead><tr><th>${t('trade.tab_asset')}</th><th>${t('trade.tab_qty')}</th><th>${t('trade.tab_price')}</th><th>${t('trade.tab_value')}</th></tr></thead><tbody>` +
      (holds.length ? holds.map(h => `<tr><td><span class="hold-ic" data-ic="${h.itemId}" data-cat="${h.kind ? (KIND_ICON[h.kind] || 'coin') : (h.category || 'consumable')}"></span> ${escapeHtml(h.name)}</td><td class="num">${h.qty}</td><td class="num">${fmtFull(h.price)}</td><td class="num">${fmtFull(h.price * h.qty)}</td></tr>`).join('') : `<tr><td colspan="4" class="empty">${t('trade.no_assets')}</td></tr>`) + `</tbody></table>`;
    c.querySelectorAll('.hold-ic').forEach(el => mountIcon(el, el.dataset.ic, el.dataset.cat, 20));
    c.querySelectorAll('[data-bank]').forEach(b => b.addEventListener('click', async () => {
      const amount = $('bankAmt').value;
      const res = await fetch(`/api/trade/${guildId}/bank`, { method: 'POST', headers: authHeaders(), body: JSON.stringify({ userId: MY_USER_ID, action: b.dataset.bank, amount }) });
      const d = await res.json();
      if (res.ok) refreshPortfolio(); else alert(d.error);
    }));
  } else if (activeTab === 'orders') {
    const os = p.openOrders || [];
    c.innerHTML = `<div class="bank-controls"><button id="btnCancelAll" class="btn" ${os.length ? '' : 'disabled'}>${t('trade.cancel_all')}</button></div>` +
      `<table class="tbl"><thead><tr><th>${t('trade.col_id')}</th><th>${t('trade.tab_asset')}</th><th>${t('trade.col_side')}</th><th>${t('trade.col_type')}</th><th>${t('trade.tab_price')}</th><th>${t('trade.col_remaining')}</th><th>${t('trade.col_action')}</th></tr></thead><tbody>` +
      (os.length ? os.map(o => `<tr><td>#${o.id}</td><td>${escapeHtml(o.itemName)}</td><td><span class="tag ${o.side}">${o.side}</span></td><td>${o.type}</td><td class="num">${fmtFull(o.price)}</td><td class="num">${o.remaining}/${o.qty}</td><td><button class="btn" data-cancel="${o.id}">${t('ui.cancel')}</button></td></tr>`).join('') : `<tr><td colspan="7" class="empty">${t('trade.no_open_orders')}</td></tr>`) + `</tbody></table>`;
    c.querySelectorAll('[data-cancel]').forEach(b => b.addEventListener('click', async () => {
      const res = await fetch(`/api/trade/${guildId}/cancel`, { method: 'POST', headers: authHeaders(), body: JSON.stringify({ userId: MY_USER_ID, orderId: Number(b.dataset.cancel) }) });
      const d = await res.json();
      if (res.ok) { refreshPortfolio(); refreshDetail(); } else alert(d.error);
    }));
    const btnAll = $('btnCancelAll');
    if (btnAll && os.length) btnAll.addEventListener('click', async () => {
      const res = await fetch(`/api/trade/${guildId}/cancelall`, { method: 'POST', headers: authHeaders(), body: JSON.stringify({ userId: MY_USER_ID }) });
      const d = await res.json();
      if (res.ok) { refreshPortfolio(); refreshDetail(); } else alert(d.error);
    });
  } else if (activeTab === 'trades') {
    const ts = (p.trades || []).slice(0, 30);
    c.innerHTML = `<table class="tbl"><thead><tr><th>Waktu</th><th>Catatan</th><th>Jumlah</th><th>Tipe</th></tr></thead><tbody>` +
      (ts.length ? ts.map(t => `<tr><td class="num">${new Date(t.timestamp).toLocaleTimeString('id-ID')}</td><td>${escapeHtml(t.note || '-')}</td><td class="num ${t.amount >= 0 ? 'up' : 'down'}">${t.amount >= 0 ? '+' : ''}${fmtFull(t.amount)}</td><td class="muted">${t.type}</td></tr>`).join('') : `<tr><td colspan="4" class="empty">Belum ada riwayat.</td></tr>`) + `</tbody></table>`;
  } else if (activeTab === 'fills') {
    const fs = window._fills || [];
    c.innerHTML = `<table class="tbl"><thead><tr><th>Waktu</th><th>Harga</th><th>Jumlah</th><th>Total</th></tr></thead><tbody>` +
      (fs.length ? fs.map(f => `<tr><td class="num">${new Date(f.timestamp).toLocaleTimeString('id-ID')}</td><td class="num">${fmtFull(f.price)}</td><td class="num">${f.qty}</td><td class="num">${fmtFull(f.amount || f.price * f.qty)}</td></tr>`).join('') : `<tr><td colspan="4" class="empty">Belum ada trade.</td></tr>`) + `</tbody></table>`;
  } else if (activeTab === 'alerts') {
    const as = window._alerts || [];
    const opts = marketItems.map(i => `<option value="${i.id}">${escapeHtml(i.name)}</option>`).join('');
    c.innerHTML =
      `<div class="alert-form"><select id="alertItem" class="select">${opts}</select><select id="alertDir" class="select"><option value="above">Naik di atas</option><option value="below">Turun di bawah</option></select><input type="number" id="alertPrice" class="input" placeholder="Harga target" /><button id="btnAddAlert" class="btn primary">Tambah</button></div>` +
      `<table class="tbl"><thead><tr><th>Aset</th><th>Arah</th><th>Harga</th><th>Aksi</th></tr></thead><tbody>` +
      (as.length ? as.map(a => `<tr><td>${escapeHtml(a.itemName)}</td><td>${a.direction}</td><td class="num">${fmtFull(a.price)}</td><td><button class="btn" data-delalert="${a.id}">Hapus</button></td></tr>`).join('') : `<tr><td colspan="4" class="empty">Belum ada alert.</td></tr>`) + `</tbody></table>`;
    $('btnAddAlert').addEventListener('click', async () => {
      const itemId = $('alertItem').value, direction = $('alertDir').value, price = $('alertPrice').value;
      const res = await fetch(`/api/trade/${guildId}/alert`, { method: 'POST', headers: authHeaders(), body: JSON.stringify({ userId: MY_USER_ID, itemId, direction, price: Number(price) }) });
      if (res.ok) { loadAlerts(); renderBottom(); } else alert((await res.json()).error);
    });
    c.querySelectorAll('[data-delalert]').forEach(b => b.addEventListener('click', async () => {
      await fetch(`/api/trade/${guildId}/alert/${b.dataset.delalert}?userId=${MY_USER_ID}`, { method: 'DELETE', headers: authHeaders() });
      loadAlerts(); renderBottom();
    }));
  } else if (activeTab === 'leaderboard') {
    const lb = window._lb || {};
    const holders = lb.holders || [], traders = lb.traders || [];
    c.innerHTML =
      `<div class="monitor-grid">` +
      `<div><div class="row-head">Pemegang Terbesar</div><table class="tbl"><thead><tr><th>#</th><th>User</th><th>Saldo</th></tr></thead><tbody>` +
      (holders.length ? holders.map(h => `<tr><td>${h.rank}</td><td class="muted">${shortId(h.userId)}</td><td class="num">${fmtFull(h.total)}</td></tr>`).join('') : `<tr><td colspan="3" class="empty">-</td></tr>`) + `</tbody></table></div>` +
      `<div><div class="row-head">Trader Teraktif</div><table class="tbl"><thead><tr><th>#</th><th>User</th><th>Volume</th></tr></thead><tbody>` +
      (traders.length ? traders.map(t => `<tr><td>${t.rank}</td><td class="muted">${shortId(t.userId)}</td><td class="num">${fmtFull(t.volume)}</td></tr>`).join('') : `<tr><td colspan="3" class="empty">-</td></tr>`) + `</tbody></table></div>` +
      `</div>`;
  }
}

function escapeHtml(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
}

// ---------- TICKER (auto update 1.5 detik) ----------
function startTicker() {
  setInterval(async () => {
    if (ticking || !guildId) return;
    ticking = true;
    try {
      tickCounter++;
      if (currentItem) await refreshDetail();
      // Refresh daftar harga (termasuk kurs USD) tiap 2 detik, lalu perbarui badge kurs
      // + konverter supaya "dolar" selalu live (sebelumnya cuma tiap 4 detik & konverter
      // tidak ikut ter-update sama sekali).
      if (tickCounter % 2 === 0) await loadMarketList();
      if (tickCounter % 5 === 0 && MY_USER_ID) await refreshPortfolio();
      renderUsdRate();
      syncConverter();
    } catch {} finally { ticking = false; }
  }, 1000);
}

// ---------- WEBSOCKET ----------
function connectWs() {
  const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
  ws = new WebSocket(`${proto}//${location.host}/?token=${TOKEN}`);
  ws.onmessage = (e) => {
    try {
      const { type, data } = JSON.parse(e.data);
      if (type === 'hello' && !guilds.length) { guilds = data.guilds || []; fillGuilds(); }
      if (type === 'market' && data.guildId === guildId) { if (currentItem) refreshDetail(); }
      if (type === 'trade' && data.guildId === guildId) { if (currentItem === data.itemId || !data.itemId) { refreshDetail(); refreshPortfolio(); } }
      if (type === 'economy' && data.guildId === guildId) { if (MY_USER_ID) refreshPortfolio(); }
      if (type === 'alert' && MY_USER_ID) { if (activeTab === 'alerts') loadAlerts().then(renderBottom); }
    } catch {}
  };
  ws.onclose = () => { if (MY_USER_ID) setTimeout(connectWs, 5000); };
}

// ---------- RESIZE ----------
window.addEventListener('resize', () => { renderCandles(); });

syncSideButtons();
syncTypeButtons();
init();
