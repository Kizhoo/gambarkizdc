# Aset Grafik RPG (Kizhoo Adventure)

Semua aset di bawah **gratis** dan sudah disertakan. Game otomatis memakainya;
bila suatu file tidak ada, kode punya fallback prosedural supaya tidak error.

Lisensi ringkas per sumber:
- **LPC (Liberated Pixel Cup)** — CC-BY-SA 3.0 / GPL 3.0 (atribusi wajib).
- **craftpix.net free packs** — gratis, boleh dipakai (lihat ketentuan tiap paket).
- **game-icons.net** — CC BY 3.0 (atribusi ke pengarang ikon).

---

## 1. Karakter / Hero per class — `hero/*.png`

Sprite-sheet karakter 64×64 (13 kolom × 21 baris), satu file per class:

| File | Class | Deskripsi |
|---|---|---|
| warrior.png | Warrior | baju merah, rambut hitam |
| mage.png | Mage | baju ungu, rambut putih |
| assassin.png | Assassin | baju gelap, rambut cokelat |
| healer.png | Healer | baju putih, rambut pirang |

- **Arah frame LPC:** tiap animasi 4 baris berurutan `up, left, down, right`.
  Game memakai baris **down** (menghadap depan/kamera): baris 10 untuk jalan,
  baris 14 untuk serangan. *(Sebelumnya salah pakai baris 8/12 = menghadap
  punggung — itulah penyebab "karakter hadap belakang" yang sudah diperbaiki.)*
- Karakter **konsisten di semua layar** (lobby, pilih class, battle, dungeon,
  profil) memakai sprite LPC ini. Menu kustomisasi warna sudah dihapus supaya
  tidak ada lagi karakter yang "beda-beda".
- Sumber & generator:
  - https://sanderfrenken.github.io/Universal-LPC-Spritesheet-Character-Generator/
  - https://github.com/sanderfrenken/Universal-LPC-Spritesheet-Character-Generator

---

## 2. Ikon Skill — `skills/*.png` (BARU)

Ikon skill per class, dipakai di tombol skill saat battle & di layar **Skill Tree**.

| Skill | Class | File | Pengarang (game-icons.net) |
|---|---|---|---|
| Power Slash | Warrior | sword-clash.png | Lorc |
| Cleave | Warrior | crossed-swords.png | Lorc |
| Berserker Rage | Warrior | burning-passion.png | Lorc |
| Fireball | Mage | fireball.png | Lorc |
| Frost Nova | Mage | snowflake-1.png | Lorc |
| Meteor | Mage | comet-spark.png | Lorc |
| Shadow Strike | Assassin | backstab.png | Lorc |
| Poison Blade | Assassin | poison-bottle.png | Lorc |
| Assassinate | Assassin | skull-crossed-bones.png | Lorc |
| Heal | Healer | health-normal.png | sbed |
| Divine Shield | Healer | shield.png | sbed |
| Blessing | Healer | holy-symbol.png | Lorc |

- Ekspor: warna putih `ffffff`, latar transparan, 512×512.
- Kalau mau unduh ulang / ganti warna: jalankan `python3 download-assets.py`
  dari folder `dashboard/public/`, atau buka langsung:
  `https://game-icons.net/icons/ffffff/transparent/1x1/{author}/{name}.png`

---

## 3. Latar (Map / Background) — `backgrounds/*.png`

Game memakai **gambar asli** untuk semua lokasi, bukan gradient CSS polos.

| Lokasi quest | File | Sumber |
|---|---|---|
| Hutan Berkabut | forest.png | craftpix |
| Gua Gelap | cave.png | craftpix |
| Danau Terpencil | lake.png | craftpix |
| Gurun Pasir | desert.png | craftpix |
| Lereng Gunung (volcano) | volcano.png | craftpix |
| Jalan Pegunungan | mountain.png | craftpix |
| Oasis Gurun | oasis.png / oasis2.png | craftpix |
| Jembatan Tua | (alias → mountain) | craftpix |
| Reruntuhan Kuil | (alias → cave) | craftpix |
| Hutan Malam | (alias → forest) | craftpix |
| Gunung Bersalju | (alias → mountain) | craftpix |

Catatan: lokasi **bridge, ruins, night, snow** belum punya gambar sendiri, jadi
game memetakannya ke gambar yang paling mirip (alias `BG_ALIAS` di `rpg.js`).
Kalau ingin gambar unik per lokasi, unduh background gratis dari sumber di
bagian 5 lalu simpan sebagai `backgrounds/bridge.png`, `ruins.png`, `night.png`,
`snow.png` — game otomatis memakainya tanpa perlu ubah kode.

Lapisan parallax hutan (untuk lobby & dungeon):
`backgrounds/forest_layers/sky.png`, `clouds.png`, `flora1.png`, `flora2.png`.

---

## 4. Monster — `monsters/*.png`

25 monster (frame 48×48): slime, goblin, wolf, skeleton, orc, golem, wraith,
minotaur, dragon, demonlord, rat, bat, spider, snake, imp, turtle, gargoyle,
yeti, hyena, scorpion, vulture, mummy, deceased.

> `snake.png` sudah diganti menjadi strip **4 frame animasi jalan** (sebelumnya
> strip 2 frame "hurt" yang membuat ular terlihat kejang).

---

## 5. Sumber aset gratis lain (untuk tambahan / map unik)

- **craftpix.net** — https://craftpix.net/freebies/ — banyak paket gratis
  (background, monster, karakter, tile, UI). Perlu klik "free download".
- **OpenGameArt** — https://opengameart.org/ — ribuan aset gratis, cek lisensi
  per aset (banyak CC0 / CC-BY).
- **Kenney** — https://kenney.nl/assets — aset pixel-art & UI, mayoritas CC0.
- **game-icons.net** — https://game-icons.net/ — 4000+ ikon game (CC BY 3.0),
  cocok untuk ikon skill/item/buff.
- **itch.io** — cari "free 2D game assets"; lisensi tiap paket berbeda.

> Pastikan baca lisensi tiap aset sebelum dipakai komersial. Untuk atribusi
> game-icons.net, sebutkan nama pengarang ikon (Lorc, Delapouite, sbed, dll).

---

## 6. Pet — `pets/*.png` (BARU)

13 sprite pet (sheet 96x48 = 2 frame @48x48: idle + aksi), digenerate khusus
untuk game ini dengan gaya konsisten monster pack (chibi, outline gelap,
3-tone shading). Rarity menentukan aura di dalam game:

| Pet | Jenis | Rarity |
|---|---|---|
| ember | Kitten Api | Umum |
| bolt | Anjing Petir | Umum |
| leafy | Rubah Daun | Umum |
| pebble | Kura-kura Batu | Umum |
| aqua | Slime Air | Umum |
| zephyr | Burung Hantu Angin | Tidak Umum |
| frost | Rubah Es | Tidak Umum |
| toxic | Katak Beracun | Tidak Umum |
| shadow | Kelelawar Bayang | Langka |
| terra | Golem Kecil | Langka |
| lumen | Rubah Cahaya | Epik |
| nyx | Anakan Naga Bayang | Legendaris |
| celeste | Unicorn Kecil | Legendaris |

## 7. Ikon Item — `icons/*.png` (BARU)

60 ikon item (senjata/zirah/aksesori/ramuan/material) 512x512 berwarna per
kategori, di-render dari SVG [game-icons.net](https://game-icons.net/)
(lisensi CC BY 3.0). Pengarang ikon yang dipakai: **Lorc** (broadsword,
wizard-staff, crystal-ball, daggers, claw-slashes, stone-spear, hourglass,
crown-coin, bat-wing, feather, pretty-fangs, boar-tusks, hunting-horn,
moon, angel-wings, ball-heart, potion-ball, jawbone, layered-armor,
spiked-armor, vine-leaf, scales, muscle-up, wingfoot, aura, snowman,
ghost-ally, fire-tail) dan **Delapouite** (war-axe, warhammer, katana,
bow-arrow, spell-book, crescent-staff, cape, cape-armor, imperial-crown,
ring, crystal-earrings, gloves, health-potion, magic-potion, slime, rat,
wool, mummy-head, whistle, bread, planet-core, fire-gem, roman-shield,
vulture, gold-stack, chest, mimic-chest).

Atribusi lengkap per ikon: https://game-icons.net/about.html
