const { SlashCommandBuilder } = require('discord.js');
const { getValidPlayer } = require('../../utils/musicGuard');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder().setName('clearqueue').setDescription('Kosongkan antrian musik tanpa menghentikan lagu yang sedang diputar'),
  async execute(interaction, client) {
    const lang = guildLang(interaction);
    const player = await getValidPlayer(interaction, client);
    if (!player) return;

    if (player.queue.length === 0) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'music.queue_empty'))], ephemeral: true });
    }

    const removedCount = player.queue.length;
    player.queue.splice(0, removedCount);

    return interaction.reply({ embeds: [successEmbed(t(lang, 'music.queue_cleared', { n: removedCount }))] });
  },
};
