const { SlashCommandBuilder } = require('discord.js');
const { getEconomy } = require('../../database/db');
const { baseEmbed } = require('../../utils/embeds');
const kizco = require('../../utils/kizco');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('balance')
    .setDescription('Cek saldo Kizco kamu atau orang lain')
    .addUserOption(o => o.setName('target').setDescription('User yang ingin dicek saldonya')),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const target = interaction.options.getUser('target') || interaction.user;
    const eco = getEconomy(interaction.guild.id, target.id);

    const embed = baseEmbed()
      .setAuthor({ name: t(lang, 'bal.author', { user: target.username }), iconURL: target.displayAvatarURL() })
      .addFields(
        { name: t(lang, 'bal.wallet'), value: kizco.format(eco.balance), inline: true },
        { name: t(lang, 'bal.bank'), value: kizco.format(eco.bank), inline: true },
        { name: t(lang, 'bal.total'), value: kizco.format(eco.balance + eco.bank), inline: true },
      );
    return interaction.reply({ embeds: [embed] });
  },
};
