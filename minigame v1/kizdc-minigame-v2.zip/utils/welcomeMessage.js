// ============================================================================
// PEMBANGUN PESAN WELCOME & GOODBYE — satu tempat payload FINAL (embed / kartu).
// Mendukung warna border custom per-server & gaya goodbye kartu.
// ============================================================================
const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { getGuildConfig } = require('../database/db');
const { applyPlaceholders } = require('./placeholders');
const { renderWelcomeCard, hasCustomBackground, backgroundPathFor } = require('./welcomeCard');
const { t } = require('./i18n');
const config = require('../config.json');

const DEFAULT_WELCOME_MSG = 'Selamat datang {user} di **{server}**! Kamu member ke-**{membercount}**.';
const DEFAULT_GOODBYE_MSG = '**{username}** telah meninggalkan **{server}**. Tersisa **{membercount}** member.';

function resolveWelcomeText(cfg, member) {
  return applyPlaceholders(cfg.welcomeMessage || DEFAULT_WELCOME_MSG, { member, guild: member.guild });
}
function resolveGoodbyeText(cfg, member) {
  return applyPlaceholders(cfg.goodbyeMessage || DEFAULT_GOODBYE_MSG, { member, guild: member.guild });
}

// ===== GAYA 1: EMBED (welcome) =====
function buildEmbedStylePayload(member, cfg) {
  const language = cfg.language || 'id';
  const text = resolveWelcomeText(cfg, member);
  const accountAge = `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`;
  const embed = new EmbedBuilder()
    .setColor(config.successColor)
    .setAuthor({ name: t(language, 'welcome.embed_author_join', { user: member.user.username }), iconURL: member.user.displayAvatarURL() })
    .setTitle(t(language, 'welcome.embed_title', { server: member.guild.name }))
    .setDescription(text)
    .setThumbnail(member.user.displayAvatarURL({ size: 256 }))
    .addFields(
      { name: t(language, 'welcome.embed_field_member'), value: `${member.guild.memberCount}`, inline: true },
      { name: t(language, 'welcome.embed_field_account'), value: accountAge, inline: true },
    )
    .setImage(member.guild.bannerURL({ size: 1024 }) || null)
    .setFooter({ text: `ID: ${member.id}` })
    .setTimestamp();
  return { content: `${member}`, embeds: [embed], files: [] };
}

// ===== GAYA 2: KARTU GAMBAR (welcome) =====
async function buildCardStylePayload(member, cfg) {
  const text = resolveWelcomeText(cfg, member);
  const guildId = member.guild.id;
  const backgroundPath = hasCustomBackground(guildId) ? backgroundPathFor(guildId) : null;
  const buffer = await renderWelcomeCard({
    member,
    guild: member.guild,
    backgroundPath,
    memberCount: member.guild.memberCount,
    accent: cfg.welcomeColor || null,
    type: 'welcome',
    language: cfg.language || 'id',
  });
  const attachment = new AttachmentBuilder(buffer, { name: 'welcome.png' });
  return { content: text, embeds: [], files: [attachment] };
}

// ===== GAYA 1: EMBED (goodbye) =====
function buildGoodbyeEmbedPayload(member, cfg) {
  const language = cfg.language || 'id';
  const text = resolveGoodbyeText(cfg, member);
  const joinedAt = member.joinedTimestamp ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>` : 'tidak diketahui';
  const embed = new EmbedBuilder()
    .setColor(config.errorColor)
    .setAuthor({ name: t(language, 'welcome.embed_author_leave', { user: member.user.username }), iconURL: member.user.displayAvatarURL() })
    .setDescription(text)
    .setThumbnail(member.user.displayAvatarURL({ size: 256 }))
    .addFields(
      { name: t(language, 'welcome.embed_field_left'), value: `${member.guild.memberCount}`, inline: true },
      { name: t(language, 'welcome.embed_field_joined'), value: joinedAt, inline: true },
    )
    .setFooter({ text: `ID: ${member.id}` })
    .setTimestamp();
  return { embeds: [embed], files: [] };
}

// ===== GAYA 2: KARTU GAMBAR (goodbye) =====
async function buildGoodbyeCardPayload(member, cfg) {
  const text = resolveGoodbyeText(cfg, member);
  const guildId = member.guild.id;
  const backgroundPath = hasCustomBackground(guildId) ? backgroundPathFor(guildId) : null;
  const buffer = await renderWelcomeCard({
    member,
    guild: member.guild,
    backgroundPath,
    memberCount: member.guild.memberCount,
    accent: cfg.welcomeColor || null,
    type: 'goodbye',
    language: cfg.language || 'id',
  });
  const attachment = new AttachmentBuilder(buffer, { name: 'goodbye.png' });
  return { content: text, embeds: [], files: [attachment] };
}

// ===== PABRIK PAYLOAD =====
async function buildWelcomePayload(member) {
  const cfg = getGuildConfig(member.guild.id);
  if (cfg.welcomeStyle === 'card') return buildCardStylePayload(member, cfg);
  return buildEmbedStylePayload(member, cfg);
}

async function buildGoodbyePayload(member) {
  const cfg = getGuildConfig(member.guild.id);
  // Gaya & warna goodby SAMA dengan welcome (sinkron, tidak diatur terpisah)
  if (cfg.welcomeStyle === 'card') return buildGoodbyeCardPayload(member, cfg);
  return buildGoodbyeEmbedPayload(member, cfg);
}

// Preview dua gaya sekaligus (welcome)
async function buildPreviewPayloads(member) {
  const cfg = getGuildConfig(member.guild.id);
  return {
    embedPayload: buildEmbedStylePayload(member, cfg),
    cardPayload: await buildCardStylePayload(member, cfg),
  };
}

module.exports = {
  buildWelcomePayload,
  buildGoodbyePayload,
  buildPreviewPayloads,
  buildEmbedStylePayload,
  buildCardStylePayload,
  buildGoodbyeEmbedPayload,
  buildGoodbyeCardPayload,
  DEFAULT_WELCOME_MSG,
  DEFAULT_GOODBYE_MSG,
};
