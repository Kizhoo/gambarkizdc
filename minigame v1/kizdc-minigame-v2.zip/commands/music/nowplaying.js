const { SlashCommandBuilder } = require('discord.js');
const { errorEmbed } = require('../../utils/embeds');
const { buildNowPlayingPayload } = require('../../utils/nowPlayingCard');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder().setName('nowplaying').setDescription('Lihat lagu yang sedang diputar sekarang'),
  async execute(interaction, client) {
    const lang = guildLang(interaction);
    const player = client.kazagumo.players.get(interaction.guild.id);
    const track = player?.queue.current;
    if (!player || !track) return interaction.reply({ embeds: [errorEmbed(t(lang, 'music.nothing_playing'))], ephemeral: true });

    // Pakai kartu yang SAMA PERSIS kayak yang di-post otomatis pas lagu mulai (nowPlayingCard.js)
    // - biar info & tombolnya konsisten di mana pun user lihatnya, bukan versi terpisah yang bisa
    // beda field/desain kalau salah satunya diubah nanti.
    // deferReply dulu: render kartu (canvas + kadang download thumbnail) itu async, jaga-jaga
    // supaya tidak kelewat jendela ~3 detik acknowledge interaction Discord.
    await interaction.deferReply();
    return interaction.editReply(await buildNowPlayingPayload(player, track));
  },
};
