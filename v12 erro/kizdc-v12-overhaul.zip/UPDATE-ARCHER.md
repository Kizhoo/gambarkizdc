# Kizhoo Adventure — Update "Archer" (v2)

Rombakan besar game RPG web + backend bot. Semua permintaan utama dikerjakan:
fix bug lama, sistem baru, dan perombakan visual — tanpa emoji (semua ikon
digambar vektor bergaya pixel).

## PERBAIKAN BUG

1. **Uang beda antara bot dan web**
   - Wallet web dulu selalu memakai server PERTAMA yang di-join bot, padahal
     saldo `/economy` per-server. Sekarang web memakai server yang sama-sama
     di-join user (OAuth) dan bot (`pickGuildId` di `utils/rpgServer.js`).
   - Gold/item dari chest & dungeon dulu tidak pernah tersimpan di mode server
     (endpoint `/api/rpg/save` mengabaikannya). Sekarang semua reward lewat
     endpoint khusus yang di-roll dan divalidasi SERVER.

2. **Karakter dan monster spawn di bawah tanah**
   - Akar masalah: body physics semua monster memakai offset tetap
     `setSize(14,22)+setOffset(1,6)` — untuk monster frame 32x36 (golem, naga,
     minotaur, yeti) body berakhir DI ATAS kaki sehingga sprite tenggelam,
     dan untuk frame 16x16 justru melayang.
   - Sekarang body dihitung dari TINGGI FRAME ASLI per monster
     (`footBody()` + `MONSTER_ASSET[].frameH`): dasar body selalu persis di kaki.
     Sudah diverifikasi visual di browser.

3. **Login Discord tidak nempel / RPG mulai dari awal terus**
   - Sesi dashboard dulu hanya `Map` di memori — bot restart = semua logout.
     Sekarang sesi disimpan di SQLite (`dashboard_sessions`), cookie 30 hari.
   - Halaman `/rpg` kini WAJIB login Discord (redirect ke OAuth bila belum).
   - Game tidak lagi fallback ke karakter baru saat API gagal — tampilkan
     halaman login.
   - Pilihan class dulu tidak pernah tersimpan di server (endpoint save
     mengabaikannya). Sekarang ada `/api/rpg/class`.

4. **Pandai besi error**
   - Hasil tempaan dulu hilang setelah reload (server mengabaikan mutasi
     inventori). Sekarang penempaan divalidasi server-side
     (`/api/rpg/craft`): bahan dicek, dikurangi, item masuk, counter naik.

5. **Monster tidak menjatuhkan bahan craft**
   - Bahan material kini di-roll SERVER saat monster dungeon mati
     (`/api/rpg/dungeon/kill`, rate-limit + validasi monster-lantai).

## SISTEM BARU / REWORK

- **Class Archer menggantikan Healer** — sprite komposit (elf atlas + busur &
  tabung panah digambar per-frame), animasi idle/lari/serang, serangan panah
  proyektil dengan aim-assist. Semua item senjata healer dikonversi jadi busur
  (migrasi otomatis untuk pemain lama: class, equipment, dan inventori).
- **Skill tree ala AAA** — 10 skill per class, 4 tier, prasyarat, upgrade level,
  poin skill. UI pohon dengan konektor, status terkunci/tersedia/maksimal.
  Mage mendapat heal diri (Regeneration) dan heal tim (Bloom of Life).
  Field efek baru: multi-hit, pierce, mark (semua dipakai bot & web).
- **Peti rarity** — hanya muncul di SEBAGIAN lantai (lantai boss selalu ada),
  isi di-roll server dengan bobot rarity per band lantai + tier peti
  (kayu/perak/emas). Semakin langka semakin jarang.
- **Mimic** — peti penyamar yang "bernapas", membuka mulut saat didekati,
  mengejar, drop lebih kaya. Counter `mimicsKilled` untuk achievement.
- **Lantai selesai TANPA hadiah** — hadiah murni dari peti & monster.
- **Pandai besi profesional** — bengkel animatif (tungku, paron, Bang Bara si
  pandai besi dengan dialog), 34 resep (senjata/zirah/aksesoris), animasi
  penempaan 3 pukulan + kartu hasil rarity.
- **Inventori AAA** — grid rarity, panel detail (stat/effect), pasang/pakai/
  jual/jual-semua, tab kategori, sidebar equipment + stat.
- **Leaderboard AAA** — nama asli (nama panggung/username Discord, bukan ID),
  medali peringkat, ikon class, tab kategori, penanda posisi sendiri.
- **Profil + alokasi stat** — friend ID (KZ-XXXX) dengan tombol salin, ganti
  nama panggung, title (dari achievement), alokasi poin ke HP/MP/ATK/DEF/SPD/
  CRIT, statistik lengkap, achievement terakhir.
- **Achievement 44 definisi** — 6 kategori (Pertempuran/Dungeon/Kerajinan/
  Sosial/Koleksi/Progresi), progress dihitung dari data hidup, klaim reward
  (gold/XP/title), toast notifikasi.
- **Teman & sosial** — tambah via friend ID/nama/ID, permintaan & terima,
  status online (presence WebSocket), hapus teman.
- **Lobby multiplayer (maks 4)** — buat/gabung dengan kode, karakter semua
  pemain TERLIHAT BERGERAK real-time di sekitar api unggun, tombol siap,
  mulai party raid (battle co-op vs boss, host-authoritative).
- **Chat 3 kanal** — Dunia (global), Lobby, dan pribadi antar teman.
  Real-time via WebSocket (`/ws`), riwayat tersimpan di DB.
- **Tanpa emoji** — semua ikon UI digambar vektor pixel (`drawIcon`, 35+ ikon),
  termasuk tombol serang/bow/skill/ramuan/dash di dungeon.

## KEAMANAN (anti-cheat)

- XP/gold/drop quest & dungeon dihitung server dari tabel monster — angka
  dari browser tidak dipercaya.
- Roll peti server-side + rate limit (15 peti / 5 menit).
- Validasi monster vs lantai, rate limit kill (40/menit).
- Validasi craft/equip/sell/skill/stat server-side.

## FILE YANG BERUBAH

| File | Perubahan |
|------|-----------|
| `dashboard/public/rpg.js` | Rewrite penuh (5.600+ baris) |
| `dashboard/public/rpg.html` | Bersih (tanpa script pihak ketiga tertanam) |
| `utils/rpgData.js` | Archer, skill tree 10/class, achievement, rank |
| `utils/rpgItems.js` | Item archer (konversi healer), resep forge, tanpa emoji |
| `utils/rpgWorld.js` | BARU — data dunia server (monster, drop, loot, mimic) |
| `utils/rpgServer.js` | Rewrite — 30+ endpoint API server-authoritative |
| `utils/rpgRealtime.js` | BARU — WebSocket: presence, chat, lobby, party |
| `utils/rpgEngine.js` | Stat MP/CRIT, passive baru (hpPct, thorns) |
| `utils/rpgBattle.js` | Multi-hit, pierce, mark, tanpa emoji |
| `utils/rpgCard.js` | Render archer (atlas + gambar busur) |
| `database/rpgDb.js` | Kolom baru, tabel ach/friends/chat/sessions, migrasi healer->archer |
| `dashboard/server.js` | Sesi persist SQLite, cookie 30 hari, WS `/ws` |
| `tests/api_test.js` | BARU — 30 test integrasi API (semuanya lulus) |
| `tests/battle_test.js` | Update cek wallet |

## CARA JALANKAN

Sama seperti sebelumnya — tidak ada langkah baru:

```
npm install
npm start          # bot + dashboard + RPG web
```

Lalu buka `https://domain-bot-kamu/rpg` (login Discord otomatis diminta).

Database lama otomatis dimigrasi saat bot dinyalakan (healer -> archer,
senjata healer -> busur, kolom & tabel baru ditambahkan tanpa menghapus data).

## TEST

```
node tests/battle_test.js   # 7/7 lulus
node tests/api_test.js      # 30/30 lulus (login gate, dungeon, chest, craft,
                            #  skill, stat, equip, leaderboard, achievements,
                            #  friends, chat WebSocket)
```

Game juga sudah diverifikasi end-to-end di browser headless: boot, pilih class
Archer, dungeon platformer (posisi spawn benar), serangan panah, kematian &
retry, semua scene UI, tanpa error console.

---

## UPDATE BESAR v3 — "GACHA & EVOLUSI" (arsip kerja)

### Keluhan yang diperbaiki
1. **Archer tak bisa memukul monster terbang** -> panah kini PROYEKTIL ASLI (aset anak panah
   + kecepatan 880px/s + homing melengkung mengikuti ketinggian target + pita tabrakan
   vertikal inklusif). Fix tambahan: dt kini memakai delta frame NYATA (sebelumnya fixed
   16.7ms -> panah melambat di fps rendah).
2. **Assassin & Archer terlihat sama** -> keduanya dapat SPRITE SHEET HASIL AI sendiri:
   archer = ranger berjubah hijau + busur; assassin = pembunuh berjubah ungu + scraf merah
   + dua belati (plus jejak bayangan saat lari).
3. **Animasi archer membosankan** -> pose menarik busur 2 frame (angkat -> tarik penuh),
   kilat moncok busur, panah ber-jejak cahaya, burst crit, hit-stop & screen shake.
4. **Efek/background "jelek"** -> background per tema kini ASET GAMBAR (gua/kastil/
   reruntuhan/salju baru) + strip parallax siluet per tema + kabut + berkas cahaya +
   loot beam warna rarity + tekstur FX (glow/sparkle/slash/streak).
5. **Item cuma ikon** -> equipment kini TERLIHAT dipakai: senjata di tangan (ikut ayun),
   zirah jadi jubah di punggung, aksesori jadi efek melayang (sayap/halo/orbit bintang) -
   di dungeon DAN battle turn-based.
6. **Pet dari mana saja** -> pet kini HANYA dari GACHA PERMATA (peti memberi pecahan +
   permata; seruling lama ditukar otomatis jadi permata).

### Sistem baru
- **GACHA PERMATA**: rates common 42% -> mythic 0.8%, pity berlapis (epic+ 20, legendary+
  60, MYTHIC 150), tarik 1x/10x (+1 bonus), tukar gold->permata, reveal kartu beranimasi
  (flash mythic prisma + banner).
- **PET MYTHIC**: Solara (phoenix matahari) & Nocturne (panther void) - total 15 pet.
- **EVOLUSI**: tiap pet punya bentuk sejati (Pyrelisk, Stormfang, ... Eclipseon) - tubuh,
  sprite sheet, skill, dan stat berubah (x1.8-x2.0). Syarat: Lv.10 + pecahan + gold.
  Cutscene evolisi lengkap di menu koleksi.
- **Semua pet 6 frame** (idle 3 / lari 2 / serang 1) per tahap - dulunya 2 frame.
- **Menara Tanpa Ujung** (endless, tema bergilir, reward menanjak + permata tiap 5 lantai).
- **World Boss Mingguan**: HP bersama seluruh pemain, kontribusi + leaderboard hadiah.
- **Rumah Lelang** antar pemain (pasang/beli/batal).
- **Hadiah antar teman** (gold/permata/item + pesan + inbox).
- **Prestige** (Lv.50): reset level & skill, +10% stat permanen per tingkat, gelar eksklusif.
- **Dungeon**: monster ELITE (mahkota + aura + loot beam), ALTAR BERKAT (berkah acak),
  RUANG RAHASIA (retakan -> peti bonus), PEDAGANG MISTERIUS (jual ramuan), KILL STREAK
  (bonus MP per milestone).
- **Title system** diperluas (paging) + leaderboard menampilkan gelar.

### File yang berubah
- `dashboard/public/rpg.js` (+~1900 baris): semua scene & sistem di atas.
- `dashboard/public/assets/`: pets (15x2 sheet 6-frame), hero/archer_sheet.png,
  hero/assassin_sheet.png, gear/ (13 senjata + 4 zirah + 4 aksesoris + panah),
  fx/ (4 tekstur), backgrounds (3 baru + 7 strip parallax), icons (tetap).
- `utils/rpgData.js`: PETS 15, PET_EVOLUTION, GACHA, WORLD_BOSSES, achievement baru (68).
- `utils/rpgServer.js`: 20+ endpoint baru (gacha, evolusi, menara, world boss, lelang,
  hadiah, prestige, pedagang, tukar permata) + peti tanpa pet + seruling -> permata.
- `database/rpgDb.js`: kolom baru (gems, petShards, pity, towerBest, prestigeLevel, dst),
  tabel baru (rpg_worldboss, rpg_worldboss_damage, rpg_auctions, rpg_gifts), stage pet.
- `utils/rpgEngine.js`: bonus stat prestige.
- `tests/api_test.js`: 66 test (was 44) - semua lulus.
