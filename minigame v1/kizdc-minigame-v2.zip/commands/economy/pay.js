const { SlashCommandBuilder } = require('discord.js');
const { getEconomy, updateBalance } = require('../../database/db');
const econ = require('../../database/economyDb');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const kizco = require('../../utils/kizco');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pay')
    .setDescription('Kirim Kizco ke orang lain')
    .addUserOption(o => o.setName('target').setDescription('Orang yang akan menerima Kizco').setRequired(true))
    .addIntegerOption(o => o.setName('jumlah').setDescription('Jumlah Kizco').setRequired(true).setMinValue(1)),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const target = interaction.options.getUser('target');
    const amount = interaction.options.getInteger('jumlah');

    if (target.id === interaction.user.id) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'pay.self'))], ephemeral: true });
    }
    if (target.bot) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'pay.bot'))], ephemeral: true });
    }

    const senderEco = getEconomy(interaction.guild.id, interaction.user.id);
    if (senderEco.balance < amount) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'bank.no_wallet', { amount: kizco.format(senderEco.balance) }))], ephemeral: true });
    }

    updateBalance(interaction.guild.id, interaction.user.id, -amount);
    updateBalance(interaction.guild.id, target.id, amount);
    econ.recordTransaction(interaction.guild.id, { type: 'pay', actorId: interaction.user.id, targetId: target.id, amount, note: 'Transfer Kizco' });

    return interaction.reply({ embeds: [successEmbed(t(lang, 'pay.ok', { amount: kizco.format(amount), user: target.username }))] });
  },
};
