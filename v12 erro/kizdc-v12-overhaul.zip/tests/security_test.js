// ============================================================================
// TEST SUITE KEAMANAN — verifikasi semua lapisan utils/security.js
// ----------------------------------------------------------------------------
// Menjalankan server Express SUNGGUHAN dengan applySecurity + mountRpg, lalu
// menyerangnya dari klien HTTP jahat (host palsu, origin asing, UA scanner,
// honeypot, hotlink, brute-force, WAF, flood) dan memastikan semua ditolak.
//
// Catatan: fetch() Node MENOLAK custom Host header (forbidden header), jadi
// klien di sini memakai http.request mentah supaya Host/Origin/UA bisa dipalsu
// persis seperti serangan dunia nyata.
//
// Jalankan: node tests/security_test.js
// ============================================================================
process.env.KIZHOO_DB_PATH = '/tmp/kiz_security_test.sqlite';
require('fs').rmSync('/tmp/kiz_security_test.sqlite', { force: true });
const http = require('http');
const path = require('path');
const express = require('express');
const rpgDb = require('../database/rpgDb');
const Sec = require('../utils/security');
const { mountRpg } = require('../utils/rpgServer');

const app = express();
Sec.applySecurity(app, { rpgDb });
Sec.startJanitor(rpgDb);
app.use(express.json({ limit: '256kb' }));
app.use(Sec.scrubBody);

// Mirror wiring produksi (dashboard/server.js): rute lock dinamis + manifest + hotlink aset.
const fs = require('fs');
app.get('/security-lock.js', (req, res) => {
  try {
    let js = fs.readFileSync(path.join(__dirname, '..', 'dashboard', 'public', 'security-lock.js'), 'utf8');
    js = js.replace('window.__KZ_SEC_CFG = null;',
      'window.__KZ_SEC_CFG = ' + JSON.stringify(Sec.manifestPayload()).replace(/</g, '\\u003c') + ';');
    res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store');
    return res.send(js);
  } catch (_) { return res.status(404).end(); }
});
app.get('/api/security/manifest', (req, res) => res.json(Sec.manifestPayload()));
app.use('/assets', Sec.hotlinkGuard, express.static(path.join(__dirname, '..', 'dashboard', 'public', 'assets')));

// Sesi palsu untuk gate /rpg (meniru cookie kz_sid valid).
rpgDb.saveSession('testsid123', { userId: '42', username: 'Tester', avatar: null, guilds: [] });
rpgDb.createCharacter('42', 'g1', 'archer');

app.use(express.static(path.join(__dirname, '..', 'dashboard', 'public')));
const auth = (req, res, next) => { req.session = { userId: '42', username: 'Tester' }; next(); };
const client = { guilds: { cache: new Map() }, users: { cache: new Map(), fetch: async () => null } };
mountRpg(app, { auth, resolveUserId: (req) => (req.session && req.session.userId) || null, client });

const server = http.createServer(app);
let pass = 0, fail = 0;
const ok = (cond, label) => { if (cond) { pass++; console.log('  OK ' + label); } else { fail++; console.log('  FAIL ' + label); } };

// Klien HTTP mentah — Host/Origin/UA/Referer sepenuhnya bisa dipalsukan.
function rawReq(port, reqPath, { method = 'GET', host = null, origin = null, ua = null, referer = null, cookie = null, body = null } = {}) {
  return new Promise((resolve, reject) => {
    const headers = {};
    if (host) headers.host = host;
    if (origin) headers.origin = origin;
    if (ua) headers['user-agent'] = ua;
    if (referer) headers.referer = referer;
    if (cookie) headers.cookie = cookie;
    if (body != null) { headers['content-type'] = 'application/json'; headers['content-length'] = Buffer.byteLength(body); }
    const r = http.request({ host: '127.0.0.1', port, path: reqPath, method, headers }, (res) => {
      let data = '';
      res.on('data', (c) => { data += c; });
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: data }));
    });
    r.on('error', reject);
    if (body != null) r.write(body);
    r.end();
  });
}

server.listen(0, async () => {
  const port = server.address().port;
  const HOST = '127.0.0.1:' + port;
  const R = (p, o) => rawReq(port, p, o);

  console.log('== 1. HOST GUARD (anti klon domain) ==');
  ok((await R('/', { host: 'situs-klonan.com' })).status === 403, 'Host domain kloningan ditolak 403');
  ok((await R('/', { host: 'konten-bajakan.xyz:8080' })).status === 403, 'Host domain palsu + port ditolak');
  ok((await R('/', { host: 'example.com' })).status === 403, 'Host example.com ditolak');
  ok((await R('/', { host: HOST })).status === 200, 'Host asli (IP lokal) diizinkan');
  ok((await R('/', { host: 'sub-xyz.trycloudflare.com' })).status === 200, 'Host tunnel trycloudflare diizinkan');
  ok((await R('/', { host: '192.168.1.20:' + port })).status === 200, 'Host IP LAN diizinkan');

  Sec._testReset(); // section 1 menambah 3 strike host — bersihkan
  console.log('== 2. SECURITY HEADERS ==');
  const h = (await R('/', { host: HOST })).headers;
  ok(/DENY/.test(h['x-frame-options'] || ''), 'X-Frame-Options DENY (anti iframe)');
  ok((h['x-content-type-options'] || '') === 'nosniff', 'X-Content-Type-Options nosniff');
  ok(/frame-ancestors 'none'/.test(h['content-security-policy'] || ''), 'CSP frame-ancestors none');
  ok((h['referrer-policy'] || '') === 'strict-origin-when-cross-origin', 'Referrer-Policy ketat');
  ok((h['permissions-policy'] || '').includes('camera=()'), 'Permissions-Policy mematikan kamera/mic');
  ok(!(h['x-powered-by'] || '').length, 'x-powered-by disembunyikan');

  Sec._testReset(); // bersihkan sisa strike
  console.log('== 3. ORIGIN GUARD (anti CSRF + klon panggil API) ==');
  ok((await R('/api/rpg/class', { host: HOST, method: 'POST', origin: 'http://situs-klonan.com', body: '{}' })).status === 403, 'POST dari Origin kloningan ditolak');
  ok((await R('/api/rpg/class', { host: HOST, method: 'POST', origin: 'null', body: '{}' })).status === 403, 'Origin null (iframe sandbox) ditolak');
  Sec._testReset(); // 2 strike origin barusan — reset sebelum tes lolos
  const localOrigin = await R('/api/rpg/class', { host: HOST, method: 'POST', origin: 'http://' + HOST, body: '{"classKey":"mage"}' });
  ok(localOrigin.status !== 403, 'POST dari Origin asli lolos origin-guard');

  Sec._testReset();
  console.log('== 4. WAF LITE ==');
  ok((await R('/api/rpg/me?x=../../etc/passwd', { host: HOST })).status === 400, 'Path traversal di query ditolak');
  ok((await R('/api/rpg/me?q=1%20UNION%20SELECT%20*', { host: HOST })).status === 400, 'SQL injection pattern ditolak');
  ok((await R('/api/rpg/me?q=<script>alert(1)</script>', { host: HOST })).status === 400, 'Tag script di query ditolak');

  Sec._testReset(); // 3 strike WAF barusan
  console.log('== 5. HOTLINK GUARD (aset) ==');
  ok((await R('/assets/pets/ember.png', { host: HOST, referer: 'http://situs-klonan.com/hot.html' })).status === 403, 'Hotlink aset dari domain asing ditolak');
  ok((await R('/assets/pets/ember.png', { host: HOST })).status === 200, 'Akses aset tanpa referer diizinkan');

  Sec._testReset(); // 1 strike hotlink
  console.log('== 6. PROTOTYPE POLLUTION SCRUB ==');
  const pollution = await R('/api/rpg/class', { host: HOST, method: 'POST', origin: 'http://' + HOST, body: JSON.stringify({ __proto__: { isAdmin: true }, classKey: 'assassin' }) });
  ok(pollution.status !== 500, 'Body __proto__ di-scrub tanpa crash');

  console.log('== 7. MANIFEST & SECURITY LOCK ==');
  const mfRes = await R('/api/security/manifest', { host: HOST });
  let mf = null; try { mf = JSON.parse(mfRes.body); } catch (_) {}
  ok(mf && Array.isArray(mf.domains) && mf.domains.includes('localhost'), 'Manifest domain resmi tersedia');
  const lock = await R('/security-lock.js', { host: HOST });
  ok(lock.status === 200 && /__KZ_SEC_CFG/.test(lock.body) && !/window\.__KZ_SEC_CFG = null;/.test(lock.body), 'security-lock.js disuntik config domain oleh server');

  console.log('== 8. GATE /rpg (halaman game) ==');
  const noSession = await R('/rpg', { host: HOST });
  ok(noSession.status === 302 && /\/auth\/login/.test(noSession.headers.location || ''), 'Tanpa sesi dialihkan ke login');
  const withSession = await R('/rpg', { host: HOST, cookie: 'kz_sid=testsid123' });
  ok(withSession.status === 200 && /__KZ_SEC_BAKE/.test(withSession.body), '/rpg menyuntik daftar domain (BAKE) untuk gate client');
  ok(/nonce=/.test(withSession.body) && !/unsafe-inline.{0,20}script/.test((withSession.headers['content-security-policy'] || '')), '/rpg pakai CSP nonce (tanpa unsafe-inline script)');

  console.log('== 9. HONEYPOT & SCANNER (ban otomatis) ==');
  ok((await R('/.env', { host: HOST })).status === 403, 'Honeypot /.env ditolak');
  ok((await R('/wp-admin/setup.php', { host: HOST })).status === 403, 'Honeypot /wp-admin ditolak');
  ok((await R('/', { host: HOST, ua: 'sqlmap/1.8 --batch' })).status === 403, 'UA sqlmap diblokir');
  ok((await R('/', { host: HOST, ua: 'Mozilla/5.0 (nikto) test' })).status === 403, 'UA nikto diblokir');
  const bannedNow = (await R('/', { host: HOST })).status === 403;
  ok(bannedNow, 'IP penyusup di-ban otomatis setelah menyentuh honeypot');
  Sec._testReset(); // bersihkan ban demi section berikutnya

  console.log('== 10. RATE LIMIT GLOBAL (flood) ==');
  let got429 = false;
  for (let i = 0; i < 700 && !got429; i++) {
    const r = await R('/api/security/manifest', { host: HOST });
    if (r.status === 429) got429 = true;
  }
  ok(got429, 'Flood 700 request kena limit 429');

  console.log('== 11. AUDIT LOG ==');
  const stats = rpgDb.getSecurityStats();
  ok(stats.byKind.length >= 3, 'Audit log mencatat jenis serangan: ' + stats.byKind.map((k) => k.kind).join(', '));
  ok(stats.recent.length > 0, 'Audit log menyimpan rincian kejadian terbaru');

  console.log('\n==== HASIL SECURITY: ' + pass + ' lulus, ' + fail + ' gagal ====');
  process.exitCode = fail ? 1 : 0;
  try { server.close(); } catch (_) {}
  try { server.closeAllConnections && server.closeAllConnections(); } catch (_) {}
  try { rpgDb.close(); } catch (_) {}
});
