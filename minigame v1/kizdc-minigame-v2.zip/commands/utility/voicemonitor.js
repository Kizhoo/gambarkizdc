const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { startMonitor } = require('../../utils/voiceMonitor');

module.exports = {
  subcommandOf: true,
  data: new SlashCommandBuilder()
    .setName('voicemonitor')
    .setDescription('Tampilkan dashboard monitoring voice channel real-time (auto-update)')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    await startMonitor(interaction);
  },
};
