const { SlashCommandBuilder } = require('discord.js');
const { getEconomy, setLastAction } = require('../../database/db');
const engine = require('../../utils/economyEngine');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const kizco = require('../../utils/kizco');
const config = require('../../config.json');
const { t, guildLang } = require('../../utils/i18n');

const COOLDOWN_MS = 60 * 60 * 1000; // 1 jam
const JOB_KEYS = ['work.j1', 'work.j2', 'work.j3', 'work.j4', 'work.j5', 'work.j6'];

module.exports = {
  data: new SlashCommandBuilder().setName('work').setDescription('Bekerja untuk dapat Kizco (dikenai pajak)'),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const eco = getEconomy(interaction.guild.id, interaction.user.id);
    const now = Date.now();

    if (now - eco.lastWork < COOLDOWN_MS) {
      const remaining = COOLDOWN_MS - (now - eco.lastWork);
      const minutes = Math.floor(remaining / 60000);
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'work.cooldown', { m: minutes }))], ephemeral: true });
    }

    const base = Math.floor(Math.random() * (config.workMax - config.workMin + 1)) + config.workMin;
    const jobKey = JOB_KEYS[Math.floor(Math.random() * JOB_KEYS.length)];
    const job = t(lang, jobKey);
    const { gross, tax, net } = engine.creditPlayer(interaction.guild.id, interaction.user.id, base, { type: 'work', note: job });
    setLastAction(interaction.guild.id, interaction.user.id, 'lastWork', now);

    const taxNote = tax > 0 ? t(lang, 'common.tax', { amount: kizco.format(tax) }) : '';
    return interaction.reply({ embeds: [successEmbed(t(lang, 'work.success', { job, amount: kizco.format(net), tax: taxNote }))] });
  },
};
