const { SlashCommandBuilder } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');
const { safeDefer } = require('../../utils/interactionHelpers');

function describeError(err, lang) {
  const message = (err?.message || '').toLowerCase();
  const cause = (err?.cause?.message || err?.cause?.code || '').toLowerCase();

  if (message.includes('sign in') || (message.includes('confirm') && message.includes('bot'))) {
    return t(lang, 'play.yt_blocked');
  }
  if (message.includes('no result') || message.includes('not found')) {
    return t(lang, 'play.no_result');
  }
  if (message.includes('load fail') || message.includes('unavailable')) {
    return t(lang, 'play.load_fail');
  }
  if (message.includes('youtube extraction failed') || message.includes('piped instances')) {
    return t(lang, 'play.extract_fail');
  }
  if (message.includes('fetch failed') || cause.includes('timeout') || cause.includes('econnrefused') || cause.includes('enotfound')) {
    return t(lang, 'play.fetch_fail');
  }
  return err?.message ? err.message.slice(0, 300) : t(lang, 'play.unknown');
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('play')
    .setDescription('Putar musik dari YouTube, Spotify, atau SoundCloud (support playlist)')
    .addStringOption(o => o.setName('lagu').setDescription('Judul lagu, link lagu, atau link playlist').setRequired(true)),
  async execute(interaction, client) {
    const lang = guildLang(interaction);
    const query = interaction.options.getString('lagu').trim();
    const voiceChannel = interaction.member.voice.channel;

    if (!voiceChannel) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'play.no_voice'))], ephemeral: true });
    }

    const permissions = voiceChannel.permissionsFor(interaction.guild.members.me);
    if (!permissions?.has('Connect') || !permissions?.has('Speak')) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'play.no_perm'))], ephemeral: true });
    }

    if (!(await safeDefer(interaction))) return;

    try {
      let player = client.kazagumo.players.get(interaction.guild.id);
      if (!player) {
        player = await client.kazagumo.createPlayer({
          guildId: interaction.guild.id,
          textId: interaction.channel.id,
          voiceId: voiceChannel.id,
          volume: 70,
          deaf: true,
        });
      }

      const result = await client.kazagumo.search(query, { requester: interaction.user });
      if (!result.tracks.length) {
        return interaction.editReply({ embeds: [errorEmbed(t(lang, 'play.no_result'))] });
      }

      if (result.type === 'PLAYLIST') {
        player.queue.add(result.tracks);
        await interaction.editReply({ embeds: [successEmbed(t(lang, 'play.playlist_added', { n: result.tracks.length, name: result.playlistName }))] });
      } else {
        player.queue.add(result.tracks[0]);
        await interaction.editReply({ embeds: [successEmbed(t(lang, 'play.added', { title: result.tracks[0].title }))] });
      }

      if (!player.playing && !player.paused) {
        player.play().catch(async (err) => {
          console.error(`[Music] Gagal memulai pemutaran di guild ${interaction.guild.id}:`, err.message);
          await interaction.followUp({ embeds: [errorEmbed(t(lang, 'play.play_fail', { err: describeError(err, lang) }))] }).catch(() => {});
        });
      }
    } catch (err) {
      console.error(`[Music] Gagal memutar query: "${query}"`);
      console.error(err);
      return interaction.editReply({ embeds: [errorEmbed(describeError(err, lang))] });
    }
  },
};
