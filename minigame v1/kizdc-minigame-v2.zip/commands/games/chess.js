const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');
const config = require('../../config.json');
const chess = require('../../utils/chessEngine');
const { renderChessBoard } = require('../../utils/chessCard');
const { pickTimeControl, collectorOptionsFor } = require('../../utils/gameTimeControl');
const { pickDifficulty } = require('../../utils/gameDifficulty');

const PIECE_NAME = { p: 'Pion', n: 'Kuda', b: 'Gajah', r: 'Benteng', q: 'Ratu', k: 'Raja' };
const GLYPH = { w: { k: '♔', q: '♕', r: '♖', b: '♗', n: '♘', p: '♙' }, b: { k: '♚', q: '♛', r: '♜', b: '♝', n: '♞', p: '♟' } };

module.exports = {
  subcommandOf: 'games',
  data: new SlashCommandBuilder()
    .setName('chess')
    .setDescription('Main Catur — lawan member lain atau lawan AI')
    .addUserOption(o => o.setName('lawan').setDescription('Member yang mau diajak main (kosongkan buat lawan AI)')),

  async execute(interaction) {
    const lang = guildLang(interaction);
    const opponent = interaction.options.getUser('lawan');
    const vsAi = !opponent;

    if (!vsAi) {
      if (opponent.bot) return interaction.reply({ embeds: [errorEmbed(t(lang, 'ch.cant_bot'))], ephemeral: true });
      if (opponent.id === interaction.user.id) return interaction.reply({ embeds: [errorEmbed(t(lang, 'ch.cant_self'))], ephemeral: true });
    }

    // ----- Pilih batas waktu per giliran dulu (20d/30d/1-10m/tanpa batas) -----
    const timeControl = await pickTimeControl(interaction, { gameTitle: 'Catur', prefix: 'chess', vsAi, opponentTag: vsAi ? null : `${opponent}` });
    if (timeControl.componentInteraction) await timeControl.componentInteraction.deferUpdate().catch(() => {});
    let challengeMsg = timeControl.message;

    // ----- Vs AI: pilih difficulty lawan (easy/medium/hard/extreme) -----
    let difficulty = { key: 'hard', label: 'Hard' };
    if (vsAi) {
      difficulty = await pickDifficulty(challengeMsg, interaction.user.id, { gameTitle: 'Catur', prefix: 'chess' });
      if (difficulty.componentInteraction) await difficulty.componentInteraction.deferUpdate().catch(() => {});
      challengeMsg = difficulty.message;
    }

    if (!vsAi) {
      // ----- Konfirmasi lawan dulu (PvP saja, AI tidak perlu konfirmasi) -----
      const challengeRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('chess_accept').setLabel(t(lang, 'ch.btn.accept')).setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('chess_decline').setLabel(t(lang, 'ch.btn.decline')).setStyle(ButtonStyle.Danger),
      );
      challengeMsg = await challengeMsg.edit({
        embeds: [new EmbedBuilder().setColor(config.embedColor).setTitle(t(lang, 'ch.challenge_title'))
          .setDescription(t(lang, 'ch.challenge_desc', { white: `${interaction.user}`, black: `${opponent}`, time: timeControl.label }))],
        components: [challengeRow],
      });
      const decision = await challengeMsg.awaitMessageComponent({ componentType: ComponentType.Button, time: 60000 }).catch(() => null);
      if (!decision || decision.customId === 'chess_decline') {
        const text = !decision ? t(lang, 'ch.declined_timeout') : t(lang, 'ch.declined', { player: `${opponent}` });
        return challengeMsg.edit({ embeds: [errorEmbed(text)], components: [] }).catch(() => {});
      }
      if (decision.user.id !== opponent.id) {
        return decision.reply({ content: t(lang, 'ch.only_challenged'), ephemeral: true });
      }
      await decision.deferUpdate();
    }

    const AI_PLAYER = { id: 'AI', username: 'AI', toString: () => '🤖 AI' };
    const players = { w: interaction.user, b: vsAi ? AI_PLAYER : opponent };
    let state = chess.initialState();
    let selected = null; // { r, c } - kotak bidak yang lagi dipilih (mode pilih tujuan)
    let finished = false;

    const statusText = () => {
      if (state.status === 'checkmate') return t(lang, 'ch.status.checkmate', { winner: `${players[state.winner]}` });
      if (state.status === 'stalemate') return t(lang, 'ch.status.stalemate');
      const turnLabel = t(lang, state.turn === 'w' ? 'ch.color.white' : 'ch.color.black');
      return `${state.status === 'check' ? t(lang, 'ch.status.check') : ''}${t(lang, 'ch.status.turn', { player: `${players[state.turn]}`, color: turnLabel })}`;
    };

    // ----- Mode 1: pilih salah satu bidak sendiri yang punya gerakan legal -----
    const buildPieceSelectButtons = () => {
      const pieces = [];
      for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) {
        const p = state.board[r][c];
        if (p && p.color === state.turn && chess.generateLegalMoves(state, r, c).length > 0) pieces.push({ r, c, p });
      }
      const rows = [];
      for (let i = 0; i < pieces.length && rows.length < 4; i += 5) {
        const row = new ActionRowBuilder();
        for (const { r, c, p } of pieces.slice(i, i + 5)) {
          row.addComponents(new ButtonBuilder().setCustomId(`chess_pick_${r}_${c}`).setLabel(`${GLYPH[p.color][p.type]} ${chess.sq(r, c)}`).setStyle(ButtonStyle.Secondary));
        }
        rows.push(row);
      }
      const metaRow = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('chess_resign').setLabel(t(lang, 'ch.btn.resign')).setStyle(ButtonStyle.Danger));
      rows.push(metaRow);
      return rows.slice(0, 5);
    };

    // ----- Mode 2: bidak sudah dipilih, pilih salah satu kotak tujuan legal -----
    const buildDestButtons = () => {
      const { r, c } = selected;
      const moves = chess.generateLegalMoves(state, r, c).slice(0, 20);
      const rows = [];
      for (let i = 0; i < moves.length && rows.length < 4; i += 5) {
        const row = new ActionRowBuilder();
        for (const m of moves.slice(i, i + 5)) {
          const label = `${m.capture ? 'x' : ''}${chess.sq(m.r, m.c)}${m.castle ? (m.castle === 'k' ? ' (O-O)' : ' (O-O-O)') : ''}`;
          row.addComponents(new ButtonBuilder().setCustomId(`chess_move_${m.r}_${m.c}`).setLabel(label).setStyle(m.capture ? ButtonStyle.Danger : ButtonStyle.Success));
        }
        rows.push(row);
      }
      rows.push(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('chess_back').setLabel(t(lang, 'ch.btn.back')).setStyle(ButtonStyle.Secondary)));
      return rows.slice(0, 5);
    };

    const legalTargetsForSelected = () => (selected ? chess.generateLegalMoves(state, selected.r, selected.c).map(m => ({ r: m.r, c: m.c })) : []);

    const renderPayload = async () => {
      const png = renderChessBoard(state, { selected, legalTargets: legalTargetsForSelected(), title: `${players.w} (${t(lang, 'ch.color.white')}) vs ${players.b} (${t(lang, 'ch.color.black')})` });
      const file = new AttachmentBuilder(png, { name: 'chess.png' });
      const embed = new EmbedBuilder().setColor(config.embedColor).setTitle(t(lang, vsAi ? 'ch.title_vs_ai' : 'ch.title')).setImage('attachment://chess.png').setDescription(statusText())
        .setFooter({ text: t(lang, 'ch.footer_time', { time: timeControl.label }) + (vsAi ? t(lang, 'ch.footer_difficulty', { level: difficulty.label }) : '') });
      const components = finished ? [] : (selected ? buildDestButtons() : buildPieceSelectButtons());
      return { embeds: [embed], files: [file], components };
    };

    const initialPayload = await renderPayload();
    const message = await challengeMsg.edit(initialPayload);

    const collector = message.createMessageComponentCollector(collectorOptionsFor(timeControl.ms));

    const maybeRunAiTurn = async () => {
      if (finished || !vsAi || state.turn !== 'b') return;
      setTimeout(async () => {
        if (finished) return;
        const mv = chess.pickAiMove(state, 'b', difficulty.key);
        if (!mv) return; // seharusnya tidak kejadian (sudah dicek checkmate/stalemate di makeMove)
        const res = chess.makeMove(state, mv.from, mv.to, 'q');
        if (res.ok) state = res.state;
        if (state.status === 'checkmate' || state.status === 'stalemate') finished = true;
        selected = null;
        await message.edit(await renderPayload()).catch(() => {});
      }, 900);
    };

    collector.on('collect', async i => {
      const currentPlayer = players[state.turn];
      if (vsAi && state.turn === 'b') return i.reply({ content: t(lang, 'ch.ai_turn'), ephemeral: true });
      if (i.user.id !== currentPlayer.id) return i.reply({ content: t(lang, 'ch.not_your_turn'), ephemeral: true });

      if (i.customId === 'chess_resign') {
        finished = true; collector.stop();
        state.status = 'checkmate'; state.winner = state.turn === 'w' ? 'b' : 'w';
        return i.update(await renderPayload());
      }
      if (i.customId === 'chess_back') {
        selected = null;
        return i.update(await renderPayload());
      }
      if (i.customId.startsWith('chess_pick_')) {
        const [, , r, c] = i.customId.split('_');
        selected = { r: parseInt(r), c: parseInt(c) };
        return i.update(await renderPayload());
      }
      if (i.customId.startsWith('chess_move_')) {
        if (!selected) return i.update(await renderPayload());
        const [, , r, c] = i.customId.split('_');
        const res = chess.makeMove(state, selected, { r: parseInt(r), c: parseInt(c) }, 'q');
        selected = null;
        if (!res.ok) return i.reply({ content: res.error || t(lang, 'ch.invalid_move'), ephemeral: true });
        state = res.state;
        if (state.status === 'checkmate' || state.status === 'stalemate') { finished = true; collector.stop(); }
        await i.update(await renderPayload());
        if (!finished) maybeRunAiTurn();
        return;
      }
    });

    collector.on('end', (collected, reason) => {
      if (!finished && (reason === 'time' || reason === 'idle')) {
        const turnLabel = t(lang, state.turn === 'w' ? 'ch.color.white' : 'ch.color.black');
        message.edit({ embeds: [new EmbedBuilder().setColor(config.embedColor).setTitle(t(lang, 'ch.title')).setDescription(t(lang, 'ch.timeout', { player: `${players[state.turn]}`, color: turnLabel }))], components: [] }).catch(() => {});
      }
    });
  },
};
