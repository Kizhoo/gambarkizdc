// ============================================================================
// /rpg — KIZHOO ADVENTURE (RPG WEB)
// ----------------------------------------------------------------------------
// Command TUNGGAL. Seluruh RPG klasik Discord (hunt, party, quest board,
// battle giliran, skill, dll) telah DIPINDAHKAN KE WEB. Command ini hanya
// menampilkan kartu pengumuman + tombol langsung ke game di browser.
//
// Tombol-tombol RPG lama yang masih menempel di pesan lama (rpg:quest:*,
// rpg:party:*, dll) di-handle di handleButton() dengan arahan ke web.
// ============================================================================
const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { baseEmbed } = require('../../utils/embeds');
const { dashboardUrl } = require('../../utils/botIntro');

function gameUrl() {
  return `${dashboardUrl().replace(/\/+$/, '')}/rpg`;
}

function gameCard() {
  return baseEmbed()
    .setTitle('Kizhoo Adventure — RPG Web')
    .setDescription(
      'Seluruh RPG klasik Discord telah **dipindahkan ke web** agar lebih cepat, halus, dan bisa dimainkan di HP maupun PC.\n\n' +
      'Akun, level, tas, dan seluruh progres lamamu tetap sama — langsung lanjut tanpa mulai dari nol.'
    )
    .addFields(
      { name: 'Petualangan', value: 'Quest beranimasi, dungeon platformer multi-lantai, monster elite, mimic, dan ruang rahasia.', inline: false },
      { name: 'Koleksi', value: 'Gacha pet (15 pet, 6 tingkat kelangkaan) + evolusi dua tahap, ratusan item dengan ikon asli, forge pandai besi.', inline: false },
      { name: 'Kompetisi', value: 'World boss mingguan, menara tanpa ujung, papan peringkat, rumah lelang antar pemain.', inline: false },
      { name: 'Sosial', value: 'Lobby multiplayer, chat, daftar teman, hadiah, dan party raid.', inline: false },
    )
    .setFooter({ text: 'Login pakai akun Discord-mu. Progres tersimpan otomatis di server.' });
}

function playRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setLabel('Mainkan di Web')
      .setStyle(ButtonStyle.Link)
      .setURL(gameUrl()),
  );
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rpg')
    .setDescription('Buka Kizhoo Adventure — seluruh RPG telah dipindahkan ke web'),
  cooldown: 2,

  async execute(interaction) {
    return interaction.reply({ embeds: [gameCard()], components: [playRow()] });
  },

  // Tombol RPG lama (quest board/battle/skill/party/hunt) yang masih ada di
  // pesan lama: balas ramah + arahkan ke web, jangan error.
  async handleButton(interaction) {
    const { baseEmbed: be } = require('../../utils/embeds');
    const embed = be()
      .setTitle('RPG telah pindah ke web')
      .setDescription(
        'Tombol RPG klasik ini sudah tidak aktif — seluruh game kini berjalan di web ' +
        'dengan grafis dan fitur yang jauh lebih lengkap. Gunakan tombol di bawah untuk membukanya.'
      );
    return interaction.reply({ embeds: [embed], components: [playRow()], ephemeral: true });
  },
};
