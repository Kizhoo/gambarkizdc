require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { REST, Routes } = require('discord.js');

const commands = [];
const commandsPath = path.join(__dirname, 'commands');
const categoryFolders = fs.readdirSync(commandsPath).filter(f =>
  fs.statSync(path.join(commandsPath, f)).isDirectory()
);

for (const category of categoryFolders) {
  const categoryPath = path.join(commandsPath, category);
  const commandFiles = fs.readdirSync(categoryPath).filter(f => f.endsWith('.js'));
  for (const file of commandFiles) {
    const command = require(path.join(categoryPath, file));
    if (command.data && command.execute && !command.subcommandOf) {
      commands.push(command.data.toJSON());
    }
  }
}

const names = commands.map(command => command.name);
const duplicate = names.find((name, index) => names.indexOf(name) !== index);
if (duplicate) throw new Error(`Nama command duplikat saat deploy: /${duplicate}`);
if (commands.length > 100) throw new Error(`Discord membatasi 100 top-level command; ditemukan ${commands.length}.`);
if (!process.env.DISCORD_TOKEN || !process.env.CLIENT_ID) {
  console.error('[deploy] DISCORD_TOKEN dan CLIENT_ID wajib diisi sebelum menjalankan npm run deploy.');
  process.exit(1);
}

const rest = new REST().setToken(process.env.DISCORD_TOKEN);

(async () => {
  try {
    console.log(`Mendaftarkan ${commands.length} slash command...`);

    let data;
    if (process.env.GUILD_ID) {
      data = await rest.put(
        Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
        { body: commands },
      );
      console.log(`Berhasil daftarkan ${data.length} command ke guild ${process.env.GUILD_ID} (instan).`);
    } else {
      data = await rest.put(
        Routes.applicationCommands(process.env.CLIENT_ID),
        { body: commands },
      );
      console.log(`Berhasil daftarkan ${data.length} command secara global (bisa butuh ~1 jam muncul).`);
    }
  } catch (error) {
    console.error('[deploy]', error);
    process.exitCode = 1;
  }
})();
