// ============================================================================
// EMOJI IMPORTER — v4 (FIX 403 Cloudflare + null crash + proxy support)
// ----------------------------------------------------------------------------
// Perbaikan:
//   1. FIX NULL CRASH: kalau emoji.gg gagal diambil (HTTP 403), semua slot tidak
//      lagi error "Cannot read properties of null (reading 'filter')".
//   2. FIX 403: emoji.gg (Cloudflare) memblokir IP server datacenter. Sekarang
//      mendukung PROXY lewat env EMOJI_PROXY_URL (atau POTOKEN_PROXY_URL).
//   3. RETRY otomatis untuk 403/429/5xx (3x dengan backoff).
//   4. User-Agent browser + Accept header bawaan (biar tidak dianggap bot).
// ============================================================================

const settings = require('./settings');

const EMOJI_GG_API = 'https://emoji.gg/api';
const DISCORD_API = 'https://discord.com/api/v10';
const MAX_EMOJI_BYTES = 256 * 1024; // 256 KiB — limit resmi Discord
const BROWSER_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

// === PROXY SUPPORT (undici ProxyAgent — sudah jadi dependency bot) ===
let _proxyAgent = null;
function getProxyAgent() {
  const proxyUrl = process.env.EMOJI_PROXY_URL
    || settings.get('emojiImporter.proxyUrl', null)
    || process.env.POTOKEN_PROXY_URL;
  if (!proxyUrl) return null;
  if (!_proxyAgent) {
    try {
      const { ProxyAgent } = require('undici');
      _proxyAgent = new ProxyAgent(proxyUrl);
      console.log(`[EmojiImport] Menggunakan proxy: ${proxyUrl}`);
    } catch (e) {
      console.warn(`[EmojiImport] Gagal init proxy (${e.message}), lanjut tanpa proxy.`);
      _proxyAgent = null;
    }
  }
  return _proxyAgent;
}

// fetch proxy-aware — fallback ke global fetch kalau undici tidak tersedia
function doFetch(url, opts = {}) {
  const agent = getProxyAgent();
  if (agent) {
    try {
      const { fetch: undiciFetch } = require('undici');
      return undiciFetch(url, { ...opts, dispatcher: agent });
    } catch { /* fallback */ }
  }
  return fetch(url, opts);
}

// === SLOT DEFAULT (reaksi/dekoratif yang ada di emoji.gg) ===
const DEFAULT_SLOTS = [
  { key: 'play',     query: 'play' },
  { key: 'sparkle',  query: 'star' },
  { key: 'heart',    query: 'heart' },
  { key: 'fire',     query: 'fire' },
  { key: 'wave',     query: 'wave' },
  { key: 'dance',    query: 'dance' },
  { key: 'cool',     query: 'cool' },
  { key: 'laugh',    query: 'laugh' },
  { key: 'yes',      query: 'yes' },
  { key: 'no',       query: 'no' },
  { key: 'party',    query: 'party' },
  { key: 'join',     query: 'join' },
  { key: 'warn',     query: 'warn' },
  { key: 'up',       query: 'up' },
];

function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }
function getConfig() { return settings.get('emojiImporter', {}); }

function sanitizeEmojiName(title, used) {
  let base = 'kz_' + title.normalize('NFKD').replace(/[^\w]/g, '').replace(/^_+|_+$/g, '');
  if (base.length < 4) base += 'emoji';
  base = base.slice(0, 32);
  let name = base, n = 1;
  while (used.has(name.toLowerCase())) {
    const suffix = String(n++);
    name = base.slice(0, 32 - suffix.length) + suffix;
  }
  used.add(name.toLowerCase());
  return name;
}

// --- Ambil daftar emoji dari emoji.gg (retry + header browser) ---
async function fetchEmojiGgList() {
  const headers = { 'User-Agent': BROWSER_UA, Accept: 'application/json' };
  let lastErr = null;
  for (let attempt = 0; attempt < 3; attempt++) {
    const res = await doFetch(EMOJI_GG_API, { headers });
    if (res.ok) return res.json();

    const blocked = res.status === 403;
    const transient = res.status === 429 || res.status >= 500;
    lastErr = new Error(
      `HTTP ${res.status}` +
      (blocked ? ' — IP server kamu di-BLOCK Cloudflare emoji.gg. Solusi: set EMOJI_PROXY_URL (proxy) di .env, atau pakai slot "url" di config.' : ''),
    );
    if (blocked || transient) {
      console.warn(`[EmojiImport] emoji.gg HTTP ${res.status} (percobaan ${attempt + 1}/3), coba lagi...`);
      await sleep(1000 * (attempt + 1));
      continue;
    }
    break;
  }
  throw lastErr || new Error('Gagal ambil data emoji.gg');
}

async function fetchExistingAppEmojis(appId, token) {
  const res = await doFetch(`${DISCORD_API}/applications/${appId}/emojis`, {
    headers: { Authorization: `Bot ${token}` },
  });
  if (!res.ok) throw new Error(`Gagal ambil daftar emoji aplikasi: HTTP ${res.status}`);
  const data = await res.json();
  return (data.items || []).map((e) => ({ id: e.id, name: e.name.toLowerCase() }));
}

async function checkRemoteSize(url) {
  try {
    const head = await doFetch(url, { method: 'HEAD' });
    const len = head.headers.get('content-length');
    if (len) return parseInt(len, 10);
  } catch { /* HEAD tidak didukung */ }
  return null;
}

async function downloadBuffer(url) {
  const res = await doFetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return Buffer.from(await res.arrayBuffer());
}

function mimeFromUrl(url) {
  const u = url.toLowerCase();
  if (u.endsWith('.gif')) return 'image/gif';
  if (u.endsWith('.png')) return 'image/png';
  if (u.endsWith('.webp')) return 'image/webp';
  if (u.endsWith('.jpg') || u.endsWith('.jpeg')) return 'image/jpeg';
  return 'image/gif';
}

async function uploadApplicationEmoji(appId, token, name, buffer, mime) {
  const base64 = buffer.toString('base64');
  const body = JSON.stringify({ name, image: `data:${mime};base64,${base64}` });
  const res = await doFetch(`${DISCORD_API}/applications/${appId}/emojis`, {
    method: 'POST',
    headers: { Authorization: `Bot ${token}`, 'Content-Type': 'application/json' },
    body,
  });
  if (res.status === 429) {
    const data = await res.json().catch(() => ({}));
    const retryMs = (data.retry_after ?? 1) * 1000 + 200;
    await sleep(retryMs);
    return uploadApplicationEmoji(appId, token, name, buffer, mime);
  }
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${await res.text().catch(() => '')}`);
  return res.json();
}

// --- Cari + pilih GIF terbaik (FIX: aman kalau allEmojis null) ---
async function findBestGif(allEmojis, query, limit) {
  if (!Array.isArray(allEmojis)) return []; // ← guard: emoji.gg gagal diambil
  const words = query.toLowerCase().split(/\s+/).filter(Boolean);
  const matches = allEmojis.filter((e) => {
    if (!e.image || !String(e.image).toLowerCase().endsWith('.gif')) return false;
    const haystack = `${e.title || ''} ${e.description || ''}`.toLowerCase();
    return words.every((w) => haystack.includes(w));
  });
  const scored = matches.map((e) => ({ e, pop: Number(e.faves || 0) })).sort((a, b) => b.pop - a.pop);
  return scored.slice(0, limit).map((x) => x.e);
}

// ============================================================================
// IMPORT SATU SLOT (query ATAU url)
// ============================================================================
async function importSlot({ slot, allEmojis, appId, token, limit, delayMs, existingNames }) {
  // --- Slot URL langsung (tidak tergantung emoji.gg) ---
  if (slot.url) {
    const knownSize = await checkRemoteSize(slot.url);
    if (knownSize && knownSize > MAX_EMOJI_BYTES) return { status: 'skip', reason: '>256KB' };
    let buffer;
    try { buffer = await downloadBuffer(slot.url); }
    catch (err) { return { status: 'fail', reason: `gagal download: ${err.message}` }; }
    if (buffer.length > MAX_EMOJI_BYTES) return { status: 'skip', reason: '>256KB' };

    const name = sanitizeEmojiName(slot.key, existingNames);
    try {
      const uploaded = await uploadApplicationEmoji(appId, token, name, buffer, mimeFromUrl(slot.url));
      return { status: 'ok', emojiTag: `<a:${name}:${uploaded.id}>`, kb: buffer.length / 1024 };
    } catch (err) {
      return { status: 'fail', reason: err.message };
    }
  }

  // --- Slot query (search emoji.gg) ---
  if (!slot.query) return { status: 'skip', reason: 'no query/url' };
  if (!Array.isArray(allEmojis)) return { status: 'fail', reason: 'emoji.gg tidak bisa diambil (lihat error di atas — coba proxy)' };

  let candidates;
  try { candidates = await findBestGif(allEmojis, slot.query, limit); }
  catch (err) { return { status: 'fail', reason: err.message }; }

  if (!candidates.length) return { status: 'fail', reason: `tidak ada hasil untuk "${slot.query}"` };

  const usedNames = new Set(existingNames);
  for (const cand of candidates) {
    const knownSize = Number(cand.filesize || 0);
    if (knownSize > MAX_EMOJI_BYTES) continue;
    if (!knownSize) {
      const hs = await checkRemoteSize(cand.image);
      if (hs && hs > MAX_EMOJI_BYTES) continue;
    }
    let buffer;
    try { buffer = await downloadBuffer(cand.image); } catch { continue; }
    if (buffer.length > MAX_EMOJI_BYTES) continue;

    const name = sanitizeEmojiName(cand.title || slot.key, usedNames);
    try {
      const uploaded = await uploadApplicationEmoji(appId, token, name, buffer, 'image/gif');
      return { status: 'ok', emojiTag: `<a:${name}:${uploaded.id}>`, kb: buffer.length / 1024 };
    } catch (err) {
      await sleep(delayMs);
      continue;
    }
  }
  return { status: 'fail', reason: 'semua kandidat gagal upload' };
}

// ============================================================================
// FUNGSI UTAMA
// ============================================================================
async function runEmojiImport(client, opts = {}) {
  const cfg = getConfig();
  const enabled = opts.enabled ?? cfg.enabled ?? true;
  if (!enabled) {
    console.log('[EmojiImport] Dinonaktifkan (emojiImporter.enabled = false).');
    return { success: false, skipped: true, reason: 'disabled' };
  }

  const token = process.env.DISCORD_TOKEN;
  const appId = process.env.DISCORD_APPLICATION_ID;
  if (!token || !appId) {
    console.warn('[EmojiImport] DISCORD_TOKEN / DISCORD_APPLICATION_ID belum diisi — importer dilewati.');
    return { success: false, skipped: true, reason: 'no-credentials' };
  }

  const slots = opts.slots || cfg.slots || DEFAULT_SLOTS;
  const limit = opts.limit ?? cfg.limitPerQuery ?? 3;
  const delayMs = opts.delayMs ?? cfg.delayMs ?? 500;

  console.log(`[EmojiImport] Mulai impor ${slots.length} slot emoji...`);

  let allEmojis = null;
  try { allEmojis = await fetchEmojiGgList(); }
  catch (err) {
    console.error(`[EmojiImport] ⚠️ Gagal ambil data emoji.gg: ${err.message}`);
    console.error(`[EmojiImport] Slot "url" tetap diproses, slot "query" dilewati.`);
  }

  let existing = [];
  try { existing = await fetchExistingAppEmojis(appId, token); }
  catch (err) { console.warn(`[EmojiImport] Tidak bisa cek emoji existing: ${err.message}`); }
  const existingNames = new Set(existing.map((e) => e.name));

  let imported = 0, skipped = 0, failed = 0;

  for (const slot of slots) {
    const alreadyMapped = settings.get(`emojis.${slot.key}`, null);
    if (alreadyMapped && /^<a?:/.test(alreadyMapped)) {
      console.log(`[EmojiImport] ${slot.key}: sudah dipetakan, skip.`);
      skipped++;
      continue;
    }

    const r = await importSlot({ slot, allEmojis, appId, token, limit, delayMs, existingNames });
    if (r.status === 'ok') {
      settings.set(`emojis.${slot.key}`, r.emojiTag);
      existingNames.add(r.emojiTag.slice(r.emojiTag.indexOf(':') + 1, r.emojiTag.lastIndexOf(':')));
      console.log(`[EmojiImport] ${slot.key}: ✅ ${r.emojiTag} (${r.kb.toFixed(1)} KB)`);
      imported++;
    } else if (r.status === 'skip') {
      console.log(`[EmojiImport] ${slot.key}: ⏭️ ${r.reason}`);
      skipped++;
    } else {
      console.log(`[EmojiImport] ${slot.key}: ❌ ${r.reason}`);
      failed++;
    }
  }

  const summary = { imported, skipped, failed };
  console.log(`[EmojiImport] Selesai — impor: ${imported}, skip: ${skipped}, gagal: ${failed}.`);
  return { success: true, ...summary };
}

// ============================================================================
// AUTO-RUN SAAT STARTUP
// ============================================================================
function initEmojiImporter(client) {
  const cfg = getConfig();
  if (cfg.autoRunOnStartup === false) {
    console.log('[EmojiImport] autoRunOnStartup = false — tidak jalan otomatis.');
    return;
  }
  const delay = Number(cfg.startupDelayMs || 20000);
  setTimeout(() => {
    runEmojiImport(client).catch((e) => console.error('[EmojiImport] Error:', e.message));
  }, delay);
}

// --- Support jalan manual ---
if (require.main === module) {
  (async () => {
    const argv = process.argv.slice(2);
    const qIdx = argv.indexOf('--query');
    const query = qIdx >= 0 ? argv[qIdx + 1] : null;
    if (query) {
      const all = await fetchEmojiGgList().catch((e) => { console.error('Gagal ambil emoji.gg:', e.message); process.exit(1); });
      const found = await findBestGif(all, query, 10);
      console.log(`Hasil "${query}":`);
      found.forEach((e) => console.log(` - ${e.title}  ${e.image}`));
    } else {
      runEmojiImport(null).then((r) => console.log('Hasil:', JSON.stringify(r)));
    }
  })();
}

// ============================================================================
// IMPORT BULK BERDASARKAN KATA KUNCI (buat command /emoji import)
// ============================================================================
function _credentials() {
  const token = process.env.DISCORD_TOKEN;
  const appId = process.env.DISCORD_APPLICATION_ID;
  if (!token || !appId) throw new Error('DISCORD_TOKEN / DISCORD_APPLICATION_ID belum diisi di .env');
  return { token, appId };
}

async function importByKeyword(query, limit = 10) {
  const { token, appId } = _credentials();
  const all = await fetchEmojiGgList();
  const candidates = await findBestGif(all, query, limit);
  if (!candidates.length) return { query, imported: [], failed: [`Tidak ada GIF cocok untuk "${query}"`] };

  const existing = await fetchExistingAppEmojis(appId, token);
  const usedNames = new Set(existing.map((e) => e.name));

  const imported = [], failed = [];
  for (const cand of candidates) {
    const knownSize = Number(cand.filesize || 0);
    if (knownSize > MAX_EMOJI_BYTES) { failed.push(`${cand.title} (terlalu besar)`); continue; }
    let buffer;
    try { buffer = await downloadBuffer(cand.image); }
    catch { failed.push(`${cand.title} (gagal download)`); continue; }
    if (buffer.length > MAX_EMOJI_BYTES) { failed.push(`${cand.title} (terlalu besar)`); continue; }

    const name = sanitizeEmojiName(cand.title || query, usedNames);
    try {
      const up = await uploadApplicationEmoji(appId, token, name, buffer, 'image/gif');
      imported.push({ name, tag: `<a:${name}:${up.id}>` });
    } catch (err) {
      failed.push(`${name} (${err.message})`);
    }
  }
  return { query, imported, failed };
}

async function importFromUrl(url, name) {
  const { token, appId } = _credentials();
  const buffer = await downloadBuffer(url);
  if (buffer.length > MAX_EMOJI_BYTES) throw new Error(`Gambar terlalu besar (${(buffer.length / 1024).toFixed(1)}KB > 256KB)`);
  const existing = await fetchExistingAppEmojis(appId, token);
  const usedNames = new Set(existing.map((e) => e.name));
  const finalName = sanitizeEmojiName(name, usedNames);
  const up = await uploadApplicationEmoji(appId, token, finalName, buffer, mimeFromUrl(url));
  return { name: finalName, tag: `<a:${finalName}:${up.id}>` };
}

async function listAppEmojis() {
  const { token, appId } = _credentials();
  const items = await fetchExistingAppEmojis(appId, token);
  return items.map((e) => ({ name: e.name, id: e.id, tag: `<a:${e.name}:${e.id}>` }));
}

module.exports = {
  initEmojiImporter,
  runEmojiImport,
  findBestGif,
  importSlot,
  importByKeyword,
  importFromUrl,
  listAppEmojis,
  DEFAULT_SLOTS,
};
