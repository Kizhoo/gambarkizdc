const { SlashCommandBuilder } = require('discord.js');
const { getValidPlayer, safePlayerAction } = require('../../utils/musicGuard');
const { successEmbed } = require('../../utils/embeds');
const { clearIdleTimeout } = require('../../utils/nowPlayingCard');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder().setName('stop').setDescription('Hentikan musik dan keluar dari voice channel'),
  async execute(interaction, client) {
    const lang = guildLang(interaction);
    const player = await getValidPlayer(interaction, client);
    if (!player) return;

    clearIdleTimeout(player);
    return safePlayerAction(interaction, () => player.destroy(), { embeds: [successEmbed(t(lang, 'music.stopped'))] });
  },
};
