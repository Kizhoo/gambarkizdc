const { errorEmbed, baseEmbed } = require('./embeds');
const { buildNowPlayingPayload, stopLiveUpdate, clearIdleTimeout } = require('./nowPlayingCard');
const { formatDuration } = require('./musicFormat');

// Tombol Jeda/Vol/Loop sekarang UPDATE KARTU YANG SAMA di tempat (interaction.update() dengan
// kartu yang di-render ulang), BUKAN ngirim pesan notifikasi terpisah kayak sebelumnya
// ("Volume diatur ke 80% oleh @user" dst) - biar channel-nya gak penuh pesan berulang, dan info
// yang keliatan SELALU representasi state terkini (auto-update), bukan snapshot pas diklik doang.
async function handleMusicButton(interaction, client) {
  const player = client.kazagumo.players.get(interaction.guild.id);
  if (!player) {
    return interaction.reply({ embeds: [errorEmbed('Tidak ada musik yang sedang diputar.')], ephemeral: true });
  }

  const voiceChannel = interaction.member.voice.channel;
  if (!voiceChannel || voiceChannel.id !== player.voiceId) {
    return interaction.reply({ embeds: [errorEmbed('Kamu harus ada di voice channel yang sama dengan bot untuk pakai tombol ini.')], ephemeral: true });
  }

  const action = interaction.customId.replace('music_', '');

  // Tombol ini SEBELUMNYA tidak ada satu pun yang menangkap kegagalan aksi player (mis. node
  // Lavalink lagi mati/timeout) - errornya cuma nyangkut jadi unhandled rejection di console
  // server, sementara di Discord tombolnya kelihatan "nge-freeze"/tidak merespons sama sekali
  // tanpa penjelasan. Sekarang semua dibungkus try/catch dengan pesan yang jelas.
  try {
    if (action === 'skip') {
      if (player.queue.length === 0) {
        return interaction.reply({ embeds: [errorEmbed('Tidak ada lagu selanjutnya di antrian.')], ephemeral: true });
      }
      const skippedTitle = player.queue.current?.title || 'lagu ini';
      await player.skip();
      // Kartu track LAMA jadi basi begitu di-skip - tandai jelas + copot tombolnya (kartu buat
      // track BERIKUTNYA otomatis muncul terpisah lewat event playerStart).
      return interaction.update({
        embeds: [baseEmbed().setTitle('⏭️ Dilewati').setDescription(`**${skippedTitle}** dilewati oleh ${interaction.user}. Lanjut ke lagu berikutnya...`)],
        components: [],
      });
    }

    if (action === 'stop') {
      stopLiveUpdate(player);
      clearIdleTimeout(player);
      await player.destroy();
      return interaction.update({ content: `⏹️ Musik dihentikan oleh ${interaction.user}.`, embeds: [], components: [] });
    }

    // Tombol Jeda/Vol/Loop butuh re-render kartu (canvas, async) sebelum bisa ditampilkan -
    // deferUpdate() dulu di sini biar interaction token Discord (~3 detik) tidak keburu expired
    // kalau render/interpolasi-nya butuh waktu sedikit lebih lama, baru editReply pas kartunya siap.
    if (action === 'pause') {
      await player.pause(!player.paused);
      await interaction.deferUpdate();
      return interaction.editReply(await buildNowPlayingPayload(player, player.queue.current));
    }

    if (action === 'voldown' || action === 'volup') {
      const delta = action === 'volup' ? 10 : -10;
      const newVolume = Math.max(0, Math.min(100, player.volume + delta));
      await player.setVolume(newVolume);
      await interaction.deferUpdate();
      return interaction.editReply(await buildNowPlayingPayload(player, player.queue.current));
    }

    if (action === 'loop') {
      if (typeof player.setLoop !== 'function') {
        return interaction.reply({ embeds: [errorEmbed('Fitur loop tidak tersedia di versi library musik saat ini.')], ephemeral: true });
      }
      const order = ['none', 'track', 'queue'];
      const next = order[(order.indexOf(player.loop) + 1) % order.length];
      await player.setLoop(next);
      await interaction.deferUpdate();
      return interaction.editReply(await buildNowPlayingPayload(player, player.queue.current));
    }

    if (action === 'shuffle') {
      if (player.queue.length < 3) return interaction.reply({ embeds: [errorEmbed('Antrian terlalu pendek untuk diacak.')], ephemeral: true });
      if (typeof player.queue.shuffle !== 'function') {
        return interaction.reply({ embeds: [errorEmbed('Fitur shuffle tidak tersedia di versi library musik saat ini.')], ephemeral: true });
      }
      player.queue.shuffle();
      return interaction.reply({ content: `🔀 Antrian diacak oleh ${interaction.user}.`, ephemeral: true });
    }

    if (action === 'queue') {
      const current = player.queue.current;
      const upcoming = player.queue.slice(0, 10);
      const lines = [];
      if (current) lines.push(`Sedang diputar: **${current.title}** \`${formatDuration(current.length)}\``);
      upcoming.forEach((track, i) => lines.push(`${i + 1}. **${track.title}** \`${formatDuration(track.length)}\``));
      if (lines.length === 0) lines.push('Antrian kosong.');
      return interaction.reply({
        embeds: [baseEmbed().setTitle('📜 Antrian Musik').setDescription(lines.join('\n')).setFooter({ text: `Total di antrian: ${player.queue.length} lagu | Volume: ${player.volume}%` })],
        ephemeral: true,
      });
    }
  } catch (err) {
    console.error(`[Music] Tombol "${action}" gagal di guild ${interaction.guild.id}:`, err.message);
    const cause = (err?.cause?.message || err?.cause?.code || '').toLowerCase();
    const rawMsg = (err.message || '').toLowerCase();
    // "youtube extraction failed"/"piped instances" itu masalah config Lavalink SERVER (source
    // plugin-nya), BUKAN node yang gak bisa dihubungi - dicek DULU sebelum cek "fetch failed"
    // generik, soalnya pesan errornya juga kebetulan mengandung frasa "fetch failed" di dalamnya
    // (bakal salah diagnosis "node mati" kalau urutannya kebalik).
    let msg;
    if (rawMsg.includes('youtube extraction failed') || rawMsg.includes('piped instances')) {
      msg = 'Node musik ini gagal ambil audio dari YouTube (server Lavalink-nya yang perlu dibenerin, bukan bot). Coba lagu dari Spotify/SoundCloud dulu.';
    } else if (cause.includes('timeout') || cause.includes('econnrefused') || cause.includes('enotfound') || rawMsg.includes('fetch failed')) {
      msg = 'Node musik (Lavalink) yang lagi dipakai tidak bisa dihubungi (mati/timeout). Coba lagi sebentar lagi.';
    } else {
      msg = `Gagal menjalankan aksi ini: ${err.message?.slice(0, 200) || 'error tidak diketahui'}`;
    }
    const payload = { embeds: [errorEmbed(msg)], ephemeral: true };
    return (interaction.replied || interaction.deferred ? interaction.followUp(payload) : interaction.reply(payload)).catch(() => {});
  }
}

module.exports = { handleMusicButton };
