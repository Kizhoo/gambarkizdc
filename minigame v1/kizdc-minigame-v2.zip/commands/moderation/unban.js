const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('Unban user berdasarkan User ID')
    .addStringOption(o => o.setName('user_id').setDescription('ID user yang akan diunban').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const userId = interaction.options.getString('user_id');

    try {
      const banInfo = await interaction.guild.bans.fetch(userId);
      if (!banInfo) return interaction.reply({ embeds: [errorEmbed(t(lang, 'mod.unban_none'))], ephemeral: true });

      await interaction.guild.members.unban(userId);
      return interaction.reply({ embeds: [successEmbed(t(lang, 'mod.unban_ok', { user: banInfo.user.tag }))] });
    } catch (err) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'mod.unban_fail'))], ephemeral: true });
    }
  },
};
