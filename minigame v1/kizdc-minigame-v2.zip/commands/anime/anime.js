const { SlashCommandBuilder } = require('discord.js');
const { getTodaySchedule, getCurrentSeason, searchAnime } = require('../../utils/animeApi');
const { todayScheduleEmbed, seasonEmbed, searchResultEmbed } = require('../../utils/animeFormat');
const { errorEmbed } = require('../../utils/embeds');
const { safeDefer } = require('../../utils/interactionHelpers');
const settings = require('../../utils/settings');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('anime')
    .setDescription('Update anime: jadwal tayang, anime musim ini, dan pencarian')
    .addSubcommand(sub => sub.setName('today').setDescription('Jadwal anime yang tayang hari ini'))
    .addSubcommand(sub => sub.setName('season').setDescription('Anime yang lagi tayang musim ini')
      .addIntegerOption(o => o.setName('halaman').setDescription('Nomor halaman (default 1)').setMinValue(1)))
    .addSubcommand(sub => sub.setName('cari').setDescription('Cari anime berdasarkan judul')
      .addStringOption(o => o.setName('judul').setDescription('Judul anime yang dicari').setRequired(true))),

  async execute(interaction) {
    const lang = guildLang(interaction);
    const sub = interaction.options.getSubcommand();
    if (!(await safeDefer(interaction))) return;
    const maxItems = settings.get('anime.maxItemsPerDigest', 10);

    try {
      if (sub === 'today') {
        const result = await getTodaySchedule({ limit: maxItems });
        return interaction.editReply({ embeds: [todayScheduleEmbed(result, { maxItems })] });
      }
      if (sub === 'season') {
        const page = interaction.options.getInteger('halaman') || 1;
        const result = await getCurrentSeason({ limit: maxItems, page });
        return interaction.editReply({ embeds: [seasonEmbed(result, { maxItems, page })] });
      }
      if (sub === 'cari') {
        const query = interaction.options.getString('judul');
        const results = await searchAnime(query, { limit: 5 });
        return interaction.editReply({ embeds: [searchResultEmbed(query, results)] });
      }
    } catch (err) {
      console.error('[anime] Gagal:', err.message);
      return interaction.editReply({ embeds: [errorEmbed(t(lang, 'anime.fail', { err: err.message }))] }).catch(() => {});
    }
  },
};
