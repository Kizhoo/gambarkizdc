// ============================================================================
// DASHBOARD KIZHOOBOT — server web + WebSocket (fase 1 / fondasi)
// ----------------------------------------------------------------------------
// Fitur fase 1:
//   - Login pakai token (DASHBOARD_TOKEN di .env)
//   - Kirim chat sebagai bot (tanpa prefix, apa adanya)
//   - TTS: bot join voice channel lalu "bicara" sesuai teks yang diketik
//   - Monitoring pesan real-time (teks/embed/stiker/gambar/gif/tombol)
//   - Status voice channel real-time (siapa di VC + indikator bicara)
//
// Cara jalan: bot dan dashboard di SATU proses Node.js (startDashboard dipanggil
// dari index.js). Komunikasi frontend <-> bot lewat REST + WebSocket.
// ============================================================================
const http = require('http');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const express = require('express');
const { WebSocketServer } = require('ws');
const { playTts } = require('./tts');
const { startListening, stopListening, isListening } = require('./listen');
const settings = require('../utils/settings');
const { getGuildConfig, updateGuildConfig, listUsers, countUsers, getUser, getEconomy, getEconomyLeaderboard, getLevelLeaderboard, getActiveGiveaways, getWarnings, getLevel, getUserProfile, updateBalance, updateBank, setUserBanned, deleteUser, setUserField, resetEconomyForGuild, db, getWatchlist, toggleWatchlistItem } = require('../database/db');
const rpgDb = require('../database/rpgDb');
const { getCommandCounts, getTotalExecuted } = require('../utils/analytics');
const economyEngine = require('../utils/economyEngine');
const econDb = require('../database/economyDb');
const orderbook = require('../utils/orderbook');
const tradeSystem = require('../utils/tradeSystem');
const shopManager = require('../utils/shopManager');
const kizco = require('../utils/kizco');
const { bankDeposit, bankWithdraw } = require('../utils/economyActions');
const marketEngine = require('../utils/marketEngine');
const { INSTRUMENTS, instrumentById, BANK_STOCK_ID } = require('../utils/instruments');

// ============================================================================
// INSTRUMEN TRADING — forex / indeks / saham sintetis buat web trading.
// ----------------------------------------------------------------------------
// Harga digerakkan oleh utils/marketEngine.js (ekonomi internal + supply/demand
// + market regime + OHLCV persisten). Fungsi di bawah adalah ADAPTER tipis supaya
// route API existing tetap kompatibel (backward compatible).
// ============================================================================

// Resolusi candle per timeframe (satu sumber kebenaran dari marketEngine).
const TF_BUCKET = marketEngine.TF_BUCKET;
const TF_COUNT = 260;

function instrumentPrice(guildId, id) {
  if (!instrumentById(id)) return null;
  return marketEngine.getPrice(guildId, id);
}
function instrumentStats24h(guildId, id) {
  const st = marketEngine.getStats24h(guildId, id);
  return { price: marketEngine.getPrice(guildId, id), change24hPct: st.change24hPct, high24h: st.high24h, low24h: st.low24h, volume24h: st.volume24h };
}
function buildInstrumentCandles(guildId, id, count = 300, bucketMs = 300000) {
  const tf = Object.keys(TF_BUCKET).find(k => TF_BUCKET[k] === bucketMs) || '5m';
  return marketEngine.getCandles(guildId, id, tf, count);
}
function buildInstrumentBook(guildId, id) {
  return marketEngine.getOrderBook(guildId, id);
}
function buildInstrumentFills(guildId, id, count = 30) {
  // Fills NYATA dari econ_fills (kosong sampai ada trade sungguhan — jujur, bukan fabrikasi).
  return econDb.listRecentFills(guildId, id, count).map(f => ({ timestamp: f.timestamp, price: f.price, qty: f.qty, amount: f.amount }));
}

// --- Cache daftar guild/channel biar frontend bisa pilih tanpa fetch manual ---
// --- Cache invite guild (biar halaman peringkat server bisa kasih link join) ---
const inviteCache = new Map(); // guildId -> { url, ts }
async function getGuildInvite(guild) {
  const cached = inviteCache.get(guild.id);
  if (cached && Date.now() - cached.ts < 10 * 60000) return cached.url;
  let url = null;
  try {
    const invites = await guild.invites.fetch().catch(() => null);
    const first = invites && invites.size ? invites.first() : null;
    if (first) url = first.url || `https://discord.gg/${first.code}`;
  } catch (_) {}
  inviteCache.set(guild.id, { url, ts: Date.now() });
  return url;
}
function serializeGuilds(client) {
  return client.guilds.cache.map((g) => ({
    id: g.id,
    name: g.name,
    icon: g.iconURL({ size: 128 }) || null,
    channels: g.channels.cache
      .filter((c) => c.type === 0) // text channel
      .map((c) => ({ id: c.id, name: c.name })),
    voiceChannels: g.channels.cache
      .filter((c) => c.type === 2) // voice channel
      .map((c) => ({ id: c.id, name: c.name })),
  }));
}

function startDashboard(client) {
  const app = express();

  // ===== SECURITY SUITE (lapisan 1-8: headers, host/origin lock, WAF, rate
  // limit, honeypot, blocklist, scrub prototype-pollution) — lihat utils/security.js =====
  const Sec = require('../utils/security');
  Sec.applySecurity(app, { rpgDb });
  Sec.startJanitor(rpgDb);

  // gzip semua respons (rpg.min.js 330 KB -> ~90 KB di kabel).
  app.use(require('compression')());

  app.use(express.json({ limit: '256kb' }));
  app.use(Sec.scrubBody); // scrub ulang SETELAH parser JSON jalan

  // --- security-lock.js dinamis: identitas domain resmi disuntik ke client
  // (anti-klon lapis client). Rute ini didaftarkan SEBELUM static supaya menang.
  app.get('/security-lock.js', (req, res) => {
    try {
      let js = fs.readFileSync(path.join(__dirname, 'public', 'security-lock.js'), 'utf8');
      js = js.replace('window.__KZ_SEC_CFG = null;',
        'window.__KZ_SEC_CFG = ' + JSON.stringify(Sec.manifestPayload()).replace(/</g, '\\u003c') + ';');
      res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
      res.setHeader('Cache-Control', 'no-store');
      return res.send(js);
    } catch (_) { return res.status(404).end(); }
  });

  // --- Manifest domain resmi (dibaca security-lock.js bila fetch berhasil).
  app.get('/api/security/manifest', (req, res) => res.json(Sec.manifestPayload()));

  // --- Status keamanan (khusus owner: session OAuth == OWNER_ID atau token).
  app.get('/api/security/status', (req, res) => {
    const sid = parseCookies(req).kz_sid;
    const session = sid ? rpgDb.getSession(sid) : null;
    const isOwner = (session && process.env.OWNER_ID && session.userId === process.env.OWNER_ID) ||
      (TOKEN && Sec.safeEqual(req.headers['authorization'] || '', `Bearer ${TOKEN}`));
    if (!isOwner) return res.status(403).json({ error: 'Khusus owner.' });
    return res.json({
      official: Sec.OFFICIAL_URL,
      allowedHosts: [...Sec.ALLOWED_HOSTS],
      stats: rpgDb.getSecurityStats(),
    });
  });

  // --- Aset: cache panjang + anti-hotlink. Halaman HTML tetap no-store.
  app.use('/assets', Sec.hotlinkGuard, express.static(path.join(__dirname, 'public', 'assets'), {
    maxAge: '7d', immutable: true,
  }));
  app.use(express.static(path.join(__dirname, 'public'), {
    setHeaders: (res, p) => {
      if (String(p).endsWith('.html')) res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
    },
  }));

  // ===== REST publik (tanpa auth) — buat halaman landing/info bot =====
  app.get('/api/public/stats', (req, res) => {
    const totalMembers = client.guilds.cache.reduce((n, g) => n + (g.memberCount || 0), 0);
    const clientId = process.env.DISCORD_CLIENT_ID || process.env.DISCORD_APPLICATION_ID || '';

    // Sosmed publik — hanya dikirim kalau diisi di config.json (`social.*`), supaya
    // frontend bisa sembunyikan bagian sosmed sama sekali kalau owner belum isi apa-apa
    // (bukan nampilin ikon mati ke link kosong).
    const socialCfg = settings.get('social', {}) || {};
    const social = {};
    for (const k of ['instagram', 'x', 'youtube', 'tiktok', 'website', 'github']) {
      if (socialCfg[k] && String(socialCfg[k]).trim()) social[k] = String(socialCfg[k]).trim();
    }
    const discordInvite = settings.get('supportServerInvite', '');
    if (discordInvite && String(discordInvite).trim()) social.discord = String(discordInvite).trim();

    // Link vote DiscordBotList & top.gg — diturunkan otomatis dari Discord application ID
    // (dipakai kedua situs sebagai ID bot di URL), null kalau ID belum diset supaya halaman
    // /vote juga bisa nampilin fallback yang jujur alih-alih tombol mati.
    const voteLinks = clientId ? {
      topgg: `https://top.gg/bot/${clientId}/vote`,
      discordbotlist: `https://discordbotlist.com/bots/${clientId}/upvote`,
    } : null;

    return res.json({
      botName: client.user?.username || 'KizhooBot',
      avatar: client.user?.displayAvatarURL({ size: 256 }) || null,
      guilds: client.guilds.cache.size,
      users: client.users.cache.size,
      totalMembers,
      commands: client.commands?.size || 0,
      uptimeSeconds: Math.floor(process.uptime()),
      ping: client.ws.ping,
      inviteUrl: clientId ? `https://discord.com/oauth2/authorize?client_id=${clientId}&permissions=8&scope=bot%20applications.commands` : null,
      social: Object.keys(social).length ? social : null,
      voteLinks,
    });
  });
  app.get('/api/public/guilds', (req, res) => {
    return res.json(client.guilds.cache.map(g => ({ id: g.id, name: g.name })));
  });

  // Peringkat server publik (economy terbaik) + info profil server.
  app.get('/api/public/servers', async (req, res) => {
    try {
      const list = await Promise.all(client.guilds.cache.map(async (g) => {
        let s = { health: 0, priceIndex: 100, inflationPct: 0, moneySupply: 0, phaseLabel: 'Ekspansi', phase: 'expansion', cycle: 0 };
        try { s = economyEngine.summary(g.id); } catch (_) {}
        const rank = economyEngine.rankScore(s, g.memberCount || 0);
        return {
          id: g.id, name: g.name, icon: g.iconURL({ size: 128 }) || null,
          members: g.memberCount || 0,
          priceIndex: Number(s.priceIndex || 0), inflationPct: Number(s.inflationPct || 0),
          moneySupply: Number(s.moneySupply || 0), health: Number(s.health || 0), phase: s.phaseLabel || 'Ekspansi',
          score: rank.score, stability: rank.stability, activity: rank.activity,
          community: rank.community, maturity: rank.maturity,
          invite: await getGuildInvite(g),
        };
      }));
      list.sort((a, b) => (b.score || 0) - (a.score || 0) || (b.moneySupply || 0) - (a.moneySupply || 0));
      return res.json({ servers: list });
    } catch (_) { return res.json({ servers: [] }); }
  });
  app.get('/api/public/server/:guildId', async (req, res) => {
    const g = client.guilds.cache.get(req.params.guildId);
    if (!g) return res.status(404).json({ error: 'Server tidak ditemukan' });
    let s = { health: 0, priceIndex: 100, inflationPct: 0, moneySupply: 0, phaseLabel: 'Ekspansi', phase: 'expansion', cycle: 0, rewardMultiplier: 1, taxRatePct: 0, bankInterestRatePct: 0 };
    try { s = economyEngine.summary(g.id); } catch (_) {}
    const rank = economyEngine.rankScore(s, g.memberCount || 0);
    return res.json({
      id: g.id, name: g.name, icon: g.iconURL({ size: 256 }) || null,
      members: g.memberCount || 0, description: g.description || null,
      invite: await getGuildInvite(g),
      economy: {
        priceIndex: Number(s.priceIndex || 0), inflationPct: Number(s.inflationPct || 0),
        moneySupply: Number(s.moneySupply || 0), health: Number(s.health || 0), phase: s.phaseLabel || 'Ekspansi',
        rewardMultiplier: Number(s.rewardMultiplier || 1), taxRatePct: Number(s.taxRatePct || 0),
        bankInterestRatePct: Number(s.bankInterestRatePct || 0), cycle: Number(s.cycle || 0),
        score: rank.score, stability: rank.stability, activity: rank.activity,
        community: rank.community, maturity: rank.maturity,
      },
    });
  });

  // Root = halaman landing (index.html). Dashboard admin disembunyikan di /panel.
  app.get('/panel', (req, res) => res.sendFile(path.join(__dirname, 'public', 'dashboard.html')));
  // Halaman market/aset (terpisah dari terminal trading).
  app.get('/market', (req, res) => res.sendFile(path.join(__dirname, 'public', 'market.html')));
  // Terminal trading (URL bersih tanpa .html; /trade.html tetap jalan via static utk backward compat).
  app.get('/trade', (req, res) => res.sendFile(path.join(__dirname, 'public', 'trade.html')));
  // Halaman peringkat server publik.
  app.get('/servers', (req, res) => res.sendFile(path.join(__dirname, 'public', 'servers.html')));
  // Halaman profil user (foto profil + info lengkap).
  app.get('/profile', (req, res) => res.sendFile(path.join(__dirname, 'public', 'profile.html')));
  // Halaman vote DiscordBotList & top.gg.
  app.get('/vote', (req, res) => res.sendFile(path.join(__dirname, 'public', 'vote.html')));

  const PORT = Number(process.env.DASHBOARD_PORT || 3000);
  const TOKEN = process.env.DASHBOARD_TOKEN || '';

  // ===== OAuth2 Discord (opsional, butuh domain + redirect URL) =====
  const CLIENT_ID = process.env.DISCORD_CLIENT_ID || process.env.DISCORD_APPLICATION_ID || '';
  const CLIENT_SECRET = process.env.DISCORD_CLIENT_SECRET || '';
  // Normalisasi redirect URI biar tidak "malformed": tambah scheme kalau lupa,
  // buang spasi & trailing slash. Ini penyebab umum error "URL tidak terbentuk
  // dengan baik" kalau user isi domain tanpa https:// atau ada typo.
  function normalizeRedirectUri(uri, fallback) {
    let u = String(uri || '').trim();
    if (!u) u = fallback;
    if (!/^https?:\/\//i.test(u)) u = 'https://' + u;
    return u.replace(/\/+$/, '');
  }
  const REDIRECT_URI = normalizeRedirectUri(process.env.DASHBOARD_REDIRECT_URL, `http://localhost:${PORT}/auth/callback`);
  // SESSION PERSIST (SQLite) — dulu cuma Map di memori, jadi tiap bot restart
  // semua user "ke-logout" padahal cookienya masih ada (ini penyebab utama
  // "login Discord di web gak nempel & RPG mulai dari awal terus"). Sekarang
  // session disimpan di tabel dashboard_sessions dan tahan restart.
  const sessions = {
    has(sid) { return !!rpgDb.getSession(sid); },
    get(sid) { return rpgDb.getSession(sid); },
    set(sid, data) { rpgDb.saveSession(sid, data); },
    delete(sid) { rpgDb.deleteSession(sid); },
  };
  // Bersihkan session kedaluwarsa tiap 6 jam.
  setInterval(() => { try { rpgDb.cleanExpiredSessions(); } catch (_) {} }, 6 * 3600 * 1000).unref();

  function parseCookies(req) {
    const c = {};
    (req.headers.cookie || '').split(';').forEach((p) => {
      const i = p.indexOf('=');
      if (i > -1) c[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
    });
    return c;
  }

  // ===== AUTH middleware (session OAuth2 ATAU token) =====
  function auth(req, res, next) {
    const sid = parseCookies(req).kz_sid;
    if (sid && sessions.has(sid)) { req.session = sessions.get(sid); return next(); }
    if (!TOKEN) return res.status(500).json({ error: 'DASHBOARD_TOKEN belum diisi di .env' });
    const h = req.headers['authorization'] || '';
    if (Sec.safeEqual(h, `Bearer ${TOKEN}`)) return next();
    return res.status(401).json({ error: 'Token tidak valid' });
  }

  // ===== REST: login (validasi token — anti brute-force + timing-safe) =====
  app.post('/api/login', (req, res) => {
    const ip = Sec.clientIp(req);
    if (!Sec.loginHit(ip)) {
      Sec.audit(ip, 'rate_login', '/api/login', 'terlalu banyak percobaan');
      return res.status(429).json({ ok: false, error: 'Terlalu banyak percobaan login. Coba lagi nanti.' });
    }
    const { token } = req.body || {};
    if (TOKEN && Sec.safeEqual(token || '', TOKEN)) { Sec.noteLoginOk(ip); return res.json({ ok: true }); }
    Sec.noteLoginFail(ip);
    return res.status(401).json({ ok: false, error: 'Token salah' });
  });

  // ===== OAuth2 Discord =====
  app.get('/auth/login', (req, res) => {
    if (!CLIENT_ID) return res.status(500).send('DISCORD_CLIENT_ID / DISCORD_APPLICATION_ID belum diisi di .env');
    if (!/^https?:\/\//.test(REDIRECT_URI)) return res.status(500).send('DASHBOARD_REDIRECT_URL tidak valid (harus https://domain/auth/callback)');
    // Simpan halaman tujuan (next) lewat state OAuth supaya setelah login user
    // dikembalikan ke halaman yang tadi dia buka (trading/panel), bukan selalu /panel.
    const next = String(req.query.next || '/panel');
    const state = Buffer.from(JSON.stringify({ next })).toString('base64url');
    const url = `https://discord.com/api/oauth2/authorize?client_id=${CLIENT_ID}&redirect_uri=${encodeURIComponent(REDIRECT_URI)}&response_type=code&scope=identify%20guilds&state=${encodeURIComponent(state)}`;
    return res.redirect(url);
  });

  app.get('/auth/callback', async (req, res) => {
    const { code } = req.query;
    if (!code) return res.redirect('/?error=no_code');
    if (!CLIENT_SECRET) return res.status(500).send('DISCORD_CLIENT_SECRET belum diisi di .env');
    try {
      const tokenRes = await fetch('https://discord.com/api/oauth2/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ client_id: CLIENT_ID, client_secret: CLIENT_SECRET, grant_type: 'authorization_code', code, redirect_uri: REDIRECT_URI }),
      });
      const tokenData = await tokenRes.json();
      if (!tokenData.access_token) throw new Error('Gagal tukar token OAuth2');

      const [userRes, guildsRes] = await Promise.all([
        fetch('https://discord.com/api/v10/users/@me', { headers: { Authorization: `Bearer ${tokenData.access_token}` } }),
        fetch('https://discord.com/api/v10/users/@me/guilds', { headers: { Authorization: `Bearer ${tokenData.access_token}` } }),
      ]);
      const user = await userRes.json();
      const guilds = await guildsRes.json();

      const sid = crypto.randomBytes(32).toString('hex');
      sessions.set(sid, {
        userId: user.id,
        username: user.username,
        avatar: user.avatar ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png` : null,
        guilds: Array.isArray(guilds) ? guilds.map((g) => ({ id: g.id, name: g.name, icon: g.icon, admin: (g.permissions & 0x8) === 0x8 })) : [],
      });
      res.setHeader('Set-Cookie', `kz_sid=${sid}; HttpOnly; Path=/; Max-Age=${30 * 24 * 3600}; SameSite=Lax${Sec.cookieFlags(req)}`);
      let next = '/panel';
      try {
        const st = JSON.parse(Buffer.from(String(req.query.state || ''), 'base64url').toString('utf8'));
        if (st && typeof st.next === 'string' && /^\/[a-zA-Z0-9._/-]*$/.test(st.next)) next = st.next;
      } catch (_) {}
      return res.redirect(next);
    } catch (e) {
      return res.redirect('/panel?error=' + encodeURIComponent(e.message));
    }
  });

  app.get('/auth/logout', (req, res) => {
    const sid = parseCookies(req).kz_sid;
    if (sid) sessions.delete(sid);
    res.setHeader('Set-Cookie', `kz_sid=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax${Sec.cookieFlags(req)}`);
    return res.redirect('/');
  });

  // ===== REST: siapa user yang login (session) =====
  app.get('/api/me', auth, (req, res) => {
    if (req.session) return res.json(req.session);
    return res.json({ tokenAuth: true });
  });

  // Daftar server yang di-join USER (dari OAuth) yang juga ada bot-nya.
  app.get('/api/me/guilds', auth, (req, res) => {
    if (!req.session) return res.json([]);
    const botGuilds = new Set(client.guilds.cache.map(g => g.id));
    const userGuilds = (req.session.guilds || []).filter(g => botGuilds.has(g.id));
    return res.json(userGuilds.map(g => ({ id: g.id, name: g.name })));
  });

  // ===== PROFIL USER (foto profil + info lengkap) =====
  app.get('/api/profile', auth, async (req, res) => {
    const userId = resolveUserId(req);
    if (!userId) return res.status(400).json({ error: 'Identitas user tidak diketahui (login Discord dulu)' });

    let discordUser = null;
    if (req.session) discordUser = { id: req.session.userId, username: req.session.username, avatar: req.session.avatar };
    if (!discordUser) {
      try {
        const u = await client.users.fetch(userId);
        discordUser = { id: u.id, username: u.username, avatar: u.displayAvatarURL({ size: 256 }) };
      } catch (_) {}
    }

    const reg = getUser(userId);
    const prof = getUserProfile(userId);
    const D = require('../utils/rpgData');
    // Daftar server = server yang di-join USER (OAuth), bukan semua server bot.
    // Fallback ke server bot cuma kalau login pakai token (tanpa session).
    let guildList = client.guilds.cache;
    if (req.session && Array.isArray(req.session.guilds)) {
      const botById = new Map(client.guilds.cache.map(g => [g.id, g]));
      guildList = req.session.guilds.map(ug => botById.get(ug.id)).filter(Boolean);
    }
    const char = rpgDb.getCharacter(userId);
    const guilds = guildList.map(g => {
      const eco = getEconomy(g.id, userId);
      // Level TERUNIFIKASI: sumber kebenaran = karakter RPG global (bukan tabel leveling lama).
      return { guildId: g.id, guildName: g.name, icon: g.iconURL({ size: 64 }) || null, balance: eco.balance, bank: eco.bank, level: char?.level ?? 1, xp: char?.xp ?? 0 };
    });
    const totalBalance = guilds.reduce((s, g) => s + g.balance, 0);
    const totalBank = guilds.reduce((s, g) => s + g.bank, 0);

    let rpg = null;
    if (char) {
      const cls = D.CLASSES[char.className];
      const rank = D.getRank(char.rankKey);
      rpg = { className: char.className, classNameLabel: cls?.name || char.className, classColor: cls?.color || '#3b82f6', level: char.level, rankKey: char.rankKey, rankName: rank?.name || char.rankKey, rankColor: rank?.color || '#9ca3af', xp: char.xp, reputation: char.reputation, monstersKilled: char.monstersKilled, questsCompleted: char.questsCompleted };
    }
    const inv = rpgDb.getInventory(userId);
    const itemCount = inv.reduce((s, r) => s + (r.qty || 0), 0);

    return res.json({
      user: discordUser, registered: reg, profile: prof,
      economy: { totalBalance, totalBank, total: totalBalance + totalBank, guilds },
      rpg, itemCount,
    });
  });
  app.post('/api/profile', auth, (req, res) => {
    const userId = resolveUserId(req);
    if (!userId) return res.status(400).json({ error: 'Identitas user tidak diketahui (login Discord dulu)' });
    const { bio, pronouns, location, color } = req.body || {};
    const changes = {};
    if (bio != null) changes.bio = String(bio).slice(0, 300);
    if (pronouns != null) changes.pronouns = String(pronouns).slice(0, 40);
    if (location != null) changes.location = String(location).slice(0, 80);
    if (color != null && /^#[0-9a-fA-F]{6}$/.test(color)) changes.color = color;
    const updated = setUserProfile(userId, changes);
    return res.json({ ok: true, profile: updated });
  });

  // ===== REST: analitik command =====
  app.get('/api/analytics', auth, (req, res) => {
    return res.json({ totalExecuted: getTotalExecuted(), commandCounts: getCommandCounts(30) });
  });

  // ===== REST: daftar guild + channel =====
  app.get('/api/guilds', auth, (req, res) => {
    // Kalau user login via OAuth, tampilkan server yang di-join USER (bukan semua
    // server bot), tapi hanya yang juga di-join bot supaya ekonomi/trading jalan.
    if (req.session && Array.isArray(req.session.guilds)) {
      const out = req.session.guilds.filter(g => client.guilds.cache.has(g.id)).map(g => {
        const bg = client.guilds.cache.get(g.id);
        return {
          id: g.id, name: g.name, icon: bg?.iconURL({ size: 128 }) || null,
          channels: bg ? bg.channels.cache.filter(c => c.type === 0).map(c => ({ id: c.id, name: c.name })) : [],
          voiceChannels: bg ? bg.channels.cache.filter(c => c.type === 2).map(c => ({ id: c.id, name: c.name })) : [],
        };
      });
      return res.json(out);
    }
    return res.json(serializeGuilds(client));
  });

  // ===== REST: kirim chat sebagai bot =====
  app.post('/api/send', auth, async (req, res) => {
    const { channelId, text } = req.body || {};
    if (!channelId || !text || !String(text).trim()) return res.status(400).json({ error: 'channelId & text wajib diisi' });
    try {
      const channel = await client.channels.fetch(channelId);
      if (!channel || !channel.isTextBased()) return res.status(404).json({ error: 'Channel tidak ditemukan / bukan channel teks' });
      await channel.send(String(text).slice(0, 2000));
      return res.json({ ok: true });
    } catch (e) {
      return res.status(500).json({ error: e.message });
    }
  });

  // ===== REST: TTS di voice channel =====
  app.post('/api/tts', auth, async (req, res) => {
    const { guildId, voiceChannelId, text } = req.body || {};
    if (!guildId || !voiceChannelId || !text || !String(text).trim()) return res.status(400).json({ error: 'guildId, voiceChannelId & text wajib diisi' });
    try {
      await playTts(client, guildId, voiceChannelId, String(text).slice(0, 200));
      return res.json({ ok: true });
    } catch (e) {
      return res.status(500).json({ error: e.message });
    }
  });

  // ===== REST: dengarkan VC (start/stop) =====
  app.post('/api/listen/start', auth, async (req, res) => {
    const { guildId, voiceChannelId } = req.body || {};
    if (!guildId || !voiceChannelId) return res.status(400).json({ error: 'guildId & voiceChannelId wajib diisi' });
    try {
      startListening(client, guildId, voiceChannelId, (pcm) => broadcastPcm(pcm));
      return res.json({ ok: true });
    } catch (e) {
      return res.status(500).json({ error: e.message });
    }
  });
  app.post('/api/listen/stop', auth, (req, res) => {
    const { guildId } = req.body || {};
    stopListening(guildId);
    return res.json({ ok: true });
  });
  app.get('/api/listen/status', auth, (req, res) => {
    return res.json({ listening: Array.from(activeListenGuilds()) });
  });

  // ===== REST: statistik bot (overview) =====
  app.get('/api/stats', auth, (req, res) => {
    const totalMembers = client.guilds.cache.reduce((n, g) => n + (g.memberCount || 0), 0);
    return res.json({
      guilds: client.guilds.cache.size,
      users: client.users.cache.size,
      totalMembers,
      registeredUsers: countUsers(),
      commands: client.commands?.size || 0,
      uptimeSeconds: Math.floor(process.uptime()),
      ping: client.ws.ping,
    });
  });

  // ===== REST: setting global (whitelist) =====
  const SETTINGS_WHITELIST = ['botName', 'footer', 'embedColor', 'successColor', 'errorColor', 'warnColor', 'isNsfw', 'dailyAmount', 'workMin', 'workMax', 'robSuccessRate', 'xpPerMessage.min', 'xpPerMessage.max', 'xpCooldownSeconds', 'ai.model', 'ai.maxHistory', 'ai.cooldownSeconds'];
  app.get('/api/settings', auth, (req, res) => {
    const out = {};
    for (const k of SETTINGS_WHITELIST) out[k] = settings.get(k, null);
    return res.json(out);
  });
  app.post('/api/settings', auth, (req, res) => {
    const body = req.body || {};
    const changes = {};
    for (const k of SETTINGS_WHITELIST) {
      if (k in body) changes[k] = body[k];
    }
    if (Object.keys(changes).length) settings.setMany(Object.entries(changes).reduce((o, [k, v]) => ({ ...o, [k]: v }), {}));
    return res.json({ ok: true, applied: changes });
  });

  // ===== REST: config per-server =====
  const GUILD_EDITABLE = ['welcomeEnabled', 'goodbyeEnabled', 'automodEnabled', 'antiLinkEnabled', 'antiSpamEnabled', 'antiraidEnabled', 'modLogEnabled', 'welcomeStyle', 'welcomeColor', 'autoroleId', 'logChannel', 'levelUpChannel', 'suggestChannelId', 'verifyRoleId', 'starboardChannelId', 'starboardThreshold', 'minAccountAgeDays', 'voiceLogChannel', 'ticketCategoryId', 'ticketLogChannel'];
  app.get('/api/guild/:guildId', auth, (req, res) => {
    return res.json(getGuildConfig(req.params.guildId));
  });
  app.post('/api/guild/:guildId', auth, (req, res) => {
    const body = req.body || {};
    const changes = {};
    for (const k of GUILD_EDITABLE) {
      if (k in body) changes[k] = body[k];
    }
    if (Object.keys(changes).length) updateGuildConfig(req.params.guildId, changes);
    return res.json({ ok: true, applied: changes });
  });

  // ===== REST: daftar user terdaftar (dengan pencarian & saldo) =====
  app.get('/api/users', auth, (req, res) => {
    const q = String(req.query.q || '').trim().toLowerCase();
    const guildId = req.query.guildId;
    let users = listUsers(500, 0).map((u) => ({ userId: u.userId, username: u.username, age: u.age, banned: !!u.banned, registeredAt: u.registeredAt }));
    if (q) users = users.filter((u) => u.userId.includes(q) || (u.username || '').toLowerCase().includes(q));
    if (guildId) {
      users = users.map((u) => { const eco = getEconomy(guildId, u.userId); return { ...u, balance: eco.balance, bank: eco.bank, total: eco.balance + eco.bank }; });
    }
    return res.json(users);
  });

  // ===== REST: manajemen user (ban, edit, hapus, atur saldo) =====
  app.post('/api/users/:userId/ban', auth, (req, res) => {
    const banned = (req.body || {}).banned !== false;
    const n = setUserBanned(req.params.userId, banned);
    return res.json({ ok: n > 0, userId: req.params.userId, banned });
  });
  app.post('/api/users/:userId/edit', auth, (req, res) => {
    const { username, age, notes } = req.body || {};
    try {
      if (username != null) setUserField(req.params.userId, 'username', String(username));
      if (age != null) setUserField(req.params.userId, 'age', Number(age) || 0);
      if (notes != null) setUserField(req.params.userId, 'notes', String(notes));
      return res.json({ ok: true });
    } catch (e) {
      return res.status(400).json({ error: e.message });
    }
  });
  app.delete('/api/users/:userId', auth, (req, res) => {
    const n = deleteUser(req.params.userId);
    return res.json({ ok: n > 0, userId: req.params.userId });
  });
  app.post('/api/users/:userId/economy', auth, (req, res) => {
    const { guildId, action, amount } = req.body || {};
    if (!guildId) return res.status(400).json({ error: 'guildId wajib diisi' });
    if (action === 'setBalance') { resetEconomyForGuild(guildId, req.params.userId); if (Number(amount) > 0) updateBalance(guildId, req.params.userId, Number(amount)); }
    else if (action === 'addBalance') updateBalance(guildId, req.params.userId, Math.round(Number(amount) || 0));
    else if (action === 'setBank') { resetEconomyForGuild(guildId, req.params.userId); if (Number(amount) > 0) updateBank(guildId, req.params.userId, Number(amount)); }
    else if (action === 'addBank') updateBank(guildId, req.params.userId, Math.round(Number(amount) || 0));
    else if (action === 'reset') resetEconomyForGuild(guildId, req.params.userId);
    else return res.status(400).json({ error: 'action tidak dikenal' });
    return res.json({ ok: true, economy: getEconomy(guildId, req.params.userId) });
  });

  // ===== REST: kontrol musik =====
  app.get('/api/music/:guildId', auth, (req, res) => {
    const player = client.kazagumo?.players?.get(req.params.guildId);
    if (!player || !player.queue?.current) return res.json({ playing: false });
    const t = player.queue.current;
    return res.json({
      playing: true,
      paused: player.paused,
      title: t.title,
      author: t.author,
      duration: t.length || 0,
      position: player.position || 0,
      volume: player.volume,
      queueLength: player.queue.length || 0,
      loop: player.loop || 'none',
      thumbnail: t.thumbnail || null,
      uri: t.uri || null,
      queue: (player.queue || []).slice(0, 10).map((q) => ({ title: q.title, author: q.author, duration: q.length })),
    });
  });
  app.post('/api/music/:guildId/action', auth, async (req, res) => {
    const { action, value } = req.body || {};
    const player = client.kazagumo?.players?.get(req.params.guildId);
    if (!player) return res.status(404).json({ error: 'Tidak ada musik yang diputar' });
    try {
      if (action === 'pause') await player.pause(!player.paused);
      else if (action === 'skip') await player.skip();
      else if (action === 'stop') await player.destroy();
      else if (action === 'volume') await player.setVolume(Math.max(0, Math.min(200, Number(value) || 100)));
      else if (action === 'seek') await player.seek(Number(value) || 0);
      else if (action === 'shuffle') player.queue.shuffle();
      else if (action === 'loop') { const order = ['none', 'track', 'queue']; await player.setLoop(order[(order.indexOf(player.loop || 'none') + 1) % 3]); }
      else return res.status(400).json({ error: 'Aksi tidak dikenal' });
      return res.json({ ok: true });
    } catch (e) {
      return res.status(500).json({ error: e.message });
    }
  });

  // ===== REST: leaderboard (economy + level) =====
  app.get('/api/leaderboard/:guildId', auth, (req, res) => {
    const economy = getEconomyLeaderboard(req.params.guildId, 20).map((e, i) => ({ rank: i + 1, userId: e.userId, balance: e.balance, bank: e.bank, total: e.total }));
    const level = getLevelLeaderboard(req.params.guildId, 20).map((l, i) => ({ rank: i + 1, userId: l.userId, level: l.level, xp: l.xp }));
    return res.json({ economy, level });
  });

  // ===== REST: giveaway aktif =====
  app.get('/api/giveaways', auth, (req, res) => {
    return res.json(getActiveGiveaways().map((g) => ({ messageId: g.messageId, guildId: g.guildId, channelId: g.channelId, prize: g.prize, winnerCount: g.winnerCount, endTime: g.endTime, hostId: g.hostId })));
  });

  // ===== REST: warning (per guild) =====
  app.get('/api/warnings/:guildId', auth, (req, res) => {
    const rows = db.prepare('SELECT * FROM warnings WHERE guildId = ? ORDER BY timestamp DESC LIMIT 50').all(req.params.guildId);
    return res.json(rows);
  });

  // ===== REST: ekonomi Kizco (realtime monitoring + grafik) =====
  app.get('/api/economy/:guildId', auth, (req, res) => {
    return res.json(economyEngine.summary(req.params.guildId));
  });
  app.get('/api/economy/:guildId/history', auth, (req, res) => {
    return res.json(economyEngine.getPriceHistory(req.params.guildId, 200));
  });
  app.get('/api/economy/:guildId/transactions', auth, (req, res) => {
    return res.json(economyEngine.getTransactions(req.params.guildId, 50));
  });
  app.get('/api/economy/:guildId/report', auth, (req, res) => {
    return res.json(econDb.getAiLog(req.params.guildId, 10));
  });

  // Grafik harga item buat dashboard (daftar item + riwayat harga).
  app.get('/api/economy/:guildId/items', auth, (req, res) => {
    return res.json(shopManager.allItems().map(i => ({ id: i.id, name: i.name, emoji: i.emoji || '📦', category: i.category })));
  });
  app.get('/api/economy/:guildId/item/:itemId', auth, (req, res) => {
    const hist = econDb.getItemPriceHistory(req.params.guildId, req.params.itemId, 200);
    return res.json(hist.map(p => ({ t: p.timestamp, price: p.price })));
  });

  // Bank sentral (cetak/bakar/set kebijakan) — dari dashboard (token = akses penuh).
  app.post('/api/economy/:guildId/bank', auth, (req, res) => {
    const { action, amount, jenis, nilai } = req.body || {};
    if (action === 'print') return res.json(economyEngine.printMoney(req.params.guildId, Number(amount)));
    if (action === 'burn') return res.json(economyEngine.burnMoney(req.params.guildId, Number(amount)));
    if (action === 'rate') {
      const patch = { reward: { rewardMultiplier: Number(nilai) }, tax: { taxRate: Number(nilai) }, interest: { bankInterestRate: Number(nilai) } }[jenis];
      if (!patch) return res.status(400).json({ error: 'jenis tidak dikenal' });
      return res.json(economyEngine.setRates(req.params.guildId, patch));
    }
    return res.status(400).json({ error: 'action tidak dikenal' });
  });

  // Katalog item (kelola stok AI, aktif/nonaktif).
  app.get('/api/economy/:guildId/catalog', auth, (req, res) => {
    const list = econDb.listItems({ activeOnly: false }).map(i => ({ id: i.id, name: i.name, category: i.category, basePrice: i.basePrice, aiGenerated: i.aiGenerated, active: i.active }));
    return res.json(list);
  });
  app.post('/api/economy/:guildId/catalog/:itemId/toggle', auth, (req, res) => {
    const item = econDb.getItem(req.params.itemId);
    if (!item) return res.status(404).json({ error: 'Item tidak ditemukan' });
    const next = item.active ? 0 : 1;
    econDb.setItemActive(req.params.itemId, next);
    return res.json({ ok: true, itemId: req.params.itemId, active: next });
  });

  // ===== REST: TRADING WEB (order book, limit/market, portfolio) =====
  function resolveUserId(req) {
    if (req.session?.userId) return req.session.userId;
    return (req.body && req.body.userId) || (req.query && req.query.userId) || null;
  }

  // Daftar instrumen trading (forex/indeks/saham) — BUKAN barang game.
  app.get('/api/trade/items', auth, (req, res) => {
    const guildId = req.query.guildId;
    const state = economyEngine.summary(guildId);
    const out = INSTRUMENTS.map(inst => {
      const st = instrumentStats24h(guildId, inst.id);
      return { id: inst.id, name: inst.name, ticker: inst.ticker, kind: inst.kind, price: st.price, change24hPct: st.change24hPct, high24h: st.high24h, low24h: st.low24h, volume24h: st.volume24h };
    });
    return res.json({ items: out, state: { priceIndex: state.priceIndex, inflationPct: state.inflationPct } });
  });

  // Daftar aset/barang game dengan pagination + filter (halaman market terpisah).
  app.get('/api/market/items', auth, (req, res) => {
    const guildId = req.query.guildId;
    const page = Math.max(1, Number(req.query.page) || 1);
    const perPage = Math.min(24, Math.max(6, Number(req.query.perPage) || 12));
    const q = String(req.query.q || '').trim().toLowerCase();
    const cat = String(req.query.category || '').trim();
    const { items, state } = shopManager.listMarket(guildId);
    let all = items.filter(i => i.id !== BANK_STOCK_ID); // instrumen bukan barang game
    if (cat) all = all.filter(i => i.category === cat);
    if (q) all = all.filter(i => (i.name || '').toLowerCase().includes(q) || i.id.includes(q));
    const total = all.length;
    const totalPages = Math.max(1, Math.ceil(total / perPage));
    const slice = all.slice((page - 1) * perPage, page * perPage).map(i => {
      const st = econDb.getItemStats(guildId, i.id);
      // Perkaya dengan data rpgItems (stat lengkap utk penjelasan efek di kartu).
      const full = rpgItems.getItem(i.id) || {};
      return { id: i.id, name: i.name, category: i.category, price: i.price, demand: i.demand, trend: i.trend, desc: i.desc, change24hPct: st.change24hPct, volume24h: st.volume24h, tier: i.tier, class: i.class, effect: i.effect, stats: full.stats || null, wtype: full.wtype || full.atype || null, use: full.use || null };
    });
    const categories = Object.entries(shopManager.CATEGORIES || {}).map(([key, v]) => ({ key, label: v.label }));
    return res.json({ items: slice, page, perPage, totalPages, total, categories, state: { priceIndex: state.priceIndex } });
  });

  // ===== AUCTION HOUSE (marketplace P2P) =====
  app.get('/api/market/my-items', auth, (req, res) => {
    const userId = resolveUserId(req);
    if (!userId) return res.status(400).json({ error: 'Identitas user tidak diketahui (login Discord dulu)' });
    const inv = rpgDb.getInventory(userId);
    // Instrumen trading (kzc_usd, kzc_xau, saham, dll) tidak dijual lewat lelang P2P,
    // jadi disembunyikan dari daftar ini supaya tidak muncul error "Item tidak dikenal".
    const out = inv
      .filter((r) => !instrumentById(r.itemId))
      .map((r) => {
        const it = shopManager.getItem(r.itemId);
        return { itemId: r.itemId, name: it?.name || r.itemId, category: it?.category || 'consumable', qty: r.qty };
      });
    return res.json({ items: out });
  });
  app.get('/api/market/listings', auth, (req, res) => {
    const guildId = req.query.guildId;
    const list = econDb.listOpenListings(guildId).map(l => {
      const it = shopManager.getItem(l.itemId);
      return { id: l.id, sellerId: l.sellerId, itemId: l.itemId, itemName: it?.name || l.itemId, category: it?.category || 'consumable', qty: l.qty, pricePerUnit: l.pricePerUnit, createdAt: l.createdAt };
    });
    return res.json({ listings: list });
  });
  app.post('/api/market/listings', auth, (req, res) => {
    const guildId = req.body && req.body.guildId;
    const userId = resolveUserId(req);
    if (!userId) return res.status(400).json({ error: 'Identitas user tidak diketahui (login Discord dulu)' });
    const { itemId, qty, pricePerUnit } = req.body || {};
    const r = tradeSystem.createListing(guildId, userId, itemId, qty, pricePerUnit);
    if (!r.ok) return res.status(400).json({ error: r.error });
    return res.json({ ok: true, listing: r.listing });
  });
  app.post('/api/market/listings/:id/buy', auth, (req, res) => {
    const guildId = req.body && req.body.guildId;
    const userId = resolveUserId(req);
    if (!userId) return res.status(400).json({ error: 'Identitas user tidak diketahui (login Discord dulu)' });
    const r = tradeSystem.buyListing(guildId, userId, Number(req.params.id), Number((req.body || {}).qty) || 1);
    if (!r.ok) return res.status(400).json({ error: r.error });
    return res.json({ ok: true, ...r });
  });
  app.post('/api/market/listings/:id/cancel', auth, (req, res) => {
    const guildId = req.body && req.body.guildId;
    const userId = resolveUserId(req);
    if (!userId) return res.status(400).json({ error: 'Identitas user tidak diketahui (login Discord dulu)' });
    const r = tradeSystem.cancelListing(guildId, userId, Number(req.params.id));
    if (!r.ok) return res.status(400).json({ error: r.error });
    return res.json({ ok: true });
  });

  // Detail satu barang game (buat modal di halaman market).
  app.get('/api/market/item/:itemId', auth, (req, res) => {
    const guildId = req.query.guildId;
    const itemId = req.params.itemId;
    const item = shopManager.getItem(itemId);
    if (!item) return res.status(404).json({ error: 'Item tidak ditemukan' });
    const price = shopManager.buyPrice(guildId, itemId);
    const full = rpgItems.getItem(itemId) || {};
    return res.json({
      item: { id: item.id, name: item.name, category: item.category, type: item.type, desc: item.desc, emoji: item.emoji, effect: item.effect, stats: full.stats || null, tier: item.tier, class: item.class, use: full.use || null, price },
      stats: econDb.getItemStats(guildId, itemId),
    });
  });

  // Beli barang game langsung dari katalog market (KZC dari dompet).
  app.post('/api/market/buy', auth, (req, res) => {
    const guildId = req.body && req.body.guildId;
    const userId = resolveUserId(req);
    if (!userId) return res.status(400).json({ error: 'Identitas user tidak diketahui (login Discord dulu)' });
    const { itemId, qty } = req.body || {};
    const q = Math.max(1, Math.round(Number(qty) || 1));
    if (!itemId) return res.status(400).json({ error: 'itemId wajib diisi' });
    if (instrumentById(itemId)) return res.status(400).json({ error: 'Instrumen trading tidak bisa dibeli dari katalog market.' });
    const item = shopManager.getItem(itemId);
    if (!item) return res.status(404).json({ error: 'Item tidak ditemukan' });
    const price = shopManager.buyPrice(guildId, itemId);
    if (price == null) return res.status(404).json({ error: 'Harga item tidak tersedia' });
    const total = price * q;
    const eco = getEconomy(guildId, userId);
    if (eco.balance < total) return res.status(400).json({ error: `KZC tidak cukup. Butuh ${total}, punya ${eco.balance}.` });
    updateBalance(guildId, userId, -total);
    rpgDb.addItem(userId, itemId, q);
    econDb.bumpDemand(guildId, itemId, q);
    econDb.recordItemPrice(guildId, itemId, price);
    econDb.recordTransaction(guildId, { type: 'purchase', actorId: userId, amount: -total, note: `Beli ${q}x ${item.name} (market)` });
    return res.json({ ok: true, total, qty: q, item: { id: item.id, name: item.name, price } });
  });

  // Agregasi riwayat harga jadi candlestick OHLC per bucket.
  function buildCandles(guildId, itemId, bucketMs = 60000) {
    const hist = econDb.getItemPriceHistory(guildId, itemId, 500);
    if (!hist.length) return [];
    const buckets = new Map();
    for (const p of hist) {
      const t = Math.floor(p.timestamp / bucketMs) * bucketMs;
      if (!buckets.has(t)) buckets.set(t, { t, open: p.price, high: p.price, low: p.price, close: p.price, volume: 1 });
      else {
        const b = buckets.get(t);
        b.high = Math.max(b.high, p.price);
        b.low = Math.min(b.low, p.price);
        b.close = p.price;
        b.volume += 1;
      }
    }
    return Array.from(buckets.values()).sort((a, b) => a.t - b.t);
  }

  app.get('/api/trade/:guildId/item/:itemId', auth, (req, res) => {
    const { guildId, itemId } = req.params;
    if (instrumentById(itemId)) {
      const inst = instrumentById(itemId);
      const st = instrumentStats24h(guildId, itemId);
      const tf = String(req.query.tf || '5m');
      const bucketMs = TF_BUCKET[tf] || 300000;
      return res.json({
        item: { id: inst.id, name: inst.name, ticker: inst.ticker, kind: inst.kind, price: st.price },
        orderbook: buildInstrumentBook(guildId, itemId),
        fills: buildInstrumentFills(guildId, itemId),
        candles: buildInstrumentCandles(guildId, itemId, TF_COUNT, bucketMs),
        stats: st,
        analysis: marketEngine.getAnalysis(guildId, itemId, tf, 300),
      });
    }
    const item = shopManager.getItem(itemId);
    if (!item) return res.status(404).json({ error: 'Item tidak ditemukan' });
    return res.json({
      item: { id: item.id, name: item.name, category: item.category, desc: item.desc, price: shopManager.buyPrice(guildId, itemId) },
      orderbook: orderbook.getOrderBook(guildId, itemId),
      fills: orderbook.getRecentFills(guildId, itemId, 30),
      candles: buildCandles(guildId, itemId),
      stats: econDb.getItemStats(guildId, itemId),
    });
  });

  // Pasang order (market/limit). userId dari session OAuth atau body.
  app.post('/api/trade/:guildId/order', auth, (req, res) => {
    const guildId = req.params.guildId;
    const userId = resolveUserId(req);
    if (!userId) return res.status(400).json({ error: 'Identitas user tidak diketahui (login Discord dulu)' });
    const { itemId, side, type, price, qty } = req.body || {};
    const qtyN = Math.max(1, Math.round(Number(qty) || 1));
    const orderType = type || 'limit';

    // Instrumen (forex/saham/indeks): dieksekusi LANGSUNG di harga live sintetis
    // (market maker virtual dengan likuiditas penuh) untuk order MARKET maupun LIMIT.
    // Order limit pada instrumen tidak "nongkrong" di order book P2P (yang hanya
    // mengenali barang game), cukup jadi batas harga: hanya terisi kalau harga pasar
    // sudah sesuai/lebih baik dari limit. Ini menghapus error "Item tidak dikenal"
    // saat pasang order limit pada instrumen trading.
    if (instrumentById(itemId)) {
      const inst = instrumentById(itemId);
      const px = instrumentPrice(guildId, itemId);
      const limitPrice = Math.max(0, Math.round(Number(price) || 0));
      if (orderType === 'limit' && limitPrice > 0) {
        if (side === 'buy' && px > limitPrice) return res.status(400).json({ error: `Harga pasar ${px} di atas limit ${limitPrice}. Naikkan limit atau pakai Market.` });
        if (side === 'sell' && px < limitPrice) return res.status(400).json({ error: `Harga pasar ${px} di bawah limit ${limitPrice}. Turunkan limit atau pakai Market.` });
      }
      if (side === 'buy') {
        const cost = px * qtyN;
        const eco = getEconomy(guildId, userId);
        if (eco.balance < cost) return res.status(400).json({ error: `KZC tidak cukup. Butuh ${cost}, punya ${eco.balance}.` });
        updateBalance(guildId, userId, -cost);
        rpgDb.addItem(userId, itemId, qtyN);
      } else if (side === 'sell') {
        const held = rpgDb.getItemQty(userId, itemId);
        if (held < qtyN) return res.status(400).json({ error: `${inst.ticker} tidak cukup. Kamu pegang ${held}.` });
        rpgDb.removeItem(userId, itemId, qtyN);
        updateBalance(guildId, userId, px * qtyN);
      } else return res.status(400).json({ error: 'side harus buy/sell' });
      econDb.addFill({ guildId, itemId, buyerId: side === 'buy' ? userId : 'mm', sellerId: side === 'sell' ? userId : 'mm', price: px, qty: qtyN, amount: px * qtyN });
      // Tekanan beli/jual pemain memengaruhi harga instrumen (kecil, diskalakan likuiditas).
      marketEngine.applyTradePressure(guildId, itemId, side, qtyN);
      if (typeof client.broadcastDashboard === 'function') client.broadcastDashboard('trade', { guildId, itemId });
      return res.json({ ok: true, fills: [{ price: px, qty: qtyN, amount: px * qtyN }], status: 'filled', price: px });
    }

    const r = orderbook.placeOrder(guildId, userId, { itemId, side, type: orderType, price, qty });
    if (!r.ok) return res.status(400).json({ error: r.error });
    if (r.fills?.length) {
      // push update ke semua client trading
      if (typeof client.broadcastDashboard === 'function') client.broadcastDashboard('trade', { guildId, itemId });
    }
    return res.json({ ok: true, ...r });
  });

  app.post('/api/trade/:guildId/cancel', auth, (req, res) => {
    const guildId = req.params.guildId;
    const userId = resolveUserId(req);
    const { orderId } = req.body || {};
    const r = orderbook.cancelOrder(guildId, userId, Number(orderId));
    if (!r.ok) return res.status(400).json({ error: r.error });
    return res.json({ ok: true, ...r });
  });

  app.post('/api/trade/:guildId/cancelall', auth, (req, res) => {
    const guildId = req.params.guildId;
    const userId = resolveUserId(req);
    if (!userId) return res.status(400).json({ error: 'Identitas user tidak diketahui' });
    const r = orderbook.cancelAllOrders(guildId, userId);
    return res.json({ ok: true, ...r });
  });

  // Portfolio & order aktif user (balance bot ikut ke web).
  app.get('/api/trade/:guildId/portfolio', auth, (req, res) => {
    const guildId = req.params.guildId;
    const userId = resolveUserId(req);
    if (!userId) return res.status(400).json({ error: 'Identitas user tidak diketahui' });
    const eco = getEconomy(guildId, userId);
    const rdb = require('../database/rpgDb');
    const inv = rdb.getInventory(userId);
    const holdings = inv.map(r => {
      const inst = instrumentById(r.itemId);
      if (inst) return { itemId: r.itemId, name: inst.name, ticker: inst.ticker, kind: inst.kind, qty: r.qty, price: instrumentPrice(guildId, r.itemId) };
      const it = shopManager.getItem(r.itemId);
      return { itemId: r.itemId, name: it?.name || r.itemId, category: it?.category || 'consumable', qty: r.qty, price: it ? shopManager.buyPrice(guildId, r.itemId) : 0 };
    });
    const openOrders = orderbook.getOpenOrders(guildId, userId).map(o => {
      const it = shopManager.getItem(o.itemId);
      return { ...o, itemName: it?.name || o.itemId, remaining: o.qty - o.filledQty };
    });
    const trades = econDb.getTransactions(guildId, 30).filter(t => t.type === 'trade' && (t.actorId === userId || t.targetId === userId));
    return res.json({
      userId, balance: eco.balance, bank: eco.bank, total: eco.balance + eco.bank,
      holdings, openOrders, trades, moneySupply: economyEngine.summary(guildId).moneySupply,
    });
  });

  // Bank deposit/withdraw dari web (saldo bot ikut ke web).
  app.post('/api/trade/:guildId/bank', auth, (req, res) => {
    const guildId = req.params.guildId;
    const userId = resolveUserId(req);
    if (!userId) return res.status(400).json({ error: 'Identitas user tidak diketahui' });
    const { action, amount } = req.body || {};
    let r;
    if (action === 'deposit') r = bankDeposit(guildId, userId, amount);
    else if (action === 'withdraw') r = bankWithdraw(guildId, userId, amount);
    else return res.status(400).json({ error: 'action harus deposit/withdraw' });
    if (!r.ok) return res.status(400).json({ error: r.error });
    return res.json({ ok: true, amount: r.amount });
  });

  // Alert harga.
  app.get('/api/trade/:guildId/alerts', auth, (req, res) => {
    const userId = resolveUserId(req);
    if (!userId) return res.status(400).json({ error: 'Identitas user tidak diketahui' });
    return res.json(econDb.listAlerts(req.params.guildId, userId).map(a => ({ ...a, itemName: shopManager.getItem(a.itemId)?.name || a.itemId })));
  });
  app.post('/api/trade/:guildId/alert', auth, (req, res) => {
    const guildId = req.params.guildId;
    const userId = resolveUserId(req);
    if (!userId) return res.status(400).json({ error: 'Identitas user tidak diketahui' });
    const { itemId, direction, price } = req.body || {};
    if (!itemId || !['above', 'below'].includes(direction) || !(Number(price) > 0)) return res.status(400).json({ error: 'itemId, direction (above/below), dan price wajib valid' });
    const a = econDb.createAlert({ guildId, userId, itemId, direction, price: Number(price) });
    return res.json({ ok: true, alert: a });
  });
  app.delete('/api/trade/:guildId/alert/:id', auth, (req, res) => {
    const userId = resolveUserId(req);
    const n = econDb.deleteAlert(Number(req.params.id));
    return res.json({ ok: true, deleted: n });
  });

  // Watchlist user (aset dibintangi di terminal trading) — tersimpan di DATABASE,
  // bukan localStorage, jadi konsisten antar perangkat & browser.
  app.get('/api/trade/watchlist', auth, (req, res) => {
    const userId = resolveUserId(req);
    if (!userId) return res.status(400).json({ error: 'Identitas user tidak diketahui (login Discord dulu)' });
    return res.json({ items: getWatchlist(userId) });
  });
  app.post('/api/trade/watchlist/toggle', auth, (req, res) => {
    const userId = resolveUserId(req);
    if (!userId) return res.status(400).json({ error: 'Identitas user tidak diketahui (login Discord dulu)' });
    const { itemId } = req.body || {};
    if (!itemId) return res.status(400).json({ error: 'itemId wajib diisi' });
    return res.json({ ok: true, items: toggleWatchlistItem(userId, itemId) });
  });

  // Leaderboard trader (pemegang terbesar + volume trade terbesar).
  app.get('/api/trade/:guildId/stats', auth, (req, res) => {
    const guildId = req.params.guildId;
    const holders = getEconomyLeaderboard(guildId, 20).map((e, i) => ({ rank: i + 1, userId: e.userId, total: e.total }));
    const traders = db.prepare(`SELECT userId, SUM(amount) AS volume FROM (
        SELECT buyerId AS userId, amount FROM econ_fills WHERE guildId = ?
        UNION ALL SELECT sellerId AS userId, amount FROM econ_fills WHERE guildId = ?
      ) GROUP BY userId ORDER BY volume DESC LIMIT 20`).all(guildId, guildId);
    return res.json({ holders, traders: traders.map((t, i) => ({ rank: i + 1, userId: t.userId, volume: t.volume })) });
  });

  // ===== RPG WEB (Kizhoo Adventure) =====
  const { mountRpg } = require('../utils/rpgServer');
  mountRpg(app, { auth, resolveUserId, client });

  // ===== HTTP server + WebSocket =====
  const server = http.createServer(app);
  // Dashboard live-feed WSS: HANYA path "/" (klien dashboard lama connect ke /?token=).
  // Path "/ws" disisakan untuk realtime RPG (lobby/chat) — dua WSS di satu port.
  const wss = new WebSocketServer({ server, path: '/' });

  // RPG realtime (presence, chat global/teman/lobby, party) di path /ws.
  try {
    const { attachRealtime } = require('../utils/rpgRealtime');
    attachRealtime(server, { client });
  } catch (e) {
    console.error('[dashboard] Gagal memasang RPG realtime:', e.message);
  }

  function broadcast(type, data) {
    const payload = JSON.stringify({ type, data });
    for (const ws of wss.clients) {
      if (ws.readyState === 1) ws.send(payload);
    }
  }
  // Expose broadcast agar modul lain (mis. mesin ekonomi di ready.js) bisa push
  // snapshot ekonomi secara real-time ke dashboard.
  client.broadcastDashboard = broadcast;

  // Broadcast PCM (binary) ke semua client WebSocket (buat fitur dengarkan VC)
  function broadcastPcm(buffer) {
    for (const ws of wss.clients) {
      if (ws.readyState === 1) ws.send(buffer, { binary: true });
    }
  }

  // daftar guild yang lagi aktif di-dengarkan
  function activeListenGuilds() {
    return client.guilds.cache.filter((g) => isListening(g.id)).map((g) => g.id);
  }

  // ===== Hook event bot → push ke WebSocket =====
  client.on('messageCreate', (message) => {
    if (message.author?.bot) return;
    const guild = message.guild;
    broadcast('message', {
      guildId: guild?.id || null,
      guildName: guild?.name || 'DM',
      channelId: message.channel.id,
      channelName: message.channel.name || 'dm',
      author: message.author.username,
      authorAvatar: message.author.displayAvatarURL({ size: 64 }),
      content: message.content || null,
      // dukungan stiker, gambar, gif, embed, tombol
      stickers: message.stickers.map((s) => ({ name: s.name, url: s.url })),
      attachments: message.attachments.map((a) => ({ name: a.name, url: a.url, type: a.contentType })),
      embeds: message.embeds.map((e) => ({ title: e.title, description: e.description?.slice(0, 500) })),
      components: message.components.length > 0,
      timestamp: message.createdTimestamp,
    });
  });

  client.on('voiceStateUpdate', (oldState, newState) => {
    const member = newState.member;
    const channel = newState.channel;
    broadcast('voice', {
      guildId: newState.guild.id,
      guildName: newState.guild.name,
      userId: member?.id || oldState.member?.id,
      username: member?.user?.username || oldState.member?.user?.username || '?',
      channelId: channel?.id || null,
      channelName: channel?.name || null,
      speaking: newState.speaking ? true : false,
      deaf: newState.deaf,
      mute: newState.mute,
      timestamp: Date.now(),
    });
  });

  // ===== WebSocket connection =====
  wss.on('connection', (ws, req) => {
    // ANTI cross-site WebSocket hijacking: Origin harus domain resmi.
    if (!Sec.wsOriginOk(req)) { ws.close(4003, 'Forbidden'); return; }
    // Auth: session OAuth (cookie kz_sid) ATAU token dashboard via query string.
    // Dulu cuma token (disimpan di localStorage). Sekarang session cookie juga
    // diterima supaya terminal trading (login Discord) bisa dapat push real-time
    // tanpa perlu menyimpan token di browser.
    const url = new URL(req.url, 'http://localhost');
    const token = url.searchParams.get('token') || '';
    const sid = parseCookies(req).kz_sid;
    const sessionOk = !!(sid && sessions.has(sid));
    const tokenOk = !!(TOKEN && token && Sec.safeEqual(token, TOKEN));
    if (!sessionOk && !tokenOk) {
      ws.close(4001, 'Unauthorized');
      return;
    }
    ws.send(JSON.stringify({ type: 'hello', data: { guilds: serializeGuilds(client) } }));
  });

  server.listen(PORT, () => {
    console.log(`[Dashboard] Berjalan di http://localhost:${PORT} (port ${PORT})`);

    if (String(process.env.ENABLE_TUNNEL).toLowerCase() === 'true') {
      const { startTunnel } = require('../utils/tunnel');
      Promise.resolve(startTunnel(PORT, (publicUrl) => {
        // Kirim URL publik ke owner lewat DM biar gampang, kalau client tersedia
        if (client?.users?.fetch && process.env.OWNER_ID) {
          client.users.fetch(process.env.OWNER_ID)
            .then((u) => u.send(`🌐 Dashboard publik kamu sekarang aktif di:\n${publicUrl}`))
            .catch(() => {});
        }
      })).catch((err) => {
        console.error('[Tunnel] Gagal memulai tunnel:', err.message || err);
      });
    }
  });

  return { app, wss, server };
}

module.exports = { startDashboard, serializeGuilds };
