// Defer reply dengan aman. Kalau interaction sudah keburu expired (biasanya karena
// latensi jaringan bot ke Discord API lebih dari 3 detik), gagal di sini tidak bisa
// diperbaiki lagi - jadi cukup dicatat ke log dan command berhenti tanpa crash.
async function safeDefer(interaction, options = {}) {
  try {
    await interaction.deferReply(options);
    return true;
  } catch (err) {
    console.error(`[${interaction.commandName}] Gagal defer reply, interaction kemungkinan sudah expired: ${err.message}`);
    return false;
  }
}

module.exports = { safeDefer };
