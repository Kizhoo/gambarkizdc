const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder().setName('coinflip').setDescription('Lempar koin (Angka/Gambar)'),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const result = Math.random() < 0.5 ? t(lang, 'coin.heads') : t(lang, 'coin.tails');
    return interaction.reply({ embeds: [baseEmbed().setTitle(t(lang, 'coin.title')).setDescription(t(lang, 'coin.result', { r: result }))] });
  },
};
