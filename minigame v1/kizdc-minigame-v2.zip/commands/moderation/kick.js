const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick member dari server')
    .addUserOption(o => o.setName('target').setDescription('Member yang akan dikick').setRequired(true))
    .addStringOption(o => o.setName('alasan').setDescription('Alasan kick').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const target = interaction.options.getMember('target');
    const reason = interaction.options.getString('alasan') || t(lang, 'mod.no_reason');

    if (!target) return interaction.reply({ embeds: [errorEmbed(t(lang, 'mod.not_found_server'))], ephemeral: true });
    if (!target.kickable) return interaction.reply({ embeds: [errorEmbed(t(lang, 'mod.cant_kick'))], ephemeral: true });

    await target.send(t(lang, 'mod.kicked_dm', { server: interaction.guild.name, reason, reason_label: t(lang, 'mod.reason') })).catch(() => {});
    await target.kick(reason);

    return interaction.reply({ embeds: [successEmbed(t(lang, 'mod.kicked_ok', { user: target.user.tag, reason, reason_label: t(lang, 'mod.reason') }))] });
  },
};
