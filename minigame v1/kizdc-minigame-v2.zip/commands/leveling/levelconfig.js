const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { updateGuildConfig, addLevelReward, removeLevelReward, getLevelRewards } = require('../../database/db');
const levelEngine = require('../../utils/levelEngine');
const { successEmbed, errorEmbed, baseEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('levelconfig')
    .setDescription('Konfigurasi sistem leveling server')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub => sub.setName('set-level').setDescription('Atur level seorang member secara manual')
      .addUserOption(o => o.setName('target').setDescription('Member yang akan diatur levelnya').setRequired(true))
      .addIntegerOption(o => o.setName('level').setDescription('Level baru').setRequired(true).setMinValue(0)))
    .addSubcommand(sub => sub.setName('set-channel').setDescription('Atur channel khusus untuk notifikasi naik level')
      .addChannelOption(o => o.setName('channel').setDescription('Channel notifikasi level up').addChannelTypes(ChannelType.GuildText).setRequired(true)))
    .addSubcommand(sub => sub.setName('reward-set').setDescription('Atur role otomatis saat mencapai level tertentu')
      .addIntegerOption(o => o.setName('level').setDescription('Level yang harus dicapai').setRequired(true).setMinValue(1))
      .addRoleOption(o => o.setName('role').setDescription('Role yang akan diberikan').setRequired(true)))
    .addSubcommand(sub => sub.setName('reward-remove').setDescription('Hapus reward role di level tertentu')
      .addIntegerOption(o => o.setName('level').setDescription('Level yang rewardnya ingin dihapus').setRequired(true).setMinValue(1)))
    .addSubcommand(sub => sub.setName('reward-list').setDescription('Lihat semua role reward per level')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'set-level') {
      const target = interaction.options.getUser('target');
      const level = interaction.options.getInteger('level');
      // Set level TERUNIFIKASI (karakter RPG + mirror per-guild disinkronkan).
      levelEngine.setLevel(target.id, level, interaction.guild.id);
      return interaction.reply({ embeds: [successEmbed(`Level **${target.username}** berhasil diatur ke **${level}**.`)] });
    }

    if (sub === 'set-channel') {
      const channel = interaction.options.getChannel('channel');
      updateGuildConfig(interaction.guild.id, { levelUpChannel: channel.id });
      return interaction.reply({ embeds: [successEmbed(`Notifikasi naik level sekarang akan dikirim ke ${channel}.`)] });
    }

    if (sub === 'reward-set') {
      const level = interaction.options.getInteger('level');
      const role = interaction.options.getRole('role');
      if (role.position >= interaction.guild.members.me.roles.highest.position) {
        return interaction.reply({ embeds: [errorEmbed('Aku tidak bisa memberi role ini karena posisinya lebih tinggi dariku.')], ephemeral: true });
      }
      addLevelReward(interaction.guild.id, level, role.id);
      return interaction.reply({ embeds: [successEmbed(`Member yang mencapai **Level ${level}** akan otomatis dapat role ${role}.`)] });
    }

    if (sub === 'reward-remove') {
      const level = interaction.options.getInteger('level');
      const removed = removeLevelReward(interaction.guild.id, level);
      if (!removed) return interaction.reply({ embeds: [errorEmbed(`Tidak ada reward yang diatur untuk level ${level}.`)], ephemeral: true });
      return interaction.reply({ embeds: [successEmbed(`Reward untuk level **${level}** berhasil dihapus.`)] });
    }

    if (sub === 'reward-list') {
      const rewards = getLevelRewards(interaction.guild.id);
      if (rewards.length === 0) {
        return interaction.reply({ embeds: [baseEmbed().setDescription('Belum ada level reward yang diatur. Pakai `/levelconfig reward-set`.')] });
      }
      const description = rewards.map(r => `**Level ${r.level}** <@&${r.roleId}>`).join('\n');
      return interaction.reply({ embeds: [baseEmbed().setTitle('Level Rewards').setDescription(description)] });
    }
  },
};
