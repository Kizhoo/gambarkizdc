// ============================================================================
// MINIGAME SERVER v2 — "KizDefense" (merge turret defense) API web
// ----------------------------------------------------------------------------
// Endpoint:
//   GET  /minigame                  — hub minigame (pilih game)
//   GET  /kizdefense                — halaman game KizDefense (publik)
//   GET  /api/minigame/build-info   — stamp build (deteksi deploy campur versi)
//   GET  /api/minigame/config       — katalog balance (turret/musuh/reward)
//   GET  /api/minigame/state        — progres pemain (auth)
//   POST /api/minigame/save         — simpan progres (auth, rate-limit, clamp)
//   POST /api/minigame/import       — impor progres demo -> akun (SEKALI, fix koin hilang)
//   POST /api/minigame/claim        — klaim reward Kizco (auth, server-authoritative)
//   GET  /api/minigame/leaderboard  — papan peringkat bestWave (auth)
//
// Model anti-cheat: simulasi jalan di klien, server melakukan:
//   - wave & totalKills monotonic naik (tidak bisa di-rollback utk farm klaim)
//   - kenaikan coins dibatasi plafon per save (wave x reward wajar)
//   - turrets divalidasi bentuk & jumlah slot (maks 15) & tier (1-20)
//   - klaim Kizco dihitung DARI bestWave server (bukan klaim klien)
//   - rate limit per user per aksi
// ============================================================================
const fs = require('fs');
const path = require('path');
const webDb = require('../database/webDb');
const { updateBalance, getEconomy } = require('../database/db');

const GAME_BUILD = '2026.09.29-2';

// ---------------- Katalog balance (cermin kizdefense.js) ----------------
const MAX_TIER = 20;
const SLOT_KEYS = ['B0','B1','B2','B3','B4','G0','G1','G2','G3','G4','G5','G6','G7','G8','G9'];
function turretDamage(tier) { return Math.round(8 * Math.pow(1.62, tier - 1)); }
function turretFireRate(tier) { return Math.max(0.5, 1.16 - 0.028 * (tier - 1)); }
function turretRange(tier) { return 300 + 14 * tier; }
function buyLevelFor(chapter) { return Math.min(MAX_TIER, 1 + Math.floor((chapter - 1) * 2)); }
function buyCost(level) { return Math.round(90 * Math.pow(1.95, level - 1) / 10) * 10; }

const REWARD = {
  killCoins: (wave, chapter) => Math.round((2 + wave * 0.8) * (1 + 0.5 * (chapter - 1))),
  waveCoins: (wave, chapter) => Math.round((40 + wave * 10) * (1 + 0.4 * (chapter - 1))),
  bossCoins: (wave, chapter) => Math.round((120 + wave * 14) * (1 + 0.6 * (chapter - 1))),
  chapterCoins: (chapter) => 300 * chapter,
  kizcoPerWave: 25,
  claimMinWaves: 10,
  claimMaxKizco: 2500,
  claimCooldownMs: 5 * 60 * 1000,
  saveCooldownMs: 4000,
  coinsMaxGainPerSave: 250000,
};
const IMPORT = { maxCoins: 250000, maxBestWave: 300, maxKills: 200000 };

// ---------------- Rate limiter sederhana per user ----------------
const rateBuckets = new Map();
function rateLimit(userId, action, max, windowMs) {
  const nowTs = Date.now();
  const key = `${userId}:${action}`;
  const arr = (rateBuckets.get(key) || []).filter((t) => nowTs - t < windowMs);
  rateBuckets.set(key, arr);
  if (arr.length >= max) return false;
  arr.push(nowTs);
  if (rateBuckets.size > 5000) rateBuckets.clear();
  return true;
}

function jsonError(res, code, msg) { return res.status(code).json({ ok: false, error: msg }); }

function publicConfig() {
  return {
    canvas: { w: 720, h: 1248 },
    maxTier: MAX_TIER,
    slotKeys: SLOT_KEYS,
    buyLevelFor, buyCost, turretDamage, turretFireRate, turretRange,
    reward: REWARD,
    build: GAME_BUILD,
  };
}

// Validasi bentuk turrets v2: { "B0".."G9": { tier } }
// MIGRASI v1: { "0".."14": { tier(1-8), dmg, rate, range } } -> slot huruf + tier [1,3,5,7,10,13,16,20]
const V1_TIER_MAP = [1, 3, 5, 7, 10, 13, 16, 20];
function sanitizeTurrets(raw) {
  const out = {};
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return out;
  let count = 0;
  for (const [k, v] of Object.entries(raw)) {
    if (count >= 15) break;
    if (!v || typeof v !== 'object') continue;
    let slotKey = null, tier = 0;
    if (SLOT_KEYS.includes(k)) {
      slotKey = k;
      tier = Math.floor(Number(v.tier) || 0);
    } else {
      // format v1 lama?
      const idx = Number(k);
      if (Number.isInteger(idx) && idx >= 0 && idx <= 14) {
        slotKey = SLOT_KEYS[idx];
        const oldTier = Math.floor(Number(v.tier) || 0);
        tier = V1_TIER_MAP[Math.min(7, Math.max(0, oldTier - 1))] || 1;
      }
    }
    if (!slotKey) continue;
    if (!(tier >= 1 && tier <= MAX_TIER)) continue;
    if (out[slotKey]) continue;
    out[slotKey] = { tier };
    count++;
  }
  return out;
}

function mountMinigame(app, { auth, resolveUserId, client } = {}) {
  const sendPage = (res, file, missing) => {
    const candidates = [
      path.join(__dirname, '..', 'dashboard', 'public', file),
      path.join(__dirname, 'public', file),
    ];
    const f = candidates.find((p) => fs.existsSync(p));
    if (!f) return res.status(404).send(missing);
    res.setHeader('Cache-Control', 'no-store');
    return res.sendFile(f);
  };

  // ---------- Halaman hub minigame (publik) ----------
  app.get('/minigame', (req, res) => sendPage(res, 'minigame.html', 'minigame.html (hub) tidak ditemukan di dashboard/public/'));

  // ---------- Halaman game KizDefense (publik — tamu boleh main) ----------
  app.get('/kizdefense', (req, res) => sendPage(res, 'kizdefense.html', 'kizdefense.html tidak ditemukan di dashboard/public/'));

  app.get('/api/minigame/build-info', (req, res) => {
    res.json({ ok: true, game: 'kizdefense', build: GAME_BUILD });
  });

  app.get('/api/minigame/config', (req, res) => {
    res.json({ ok: true, config: publicConfig() });
  });

  app.get('/api/minigame/state', auth, (req, res) => {
    const userId = resolveUserId(req);
    if (!userId) return jsonError(res, 400, 'Identitas user tidak diketahui (login Discord dulu)');
    const p = webDb.ensureProgress(userId);
    let turrets = {}, stats = {};
    try { turrets = JSON.parse(p.turrets || '{}'); } catch (_) {}
    try { stats = JSON.parse(p.stats || '{}'); } catch (_) {}
    const idle = computeIdleEarnings(p);
    return res.json({
      ok: true,
      build: GAME_BUILD,
      progress: {
        wave: p.wave, bestWave: p.bestWave, coins: p.coins + idle.coins,
        turrets: sanitizeTurrets(turrets), stats, totalKills: p.totalKills,
        tutorialStep: Number(stats.tutorialStep) || 0,
        lastClaimWave: p.lastClaimWave, lastClaimAt: p.lastClaimAt,
        idleEarned: idle.coins, idleSeconds: idle.seconds,
      },
      claim: claimPreview(p),
      config: publicConfig(),
    });
  });

  app.post('/api/minigame/save', auth, (req, res) => {
    const userId = resolveUserId(req);
    if (!userId) return jsonError(res, 400, 'Identitas user tidak diketahui (login Discord dulu)');
    if (!rateLimit(userId, 'mgsave', 1, REWARD.saveCooldownMs)) return jsonError(res, 429, 'Terlalu sering menyimpan. Coba lagi sebentar lagi.');
    const cur = webDb.ensureProgress(userId);
    const b = req.body || {};

    const wave = Math.max(1, Math.min(100000, Math.floor(Number(b.wave) || 1)));
    const bestWave = Math.max(cur.bestWave, Math.min(100000, Math.floor(Number(b.bestWave) || 0)), wave);
    const totalKills = Math.max(cur.totalKills, Math.max(0, Math.min(1e9, Math.floor(Number(b.totalKills) || 0))));
    let coins = Math.max(0, Math.min(1e9, Math.floor(Number(b.coins) || 0)));
    if (coins > cur.coins) {
      const waveAdv = Math.max(0, bestWave - cur.bestWave);
      const killsAdv = Math.max(0, totalKills - cur.totalKills);
      const plausible = cur.coins + waveAdv * (REWARD.waveCoins(bestWave, 1) + 26 * REWARD.killCoins(bestWave, 1)) + killsAdv * REWARD.killCoins(bestWave, 1) + 3000;
      const cap = Math.min(plausible, cur.coins + REWARD.coinsMaxGainPerSave);
      if (coins > cap) coins = cap;
    }
    const turrets = sanitizeTurrets(b.turrets);
    let stats = {};
    if (b.stats && typeof b.stats === 'object' && !Array.isArray(b.stats)) {
      stats = {
        tutorialStep: Math.max(0, Math.min(4, Math.floor(Number(b.stats.tutorialStep) || 0))),
        defHpMax: Math.max(100, Math.min(300, Math.floor(Number(b.stats.defHpMax) || 100))),
        sessionKills: Math.max(0, Math.min(1e6, Math.floor(Number(b.stats.sessionKills) || 0))),
        sessionCoins: Math.max(0, Math.min(1e8, Math.floor(Number(b.stats.sessionCoins) || 0))),
        speedX: Number(b.stats.speedX) === 2 ? 2 : 1,
      };
    }
    const saved = webDb.saveProgress(userId, { wave, bestWave, coins, turrets, stats, totalKills });
    webDb.touchProgress(userId);
    return res.json({ ok: true, progress: { wave: saved.wave, bestWave: saved.bestWave, coins: saved.coins, totalKills: saved.totalKills }, claim: claimPreview(saved) });
  });

  // ---------- Impor progres mode-demo -> akun (SEKALI) ----------
  // Fix bug: main di mode demo (localStorage) lalu login -> koin/progres "hilang"
  // karena server masih kosong. Endpoint ini memindahkan progres demo tepat
  // sekali dengan clamp ketat; hanya boleh bila progres server masih segar.
  app.post('/api/minigame/import', auth, (req, res) => {
    const userId = resolveUserId(req);
    if (!userId) return jsonError(res, 400, 'Identitas user tidak diketahui (login Discord dulu)');
    if (!rateLimit(userId, 'mgimport', 3, 60 * 60 * 1000)) return jsonError(res, 429, 'Terlalu sering impor.');
    const cur = webDb.ensureProgress(userId);
    const fresh = !cur.bestWave && !cur.totalKills && !cur.coins && !Object.keys(sanitizeTurrets(cur.turrets || '{}')).length;
    if (!fresh) return jsonError(res, 400, 'Progres akun sudah ada — impor demo hanya untuk akun baru.');
    const b = req.body || {};
    const bestWave = Math.max(0, Math.min(IMPORT.maxBestWave, Math.floor(Number(b.bestWave) || 0)));
    const wave = Math.max(1, Math.min(Math.max(1, bestWave), Math.floor(Number(b.wave) || 1)));
    const totalKills = Math.max(0, Math.min(IMPORT.maxKills, Math.floor(Number(b.totalKills) || 0)));
    const coins = Math.max(0, Math.min(IMPORT.maxCoins, Math.floor(Number(b.coins) || 0)));
    const turrets = sanitizeTurrets(b.slots || b.turrets);
    const saved = webDb.saveProgress(userId, { wave, bestWave, coins, turrets, stats: { tutorialStep: 0 }, totalKills });
    webDb.touchProgress(userId);
    return res.json({ ok: true, imported: true, progress: { wave: saved.wave, bestWave: saved.bestWave, coins: saved.coins } });
  });

  app.post('/api/minigame/claim', auth, (req, res) => {
    const userId = resolveUserId(req);
    if (!userId) return jsonError(res, 400, 'Identitas user tidak diketahui (login Discord dulu)');
    const guildId = String((req.body || {}).guildId || '');
    if (!guildId) return jsonError(res, 400, 'guildId wajib diisi (server Discord tujuan reward)');
    if (!client || !client.guilds || !client.guilds.cache || !client.guilds.cache.has(guildId)) {
      return jsonError(res, 400, 'Bot tidak ada di server itu.');
    }
    if (!rateLimit(userId, 'mgclaim', 1, REWARD.claimCooldownMs)) return jsonError(res, 429, 'Klaim barusan saja. Tunggu beberapa menit.');

    const p = webDb.ensureProgress(userId);
    const eligible = Math.max(0, p.bestWave - p.lastClaimWave);
    if (eligible < REWARD.claimMinWaves) {
      return jsonError(res, 400, `Butuh minimal ${REWARD.claimMinWaves} wave sejak klaim terakhir (sekarang: ${eligible}).`);
    }
    const amount = Math.min(REWARD.claimMaxKizco, Math.floor(eligible * REWARD.kizcoPerWave));
    if (amount <= 0) return jsonError(res, 400, 'Reward kosong.');

    updateBalance(guildId, userId, amount);
    webDb.recordClaim(userId, { wave: p.bestWave, amount });
    const eco = getEconomy(guildId, userId);
    return res.json({ ok: true, amount, waves: eligible, balance: eco.balance, nextClaimInWaves: REWARD.claimMinWaves });
  });

  app.get('/api/minigame/leaderboard', auth, (req, res) => {
    const rows = webDb.getMinigameLeaderboard(20);
    const enriched = [];
    for (const r of rows) {
      let name = r.userId;
      try {
        if (client && client.users) {
          const u = client.users.cache.get(r.userId);
          if (u) name = u.username;
        }
      } catch (_) {}
      enriched.push({ userId: r.userId, name, bestWave: r.bestWave, totalKills: r.totalKills });
    }
    return res.json({ ok: true, leaderboard: enriched });
  });
}

// ---------- Penghasilan idle offline ----------
function computeIdleEarnings(p) {
  const last = Math.max(0, p.lastSeenAt || 0);
  const seconds = Math.max(0, Math.min(8 * 3600, Math.floor((Date.now() - last) / 1000)));
  const perMinute = 3 + p.bestWave * 0.6;
  const coins = Math.floor((seconds / 60) * perMinute);
  return { coins: Math.max(0, Math.min(200000, coins)), seconds };
}

function claimPreview(p) {
  const eligible = Math.max(0, p.bestWave - p.lastClaimWave);
  return {
    eligibleWaves: eligible,
    minWaves: REWARD.claimMinWaves,
    canClaim: eligible >= REWARD.claimMinWaves,
    estimateKizco: Math.min(REWARD.claimMaxKizco, Math.floor(eligible * REWARD.kizcoPerWave)),
    cooldownMs: REWARD.claimCooldownMs,
  };
}

module.exports = { mountMinigame, GAME_BUILD, publicConfig, computeIdleEarnings };
