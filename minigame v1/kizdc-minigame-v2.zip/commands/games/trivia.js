const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const { errorEmbed, baseEmbed } = require('../../utils/embeds');
const { safeDefer } = require('../../utils/interactionHelpers');
const settings = require('../../utils/settings');
const { t, guildLang } = require('../../utils/i18n');

function decodeHTML(text) {
  return text
    .replace(/&quot;/g, '"')
    .replace(/&#0?39;/g, "'")
    .replace(/&amp;/g, '&')
    .replace(/&eacute;/g, 'e')
    .replace(/&uuml;/g, 'u')
    .replace(/&ouml;/g, 'o')
    .replace(/&auml;/g, 'a')
    .replace(/&ntilde;/g, 'n');
}

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

const CATEGORY_CHOICES = [
  { name: 'Campuran', value: 'any' },
  { name: 'General Knowledge', value: '9' },
  { name: 'Video Games', value: '15' },
  { name: 'Film', value: '11' },
  { name: 'Musik', value: '12' },
  { name: 'Sains', value: '17' },
  { name: 'Sejarah', value: '23' },
];

module.exports = {
  subcommandOf: 'games',
  data: new SlashCommandBuilder()
    .setName('trivia')
    .setDescription('Main kuis trivia rame-rame, siapa saja di channel boleh ikut jawab')
    .addIntegerOption(o => o.setName('putaran').setDescription('Jumlah soal (default 5)').setMinValue(1).setMaxValue(15))
    .addStringOption(o => o.setName('kategori').setDescription('Kategori soal').addChoices(...CATEGORY_CHOICES)),

  async execute(interaction) {
    const lang = guildLang(interaction);
    const rounds = interaction.options.getInteger('putaran') || 5;
    const category = interaction.options.getString('kategori') || 'any';

    if (!(await safeDefer(interaction))) return;

    let questions;
    try {
      const categoryParam = category !== 'any' ? `&category=${category}` : '';
      const res = await fetch(`https://opentdb.com/api.php?amount=${rounds}${categoryParam}&type=multiple`);
      if (!res.ok) throw new Error(`opentdb.com merespons status ${res.status}`);
      const data = await res.json();
      if (data.response_code !== 0 || !data.results?.length) {
        throw new Error(t(lang, 'trivia.no_questions'));
      }
      questions = data.results;
    } catch (err) {
      console.error('[trivia] Gagal ambil soal:', err.message);
      return interaction.editReply({ embeds: [errorEmbed(t(lang, 'trivia.fail'))] });
    }

    const scores = new Map();

    for (let q = 0; q < questions.length; q++) {
      const question = questions[q];
      const correctAnswer = decodeHTML(question.correct_answer);
      const options = shuffle([...question.incorrect_answers.map(decodeHTML), correctAnswer]);
      const correctIndex = options.indexOf(correctAnswer);

      const secondsPerQuestion = settings.get('games.triviaSecondsPerQuestion', 15);
      const embed = baseEmbed()
        .setTitle(t(lang, 'trivia.question', { q: q + 1, n: questions.length }))
        .setDescription(`**${decodeHTML(question.question)}**\n\n${t(lang, 'trivia.meta', { c: decodeHTML(question.category), d: question.difficulty })}`)
        .setFooter({ text: t(lang, 'trivia.footer', { s: secondsPerQuestion }) });

      const row = new ActionRowBuilder().addComponents(
        options.map((opt, i) => new ButtonBuilder().setCustomId(`trivia_${i}`).setLabel(opt.slice(0, 80)).setStyle(ButtonStyle.Primary))
      );

      const message = q === 0
        ? await interaction.editReply({ embeds: [embed], components: [row] })
        : await interaction.followUp({ embeds: [embed], components: [row] });

      const answered = new Set();

      await new Promise(resolve => {
        const collector = message.createMessageComponentCollector({ componentType: ComponentType.Button, time: secondsPerQuestion * 1000 });

        collector.on('collect', async i => {
          if (answered.has(i.user.id)) {
            return i.reply({ content: t(lang, 'trivia.answered'), ephemeral: true });
          }
          answered.add(i.user.id);

          const chosenIndex = parseInt(i.customId.split('_')[1]);
          const isCorrect = chosenIndex === correctIndex;

          if (isCorrect) {
            const current = scores.get(i.user.id) || { username: i.user.username, score: 0 };
            current.score += 1;
            scores.set(i.user.id, current);
          }

          return i.reply({ content: isCorrect ? t(lang, 'trivia.correct') : t(lang, 'trivia.wrong', { a: correctAnswer }), ephemeral: true });
        });

        collector.on('end', () => resolve());
      });

      const revealEmbed = baseEmbed()
        .setTitle(t(lang, 'trivia.reveal_title', { q: q + 1, n: questions.length }))
        .setDescription(`**${decodeHTML(question.question)}**\n\n${t(lang, 'trivia.reveal', { a: correctAnswer })}`);
      await message.edit({ embeds: [revealEmbed], components: [] }).catch(() => {});
    }

    const sorted = [...scores.entries()].sort((a, b) => b[1].score - a[1].score);
    const leaderboard = sorted.length > 0
      ? sorted.map(([userId, data], i) => `${i + 1}. <@${userId}> - ${t(lang, 'trivia.points', { n: data.score })}`).join('\n')
      : t(lang, 'trivia.no_one');

    const finalEmbed = baseEmbed().setTitle(t(lang, 'trivia.done')).setDescription(leaderboard);
    await interaction.followUp({ embeds: [finalEmbed] });
  },
};
