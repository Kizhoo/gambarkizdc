const { SlashCommandBuilder } = require('discord.js');
const { getMarriage, removeMarriage } = require('../../database/db');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder().setName('divorce').setDescription('Cerai dari pasangan kamu saat ini'),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const marriage = getMarriage(interaction.guild.id, interaction.user.id);
    if (!marriage) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'divorce.none'))], ephemeral: true });
    }

    removeMarriage(interaction.guild.id, interaction.user.id);
    return interaction.reply({ embeds: [successEmbed(t(lang, 'divorce.ok', { p: marriage.partnerId }))] });
  },
};
