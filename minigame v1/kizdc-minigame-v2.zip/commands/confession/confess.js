const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getGuildConfig, updateGuildConfig } = require('../../database/db');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('confess')
    .setDescription('Kirim confession anonim ke server')
    .addStringOption(o => o.setName('pesan').setDescription('Isi confession kamu').setRequired(true)),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const cfg = getGuildConfig(interaction.guild.id);
    if (!cfg.confessionChannelId) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'confess.not_enabled'))], ephemeral: true });
    }

    const channel = interaction.guild.channels.cache.get(cfg.confessionChannelId);
    if (!channel) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'confess.channel_not_found'))], ephemeral: true });
    }

    const number = (cfg.confessionCounter || 0) + 1;
    updateGuildConfig(interaction.guild.id, { confessionCounter: number });

    const embed = new EmbedBuilder()
      .setColor('#2b2d31')
      .setTitle(t(lang, 'confess.title', { n: number }))
      .setDescription(interaction.options.getString('pesan'))
      .setFooter({ text: t(lang, 'confess.anon')})
      .setTimestamp();

    await channel.send({ embeds: [embed] });
    return interaction.reply({ embeds: [successEmbed(t(lang, 'confess.sent'))], ephemeral: true });
  },
};
