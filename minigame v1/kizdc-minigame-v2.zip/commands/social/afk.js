const { SlashCommandBuilder } = require('discord.js');
const { setAfk } = require('../../database/db');
const { successEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('afk')
    .setDescription('Set status AFK kamu')
    .addStringOption(o => o.setName('alasan').setDescription('Alasan AFK (opsional)')),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const reason = interaction.options.getString('alasan') || t(lang, 'mod.no_reason');
    setAfk(interaction.guild.id, interaction.user.id, reason);
    return interaction.reply({ embeds: [successEmbed(t(lang, 'afk.ok', { r: reason }))] });
  },
};
