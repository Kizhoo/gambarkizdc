const { SlashCommandBuilder } = require('discord.js');
const { getValidPlayer, safePlayerAction } = require('../../utils/musicGuard');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder().setName('resume').setDescription('Lanjutkan musik yang dijeda'),
  async execute(interaction, client) {
    const lang = guildLang(interaction);
    const player = await getValidPlayer(interaction, client);
    if (!player) return;

    if (!player.paused) return interaction.reply({ embeds: [errorEmbed(t(lang, 'music.not_paused'))], ephemeral: true });

    return safePlayerAction(interaction, () => player.pause(false), { embeds: [successEmbed(t(lang, 'music.resumed'))] });
  },
};
