// ============================================================================
// ENGINE CATUR — aturan penuh, murni logika (dipakai commands/games/chess.js)
// ----------------------------------------------------------------------------
// Koordinat: row 0-7 = rank 1-8, col 0-7 = file a-h (row 0/col 0 = a1). Putih
// mulai di row 0-1, hitam di row 6-7. Orientasi visual (flip biar putih di
// bawah) itu urusan renderer, bukan engine ini.
//
// Didukung: semua gerak bidak standar, capture, castling (kingside/queenside),
// en passant, promosi (default ke ratu - dipilih lewat tombol kalau ada opsi
// lain), skak, skakmat, stalemate. TIDAK didukung (disengaja, biar scope aman
// & teruji baik): draw by repetition/50-move rule/insufficient material - game
// berakhir lewat checkmate/stalemate/resign saja.
// ============================================================================
const FILES = 'abcdefgh';

function sq(r, c) { return `${FILES[c]}${r + 1}`; }
function inBounds(r, c) { return r >= 0 && r < 8 && c >= 0 && c < 8; }
function cloneBoard(board) { return board.map(row => row.map(cell => (cell ? { ...cell } : null))); }

function initialState() {
  const back = ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'];
  const board = Array.from({ length: 8 }, () => Array(8).fill(null));
  for (let c = 0; c < 8; c++) {
    board[0][c] = { type: back[c], color: 'w' };
    board[1][c] = { type: 'p', color: 'w' };
    board[6][c] = { type: 'p', color: 'b' };
    board[7][c] = { type: back[c], color: 'b' };
  }
  return {
    board, turn: 'w',
    castling: { wK: true, wQ: true, bK: true, bQ: true },
    enPassant: null,
    status: 'active', winner: null,
    history: [], lastMove: null,
  };
}

const SLIDE_DIRS = {
  b: [[-1, -1], [-1, 1], [1, -1], [1, 1]],
  r: [[-1, 0], [1, 0], [0, -1], [0, 1]],
  q: [[-1, -1], [-1, 1], [1, -1], [1, 1], [-1, 0], [1, 0], [0, -1], [0, 1]],
};
const KNIGHT_DELTAS = [[-2, -1], [-2, 1], [-1, -2], [-1, 2], [1, -2], [1, 2], [2, -1], [2, 1]];
const KING_DELTAS = [[-1, -1], [-1, 0], [-1, 1], [0, -1], [0, 1], [1, -1], [1, 0], [1, 1]];

// Semua "kemungkinan" gerak sebuah bidak TANPA cek apakah raja sendiri jadi skak (dipakai
// juga buat cek "apakah kotak ini diserang" - jadi jangan rekursif ke legal-move check).
function pseudoMoves(state, r, c) {
  const piece = state.board[r][c];
  if (!piece) return [];
  const moves = [];
  const enemy = piece.color === 'w' ? 'b' : 'w';
  const at = (rr, cc) => state.board[rr][cc];

  if (piece.type === 'p') {
    const dir = piece.color === 'w' ? 1 : -1;
    const startRow = piece.color === 'w' ? 1 : 6;
    const promoRow = piece.color === 'w' ? 7 : 0;
    if (inBounds(r + dir, c) && !at(r + dir, c)) {
      moves.push({ r: r + dir, c, promotion: r + dir === promoRow });
      if (r === startRow && !at(r + 2 * dir, c)) moves.push({ r: r + 2 * dir, c, doubleStep: true });
    }
    for (const dc of [-1, 1]) {
      const rr = r + dir, cc = c + dc;
      if (!inBounds(rr, cc)) continue;
      const target = at(rr, cc);
      if (target && target.color === enemy) moves.push({ r: rr, c: cc, capture: true, promotion: rr === promoRow });
      else if (state.enPassant && state.enPassant.r === rr && state.enPassant.c === cc) {
        moves.push({ r: rr, c: cc, capture: true, enPassant: true });
      }
    }
  } else if (piece.type === 'n') {
    for (const [dr, dc] of KNIGHT_DELTAS) {
      const rr = r + dr, cc = c + dc;
      if (!inBounds(rr, cc)) continue;
      const target = at(rr, cc);
      if (!target || target.color === enemy) moves.push({ r: rr, c: cc, capture: !!target });
    }
  } else if (piece.type === 'k') {
    for (const [dr, dc] of KING_DELTAS) {
      const rr = r + dr, cc = c + dc;
      if (!inBounds(rr, cc)) continue;
      const target = at(rr, cc);
      if (!target || target.color === enemy) moves.push({ r: rr, c: cc, capture: !!target });
    }
    // Castling ditambahkan di generateLegalMoves (butuh cek "lewat kotak yang diserang").
  } else {
    for (const [dr, dc] of SLIDE_DIRS[piece.type]) {
      let rr = r + dr, cc = c + dc;
      while (inBounds(rr, cc)) {
        const target = at(rr, cc);
        if (!target) { moves.push({ r: rr, c: cc }); }
        else { if (target.color === enemy) moves.push({ r: rr, c: cc, capture: true }); break; }
        rr += dr; cc += dc;
      }
    }
  }
  return moves;
}

function findKing(state, color) {
  for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) {
    const p = state.board[r][c];
    if (p && p.type === 'k' && p.color === color) return { r, c };
  }
  return null;
}

// Apakah kotak (r,c) sedang diserang oleh `byColor`.
function isSquareAttacked(state, r, c, byColor) {
  for (let rr = 0; rr < 8; rr++) for (let cc = 0; cc < 8; cc++) {
    const p = state.board[rr][cc];
    if (!p || p.color !== byColor) continue;
    for (const m of pseudoMoves(state, rr, cc)) if (m.r === r && m.c === c) return true;
  }
  return false;
}

function isInCheck(state, color) {
  const k = findKing(state, color);
  if (!k) return false;
  return isSquareAttacked(state, k.r, k.c, color === 'w' ? 'b' : 'w');
}

// Terapkan sebuah pseudo-move ke SALINAN board (buat simulasi cek-legal / eksekusi beneran).
function applyMoveToBoard(board, from, to, move, promotionType) {
  const piece = board[from.r][from.c];
  const b = board;
  b[to.r][to.c] = { ...piece };
  b[from.r][from.c] = null;
  if (move.enPassant) b[from.r][to.c] = null; // bidak yang kena en passant ada di baris asal, kolom tujuan
  if (move.promotion) b[to.r][to.c].type = promotionType || 'q';
  if (piece.type === 'k' && Math.abs(to.c - from.c) === 2) {
    // castling: pindahkan benteng juga
    const rookFromC = to.c > from.c ? 7 : 0;
    const rookToC = to.c > from.c ? to.c - 1 : to.c + 1;
    b[to.r][rookToC] = b[from.r][rookFromC];
    b[from.r][rookFromC] = null;
  }
  return b;
}

// Gerak LEGAL sebuah bidak di (r,c): pseudo-move yang TIDAK bikin raja sendiri skak, plus
// castling (dicek terpisah karena syaratnya beda: lewat & mendarat di kotak yang tidak diserang).
function generateLegalMoves(state, r, c) {
  const piece = state.board[r][c];
  if (!piece || piece.color !== state.turn) return [];
  const legal = [];
  for (const m of pseudoMoves(state, r, c)) {
    const board2 = applyMoveToBoard(cloneBoard(state.board), { r, c }, { r: m.r, c: m.c }, m);
    const state2 = { ...state, board: board2 };
    if (!isInCheck(state2, piece.color)) legal.push(m);
  }
  if (piece.type === 'k' && !isInCheck(state, piece.color)) {
    const row = piece.color === 'w' ? 0 : 7;
    const enemy = piece.color === 'w' ? 'b' : 'w';
    const canCastle = (side) => {
      const key = piece.color + (side === 'k' ? 'K' : 'Q');
      if (!state.castling[key]) return false;
      const cols = side === 'k' ? [5, 6] : [1, 2, 3];
      for (const cc of cols) if (state.board[row][cc]) return false;
      const passCols = side === 'k' ? [4, 5, 6] : [4, 3, 2];
      for (const cc of passCols) if (isSquareAttacked(state, row, cc, enemy)) return false;
      return true;
    };
    if (c === 4 && r === row) {
      if (canCastle('k')) legal.push({ r: row, c: 6, castle: 'k' });
      if (canCastle('q')) legal.push({ r: row, c: 2, castle: 'q' });
    }
  }
  return legal;
}

function allLegalMoves(state, color) {
  const out = [];
  for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) {
    const p = state.board[r][c];
    if (p && p.color === color) for (const m of generateLegalMoves(state, r, c)) out.push({ from: { r, c }, to: { r: m.r, c: m.c }, move: m });
  }
  return out;
}

// Eksekusi move BENERAN (bukan simulasi) - update giliran, hak castling, en passant, status game.
function makeMove(state, from, to, promotionType = 'q') {
  const legal = generateLegalMoves(state, from.r, from.c).find(m => m.r === to.r && m.c === to.c);
  if (!legal) return { ok: false, error: 'Gerakan tidak legal.' };
  const piece = state.board[from.r][from.c];
  const board = applyMoveToBoard(cloneBoard(state.board), from, to, legal, promotionType);

  const castling = { ...state.castling };
  if (piece.type === 'k') { castling[piece.color + 'K'] = false; castling[piece.color + 'Q'] = false; }
  if (piece.type === 'r') {
    if (from.r === (piece.color === 'w' ? 0 : 7) && from.c === 0) castling[piece.color + 'Q'] = false;
    if (from.r === (piece.color === 'w' ? 0 : 7) && from.c === 7) castling[piece.color + 'K'] = false;
  }
  // Kalau benteng lawan yang KETANGKEP, hak castling sisi itu juga hilang.
  const capturedPiece = state.board[to.r][to.c];
  if (capturedPiece && capturedPiece.type === 'r') {
    const opColor = capturedPiece.color;
    if (to.r === (opColor === 'w' ? 0 : 7) && to.c === 0) castling[opColor + 'Q'] = false;
    if (to.r === (opColor === 'w' ? 0 : 7) && to.c === 7) castling[opColor + 'K'] = false;
  }

  const enPassant = legal.doubleStep ? { r: (from.r + to.r) / 2, c: from.c } : null;
  const nextTurn = state.turn === 'w' ? 'b' : 'w';
  const notation = `${piece.type === 'p' ? '' : piece.type.toUpperCase()}${legal.capture ? 'x' : ''}${sq(to.r, to.c)}${legal.castle ? (legal.castle === 'k' ? ' (O-O)' : ' (O-O-O)') : ''}`;

  let next = {
    board, turn: nextTurn, castling, enPassant, status: 'active', winner: null,
    history: [...state.history, notation], lastMove: { from, to },
  };
  const inCheck = isInCheck(next, nextTurn);
  const hasMoves = allLegalMoves(next, nextTurn).length > 0;
  if (!hasMoves) {
    next.status = inCheck ? 'checkmate' : 'stalemate';
    next.winner = inCheck ? piece.color : null;
  } else if (inCheck) {
    next.status = 'check';
  }
  return { ok: true, state: next, captured: capturedPiece, notation };
}

// AI dengan 4 tingkat difficulty (easy/medium/hard/extreme). Basisnya tetap heuristik greedy
// 1-ply yang sama (skakmat > capture bernilai tinggi > gerak yang bikin skak), tapi:
// - easy/medium/hard beda di "blunder rate" (peluang malah ambil gerakan ACAK, bukan yang
//   dinilai terbaik) - makin gampang makin sering blunder.
// - extreme TIDAK PERNAH blunder, dan tambahan mikir 1 langkah ke depan (2-ply): dari beberapa
//   kandidat gerakan terbaik versi 1-ply, pilih yang balasan TERBAIK lawan paling kecil - biar
//   AI tidak jalan ke posisi yang jelas-jelas ketangkep balik.
const PIECE_VALUE = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };
const BLUNDER_RATE = { easy: 0.75, medium: 0.35, hard: 0.08, extreme: 0 };

function scoreMove(state, color, m) {
  const res = makeMove(state, m.from, m.to, 'q');
  if (!res.ok) return { score: -Infinity, res: null };
  let score = 0;
  if (res.state.status === 'checkmate' && res.state.winner === color) score += 1000;
  if (m.move.capture) {
    const captured = state.board[m.to.r][m.to.c] || (m.move.enPassant ? { type: 'p' } : null);
    if (captured) score += (PIECE_VALUE[captured.type] || 0) * 10;
  }
  if (res.state.status === 'check' || res.state.status === 'checkmate') score += 2;
  return { score, res: res.state };
}

function pickAiMove(state, color, difficulty = 'hard') {
  const moves = allLegalMoves(state, color);
  if (!moves.length) return null;

  const blunderRate = BLUNDER_RATE[difficulty] ?? BLUNDER_RATE.hard;
  if (blunderRate > 0 && Math.random() < blunderRate) {
    return moves[Math.floor(Math.random() * moves.length)];
  }

  const scored = moves.map(m => ({ m, ...scoreMove(state, color, m) })).filter(x => x.res);
  if (!scored.length) return moves[0];

  if (difficulty !== 'extreme') {
    scored.sort((a, b) => (b.score + Math.random() * 0.5) - (a.score + Math.random() * 0.5));
    return scored[0].m;
  }

  // EXTREME: dari top kandidat 1-ply, cek balasan terbaik lawan, minimalkan itu.
  scored.sort((a, b) => b.score - a.score);
  const opColor = color === 'w' ? 'b' : 'w';
  const topCandidates = scored.slice(0, Math.min(6, scored.length));
  let best = topCandidates[0], bestNet = -Infinity;
  for (const cand of topCandidates) {
    const opMoves = allLegalMoves(cand.res, opColor);
    let worstReplyForUs = 0;
    for (const om of opMoves) {
      const opScored = scoreMove(cand.res, opColor, om);
      if (opScored.score > worstReplyForUs) worstReplyForUs = opScored.score;
    }
    const net = cand.score - worstReplyForUs;
    if (net > bestNet) { bestNet = net; best = cand; }
  }
  return best.m;
}

module.exports = {
  initialState, generateLegalMoves, allLegalMoves, makeMove, isInCheck, pickAiMove, sq, FILES,
};
