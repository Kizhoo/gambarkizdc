// Test integrasi: mountMinigame pada Express + http server sungguhan.
// Memverifikasi: halaman publik /minigame, config, state (auto-create),
// save (clamp anti-cheat), claim (gate minimal wave + saldo masuk),
// leaderboard, dan build-info — end-to-end tanpa Discord.
process.env.KIZHOO_DB_PATH = '/tmp/kiz_minigame_test.sqlite';
require('fs').rmSync('/tmp/kiz_minigame_test.sqlite', { force: true });
const express = require('express');
const http = require('http');
const webDb = require('../database/webDb');
const { mountMinigame } = require('../utils/minigameServer');
const { getEconomy, updateBalance } = require('../database/db');

const app = express();
app.use(express.json());

const auth = (req, res, next) => { req.session = { userId: req.headers['x-test-user'] || '777', username: 'Tester' }; next(); };
const client = {
  guilds: { cache: new Map([['g1', { id: 'g1' }]]) },
  users: { cache: new Map(), fetch: async () => null },
};
mountMinigame(app, { auth, resolveUserId: (req) => (req.session && req.session.userId) || null, client });

const server = http.createServer(app);
let pass = 0, fail = 0;
const ok = (cond, label) => { if (cond) { pass++; console.log('  OK', label); } else { fail++; console.log('  FAIL', label); } };

function req(port, path, { method = 'GET', body = null, user = null } = {}) {
  return new Promise((resolve, reject) => {
    const headers = { 'content-type': 'application/json' };
    if (user) headers['x-test-user'] = user;
    const r = http.request({ host: '127.0.0.1', port, path, method, headers }, (res) => {
      let data = '';
      res.on('data', (c) => { data += c; });
      res.on('end', () => {
        let json = null; try { json = JSON.parse(data); } catch (_) {}
        resolve({ status: res.statusCode, json, body: data });
      });
    });
    r.on('error', reject);
    if (body != null) r.write(JSON.stringify(body));
    r.end();
  });
}

server.listen(0, async () => {
  const port = server.address().port;

  console.log('== 1. Halaman & build-info ==');
  const page = await req(port, '/minigame');
  ok(page.status === 200 && /KizDefense/.test(page.body), '/minigame halaman hub ter-render');
  const game = await req(port, '/kizdefense');
  ok(game.status === 200 && /kizdefense\.js/.test(game.body), '/kizdefense halaman game ter-render');
  const bi = await req(port, '/api/minigame/build-info');
  ok(bi.json && bi.json.ok && /^\d{4}\.\d{2}\.\d{2}-/.test(bi.json.build), 'build-info mengembalikan stamp: ' + (bi.json && bi.json.build));

  console.log('== 2. Config ==');
  const cfg = await req(port, '/api/minigame/config');
  ok(cfg.json && cfg.json.config && cfg.json.config.maxTier === 20, 'config: 20 tier menara (T1-T20)');
  ok(Array.isArray(cfg.json.config.slotKeys) && cfg.json.config.slotKeys.length === 15, 'config: 15 slot (B0-B4 + G0-G9)');
  ok(cfg.json.config.reward.kizcoPerWave === 25, 'config: reward Kizco per wave = 25');

  console.log('== 3. State (auto-create + idle) ==');
  const st = await req(port, '/api/minigame/state');
  ok(st.json && st.json.ok && st.json.progress.wave === 1, 'state: progress baru dibuat (wave 1)');
  ok(typeof st.json.progress.idleEarned === 'number', 'state: idle earnings terhitung');

  console.log('== 4. Save + clamp anti-cheat ==');
  const sv1 = await req(port, '/api/minigame/save', { method: 'POST', body: { wave: 30, bestWave: 30, coins: 999999999, totalKills: 500, turrets: { B0: { tier: 3 }, G2: { tier: 20 }, G7: { tier: 99 }, bogus: {} } } });
  ok(sv1.json && sv1.json.ok, 'save diterima');
  ok(sv1.json.progress.bestWave === 30, 'bestWave tersimpan 30');
  ok(sv1.json.progress.coins < 999999999, 'coins besar di-clamp server (anti-cheat)');
  const prog = webDb.getProgress('777');
  let savedTurrets = JSON.parse(prog.turrets);
  ok(savedTurrets['B0'] && savedTurrets['B0'].tier === 3, 'turret B0 tersimpan (format v2)');
  ok(savedTurrets['G2'] && savedTurrets['G2'].tier === 20, 'turret G2 tier 20 tersimpan');
  ok(!savedTurrets['bogus'] && !savedTurrets['G7'], 'turret tidak valid dibersihkan (tier 99 ditolak)');
  // rollback wave tidak boleh menurunkan bestWave (diverifikasi lewat modul langsung,
  // karena endpointnya sendiri kena rate limit 4 saat dipanggil beruntun)
  const sv2 = await req(port, '/api/minigame/save', { method: 'POST', body: { wave: 3, bestWave: 3, coins: 100 } });
  ok(sv2.status === 429, 'save beruntun kena rate limit 429');
  webDb.saveProgress('777', { wave: 3, bestWave: 3, coins: 100 });
  ok(webDb.getProgress('777').bestWave === 30, 'bestWave monotonic (anti rollback)');

  console.log('== 4b. Impor demo -> akun baru ==');
  const imOk = await req(port, '/api/minigame/import', { method: 'POST', user: '555', body: { wave: 7, bestWave: 9, coins: 1500, totalKills: 60, slots: { B0: { tier: 4 }, G0: { tier: 3 } } } });
  if (imOk.json && imOk.json.ok) {
    ok(imOk.json.imported === true && imOk.json.progress.coins === 1500, 'impor demo berhasil (koin tidak hilang)');
    ok(webDb.getProgress('555').turrets.includes('"tier":4'), 'turret demo tersimpan ke akun');
    const imDb = await req(port, '/api/minigame/import', { method: 'POST', user: '555', body: { wave: 99, bestWave: 99, coins: 999999 } });
    ok(imDb.status === 400, 'impor kedua ditolak (sudah ada progres)');
    const imOld = await req(port, '/api/minigame/import', { method: 'POST', user: '777', body: { wave: 99, bestWave: 99, coins: 999999 } });
    ok(imOld.status === 400, 'impor ke akun lama ditolak');
  } else {
    ok(false, 'impor demo gagal: ' + JSON.stringify(imOk.json));
  }

  console.log('== 5. Claim ==');
  const cl1 = await req(port, '/api/minigame/claim', { method: 'POST', body: { guildId: 'g1' } });
  ok(cl1.json && cl1.json.ok, 'klaim 30 wave berhasil');
  ok(cl1.json.amount === 750, 'jumlah klaim = 30 x 25 = 750 KZC');
  ok(getEconomy('g1', '777').balance === 750, 'saldo economy bertambah 750');
  const cl2 = await req(port, '/api/minigame/claim', { method: 'POST', body: { guildId: 'g1' } });
  ok(cl2.status === 429 || (cl2.json && !cl2.json.ok), 'klaim ulang diblokir (cooldown/ambang)');
  const cl3 = await req(port, '/api/minigame/claim', { method: 'POST', body: { guildId: 'g-tidak-ada' } });
  ok(cl3.status === 400, 'guild asing ditolak');

  console.log('== 6. Leaderboard ==');
  webDb.saveProgress('888', { wave: 12, bestWave: 12, coins: 50, totalKills: 40 });
  const lb = await req(port, '/api/minigame/leaderboard');
  ok(lb.json && lb.json.leaderboard.length >= 2, 'leaderboard berisi pemain');
  ok(lb.json.leaderboard[0].bestWave >= lb.json.leaderboard[1].bestWave, 'leaderboard terurut');

  console.log('\n==== HASIL: ' + pass + ' lulus, ' + fail + ' gagal ====');
  process.exitCode = fail ? 1 : 0;
  try { server.close(); } catch (_) {}
  try { server.closeAllConnections && server.closeAllConnections(); } catch (_) {}
});
