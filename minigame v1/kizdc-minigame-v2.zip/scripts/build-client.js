#!/usr/bin/env node
/* ============================================================================
 * BUILD CLIENT — minify rpg.js -> rpg.min.js (pihak hosting ramah)
 * ----------------------------------------------------------------------------
 * PENTING: versi ini pakai MINIFIKASI STANDAR (terser) saja, BUKAN obfuscation.
 * Alasan: banyak shared hosting (termasuk MonkeyBytes) melarang kode
 * ter-obfuscate lewat scanner ToS otomatis (rule OBFUSCATED_CODE), karena
 * pola stringArray/hex-names/self-defending identik dengan malware.
 * Minifikasi terser adalah praktik industri normal (seperti jQuery, React,
 * dsb.) — struktur & string tetap terbaca oleh scanner, hanya dipadatkan.
 *
 * Proteksi anti-klon TIDAK bergantung pada obfuscation — tetap dijaga oleh:
 *   - Server : hostGuard + originGuardForReq (domain lock, API mati di klon)
 *   - Client : security-lock.js + security gate rpg.js (baris paling atas)
 *   - Aset   : hotlinkGuard
 *
 * Jalankan:  npm run build:client   (setiap selesai edit rpg.js)
 * Rpg.html otomatis pakai rpg.min.js; kalau file ini belum ada, dia fallback
 * ke rpg.js — jadi pengembangan tetap nyaman tanpa build.
 * ========================================================================== */
const fs = require('fs');
const path = require('path');
const { minify } = require('terser');

const root = path.join(__dirname, '..');
const src = path.join(root, 'dashboard', 'public', 'rpg.js');
const out = path.join(root, 'dashboard', 'public', 'rpg.min.js');

const source = fs.readFileSync(src, 'utf8');
console.log('[build-client] Sumber :', src, `(${(source.length / 1024).toFixed(1)} KB)`);

(async () => {
  const result = await minify(source, {
    compress: {
      dead_code: true,
      drop_console: false,      // jangan buang console (QA butuh log error)
      passes: 2,
    },
    mangle: {
      toplevel: false,          // global (window.__kzRpgLoaded dll) tetap utuh
      reserved: ['Phaser', 'RPG_CONFIG', '__kzSecGate', '__KZ_SEC_BAKE', '__kzRpgLoaded'],
    },
    format: {
      comments: false,
      ascii_only: true,
    },
    sourceMap: false,
  });

  if (result.error) {
    console.error('[build-client] GAGAL minify:', result.error);
    process.exit(1);
  }

  const code = result.code + '\n';
  fs.writeFileSync(out, code);
  console.log('[build-client] Output :', out, `(${(code.length / 1024).toFixed(1)} KB)`);

  // Validasi hasil: harus masih jadi JavaScript yang valid.
  const { execFileSync } = require('child_process');
  try {
    execFileSync(process.execPath, ['--check', out], { stdio: 'pipe' });
    console.log('[build-client] node --check LULUS — rpg.min.js siap dipakai.');
  } catch (e) {
    console.error('[build-client] GAGAL: hasil minify tidak valid!', e.stderr ? String(e.stderr) : e.message);
    process.exit(1);
  }
})();
