const { EmbedBuilder } = require('discord.js');
const { getGuildConfig } = require('../database/db');
const { sendLog } = require('../utils/serverLog');
const { buildWelcomePayload } = require('../utils/welcomeMessage');
const config = require('../config.json');

module.exports = {
  name: 'guildMemberAdd',
  async execute(member, client) {
    const cfg = getGuildConfig(member.guild.id);

    // Log join ke log channel (terpisah dari welcome)
    sendLog(member.guild, {
      title: 'Member Bergabung',
      color: config.successColor,
      author: { name: member.user.tag, iconURL: member.user.displayAvatarURL() },
      fields: [
        { name: 'Total member', value: `${member.guild.memberCount}`, inline: true },
        { name: 'Akun dibuat', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`, inline: true },
      ],
      footer: `User ID: ${member.id}`,
    });

    // ===== ANTI-RAID (cek umur akun) =====
    if (cfg.antiraidEnabled) {
      const accountAgeDays = (Date.now() - member.user.createdTimestamp) / 86400000;
      if (accountAgeDays < (cfg.minAccountAgeDays || 3)) {
        await member.send(
          `Kamu ditolak bergabung ke **${member.guild.name}** karena akun Discord kamu masih terlalu baru (proteksi anti-raid). Coba lagi nanti.`
        ).catch(() => {});
        await member.kick('Anti-raid: akun terlalu baru').catch(() => {});

        if (cfg.logChannel) {
          const logChannel = member.guild.channels.cache.get(cfg.logChannel);
          if (logChannel) {
            logChannel.send({
              embeds: [new EmbedBuilder()
                .setColor(config.errorColor)
                .setTitle('Anti-Raid: Member Ditolak')
                .setDescription(`**${member.user.tag}** (${member.id}) dikick otomatis.\nUmur akun: ${accountAgeDays.toFixed(1)} hari (minimal ${cfg.minAccountAgeDays} hari).`)
                .setTimestamp()],
            }).catch(() => {});
          }
        }
        return; // stop, jangan lanjut ke autorole/welcome
      }
    }

    // ===== AUTOROLE =====
    if (cfg.autoroleId) {
      const role = member.guild.roles.cache.get(cfg.autoroleId);
      if (role) {
        member.roles.add(role).catch(err => console.error('Gagal kasih autorole: ', err));
      }
    }

    // ===== WELCOME MESSAGE =====
    if (!cfg.welcomeEnabled || !cfg.welcomeChannel) return;

    const channel = member.guild.channels.cache.get(cfg.welcomeChannel);
    if (!channel) return;

    // Gaya (embed klasik / kartu gambar) ditentukan oleh welcomeStyle di guild_config, diatur
    // lewat /welcome pilih-gaya. Payload-nya dibangun di utils/welcomeMessage.js supaya SAMA
    // PERSIS dengan yang dilihat admin waktu preview - tidak ada implementasi ganda di sini.
    buildWelcomePayload(member)
      .then(payload => channel.send(payload))
      .catch(err => console.error('Gagal kirim welcome message: ', err));
  },
};
