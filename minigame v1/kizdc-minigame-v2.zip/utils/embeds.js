const { EmbedBuilder } = require('discord.js');
const config = require('../config.json');

function baseEmbed() {
  return new EmbedBuilder().setColor(config.embedColor).setFooter({ text: config.footer }).setTimestamp();
}

function successEmbed(description) {
  return baseEmbed().setColor(config.successColor).setDescription(`${description}`);
}

function errorEmbed(description) {
  return baseEmbed().setColor(config.errorColor).setDescription(`${description}`);
}

function warnEmbed(description) {
  return baseEmbed().setColor(config.warnColor).setDescription(`${description}`);
}

module.exports = { baseEmbed, successEmbed, errorEmbed, warnEmbed };
