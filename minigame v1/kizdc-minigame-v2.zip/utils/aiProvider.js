// ============================================================================
// AI PROVIDER TERPADU
// ----------------------------------------------------------------------------
// Mendukung banyak provider & model, semua diatur dari config.json bagian "ai".
//   - cloudflare  : gratis, pakai CLOUDFLARE_ACCOUNT_ID + CLOUDFLARE_API_TOKEN
//   - openai      : model premium (gpt-4o, dll), pakai OPENAI_API_KEY
//   - groq        : cepat & gratis-tier, pakai GROQ_API_KEY
//   - gemini      : Google, pakai GEMINI_API_KEY
//
// generateText(messages, { provider, model }) -> string
// generateImage(prompt) -> Buffer (PNG)
//
// Kalau premiumEnabled=true di config, generateText tanpa override otomatis
// memakai premiumProvider + premiumModel.
// ============================================================================
const settings = require('./settings');

const CF_API_BASE = 'https://api.cloudflare.com/client/v4/accounts';

function resolveTextTarget(override = {}) {
  const ai = settings.get('ai', {});
  if (override.provider && override.model) return { provider: override.provider, model: override.model };
  if (override.model) return { provider: ai.provider || 'cloudflare', model: override.model };
  if (ai.premiumEnabled) return { provider: ai.premiumProvider || 'openai', model: ai.premiumModel || 'gpt-4o' };
  return { provider: ai.provider || 'cloudflare', model: ai.model || '@cf/meta/llama-3.1-8b-instruct' };
}

// ---------- CLOUDFLARE ----------
function cfCreds() {
  const accountId = process.env.CLOUDFLARE_ACCOUNT_ID;
  const apiToken = process.env.CLOUDFLARE_API_TOKEN;
  if (!accountId || !apiToken) throw new Error('CLOUDFLARE_ACCOUNT_ID / CLOUDFLARE_API_TOKEN belum diisi di .env.');
  return { accountId, apiToken };
}

async function cfText(model, messages) {
  const { accountId, apiToken } = cfCreds();
  const res = await fetch(`${CF_API_BASE}/${accountId}/ai/run/${model}`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${apiToken}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ messages, max_tokens: settings.get('ai.maxTokens', 2048) }),
  });
  if (!res.ok) throw new Error(`Cloudflare AI (${model}) status ${res.status}: ${(await res.text().catch(() => '')).slice(0, 300)}`);
  const data = await res.json();
  if (!data.success || !data.result?.response) {
    // BUGFIX: pesan error sebelumnya cuma nampilin data.errors, yang kadang KOSONG ([]) walau
    // request-nya beneran gagal (mis. model butuh parameter tambahan yang tidak dikirim, atau
    // belum ter-enable buat akun ini) - jadinya error "Cloudflare AI gagal: []" yang sama sekali
    // tidak membantu didiagnosis. Sekarang seluruh body respons disertakan biar kelihatan apa
    // yang sebenarnya dikembalikan Cloudflare.
    throw new Error(`Cloudflare AI (${model}) gagal: ${JSON.stringify(data).slice(0, 400)}`);
  }
  // BUGFIX: beberapa model Cloudflare Workers AI (terutama yang mendukung tool-calling)
  // kadang mengembalikan `result.response` sebagai object/array, bukan string murni, walau
  // tidak dipakai lewat mode tool-calling. Konsumen (mis. lunaAgent.extractJson) selalu
  // mengasumsikan string dan crash dengan "text.trim is not a function" kalau ini lolos
  // sebagai object. Paksa jadi string di sini biar SEMUA pemanggil generateText() aman.
  const r = data.result.response;
  return typeof r === 'string' ? r : JSON.stringify(r);
}

// ---------- OPENAI-COMPATIBLE (openai & groq) ----------
async function openaiCompatText({ baseUrl, apiKey, keyName }, model, messages) {
  if (!apiKey) throw new Error(`${keyName} belum diisi. Set lewat secret/env dulu untuk pakai model premium ini.`);
  const res = await fetch(`${baseUrl}/chat/completions`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ model, messages, temperature: 0.7, max_tokens: settings.get('ai.maxTokens', 2048) }),
  });
  if (!res.ok) throw new Error(`${keyName} status ${res.status}: ${(await res.text().catch(() => '')).slice(0, 200)}`);
  const data = await res.json();
  const content = data.choices?.[0]?.message?.content;
  if (!content) throw new Error('Provider AI tidak mengembalikan jawaban.');
  return content;
}

// ---------- GEMINI ----------
async function geminiText(model, messages) {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error('GEMINI_API_KEY belum diisi.');
  const sys = messages.filter(m => m.role === 'system').map(m => m.content).join('\n');
  const contents = messages.filter(m => m.role !== 'system').map(m => ({
    role: m.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: m.content }],
  }));
  const body = { contents, generationConfig: { maxOutputTokens: settings.get('ai.maxTokens', 2048) } };
  if (sys) body.systemInstruction = { parts: [{ text: sys }] };
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`Gemini status ${res.status}: ${(await res.text().catch(() => '')).slice(0, 200)}`);
  const data = await res.json();
  const content = data.candidates?.[0]?.content?.parts?.map(p => p.text).join('');
  if (!content) throw new Error('Gemini tidak mengembalikan jawaban.');
  return content;
}

async function generateText(messages, override = {}) {
  const { provider, model } = resolveTextTarget(override);
  switch (provider) {
    case 'openai':
      return openaiCompatText({ baseUrl: 'https://api.openai.com/v1', apiKey: process.env.OPENAI_API_KEY, keyName: 'OPENAI_API_KEY' }, model, messages);
    case 'groq':
      return openaiCompatText({ baseUrl: 'https://api.groq.com/openai/v1', apiKey: process.env.GROQ_API_KEY, keyName: 'GROQ_API_KEY' }, model, messages);
    case 'gemini':
      return geminiText(model, messages);
    case 'local':
      // AI lokal/offline: llama.cpp server (atau server OpenAI-compatible lain) di mesin
      // terpisah. Bebas biaya per request & tidak pakai API key cloud. Lihat scripts/local-ai/README.md.
      return openaiCompatText({ baseUrl: process.env.LOCAL_AI_BASE_URL || 'http://localhost:8080/v1', apiKey: process.env.LOCAL_AI_API_KEY || 'local', keyName: 'LOCAL_AI' }, model, messages);
    case 'cloudflare':
    default: {
      // Rantai fallback: model utama -> 70B (kualitas masih bagus, sudah kebukti jalan) -> 8B
      // (paling dasar, PASTI selalu tersedia). Kalau model utama gagal (belum ter-enable buat
      // akun ini, dll), daripada seluruh fitur AI mati total, otomatis coba yang berikutnya.
      const FALLBACK_CHAIN = ['@cf/meta/llama-3.3-70b-instruct-fp8-fast', '@cf/meta/llama-3.1-8b-instruct'];
      const tryChain = [model, ...FALLBACK_CHAIN.filter(m => m !== model)];
      let lastErr;
      for (const m of tryChain) {
        try {
          return await cfText(m, messages);
        } catch (e) {
          lastErr = e;
          console.warn(`[aiProvider] Model "${m}" gagal (${e.message})${m !== tryChain[tryChain.length - 1] ? ', coba model berikutnya.' : '.'}`);
        }
      }
      throw lastErr;
    }
  }
}

// ---------- IMAGE ----------
async function generateImage(prompt) {
  const ai = settings.get('ai', {});
  // OpenAI DALL-E kalau premium + OPENAI_API_KEY tersedia
  if (ai.premiumEnabled && ai.premiumProvider === 'openai' && process.env.OPENAI_API_KEY) {
    const res = await fetch('https://api.openai.com/v1/images/generations', {
      method: 'POST',
      headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: 'dall-e-3', prompt, n: 1, size: '1024x1024', response_format: 'b64_json' }),
    });
    if (!res.ok) throw new Error(`OpenAI image status ${res.status}: ${(await res.text().catch(() => '')).slice(0, 200)}`);
    const data = await res.json();
    return Buffer.from(data.data[0].b64_json, 'base64');
  }
  // Default: Cloudflare Stable Diffusion
  const { accountId, apiToken } = cfCreds();
  const imageModel = ai.imageModel || '@cf/stabilityai/stable-diffusion-xl-base-1.0';
  const res = await fetch(`${CF_API_BASE}/${accountId}/ai/run/${imageModel}`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${apiToken}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt }),
  });
  if (!res.ok) throw new Error(`Cloudflare AI image status ${res.status}: ${(await res.text().catch(() => '')).slice(0, 200)}`);
  const ct = res.headers.get('content-type') || '';
  if (ct.includes('application/json')) {
    const data = await res.json();
    throw new Error(`Gagal membuat gambar: ${JSON.stringify(data.errors || data)}`);
  }
  return Buffer.from(await res.arrayBuffer());
}

module.exports = { generateText, generateImage, resolveTextTarget };
