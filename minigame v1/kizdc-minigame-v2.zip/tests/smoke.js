const fs = require('fs');
const os = require('os');
const path = require('path');

const tempDb = path.join(os.tmpdir(), `kizhoo-smoke-${process.pid}.sqlite`);
process.env.KIZHOO_DB_PATH = tempDb;

function assert(value, message) {
  if (!value) throw new Error(message);
}

try {
  const commandRoot = path.join(__dirname, '..', 'commands');
  const names = new Set();
  const commands = [];
  for (const category of fs.readdirSync(commandRoot)) {
    const categoryPath = path.join(commandRoot, category);
    if (!fs.statSync(categoryPath).isDirectory()) continue;
    for (const file of fs.readdirSync(categoryPath).filter(name => name.endsWith('.js'))) {
      const command = require(path.join(categoryPath, file));
      if (command.subcommandOf) continue;
      assert(command.data && command.execute, `${category}/${file} tidak memiliki data/execute`);
      const json = command.data.toJSON();
      assert(!names.has(json.name), `Command duplikat: ${json.name}`);
      names.add(json.name);
      commands.push(json);
    }
  }
  assert(commands.length <= 100, `Top-level command melebihi batas: ${commands.length}`);
  const games = commands.find(command => command.name === 'games');
  const register = commands.find(command => command.name === 'register');
  // 21 subcommand: 6 game klasik + party + trivia/scramble/wyr + 9 tebak-* + benar-salah + werewolf.
  assert(games?.options?.length === 21, 'Jumlah subcommand /games harus 21');
  assert((register?.options || []).length === 0, '/register harus berupa panel tombol tanpa input command');

  const { roleDeck, determineWinner, tally, chooseWolfTarget, ROLE_DEFS } = require('../utils/werewolfGame');
  for (let count = 4; count <= 8; count++) {
    const deck = roleDeck(count);
    assert(deck.length === count, `Deck ${count} tidak lengkap`);
    assert(deck.every(role => ROLE_DEFS[role]), `Deck ${count} memiliki role tidak valid`);
    const wolves = deck.filter(role => ROLE_DEFS[role].team === 'wolf').length;
    assert(wolves >= 1 && wolves < count / 2, `Deck ${count} tidak seimbang`);
  }
  const parity = { players: [{ alive: true, role: 'werewolf' }, { alive: true, role: 'villager' }] };
  assert(determineWinner(parity) === 'wolf', 'Parity Werewolf tidak terdeteksi');
  parity.players[0].alive = false;
  assert(determineWinner(parity) === 'village', 'Kemenangan desa tidak terdeteksi');
  assert(tally({ a: 'x', b: 'x', c: 'y' }).target === 'x', 'Voting mayoritas gagal');
  assert(tally({ a: 'x', b: 'y' }).tied, 'Voting seri gagal');
  const wolfChoice = chooseWolfTarget({
    players: [
      { id: 'alpha', alive: true, role: 'alpha' },
      { id: 'wolf', alive: true, role: 'werewolf' },
      { id: 'target-a', alive: true, role: 'villager' },
      { id: 'target-b', alive: true, role: 'doctor' },
    ],
    actions: { alpha: { type: 'wolf', targetId: 'target-a' }, wolf: { type: 'wolf', targetId: 'target-b' } },
  });
  assert(wolfChoice === 'target-a', 'Bobot pilihan Alpha Wolf gagal');

  const db = require('../database/db');
  const first = db.registerUser('smoke-user', 'Tester', 18);
  const second = db.registerUser('smoke-user', 'Tester Baru', 19);
  assert(first.registeredAt === second.registeredAt, 'Tanggal registrasi berubah saat update');
  const state = { id: 'smoke-game', guildId: 'smoke-guild', phase: 'lobby', players: [] };
  db.saveWerewolfSession(state);
  assert(db.getWerewolfSessionByGuild('smoke-guild')?.id === state.id, 'Persistensi Werewolf gagal');
  db.deleteWerewolfSession(state.id);
  db.deleteUser('smoke-user');
  db.db.close();

  console.log(`Smoke test lulus: ${commands.length}/100 top-level command, 17 game, deck 4–8 pemain, database aman.`);
} finally {
  for (const suffix of ['', '-wal', '-shm']) {
    try { fs.unlinkSync(`${tempDb}${suffix}`); } catch (_) {}
  }
}
