const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { isOwner } = require('../../utils/ownerCheck');
const { baseEmbed, successEmbed, errorEmbed } = require('../../utils/embeds');
const { safeDefer } = require('../../utils/interactionHelpers');
const { getNodes, addNode, removeNode, discoverOnlineNodes, autoDiscoverAndConnect } = require('../../utils/nodeManager');
const { healthyNodeCount } = require('../../utils/nodeHealthMonitor');

function nodesEmbed(client) {
  const nodes = getNodes();
  const sk = client.kazagumo?.shoukaku;
  const lines = nodes.length ? nodes.map(n => {
    const live = sk?.nodes?.get(n.name);
    const state = live ? (live.state === 2 || live.state === 'CONNECTED' ? 'connected' : 'connecting') : 'idle';
    return `**${n.name}** — \`${n.url}\` ${n.secure ? '(ssl)' : ''} — ${state}`;
  }).join('\n') : 'Belum ada node. Pakai /node add atau /node discover.';

  return baseEmbed()
    .setTitle('Manajemen Node Lavalink')
    .setDescription(lines)
    .setFooter({ text: `Node sehat aktif: ${healthyNodeCount()} • Update tanpa restart` });
}

function controlRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('node_refresh').setLabel('Refresh').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('node_discover').setLabel('Cari Node Online').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('node_heal').setLabel('Auto-Perbaiki').setStyle(ButtonStyle.Success),
  );
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('node')
    .setDescription('[Owner] Kelola node musik Lavalink (hot-update tanpa restart)')
    .addSubcommand(s => s.setName('list').setDescription('Lihat & kelola semua node'))
    .addSubcommand(s => s.setName('add').setDescription('Tambah node baru (langsung aktif tanpa restart)')
      .addStringOption(o => o.setName('name').setDescription('Nama unik node').setRequired(true))
      .addStringOption(o => o.setName('url').setDescription('host:port (mis. lava.host.com:443)').setRequired(true))
      .addStringOption(o => o.setName('auth').setDescription('Password node').setRequired(true))
      .addBooleanOption(o => o.setName('secure').setDescription('Pakai SSL/wss (default true)')))
    .addSubcommand(s => s.setName('remove').setDescription('Hapus node')
      .addStringOption(o => o.setName('name').setDescription('Nama node').setRequired(true).setAutocomplete(true)))
    .addSubcommand(s => s.setName('discover').setDescription('Cari node Lavalink publik yang online dari internet')),

  async autocomplete(interaction) {
    const focused = interaction.options.getFocused().toLowerCase();
    const opts = getNodes().map(n => ({ name: `${n.name} (${n.url})`, value: n.name })).filter(o => o.value.toLowerCase().includes(focused)).slice(0, 25);
    await interaction.respond(opts);
  },

  async execute(interaction, client) {
    if (!isOwner(interaction.user.id)) {
      return interaction.reply({ embeds: [errorEmbed('Command ini khusus owner bot.')], ephemeral: true });
    }
    const sub = interaction.options.getSubcommand();

    if (sub === 'list') {
      return interaction.reply({ embeds: [nodesEmbed(client)], components: [controlRow()], ephemeral: true });
    }

    if (sub === 'add') {
      try {
        const node = addNode(client, {
          name: interaction.options.getString('name'),
          url: interaction.options.getString('url'),
          auth: interaction.options.getString('auth'),
          secure: interaction.options.getBoolean('secure') ?? true,
        });
        return interaction.reply({ embeds: [successEmbed(`Node **${node.name}** ditambahkan & disimpan ke config.json. Sedang menyambung ke \`${node.url}\` tanpa restart.`)], ephemeral: true });
      } catch (e) {
        return interaction.reply({ embeds: [errorEmbed(e.message)], ephemeral: true });
      }
    }

    if (sub === 'remove') {
      try {
        removeNode(client, interaction.options.getString('name'));
        return interaction.reply({ embeds: [successEmbed('Node dihapus dari config & Shoukaku (tanpa restart).')], ephemeral: true });
      } catch (e) {
        return interaction.reply({ embeds: [errorEmbed(e.message)], ephemeral: true });
      }
    }

    if (sub === 'discover') {
      if (!(await safeDefer(interaction, { ephemeral: true }))) return;
      const { source, nodes } = await discoverOnlineNodes(12);
      if (!nodes.length) {
        return interaction.editReply({ embeds: [errorEmbed('Tidak ada node online yang ditemukan dari sumber discovery saat ini.')] });
      }
      const embed = baseEmbed()
        .setTitle('Node Online Ditemukan')
        .setDescription(nodes.map(n => `**${n.name}** — \`${n.url}\` ${n.secure ? '(ssl)' : ''}`).join('\n'))
        .setFooter({ text: `Sumber: ${source} • Klik "Auto-Perbaiki" untuk sambung otomatis` });
      return interaction.editReply({ embeds: [embed], components: [controlRow()] });
    }
  },

  // Handler tombol (dipanggil dari interactionCreate)
  async handleButton(interaction, client) {
    if (!isOwner(interaction.user.id)) {
      return interaction.reply({ embeds: [errorEmbed('Tombol ini khusus owner.')], ephemeral: true });
    }
    const id = interaction.customId;
    if (id === 'node_refresh') {
      return interaction.update({ embeds: [nodesEmbed(client)], components: [controlRow()] });
    }
    if (id === 'node_discover') {
      await interaction.deferUpdate();
      const { source, nodes } = await discoverOnlineNodes(12);
      const embed = nodes.length
        ? baseEmbed().setTitle('Node Online Ditemukan').setDescription(nodes.map(n => `**${n.name}** — \`${n.url}\``).join('\n')).setFooter({ text: `Sumber: ${source}` })
        : errorEmbed('Tidak ada node online ditemukan sekarang.');
      return interaction.editReply({ embeds: [embed], components: [controlRow()] });
    }
    if (id === 'node_heal') {
      await interaction.deferUpdate();
      const result = await autoDiscoverAndConnect(client, 6);
      const embed = result.connected
        ? successEmbed(`Tersambung ke node online: **${result.connected.name}** (\`${result.connected.url}\`). Disimpan ke config.`)
        : errorEmbed(`Gagal menyambung otomatis (mencoba ${result.tried} node). Coba lagi nanti atau /node add manual.`);
      return interaction.editReply({ embeds: [embed], components: [controlRow()] });
    }
  },
};
