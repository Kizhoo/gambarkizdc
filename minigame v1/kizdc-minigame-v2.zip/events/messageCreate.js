const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { getGuildConfig, getLevel, touchXpCooldown, getBannedWords, getAfk, removeAfk, getLevelRewardForLevel, getAiChannel, updateBalance } = require('../database/db');
const { handleAiChannelMessage } = require('../utils/aiChannelHandler');
const { renderLevelUpNotifCard } = require('../utils/profileCard');
const levelEngine = require('../utils/levelEngine');
const webDb = require('../database/webDb');
const config = require('../config.json');

const LINK_REGEX = /(https?:\/\/[^\s]+|discord\.gg\/[^\s]+)/i;
const spamTracker = new Map(); // userId -> { count, lastTimestamp }

module.exports = {
  name: 'messageCreate',
  async execute(message, client) {
    if (!message.guild || message.author.bot) return;

    // ===================== AI CHANNEL (workspace privat) =====================
    // Kalau channel ini terdaftar sebagai channel AI privat, semua pesan di sini dianggap
    // prompt AI - tidak diproses AFK/automod/leveling di bawah karena bukan channel biasa.
    const aiChannelRow = getAiChannel(message.channel.id);
    if (aiChannelRow) {
      return handleAiChannelMessage(message, aiChannelRow);
    }

    const cfg = getGuildConfig(message.guild.id);

    // ===================== AFK SYSTEM =====================
    // Hapus status AFK kalau yang kirim pesan sebelumnya AFK
    const selfAfk = getAfk(message.guild.id, message.author.id);
    if (selfAfk) {
      removeAfk(message.guild.id, message.author.id);
      message.reply({ content: `Selamat datang kembali ${message.author}, status AFK sudah dihapus.`}).catch(() => {});
    }

    // Kasih tau kalau mention orang yang lagi AFK
    if (message.mentions.users.size > 0) {
      for (const [, mentioned] of message.mentions.users) {
        if (mentioned.bot) continue;
        const afk = getAfk(message.guild.id, mentioned.id);
        if (afk) {
          const minutesAgo = Math.floor((Date.now() - afk.timestamp) / 60000);
          message.channel.send(`**${mentioned.username}** sedang AFK (${minutesAgo} menit lalu): ${afk.reason}`).catch(() => {});
        }
      }
    }

    // ===================== AUTOMOD =====================
    if (cfg.automodEnabled && !message.member.permissions.has('ManageMessages')) {
      // Banned words
      const bannedWords = getBannedWords(message.guild.id);
      const contentLower = message.content.toLowerCase();
      const foundWord = bannedWords.find(w => contentLower.includes(w));
      if (foundWord) {
        await message.delete().catch(() => {});
        const warnMsg = await message.channel.send(`${message.author}, pesanmu mengandung kata terlarang dan telah dihapus.`);
        setTimeout(() => warnMsg.delete().catch(() => {}), 5000);
        return;
      }

      // Anti-link
      if (cfg.antiLinkEnabled && LINK_REGEX.test(message.content)) {
        await message.delete().catch(() => {});
        const warnMsg = await message.channel.send(`${message.author}, link tidak diizinkan di sini.`);
        setTimeout(() => warnMsg.delete().catch(() => {}), 5000);
        return;
      }

      // Anti-spam (5 pesan dalam 5 detik)
      if (cfg.antiSpamEnabled) {
        const key = `${message.guild.id}-${message.author.id}`;
        const now = Date.now();
        const tracker = spamTracker.get(key) || { count: 0, first: now };
        if (now - tracker.first > 5000) {
          tracker.count = 1;
          tracker.first = now;
        } else {
          tracker.count++;
        }
        spamTracker.set(key, tracker);

        if (tracker.count >= 5) {
          message.delete().catch(() => {});
          const timeoutMs = 60 * 1000;
          message.member.timeout(timeoutMs, 'Terdeteksi spam otomatis').catch(() => {});
          message.channel.send(`${message.author} di-timeout 1 menit karena spam.`);
          spamTracker.delete(key);
          return;
        }
      }
    }

    // ===================== LEVELING (XP) =====================
    const userLevel = getLevel(message.guild.id, message.author.id);
    const cooldownMs = config.xpCooldownSeconds * 1000;
    if (Date.now() - userLevel.lastXpTimestamp >= cooldownMs) {
      const xpGain = Math.floor(
        Math.random() * (config.xpPerMessage.max - config.xpPerMessage.min + 1) + config.xpPerMessage.min
      );
      // LEVEL TERUNIFIKASI: XP chat masuk ke level global user (SATU level),
      // tabel leveling per-guild ikut disinkronkan di dalam addExp.
      const result = levelEngine.addExp(message.author.id, xpGain, message.guild.id);
      // Catat cooldown XP CHAT terpisah dari sync level supaya aktivitas RPG tidak
      // mem-blok XP dari ngetik pesan (lihat touchXpCooldown di database/db.js).
      touchXpCooldown(message.guild.id, message.author.id);

      if (result.leveledUp) {
        const targetChannelId = cfg.levelUpChannel || message.channel.id;
        const targetChannel = message.guild.channels.cache.get(targetChannelId) || message.channel;

        let roleName = null;
        const reward = getLevelRewardForLevel(message.guild.id, result.toLevel);
        if (reward) {
          const role = message.guild.roles.cache.get(reward.roleId);
          if (role) {
            message.member.roles.add(role).catch(() => {});
            roleName = role.name;
          }
        }

        // GABUNG leveling + economy: tiap naik level, user otomatis dapat gold (config.levelUpGoldPerLevel
        // per level) langsung masuk saldo /economy — jadi progres ngobrol beneran nyambung ke ekonomi bot.
        const goldBonus = result.toLevel * (config.levelUpGoldPerLevel || 25);
        const econ = updateBalance(message.guild.id, message.author.id, goldBonus);

        try {
          // Latar kartu rank per-user (dari kustomisasi profil) ikut dipakai di notif level-up.
          const app = webDb.getUser(message.author.id) || {};
          const png = await renderLevelUpNotifCard({
            user: message.author, member: message.member,
            oldLevel: result.fromLevel, newLevel: result.toLevel,
            xp: result.xpIntoLevel, needed: result.xpForNext,
            goldBonus, newBalance: econ.balance, roleName, guildId: message.guild.id, accent: cfg.welcomeColor, language: cfg.language,
            cardBg: app.cardBg || null, cardBgUrl: app.cardBgUrl || null,
          });
          const file = new AttachmentBuilder(png, { name: 'levelup.png' });
          targetChannel.send({ files: [file] }).catch(() => {});
        } catch (e) {
          // Fallback embed teks lama kalau canvas gagal render.
          const rewardText = roleName ? `\n Kamu mendapat role baru: ${roleName}!` : '';
          const embed = new EmbedBuilder()
            .setColor(config.successColor)
            .setAuthor({ name: message.author.username, iconURL: message.author.displayAvatarURL() })
            .setTitle('Naik Level')
            .setDescription(`Selamat ${message.author}, kamu sekarang **Level ${result.toLevel}** dan dapat 🪙 **${goldBonus}** KZC.${rewardText}`)
            .setFooter({ text: config.footer })
            .setTimestamp();
          targetChannel.send({ embeds: [embed] }).catch(() => {});
        }
      }
    }
  },
};
