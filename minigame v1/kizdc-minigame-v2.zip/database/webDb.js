// ============================================================================
// WEB DB — modul data web & fitur non-game (pengganti rpgDb pasca-penghapusan RPG)
// ----------------------------------------------------------------------------
// Memiliki:
//   1. web_users        — user web (level & XP terunifikasi, kustomisasi kartu)
//   2. web_inventory    — inventaris item (dipakai pasar/lelang web)
//   3. dashboard_sessions — sesi login web (persist, tahan restart)
//   4. web_security_log — audit log lapisan keamanan (di-inject ke utils/security)
//   5. minigame_progress — progres Minigame "KizDefense" (turret defense idle)
//
// MIGRASI JUJUR SATU KALI: kalau database lama masih punya tabel rpg_*
// (era Kizhoo Adventure), level/XP pemain, inventaris item, dan kustomisasi
// kartu dipindahkan ke tabel baru saat boot pertama — progres TIDAK hilang.
// Tabel rpg_* lama tidak pernah ditulis lagi (dibiarkan dorman; aman
// dihapus manual kapan saja lewat SQLite tanpa efek ke bot).
// ============================================================================
const { db } = require('./db');

const now = () => Date.now();

// ================== SKEMA ==================
db.exec(`
CREATE TABLE IF NOT EXISTS web_users (
  userId TEXT PRIMARY KEY,
  xp INTEGER NOT NULL DEFAULT 0,
  level INTEGER NOT NULL DEFAULT 1,
  gameName TEXT,
  title TEXT,
  cardBg TEXT,
  cardBgUrl TEXT,
  createdAt INTEGER NOT NULL,
  updatedAt INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS web_inventory (
  userId TEXT NOT NULL,
  itemId TEXT NOT NULL,
  qty INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (userId, itemId)
);
CREATE TABLE IF NOT EXISTS dashboard_sessions (
  sid TEXT PRIMARY KEY,
  payload TEXT NOT NULL,
  createdAt INTEGER NOT NULL,
  expiresAt INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS web_security_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts INTEGER NOT NULL,
  ip TEXT NOT NULL,
  kind TEXT NOT NULL,
  path TEXT,
  detail TEXT
);
CREATE TABLE IF NOT EXISTS minigame_progress (
  userId TEXT PRIMARY KEY,
  wave INTEGER NOT NULL DEFAULT 1,
  bestWave INTEGER NOT NULL DEFAULT 0,
  coins INTEGER NOT NULL DEFAULT 0,
  turrets TEXT NOT NULL DEFAULT '{}',
  stats TEXT NOT NULL DEFAULT '{}',
  totalKills INTEGER NOT NULL DEFAULT 0,
  lastClaimWave INTEGER NOT NULL DEFAULT 0,
  lastClaimAt INTEGER NOT NULL DEFAULT 0,
  lastSeenAt INTEGER NOT NULL DEFAULT 0,
  updatedAt INTEGER NOT NULL
);
`);

// ================== MIGRASI SATU KALI DARI TABEL rpg_* LAMA ==================
// Idempoten: hanya jalan kalau web_users masih kosong DAN tabel lama ada.
(function migrateFromRpgTables() {
  try {
    const has = (t) => !!db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name = ?").get(t);
    const count = db.prepare('SELECT COUNT(*) AS n FROM web_users').get().n;
    if (count > 0) return;

    const srcChar = has('rpg_characters') ? 'rpg_characters' : null;
    if (srcChar) {
      const rows = db.prepare(`SELECT userId, xp, level, gameName, title, appearance FROM ${srcChar}`).all();
      const ins = db.prepare(`INSERT OR IGNORE INTO web_users (userId, xp, level, gameName, title, cardBg, cardBgUrl, createdAt, updatedAt)
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`);
      for (const r of rows) {
        let cardBg = null, cardBgUrl = null;
        try {
          const app = JSON.parse(r.appearance || '{}');
          cardBg = app.cardBg || null;
          cardBgUrl = app.cardBgUrl || null;
        } catch (_) {}
        ins.run(r.userId, Math.max(0, Math.floor(r.xp || 0)), Math.max(1, Math.floor(r.level || 1)),
          r.gameName || null, r.title || null, cardBg, cardBgUrl, now(), now());
      }
      console.log(`[webDb] Migrasi level: ${rows.length} karakter rpg -> web_users (progres level dipertahankan)`);
    }

    if (has('rpg_inventory')) {
      const info = db.prepare(`INSERT OR IGNORE INTO web_inventory (userId, itemId, qty)
                                SELECT userId, itemId, qty FROM rpg_inventory WHERE qty > 0`).run();
      console.log(`[webDb] Migrasi inventaris: ${info.changes} baris rpg_inventory -> web_inventory (item pasar aman)`);
    }

    if (has('dashboard_sessions')) {
      // Tabel session lama bisa langsung dipakai (skema identik) — tidak perlu pindah.
    }
  } catch (e) {
    console.error('[webDb] Migrasi rpg -> web dilewati:', e.message);
  }
})();

// ================== USER (level terunifikasi) ==================
const COLS = 'userId, xp, level, gameName, title, cardBg, cardBgUrl, createdAt, updatedAt';
function getUser(userId) {
  return db.prepare(`SELECT ${COLS} FROM web_users WHERE userId = ?`).get(userId) || null;
}
function ensureUser(userId) {
  const t = now();
  db.prepare(`INSERT OR IGNORE INTO web_users (userId, xp, level, createdAt, updatedAt) VALUES (?, 0, 1, ?, ?)`)
    .run(userId, t, t);
  return getUser(userId);
}
function updateUser(userId, patch = {}) {
  const allowed = {};
  if (patch.xp != null) allowed.xp = Math.max(0, Math.floor(Number(patch.xp) || 0));
  if (patch.level != null) allowed.level = Math.max(1, Math.floor(Number(patch.level) || 1));
  if (patch.gameName != null) allowed.gameName = String(patch.gameName).slice(0, 40);
  if (patch.title != null) allowed.title = String(patch.title).slice(0, 60);
  if (patch.cardBg != null) allowed.cardBg = String(patch.cardBg).slice(0, 40);
  if (patch.cardBgUrl != null) allowed.cardBgUrl = String(patch.cardBgUrl).slice(0, 300);
  const keys = Object.keys(allowed);
  if (!keys.length) return getUser(userId);
  ensureUser(userId);
  db.prepare(`UPDATE web_users SET ${keys.map(k => `${k} = ?`).join(', ')}, updatedAt = ? WHERE userId = ?`)
    .run(...keys.map(k => allowed[k]), now(), userId);
  return getUser(userId);
}
function getTopByLevel(limit = 10) {
  return db.prepare('SELECT userId, level, xp, gameName FROM web_users ORDER BY level DESC, xp DESC LIMIT ?').all(limit);
}
function touchUser(userId) {
  db.prepare('UPDATE web_users SET updatedAt = ? WHERE userId = ?').run(now(), userId);
}

// ================== INVENTARIS (pasar / lelang web) ==================
function getInventory(userId) {
  return db.prepare('SELECT * FROM web_inventory WHERE userId = ? AND qty > 0 ORDER BY itemId').all(userId);
}
function getItemQty(userId, itemId) {
  return db.prepare('SELECT qty FROM web_inventory WHERE userId = ? AND itemId = ?').get(userId, itemId)?.qty || 0;
}
function addItem(userId, itemId, qty = 1) {
  db.prepare(`
    INSERT INTO web_inventory (userId, itemId, qty) VALUES (?, ?, ?)
    ON CONFLICT(userId, itemId) DO UPDATE SET qty = qty + excluded.qty
  `).run(userId, itemId, Math.max(0, Math.floor(qty)));
}
// Return false (tanpa mengubah apa pun) kalau qty di tangan kurang — dicek DULU
// sebelum UPDATE supaya qty tidak pernah negatif.
function removeItem(userId, itemId, qty = 1) {
  const have = getItemQty(userId, itemId);
  if (have < qty) return false;
  db.prepare('UPDATE web_inventory SET qty = qty - ? WHERE userId = ? AND itemId = ?').run(qty, userId, itemId);
  return true;
}

// ================== SESI DASHBOARD (persist, tahan restart) ==================
function saveSession(sid, payload, maxAgeMs = 30 * 24 * 3600 * 1000) {
  const t = now();
  db.prepare(`INSERT INTO dashboard_sessions (sid, payload, createdAt, expiresAt) VALUES (?, ?, ?, ?)
              ON CONFLICT(sid) DO UPDATE SET payload = excluded.payload, expiresAt = excluded.expiresAt`)
    .run(sid, JSON.stringify(payload), t, t + maxAgeMs);
}
function getSession(sid) {
  const row = db.prepare('SELECT * FROM dashboard_sessions WHERE sid = ? AND expiresAt > ?').get(sid, now());
  if (!row) return null;
  try { return JSON.parse(row.payload); } catch (_) { return null; }
}
function deleteSession(sid) {
  db.prepare('DELETE FROM dashboard_sessions WHERE sid = ?').run(sid);
}
function cleanExpiredSessions() {
  db.prepare('DELETE FROM dashboard_sessions WHERE expiresAt <= ?').run(now());
}

// ================== KEAMANAN: audit log ==================
function logSecurity(ip, kind, path, detail) {
  try {
    db.prepare('INSERT INTO web_security_log (ts, ip, kind, path, detail) VALUES (?, ?, ?, ?, ?)')
      .run(now(), String(ip || '').slice(0, 64), String(kind || '').slice(0, 32), String(path || '').slice(0, 180), String(detail || '').slice(0, 240));
  } catch (_) {}
}
function getSecurityStats() {
  const since = now() - 24 * 3600 * 1000;
  const byKind = db.prepare('SELECT kind, COUNT(*) AS n, COUNT(DISTINCT ip) AS ips FROM web_security_log WHERE ts >= ? GROUP BY kind ORDER BY n DESC').all(since);
  const recent = db.prepare('SELECT ts, ip, kind, path, detail FROM web_security_log WHERE ts >= ? ORDER BY id DESC LIMIT 60').all(since);
  return { since, byKind, recent };
}
// Pangkas log lama (maks 5.000 baris) — dipanggil janitor security.
// Sengaja TIDAK pakai setInterval di sini (interval saat process.exit memicu
// crash native better-sqlite3 di Node 24).
function trimSecurityLog() {
  try { db.prepare('DELETE FROM web_security_log WHERE id <= (SELECT COALESCE(MAX(id),0) - 5000 FROM web_security_log)').run(); } catch (_) {}
}

// ================== MINIGAME: KIZDEFENSE ==================
function getProgress(userId) {
  return db.prepare('SELECT * FROM minigame_progress WHERE userId = ?').get(userId) || null;
}
function ensureProgress(userId) {
  db.prepare('INSERT OR IGNORE INTO minigame_progress (userId, lastSeenAt, updatedAt) VALUES (?, ?, ?)').run(userId, now(), now());
  return getProgress(userId);
}
function saveProgress(userId, patch = {}) {
  ensureProgress(userId);
  const cur = getProgress(userId);
  const set = [];
  const args = [];
  const put = (col, val) => { set.push(`${col} = ?`); args.push(val); };
  if (patch.wave != null) put('wave', Math.max(1, Math.min(100000, Math.floor(Number(patch.wave) || 1))));
  // bestWave & totalKills MONOTONIC di lapisan DB (anti rollback-replay klaim):
  // tidak pernah boleh turun, apa pun yang dikirim klien.
  if (patch.bestWave != null) put('bestWave', Math.max(cur.bestWave || 0, Math.min(100000, Math.floor(Number(patch.bestWave) || 0))));
  if (patch.coins != null) put('coins', Math.max(0, Math.min(1e9, Math.floor(Number(patch.coins) || 0))));
  if (patch.turrets != null) put('turrets', JSON.stringify(patch.turrets).slice(0, 20000));
  if (patch.stats != null) put('stats', JSON.stringify(patch.stats).slice(0, 20000));
  if (patch.totalKills != null) put('totalKills', Math.max(cur.totalKills || 0, Math.min(1e9, Math.floor(Number(patch.totalKills) || 0))));
  if (patch.lastClaimWave != null) put('lastClaimWave', Math.max(0, Math.min(100000, Math.floor(Number(patch.lastClaimWave) || 0))));
  if (!set.length) return getProgress(userId);
  put('updatedAt', now());
  db.prepare(`UPDATE minigame_progress SET ${set.join(', ')} WHERE userId = ?`).run(...args, userId);
  return getProgress(userId);
}
function touchProgress(userId) {
  db.prepare('UPDATE minigame_progress SET lastSeenAt = ?, updatedAt = ? WHERE userId = ?').run(now(), now(), userId);
}
function recordClaim(userId, { wave, amount }) {
  db.prepare('UPDATE minigame_progress SET lastClaimWave = ?, lastClaimAt = ?, updatedAt = ? WHERE userId = ?')
    .run(Math.floor(wave), now(), now(), userId);
}
function getMinigameLeaderboard(limit = 20) {
  return db.prepare('SELECT userId, bestWave, totalKills FROM minigame_progress WHERE bestWave > 0 ORDER BY bestWave DESC, totalKills DESC LIMIT ?').all(limit);
}

module.exports = {
  getUser, ensureUser, updateUser, getTopByLevel, touchUser,
  getInventory, getItemQty, addItem, removeItem,
  saveSession, getSession, deleteSession, cleanExpiredSessions,
  logSecurity, getSecurityStats, trimSecurityLog,
  getProgress, ensureProgress, saveProgress, touchProgress, recordClaim, getMinigameLeaderboard,
  close: () => {},
};
