const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const B = require('../../utils/economyButtons');
const engine = require('../../utils/economyEngine');
const kizco = require('../../utils/kizco');
const { getGuildConfig, updateGuildConfig, db } = require('../../database/db');
const { isOwner } = require('../../utils/ownerCheck');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');
const marketEngine = require('../../utils/marketEngine');
const { instrumentById } = require('../../utils/instruments');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('economy')
    .setDescription('Panel & analisis ekonomi Kizco (inflasi, grafik, bank sentral, notifikasi)')
    .addSubcommand(sub => sub.setName('status').setDescription('Snapshot makroekonomi (dengan tombol navigasi)'))
    .addSubcommand(sub => sub.setName('chart').setDescription('Grafik tren indeks harga & uang beredar'))
    .addSubcommand(sub => sub.setName('report').setDescription('Laporan terbaru AI Ekonom'))
    .addSubcommand(sub => sub.setName('history').setDescription('Riwayat transaksi ekonomi terbaru'))
    .addSubcommand(sub => sub.setName('channel').setDescription('Lihat konfigurasi channel notifikasi ekonomi'))
    .addSubcommand(sub => sub.setName('setchannel').setDescription('[Admin] Set channel tujuan notifikasi ekonomi')
      .addChannelOption(o => o.setName('channel').setDescription('Channel tujuan notifikasi').setRequired(true).addChannelTypes(ChannelType.GuildText)))
    .addSubcommand(sub => sub.setName('notify').setDescription('[Admin] Aktifkan/nonaktifkan notifikasi ekonomi')
      .addStringOption(o => o.setName('mode').setDescription('on / off').setRequired(true).addChoices({ name: 'Aktif (on)', value: 'on' }, { name: 'Nonaktif (off)', value: 'off' })))
    .addSubcommand(sub => sub.setName('traders').setDescription('Papan peringkat trader teraktif (volume)'))
    .addSubcommand(sub => sub.setName('signal').setDescription('Analisis teknikal pasar KZC (trend/momentum/struktur) — bukan saran beli/jual')
      .addStringOption(o => o.setName('instrumen').setDescription('Instrumen (default KZC/USD)')
        .addChoices(
          { name: 'KZC/USD', value: 'kzc_usd' }, { name: 'KZC/XAU', value: 'kzc_xau' },
          { name: 'KZC/CRYPTO', value: 'kzc_cry' }, { name: 'Indeks Kizco', value: 'kzc_idx' },
          { name: 'Bank Kizaria (BKZ)', value: 'bank_kizaria' },
        )))
    .addSubcommandGroup(g => g.setName('bank').setDescription('[Owner] Bank Sentral Kizaria (BSK) — cetak/bakar uang & set kebijakan')
      .addSubcommand(s => s.setName('print').setDescription('Cetak uang (QE) ke semua pemegang')
        .addIntegerOption(o => o.setName('jumlah').setDescription('Jumlah KZC').setRequired(true).setMinValue(1)))
      .addSubcommand(s => s.setName('burn').setDescription('Bakar uang (QT) secara proporsional')
        .addIntegerOption(o => o.setName('jumlah').setDescription('Jumlah KZC').setRequired(true).setMinValue(1)))
      .addSubcommand(s => s.setName('rate').setDescription('Set tuas kebijakan moneter')
        .addStringOption(o => o.setName('jenis').setDescription('Tuas yang diubah').setRequired(true)
          .addChoices({ name: 'Pengali Reward (0.1-3)', value: 'reward' }, { name: 'Pajak (0-0.9)', value: 'tax' }, { name: 'Bunga Bank (0-0.2)', value: 'interest' }))
        .addNumberOption(o => o.setName('nilai').setDescription('Nilai (desimal)').setRequired(true)))),

  async execute(interaction) {
    const lang = guildLang(interaction);
    const group = interaction.options.getSubcommandGroup(false);
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    if (group === 'bank') {
      if (!isOwner(interaction.user.id)) {
        return interaction.reply({ embeds: [errorEmbed(t(lang, 'economy.owner_only'))], ephemeral: true });
      }
      if (sub === 'print') {
        const r = engine.printMoney(guildId, interaction.options.getInteger('jumlah'));
        return interaction.reply({ embeds: [successEmbed(t(lang, 'economy.print_ok', { amount: kizco.format(r.distributed) }))] });
      }
      if (sub === 'burn') {
        const r = engine.burnMoney(guildId, interaction.options.getInteger('jumlah'));
        return interaction.reply({ embeds: [successEmbed(t(lang, 'economy.burn_ok', { amount: kizco.format(r.burned) }))] });
      }
      if (sub === 'rate') {
        const jenis = interaction.options.getString('jenis');
        const nilai = interaction.options.getNumber('nilai');
        const patch = { reward: { rewardMultiplier: nilai }, tax: { taxRate: nilai }, interest: { bankInterestRate: nilai } }[jenis];
        const r = engine.setRates(guildId, patch);
        return interaction.reply({ embeds: [successEmbed(t(lang, 'economy.rate_ok', { reward: r.rewardMultiplier, tax: (r.taxRate * 100).toFixed(1), interest: (r.bankInterestRate * 100).toFixed(2) }))] });
      }
    }

    if (sub === 'status') return interaction.reply(B.renderStatus(guildId));
    if (sub === 'chart') return interaction.reply(B.renderChart(guildId));
    if (sub === 'report') return interaction.reply(B.renderReport(guildId));
    if (sub === 'history') return interaction.reply(B.renderHistory(guildId));
    if (sub === 'channel') return interaction.reply(B.renderChannelConfig(guildId));

    if (sub === 'setchannel') {
      if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
        return interaction.reply({ embeds: [errorEmbed(t(lang, 'economy.perm'))], ephemeral: true });
      }
      const channel = interaction.options.getChannel('channel');
      updateGuildConfig(guildId, { econChannelId: channel.id, econNotifyEnabled: 1 });
      return interaction.reply({ embeds: [successEmbed(t(lang, 'economy.setchannel_ok', { channel: channel.id }))] });
    }

    if (sub === 'notify') {
      if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
        return interaction.reply({ embeds: [errorEmbed(t(lang, 'economy.perm'))], ephemeral: true });
      }
      const mode = interaction.options.getString('mode') === 'on' ? 1 : 0;
      const cfg = getGuildConfig(guildId);
      if (mode && !cfg.econChannelId) {
        return interaction.reply({ embeds: [errorEmbed(t(lang, 'economy.notify_none'))], ephemeral: true });
      }
      updateGuildConfig(guildId, { econNotifyEnabled: mode });
      return interaction.reply({ embeds: [successEmbed(mode ? t(lang, 'economy.notify_on') : t(lang, 'economy.notify_off'))] });
    }

    if (sub === 'traders') {
      const traders = db.prepare(`SELECT userId, SUM(amount) AS volume FROM (
          SELECT buyerId AS userId, amount FROM econ_fills WHERE guildId = ?
          UNION ALL SELECT sellerId AS userId, amount FROM econ_fills WHERE guildId = ?
        ) GROUP BY userId ORDER BY volume DESC LIMIT 10`).all(guildId, guildId);
      if (!traders.length) {
        return interaction.reply({ embeds: [errorEmbed(t(lang, 'economy.traders_empty'))], ephemeral: true });
      }
      const lines = traders.map((t, i) => {
        const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i + 1}`;
        return `${medal} <@${t.userId}> — volume **${kizco.format(t.volume)}**`;
      }).join('\n');
      const { baseEmbed } = require('../../utils/embeds');
      return interaction.reply({ embeds: [baseEmbed().setTitle(t(lang, 'economy.traders_title')).setDescription(lines).setFooter({ text: t(lang, 'economy.traders_footer') })] });
    }

    if (sub === 'signal') {
      const { baseEmbed } = require('../../utils/embeds');
      const symbol = interaction.options.getString('instrumen') || 'kzc_usd';
      const inst = instrumentById(symbol);
      const a = marketEngine.getAnalysis(guildId, symbol, '1h', 300);
      const price = marketEngine.getPrice(guildId, symbol);
      if (!a.ready) {
        return interaction.reply({ embeds: [errorEmbed(t(lang, 'economy.signal_no_data'))], ephemeral: true });
      }
      const TREND = { bullish: 'BULLISH 🟢', bearish: 'BEARISH 🔴', sideways: 'SIDEWAYS ⚪' }[a.trend] || a.trend.toUpperCase();
      const MOMENTUM = { positive: 'POSITIVE 🟢', negative: 'NEGATIVE 🔴', neutral: 'NEUTRAL ⚪' }[a.momentum] || a.momentum.toUpperCase();
      const VOL = { above_average: 'ABOVE AVERAGE', below_average: 'BELOW AVERAGE', average: 'AVERAGE' }[a.volumeBias] || '—';
      const STRUCT = {
        higher_high_higher_low: 'HIGHER HIGH / HIGHER LOW', lower_high_lower_low: 'LOWER HIGH / LOWER LOW',
        break_of_structure_up: 'BREAK OF STRUCTURE (UP)', break_of_structure_down: 'BREAK OF STRUCTURE (DOWN)', ranging: 'RANGING',
      }[a.structure] || a.structure;
      const i = a.indicators || {};
      const bias = a.trend === 'bullish' && a.momentum !== 'negative' ? 'BULLISH' : a.trend === 'bearish' && a.momentum !== 'positive' ? 'BEARISH' : 'NEUTRAL';
      const embed = baseEmbed()
        .setTitle(`📊 ${inst.ticker} — KZC Market Analysis`)
        .setDescription(`Harga: **${price.toLocaleString('id-ID')}**`)
        .addFields(
          { name: 'Trend', value: TREND, inline: true },
          { name: 'Momentum', value: MOMENTUM, inline: true },
          { name: 'Volume', value: VOL, inline: true },
          { name: 'Market Structure', value: STRUCT, inline: true },
          { name: 'Technical Bias', value: bias, inline: true },
          { name: 'Indikator', value: `RSI 14: **${i.rsi != null ? Number(i.rsi).toFixed(1) : '—'}**\nEMA 9/20/50: **${i.ema9 ? Math.round(i.ema9) : '—'} / ${i.ema20 ? Math.round(i.ema20) : '—'} / ${i.ema50 ? Math.round(i.ema50) : '—'}**\nATR: **${i.atr ? Math.round(i.atr) : '—'}** • Rel. Vol: **${i.relativeVolume ?? '—'}x**`, inline: false },
        )
        .setFooter({ text: t(lang, 'economy.signal_disclaimer') });
      return interaction.reply({ embeds: [embed] });
    }
  },
};
