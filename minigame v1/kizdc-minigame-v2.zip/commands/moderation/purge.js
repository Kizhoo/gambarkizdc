const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { safeDefer } = require('../../utils/interactionHelpers');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('purge')
    .setDescription('Hapus banyak pesan sekaligus')
    .addIntegerOption(o => o.setName('jumlah').setDescription('Jumlah pesan (1-100)').setRequired(true).setMinValue(1).setMaxValue(100))
    .addUserOption(o => o.setName('dari_user').setDescription('Hanya hapus pesan dari user ini'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const amount = interaction.options.getInteger('jumlah');
    const fromUser = interaction.options.getUser('dari_user');

    if (!(await safeDefer(interaction, { ephemeral: true }))) return;

    try {
      const messages = await interaction.channel.messages.fetch({ limit: 100 });
      let toDelete = fromUser
        ? messages.filter(m => m.author.id === fromUser.id).first(amount)
        : messages.first(amount);

      if (!toDelete || toDelete.length === 0) {
        return interaction.editReply({ embeds: [errorEmbed(t(lang, 'mod.purge_none'))] });
      }

      const deleted = await interaction.channel.bulkDelete(toDelete, true);
      return interaction.editReply({ embeds: [successEmbed(t(lang, 'mod.purge_ok', { n: deleted.size }))] });
    } catch (err) {
      console.error('[purge] Gagal menghapus pesan:', err.message);
      const friendly = err.message?.includes('14 days')
        ? t(lang, 'mod.purge_old')
        : t(lang, 'mod.purge_fail');
      return interaction.editReply({ embeds: [errorEmbed(friendly)] }).catch(() => {});
    }
  },
};
