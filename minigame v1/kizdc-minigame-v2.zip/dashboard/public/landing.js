// ============================================================================
// KIZHOOBOT LANDING PAGE — ambil statistik publik & isi UI + pengalih bahasa.
// ============================================================================
function $(id) { return document.getElementById(id); }
function fmt(n) { return (Number(n) || 0).toLocaleString('id-ID'); }
function fmtUptime(sec) {
  const d = Math.floor(sec / 86400), h = Math.floor((sec % 86400) / 3600), m = Math.floor((sec % 3600) / 60);
  if (d > 0) return `${d} hari ${h} jam`;
  if (h > 0) return `${h} jam ${m} menit`;
  return `${m} menit`;
}

let _stats = null;

// ===== SOSMED — cuma dirender kalau backend kirim link (owner sudah isi di config.json) =====
const SOCIAL_ICONS = {
  discord: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="6" width="18" height="12" rx="5"/><circle cx="9" cy="12" r="1.2" fill="currentColor" stroke="none"/><circle cx="15" cy="12" r="1.2" fill="currentColor" stroke="none"/></svg>',
  instagram: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4.2"/><circle cx="17.2" cy="6.8" r="1.1" fill="currentColor" stroke="none"/></svg>',
  x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M4 4l16 16M20 4L4 20"/></svg>',
  youtube: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="2.5" y="5.5" width="19" height="13" rx="4"/><path d="M10.3 9.1v5.8l5.2-2.9-5.2-2.9z" fill="currentColor" stroke="none"/></svg>',
  tiktok: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M14 3v10.6a3.3 3.3 0 1 1-3.3-3.3c.3 0 .56.03.83.09"/><path d="M14 3c.4 2.5 2.3 4.3 4.7 4.6"/></svg>',
  website: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.6 3.8 5.7 3.8 9s-1.3 6.4-3.8 9c-2.5-2.6-3.8-5.7-3.8-9s1.3-6.4 3.8-9z"/></svg>',
  github: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M9 19c-4 1.2-4-2-5.5-2.5M16 21v-2.9c0-.9.3-1.5.7-1.9-2.4-.3-4.9-1.2-4.9-5.4 0-1.2.4-2.1 1.1-2.9-.1-.3-.5-1.5.1-3.1 0 0 .9-.3 3 1.1a10.4 10.4 0 0 1 5.4 0c2.1-1.4 3-1.1 3-1.1.6 1.6.2 2.8.1 3.1.7.8 1.1 1.7 1.1 2.9 0 4.2-2.5 5.1-4.9 5.4.4.4.8 1.1.8 2.2V21"/></svg>',
};
const SOCIAL_LABEL = { discord: 'Discord', instagram: 'Instagram', x: 'X (Twitter)', youtube: 'YouTube', tiktok: 'TikTok', website: 'Website', github: 'GitHub' };
const SOCIAL_COLOR = { discord: '#5865f2', instagram: '#e1306c', x: '#e6e9ef', youtube: '#ff4d4d', tiktok: '#25f4ee', website: '#4f8cff', github: '#a7b0c2' };
const SOCIAL_ORDER = ['discord', 'instagram', 'x', 'youtube', 'tiktok', 'website', 'github'];

function renderSocial(social) {
  const section = $('sosmed');
  const grid = $('socialGrid');
  const navLink = $('navSosmedLink');
  if (!section || !grid) return;
  const keys = SOCIAL_ORDER.filter((k) => social && social[k]);
  if (!keys.length) {
    section.classList.add('hidden');
    if (navLink) navLink.classList.add('hidden');
    return;
  }
  grid.innerHTML = keys.map((k) => {
    const url = String(social[k]).replace(/"/g, '&quot;');
    return `<a class="social-link" href="${url}" target="_blank" rel="noopener noreferrer" style="--sc:${SOCIAL_COLOR[k]}">` +
      `<span class="social-icon">${SOCIAL_ICONS[k]}</span><span>${SOCIAL_LABEL[k]}</span></a>`;
  }).join('');
  section.classList.remove('hidden');
  if (navLink) navLink.classList.remove('hidden');
}

// Tombol/link "Vote" (nav + footer) cuma muncul kalau backend punya voteLinks
// (Discord application ID sudah diset lewat DISCORD_CLIENT_ID di .env).
function renderVoteLinks(voteLinks) {
  const nav = $('navVoteLink');
  const footer = $('footerVoteLink');
  if (!voteLinks) return;
  if (nav) nav.classList.remove('hidden');
  if (footer) footer.classList.remove('hidden');
}

// Badge "Aktif di X server" — angka dinamis, jadi dirender manual lewat i18n.
function renderBadge() {
  const el = $('heroBadge');
  if (!el || !window.WebI18n) return;
  const n = _stats ? fmt(_stats.guilds) : '...';
  el.textContent = window.WebI18n.t(window.WebI18n.currentLang(), 'hero.badge', { n });
}

async function loadStats() {
  try {
    const res = await fetch('/api/public/stats');
    if (!res.ok) return;
    const s = await res.json();
    _stats = s;

    $('stGuilds').textContent = fmt(s.guilds);
    $('stMembers').textContent = fmt(s.totalMembers || s.users);
    $('stCommands').textContent = fmt(s.commands);
    $('stUptime').textContent = fmtUptime(s.uptimeSeconds);
    renderBadge();

    if (s.avatar) {
      $('heroAvatar').src = s.avatar;
      $('heroAvatar').style.display = 'block';
      const nav = $('navAvatar'); if (nav) { nav.textContent = ''; nav.style.backgroundImage = `url(${s.avatar})`; nav.style.backgroundSize = 'cover'; nav.style.backgroundPosition = 'center'; }
      const f = $('footerAvatar'); if (f) { f.textContent = ''; f.style.backgroundImage = `url(${s.avatar})`; f.style.backgroundSize = 'cover'; f.style.backgroundPosition = 'center'; }
    } else {
      $('heroAvatar').style.display = 'none';
    }

    const invite = $('btnInvite');
    if (s.inviteUrl) { invite.href = s.inviteUrl; invite.target = '_blank'; invite.rel = 'noopener'; }
    else { invite.style.display = 'none'; }

    if (s.botName && s.botName !== 'KizhooBot') {
      document.querySelectorAll('.brand-name').forEach(el => { el.textContent = s.botName; });
    }

    renderSocial(s.social);
    renderVoteLinks(s.voteLinks);
  } catch (e) {
    // Landing page tetap tampil walau API gagal. Angka dibiarkan '—'.
  }
}

// ===== Pengalih bahasa (cookie kz_lang) =====
function initI18n() {
  if (!window.WebI18n) return;
  window.WebI18n.apply();
  renderBadge();
  const sel = $('langSelect');
  if (sel) {
    sel.addEventListener('change', () => {
      window.WebI18n.setLang(sel.value);
      window.WebI18n.apply();
      renderBadge();
    });
  }
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initI18n);
else initI18n();

loadStats();

// Scroll reveal — animasi masuk saat di-scroll.
(function initReveal() {
  const targets = document.querySelectorAll('.feature, .stat, .section-head, .cmd, .faq details, .why p');
  targets.forEach(el => el.classList.add('reveal'));
  if (!('IntersectionObserver' in window)) { targets.forEach(el => el.classList.add('visible')); return; }
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add('visible'); io.unobserve(e.target); }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
  targets.forEach(el => io.observe(el));
})();
