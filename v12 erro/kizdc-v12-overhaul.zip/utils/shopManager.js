// ============================================================================
// AI MANAJER TOKO + KATALOG ITEM DINAMIS (bukan cuma barang tetap)
// ----------------------------------------------------------------------------
// Sumber kebenaran katalog sekarang tabel `econ_items` (database/economyDb.js).
// Katalog di-SEED sekali dari rpgItems (senjata/zirah/aksesoris/ramuan), lalu
// AI Manajer bisa MENAMBAH item BARU sesuai permintaan (bukan asal-asalan),
// menaikkan/menurunkan harga, dan "memensiunkan" barang yang tidak laku.
//
// Fungsi getItem/allItems/allCategories dipakai bareng oleh /market, tombol
// interaktif, sistem trading, dan (setelah RPG shop dihapus) RPG inventory.
// ============================================================================
const econ = require('../database/economyDb');
const engine = require('./economyEngine');
const rpgItems = require('./rpgItems');
const { generateText } = require('./aiProvider');
const kizco = require('./kizco');
const { seedGeneratedItems, purgeGeneratedItems } = require('./itemGenerator');

// Kategori standar (termasuk barang non-RPG hasil generator).
const CATEGORIES = {
  weapon: { label: 'Senjata', emoji: '🗡️' },
  armor: { label: 'Zirah', emoji: '🛡️' },
  accessory: { label: 'Aksesoris', emoji: '💍' },
  potion: { label: 'Ramuan', emoji: '🧪' },
  consumable: { label: 'Kebutuhan', emoji: '📦' },
  material: { label: 'Bahan', emoji: '🪨' },
  artifact: { label: 'Artefak', emoji: '🔮' },
  collectible: { label: 'Koleksi', emoji: '🪙' },
  cosmetic: { label: 'Kosmetik', emoji: '🎩' },
  food: { label: 'Makanan', emoji: '🍖' },
};

// Barang kebutuhan situasional (TIDAK DIJUAL LAGI — hanya fallback lookup untuk
// pemain yang masih menyimpannya. Market resmi = 90 item katalog rpgItems).
const NECESSITIES = {
  hunt_ration: { id: 'hunt_ration', name: 'Ransum Berburu', category: 'consumable', type: 'consumable', basePrice: 35, effect: { heal: 80 }, desc: 'Bekal buat petualang yang sering berburu. Memulihkan 80 HP.', emoji: '🍖' },
  training_ticket: { id: 'training_ticket', name: 'Tiket Latihan', category: 'consumable', type: 'consumable', basePrice: 60, effect: { xpBoost: 1 }, desc: 'Memberi +XP tambahan saat quest/hunt berikutnya (1x pakai).', emoji: '🎫' },
  merchant_contract: { id: 'merchant_contract', name: 'Kontrak Dagang', category: 'consumable', type: 'consumable', basePrice: 90, effect: { sellBonus: 1 }, desc: 'Menaikkan harga jual barang kamu 15% untuk 1 transaksi.', emoji: '📜' },
  guardian_charm: { id: 'guardian_charm', name: 'Jimat Pelindung', category: 'consumable', type: 'consumable', basePrice: 120, effect: { defBoost: 1 }, desc: 'Bonus DEF sementara +5 untuk pertarungan berikutnya.', emoji: '🧿' },
};

// Seed katalog: SELALU singkronkan katalog resmi 90 item (idempotent — upsert).
// FIX: dulu hanya seed saat econ_items kosong, padahal DB lama sudah berisi 600+
// item generator → katalog baru tidak pernah masuk & market tetap penuh sampah.
function ensureSeed() {
  for (const it of Object.values(rpgItems.ITEMS)) {
    // equip: simpan stats + efek khusus agar market bisa menampilkan keduanya.
    const effect = (it.type === 'equip')
      ? { ...(it.stats || {}), special: it.effect || null }
      : (it.effect || it.stats || {});
    econ.upsertItem({ ...it, basePrice: it.basePrice || it.price || 10, effect, aiGenerated: 0 });
  }
  // Bersihkan item non-katalog (generator lama + sisa AI) → nonaktif dari market.
  try { purgeGeneratedItems(); } catch (e) { console.warn('[shopManager] Gagal purge item lama:', e.message); }
}
ensureSeed();

function getItem(id) {
  const it = econ.getItem(id);
  if (it) return it;
  return rpgItems.getItem(id) || NECESSITIES[id] || null; // fallback aman
}
function allItems() {
  return econ.listItems({ activeOnly: true });
}
function listByCategory(category) {
  return allItems().filter(i => i.category === category);
}
function allCategories() {
  return Object.entries(CATEGORIES).map(([key, v]) => ({ key, ...v }));
}

// ---------------- Analisis sinyal permintaan ----------------
function analyzeDemand(guildId) {
  const txs = econ.getTransactions(guildId, 250);
  const signals = { hunt: 0, quest: 0, pvp: 0, leveling: 0, trade: 0, purchase: 0, total: 0 };
  for (const t of txs) {
    signals.total++;
    if (t.type === 'hunt') signals.hunt++;
    else if (t.type === 'quest') signals.quest++;
    else if (t.type === 'purchase') signals.purchase++;
    else if (t.type === 'trade' || t.type === 'sell') signals.trade++;
    else if (t.type === 'levelup' || t.type === 'work' || t.type === 'daily') signals.leveling++;
  }
  signals.pvp = Math.max(signals.pvp, signals.purchase);
  return signals;
}

// ---------------- Harga dinamis ----------------
function priceOf(guildId, item, demandScore) {
  return engine.shopPrice(guildId, item.basePrice, demandScore);
}

// Daftar barang pasar lengkap dengan harga dinamis + tren.
function listMarket(guildId) {
  const st = engine.summary(guildId);
  const metas = {};
  for (const m of econ.getAllShopMeta(guildId)) metas[m.itemId] = m;

  const items = allItems().map(i => {
    const meta = metas[i.id] || {};
    const demand = meta.demandScore || 0;
    const price = priceOf(guildId, i, demand);
    let trend = 'stabil';
    if (demand >= 5) trend = '🔥 tinggi';
    else if (demand >= 2) trend = '📈 naik';
    else if (demand <= -2) trend = '📉 turun';
    return { id: i.id, name: i.name, category: i.category, type: i.type, price, basePrice: i.basePrice, demand, trend, desc: i.desc, emoji: i.emoji, tier: i.tier, class: i.class, effect: i.effect };
  });

  const signals = analyzeDemand(guildId);
  return { items, state: st, signals, totalListed: items.length };
}

function buyPrice(guildId, itemId) {
  const item = getItem(itemId);
  if (!item) return null;
  const meta = econ.getShopMeta(guildId, itemId);
  return priceOf(guildId, item, meta?.demandScore || 0);
}

// ---------------- GENERATE ITEM (FITUR DIHAPUS) ----------------
// Sebelumnya AI Manajer Toko bisa MENAMBAH item baru sesuai permintaan lewat
// provider AI. Sesuai permintaan, fitur ini DIHAPUS: katalog sekarang statis
// (seed dari rpgItems + generator deterministik yang sudah dirampingkan).
// Fungsi dibiarkan ada (return []) supaya pemanggil lama tidak error.
async function generateItems() {
  return [];
}

// ---------------- Siklus manajer toko ----------------
function runShopManager(guildId) {
  // Sync stok & decay permintaan.
  for (const item of allItems()) {
    const meta = econ.getShopMeta(guildId, item.id);
    if (!meta) {
      econ.setShopMeta(guildId, item.id, { basePrice: item.basePrice, demandScore: 0, stock: 0, category: item.category, aiManaged: 1 });
    } else {
      const decayed = meta.demandScore * 0.9;
      econ.setShopMeta(guildId, item.id, { demandScore: Number(decayed.toFixed(2)) });
    }
  }
  const signals = analyzeDemand(guildId);
  return { signals, report: buildMarketReport(guildId, [], signals) };
}

async function runShopManagerWithAi(guildId) {
  runShopManager(guildId);
  const created = []; // AI generate item sudah dihapus permanen
  const changes = created.map(n => `➕ Stok baru: **${n}**`);
  const signals = analyzeDemand(guildId);
  const report = buildMarketReport(guildId, changes, signals);
  return { changes, signals, report, created };
}

function buildMarketReport(guildId, changes, signals) {
  const lines = [];
  if (changes.length) lines.push(...changes);
  else lines.push('Tidak ada perubahan stok — pasokan sudah sesuai permintaan.');
  lines.push(`Permintaan: berburu ${signals.hunt}, quest ${signals.quest}, leveling ${signals.leveling}, dagang ${signals.trade}.`);
  return lines.join('\n');
}

async function marketReportAi(guildId, changes, signals) {
  if (!process.env.CLOUDFLARE_ACCOUNT_ID || !process.env.CLOUDFLARE_API_TOKEN) return buildMarketReport(guildId, changes, signals);
  try {
    const st = engine.summary(guildId);
    const prompt = `Kamu manajer pasar game Kizco. Tulis laporan pasar 2-3 kalimat Bahasa Indonesia yang ringkas. Data: ${JSON.stringify({ priceIndex: st.priceIndex, inflationPct: st.inflationPct, signals, changes })}. Fokus: stok apa yang diubah dan kenapa.`;
    const text = await generateText([{ role: 'user', content: prompt }], {});
    return String(text || '').slice(0, 600) || buildMarketReport(guildId, changes, signals);
  } catch (_) {
    return buildMarketReport(guildId, changes, signals);
  }
}

module.exports = {
  CATEGORIES, NECESSITIES,
  getItem, allItems, listByCategory, allCategories,
  analyzeDemand, priceOf, listMarket, buyPrice,
  runShopManager, runShopManagerWithAi, generateItems,
  marketReportAi, buildMarketReport,
};
