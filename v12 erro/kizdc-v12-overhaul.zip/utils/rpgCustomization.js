// ============================================================================
// KATALOG KUSTOMISASI KARAKTER — /rpg customize
// ----------------------------------------------------------------------------
// Sumber kebenaran TUNGGAL buat pilihan yang valid (dipakai command buat bikin
// choices dropdown Discord DAN buat validasi server-side sebelum simpan ke DB).
// ============================================================================
const HAIR_STYLES = {
  bald: 'Botak', short: 'Pendek', mohawk: 'Mohawk', long: 'Panjang',
};

const EXPRESSIONS = {
  netral: 'Netral', senyum: 'Senyum', garang: 'Garang', tegas: 'Tegas/Fokus',
};

// Nama warna -> hex. Dipakai buat hairColor, outfitColor, pantsColor, shoesColor sekaligus
// (satu daftar warna buat semua slot, biar dropdown-nya konsisten & gampang diinget).
const COLORS = {
  hitam: '#0b0b12', coklat: '#472a19', pirang: '#c9992e', putih: '#f8fafc',
  merah: '#e23636', biru: '#3b82f6', hijau: '#3fbf5f', ungu: '#a855f7',
  kuning: '#f2c94c', cyan: '#4de1c1', abu: '#5b6472', oranye: '#e08a3c',
};

function isValidHair(v) { return Object.prototype.hasOwnProperty.call(HAIR_STYLES, v); }
function isValidExpression(v) { return Object.prototype.hasOwnProperty.call(EXPRESSIONS, v); }
function isValidColor(v) { return Object.prototype.hasOwnProperty.call(COLORS, v); }
function colorHex(name) { return COLORS[name] || null; }

module.exports = { HAIR_STYLES, EXPRESSIONS, COLORS, isValidHair, isValidExpression, isValidColor, colorHex };
