const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { safeDefer } = require('../../utils/interactionHelpers');
const { fetchExternal } = require('../../utils/httpClient');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder().setName('meme').setDescription('Ambil meme random dari Reddit'),
  async execute(interaction) {
    const lang = guildLang(interaction);
    if (!(await safeDefer(interaction))) return;

    try {
      const res = await fetchExternal('https://meme-api.com/gimme');
      if (!res.ok) throw new Error(`meme-api.com merespons status ${res.status}`);
      const data = await res.json();

      const embed = baseEmbed()
        .setTitle(data.title)
        .setImage(data.url)
        .setURL(data.postLink)
        .setFooter({ text: `${t(lang, 'fun.likes', { n: data.ups })} | r/${data.subreddit}` });

      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      console.error('[meme] Gagal ambil meme:', err.message);
      return interaction.editReply({ embeds: [errorEmbed(t(lang, 'fun.fetch_fail'))] }).catch(() => {});
    }
  },
};
