// QA server khusus REPRO BUG "karakter baru": user TANPA karakter sama sekali,
// persis kondisi yang memicu crash "Cannot read properties of null (reading
// 'slice')" di DungeonSelectScene.create (pilih class -> dungeons null).
process.env.KIZHOO_DB_PATH = '/tmp/kiz_fresh_qa.sqlite';
require('fs').rmSync('/tmp/kiz_fresh_qa.sqlite', { force: true });
const express = require('express');
const http = require('http');
const path = require('path');
const { mountRpg } = require('../utils/rpgServer');
const { attachRealtime } = require('../utils/rpgRealtime');
const rpgDb = require('../database/rpgDb');

const app = express();
app.use(express.json());
app.use((req, res, next) => { res.setHeader('Cache-Control', 'no-store'); next(); });
app.use(express.static(path.join(__dirname, '..', 'dashboard', 'public')));
const sessions = {};
const auth = (req, res, next) => {
  const sid = String(req.headers.cookie || '').replace(/.*kz_sid=([^;]*).*/, '$1');
  if (sessions[sid]) { req.session = sessions[sid]; return next(); }
  return res.status(401).json({ error: 'belum login' });
};
const client = { guilds: { cache: new Map() }, users: { cache: new Map(), fetch: async () => null } };
client.guilds.cache.set('g1', { id: 'g1' });
client.users.cache.set('777', { id: '777', username: 'PemainBaru' });
mountRpg(app, { auth, resolveUserId: (req) => (req.session && req.session.userId) || null, client });

const server = http.createServer(app);
attachRealtime(server, { client });
server.listen(8795, () => {
  // Sengaja TIDAK membuat karakter: sesi 'fresh' = user baru murni.
  sessions['fresh'] = { userId: '777', username: 'PemainBaru', avatar: null, guilds: [{ id: 'g1', name: 'QA' }] };
  rpgDb.saveSession('fresh', sessions['fresh']); // GET /rpg memvalidasi sesi dari DB.
  console.log('QA FRESH server di http://127.0.0.1:8795/rpg (cookie kz_sid=fresh, user 777 TANPA karakter)');
});
