# KREDIT ASET PIHAK KETIGA (KizDC v12)

## Catatan pengemasan v12
- `pets_atlas.png` / `pets_atlas.json`: SELURUH 30 sheet pet (di bawah) dikemas
  ulang menjadi SATU atlas tekstur (frame bernama `petid_frame`) — aset yang
  sama, lisensi yang sama, hanya repacking untuk 1 request HTTP + 1 tekstur
  GPU (mengurangi tekanan memori grafis perangkat low-end).
- `sw.js`, `manifest.webmanifest`, `assets/icons-pwa/*`: buatan sendiri (MIT);
  ikon PWA = frame `ember_0` dari atlas pet di atas (lisensi ikut sumbernya).

Semua aset di bawah adalah aset GRATIS dari OpenGameArt / GitHub yang diunduh,
dipotong, diskalakan, dan/atau direwarna untuk kebutuhan game KizDC.
Bentuk asli tersedia di sumber masing-masing. Terima kasih kepada semua senimannya.

## Hero (assets/hero/*.png)
- Basis: Universal LPC Spritesheet Character Generator — sanderfrenken dkk.
  https://github.com/sanderfrenken/Universal-LPC-Spritesheet-Character-Generator
  Lisensi: CC-BY-SA 3.0 / GPL 3.0 (sesuai komponen; lihat CREDITS.csv repo).
  Komposit via generator: body + celana + sepatu + armor plate/leather/kulit +
  rambut + topi penyihir/kerudung + senjata (arming sword, tongkat gnarled,
  belati, busur great) + quiver + jubah.

## Pet (assets/pets/*.png)
- Rubah, Anjing Shiba, Singa, Beruang, Rusa: "LPC animals 2022" (CC-BY 4.0)
  https://opengameart.org/content/lpc-bears-deer-lions-and-more — Matthew Kroehn dkk.
- Batu, Slime, Kelelawar, Golem, Golem Berlapis: "Enemy Galore I" (CC-BY 4.0)
  https://opengameart.org/content/enemy-galore-i — Justin Cyr (SketchyLab)
- Kucing: "Cat/Golden Cat" (CC-BY 4.0) https://opengameart.org/content/catgolden-cat
- Burung Hantu: "OWL" (CC-BY 3.0) https://opengameart.org/content/owl-0
- Katak: "Animated frog" (CC-BY-SA 3.0) https://opengameart.org/content/animated-frog
- Hell Hound (evolusi Bolt): "Hell Hound Character" (CC-BY 3.0)
  https://opengameart.org/content/hell-hound-character
- Kura-kura (evolusi Pebble): "Animated turtle" (CC0)
  https://opengameart.org/content/animated-turtle
- Naga (Nyx): "Dragon - Fully Animated" (CC0)
  https://opengameart.org/content/dragon-fully-animated
- Unicorn & Pegasus (Celeste): "LPC Horses rework" (CC-BY-SA 3.0)
  https://opengameart.org/content/lpc-horses-rework
- Phoenix (Solara): "Phoenix (reborn)" (CC0)
  https://opengameart.org/content/phoenix-reborn
- Rubah kecil alternatif: "Fox" (CC0) https://opengameart.org/content/fox-1
- Recolor (es/racun/bayang/listrik/cahaya) dilakukan via penggeseran hue +
  penerangan — turunan dari aset di atas dengan lisensi mengikuti sumbernya.

## VFX Skill (assets/fx/vfx_*.png)
- Ledakan api: "Fire spell explosion" (CC-BY 3.0)
  https://opengameart.org/content/fire-spell-explosion
- Es nova: "Ice nova" dari pak yang sama (CC-BY 3.0).
- Air: "Water magic effect" (CC-BY 3.0) https://opengameart.org/content/water-magic-effect
- Arcane: "Arcane magic effect" (CC-BY 3.0) https://opengameart.org/content/arcane-magic-effect
- Slash: "Weapon Slash Effect" (CC0) https://opengameart.org/content/weapon-slash-effect
- Lingkaran summon: "Teleporter circle" (CC-BY 3.0) https://opengameart.org/content/teleporter-circle
- Aura: "Auras" (CC0) https://opengameart.org/content/auras
- Magic pack (firelion/iceshield/lightningclaw/snake/tornado/spikes/tentakel):
  "Extended LPC Magic Pack" (CC-BY-SA 3.0) https://opengameart.org/content/extended-lpc-magic-pack
- Efek LPC umum: "LPC Items and game effects" (CC-BY 3.0)
  https://opengameart.org/content/lpc-items-and-game-effects

Catatan: game ini gratis. Aset CC-BY/CC-BY-SA tetap membawa atribusi di file ini;
modifikasi kami (potong/skala/rewarna) mengikuti lisensi asal masing-masing.

## Karakter Hero v13 (assets/hero/*.png) — 4 karakter BERBEDA per class
- WARRIOR "Dark Knight": "2D Character - The Dark Knight" oleh comphonia (CC0)
  https://opengameart.org/content/dark-knight-2d-character-sprites
  (Idle 51f / Walk 34f / Run 22f / Jump 30f / Slash 46f / Kick 37f / Impact 24f /
  Death 70f / Casting 90f — dipotong via rect meta Unity, sheet 13 kolom x 8 baris.)
- MAGE "Maya penyihir kecil": "Little Witch" (CC0)
  https://opengameart.org/content/little-witch
  (Run 16f + Jump/Idle 13f asli; baris cast 7 frame diarang dari pose lengan
  terangkat + orb glow teal digambar programatik mengikuti palet aslinya.)
- ARCHER "Pemanah hud": "2D animated Archer Spritesheet" oleh mh-studios (CC0)
  https://opengameart.org/content/2d-animated-archer-spritesheet
  (76 frame: idle 10 / run 22 / shoot 22 / jump 22 — dimirror ke arah kanan.)
- ASSASSIN "Prototipe lincah": Craftpix Free Asset "Prototype character"
  (lisensi bebas Craftpix https://craftpix.net/file-licenses/) — dari paket
  milik pemain (proto1/2/3, warna ASLI, bukan recolor): Walking/Running/Jump/
  Double Strike/Taking Damage/Casting Spell/Aerial Strike.

## Ledakan v13 (assets/fx/fx_expl_*.png)
- "Free pixel art explosion sprites" dari Craftpix (paket pemain, lisensi
  bebas https://craftpix.net/file-licenses/) — 11 varian: oranye, lingkaran,
  biru, oval, gas, gas-lingkaran, dua warna, nuklir, api, petir, asap.
  Dipakai untuk KO musuh, kill boss/champion, ultimate pet, meteor.

## Deco v13 (assets/deco/fairy.png, predator.png, flystone.png)
- "Free Platformer Game Tileset Pixel Art" dari Craftpix (paket pemain,
  lisensi bebas https://craftpix.net/file-licenses/): peri bercahaya (12f),
  tanaman predator (9f), pulau batu melayang (6f). Latar hutan/danau parallax
  (sky/clouds/flora1/flora2) memang sudah memakai paket yang sama sejak v12.
