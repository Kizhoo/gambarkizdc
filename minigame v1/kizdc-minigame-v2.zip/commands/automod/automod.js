const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, updateGuildConfig, addBannedWord, removeBannedWord, getBannedWords } = require('../../database/db');
const { successEmbed, errorEmbed, baseEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('automod')
    .setDescription('Kelola sistem automod server')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub => sub.setName('toggle').setDescription('Nyalakan/matikan automod (master switch)'))
    .addSubcommand(sub => sub.setName('antilink-toggle').setDescription('Nyalakan/matikan filter anti-link (butuh automod aktif)'))
    .addSubcommand(sub => sub.setName('antispam-toggle').setDescription('Nyalakan/matikan filter anti-spam (butuh automod aktif)'))
    .addSubcommand(sub => sub.setName('bannedword-add').setDescription('Tambah kata terlarang ke filter automod')
      .addStringOption(o => o.setName('kata').setDescription('Kata yang akan diblokir').setRequired(true)))
    .addSubcommand(sub => sub.setName('bannedword-remove').setDescription('Hapus kata dari filter automod')
      .addStringOption(o => o.setName('kata').setDescription('Kata yang akan dihapus').setRequired(true)))
    .addSubcommand(sub => sub.setName('bannedword-list').setDescription('Lihat daftar kata terlarang'))
    .addSubcommand(sub => sub.setName('antiraid-toggle').setDescription('Nyalakan/matikan proteksi anti-raid (kick otomatis akun baru)'))
    .addSubcommand(sub => sub.setName('antiraid-minage').setDescription('Atur minimal umur akun Discord untuk bisa join')
      .addIntegerOption(o => o.setName('hari').setDescription('Minimal umur akun dalam hari').setRequired(true).setMinValue(0).setMaxValue(365))),

  async execute(interaction) {
    const lang = guildLang(interaction);
    const sub = interaction.options.getSubcommand();
    const cfg = getGuildConfig(interaction.guild.id);
    const on = t(lang, 'music.on'), off = t(lang, 'music.off');

    if (sub === 'toggle') {
      const newState = cfg.automodEnabled ? 0 : 1;
      updateGuildConfig(interaction.guild.id, { automodEnabled: newState });
      return interaction.reply({ embeds: [successEmbed(t(lang, 'auto.toggled', { state: newState ? on : off }))] });
    }

    if (sub === 'antilink-toggle') {
      if (!cfg.automodEnabled) return interaction.reply({ embeds: [errorEmbed(t(lang, 'auto.not_enabled'))], ephemeral: true });
      const newState = cfg.antiLinkEnabled ? 0 : 1;
      updateGuildConfig(interaction.guild.id, { antiLinkEnabled: newState });
      return interaction.reply({ embeds: [successEmbed(t(lang, 'auto.antilink', { state: newState ? on : off }))] });
    }

    if (sub === 'antispam-toggle') {
      if (!cfg.automodEnabled) return interaction.reply({ embeds: [errorEmbed(t(lang, 'auto.not_enabled'))], ephemeral: true });
      const newState = cfg.antiSpamEnabled ? 0 : 1;
      updateGuildConfig(interaction.guild.id, { antiSpamEnabled: newState });
      return interaction.reply({ embeds: [successEmbed(t(lang, 'auto.antispam', { state: newState ? on : off }))] });
    }

    if (sub === 'bannedword-add') {
      const word = interaction.options.getString('kata');
      addBannedWord(interaction.guild.id, word);
      return interaction.reply({ embeds: [successEmbed(t(lang, 'auto.word_added', { w: word }))], ephemeral: true });
    }

    if (sub === 'bannedword-remove') {
      const word = interaction.options.getString('kata');
      const removed = removeBannedWord(interaction.guild.id, word);
      if (!removed) return interaction.reply({ embeds: [errorEmbed(t(lang, 'auto.word_not_found'))], ephemeral: true });
      return interaction.reply({ embeds: [successEmbed(t(lang, 'auto.word_removed', { w: word }))], ephemeral: true });
    }

    if (sub === 'bannedword-list') {
      const words = getBannedWords(interaction.guild.id);
      const description = words.length ? words.map(w => `\`${w}\``).join(', ') : t(lang, 'auto.no_words');
      return interaction.reply({ embeds: [baseEmbed().setTitle(t(lang, 'auto.word_list_title')).setDescription(description)], ephemeral: true });
    }

    if (sub === 'antiraid-toggle') {
      const newState = cfg.antiraidEnabled ? 0 : 1;
      updateGuildConfig(interaction.guild.id, { antiraidEnabled: newState });
      return interaction.reply({
        embeds: [successEmbed(t(lang, 'auto.antiraid', { state: newState ? on : off, days: cfg.minAccountAgeDays || 3 }))],
      });
    }

    if (sub === 'antiraid-minage') {
      const days = interaction.options.getInteger('hari');
      updateGuildConfig(interaction.guild.id, { minAccountAgeDays: days });
      return interaction.reply({ embeds: [successEmbed(t(lang, 'auto.minage', { days }))] });
    }
  },
};
