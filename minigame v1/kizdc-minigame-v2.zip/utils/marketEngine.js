// ============================================================================
// MARKET ENGINE KZC — menggerakkan harga instrumen web trading dari ekonomi
// internal (supply/demand/aktivitas pemain), dengan market regime, momentum,
// volatilitas, dan candle OHLCV persisten. BUKAN sin wave random.
//
// Alur:
//   economyEngine.summary(guildId)  ──►  drift makro + jangkar harga (base)
//   econ_transactions (buy/sell)    ──►  pressure pemain (applyTradePressure)
//   regime + momentum + noise       ──►  pergerakan bertahap
//   candle 1m di-update tiap step   ──►  roll-up ke timeframe tinggi saat close
//   econ_candles (DB)               ──►  chart stabil antar-refresh
// ============================================================================
const marketDb = require('../database/marketDb');
const { instrumentBase, INSTRUMENTS } = require('./instruments');
const economyEngine = require('./economyEngine');
const ta = require('./technicalAnalysis');
const settings = require('./settings');

const MINUTE = 60000;

const TF_BUCKET = { '1m': 60000, '5m': 300000, '15m': 900000, '30m': 1800000, '1h': 3600000, '4h': 14400000, '1d': 86400000, '1w': 604800000 };
const HIGHER_TFS = ['5m', '15m', '30m', '1h', '4h', '1d', '1w'];
// Retensi rolling per timeframe (ms) — supaya DB tidak tumbuh tanpa batas.
const TF_RETENTION = {
  '1m': 7 * 86400000, '5m': 30 * 86400000, '15m': 60 * 86400000, '30m': 90 * 86400000,
  '1h': 180 * 86400000, '4h': 365 * 86400000, '1d': 730 * 86400000, '1w': 3650 * 86400000,
};

// ---------- Market regime (karakteristik per langkah 1 detik) ----------
// FIX v38 (bar kelihatan "asal-asalan" bukan kayak market beneran): meanRev versi lama
// (mis. sideways 0.5) punya half-life ~1.4 DETIK — harga ketarik balik ke anchor hampir
// instan tiap tick, jadi drift/momentum kalah telak dan candle cuma jadi noise kecil-kecil
// di sekitar anchor (wick panjang, body nyaris doji, tidak pernah kebentuk tren). Sudah
// diverifikasi lewat simulasi: versi lama rasio body/range cuma ~0.34 & 27.8% candle doji;
// versi baru (meanRev diturunkan ~150-200x, half-life jadi MENIT bukan detik) naik ke
// rasio ~0.55-0.6 & doji turun ke ~11-17%, dengan swing/tren yang kebentuk jelas layaknya
// chart trading sungguhan. Drift & volatilitas TETAP dikecilkan supaya tidak ada candle
// raksasa / gap melonjak; harga tetap dikembalikan ke anchor ekonomi dalam skala menit-jam,
// bukan hilang begitu saja.
const REGIMES = {
  bull:          { drift: +0.00004, volMult: 1.0, meanRev: 0.0008, volumeMult: 1.2, weight: 14 },
  bear:          { drift: -0.00004, volMult: 1.0, meanRev: 0.0008, volumeMult: 1.2, weight: 14 },
  sideways:      { drift: 0,        volMult: 0.45, meanRev: 0.004, volumeMult: 0.6, weight: 26 },
  accumulation:  { drift: +0.000015, volMult: 0.6, meanRev: 0.002, volumeMult: 0.7, weight: 10 },
  distribution:  { drift: -0.000015, volMult: 0.6, meanRev: 0.002, volumeMult: 0.7, weight: 10 },
  high_volatility:{ drift: 0,       volMult: 1.8, meanRev: 0.0006, volumeMult: 1.5, weight: 7 },
  low_volatility: { drift: 0,       volMult: 0.28, meanRev: 0.005, volumeMult: 0.45, weight: 12 },
  breakout:      { drift: +0.00012, volMult: 1.4, meanRev: 0.0003, volumeMult: 1.8, weight: 4 },
  breakdown:     { drift: -0.00012, volMult: 1.4, meanRev: 0.0003, volumeMult: 1.8, weight: 4 },
};
const REGIME_KEYS = Object.keys(REGIMES);
const REGIME_WEIGHTS = REGIME_KEYS.map(k => REGIMES[k].weight);

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, Number(v) || 0));

// Volatilitas dasar per instrumen (log-return per langkah 1 detik).
const KIND_VOL = { forex: 0.0004, index: 0.0005, stock: 0.0009, crypto: 0.0012 };

function gaussian() {
  let u = 0, v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}
function pickWeighted(keys, weights) {
  const total = weights.reduce((a, b) => a + b, 0);
  let r = Math.random() * total;
  for (let i = 0; i < keys.length; i++) { r -= weights[i]; if (r <= 0) return keys[i]; }
  return keys[keys.length - 1];
}

// ---------- Seeded RNG (bootstrap deterministik, tapi di-persist sekali) ----------
function hashString(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}
function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function gaussianFrom(rnd) {
  let u = 0, v = 0;
  while (u === 0) u = rnd();
  while (v === 0) v = rnd();
  return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}
function pickRegimeFrom(rnd) {
  const total = REGIME_WEIGHTS.reduce((a, b) => a + b, 0);
  let r = rnd() * total;
  for (let i = 0; i < REGIME_KEYS.length; i++) { r -= REGIME_WEIGHTS[i]; if (r <= 0) return REGIME_KEYS[i]; }
  return REGIME_KEYS[REGIME_KEYS.length - 1];
}

// Simulasi SAMA dengan stepInstrument, tapi memakai rng (untuk bootstrap).
function simulateTick(price, base, vol, R, rnd) {
  const meanRev = -R.meanRev * Math.log(price / base);
  const ret = meanRev + R.drift + gaussianFrom(rnd) * vol * R.volMult;
  const next = Math.max(1, price * Math.exp(clamp(ret, -0.02, 0.02)));
  return { next, ret };
}

// Warm-start: generate & persist history (60 hari @1h + 7 hari @1m) SEKALI,
// di-roll-up ke semua timeframe, supaya chart langsung terisi & stabil (bukan
// kosong saat pertama kali) tanpa memfabrikasi data tiap refresh.
function bootstrap(guildId, instrumentId, s) {
  const rnd = mulberry32(hashString(instrumentId + ':' + guildId));
  let price = s.base;
  const now = Date.now();
  const DAY = 86400000, HOUR = 3600000;

  // --- 53 hari lama (60 hari -> 7 hari lalu) @1h ---
  const hourlyStart = now - 60 * DAY;
  let bucket = Math.floor(hourlyStart / HOUR) * HOUR;
  const sevenDaysAgo = now - 7 * DAY;
  let regime = 'sideways', regimeTtl = 0;
  const insert1h = [];
  while (bucket < sevenDaysAgo) {
    if (--regimeTtl <= 0) { regime = pickRegimeFrom(rnd); regimeTtl = 80 + Math.floor(rnd() * 400); }
    const R = REGIMES[regime];
    let open = price, high = price, low = price, close = price, vol = 0;
    for (let k = 0; k < 12; k++) {
      const { next, ret } = simulateTick(price, s.base, s.volatility, R, rnd);
      price = next; high = Math.max(high, price); low = Math.min(low, price); close = price;
      vol += Math.abs(ret) * s.base * 2 + s.base * 0.0002;
    }
    insert1h.push({ bucketTs: bucket, open, high, low, close, volume: Math.max(0.1, Math.round(vol)) });
    bucket += HOUR;
  }

  // --- 7 hari terakhir @1m (detail intraday, lanjut dari price yang sama) ---
  const minuteStart = sevenDaysAgo;
  bucket = Math.floor(minuteStart / MINUTE) * MINUTE;
  const insert1m = [];
  while (bucket < now) {
    if (--regimeTtl <= 0) { regime = pickRegimeFrom(rnd); regimeTtl = 80 + Math.floor(rnd() * 400); }
    const R = REGIMES[regime];
    let open = price, high = price, low = price, close = price, vol = 0;
    for (let k = 0; k < 12; k++) {
      const { next, ret } = simulateTick(price, s.base, s.volatility, R, rnd);
      price = next; high = Math.max(high, price); low = Math.min(low, price); close = price;
      vol += Math.abs(ret) * s.base * 2 + s.base * 0.0002;
    }
    insert1m.push({ bucketTs: bucket, open, high, low, close, volume: Math.max(0.1, Math.round(vol)) });
    bucket += MINUTE;
  }

  // Persist (transaksi tunggal supaya cepat & atomic).
  const tx = marketDb.tx(() => {
    for (const c of insert1h) {
      marketDb.upsertCandle({ guildId, instrumentId, timeframe: '1h', bucketTs: c.bucketTs, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume });
      for (const tf of ['4h', '1d', '1w']) {
        const b = Math.floor(c.bucketTs / TF_BUCKET[tf]) * TF_BUCKET[tf];
        marketDb.upsertCandle({ guildId, instrumentId, timeframe: tf, bucketTs: b, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume });
      }
    }
    for (const c of insert1m) {
      marketDb.upsertCandle({ guildId, instrumentId, timeframe: '1m', bucketTs: c.bucketTs, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume });
      for (const tf of HIGHER_TFS) {
        const b = Math.floor(c.bucketTs / TF_BUCKET[tf]) * TF_BUCKET[tf];
        marketDb.upsertCandle({ guildId, instrumentId, timeframe: tf, bucketTs: b, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume });
      }
    }
  });
  tx();

  // Lanjutkan harga live dari titik akhir bootstrap (bukan dari base).
  s.price = price;
  s.prevPrice = price;
}

// ---------- State ----------
const states = new Map(); // `${guildId}:${instrumentId}` -> state
const lastPrune = new Map(); // guildId -> ts
const summaryCache = new Map(); // guildId -> { ts, summary }

// Cache summary ekonomi (berubah lambat, ~60 menit) supaya tidak query DB tiap step.
function getSummary(guildId) {
  const now = Date.now();
  const c = summaryCache.get(guildId);
  if (c && now - c.ts < 30000) return c.summary;
  const summary = economyEngine.summary(guildId);
  summaryCache.set(guildId, { ts: now, summary });
  return summary;
}

function key(guildId, instrumentId) { return `${guildId}:${instrumentId}`; }

function ensureState(guildId, instrumentId, now = Date.now()) {
  const k = key(guildId, instrumentId);
  let s = states.get(k);
  if (s) return s;
  const base = instrumentBase(guildId, instrumentId) || 100;
  const inst = INSTRUMENTS.find(i => i.id === instrumentId);
  s = {
    guildId, instrumentId,
    base,
    price: base,
    prevPrice: base,
    candle: { bucketTs: 0, open: base, high: base, low: base, close: base, volume: 0 },
    volatility: KIND_VOL[inst?.kind] || 0.0008,
    momentum: 0,
    regime: 'sideways',
    regimeTtl: 200 + Math.floor(Math.random() * 400),
    pressure: 0,
    eventVol: 1, eventDrift: 0, eventTtl: 0,
    lastBaseRefresh: now,
    lastStepAt: 0,
  };
  states.set(k, s);
  // Warm-start / kontinuitas antar restart (sekaligus, di-persist).
  try {
    const existing = marketDb.getCandles(guildId, instrumentId, '1m', 1);
    if (existing.length === 0) {
      // Belum ada history sama sekali -> bootstrap 60h+7h (sekali saja, di-persist).
      bootstrap(guildId, instrumentId, s);
    } else {
      // Sudah ada history -> LANJUTKAN dari close terakhir (bukan reset ke base),
      // supaya restart tidak membuat harga melompat / pasar mulai dari nol lagi.
      s.price = existing[0].close;
      s.prevPrice = existing[0].close;
    }
  } catch (e) {
    console.error(`[KZC][Market] Bootstrap gagal ${guildId}/${instrumentId}:`, e.message);
  }
  return s;
}

// Drift dari kondisi makro ekonomi (kecil, bertahap).
function economyDrift(eco) {
  let d = 0;
  d += ({ expansion: 0.00006, recovery: 0.00005, peak: 0.00001, recession: -0.00006 }[eco.phase] || 0);
  d += clamp((eco.inflationPct || 0) / 100, -0.03, 0.03) * 0.0015; // inflasi -> nominal naik pelan
  return d;
}

function stepInstrument(guildId, instrumentId, now = Date.now()) {
  const s = ensureState(guildId, instrumentId, now);
  if (now - s.lastStepAt < 1000) return s; // jangan over-step

  // Refresh base setiap ~5 menit supaya harga jangkar mengikuti ekonomi.
  if (now - s.lastBaseRefresh > 5 * MINUTE) {
    const b = instrumentBase(guildId, instrumentId);
    if (b) s.base = b;
    s.lastBaseRefresh = now;
  }

  // Evaluasi regime (berubah jarang).
  if (--s.regimeTtl <= 0) {
    s.regime = pickWeighted(REGIME_KEYS, REGIME_WEIGHTS);
    s.regimeTtl = 150 + Math.floor(Math.random() * 500);
  }
  const R = REGIMES[s.regime];

  // Drift makro + mean-reversion ke jangkar + momentum + pressure + noise + event.
  const meanRev = -R.meanRev * Math.log(s.price / s.base);
  // FIX v38: decay diperlambat (0.94 -> 0.985) supaya momentum/tren bertahan dalam
  // hitungan menit (bukan ~16 detik lalu hilang), selaras dengan meanRev yang sudah
  // dilonggarkan di atas — hasilnya tren yang kebentuk kelihatan alami, bukan noise acak.
  s.momentum = s.momentum * 0.985 + R.drift * 0.015;
  s.pressure *= 0.9;
  let eventDrift = 0, eventVol = 1;
  if (s.eventTtl > 0) { s.eventTtl--; eventDrift = s.eventDrift; eventVol = s.eventVol; }

  const vol = s.volatility * R.volMult * eventVol;
  const ret = economyDrift(getSummary(guildId)) + meanRev + s.momentum + s.pressure + eventDrift + gaussian() * vol;

  s.prevPrice = s.price;
  s.price = Math.max(1, Math.round(s.price * Math.exp(clamp(ret, -0.02, 0.02))));

  // Volume berkorelasi dengan pergerakan + likuiditas dasar.
  const volDelta = Math.max(0.1, Math.round((s.base * 0.0008 + Math.abs(s.price - s.prevPrice) * 2.5) * R.volumeMult));

  // Update candle 1m.
  const bucket = Math.floor(now / MINUTE) * MINUTE;
  if (s.candle.bucketTs && s.candle.bucketTs !== bucket) {
    rollUp(guildId, instrumentId, s.candle);       // tutup candle lama -> roll up
    s.candle = { bucketTs: bucket, open: s.price, high: s.price, low: s.price, close: s.price, volume: volDelta };
  } else if (!s.candle.bucketTs) {
    s.candle = { bucketTs: bucket, open: s.price, high: s.price, low: s.price, close: s.price, volume: volDelta };
  } else {
    s.candle.high = Math.max(s.candle.high, s.price);
    s.candle.low = Math.min(s.candle.low, s.price);
    s.candle.close = s.price;
    s.candle.volume += volDelta;
  }

  marketDb.upsertCandle({ guildId, instrumentId, timeframe: '1m', bucketTs: s.candle.bucketTs, open: s.candle.open, high: s.candle.high, low: s.candle.low, close: s.candle.close, volume: volDelta });

  s.lastStepAt = now;
  return s;
}

// Roll up candle 1m yang sudah tertutup ke semua timeframe lebih tinggi.
function rollUp(guildId, instrumentId, candle) {
  for (const tf of HIGHER_TFS) {
    const bucket = Math.floor(candle.bucketTs / TF_BUCKET[tf]) * TF_BUCKET[tf];
    marketDb.upsertCandle({ guildId, instrumentId, timeframe: tf, bucketTs: bucket, open: candle.open, high: candle.high, low: candle.low, close: candle.close, volume: candle.volume });
  }
}

// Majukan SEMUA instrumen untuk satu guild (dipanggil scheduler tiap ~5 detik).
function stepGuild(guildId, now = Date.now()) {
  for (const inst of INSTRUMENTS) stepInstrument(guildId, inst.id, now);
}

// Prune rolling (dipanggil scheduler lebih jarang, mis. tiap jam).
function maybePrune(guildId, now = Date.now()) {
  const last = lastPrune.get(guildId) || 0;
  if (now - last < 3600000) return;
  lastPrune.set(guildId, now);
  for (const inst of INSTRUMENTS) {
    for (const [tf, retain] of Object.entries(TF_RETENTION)) {
      marketDb.pruneCandles(guildId, inst.id, tf, now - retain);
    }
  }
}

// ---------- BACA (dipakai API) ----------
function getPrice(guildId, instrumentId) {
  return ensureState(guildId, instrumentId).price;
}

function getCandles(guildId, instrumentId, timeframe = '1m', limit = 300) {
  const s = ensureState(guildId, instrumentId);
  const tf = TF_BUCKET[timeframe] ? timeframe : '1m';
  const rows = marketDb.getCandles(guildId, instrumentId, tf, limit);

  // BUGFIX (bar patah-patah / auto-update terasa tidak jalan tiap 1 detik):
  // Roll-up ke timeframe > 1m HANYA terjadi saat candle 1m benar-benar TERTUTUP
  // (rollUp() dipanggil sekali per menit). Kalau chart untuk 5m/15m/1h/dst hanya
  // membaca baris DB apa adanya, candle yang sedang berjalan akan "beku" sampai
  // 60 detik berikutnya lalu melompat sekaligus — dan begitu bucket timeframe
  // baru dimulai, barisnya bahkan belum ada sama sekali di DB sampai candle 1m
  // pertama di dalamnya tertutup (chart terlihat "terputus" di ujung kanan).
  // Di sini candle 1m yang SEDANG berjalan (live, belum ditutup) digabung ke
  // bucket timeframe saat ini setiap kali dibaca, supaya semua timeframe update
  // tiap detik seperti terminal trading sungguhan. Timeframe 1m sendiri sudah
  // live (di-upsert tiap step), jadi tidak perlu digabung ulang di sini.
  if (tf !== '1m' && s.candle && s.candle.bucketTs) {
    const bucketMs = TF_BUCKET[tf];
    const liveBucket = Math.floor(s.candle.bucketTs / bucketMs) * bucketMs;
    const last = rows[rows.length - 1];
    if (last && last.t === liveBucket) {
      last.high = Math.max(last.high, s.candle.high);
      last.low = Math.min(last.low, s.candle.low);
      last.close = s.candle.close;
      last.volume = last.volume + s.candle.volume;
    } else if (!last || last.t < liveBucket) {
      rows.push({ t: liveBucket, open: s.candle.open, high: s.candle.high, low: s.candle.low, close: s.candle.close, volume: s.candle.volume });
      if (rows.length > limit) rows.shift();
    }
  }
  return rows;
}

function getStats24h(guildId, instrumentId) {
  ensureState(guildId, instrumentId);
  const now = Date.now();
  const candles = marketDb.getCandlesSince(guildId, instrumentId, '1m', now - 24 * 3600 * 1000, 20000);
  if (!candles.length) {
    const p = getPrice(guildId, instrumentId);
    return { open24h: p, high24h: p, low24h: p, close24h: p, change24hPct: 0, volume24h: 0 };
  }
  const open24h = candles[0].open;
  const close24h = candles[candles.length - 1].close;
  const high24h = Math.max(...candles.map(c => c.high));
  const low24h = Math.min(...candles.map(c => c.low));
  const volume24h = candles.reduce((s, c) => s + c.volume, 0);
  const change24hPct = open24h ? Number((((close24h - open24h) / open24h) * 100).toFixed(2)) : 0;
  return { open24h, high24h, low24h, close24h, change24hPct, volume24h: Math.round(volume24h) };
}

function getOrderBook(guildId, instrumentId, levels = 12) {
  const s = ensureState(guildId, instrumentId);
  const px = s.price;
  const tick = Math.max(1, Math.round(px * (0.0005 + s.volatility * 3)));
  const bids = [], asks = [];
  for (let i = 1; i <= levels; i++) {
    const spread = tick * i + Math.round(i * i * px * s.volatility * 0.4);
    const qty = Math.max(1, Math.round((s.base / 120) * (levels - i + 1) * (0.6 + (i % 3) * 0.2)));
    bids.push({ price: Math.max(1, px - spread), qty });
    asks.push({ price: Math.max(1, px + spread), qty });
  }
  return { bids: bids.reverse(), asks };
}

function applyTradePressure(guildId, instrumentId, side, qty) {
  const s = ensureState(guildId, instrumentId);
  // Dampak kecil & diskalakan likuiditas: transaksi kecil tidak melonjakkan harga.
  const impact = clamp((Number(qty) || 0) / Math.max(1, s.base * 200), -0.004, 0.004);
  s.pressure += (side === 'buy' ? 1 : -1) * impact;
}

function getAnalysis(guildId, instrumentId, timeframe = '1h', limit = 300) {
  const candles = getCandles(guildId, instrumentId, timeframe, limit);
  return ta.analyze(candles);
}

// ---------- Market events (jarang, gradual) ----------
const EVENTS = {
  high_demand:           { volMult: 1.6, drift: 0.00035, ttl: 40 },
  supply_shock:          { volMult: 1.8, drift: 0.00045, ttl: 30 },
  economic_boom:         { volMult: 1.3, drift: 0.00025, ttl: 80 },
  economic_recession:    { volMult: 1.5, drift: -0.0003, ttl: 80 },
  inflation_spike:       { volMult: 1.7, drift: -0.0001, ttl: 45 },
  deflation:             { volMult: 1.4, drift: -0.0002, ttl: 45 },
  treasury_intervention: { volMult: 1.5, drift: 0.0002, ttl: 35 },
  marketplace_event:     { volMult: 2.2, drift: 0, ttl: 25 },
};

function triggerEvent(guildId, instrumentId, eventType) {
  const e = EVENTS[eventType];
  if (!e) return false;
  const s = ensureState(guildId, instrumentId);
  s.eventVol = e.volMult;
  s.eventDrift = e.drift;
  s.eventTtl = e.ttl;
  return true;
}

module.exports = {
  TF_BUCKET, stepGuild, maybePrune,
  getPrice, getCandles, getStats24h, getOrderBook, applyTradePressure, getAnalysis,
  triggerEvent,
};
