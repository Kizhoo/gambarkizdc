# AI Lokal / Offline untuk KizhooBot

Bot ini sebenarnya sudah mendukung provider AI tanpa biaya (Cloudflare Workers AI, gratis dengan
kuota harian). Tapi kalau kamu mau **AI offline yang jalan di server sendiri** (tanpa API key cloud,
tanpa biaya per request, dan satu model bisa dipakai semua server tanpa "boros"), bisa pakai
**llama.cpp server** dengan model kecil.

## Cara kerja

1. Jalankan **llama.cpp server** di server terpisah (atau server yang sama, port beda).
2. Server itu menyediakan API yang kompatibel dengan OpenAI (`/v1/chat/completions`).
3. Bot cukup diarahkan ke `ai.provider = local` — sudah saya tambahkan dukungannya di
   `utils/aiProvider.js`.

## Model kecil (di bawah / sekitar 300MB)

| Model | Ukuran (GGUF Q4) | Catatan |
|-------|------------------|---------|
| **SmolLM2-135M-Instruct** | ±270MB | Paling kecil; cukup buat teks sederhana/pendek |
| **Qwen2.5-0.5B-Instruct** | ±400MB | "Di atas dikit" dari 300MB, kualitas jauh lebih baik & lumayan paham Bahasa Indonesia |
| **TinyLlama-1.1B** | ±650MB | Lebih besar, kualitas menengah |

Rekomendasi: **Qwen2.5-0.5B-Instruct** — ukuran masih kecil tapi jauh lebih berguna untuk narasi AI
Ekonom / Luna dibanding model 135M.

> Catatan jujur: model sekecil ini jelas **tidak sepintar** Llama 3.1 8B / GPT. Hasilnya lebih
> sederhana dan kadang kurang natural. Cocok untuk report ringkas, bukan percakapan panjang.

## Langkah setup (llama.cpp server)

### 1. Install llama.cpp (sekali saja)

```bash
# Di server (Linux). Pastikan ada cmake & g++.
git clone https://github.com/ggerganov/llama.cpp.git
cd llama.cpp
cmake -B build -DGGML_CUDA=OFF   # CPU saja; kalau ada GPU NVIDIA: -DGGML_CUDA=ON
cmake --build build --config Release -j
```

### 2. Download model GGUF (Q4)

```bash
# Qwen2.5-0.5B-Instruct (Q4_K_M, ±400MB)
# Unduh dari HuggingFace, mis. repo: Qwen/Qwen2.5-0.5B-Instruct-GGUF
# Simpan sebagai: models/qwen2.5-0.5b-instruct-q4_k_m.gguf
```

Contoh link HuggingFace (cari file `*.gguf` di repo):
`https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF`

### 3. Jalankan server (OpenAI-compatible API)

```bash
./build/bin/llama-server \
  -m models/qwen2.5-0.5b-instruct-q4_k_m.gguf \
  --host 0.0.0.0 --port 8080 \
  -c 2048 -ngl 0
```

Server akan listen di `http://IP-SERVER:8080/v1/chat/completions`.

### 4. Arahkan bot ke AI lokal

Edit `config.json` bagian `ai`:

```json
"ai": {
  "provider": "local",
  "model": "qwen2.5-0.5b-instruct"
}
```

Lalu di `.env` (opsional, kalau server-nya bukan di localhost):

```env
LOCAL_AI_BASE_URL=http://IP-SERVER:8080/v1
```

Kalau server lokal di mesin yang sama, cukup biarkan default `http://localhost:8080/v1`.

### 5. Restart bot

Setelah itu semua fitur AI (AI Ekonom, generate item, Luna) otomatis pakai model lokal.

## Alternatif: Node.js murni (tanpa binary llama.cpp)

Kalau mau **pure Node.js** (tanpa kompilasi C++), pakai package
[`node-llama-cpp`](https://www.npmjs.com/package/node-llama-cpp):

```bash
npm install node-llama-cpp
```

Lalu buat file kecil `scripts/local-ai/server.js` yang load model GGUF & expose endpoint
`/v1/chat/completions` via Express. Intinya sama: bot cuma butuh endpoint OpenAI-compatible.

## Cara kerja di kode

`utils/aiProvider.js` sekarang punya provider baru `local`:

```js
case 'local':
  return openaiCompatText({
    baseUrl: process.env.LOCAL_AI_BASE_URL || 'http://localhost:8080/v1',
    apiKey: process.env.LOCAL_AI_API_KEY || 'local',
    keyName: 'LOCAL_AI',
  }, model, messages);
```

Jadi kamu bebas ganti kapan pun antara `cloudflare` (gratis, tanpa setup) dan `local` (offline,
tanpa biaya, satu model untuk semua server).
