const { SlashCommandBuilder } = require('discord.js');
const { getEconomy, updateBalance, setLastAction } = require('../../database/db');
const econ = require('../../database/economyDb');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const kizco = require('../../utils/kizco');
const config = require('../../config.json');
const { t, guildLang } = require('../../utils/i18n');

const COOLDOWN_MS = 2 * 60 * 60 * 1000; // 2 jam

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rob')
    .setDescription('Coba rampok Kizco orang lain (berisiko!)')
    .addUserOption(o => o.setName('target').setDescription('Orang yang ingin dirampok').setRequired(true)),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const target = interaction.options.getUser('target');

    if (target.id === interaction.user.id) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'rob.self'))], ephemeral: true });
    }
    if (target.bot) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'rob.bot'))], ephemeral: true });
    }

    const robberEco = getEconomy(interaction.guild.id, interaction.user.id);
    const now = Date.now();
    if (now - robberEco.lastRob < COOLDOWN_MS) {
      const minutes = Math.floor((COOLDOWN_MS - (now - robberEco.lastRob)) / 60000);
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'rob.cooldown', { m: minutes }))], ephemeral: true });
    }

    const targetEco = getEconomy(interaction.guild.id, target.id);
    if (targetEco.balance < 50) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'rob.no_target_funds'))], ephemeral: true });
    }

    setLastAction(interaction.guild.id, interaction.user.id, 'lastRob', now);
    const success = Math.random() < config.robSuccessRate;

    if (success) {
      const stolen = Math.floor(targetEco.balance * (Math.random() * 0.3 + 0.1)); // curi 10-40%
      updateBalance(interaction.guild.id, target.id, -stolen);
      updateBalance(interaction.guild.id, interaction.user.id, stolen);
      econ.recordTransaction(interaction.guild.id, { type: 'rob', actorId: interaction.user.id, targetId: target.id, amount: stolen, note: 'Perampokan berhasil' });
      return interaction.reply({ embeds: [successEmbed(t(lang, 'rob.success', { amount: kizco.format(stolen), user: target.username }))] });
    } else {
      const fine = Math.floor(Math.random() * 200) + 50;
      const paid = Math.min(fine, robberEco.balance);
      updateBalance(interaction.guild.id, interaction.user.id, -paid);
      econ.recordTransaction(interaction.guild.id, { type: 'fine', actorId: interaction.user.id, amount: -paid, note: 'Denda perampokan gagal' });
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'rob.fail', { amount: kizco.format(paid) }))] });
    }
  },
};
