// ============================================================================
// TECHNICAL ANALYSIS — indikator dihitung dari OHLCV NYATA (hasil market engine).
// ----------------------------------------------------------------------------
// Semua indikator menerima array candle `{ t, open, high, low, close, volume }`
// (urut ASC lama->baru) dan mengembalikan series/sebuah nilai. TIDAK ada angka
// hardcoded; parameter period default standar industri.
// ============================================================================

function ema(values, period) {
  const out = new Array(values.length).fill(null);
  if (!values.length || values.length < period) return out;
  const k = 2 / (period + 1);
  let prev = values.slice(0, period).reduce((a, b) => a + b, 0) / period;
  out[period - 1] = prev;
  for (let i = period; i < values.length; i++) {
    prev = values[i] * k + prev * (1 - k);
    out[i] = prev;
  }
  return out;
}

function sma(values, period) {
  const out = new Array(values.length).fill(null);
  let sum = 0;
  for (let i = 0; i < values.length; i++) {
    sum += values[i];
    if (i >= period) sum -= values[i - period];
    if (i >= period - 1) out[i] = sum / period;
  }
  return out;
}

function rsi(closes, period = 14) {
  const out = new Array(closes.length).fill(null);
  if (closes.length <= period) return out;
  let gain = 0, loss = 0;
  for (let i = 1; i <= period; i++) {
    const d = closes[i] - closes[i - 1];
    if (d >= 0) gain += d; else loss -= d;
  }
  let avgGain = gain / period, avgLoss = loss / period;
  out[period] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  for (let i = period + 1; i < closes.length; i++) {
    const d = closes[i] - closes[i - 1];
    avgGain = (avgGain * (period - 1) + Math.max(0, d)) / period;
    avgLoss = (avgLoss * (period - 1) + Math.max(0, -d)) / period;
    out[i] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  }
  return out;
}

function macd(closes, fast = 12, slow = 26, signal = 9) {
  const ef = ema(closes, fast), es = ema(closes, slow);
  const line = closes.map((_, i) => (ef[i] != null && es[i] != null ? ef[i] - es[i] : null));
  const sig = ema(line.filter(v => v != null), signal);
  // realign signal to full length
  const signalSeries = new Array(closes.length).fill(null);
  let j = 0;
  for (let i = 0; i < line.length; i++) { if (line[i] != null) signalSeries[i] = sig[j++] != null ? sig[j - 1] : null; }
  const hist = closes.map((_, i) => (line[i] != null && signalSeries[i] != null ? line[i] - signalSeries[i] : null));
  return { line, signal: signalSeries, hist };
}

function bollinger(closes, period = 20, mult = 2) {
  const mid = sma(closes, period);
  const upper = new Array(closes.length).fill(null);
  const lower = new Array(closes.length).fill(null);
  for (let i = period - 1; i < closes.length; i++) {
    const slice = closes.slice(i - period + 1, i + 1);
    const m = mid[i];
    const variance = slice.reduce((s, v) => s + (v - m) ** 2, 0) / period;
    const sd = Math.sqrt(variance);
    upper[i] = m + mult * sd;
    lower[i] = m - mult * sd;
  }
  return { upper, middle: mid, lower };
}

function trueRange(c, i, prevClose) {
  return Math.max(c[i].high - c[i].low, Math.abs(c[i].high - prevClose), Math.abs(c[i].low - prevClose));
}

function atr(candles, period = 14) {
  const out = new Array(candles.length).fill(null);
  if (candles.length <= period) return out;
  let trSum = 0;
  for (let i = 1; i <= period; i++) trSum += trueRange(candles, i, candles[i - 1].close);
  out[period] = trSum / period;
  for (let i = period + 1; i < candles.length; i++) {
    out[i] = (out[i - 1] * (period - 1) + trueRange(candles, i, candles[i - 1].close)) / period;
  }
  return out;
}

function volumeMa(candles, period = 20) {
  return sma(candles.map(c => c.volume), period);
}

// ---------- Market structure ----------
// Identifikasi pivot tinggi/rendah lokal, lalu HH/HL/LH/LL, BOS, CHoCH, support/resistance.
function pivotHighs(candles, left = 2, right = 2) {
  const out = [];
  for (let i = left; i < candles.length - right; i++) {
    let isHigh = true;
    for (let j = i - left; j <= i + right; j++) { if (j !== i && candles[j].high > candles[i].high) { isHigh = false; break; } }
    if (isHigh) out.push({ i, price: candles[i].high });
  }
  return out;
}
function pivotLows(candles, left = 2, right = 2) {
  const out = [];
  for (let i = left; i < candles.length - right; i++) {
    let isLow = true;
    for (let j = i - left; j <= i + right; j++) { if (j !== i && candles[j].low < candles[i].low) { isLow = false; break; } }
    if (isLow) out.push({ i, price: candles[i].low });
  }
  return out;
}

function last(arr) { return arr.length ? arr[arr.length - 1] : null; }

function analyze(candles) {
  if (!candles || candles.length < 30) {
    return { ready: false, note: 'insufficient_data' };
  }
  const closes = candles.map(c => c.close);
  const lastClose = closes[closes.length - 1];

  const ema9 = last(ema(closes, 9));
  const ema20 = last(ema(closes, 20));
  const ema50 = last(ema(closes, 50));
  const ema200 = last(ema(closes, 200));
  const sma20 = last(sma(closes, 20));
  const sma50 = last(sma(closes, 50));
  const rsiVal = last(rsi(closes, 14));
  const macdVals = macd(closes);
  const macdLine = last(macdVals.line);
  const macdSignal = last(macdVals.signal);
  const macdHist = last(macdVals.hist);
  const boll = bollinger(closes);
  const bollUpper = last(boll.upper), bollMiddle = last(boll.middle), bollLower = last(boll.lower);
  const atrVal = last(atr(candles, 14));
  const volMa = last(volumeMa(candles, 20));
  const lastVolume = candles[candles.length - 1].volume;
  const relVolume = volMa > 0 ? lastVolume / volMa : 1;

  // Trend (EMA stack)
  let trend = 'sideways';
  if (ema20 && ema50) {
    if (lastClose > ema20 && ema20 > ema50) trend = 'bullish';
    else if (lastClose < ema20 && ema20 < ema50) trend = 'bearish';
  }

  // Momentum (MACD + RSI)
  let momentum = 'neutral';
  if (macdHist > 0 && (macdLine > macdSignal)) momentum = 'positive';
  else if (macdHist < 0 && (macdLine < macdSignal)) momentum = 'negative';

  // Market structure
  const highs = pivotHighs(candles);
  const lows = pivotLows(candles);
  let structure = 'ranging';
  const lastHighs = highs.slice(-3).map(p => p.price);
  const lastLows = lows.slice(-3).map(p => p.price);
  if (lastHighs.length >= 2 && lastLows.length >= 2) {
    const hh = lastHighs[lastHighs.length - 1] > lastHighs[lastHighs.length - 2];
    const hl = lastLows[lastLows.length - 1] > lastLows[lastLows.length - 2];
    const lh = lastHighs[lastHighs.length - 1] < lastHighs[lastHighs.length - 2];
    const ll = lastLows[lastLows.length - 1] < lastLows[lastLows.length - 2];
    if (hh && hl) structure = 'higher_high_higher_low';
    else if (lh && ll) structure = 'lower_high_lower_low';
    else if (hh && !hl) structure = 'break_of_structure_up';
    else if (ll && !lh) structure = 'break_of_structure_down';
  }

  // Support/resistance dari pivot
  const resistance = lastHighs.length ? Math.max(...lastHighs) : null;
  const support = lastLows.length ? Math.min(...lastLows) : null;

  return {
    ready: true,
    price: lastClose,
    indicators: {
      ema9, ema20, ema50, ema200, sma20, sma50,
      rsi: rsiVal,
      macd: macdLine, macdSignal, macdHist,
      bollingerUpper: bollUpper, bollingerMiddle: bollMiddle, bollingerLower: bollLower,
      atr: atrVal, relativeVolume: Number(relVolume.toFixed(2)),
    },
    trend, momentum, structure,
    support, resistance,
    volumeBias: relVolume > 1.2 ? 'above_average' : relVolume < 0.7 ? 'below_average' : 'average',
  };
}

module.exports = { ema, sma, rsi, macd, bollinger, atr, volumeMa, analyze };
