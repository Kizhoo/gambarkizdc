// ============================================================================
// GRAFIK EKONOMI KIZCO — render PNG (line chart) pakai @napi-rs/canvas
// ----------------------------------------------------------------------------
// Mirip chart trading/crypto: dua seri (indeks harga & uang beredar), grid,
// sumbu dengan label ringkas, plus anotasi fase siklus. Dipakai command
// /economy chart untuk menampilkan tren ekonomi langsung di Discord.
// ============================================================================
const { createCanvas } = require('@napi-rs/canvas');
const kizco = require('./kizco');

const W = 900, H = 360, PAD = { t: 24, r: 70, b: 40, l: 70 };

function niceMax(v) {
  if (v <= 0) return 1;
  const pow = Math.pow(10, Math.floor(Math.log10(v)));
  const n = v / pow;
  const m = n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10;
  return m * pow;
}

// points: array objek { timestamp, priceIndex, moneySupply } urut lama->baru.
function renderPriceChart(points, { title = 'Grafik Ekonomi Kizco' } = {}) {
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  // Latar gelap ala chart trading.
  ctx.fillStyle = '#0b0e14';
  ctx.fillRect(0, 0, W, H);

  if (!points || points.length < 2) {
    ctx.fillStyle = '#8a93a6';
    ctx.font = '18px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('Belum cukup data untuk digambar.', W / 2, H / 2);
    return canvas.toBuffer('image/png');
  }

  const plotW = W - PAD.l - PAD.r;
  const plotH = H - PAD.t - PAD.b;

  // Skala Y: dua seri beda besaran -> normalisasi masing-masing (twin axis).
  const prices = points.map(p => p.priceIndex);
  const supplies = points.map(p => p.moneySupply);
  const pMin = Math.min(...prices), pMax = Math.max(...prices);
  const mMin = Math.min(...supplies), mMax = Math.max(...supplies);
  const pRange = (pMax - pMin) || 1;
  const mRange = (mMax - mMin) || 1;
  const pTop = pMax + pRange * 0.15, pBottom = Math.max(0, pMin - pRange * 0.15);

  const x = i => PAD.l + (i / (points.length - 1)) * plotW;
  const yPrice = v => PAD.t + (1 - (v - pBottom) / (pTop - pBottom)) * plotH;
  const yMoney = v => PAD.t + (1 - (v - mMin) / (mMax - mMin || 1)) * plotH;

  // Grid horizontal + label sumbu kiri (indeks harga).
  ctx.strokeStyle = 'rgba(255,255,255,0.06)';
  ctx.fillStyle = '#8a93a6';
  ctx.font = '11px sans-serif';
  ctx.textAlign = 'right';
  for (let g = 0; g <= 4; g++) {
    const gy = PAD.t + (g / 4) * plotH;
    ctx.beginPath(); ctx.moveTo(PAD.l, gy); ctx.lineTo(W - PAD.r, gy); ctx.stroke();
    const val = pBottom + (1 - g / 4) * (pTop - pBottom);
    ctx.fillText(val.toFixed(0), PAD.l - 8, gy + 4);
  }

  // Sumbu kanan: uang beredar (compact).
  ctx.textAlign = 'left';
  for (let g = 0; g <= 4; g++) {
    const gy = PAD.t + (g / 4) * plotH;
    const val = mMin + (1 - g / 4) * mRange;
    ctx.fillText(kizco.compact(val), W - PAD.r + 8, gy + 4);
  }

  // Label sumbu.
  ctx.fillStyle = '#5b6472';
  ctx.font = '10px sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText('Uang beredar (KZC)', W - PAD.r + 8, PAD.t - 10);
  ctx.textAlign = 'right';
  ctx.fillText('Indeks harga', PAD.l - 8, PAD.t - 10);

  // Garis harga (biru) + area fill.
  ctx.beginPath();
  points.forEach((p, i) => i === 0 ? ctx.moveTo(x(i), yPrice(p.priceIndex)) : ctx.lineTo(x(i), yPrice(p.priceIndex)));
  ctx.strokeStyle = '#4f8cff';
  ctx.lineWidth = 2.5;
  ctx.stroke();

  const grad = ctx.createLinearGradient(0, PAD.t, 0, PAD.t + plotH);
  grad.addColorStop(0, 'rgba(79,140,255,0.25)');
  grad.addColorStop(1, 'rgba(79,140,255,0)');
  ctx.lineTo(x(points.length - 1), PAD.t + plotH);
  ctx.lineTo(x(0), PAD.t + plotH);
  ctx.closePath();
  ctx.fillStyle = grad;
  ctx.fill();

  // Garis uang beredar (kuning).
  ctx.beginPath();
  points.forEach((p, i) => i === 0 ? ctx.moveTo(x(i), yMoney(p.moneySupply)) : ctx.lineTo(x(i), yMoney(p.moneySupply)));
  ctx.strokeStyle = '#ffc14d';
  ctx.lineWidth = 2;
  ctx.stroke();

  // Titik terakhir + label nilai.
  const last = points[points.length - 1];
  ctx.fillStyle = '#4f8cff';
  ctx.beginPath(); ctx.arc(x(points.length - 1), yPrice(last.priceIndex), 4, 0, Math.PI * 2); ctx.fill();

  // Label waktu di bawah (pertama & terakhir).
  const fmt = ts => { const d = new Date(ts); return `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`; };
  ctx.fillStyle = '#8a93a6';
  ctx.font = '11px sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText(fmt(points[0].timestamp), PAD.l, H - 12);
  ctx.textAlign = 'right';
  ctx.fillText(fmt(last.timestamp), W - PAD.r, H - 12);

  // Judul.
  ctx.fillStyle = '#e6e9ef';
  ctx.font = 'bold 15px sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText(title, PAD.l, 18);

  // Legend.
  ctx.font = '11px sans-serif';
  ctx.fillStyle = '#4f8cff'; ctx.fillRect(W - PAD.r - 16, 12, 10, 10);
  ctx.fillStyle = '#e6e9ef'; ctx.textAlign = 'right'; ctx.fillText('Indeks harga', W - PAD.r - 30, 21);
  ctx.fillStyle = '#ffc14d'; ctx.fillRect(W - PAD.r - 16, 28, 10, 10);
  ctx.fillStyle = '#e6e9ef'; ctx.fillText('Uang beredar', W - PAD.r - 30, 37);

  return canvas.toBuffer('image/png');
}

// ============================================================================
// GRAFIK HARGA ITEM (ala chart saham/kripto) — satu seri harga per item.
// ============================================================================
function renderItemChart(points, { title = 'Grafik Harga Item', color = '#34d399' } = {}) {
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#0b0e14';
  ctx.fillRect(0, 0, W, H);

  if (!points || points.length < 2) {
    ctx.fillStyle = '#8a93a6';
    ctx.font = '18px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('Belum cukup data harga.', W / 2, H / 2);
    return canvas.toBuffer('image/png');
  }

  const plotW = W - PAD.l - PAD.r;
  const plotH = H - PAD.t - PAD.b;
  const prices = points.map(p => p.price);
  const min = Math.min(...prices), max = Math.max(...prices);
  const range = (max - min) || 1;
  const top = max + range * 0.15, bottom = Math.max(0, min - range * 0.15);

  const x = i => PAD.l + (i / (points.length - 1)) * plotW;
  const y = v => PAD.t + (1 - (v - bottom) / (top - bottom)) * plotH;

  ctx.strokeStyle = 'rgba(255,255,255,0.06)';
  ctx.fillStyle = '#8a93a6';
  ctx.font = '11px sans-serif';
  ctx.textAlign = 'right';
  for (let g = 0; g <= 4; g++) {
    const gy = PAD.t + (g / 4) * plotH;
    ctx.beginPath(); ctx.moveTo(PAD.l, gy); ctx.lineTo(W - PAD.r, gy); ctx.stroke();
    const val = bottom + (1 - g / 4) * (top - bottom);
    ctx.fillText(kizco.compact(val), PAD.l - 8, gy + 4);
  }

  ctx.beginPath();
  points.forEach((p, i) => i === 0 ? ctx.moveTo(x(i), y(p.price)) : ctx.lineTo(x(i), y(p.price)));
  ctx.strokeStyle = color;
  ctx.lineWidth = 2.5;
  ctx.stroke();
  const grad = ctx.createLinearGradient(0, PAD.t, 0, PAD.t + plotH);
  grad.addColorStop(0, color + '44');
  grad.addColorStop(1, color + '00');
  ctx.lineTo(x(points.length - 1), PAD.t + plotH);
  ctx.lineTo(x(0), PAD.t + plotH);
  ctx.closePath();
  ctx.fillStyle = grad;
  ctx.fill();

  const last = points[points.length - 1];
  ctx.fillStyle = color;
  ctx.beginPath(); ctx.arc(x(points.length - 1), y(last.price), 4, 0, Math.PI * 2); ctx.fill();

  const fmt = ts => { const d = new Date(ts); return `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`; };
  ctx.fillStyle = '#8a93a6';
  ctx.font = '11px sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText(fmt(points[0].timestamp), PAD.l, H - 12);
  ctx.textAlign = 'right';
  ctx.fillText(fmt(last.timestamp), W - PAD.r, H - 12);

  ctx.fillStyle = '#e6e9ef';
  ctx.font = 'bold 15px sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText(`${title} • terakhir ${kizco.format(last.price)}`, PAD.l, 18);

  return canvas.toBuffer('image/png');
}

module.exports = { renderPriceChart, renderItemChart };
