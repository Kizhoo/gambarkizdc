const { SlashCommandBuilder } = require('discord.js');
const { getEconomyLeaderboard } = require('../../database/db');
const { baseEmbed } = require('../../utils/embeds');
const kizco = require('../../utils/kizco');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder().setName('ecoleaderboard').setDescription('Lihat 10 orang terkaya Kizco di server ini'),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const top = getEconomyLeaderboard(interaction.guild.id, 10);

    if (top.length === 0) {
      return interaction.reply({ embeds: [baseEmbed().setDescription(t(lang, 'eco.lb.empty'))] });
    }

    const description = top.map((row, i) => {
      const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i + 1}`;
      return `${medal} <@${row.userId}> — **${kizco.format(row.total)}**`;
    }).join('\n');

    return interaction.reply({ embeds: [baseEmbed().setTitle(t(lang, 'eco.lb.title')).setDescription(description)] });
  },
};
