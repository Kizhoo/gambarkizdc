const { EmbedBuilder } = require('discord.js');
const { getGuildConfig } = require('../database/db');
const config = require('../config.json');

module.exports = {
  name: 'guildBanRemove',
  async execute(ban) {
    const cfg = getGuildConfig(ban.guild.id);
    if (!cfg.modLogEnabled || !cfg.logChannel) return;

    const logChannel = ban.guild.channels.cache.get(cfg.logChannel);
    if (!logChannel) return;

    const embed = new EmbedBuilder()
      .setColor(config.successColor)
      .setAuthor({ name: ban.user.tag, iconURL: ban.user.displayAvatarURL() })
      .setTitle('Member Diunban')
      .setFooter({ text: `User ID: ${ban.user.id}`})
      .setTimestamp();
    logChannel.send({ embeds: [embed] }).catch(() => {});
  },
};
