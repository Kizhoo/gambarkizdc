const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  subcommandOf: true,
  data: new SlashCommandBuilder()
    .setName('color')
    .setDescription('Lihat preview warna dari kode hex')
    .addStringOption(o => o.setName('hex').setDescription('Kode warna hex, contoh: ff5733 atau #ff5733').setRequired(true)),
  async execute(interaction) {
    const lang = guildLang(interaction);
    let hex = interaction.options.getString('hex').replace('#', '').trim().toUpperCase();

    if (!/^[0-9A-F]{6}$/.test(hex)) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'color.invalid'))], ephemeral: true });
    }

    const r = parseInt(hex.slice(0, 2), 16);
    const g = parseInt(hex.slice(2, 4), 16);
    const b = parseInt(hex.slice(4, 6), 16);

    const embed = baseEmbed()
      .setColor(`#${hex}`)
      .setTitle(t(lang, 'color.title', { hex }))
      .setThumbnail(`https://singlecolorimage.com/get/${hex}/200x200`)
      .addFields(
        { name: 'HEX', value: `#${hex}`, inline: true },
        { name: 'RGB', value: `${r}, ${g}, ${b}`, inline: true },
      );

    return interaction.reply({ embeds: [embed] });
  },
};
