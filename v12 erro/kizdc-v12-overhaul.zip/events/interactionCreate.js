const { errorEmbed, successEmbed } = require('../utils/embeds');
const { handleTicketButton } = require('../utils/ticketUtil');
const { handleMusicButton } = require('../utils/musicButtonHandler');
const { handleSuggestionButton } = require('../utils/suggestionHandler');
const { handlePanel, handlePanelModal } = require('../utils/panelHandler');
const { handleVoiceMonitorButton } = require('../utils/voiceMonitor');
const { handleCreateButton: handleAiChannelCreate, handleModelSelect: handleAiChannelModel, handleResetButton: handleAiChannelReset, handleDeleteButton: handleAiChannelDelete } = require('../utils/aiChannelHandler');
const registerCommand = require('../commands/utility/register');
const { handleButton: handleWerewolfButton, handleTarget: handleWerewolfTarget } = require('../utils/werewolfGame');
const { getGuildConfig, isRegistered, getUser, registerUser } = require('../database/db');
const { isOwner } = require('../utils/ownerCheck');
const { alertOwner } = require('../utils/errorAlert');
const settings = require('../utils/settings');
const { handleButton: handleEconomyButton } = require('../utils/economyButtons');
const { handleLanguageSelect } = require('../utils/botIntro');
const { t, guildLang } = require('../utils/i18n');

// Discord kadang ngirim event interaction yang SAMA dua kali (gateway reconnect, retry
// jaringan, dll) — bukan karena user klik dua kali. Kalau itu kejadian, handler pertama
// sudah balas (reply/update/deferReply), lalu handler kedua nyoba balas LAGI ke interaction
// yang SAMA -> DiscordAPIError 40060 "Interaction has already been acknowledged". Ini yang
// bikin error itu muncul di command/tombol yang sama sekali tidak berhubungan (quiz, AI
// channel, quest, shop, dll) — bukan bug di masing-masing command, tapi soal duplikasi
// delivery. Dicegat sekali di sini buat semua jenis interaksi, bukan ditambal satu-satu.
const recentInteractionIds = new Set();
function isDuplicateInteraction(interaction) {
  if (recentInteractionIds.has(interaction.id)) return true;
  recentInteractionIds.add(interaction.id);
  setTimeout(() => recentInteractionIds.delete(interaction.id), 20000);
  return false;
}

// Gate command di balik registrasi (kalau diaktifkan di config.json).
function needsRegistration(interaction) {
  if (!settings.get('registration.enabled', false)) return false;
  if (!settings.get('registration.gateAllCommands', false)) return false;
  if (isOwner(interaction.user.id)) return false;
  const exempt = settings.get('registration.exemptCommands', []);
  // Cek nama command utama ATAU subcommand-nya (biar /util ping, /util register tetap exempt)
  const sub = interaction.options?.getSubcommand?.(false) || interaction.commandName;
  if (exempt.includes(interaction.commandName) || exempt.includes(sub)) return false;
  return !isRegistered(interaction.user.id);
}

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {
    if (isDuplicateInteraction(interaction)) {
      console.warn(`[interactionCreate] Interaction duplikat dari Discord diabaikan (id: ${interaction.id}).`);
      return;
    }
    // ===== SLASH COMMAND =====
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;

      // lacak penggunaan command (buat dashboard analitik)
      const { trackCommand } = require('../utils/analytics');
      trackCommand(interaction.commandName);

      // ---- Auto-registrasi: user yang menjalankan command otomatis didaftarkan
      // dengan info default (umur default dari config). Gate "daftar dulu" dinonaktifkan;
      // hanya akun yang DIBLOKIR yang tetap ditolak. ----
      if (settings.get('registration.enabled', false)) {
        const u = getUser(interaction.user.id);
        if (u && u.banned) {
          return interaction.reply({ embeds: [errorEmbed(t(guildLang(interaction), 'common.blocked'))], ephemeral: true });
        }
        if (!u) {
          registerUser(interaction.user.id, interaction.user.username, settings.get('registration.defaultAge', 18));
        }
      }

      // cooldown sederhana per command per user (3 detik default)
      const cooldownKey = `${interaction.commandName}-${interaction.user.id}`;
      const cooldownAmount = (command.cooldown ?? 3) * 1000;
      const now = Date.now();
      const timestamps = client.cooldowns;
      if (timestamps.has(cooldownKey)) {
        const expirationTime = timestamps.get(cooldownKey) + cooldownAmount;
        if (now < expirationTime) {
          const remaining = ((expirationTime - now) / 1000).toFixed(1);
          return interaction.reply({
            embeds: [errorEmbed(t(guildLang(interaction), 'common.cooldown', { sec: remaining }))],
            ephemeral: true,
          });
        }
      }
      timestamps.set(cooldownKey, now);
      setTimeout(() => timestamps.delete(cooldownKey), cooldownAmount);

      try {
        await command.execute(interaction, client);
      } catch (error) {
        if (error?.code === 10062) {
          console.error(`[interactionCreate] Interaction expired untuk command "${interaction.commandName}".`);
          return;
        }
        console.error(`Error di command ${interaction.commandName}:`, error);
        alertOwner(client, error, `Command /${interaction.commandName}`).catch(() => {});
        const payload = { embeds: [errorEmbed(t(guildLang(interaction), 'common.error'))], ephemeral: true };
        try {
          if (interaction.replied || interaction.deferred) await interaction.followUp(payload);
          else await interaction.reply(payload);
        } catch (followUpError) {
          console.error(`[interactionCreate] Gagal kirim pesan error:`, followUpError.message);
        }
      }
      return;
    }

    // ===== AUTOCOMPLETE =====
    if (interaction.isAutocomplete()) {
      const command = client.commands.get(interaction.commandName);
      if (!command || !command.autocomplete) return;
      try { await command.autocomplete(interaction, client); }
      catch (err) { console.error('Autocomplete error: ', err); }
      return;
    }

    // ===== MODAL SUBMIT =====
    if (interaction.isModalSubmit()) {
      try {
        if (interaction.customId.startsWith('pnlmodal:')) return await handlePanelModal(interaction, client);
        if (interaction.customId === 'reg:modal') return await registerCommand.handleModal(interaction, client);
      } catch (error) {
        if (error?.code === 10062) return;
        console.error('[interactionCreate] Modal error:', error);
        alertOwner(client, error, `Modal ${interaction.customId}`).catch(() => {});
        const payload = { embeds: [errorEmbed('Formulir gagal diproses. Silakan coba lagi.')], ephemeral: true };
        if (interaction.replied || interaction.deferred) await interaction.followUp(payload).catch(() => {});
        else await interaction.reply(payload).catch(() => {});
      }
      return;
    }

    // ===== USER SELECT MENU (Werewolf target/vote) =====
    if (interaction.isUserSelectMenu()) {
      try {
        if (interaction.customId.startsWith('ww:target:')) return await handleWerewolfTarget(interaction, client);
      } catch (error) {
        if (error?.code === 10062) return;
        console.error('[interactionCreate] User select error:', error);
        alertOwner(client, error, `UserSelect ${interaction.customId}`).catch(() => {});
        const payload = { embeds: [errorEmbed('Target gagal diproses. Coba pilih kembali.')], ephemeral: true };
        if (interaction.replied || interaction.deferred) await interaction.followUp(payload).catch(() => {});
        else await interaction.reply(payload).catch(() => {});
      }
      return;
    }

    // ===== SELECT MENU (string & channel) =====
    if (interaction.isStringSelectMenu() || interaction.isChannelSelectMenu()) {
      try {
        if (interaction.customId === 'lang:select') return await handleLanguageSelect(interaction, client);
        if (interaction.customId.startsWith('pnl:')) return await handlePanel(interaction, client);
        if (interaction.customId === 'aich:model') return await handleAiChannelModel(interaction, client);
      } catch (error) {
        if (error?.code === 10062) return;
        console.error('[interactionCreate] Select error:', error);
        alertOwner(client, error, `Select ${interaction.customId}`).catch(() => {});
      }
      return;
    }

    // ===== BUTTON =====
    if (interaction.isButton()) {
      try {
        const id = interaction.customId;
        if (id.startsWith('ticket_')) return await handleTicketButton(interaction, client);
        if (id.startsWith('music_')) return await handleMusicButton(interaction, client);
        if (id.startsWith('sug_')) return await handleSuggestionButton(interaction, client);
        if (id.startsWith('pnl:')) return await handlePanel(interaction, client);
        if (id.startsWith('node_')) {
          const nodeCmd = client.commands.get('node');
          if (nodeCmd?.handleButton) return await nodeCmd.handleButton(interaction, client);
        }
        if (id.startsWith('vmon_')) return await handleVoiceMonitorButton(interaction, client);
        if (id.startsWith('reg:')) return await registerCommand.handleButton(interaction, client);
        if (id.startsWith('rpg:')) {
          const rpgCmd = client.commands.get('rpg');
          if (rpgCmd?.handleButton) return await rpgCmd.handleButton(interaction, client);
        }
        if (id.startsWith('ww:')) return await handleWerewolfButton(interaction, client);
        if (id.startsWith('econ:') || id.startsWith('market:')) return await handleEconomyButton(interaction, client);
        if (id === 'aich:create') return await handleAiChannelCreate(interaction, client);
        if (id === 'aich:reset') return await handleAiChannelReset(interaction, client);
        if (id === 'aich:delete') return await handleAiChannelDelete(interaction, client);

        if (id === 'verify_button') {
          const cfg = getGuildConfig(interaction.guild.id);
          if (!cfg.verifyRoleId) return await interaction.reply({ embeds: [errorEmbed('Sistem verifikasi belum di-setup.')], ephemeral: true });
          const role = interaction.guild.roles.cache.get(cfg.verifyRoleId);
          if (!role) return await interaction.reply({ embeds: [errorEmbed('Role verifikasi tidak ditemukan.')], ephemeral: true });
          if (interaction.member.roles.cache.has(role.id)) return await interaction.reply({ embeds: [errorEmbed('Kamu sudah terverifikasi.')], ephemeral: true });
          await interaction.member.roles.add(role).catch(() => {});
          return await interaction.reply({ embeds: [successEmbed(`Verifikasi berhasil! Role ${role} diberikan.`)], ephemeral: true });
        }
      } catch (error) {
        if (error?.code === 10062) { console.error(`[interactionCreate] Button "${interaction.customId}" expired.`); return; }
        console.error(`[interactionCreate] Error di button "${interaction.customId}":`, error);
        alertOwner(client, error, `Button ${interaction.customId}`).catch(() => {});
        const payload = { embeds: [errorEmbed('Tombol gagal diproses. Silakan coba kembali.')], ephemeral: true };
        if (interaction.replied || interaction.deferred) await interaction.followUp(payload).catch(() => {});
        else await interaction.reply(payload).catch(() => {});
      }
    }
  },
};
