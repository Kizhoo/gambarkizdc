const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  subcommandOf: true,
  data: new SlashCommandBuilder()
    .setName('roleinfo')
    .setDescription('Lihat informasi sebuah role')
    .addRoleOption(o => o.setName('role').setDescription('Role yang ingin dilihat').setRequired(true)),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const role = interaction.options.getRole('role');
    const embed = baseEmbed()
      .setTitle(t(lang, 'role.title', { name: role.name }))
      .setColor(role.color || '#2b2d31')
      .addFields(
        { name: 'ID', value: role.id, inline: true },
        { name: t(lang, 'info.color'), value: role.hexColor, inline: true },
        { name: t(lang, 'info.member_count'), value: `${role.members.size}`, inline: true },
        { name: t(lang, 'info.position'), value: `${role.position}`, inline: true },
        { name: 'Mentionable', value: role.mentionable ? t(lang, 'common.yes') : t(lang, 'common.no'), inline: true },
        { name: t(lang, 'info.created'), value: `<t:${Math.floor(role.createdTimestamp / 1000)}:R>`, inline: true },
      );
    return interaction.reply({ embeds: [embed] });
  },
};
