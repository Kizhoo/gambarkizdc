// ============================================================================
// KONTROL WAKTU PER GILIRAN — dipakai bareng oleh chess/tictactoe/connectfour
// ----------------------------------------------------------------------------
// Sebelum papan dimulai, penantang (yang ngetik command) milih batas waktu per
// giliran lewat tombol: 20 Detik, 30 Detik, 1/2/4/5/10 Menit, atau Tanpa Batas
// Waktu (santai, tidak dikejar waktu sama sekali).
//
// Implementasi teknis: dipetakan ke opsi `idle` collector discord.js (reset
// tiap ada interaksi baru) - itu PERSIS artinya "batas waktu per giliran", beda
// dari `time` (total durasi tetap sejak collector dibuat, tidak reset). Kalau
// user pilih "Tanpa Batas Waktu", `idle` tidak dipasang sama sekali - collector
// cuma dibatasi `time` super panjang (6 jam) sekadar jaring pengaman memori,
// bukan batas waktu main yang beneran kerasa ke pemain.
// ============================================================================
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, EmbedBuilder } = require('discord.js');

const TIME_OPTIONS = [
  { label: '20 Detik', ms: 20 * 1000 },
  { label: '30 Detik', ms: 30 * 1000 },
  { label: '1 Menit', ms: 60 * 1000 },
  { label: '2 Menit', ms: 2 * 60 * 1000 },
  { label: '4 Menit', ms: 4 * 60 * 1000 },
  { label: '5 Menit', ms: 5 * 60 * 1000 },
  { label: '10 Menit', ms: 10 * 60 * 1000 },
  { label: 'Tanpa Batas Waktu', ms: null },
];

const SAFETY_CAP_MS = 6 * 60 * 60 * 1000; // jaring pengaman kalau "Tanpa Batas Waktu" dipilih

function buildTimeControlRows(prefix) {
  const rows = [];
  for (let i = 0; i < TIME_OPTIONS.length; i += 4) {
    const row = new ActionRowBuilder();
    TIME_OPTIONS.slice(i, i + 4).forEach((opt, idx) => {
      const n = i + idx;
      row.addComponents(
        new ButtonBuilder()
          .setCustomId(`${prefix}_time_${n}`)
          .setLabel(opt.label)
          .setStyle(opt.ms === null ? ButtonStyle.Primary : ButtonStyle.Secondary),
      );
    });
    rows.push(row);
  }
  return rows;
}

// Tampilkan pemilihan waktu ke pemanggil command (via interaction.reply), tunggu dia klik salah
// satu tombol. Return { ms, label, message } - `message` adalah pesan yang SAMA dipakai untuk
// melanjutkan ke step berikutnya (tantangan / papan game) lewat message.edit(...).
async function pickTimeControl(interaction, { gameTitle, prefix, vsAi = false, opponentTag = null }) {
  const modeLine = vsAi
    ? '🤖 **Mode: Solo vs AI** (opsi `lawan` dikosongkan). Kalau maksudnya main lawan teman, batalkan (biarkan waktu habis / abaikan) lalu ulangi command dan isi opsi `lawan` dengan nama temanmu.'
    : `👥 **Mode: vs Member** — lawan: ${opponentTag}`;
  const embed = new EmbedBuilder()
    .setColor('#5865F2')
    .setTitle(`${gameTitle} — Pilih Batas Waktu`)
    .setDescription(`${modeLine}\n\nPilih batas waktu **per giliran**. Kalau tidak ada yang dipilih dalam 30 detik, default **5 Menit** dipakai.\n\nTombol biru = main santai tanpa dikejar waktu sama sekali.`);
  const message = await interaction.reply({ embeds: [embed], components: buildTimeControlRows(prefix), fetchReply: true });

  const picked = await message.awaitMessageComponent({
    componentType: ComponentType.Button,
    time: 30000,
    filter: (i) => i.user.id === interaction.user.id,
  }).catch(() => null);

  if (!picked) {
    return { ms: 5 * 60 * 1000, label: '5 Menit (default)', message, componentInteraction: null };
  }
  const idx = Number(picked.customId.split('_').pop());
  const opt = TIME_OPTIONS[idx] || TIME_OPTIONS[5];
  return { ms: opt.ms, label: opt.label, message, componentInteraction: picked };
}

// Bangun opsi collector discord.js dari pilihan waktu di atas.
function collectorOptionsFor(ms) {
  const opts = { componentType: ComponentType.Button, time: SAFETY_CAP_MS };
  if (ms != null) opts.idle = ms;
  return opts;
}

module.exports = { TIME_OPTIONS, buildTimeControlRows, pickTimeControl, collectorOptionsFor, SAFETY_CAP_MS };
