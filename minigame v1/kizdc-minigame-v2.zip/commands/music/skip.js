const { SlashCommandBuilder } = require('discord.js');
const { getValidPlayer, safePlayerAction } = require('../../utils/musicGuard');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder().setName('skip').setDescription('Lewati lagu yang sedang diputar'),
  async execute(interaction, client) {
    const lang = guildLang(interaction);
    const player = await getValidPlayer(interaction, client);
    if (!player) return;

    if (player.queue.length === 0) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'music.no_next'))], ephemeral: true });
    }

    const nextTrack = player.queue[0];
    return safePlayerAction(interaction, () => player.skip(), { embeds: [successEmbed(t(lang, 'music.skipped', { t: nextTrack.title }))] });
  },
};
