const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ship')
    .setDescription('Hitung persentase kecocokan dua orang')
    .addUserOption(o => o.setName('user1').setDescription('Orang pertama').setRequired(true))
    .addUserOption(o => o.setName('user2').setDescription('Orang kedua').setRequired(true)),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const user1 = interaction.options.getUser('user1');
    const user2 = interaction.options.getUser('user2');

    const seed = [...`${user1.id}${user2.id}`].reduce((acc, c) => acc + c.charCodeAt(0), 0);
    const percentage = seed % 101;

    const bar = '█'.repeat(Math.round(percentage / 10)) +'░'.repeat(10 - Math.round(percentage / 10));

    let comment;
    if (percentage >= 80) comment = t(lang, 'ship.perfect');
    else if (percentage >= 50) comment = t(lang, 'ship.good');
    else if (percentage >= 20) comment = t(lang, 'ship.ok');
    else comment = t(lang, 'ship.bad');

    const embed = baseEmbed()
      .setTitle('Ship Calculator')
      .setDescription(`${user1} ${user2}\n\n**${percentage}%**\n${bar}\n\n${comment}`);
    return interaction.reply({ embeds: [embed] });
  },
};
