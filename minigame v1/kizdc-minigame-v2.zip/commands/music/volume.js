const { SlashCommandBuilder } = require('discord.js');
const { getValidPlayer, safePlayerAction } = require('../../utils/musicGuard');
const { successEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('volume')
    .setDescription('Atur volume musik (0-100)')
    .addIntegerOption(o => o.setName('persen').setDescription('Volume 0-100').setRequired(true).setMinValue(0).setMaxValue(100)),
  async execute(interaction, client) {
    const lang = guildLang(interaction);
    const player = await getValidPlayer(interaction, client);
    if (!player) return;

    const percent = interaction.options.getInteger('persen');
    return safePlayerAction(interaction, () => player.setVolume(percent), { embeds: [successEmbed(t(lang, 'music.volume_set', { p: percent }))] });
  },
};
