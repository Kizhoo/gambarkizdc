// Handler tombol approve/reject saran + notifikasi DM ke pengusul.
const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { getSuggestion, updateSuggestionStatus } = require('../database/db');
const { errorEmbed, successEmbed } = require('./embeds');
const settings = require('./settings');

async function handleSuggestionButton(interaction, client) {
  // customId: sug_approve_<id> / sug_reject_<id>
  const [, action, idStr] = interaction.customId.split('_');
  const id = parseInt(idStr, 10);

  if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
    return interaction.reply({ embeds: [errorEmbed('Hanya admin (Manage Server) yang bisa approve/reject saran.')], ephemeral: true });
  }

  const suggestion = getSuggestion(id);
  if (!suggestion) {
    return interaction.reply({ embeds: [errorEmbed('Data saran tidak ditemukan (mungkin sudah lama).')], ephemeral: true });
  }
  if (suggestion.status !== 'pending') {
    return interaction.reply({ embeds: [errorEmbed(`Saran ini sudah **${suggestion.status}** sebelumnya.`)], ephemeral: true });
  }

  const approved = action === 'approve';
  const status = approved ? 'approved' : 'rejected';
  updateSuggestionStatus(id, status);

  // Update embed di channel
  const original = interaction.message.embeds[0];
  const updated = EmbedBuilder.from(original)
    .setColor(approved ? settings.get('successColor', '#57F287') : settings.get('errorColor', '#ED4245'))
    .spliceFields(0, 1, { name: 'Status', value: `${approved ? 'Disetujui' : 'Ditolak'} oleh ${interaction.user.tag}` });
  await interaction.update({ embeds: [updated], components: [] }).catch(() => {});

  // DM ke pengusul
  try {
    const user = await client.users.fetch(suggestion.userId);
    const dm = new EmbedBuilder()
      .setColor(approved ? settings.get('successColor', '#57F287') : settings.get('errorColor', '#ED4245'))
      .setTitle(approved ? 'Saran Kamu Disetujui' : 'Saran Kamu Ditolak')
      .setDescription(`Saran kamu di **${interaction.guild.name}**:\n> ${suggestion.content}`)
      .addFields({ name: 'Keputusan', value: `${approved ? 'Disetujui' : 'Ditolak'} oleh ${interaction.user.tag}` })
      .setTimestamp();
    await user.send({ embeds: [dm] });
  } catch (e) {
    // user mungkin DM tertutup — beri tahu admin secara ephemeral
    await interaction.followUp({ embeds: [successEmbed(`Status disimpan. (Tapi gagal DM ke pengusul — DM-nya mungkin tertutup.)`)], ephemeral: true }).catch(() => {});
  }
}

module.exports = { handleSuggestionButton };
