const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { updateGuildConfig } = require('../../database/db');
const { successEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('starboard')
    .setDescription('Kelola fitur starboard server')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub => sub.setName('set').setDescription('Setup starboard (pesan dengan banyak akan dipajang)')
      .addChannelOption(o => o.setName('channel').setDescription('Channel untuk starboard').addChannelTypes(ChannelType.GuildText).setRequired(true))
      .addIntegerOption(o => o.setName('threshold').setDescription('Minimal jumlah (default 3)').setMinValue(1).setMaxValue(50)))
    .addSubcommand(sub => sub.setName('disable').setDescription('Matikan fitur starboard')),

  async execute(interaction) {
    const lang = guildLang(interaction);
    const sub = interaction.options.getSubcommand();

    if (sub === 'set') {
      const channel = interaction.options.getChannel('channel');
      const threshold = interaction.options.getInteger('threshold') || 3;
      updateGuildConfig(interaction.guild.id, { starboardChannelId: channel.id, starboardThreshold: threshold });
      return interaction.reply({ embeds: [successEmbed(t(lang, 'star.set', { channel: `${channel}`, threshold }))] });
    }

    if (sub === 'disable') {
      updateGuildConfig(interaction.guild.id, { starboardChannelId: null });
      return interaction.reply({ embeds: [successEmbed(t(lang, 'star.disable'))] });
    }
  },
};
