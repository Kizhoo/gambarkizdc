// ============================================================================
// /luna — RESEPSIONIS AI GUILD
// ----------------------------------------------------------------------------
// Ngobrol dengan Luna. Dia membaca database yang SAMA dengan web game (status,
// pet, gacha, world boss, menara, lelang, teman) dan bisa melakukan aksi ringan
// (terima quest, alokasi stat, buka skill, pasang item, aktifkan pet, belanja,
// mengajukan promosi rank — ACC tetap di owner). Gameplay inti diarahkan ke web.
// ============================================================================
const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, AttachmentBuilder } = require('discord.js');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { safeDefer } = require('../../utils/interactionHelpers');
const { runLuna } = require('../../utils/lunaAgent');
const { dashboardUrl } = require('../../utils/botIntro');
const { t, guildLang } = require('../../utils/i18n');
const fs = require('fs');
const path = require('path');

const LUNA_AVATAR = path.join(__dirname, '..', '..', 'assets', 'luna-avatar.png');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('luna')
    .setDescription('Bicara dengan Luna, resepsionis AI Guild (cek status, pet, gacha, world boss, quest, promosi, dll)')
    .addStringOption(o => o.setName('pesan').setDescription('Apa yang ingin kamu tanyakan/lakukan?').setRequired(true).setMaxLength(400)),
  cooldown: 4,

  async execute(interaction) {
    const lang = guildLang(interaction);
    const message = interaction.options.getString('pesan');
    if (!(await safeDefer(interaction))) return;
    const ctx = {
      userId: interaction.user.id,
      guildId: interaction.guild.id,
      guild: interaction.guild,
      member: interaction.member,
      client: interaction.client,
      channelId: interaction.channelId,
    };
    try {
      const { reply, steps } = await runLuna(ctx, message);
      const embed = baseEmbed()
        .setColor('#C084FC')
        .setAuthor({ name: t(lang, 'luna.author'), iconURL: interaction.client.user.displayAvatarURL() })
        .setDescription(reply)
        .setFooter({ text: t(lang, 'luna.used', { tools: steps && steps.length ? steps.map(s => s.tool).join(', ') : 'obrolan' }) });
      // Avatar Luna (ilustrasi asli) — thumbnail bila file tersedia.
      const payload = { content: `> ${message.slice(0, 200)}`, embeds: [embed] };
      try {
        if (fs.existsSync(LUNA_AVATAR)) {
          const file = new AttachmentBuilder(LUNA_AVATAR, { name: 'luna.png' });
          embed.setThumbnail('attachment://luna.png');
          payload.files = [file];
        }
      } catch { /* avatar bersifat opsional — jangan gagalkan balasan */ }
      // Tombol pintasan ke web game (main gameplay ada di sana).
      payload.components = [new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setLabel('Buka Web Game')
          .setStyle(ButtonStyle.Link)
          .setURL(`${dashboardUrl().replace(/\/+$/, '')}/rpg`),
      )];
      return interaction.editReply(payload);
    } catch (e) {
      console.error('[luna]', e);
      return interaction.editReply({ embeds: [errorEmbed(t(lang, 'luna.confused', { err: e.message }))] });
    }
  },
};
