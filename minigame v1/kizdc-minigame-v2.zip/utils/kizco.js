// ============================================================================
// KIZCO — SATU MATA UANG UNTUK SEMUA SISTEM
// ----------------------------------------------------------------------------
// Sebelumnya bot punya dua "mata uang" terpisah yang membingungkan:
//   - economy  : "cash" + "bank" (angka bulat, tanpa nama resmi)
//   - RPG      : "gold" + "silver" + "copper" (recehan flavor)
//
// Mulai sekarang SEMUANYA memakai satu mata uang: **Kizco (KZC)**.
// Sumber kebenaran tetap kolom `economy.balance` dan `economy.bank` di DB
// (bank = tabungan Kizco, konsep yang sama dengan rekening di dunia nyata,
// bukan mata uang kedua). Modul ini hanya lapisan tampilan + konstanta,
// jadi TIDAK ada migrasi skala nilai dan nol risiko ke saldo lama.
// ============================================================================
const SYMBOL = 'KZC';
const NAME = 'Kizco';
const DECIMALS = 0; // Kizco disimpan sebagai bilangan bulat (1 KZC = unit terkecil)

// Format standar buat teks embed: "12.500 KZC"
function format(amount, { symbol = true, locale = 'id-ID' } = {}) {
  const n = Math.round(Number(amount) || 0);
  const s = n.toLocaleString(locale);
  return symbol ? `${s} KZC` : s;
}

// Format singkat buat angka besar: 1.2K, 3.4M, 5.6B (berguna buat label grafik).
function compact(amount) {
  const n = Number(amount) || 0;
  const abs = Math.abs(n);
  const sign = n < 0 ? '-' : '';
  if (abs >= 1e9) return `${sign}${(abs / 1e9).toFixed(1)}B`;
  if (abs >= 1e6) return `${sign}${(abs / 1e6).toFixed(1)}M`;
  if (abs >= 1e3) return `${sign}${(abs / 1e3).toFixed(1)}K`;
  return `${sign}${Math.round(abs)}`;
}

// Format persen dengan tanda +/-, mis. "+2.35%" / "-0.80%".
function pct(value, { digits = 2 } = {}) {
  const n = Number(value) || 0;
  const sign = n > 0 ? '+' : '';
  return `${sign}${n.toFixed(digits)}%`;
}

// Konversi jumlah relatif terhadap indeks harga (priceIndex 100 = harga dasar).
// Dipakai buat menghitung harga nominal item / reward yang mengikuti inflasi.
function scaleByPrice(base, priceIndex) {
  const idx = Number(priceIndex) || 100;
  return Math.max(1, Math.round((Number(base) || 0) * (idx / 100)));
}

module.exports = { SYMBOL, NAME, DECIMALS, format, compact, pct, scaleByPrice };
