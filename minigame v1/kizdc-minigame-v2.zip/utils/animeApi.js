// ============================================================================
// ANIME API - client buat AniList GraphQL API (gratis, tanpa API key, tanpa
// batas registrasi). Dipakai buat command /anime dan job auto-update di ready.js.
//
// Sebelumnya pakai Jikan (unofficial MyAnimeList API) tapi sering timeout/504
// karena Jikan cuma proxy yang scraping MAL dan gampang overload. AniList basis
// datanya sendiri (bukan proxy), rate limit 90 req/menit (Jikan cuma 30/menit),
// dan datanya termasuk jam tayang PRESIS per episode (bukan cuma "hari apa").
// Docs: https://docs.anilist.co/  |  Endpoint tunggal: https://graphql.anilist.co (POST)
// ============================================================================
const { fetchExternal } = require('./httpClient');
const settings = require('./settings');

const CACHE_TTL_MS = 10 * 60 * 1000; // 10 menit, cukup buat hemat kuota tanpa bikin data basi
const RETRYABLE_STATUSES = new Set([429, 500, 502, 503, 504]);
const cache = new Map();

function endpoint() {
  return settings.get('anime.aniListEndpoint', 'https://graphql.anilist.co');
}

function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

// Query GraphQL sendiri (bukan lewat publicApi.fetchJson) karena butuh POST + body JSON,
// sementara fetchJson di utils/publicApi.js dirancang buat GET. Retry & cache manual di
// sini meniru pola yang sama (retry status 5xx/429, cache per-query+variabel).
async function queryAniList(query, variables, { ttl = CACHE_TTL_MS, retries = 2, timeout = 10000 } = {}) {
  const cacheKey = JSON.stringify({ query, variables });
  const cached = cache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now()) return cached.value;

  const body = JSON.stringify({ query, variables });
  let lastError;
  for (let attempt = 0; attempt <= retries; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const res = await fetchExternal(endpoint(), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body,
        signal: controller.signal,
      }, 0);
      clearTimeout(timer);

      if (!res.ok) {
        const retryable = RETRYABLE_STATUSES.has(res.status);
        const err = new Error(`API AniList merespons HTTP ${res.status}`);
        if (retryable && attempt < retries) { lastError = err; await sleep(600 * 2 ** attempt); continue; }
        throw err;
      }
      const json = await res.json();
      if (json.errors?.length) throw new Error(json.errors.map(e => e.message).join('; '));
      if (ttl > 0) cache.set(cacheKey, { value: json.data, expiresAt: Date.now() + ttl });
      return json.data;
    } catch (err) {
      clearTimeout(timer);
      lastError = err;
      if (attempt === retries) throw err;
      await sleep(600 * 2 ** attempt);
    }
  }
  throw lastError || new Error('Request ke AniList gagal');
}

const MEDIA_FIELDS = `
  id
  idMal
  title { romaji english }
  coverImage { large color }
  bannerImage
  episodes
  averageScore
  genres
  siteUrl
  status
  format
  isAdult
  externalLinks { url site type }
  description(asHtml: false)
`;

// Situs streaming resmi yang umum dipakai di Asia Tenggara/Indonesia - dipakai buat urutin
// link streaming biar yang paling relevan buat penonton Indonesia tampil duluan.
const STREAMING_PRIORITY = ['crunchyroll', 'netflix', 'muse', 'ani-one', 'bilibili', 'vidio', 'iqiyi', 'wetv', 'disney', 'hidive', 'funimation', 'prime video'];

function stripHtml(text) {
  if (!text) return null;
  return text.replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]+>/g, '').trim();
}

function extractStreamingLinks(externalLinks) {
  const links = (externalLinks || [])
    .filter(l => l.type === 'STREAMING' && l.url && l.site)
    .map(l => ({ site: l.site, url: l.url }));
  links.sort((a, b) => {
    const pa = STREAMING_PRIORITY.findIndex(s => a.site.toLowerCase().includes(s));
    const pb = STREAMING_PRIORITY.findIndex(s => b.site.toLowerCase().includes(s));
    return (pa === -1 ? 99 : pa) - (pb === -1 ? 99 : pb);
  });
  return links.slice(0, 5);
}

function normalizeAnime(m) {
  if (!m) return null;
  return {
    malId: m.idMal ?? m.id, // fallback ke id AniList kalau idMal kosong (anime yg belum ke-link ke MAL)
    url: m.siteUrl,
    title: m.title?.english || m.title?.romaji || 'Tanpa judul',
    titleNative: m.title?.romaji || null,
    image: m.coverImage?.large || null,
    bannerImage: m.bannerImage || null,
    color: m.coverImage?.color || null,
    episodes: m.episodes ?? null,
    score: m.averageScore != null ? Math.round(m.averageScore) / 10 : null, // AniList skala 0-100 -> disamakan ke skala 0-10 spt MAL
    genres: Array.isArray(m.genres) ? m.genres : [],
    broadcast: null, // diisi terpisah kalau datang dari airing schedule (lihat getTodaySchedule)
    synopsis: stripHtml(m.description),
    status: m.status || null,
    streamingLinks: extractStreamingLinks(m.externalLinks),
  };
}

// "Jadwal hari ini" sekarang berarti "episode yang tayang dalam 24 jam ke depan", lebih presisi
// daripada daftar hari-siaran mingguan - dapat jam & nomor episode pasti, bukan cuma "Minggu".
async function getTodaySchedule({ limit = 15 } = {}) {
  const query = `
    query ($start: Int, $end: Int, $perPage: Int) {
      Page(page: 1, perPage: $perPage) {
        airingSchedules(airingAt_greater: $start, airingAt_lesser: $end, sort: TIME) {
          airingAt
          episode
          media { ${MEDIA_FIELDS} }
        }
      }
    }
  `;
  const now = Math.floor(Date.now() / 1000);
  const data = await queryAniList(query, { start: now, end: now + 86400, perPage: limit });
  const schedules = data?.Page?.airingSchedules || [];
  const anime = schedules.map(s => {
    const item = normalizeAnime(s.media);
    if (!item) return null;
    const airDate = new Date(s.airingAt * 1000);
    item.broadcast = `Episode ${s.episode} • ${airDate.toLocaleString('id-ID', { weekday: 'long', hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Jakarta' })} WIB`;
    return item;
  }).filter(Boolean);
  return { windowHours: 24, anime };
}

async function getCurrentSeason({ limit = 15, page = 1 } = {}) {
  const now = new Date();
  const month = now.getMonth() + 1;
  const season = month <= 3 ? 'WINTER' : month <= 6 ? 'SPRING' : month <= 9 ? 'SUMMER' : 'FALL';
  const seasonYear = now.getFullYear();

  const query = `
    query ($season: MediaSeason, $seasonYear: Int, $page: Int, $perPage: Int) {
      Page(page: $page, perPage: $perPage) {
        pageInfo { hasNextPage }
        media(season: $season, seasonYear: $seasonYear, type: ANIME, sort: POPULARITY_DESC, status: RELEASING) {
          ${MEDIA_FIELDS}
        }
      }
    }
  `;
  const data = await queryAniList(query, { season, seasonYear, page, perPage: limit });
  return {
    season, seasonYear,
    anime: (data?.Page?.media || []).map(normalizeAnime).filter(Boolean),
    hasNextPage: !!data?.Page?.pageInfo?.hasNextPage,
  };
}

async function searchAnime(query, { limit = 5 } = {}) {
  const gql = `
    query ($search: String, $perPage: Int) {
      Page(page: 1, perPage: $perPage) {
        media(search: $search, type: ANIME) { ${MEDIA_FIELDS} }
      }
    }
  `;
  const data = await queryAniList(gql, { search: query, perPage: limit });
  return (data?.Page?.media || []).map(normalizeAnime).filter(Boolean);
}

// Semua episode (bukan cuma episode 1) yang tayang dalam jendela waktu sempit - dipakai job
// auto-alert "episode baru" biar notifikasinya satu-satu sesuai jam tayang beneran, bukan
// digabung jadi satu batch. Difilter TV-only & non-adult biar gak kebanjiran OVA/movie/musik.
async function getUpcomingEpisodes({ windowMinutes = 30, perPage = 50 } = {}) {
  const query = `
    query ($start: Int, $end: Int, $perPage: Int) {
      Page(page: 1, perPage: $perPage) {
        airingSchedules(airingAt_greater: $start, airingAt_lesser: $end, sort: TIME) {
          airingAt
          episode
          media { ${MEDIA_FIELDS} }
        }
      }
    }
  `;
  const now = Math.floor(Date.now() / 1000);
  const data = await queryAniList(query, { start: now, end: now + windowMinutes * 60, perPage }, { ttl: 60000 });
  const schedules = data?.Page?.airingSchedules || [];
  return schedules
    .filter(s => s.media && s.media.format === 'TV' && !s.media.isAdult)
    .map(s => {
      const item = normalizeAnime(s.media);
      if (!item) return null;
      const airDate = new Date(s.airingAt * 1000);
      item.episode = s.episode;
      item.broadcast = `${s.episode === 1 ? 'Episode Perdana' : `Episode ${s.episode}`} • ${airDate.toLocaleString('id-ID', { weekday: 'long', hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Jakarta' })} WIB`;
      return item;
    }).filter(Boolean);
}

module.exports = { getTodaySchedule, getCurrentSeason, getUpcomingEpisodes, searchAnime, normalizeAnime };
