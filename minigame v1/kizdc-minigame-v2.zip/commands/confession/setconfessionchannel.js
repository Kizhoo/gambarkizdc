const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { updateGuildConfig } = require('../../database/db');
const { successEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setconfessionchannel')
    .setDescription('[Admin] Atur channel untuk confession anonim')
    .addChannelOption(o => o.setName('channel').setDescription('Channel confession').addChannelTypes(ChannelType.GuildText).setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const channel = interaction.options.getChannel('channel');
    updateGuildConfig(interaction.guild.id, { confessionChannelId: channel.id });
    return interaction.reply({ embeds: [successEmbed(t(lang, 'confess.channel_set', { channel: `${channel}` }))] });
  },
};
