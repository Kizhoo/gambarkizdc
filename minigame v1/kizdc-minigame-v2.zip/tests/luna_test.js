// ============================================================================
// LUNA TOOL TEST — verifikasi tool Luna pasca-penghapusan RPG
// ----------------------------------------------------------------------------
// Fokus: tool minigame (minigame_status / minigame_leaderboard), tool level
// terunifikasi (check_level / set_user_level), inventaris pasar, tool economy,
// dan tool RPG lama benar-benar hilang dari katalog.
// ============================================================================
process.env.KIZHOO_DB_PATH = '/tmp/kiz_luna_test.sqlite';
require('fs').rmSync('/tmp/kiz_luna_test.sqlite', { force: true });

const webDb = require('../database/webDb');
const levelEngine = require('../utils/levelEngine');
const { TOOLS, toolCatalog } = require('../utils/lunaAgent');
const { updateBalance, getEconomy } = require('../database/db');

let pass = 0, fail = 0;
const ok = (cond, label) => { if (cond) { pass++; console.log('  OK', label); } else { fail++; console.log('  FAIL', label); } };
const ctx = { userId: 'u1', guildId: 'g1', guild: { id: 'g1', name: 'Guild Tes' } };

console.log('== 1. Tool RPG lama hilang ==');
for (const dead of ['get_status', 'check_promotion', 'request_promotion', 'list_quests', 'accept_quest', 'allocate_stat', 'list_shop', 'buy_item', 'equip_item', 'unlock_skill', 'unequip_item', 'item_info', 'rank_ladder', 'class_info', 'quest_progress', 'pet_collection', 'pet_activate', 'gacha_info', 'worldboss_info', 'tower_info', 'auction_info', 'friends_list']) {
  ok(!TOOLS[dead], 'tool ' + dead + ' sudah dihapus');
}

console.log('== 2. Tool baru & yang dipertahankan ada ==');
for (const alive of ['minigame_status', 'minigame_leaderboard', 'check_level', 'level_leaderboard', 'check_balance', 'web_game_link', 'inventory_list', 'server_info', 'calculate', 'bot_ping']) {
  ok(!!TOOLS[alive], 'tool ' + alive + ' tersedia');
}

console.log('== 3. web_game_link menunjuk /minigame ==');
const link = TOOLS.web_game_link.run(ctx, {});
ok(/\/minigame$/.test(link.url), 'URL: ' + link.url);
ok(!/\/rpg/.test(link.url), 'tidak lagi menunjuk /rpg');

console.log('== 4. Level terunifikasi ==');
const lv0 = TOOLS.check_level.run(ctx, {});
ok(lv0.level === 1 && lv0.xp === 0, 'user baru mulai level 1');
levelEngine.addExp('u1', 9999, 'g1');
const lv1 = TOOLS.check_level.run(ctx, {});
ok(lv1.level > 1, 'setelah addExp level naik: ' + lv1.level);
ok(lv1.xpNeeded > 0, 'XP requirement terhitung: ' + lv1.xpNeeded);

console.log('== 5. Tool minigame ==');
const st0 = TOOLS.minigame_status.run(ctx, {});
ok(st0.played === false, 'belum main -> played:false (ada hint arahkan /minigame)');
webDb.saveProgress('u1', { wave: 12, bestWave: 14, coins: 500, totalKills: 130, turrets: { 0: { tier: 2, dmg: 1, rate: 0, range: 0 }, 3: { tier: 1, dmg: 0, rate: 0, range: 0 } } });
const st1 = TOOLS.minigame_status.run(ctx, {});
ok(st1.played !== false && st1.bestWave === 14, 'progres terbaca: rekor gelombang ' + st1.bestWave);
ok(st1.turretCount === 2, 'menara terpasang terhitung: ' + st1.turretCount);
ok(st1.claimEstimateKizco === 350, 'estimasi klaim 14x25=350: ' + st1.claimEstimateKizco);
webDb.saveProgress('u2', { wave: 9, bestWave: 22, coins: 10, totalKills: 240 });
const lb = TOOLS.minigame_leaderboard.run(ctx, {});
ok(lb.list.length === 2 && lb.list[0].bestWave >= lb.list[1].bestWave, 'leaderboard terurut');

console.log('== 6. Inventaris pasar ==');
webDb.addItem('u1', 'w_rusty', 3);
webDb.addItem('u1', 'p_heal', 2);
const inv = TOOLS.inventory_list.run(ctx, {});
ok(inv.count === 2, 'inventaris terbaca: ' + inv.count + ' jenis');
ok(inv.items.some((i) => i.itemId === 'w_rusty' && i.qty === 3), 'item w_rusty x3 ada');
ok(inv.items.every((i) => typeof i.name === 'string' && i.name), 'nama item ter-resolve dari katalog');

console.log('== 7. Economy ==');
updateBalance('g1', 'u1', 500);
const bal = TOOLS.check_balance.run(ctx, {});
ok(bal.cash === 500, 'saldo terbaca: ' + bal.cash);

console.log('== 8. Katalog tool (untuk system prompt) ==');
const cat = toolCatalog({ userId: 'u1', guildId: 'g1' });
ok(/minigame_status/.test(cat), 'katalog memuat minigame_status');
ok(!/\bget_status\b/.test(cat), 'katalog TIDAK memuat get_status lama');

console.log('\n==== HASIL LUNA: ' + pass + ' lulus, ' + fail + ' gagal ====');
process.exitCode = fail ? 1 : 0;
