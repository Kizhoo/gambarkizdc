// Test fokus: fix tombol Terima teman + guild switcher header.
// GET /api/rpg/friends harus mengembalikan requests[].userId = ID PENGIRIM
// (dulu: ID sendiri -> tombol Terima selalu ditolak server).
process.env.KIZHOO_DB_PATH = '/tmp/kiz_friend_test.sqlite';
require('fs').rmSync('/tmp/kiz_friend_test.sqlite', { force: true });
const express = require('express');
const http = require('http');
const rpgDb = require('../database/rpgDb');
const { mountRpg } = require('../utils/rpgServer');

const app = express();
app.use(express.json());
const sessions = {};
const auth = (req, res, next) => {
  const sid = String(req.headers.cookie || '').replace(/.*kz_sid=([^;]*).*/, '$1');
  if (sessions[sid]) { req.session = sessions[sid]; return next(); }
  return res.status(401).json({ error: 'belum login' });
};
const resolveUserId = (req) => (req.session && req.session.userId) || null;
const client = { guilds: { cache: new Map() }, users: { cache: new Map(), fetch: async () => null } };
client.guilds.cache.set('g1', { id: 'g1', name: 'Server Satu' });
client.guilds.cache.set('g2', { id: 'g2', name: 'Server Dua' });
mountRpg(app, { auth, resolveUserId, client });

const server = http.createServer(app);
server.listen(0, async () => {
  const port = server.address().port;
  const base = 'http://127.0.0.1:' + port;
  let pass = 0, fail = 0;
  const ok = (c, m) => { if (c) { pass++; console.log('  OK', m); } else { fail++; console.log('  FAIL', m); } };

  const mk = (sid, userId, username, guilds) => {
    sessions[sid] = { userId, username, avatar: null, guilds };
    rpgDb.saveSession(sid, sessions[sid]);
    return { 'Content-Type': 'application/json', Cookie: 'kz_sid=' + sid };
  };
  const HA = mk('sidA', '111', 'alfa', [{ id: 'g1', name: 'Server Satu' }, { id: 'g2', name: 'Server Dua' }]);
  const HB = mk('sidB', '222', 'bravo', [{ id: 'g2', name: 'Server Dua' }]);
  const POST = (h, p, b) => fetch(base + p, { method: 'POST', headers: h, body: JSON.stringify(b || {}) }).then(r => r.json());
  const GET = (h, p) => fetch(base + p, { headers: h }).then(r => r.json());

  // Siapkan karakter kedua user.
  await POST(HA, '/api/rpg/class', { classKey: 'warrior' });
  await POST(HB, '/api/rpg/class', { classKey: 'mage' });

  // 1. Alfa mengajak bravo.
  const meA = await GET(HA, '/api/rpg/me');
  let r = await POST(HA, '/api/rpg/friends/add', { query: meA.char ? '' : '' });
  const fidB = (await GET(HB, '/api/rpg/me')).char.friendId;
  r = await POST(HA, '/api/rpg/friends/add', { query: fidB });
  ok(r && r.ok && r.status === 'pending', 'alfa mengirim permintaan ke bravo (via friendId)');

  // 2. GET friends sebagai bravo: requests[].userId HARUS id alfa (111).
  r = await GET(HB, '/api/rpg/friends');
  ok(r.requests && r.requests.length === 1, 'bravo melihat 1 permintaan masuk');
  ok(r.requests[0].userId === '111', 'requests[].userId = ID PENGIRIM (111), dapat: ' + (r.requests[0] && r.requests[0].userId));

  // 3. Tombol Terima (klien memakai requests[].userId) -> harus berhasil.
  r = await POST(HB, '/api/rpg/friends/accept', { userId: r.requests[0].userId });
  ok(r && r.ok, 'accept dengan userId pengirim BERHASIL');

  // 4. Verifikasi jadi teman dua arah.
  r = await GET(HB, '/api/rpg/friends');
  ok(r.friends.length === 1 && r.friends[0].userId === '111', 'bravo berteman dengan alfa');
  r = await GET(HA, '/api/rpg/friends');
  ok(r.friends.length === 1 && r.friends[0].userId === '222', 'alfa berteman dengan bravo (dua arah)');

  // 5. Guild switcher: saldo per-server via header X-RPG-Guild.
  rpgDb.addGold('111', 'g1', 1000);
  rpgDb.addGold('111', 'g2', 7000);
  const meG1 = await GET(HA, '/api/rpg/me');
  ok(meG1.char.gold === 1000, 'tanpa header: guild pertama (g1) saldo 1000, dapat ' + meG1.char.gold);
  const meG2 = await fetch(base + '/api/rpg/me', { headers: { ...HA, 'X-RPG-Guild': 'g2' } }).then(x => x.json());
  ok(meG2.char.gold === 7000, 'header X-RPG-Guild=g2: saldo 7000, dapat ' + meG2.char.gold);
  const meGx = await fetch(base + '/api/rpg/me', { headers: { ...HA, 'X-RPG-Guild': 'g9' } }).then(x => x.json());
  ok(meGx.char.gold === 1000, 'header guild tidak mutual (g9) ditolak -> fallback g1');

  console.log('\n==== HASIL FRIEND+GUILD: ' + pass + ' lulus, ' + fail + ' gagal ====');
  process.exit(fail ? 1 : 0);
});
