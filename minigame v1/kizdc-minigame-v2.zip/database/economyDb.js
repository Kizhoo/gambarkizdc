// ============================================================================
// DATA LAYER EKONOMI KIZCO — state makro, riwayat harga, transaksi, AI log,
// dan tawaran trading. Semua tabel diprefix `econ_`.
//
// Pakai koneksi better-sqlite3 yang SAMA dari database/db.js (satu file DB,
// jadi ikut ke-backup otomatis). Modul ini TIDAK memuat ulang koneksi baru.
// ============================================================================
const { db } = require('./db');

db.exec(`
-- State makroekonomi per server (satu baris per guild).
CREATE TABLE IF NOT EXISTS econ_state (
  guildId TEXT PRIMARY KEY,
  treasury INTEGER NOT NULL DEFAULT 0,          -- KZC yang "ditahan" sistem (belum dihancurkan/dikembalikan)
  priceIndex REAL NOT NULL DEFAULT 100.0,       -- level harga umum (100 = baseline)
  inflationRate REAL NOT NULL DEFAULT 0.0,      -- inflasi/deflasi per siklus (desimal, 0.02 = +2%)
  moneySupply INTEGER NOT NULL DEFAULT 0,       -- snapshot M = total dompet + bank (sirkulasi)
  totalMinted INTEGER NOT NULL DEFAULT 0,       -- kumulatif KZC yang pernah dicetak (creation)
  totalBurned INTEGER NOT NULL DEFAULT 0,       -- kumulatif KZC yang dihancurkan (sink)
  rewardMultiplier REAL NOT NULL DEFAULT 1.0,   -- pengali reward (kebijakan moneter AI)
  taxRate REAL NOT NULL DEFAULT 0.05,           -- pajak penghasilan (0.05 = 5%)
  bankInterestRate REAL NOT NULL DEFAULT 0.02,  -- bunga simpanan bank per siklus (desimal)
  policyRate REAL NOT NULL DEFAULT 3.0,         -- suku bunga acuan (Taylor-rule, %/tahun utk display)
  phase TEXT NOT NULL DEFAULT 'expansion',      -- expansion|peak|recession|recovery
  health INTEGER NOT NULL DEFAULT 70,           -- skor kesehatan ekonomi 0-100
  cycle INTEGER NOT NULL DEFAULT 0,             -- jumlah siklus yang sudah dijalankan
  lastActivity INTEGER NOT NULL DEFAULT 0,      -- jumlah transaksi produktif di jendela terakhir
  lastTickAt INTEGER NOT NULL DEFAULT 0
);

-- Riwayat harga (satu titik per siklus) — dipakai grafik & analisis tren.
CREATE TABLE IF NOT EXISTS econ_price_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT NOT NULL,
  timestamp INTEGER NOT NULL,
  priceIndex REAL NOT NULL,
  moneySupply INTEGER NOT NULL,
  inflationRate REAL NOT NULL,
  phase TEXT NOT NULL,
  rewardMultiplier REAL NOT NULL,
  taxRate REAL NOT NULL,
  bankInterestRate REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_econ_price_guild ON econ_price_history (guildId, id);

-- Buku besar transaksi (creation/transfer/sink) — feed real-time dashboard + metrik aktivitas.
CREATE TABLE IF NOT EXISTS econ_transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT NOT NULL,
  timestamp INTEGER NOT NULL,
  type TEXT NOT NULL,        -- daily|work|quest|hunt|levelup|pay|rob|fine|bank|purchase|sell|trade|tax|interest|qe|reward
  actorId TEXT,              -- user pelaku (opsional)
  targetId TEXT,             -- user lawan (opsional)
  amount INTEGER NOT NULL,   -- KZC (positif = creation/credit, negatif = sink/debit)
  note TEXT
);
CREATE INDEX IF NOT EXISTS idx_econ_tx_guild ON econ_transactions (guildId, id);

-- Catatan keputusan AI ekonom (audit trail + feed "market report").
CREATE TABLE IF NOT EXISTS econ_ai_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT NOT NULL,
  timestamp INTEGER NOT NULL,
  decision TEXT NOT NULL,    -- ringkasan keputusan (kebijakan yang diambil)
  policyJson TEXT,           -- detail kebijakan (JSON)
  reasoning TEXT             -- alasan singkat
);
CREATE INDEX IF NOT EXISTS idx_econ_ai_guild ON econ_ai_log (guildId, id);

-- Katalog item toko otomatis (AI-managed): basePrice = harga pada priceIndex 100.
CREATE TABLE IF NOT EXISTS econ_shop_meta (
  guildId TEXT NOT NULL,
  itemId TEXT NOT NULL,
  basePrice INTEGER NOT NULL,
  demandScore REAL NOT NULL DEFAULT 0.0,  -- skor permintaan (dari riwayat pembelian)
  stock INTEGER NOT NULL DEFAULT 0,       -- stok (opsional, -1 = tak terbatas)
  category TEXT,                          -- category kebutuhan (konsumsi/potongan/boost/dll)
  lastSoldAt INTEGER DEFAULT 0,
  aiManaged INTEGER NOT NULL DEFAULT 1,   -- 1 = dikelola AI, 0 = manual admin
  PRIMARY KEY (guildId, itemId)
);

-- Tawaran trading antar pemain (P2P).
CREATE TABLE IF NOT EXISTS econ_trades (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT NOT NULL,
  fromUserId TEXT NOT NULL,
  toUserId TEXT NOT NULL,
  kizco INTEGER NOT NULL DEFAULT 0,       -- KZC yang ditawarkan dari fromUser ke toUser
  itemIds TEXT NOT NULL DEFAULT '[]',     -- JSON array itemId RPG yang ikut ditawarkan
  itemQtys TEXT NOT NULL DEFAULT '[]',    -- JSON array qty (sejajar itemIds)
  status TEXT NOT NULL DEFAULT 'pending', -- pending|accepted|declined|cancelled
  createdAt INTEGER NOT NULL,
  resolvedAt INTEGER
);
CREATE INDEX IF NOT EXISTS idx_econ_trades_user ON econ_trades (guildId, toUserId);

-- Listing jual-beli item antar pemain (marketplace P2P).
CREATE TABLE IF NOT EXISTS econ_listings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT NOT NULL,
  sellerId TEXT NOT NULL,
  itemId TEXT NOT NULL,
  qty INTEGER NOT NULL DEFAULT 1,
  pricePerUnit INTEGER NOT NULL,   -- harga KZC per unit
  status TEXT NOT NULL DEFAULT 'open', -- open|sold|cancelled
  createdAt INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_econ_listings_guild ON econ_listings (guildId, status);

-- Riwayat harga per item (buat grafik trading ala saham/kripto).
CREATE TABLE IF NOT EXISTS econ_item_prices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT NOT NULL,
  itemId TEXT NOT NULL,
  timestamp INTEGER NOT NULL,
  price INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_econ_item_prices ON econ_item_prices (guildId, itemId, id);

-- Order book (limit/market orders) buat web trading profesional.
CREATE TABLE IF NOT EXISTS econ_orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT NOT NULL,
  userId TEXT NOT NULL,
  itemId TEXT NOT NULL,
  side TEXT NOT NULL,          -- buy|sell
  type TEXT NOT NULL,          -- limit|market
  price INTEGER NOT NULL DEFAULT 0,
  qty INTEGER NOT NULL,
  filledQty INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'open', -- open|filled|cancelled
  createdAt INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_econ_orders_open ON econ_orders (guildId, itemId, side, status);

-- Riwayat transaksi yang terjadi (fill) — buat ticker "trades terbaru".
CREATE TABLE IF NOT EXISTS econ_fills (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT NOT NULL,
  itemId TEXT NOT NULL,
  buyerId TEXT NOT NULL,
  sellerId TEXT NOT NULL,
  price INTEGER NOT NULL,
  qty INTEGER NOT NULL,
  amount INTEGER NOT NULL,
  timestamp INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_econ_fills ON econ_fills (guildId, itemId, id);

-- Katalog item DINAMIS (AI-managed). Bisa bertambah/menghilang seiring waktu.
CREATE TABLE IF NOT EXISTS econ_items (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'consumable', -- equip|consumable
  basePrice INTEGER NOT NULL DEFAULT 10,
  effectJson TEXT DEFAULT '{}',
  desc TEXT DEFAULT '',
  emoji TEXT DEFAULT '📦',
  minRank TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  aiGenerated INTEGER NOT NULL DEFAULT 0,
  createdAt INTEGER NOT NULL
);

-- Alert harga (price alert) buat web trading.
CREATE TABLE IF NOT EXISTS econ_alerts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT NOT NULL,
  userId TEXT NOT NULL,
  itemId TEXT NOT NULL,
  direction TEXT NOT NULL, -- above|below
  price INTEGER NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  createdAt INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_econ_alerts ON econ_alerts (guildId, itemId, active);

-- Mutasi rekening Bank (deposit/withdraw/bunga) — buat laporan rekening per user.
CREATE TABLE IF NOT EXISTS econ_bank_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT NOT NULL,
  userId TEXT NOT NULL,
  type TEXT NOT NULL, -- deposit|withdraw|interest
  amount INTEGER NOT NULL,
  note TEXT,
  timestamp INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_econ_bank_log ON econ_bank_log (guildId, userId, id);
`);

const now = () => Date.now();

// Auto-migrasi kolom `tier` & `class` (untuk senjata per-class dengan tier/raritas).
(function ensureItemTierColumns() {
  const cols = db.prepare('PRAGMA table_info(econ_items)').all().map(c => c.name);
  if (!cols.includes('tier')) db.exec('ALTER TABLE econ_items ADD COLUMN tier TEXT');
  if (!cols.includes('class')) db.exec('ALTER TABLE econ_items ADD COLUMN class TEXT');
})();

// ---------------- STATE ----------------
function getState(guildId) {
  let row = db.prepare('SELECT * FROM econ_state WHERE guildId = ?').get(guildId);
  if (!row) {
    db.prepare('INSERT INTO econ_state (guildId) VALUES (?)').run(guildId);
    row = db.prepare('SELECT * FROM econ_state WHERE guildId = ?').get(guildId);
  }
  return row;
}
function updateState(guildId, fields) {
  getState(guildId);
  const keys = Object.keys(fields);
  if (!keys.length) return getState(guildId);
  const setClause = keys.map(k => `${k} = @${k}`).join(', ');
  db.prepare(`UPDATE econ_state SET ${setClause} WHERE guildId = @guildId`).run({ guildId, ...fields });
  return getState(guildId);
}

// ---------------- RIWAYAT HARGA ----------------
function addPricePoint(guildId, p) {
  db.prepare(`INSERT INTO econ_price_history
    (guildId, timestamp, priceIndex, moneySupply, inflationRate, phase, rewardMultiplier, taxRate, bankInterestRate)
    VALUES (@guildId, @timestamp, @priceIndex, @moneySupply, @inflationRate, @phase, @rewardMultiplier, @taxRate, @bankInterestRate)`)
    .run({
      guildId, timestamp: p.timestamp || now(),
      priceIndex: p.priceIndex, moneySupply: p.moneySupply, inflationRate: p.inflationRate,
      phase: p.phase, rewardMultiplier: p.rewardMultiplier, taxRate: p.taxRate, bankInterestRate: p.bankInterestRate,
    });
}
function getPriceHistory(guildId, limit = 100) {
  return db.prepare('SELECT * FROM econ_price_history WHERE guildId = ? ORDER BY id DESC LIMIT ?').all(guildId, limit).reverse();
}
function getLastPricePoint(guildId) {
  return db.prepare('SELECT * FROM econ_price_history WHERE guildId = ? ORDER BY id DESC LIMIT 1').get(guildId) || null;
}

// ---------------- TRANSAKSI ----------------
function recordTransaction(guildId, { type, actorId = null, targetId = null, amount = 0, note = null } = {}) {
  return db.prepare('INSERT INTO econ_transactions (guildId, timestamp, type, actorId, targetId, amount, note) VALUES (?, ?, ?, ?, ?, ?, ?)')
    .run(guildId, now(), type, actorId, targetId, Math.round(Number(amount) || 0), note);
}
function getTransactions(guildId, limit = 50) {
  return db.prepare('SELECT * FROM econ_transactions WHERE guildId = ? ORDER BY id DESC LIMIT ?').all(guildId, limit);
}
function countProductiveTransactions(guildId, sinceMs) {
  const PRODUCTIVE = ['daily', 'work', 'quest', 'hunt', 'levelup', 'purchase', 'sell', 'trade'];
  const placeholders = PRODUCTIVE.map(() => '?').join(',');
  const row = db.prepare(`SELECT COUNT(*) AS c FROM econ_transactions WHERE guildId = ? AND timestamp >= ? AND type IN (${placeholders})`)
    .get(guildId, sinceMs, ...PRODUCTIVE);
  return row.c;
}

// ---------------- LOG AI ----------------
function addAiLog(guildId, { decision, policyJson = null, reasoning = null } = {}) {
  return db.prepare('INSERT INTO econ_ai_log (guildId, timestamp, decision, policyJson, reasoning) VALUES (?, ?, ?, ?, ?)')
    .run(guildId, now(), decision, policyJson ? JSON.stringify(policyJson) : null, reasoning);
}
function getAiLog(guildId, limit = 20) {
  return db.prepare('SELECT * FROM econ_ai_log WHERE guildId = ? ORDER BY id DESC LIMIT ?').all(guildId, limit);
}

// ---------------- SHOP META ----------------
function getShopMeta(guildId, itemId) {
  return db.prepare('SELECT * FROM econ_shop_meta WHERE guildId = ? AND itemId = ?').get(guildId, itemId) || null;
}
function setShopMeta(guildId, itemId, fields) {
  const existing = getShopMeta(guildId, itemId);
  if (!existing) {
    db.prepare(`INSERT INTO econ_shop_meta (guildId, itemId, basePrice, demandScore, stock, category, aiManaged, lastSoldAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, 0)`)
      .run(guildId, itemId, fields.basePrice ?? 0, fields.demandScore ?? 0, fields.stock ?? 0, fields.category ?? null, fields.aiManaged ?? 1);
  }
  const keys = Object.keys(fields);
  if (keys.length) {
    const setClause = keys.map(k => `${k} = @${k}`).join(', ');
    db.prepare(`UPDATE econ_shop_meta SET ${setClause} WHERE guildId = @guildId AND itemId = @itemId`).run({ guildId, itemId, ...fields });
  }
  return getShopMeta(guildId, itemId);
}
function bumpDemand(guildId, itemId, amount = 1) {
  const meta = getShopMeta(guildId, itemId);
  if (!meta) return;
  db.prepare('UPDATE econ_shop_meta SET demandScore = demandScore + ?, lastSoldAt = ? WHERE guildId = ? AND itemId = ?')
    .run(amount, now(), guildId, itemId);
}
function getAllShopMeta(guildId) {
  return db.prepare('SELECT * FROM econ_shop_meta WHERE guildId = ?').all(guildId);
}

// ---------------- TRADES ----------------
function createTrade({ guildId, fromUserId, toUserId, kizco = 0, itemIds = [], itemQtys = [] }) {
  const info = db.prepare(`INSERT INTO econ_trades (guildId, fromUserId, toUserId, kizco, itemIds, itemQtys, createdAt)
    VALUES (?, ?, ?, ?, ?, ?, ?)`)
    .run(guildId, fromUserId, toUserId, Math.round(Number(kizco) || 0), JSON.stringify(itemIds), JSON.stringify(itemQtys), now());
  return getTrade(info.lastInsertRowid);
}
function getTrade(id) {
  const t = db.prepare('SELECT * FROM econ_trades WHERE id = ?').get(id) || null;
  if (t) { try { t.itemIds = JSON.parse(t.itemIds); t.itemQtys = JSON.parse(t.itemQtys); } catch (_) { t.itemIds = []; t.itemQtys = []; } }
  return t;
}
function listTradesForUser(guildId, userId) {
  return db.prepare('SELECT * FROM econ_trades WHERE guildId = ? AND (fromUserId = ? OR toUserId = ?) AND status = \'pending\' ORDER BY id DESC').all(guildId, userId, userId)
    .map(t => { try { t.itemIds = JSON.parse(t.itemIds); t.itemQtys = JSON.parse(t.itemQtys); } catch (_) { t.itemIds = []; t.itemQtys = []; } return t; });
}
function resolveTrade(id, status) {
  db.prepare('UPDATE econ_trades SET status = ?, resolvedAt = ? WHERE id = ?').run(status, now(), id);
  return getTrade(id);
}

// ---------------- LISTINGS (marketplace P2P) ----------------
function createListing({ guildId, sellerId, itemId, qty = 1, pricePerUnit }) {
  const info = db.prepare('INSERT INTO econ_listings (guildId, sellerId, itemId, qty, pricePerUnit, createdAt) VALUES (?, ?, ?, ?, ?, ?)')
    .run(guildId, sellerId, itemId, qty, Math.round(Number(pricePerUnit) || 0), now());
  return getListing(info.lastInsertRowid);
}
function getListing(id) {
  return db.prepare('SELECT * FROM econ_listings WHERE id = ?').get(id) || null;
}
function listOpenListings(guildId, itemId = null) {
  if (itemId) return db.prepare("SELECT * FROM econ_listings WHERE guildId = ? AND status = 'open' AND itemId = ? ORDER BY pricePerUnit ASC, id ASC").all(guildId, itemId);
  return db.prepare("SELECT * FROM econ_listings WHERE guildId = ? AND status = 'open' ORDER BY id DESC").all(guildId);
}
function resolveListing(id, status) {
  db.prepare('UPDATE econ_listings SET status = ? WHERE id = ?').run(status, id);
  return getListing(id);
}
function removeListingQty(id, qty) {
  const l = getListing(id);
  if (!l) return null;
  if (l.qty - qty <= 0) { resolveListing(id, 'sold'); return getListing(id); }
  db.prepare('UPDATE econ_listings SET qty = qty - ? WHERE id = ?').run(qty, id);
  return getListing(id);
}

// ---------------- RIWAYAT HARGA ITEM (grafik trading) ----------------
function recordItemPrice(guildId, itemId, price) {
  db.prepare('INSERT INTO econ_item_prices (guildId, itemId, timestamp, price) VALUES (?, ?, ?, ?)')
    .run(guildId, itemId, now(), Math.round(Number(price) || 0));
}
function getItemPriceHistory(guildId, itemId, limit = 100) {
  return db.prepare('SELECT * FROM econ_item_prices WHERE guildId = ? AND itemId = ? ORDER BY id DESC LIMIT ?').all(guildId, itemId, limit).reverse();
}

// ---------------- ORDER BOOK --------------
function createOrder(o) {
  const info = db.prepare('INSERT INTO econ_orders (guildId, userId, itemId, side, type, price, qty, filledQty, status, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?)')
    .run(o.guildId, o.userId, o.itemId, o.side, o.type, Math.round(o.price || 0), o.qty, 'open', now());
  return getOrder(info.lastInsertRowid);
}
function getOrder(id) { return db.prepare('SELECT * FROM econ_orders WHERE id = ?').get(id) || null; }
function listOpenOrders(guildId, { itemId = null, side = null, userId = null } = {}) {
  let sql = "SELECT * FROM econ_orders WHERE guildId = ? AND status = 'open'";
  const args = [guildId];
  if (itemId) { sql += ' AND itemId = ?'; args.push(itemId); }
  if (side) { sql += ' AND side = ?'; args.push(side); }
  if (userId) { sql += ' AND userId = ?'; args.push(userId); }
  sql += ' ORDER BY price DESC, id ASC';
  return db.prepare(sql).all(...args);
}
function listOpenOrdersForUser(guildId, userId) {
  return db.prepare("SELECT * FROM econ_orders WHERE guildId = ? AND userId = ? AND status = 'open' ORDER BY id DESC").all(guildId, userId);
}
function fillOrder(id, qty) {
  const o = getOrder(id);
  if (!o) return null;
  const newFilled = o.filledQty + qty;
  const status = newFilled >= o.qty ? 'filled' : 'open';
  db.prepare('UPDATE econ_orders SET filledQty = ?, status = ? WHERE id = ?').run(newFilled, status, id);
  return getOrder(id);
}
function cancelOrder(id) {
  db.prepare("UPDATE econ_orders SET status = 'cancelled' WHERE id = ? AND status = 'open'").run(id);
  return getOrder(id);
}
function addFill(f) {
  db.prepare('INSERT INTO econ_fills (guildId, itemId, buyerId, sellerId, price, qty, amount, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
    .run(f.guildId, f.itemId, f.buyerId, f.sellerId, f.price, f.qty, f.amount, now());
}
function listRecentFills(guildId, itemId = null, limit = 50) {
  if (itemId) return db.prepare('SELECT * FROM econ_fills WHERE guildId = ? AND itemId = ? ORDER BY id DESC LIMIT ?').all(guildId, itemId, limit);
  return db.prepare('SELECT * FROM econ_fills WHERE guildId = ? ORDER BY id DESC LIMIT ?').all(guildId, limit);
}

// ---------------- KATALOG ITEM DINAMIS --------------
function upsertItem(it) {
  db.prepare(`INSERT INTO econ_items (id, name, category, type, basePrice, effectJson, desc, emoji, minRank, tier, class, active, aiGenerated, createdAt)
    VALUES (@id, @name, @category, @type, @basePrice, @effectJson, @desc, @emoji, @minRank, @tier, @class, @active, @aiGenerated, @createdAt)
    ON CONFLICT(id) DO UPDATE SET name=excluded.name, category=excluded.category, type=excluded.type, basePrice=excluded.basePrice,
      effectJson=excluded.effectJson, desc=excluded.desc, emoji=excluded.emoji, minRank=excluded.minRank, tier=excluded.tier, class=excluded.class, active=excluded.active, aiGenerated=excluded.aiGenerated`)
    .run({
      id: it.id, name: it.name, category: it.category, type: it.type || 'consumable',
      basePrice: it.basePrice || 10, effectJson: JSON.stringify(it.effect || {}),
      desc: it.desc || '', emoji: it.emoji || '📦', minRank: it.minRank || null,
      tier: it.tier || null, class: it.class || null,
      active: it.active != null ? it.active : 1, aiGenerated: it.aiGenerated ? 1 : 0, createdAt: now(),
    });
  return getItem(it.id);
}
function getItem(itemId) {
  const it = db.prepare('SELECT * FROM econ_items WHERE id = ?').get(itemId);
  if (!it) return null;
  try { it.effect = JSON.parse(it.effectJson || '{}'); } catch (_) { it.effect = {}; }
  it.price = it.basePrice;
  return it;
}
function listItems({ activeOnly = true } = {}) {
  const rows = activeOnly ? db.prepare('SELECT * FROM econ_items WHERE active = 1 ORDER BY category, basePrice').all()
    : db.prepare('SELECT * FROM econ_items ORDER BY category, basePrice').all();
  return rows.map(it => { try { it.effect = JSON.parse(it.effectJson || '{}'); } catch (_) { it.effect = {}; } it.price = it.basePrice; return it; });
}
function countItems() { return db.prepare('SELECT COUNT(*) AS c FROM econ_items').get().c; }
function renameItem(id, name) {
  db.prepare('UPDATE econ_items SET name = ? WHERE id = ?').run(name, id);
  return getItem(id);
}
function deactivateItem(id) { db.prepare('UPDATE econ_items SET active = 0 WHERE id = ?').run(id); }
function setItemActive(id, active) { db.prepare('UPDATE econ_items SET active = ? WHERE id = ?').run(active ? 1 : 0, id); return getItem(id); }

// ---------------- ALERT HARGA --------------
function createAlert({ guildId, userId, itemId, direction, price }) {
  const info = db.prepare('INSERT INTO econ_alerts (guildId, userId, itemId, direction, price, active, createdAt) VALUES (?, ?, ?, ?, ?, 1, ?)')
    .run(guildId, userId, itemId, direction, Math.round(Number(price) || 0), now());
  return db.prepare('SELECT * FROM econ_alerts WHERE id = ?').get(info.lastInsertRowid);
}
function listAlerts(guildId, userId) {
  return db.prepare('SELECT * FROM econ_alerts WHERE guildId = ? AND userId = ? ORDER BY id DESC').all(guildId, userId);
}
function listActiveAlerts(guildId, itemId) {
  return db.prepare('SELECT * FROM econ_alerts WHERE guildId = ? AND itemId = ? AND active = 1').all(guildId, itemId);
}
function deactivateAlert(id) {
  db.prepare('UPDATE econ_alerts SET active = 0 WHERE id = ?').run(id);
}
function deleteAlert(id) {
  return db.prepare('DELETE FROM econ_alerts WHERE id = ?').run(id).changes;
}

// ---------------- STATISTIK ITEM (24 jam) --------------
// ---------------- MUTASI BANK --------------
function addBankLog({ guildId, userId, type, amount, note = null }) {
  db.prepare('INSERT INTO econ_bank_log (guildId, userId, type, amount, note, timestamp) VALUES (?, ?, ?, ?, ?, ?)')
    .run(guildId, userId, type, Math.round(Number(amount) || 0), note, now());
}
function getBankLog(guildId, userId, limit = 30) {
  return db.prepare('SELECT * FROM econ_bank_log WHERE guildId = ? AND userId = ? ORDER BY id DESC LIMIT ?').all(guildId, userId, limit);
}

function getItemStats(guildId, itemId) {
  const since = now() - 24 * 3600 * 1000;
  const prices = db.prepare('SELECT * FROM econ_item_prices WHERE guildId = ? AND itemId = ? AND timestamp >= ? ORDER BY id ASC').all(guildId, itemId, since);
  const fills = db.prepare('SELECT * FROM econ_fills WHERE guildId = ? AND itemId = ? AND timestamp >= ?').all(guildId, itemId, since);
  if (!prices.length) {
    return { lastPrice: null, change24hPct: 0, high24h: null, low24h: null, volume24h: 0, trades24h: 0 };
  }
  const first = prices[0].price;
  const last = prices[prices.length - 1].price;
  const high = Math.max(...prices.map(p => p.price));
  const low = Math.min(...prices.map(p => p.price));
  const volume = fills.reduce((s, f) => s + f.amount, 0);
  return {
    lastPrice: last,
    change24hPct: first ? Number((((last - first) / first) * 100).toFixed(2)) : 0,
    high24h: high, low24h: low, volume24h: volume, trades24h: fills.length,
  };
}

// ---------------- AGREGAT MAKRO ----------------
// Total KZC beredar (dompet + bank) — ini M (money supply) sebenarnya.
function computeMoneySupply(guildId) {
  const row = db.prepare('SELECT COALESCE(SUM(balance),0) AS b, COALESCE(SUM(bank),0) AS k FROM economy WHERE guildId = ?').get(guildId);
  return (row.b || 0) + (row.k || 0);
}

module.exports = {
  getState, updateState,
  addPricePoint, getPriceHistory, getLastPricePoint,
  recordTransaction, getTransactions, countProductiveTransactions,
  addAiLog, getAiLog,
  getShopMeta, setShopMeta, bumpDemand, getAllShopMeta,
  createTrade, getTrade, listTradesForUser, resolveTrade,
  createListing, getListing, listOpenListings, resolveListing, removeListingQty,
  recordItemPrice, getItemPriceHistory,
  createOrder, getOrder, listOpenOrders, listOpenOrdersForUser, fillOrder, cancelOrder, addFill, listRecentFills,
  upsertItem, getItem, listItems, countItems, renameItem, deactivateItem, setItemActive,
  createAlert, listAlerts, listActiveAlerts, deactivateAlert, deleteAlert, getItemStats,
  addBankLog, getBankLog,
  computeMoneySupply,
};
