require('dotenv').config();
const { REST, Routes } = require('discord.js');

const rest = new REST().setToken(process.env.DISCORD_TOKEN);

(async () => {
  try {
    console.log('Menghapus SEMUA slash command GLOBAL milik bot ini...');
    await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), { body: [] });
    console.log('Command global berhasil dibersihkan.');

    if (process.env.GUILD_ID) {
      console.log(`Menghapus SEMUA slash command di GUILD ${process.env.GUILD_ID}...`);
      await rest.put(Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID), { body: [] });
      console.log('Command guild berhasil dibersihkan.');
    }

    console.log('\nSelesai! Semua command lama (termasuk sisa-sisa dari bot versi sebelumnya) sudah dihapus bersih.');
    console.log('Sekarang jalankan: npm run deploy');
  } catch (error) {
    console.error('Gagal membersihkan command: ', error);
  }
})();
