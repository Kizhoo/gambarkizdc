const { EmbedBuilder } = require('discord.js');
const { endGiveaway } = require('../database/db');
const config = require('../config.json');

async function finishGiveaway(client, giveaway) {
  endGiveaway(giveaway.messageId);
  try {
    const channel = await client.channels.fetch(giveaway.channelId).catch(() => null);
    if (!channel) return;
    const message = await channel.messages.fetch(giveaway.messageId).catch(() => null);
    if (!message) return;

    const reaction = message.reactions.cache.get('🎉');
    let participants = [];
    if (reaction) {
      const users = await reaction.users.fetch();
      participants = users.filter(u => !u.bot).map(u => u.id);
    }

    if (participants.length === 0) {
      const noWinnerEmbed = new EmbedBuilder()
        .setColor(config.errorColor)
        .setTitle('🎉 Giveaway Berakhir')
        .setDescription(`Hadiah: **${giveaway.prize}**\n\nTidak ada yang ikut, jadi tidak ada pemenang.`)
        .setTimestamp();
      await message.edit({ embeds: [noWinnerEmbed] });
      await channel.send('Giveaway berakhir tanpa pemenang karena tidak ada peserta. 😢');
      return;
    }

    const shuffled = participants.sort(() => 0.5 - Math.random());
    const winners = shuffled.slice(0, Math.min(giveaway.winnerCount, participants.length));
    const winnerMentions = winners.map(id => `<@${id}>`).join(', ');

    const endEmbed = new EmbedBuilder()
      .setColor(config.successColor)
      .setTitle('🎉 Giveaway Berakhir')
      .setDescription(`Hadiah: **${giveaway.prize}**\n\nPemenang: ${winnerMentions}`)
      .setTimestamp();
    await message.edit({ embeds: [endEmbed] });
    await channel.send(`🎉 Selamat ${winnerMentions}! Kamu memenangkan **${giveaway.prize}**!`);
  } catch (err) {
    console.error('Error saat mengakhiri giveaway: ', err);
  }
}

module.exports = { finishGiveaway };
