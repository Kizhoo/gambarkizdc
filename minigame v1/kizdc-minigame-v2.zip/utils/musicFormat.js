// ============================================================================
// FORMAT TAMPILAN MUSIK — dipakai bareng oleh musicSetup.js, nowplaying.js, queue.js
// ----------------------------------------------------------------------------
// Ditarik ke sini biar formatnya konsisten di semua tempat (bukan disalin-tempel
// per file) - persis filosofi yang sama kayak modul-modul shared lainnya.
// ============================================================================
function formatDuration(ms) {
  if (!ms || ms <= 0) return 'Live';
  const totalSeconds = Math.floor(ms / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  const mm = hours > 0 ? String(minutes).padStart(2, '0') : String(minutes);
  const ss = String(seconds).padStart(2, '0');
  return hours > 0 ? `${hours}:${mm}:${ss}` : `${mm}:${ss}`;
}

// Desain lama pakai karakter blok/shading (█░) sempat kelihatan "berantakan"/kotak-kotak di
// sebagian klien Discord (font rendering beda-beda per platform - persis kelas masalah yang sama
// kayak yang pernah kejadian di bidak catur). Sekarang pakai garis + emoji bulat sebagai penanda
// posisi - karakter simpel + emoji standar, jauh lebih konsisten renderingnya di semua klien.
function progressBar(positionMs, lengthMs, barLength = 24) {
  if (!lengthMs || lengthMs <= 0) return '🔴 LIVE ' + '▬'.repeat(barLength);
  const progress = Math.min(1, Math.max(0, positionMs / lengthMs));
  const markerIndex = Math.min(barLength - 1, Math.round(progress * (barLength - 1)));
  let bar = '';
  for (let i = 0; i < barLength; i++) bar += (i === markerIndex ? '🔘' : '▬');
  return bar;
}

const SOURCE_LABELS = { youtube: 'YouTube', spotify: 'Spotify', soundcloud: 'SoundCloud', deezer: 'Deezer', applemusic: 'Apple Music' };
function sourceLabel(sourceName) {
  return SOURCE_LABELS[String(sourceName || '').toLowerCase()] || (sourceName ? sourceName : 'Tidak diketahui');
}

module.exports = { formatDuration, progressBar, sourceLabel };
