const { EmbedBuilder } = require('discord.js');
const { getGuildConfig } = require('../database/db');
const { cacheDeleted } = require('../utils/snipeCache');
const config = require('../config.json');

module.exports = {
  name: 'messageDelete',
  async execute(message) {
    if (!message.guild || !message.author || message.author.bot) return;

    cacheDeleted(message.channel.id, {
      content: message.content || '*(tidak ada teks, mungkin cuma attachment/embed)*',
      author: message.author,
      timestamp: Date.now(),
      attachments: [...message.attachments.values()].map(a => a.url),
    });

    const cfg = getGuildConfig(message.guild.id);
    if (cfg.modLogEnabled && cfg.logChannel) {
      const logChannel = message.guild.channels.cache.get(cfg.logChannel);
      if (logChannel) {
        const embed = new EmbedBuilder()
          .setColor(config.errorColor)
          .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL() })
          .setTitle('Pesan Dihapus')
          .setDescription(message.content || '*(tidak ada teks)*')
          .addFields({ name: 'Channel', value: `${message.channel}`, inline: true })
          .setFooter({ text: `User ID: ${message.author.id}`})
          .setTimestamp();
        logChannel.send({ embeds: [embed] }).catch(() => {});
      }
    }
  },
};
