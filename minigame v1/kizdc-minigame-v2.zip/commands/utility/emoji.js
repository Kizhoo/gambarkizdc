// ============================================================================
// COMMAND /emoji — import & kelola emoji animasi bot (owner only)
// ----------------------------------------------------------------------------
// /emoji import <kata> [jumlah]  → import banyak emoji dari emoji.gg sekaligus
// /emoji url <url> <nama>        → import 1 emoji dari URL langsung
// /emoji list                    → lihat semua emoji yang sudah di-import
// ============================================================================
const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { isOwner } = require('../../utils/ownerCheck');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { importByKeyword, importFromUrl, listAppEmojis } = require('../../utils/emojiImporter');

module.exports = {
  subcommandOf: true, // dimuat sebagai subcommand group "emoji" di /util
  data: new SlashCommandBuilder()
    .setName('emoji')
    .setDescription('[Owner] Import & kelola emoji animasi bot (emoji.gg / URL)')
    .addSubcommand(sub => sub.setName('import')
      .setDescription('Import banyak emoji dari emoji.gg berdasarkan kata kunci')
      .addStringOption(o => o.setName('kata').setDescription('Kata kunci (mis. cat, pepe, anime, dance)').setRequired(true))
      .addIntegerOption(o => o.setName('jumlah').setDescription('Jumlah maksimal (1-30, default 10)').setMinValue(1).setMaxValue(30)))
    .addSubcommand(sub => sub.setName('url')
      .setDescription('Import 1 emoji dari URL langsung (gif/png/webp)')
      .addStringOption(o => o.setName('url').setDescription('URL gambar emoji').setRequired(true))
      .addStringOption(o => o.setName('nama').setDescription('Nama emoji (2-32 huruf/angka)').setRequired(true)))
    .addSubcommand(sub => sub.setName('list')
      .setDescription('Lihat semua emoji yang sudah di-import')),

  async execute(interaction, client) {
    if (!isOwner(interaction.user.id)) {
      return interaction.reply({ embeds: [errorEmbed('Hanya owner bot yang bisa pakai command ini.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    // ===== IMPORT BULK (emoji.gg) =====
    if (sub === 'import') {
      const kata = interaction.options.getString('kata');
      const jumlah = interaction.options.getInteger('jumlah') || 10;

      await interaction.deferReply();
      try {
        const res = await importByKeyword(kata, jumlah);

        const embed = baseEmbed()
          .setTitle(`Hasil import: "${kata}"`)
          .setColor('#57F287')
          .addFields(
            { name: `✅ Berhasil (${res.imported.length})`, value: res.imported.length ? res.imported.map(e => `\`:${e.name}:\``).join(' ') : '*Tidak ada*' },
            { name: `❌ Gagal (${res.failed.length})`, value: res.failed.length ? res.failed.slice(0, 10).join('\n') : '*Tidak ada*' },
          )
          .setFooter({ text: 'Emoji animasi dipakai bot di semua server' });

        return interaction.editReply({ embeds: [embed] });
      } catch (err) {
        return interaction.editReply({ embeds: [errorEmbed(`Gagal import: ${err.message}`)] }).catch(() => {});
      }
    }

    // ===== IMPORT DARI URL =====
    if (sub === 'url') {
      const url = interaction.options.getString('url');
      const nama = interaction.options.getString('nama');

      await interaction.deferReply();
      try {
        const res = await importFromUrl(url, nama);
        const embed = baseEmbed()
          .setTitle('Emoji di-import')
          .setColor('#57F287')
          .setDescription(`Berhasil: \`:${res.name}:\`\n\nTag: \`${res.tag}\``);
        return interaction.editReply({ embeds: [embed] });
      } catch (err) {
        return interaction.editReply({ embeds: [errorEmbed(`Gagal import: ${err.message}`)] }).catch(() => {});
      }
    }

    // ===== LIST =====
    if (sub === 'list') {
      await interaction.deferReply({ ephemeral: true });
      try {
        const items = await listAppEmojis();
        if (!items.length) {
          return interaction.editReply({ embeds: [errorEmbed('Belum ada emoji yang di-import.')] });
        }
        const lines = items.map((e, i) => `${i + 1}. \`:${e.name}:\` — \`${e.tag}\``);
        // potong jadi beberapa embed kalau kebanyakan (limit 50 baris)
        const chunks = [];
        for (let i = 0; i < lines.length; i += 25) chunks.push(lines.slice(i, i + 25));
        const embeds = chunks.map((c, i) =>
          baseEmbed()
            .setTitle(`Emoji bot (${items.length} total)${chunks.length > 1 ? ` — bagian ${i + 1}/${chunks.length}` : ''}`)
            .setColor('#5865F2')
            .setDescription(c.join('\n')),
        );
        return interaction.editReply({ embeds });
      } catch (err) {
        return interaction.editReply({ embeds: [errorEmbed(`Gagal ambil daftar: ${err.message}`)] });
      }
    }
  },
};
