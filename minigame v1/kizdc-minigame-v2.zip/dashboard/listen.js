// ============================================================================
// LISTEN — dengarkan audio voice channel & stream ke dashboard (WebSocket)
// ----------------------------------------------------------------------------
// ⚠️  PERINGATAN: merekam/meneruskan suara user TANPA izin melanggar Developer
//     Policy Discord. Fitur ini dibuat sesuai permintaan owner, risiko banned
//     ditanggung sendiri. Ada toggle ON/OFF supaya tidak selalu aktif.
//
// Cara kerja: bot join VC dengan selfDeaf:false (biar bisa menerima audio),
// terima Opus dari tiap user yang bicara, decode jadi PCM 48kHz stereo,
// lalu kirim chunk PCM lewat callback onPcm (diteruskan ke WebSocket).
// ============================================================================
const { joinVoiceChannel, getVoiceConnection, EndBehaviorType } = require('@discordjs/voice');

let activeListeners = new Set(); // guildId yang lagi di-dengarkan

function isListening(guildId) {
  return activeListeners.has(guildId);
}

// Diagnostik cepat: cek library Opus/decoder tersedia atau tidak.
function voiceDiagnostics() {
  const out = { '@discordjs/opus': false, 'opusscript': false, 'prism-media': false };
  try { require('@discordjs/opus'); out['@discordjs/opus'] = true; } catch {}
  try { require('opusscript'); out['opusscript'] = true; } catch {}
  try { require('prism-media'); out['prism-media'] = true; } catch {}
  out.canDecode = out['prism-media'] && (out['@discordjs/opus'] || out['opusscript']);
  return out;
}

function startListening(client, guildId, voiceChannelId, onPcm, onError) {
  let prism;
  try {
    prism = require('prism-media');
  } catch {
    throw new Error('Dependency prism-media belum diinstall');
  }

  const guild = client.guilds.cache.get(guildId);
  if (!guild) throw new Error('Guild tidak ditemukan');
  const channel = guild.channels.cache.get(voiceChannelId);
  if (!channel || channel.type !== 2) throw new Error('Voice channel tidak ditemukan');

  // hancurkan koneksi lama kalau ada (biar tidak dobel)
  const old = getVoiceConnection(guildId);
  if (old) old.destroy();

  const connection = joinVoiceChannel({
    channelId: voiceChannelId,
    guildId,
    adapterCreator: guild.voiceAdapterCreator,
    selfDeaf: false, // PENTING: jangan deafen, biar bisa menerima audio
    selfMute: true,  // jangan kirim audio balik
  });

  const receiver = connection.receiver;

  // Setiap user mulai bicara → subscribe & decode
  receiver.speaking.on('start', (userId) => {
    try {
      const stream = receiver.subscribe(userId, {
        end: { behavior: EndBehaviorType.AfterSilence, duration: 300 },
      });
      // Decoder Opus -> PCM (Int16 LE, 48kHz stereo). Pilih @discordjs/opus
      // (native) dulu, fallback opusscript otomatis ditangani prism-media.
      const decoder = new prism.opus.Decoder({ rate: 48000, channels: 2, frameSize: 960 });
      stream.pipe(decoder);
      decoder.on('data', (chunk) => onPcm(chunk));
      decoder.on('error', (err) => { if (onError) onError(err.message); });
    } catch (e) {
      if (onError) onError(e.message);
    }
  });

  connection.on('error', (err) => { if (onError) onError(err.message); });

  activeListeners.add(guildId);
  return connection;
}

function stopListening(guildId) {
  activeListeners.delete(guildId);
  const connection = getVoiceConnection(guildId);
  if (connection) connection.destroy();
  return true;
}

module.exports = { startListening, stopListening, isListening, voiceDiagnostics };
