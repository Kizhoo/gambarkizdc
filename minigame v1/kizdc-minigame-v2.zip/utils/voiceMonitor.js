// ============================================================================
// VOICE MONITORING REAL-TIME
// ----------------------------------------------------------------------------
// CATATAN PENTING: Discord TIDAK mengizinkan bot menerima/melihat video screen-share
// atau webcam. Jadi "membagikan layar" user secara video mustahil lewat API bot.
// Yang BISA dipantau real-time: siapa di voice, mute/deafen, sedang streaming (Go Live)
// atau kamera nyala, plus log join/leave/pindah channel.
//
// - Dashboard live: pesan embed yang auto-refresh tiap beberapa detik menampilkan
//   isi semua voice channel + status tiap member.
// ============================================================================
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const settings = require('./settings');
const { t, guildLang } = require('./i18n');

// guildId -> { message, interval, channelId, lang }
const activeMonitors = new Map();

function memberStatusIcons(vs, lang) {
  const tags = [];
  if (vs.selfStream) tags.push(t(lang, 'vmon.live'));
  if (vs.selfVideo) tags.push(t(lang, 'vmon.camera'));
  if (vs.selfMute || vs.serverMute) tags.push(t(lang, 'vmon.mute'));
  if (vs.selfDeaf || vs.serverDeaf) tags.push(t(lang, 'vmon.deaf'));
  return tags.length ? tags.join(', ') : t(lang, 'vmon.active');
}

function buildDashboard(guild) {
  const lang = guildLang(guild);
  const voiceChannels = guild.channels.cache.filter(c => c.isVoiceBased());
  const embed = new EmbedBuilder()
    .setColor(settings.get('embedColor', '#2b2d31'))
    .setTitle(t(lang, 'vmon.title', { name: guild.name }))
    .setTimestamp()
    .setFooter({ text: t(lang, 'vmon.footer') });

  let totalInVoice = 0;
  const fields = [];
  for (const [, ch] of voiceChannels) {
    const members = ch.members.filter(m => !m.user.bot);
    if (members.size === 0) continue;
    totalInVoice += members.size;
    const lines = members.map(m => `• ${m.displayName} — ${memberStatusIcons(m.voice, lang)}`).join('\n');
    fields.push({ name: `${ch.name} (${members.size})`, value: lines.slice(0, 1024) });
  }

  if (fields.length === 0) {
    embed.setDescription(t(lang, 'vmon.empty'));
  } else {
    embed.setDescription(t(lang, 'vmon.total', { n: totalInVoice })).addFields(fields.slice(0, 20));
  }
  return embed;
}

function controlRow(active, lang) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('vmon_refresh').setLabel(t(lang, 'vmon.refresh')).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('vmon_stop').setLabel(active ? t(lang, 'vmon.stop') : t(lang, 'vmon.stop2')).setStyle(ButtonStyle.Danger).setDisabled(!active),
  );
}

async function startMonitor(interaction) {
  const guild = interaction.guild;
  const lang = guildLang(interaction);
  // hentikan monitor lama kalau ada
  stopMonitor(guild.id);

  const embed = buildDashboard(guild);
  const msg = await interaction.reply({ embeds: [embed], components: [controlRow(true, lang)], fetchReply: true });

  const interval = setInterval(async () => {
    try {
      const rec = activeMonitors.get(guild.id);
      if (!rec) return;
      await rec.message.edit({ embeds: [buildDashboard(guild)], components: [controlRow(true, rec.lang)] });
    } catch (e) {
      stopMonitor(guild.id);
    }
  }, 10000); // refresh tiap 10 detik (aman dari rate limit)

  activeMonitors.set(guild.id, { message: msg, interval, lang });
}

function stopMonitor(guildId) {
  const rec = activeMonitors.get(guildId);
  if (rec) {
    clearInterval(rec.interval);
    activeMonitors.delete(guildId);
    rec.message.edit({ components: [controlRow(false, rec.lang)] }).catch(() => {});
  }
}

async function handleVoiceMonitorButton(interaction) {
  const lang = guildLang(interaction);
  if (interaction.customId === 'vmon_refresh') {
    return interaction.update({ embeds: [buildDashboard(interaction.guild)], components: [controlRow(activeMonitors.has(interaction.guild.id), lang)] });
  }
  if (interaction.customId === 'vmon_stop') {
    stopMonitor(interaction.guild.id);
    return interaction.update({ embeds: [buildDashboard(interaction.guild)], components: [controlRow(false, lang)] });
  }
}

module.exports = { startMonitor, stopMonitor, handleVoiceMonitorButton, buildDashboard };
