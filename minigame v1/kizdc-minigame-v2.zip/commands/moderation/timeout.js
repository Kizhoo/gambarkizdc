const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Kelola timeout (bisukan sementara) member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addSubcommand(sub => sub.setName('set').setDescription('Timeout member')
      .addUserOption(o => o.setName('target').setDescription('Member yang akan ditimeout').setRequired(true))
      .addIntegerOption(o => o.setName('menit').setDescription('Lama timeout dalam menit').setRequired(true).setMinValue(1).setMaxValue(40320))
      .addStringOption(o => o.setName('alasan').setDescription('Alasan timeout')))
    .addSubcommand(sub => sub.setName('remove').setDescription('Hapus timeout dari member')
      .addUserOption(o => o.setName('target').setDescription('Member yang akan dihapus timeoutnya').setRequired(true))),

  async execute(interaction) {
    const lang = guildLang(interaction);
    const sub = interaction.options.getSubcommand();
    const target = interaction.options.getMember('target');
    if (!target) return interaction.reply({ embeds: [errorEmbed(t(lang, 'mod.not_found'))], ephemeral: true });

    if (sub === 'set') {
      const minutes = interaction.options.getInteger('menit');
      const reason = interaction.options.getString('alasan') || t(lang, 'mod.no_reason');
      if (!target.moderatable) return interaction.reply({ embeds: [errorEmbed(t(lang, 'mod.cant_timeout'))], ephemeral: true });

      await target.timeout(minutes * 60 * 1000, reason);
      return interaction.reply({ embeds: [successEmbed(t(lang, 'mod.timeout_ok', { user: target.user.tag, min: minutes, reason, reason_label: t(lang, 'mod.reason') }))] });
    }

    if (sub === 'remove') {
      if (!target.communicationDisabledUntil) {
        return interaction.reply({ embeds: [errorEmbed(t(lang, 'mod.timeout_not'))], ephemeral: true });
      }
      await target.timeout(null);
      return interaction.reply({ embeds: [successEmbed(t(lang, 'mod.timeout_removed', { user: target.user.tag }))] });
    }
  },
};
