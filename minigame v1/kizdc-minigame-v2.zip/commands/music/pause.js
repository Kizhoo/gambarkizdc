const { SlashCommandBuilder } = require('discord.js');
const { getValidPlayer, safePlayerAction } = require('../../utils/musicGuard');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder().setName('pause').setDescription('Jeda musik yang sedang diputar'),
  async execute(interaction, client) {
    const lang = guildLang(interaction);
    const player = await getValidPlayer(interaction, client);
    if (!player) return;

    if (player.paused) return interaction.reply({ embeds: [errorEmbed(t(lang, 'music.already_paused'))], ephemeral: true });

    return safePlayerAction(interaction, () => player.pause(true), { embeds: [successEmbed(t(lang, 'music.paused'))] });
  },
};
