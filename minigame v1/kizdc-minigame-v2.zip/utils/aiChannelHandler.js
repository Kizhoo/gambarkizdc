// ============================================================================
// AI CHANNEL - workspace privat ala ChatGPT/Claude: tiap user bisa bikin channel
// privat (cuma dia + bot yang lihat), ketik langsung tanpa command, ganti model
// lewat dropdown, dan bikin beberapa channel sekaligus (obrolan terpisah-pisah).
// ============================================================================
const {
  ChannelType, PermissionFlagsBits, AttachmentBuilder,
  ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder,
} = require('discord.js');
const {
  getAiChannel, listAiChannelsForUser, createAiChannel, setAiChannelModel, deleteAiChannel,
  addAiChannelMessage, getAiChannelHistory, clearAiChannelHistory, getAiCategoryId, setAiCategoryId,
} = require('../database/db');
const { generateText } = require('./aiProvider');
const { ingestAttachment } = require('./fileIngest');
const { baseEmbed, successEmbed, errorEmbed } = require('./embeds');
const settings = require('./settings');

const MESSAGE_LIMIT_SAFE = 1900; // batas aman di bawah limit 2000 karakter pesan biasa Discord

function cfg() {
  return settings.get('aiChannels', {
    enabled: true, maxChannelsPerUser: 3, categoryName: 'AI Chats', maxHistory: 20, cooldownSeconds: 3,
  });
}

function slugify(text) {
  return String(text).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 20) || 'user';
}

// Saring baris DB yang channel Discord-nya sudah tidak ada lagi (misal dihapus manual lewat
// UI Discord tanpa lewat tombol "Hapus Channel Ini") - sekalian dibersihkan dari DB.
function pruneOrphans(guild, rows) {
  const alive = [];
  for (const row of rows) {
    if (guild.channels.cache.has(row.channelId)) alive.push(row);
    else deleteAiChannel(row.channelId);
  }
  return alive;
}

async function getOrCreateAiCategory(guild) {
  const existingId = getAiCategoryId(guild.id);
  if (existingId) {
    const existing = guild.channels.cache.get(existingId);
    if (existing) return existing;
  }
  // Kategori ikut di-deny buat @everyone juga (bukan cuma channel di dalamnya) - defensive,
  // supaya kalau ada channel yang somehow ke-"sync" ulang ke permission kategori lewat UI
  // Discord manual, defaultnya tetap privat, bukan malah kebuka.
  const created = await guild.channels.create({
    name: cfg().categoryName,
    type: ChannelType.GuildCategory,
    permissionOverwrites: [{ id: guild.roles.everyone, deny: [PermissionFlagsBits.ViewChannel] }],
  });
  setAiCategoryId(guild.id, created.id);
  return created;
}

function modelSelectMenu(currentModel) {
  const modelList = settings.get('ai.models.cloudflare', []);
  return new StringSelectMenuBuilder()
    .setCustomId('aich:model')
    .setPlaceholder('Ganti model AI')
    .addOptions(modelList.slice(0, 25).map(m => ({
      label: m.replace('@cf/', '').slice(0, 100),
      value: `cloudflare:${m}`.slice(0, 100),
      default: m === currentModel,
    })));
}

function buildControlPanel(row) {
  const embed = baseEmbed()
    .setTitle('Panel Kontrol AI Channel')
    .setDescription(`Channel privat buat <@${row.userId}>. Ketik pesan apa aja di sini buat ngobrol - **gak perlu command**. Bisa lampirin file/zip juga, langsung ditanggapi.`)
    .addFields(
      { name: 'Model aktif', value: `\`${row.model}\``, inline: true },
      { name: 'Provider', value: row.provider, inline: true },
    )
    .setFooter({ text: 'Ganti model lewat dropdown di bawah. Riwayat obrolan tersimpan khusus buat channel ini saja.' });

  const buttons = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('aich:reset').setLabel('Reset Riwayat').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('aich:delete').setLabel('Hapus Channel Ini').setStyle(ButtonStyle.Danger),
  );
  return { embeds: [embed], components: [new ActionRowBuilder().addComponents(modelSelectMenu(row.model)), buttons] };
}

// Dipanggil dari /ai channel - nampilin daftar channel yg sudah ada + tombol bikin baru.
function promptView(interaction) {
  const options = cfg();
  const existing = pruneOrphans(interaction.guild, listAiChannelsForUser(interaction.guild.id, interaction.user.id));
  const canCreateMore = existing.length < options.maxChannelsPerUser;

  const embed = baseEmbed()
    .setTitle('Channel AI Kamu')
    .setDescription(existing.length
      ? `Kamu punya ${existing.length}/${options.maxChannelsPerUser} channel AI aktif:\n${existing.map(r => `<#${r.channelId}> — \`${r.model}\``).join('\n')}`
      : 'Kamu belum punya channel AI privat. Klik tombol di bawah buat bikin satu - nanti tinggal ketik langsung di sana, gak perlu command sama sekali, mirip ChatGPT/Claude.');
  if (!canCreateMore) embed.setFooter({ text: `Batas maksimal ${options.maxChannelsPerUser} channel per orang tercapai. Hapus salah satu dulu (tombol "Hapus Channel Ini" di dalam channelnya) buat bikin yang baru.` });

  const button = new ButtonBuilder().setCustomId('aich:create').setLabel('Buat Channel AI Baru').setStyle(ButtonStyle.Success).setDisabled(!canCreateMore);
  return { embeds: [embed], components: [new ActionRowBuilder().addComponents(button)], ephemeral: true };
}

async function handleCreateButton(interaction) {
  await interaction.deferReply({ ephemeral: true });
  const options = cfg();
  if (options.enabled === false) return interaction.editReply({ embeds: [errorEmbed('Fitur AI channel sedang dimatikan.')] });

  const existing = pruneOrphans(interaction.guild, listAiChannelsForUser(interaction.guild.id, interaction.user.id));
  if (existing.length >= options.maxChannelsPerUser) {
    return interaction.editReply({ embeds: [errorEmbed(`Sudah mencapai batas maksimal ${options.maxChannelsPerUser} channel AI. Hapus salah satu dulu lewat tombol "Hapus Channel Ini".`)] });
  }

  let category;
  try {
    category = await getOrCreateAiCategory(interaction.guild);
  } catch (err) {
    console.error('[aiChannel] Gagal bikin/ambil kategori:', err.message);
    return interaction.editReply({ embeds: [errorEmbed('Gagal menyiapkan kategori channel AI (cek permission Manage Channels bot).')] });
  }

  const provider = settings.get('ai.provider', 'cloudflare');
  const model = settings.get('ai.model', '@cf/meta/llama-3.1-8b-instruct');
  const baseName = `ai-${slugify(interaction.user.username)}`;
  const channelName = existing.length ? `${baseName}-${existing.length + 1}` : baseName;

  let channel;
  try {
    channel = await interaction.guild.channels.create({
      name: channelName,
      type: ChannelType.GuildText,
      parent: category.id,
      topic: `Channel AI privat milik ${interaction.user.tag} (${interaction.user.id})`,
      permissionOverwrites: [
        { id: interaction.guild.roles.everyone, deny: [PermissionFlagsBits.ViewChannel] },
        { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles] },
        { id: interaction.client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles, PermissionFlagsBits.ManageChannels] },
      ],
    });
  } catch (err) {
    console.error('[aiChannel] Gagal bikin channel:', err.message);
    return interaction.editReply({ embeds: [errorEmbed('Gagal membuat channel (cek permission Manage Channels bot).')] });
  }

  createAiChannel({ channelId: channel.id, guildId: interaction.guild.id, userId: interaction.user.id, provider, model });
  await channel.send(buildControlPanel({ userId: interaction.user.id, provider, model })).catch(() => {});
  await channel.send(`${interaction.user}, selamat datang! Ketik pesan apa aja di sini buat mulai ngobrol - gak perlu command.`).catch(() => {});

  return interaction.editReply({ embeds: [successEmbed(`Channel AI baru dibuat: ${channel}`)] });
}

async function requireOwner(interaction) {
  const row = getAiChannel(interaction.channel.id);
  if (!row) {
    await interaction.reply({ embeds: [errorEmbed('Channel ini bukan channel AI terdaftar (mungkin datanya kehapus).')], ephemeral: true }).catch(() => {});
    return null;
  }
  if (interaction.user.id !== row.userId) {
    await interaction.reply({ embeds: [errorEmbed('Cuma pemilik channel ini yang bisa pakai tombol/menu ini.')], ephemeral: true }).catch(() => {});
    return null;
  }
  return row;
}

async function handleModelSelect(interaction) {
  const row = await requireOwner(interaction);
  if (!row) return;
  const [provider, ...rest] = interaction.values[0].split(':');
  const model = rest.join(':');
  setAiChannelModel(interaction.channel.id, { provider, model });
  return interaction.update(buildControlPanel({ ...row, provider, model }));
}

async function handleResetButton(interaction) {
  const row = await requireOwner(interaction);
  if (!row) return;
  clearAiChannelHistory(interaction.channel.id);
  return interaction.reply({ embeds: [successEmbed('Riwayat obrolan di channel ini sudah dihapus. Mulai lagi dari nol.')], ephemeral: true });
}

async function handleDeleteButton(interaction) {
  const row = await requireOwner(interaction);
  if (!row) return;
  await interaction.reply({ embeds: [successEmbed('Channel ini akan dihapus dalam beberapa detik...')] }).catch(() => {});
  deleteAiChannel(interaction.channel.id);
  setTimeout(() => interaction.channel.delete('Dihapus pemilik lewat tombol Hapus Channel Ini').catch(() => {}), 3000);
}

// Dipanggil dari events/messageCreate.js kalau pesan masuk ke channel yang terdaftar sebagai
// AI channel - jadi user tinggal ketik, tanpa command sama sekali.
const lastUsedAt = new Map(); // channelId -> timestamp, cooldown ringan anti-spam

async function handleAiChannelMessage(message, row) {
  if (message.author.id !== row.userId) return; // jaga-jaga kalau channel private ini somehow keisi orang lain
  const attachment = message.attachments.first();
  if (!message.content && !attachment) return;

  const cooldownSeconds = cfg().cooldownSeconds ?? 3;
  const last = lastUsedAt.get(message.channel.id) || 0;
  if (Date.now() - last < cooldownSeconds * 1000) return message.react('⏳').catch(() => {});
  lastUsedAt.set(message.channel.id, Date.now());

  let fileInfo = null;
  if (attachment) {
    try {
      fileInfo = await ingestAttachment(attachment);
      if (fileInfo.kind === 'unsupported') return message.reply({ embeds: [errorEmbed(fileInfo.reason)] }).catch(() => {});
    } catch (err) {
      return message.reply({ embeds: [errorEmbed(`Gagal membaca lampiran: ${err.message}`)] }).catch(() => {});
    }
  }

  await message.channel.sendTyping().catch(() => {});

  try {
    const maxHistory = cfg().maxHistory ?? 20;
    const history = getAiChannelHistory(message.channel.id, maxHistory);
    const userContent = fileInfo ? `${message.content}\n\n[Lampiran: ${fileInfo.name}]\n${fileInfo.contextText}` : message.content;
    const messages = [
      { role: 'system', content: settings.get('ai.systemPrompt', 'Kamu asisten AI ramah.') },
      ...history,
      { role: 'user', content: userContent },
    ];

    const response = await generateText(messages, { provider: row.provider, model: row.model });

    addAiChannelMessage(message.channel.id, 'user', fileInfo ? `${message.content} [lampiran: ${fileInfo.name}]` : message.content);
    addAiChannelMessage(message.channel.id, 'assistant', response);

    const files = [];
    let content = response || '(AI tidak mengirim balasan teks.)';
    if (content.length > MESSAGE_LIMIT_SAFE) {
      files.push(new AttachmentBuilder(Buffer.from(response, 'utf8'), { name: 'jawaban-ai.txt' }));
      content = `${content.slice(0, MESSAGE_LIMIT_SAFE)}...\n\n*Jawaban lengkap dilampirkan sebagai file karena terlalu panjang.*`;
    }
    return message.channel.send({ content, files }).catch(() => {});
  } catch (err) {
    console.error('[aiChannel] Gagal dapat respons AI:', err.message);
    return message.reply({ embeds: [errorEmbed(`Gagal mendapat respons dari AI: ${err.message}`)] }).catch(() => {});
  }
}

module.exports = {
  promptView, handleCreateButton, handleModelSelect, handleResetButton, handleDeleteButton, handleAiChannelMessage,
};
