// ============================================================================
// ORDER BOOK + MATCHING ENGINE — buat web trading profesional
// ----------------------------------------------------------------------------
// Mendukung order MARKET dan LIMIT (bid/ask) dengan pencocokan kontinu ala
// bursa sungguhan: taker di-fill di harga maker (order yang sudah nongkrong).
// Escrow penuh di awal (item dijual ditahan, dana beli ditahan) supaya tidak
// pernah double-spend; sisa yang tidak terisi dikembalikan saat cancel/partial.
// ============================================================================
const econ = require('../database/economyDb');
const { getEconomy, updateBalance } = require('../database/db');
const rdb = require('../database/webDb');
const shop = require('./shopManager');
const priceAlerts = require('./priceAlerts');

function executeFill(guildId, { buyerId, sellerId, itemId, price, qty }) {
  const amount = price * qty;
  updateBalance(guildId, buyerId, -amount);
  updateBalance(guildId, sellerId, amount);
  rdb.addItem(buyerId, itemId, qty);
  econ.addFill({ guildId, itemId, buyerId, sellerId, price, qty, amount });
  econ.recordItemPrice(guildId, itemId, price);
  econ.recordTransaction(guildId, { type: 'trade', actorId: buyerId, targetId: sellerId, amount, note: `${qty}x ${itemId} @ ${price}` });
  priceAlerts.checkAndNotify(guildId, itemId, price).catch(() => {});
}

function placeOrder(guildId, userId, { itemId, side, type = 'limit', price = 0, qty = 1 }) {
  const item = shop.getItem(itemId);
  if (!item) return { ok: false, error: 'Item tidak dikenal.' };
  qty = Math.max(1, Math.round(Number(qty) || 1));
  price = Math.max(0, Math.round(Number(price) || 0));
  if (!['buy', 'sell'].includes(side)) return { ok: false, error: 'side harus buy/sell.' };
  if (type === 'limit' && price <= 0) return { ok: false, error: 'Order limit butuh harga > 0.' };

  // Escrow penjual (item) di awal.
  if (side === 'sell') {
    if (rdb.getItemQty(userId, itemId) < qty) return { ok: false, error: `Kamu tidak punya cukup ${item.name}.` };
    rdb.removeItem(userId, itemId, qty);
  }

  const fills = [];
  let remaining = qty;

  if (side === 'buy') {
    const asks = econ.listOpenOrders(guildId, { itemId, side: 'sell' }).sort((a, b) => a.price - b.price || a.id - b.id);
    for (const ask of asks) {
      if (remaining <= 0) break;
      if (type === 'limit' && ask.price > price) break;
      const fillQty = Math.min(remaining, ask.qty - ask.filledQty);
      const cost = ask.price * fillQty;
      const buyer = getEconomy(guildId, userId);
      if (buyer.balance < cost) break; // tidak mampu, berhenti
      executeFill(guildId, { buyerId: userId, sellerId: ask.userId, itemId, price: ask.price, qty: fillQty });
      econ.fillOrder(ask.id, fillQty);
      fills.push({ price: ask.price, qty: fillQty, amount: cost });
      remaining -= fillQty;
    }
    // Sisa -> order limit nongkrong (escrow dana).
    if (remaining > 0 && type === 'limit') {
      const escrow = price * remaining;
      const buyer = getEconomy(guildId, userId);
      if (buyer.balance < escrow) return { ok: false, error: `KZC tidak cukup untuk escrow ${escrow}.`, fills };
      updateBalance(guildId, userId, -escrow);
      const order = econ.createOrder({ guildId, userId, itemId, side: 'buy', type: 'limit', price, qty: remaining });
      return { ok: true, orderId: order.id, fills, remainingQty: remaining, status: fills.length ? 'partial' : 'open' };
    }
  } else { // sell
    const bids = econ.listOpenOrders(guildId, { itemId, side: 'buy' }).sort((a, b) => b.price - a.price || a.id - b.id);
    for (const bid of bids) {
      if (remaining <= 0) break;
      if (type === 'limit' && bid.price < price) break;
      const fillQty = Math.min(remaining, bid.qty - bid.filledQty);
      executeFill(guildId, { buyerId: bid.userId, sellerId: userId, itemId, price: bid.price, qty: fillQty });
      econ.fillOrder(bid.id, fillQty);
      fills.push({ price: bid.price, qty: fillQty, amount: bid.price * fillQty });
      remaining -= fillQty;
    }
    if (remaining > 0 && type === 'limit') {
      const order = econ.createOrder({ guildId, userId, itemId, side: 'sell', type: 'limit', price, qty: remaining });
      return { ok: true, orderId: order.id, fills, remainingQty: remaining, status: fills.length ? 'partial' : 'open' };
    }
    // Market/partial yang tidak terisi -> kembalikan item.
    if (remaining > 0) rdb.addItem(userId, itemId, remaining);
  }

  return { ok: true, fills, remainingQty: remaining, status: remaining === 0 ? 'filled' : 'partial' };
}

function cancelOrder(guildId, userId, orderId) {
  const o = econ.getOrder(orderId);
  if (!o || o.guildId !== guildId) return { ok: false, error: 'Order tidak ditemukan.' };
  if (o.userId !== userId) return { ok: false, error: 'Hanya pemilik order yang bisa membatalkan.' };
  if (o.status !== 'open') return { ok: false, error: 'Order sudah diproses.' };

  const unfilled = o.qty - o.filledQty;
  if (o.side === 'buy') {
    updateBalance(guildId, userId, o.price * unfilled); // refund dana escrow
  } else {
    rdb.addItem(userId, o.itemId, unfilled); // refund item escrow
  }
  econ.cancelOrder(orderId);
  return { ok: true, refunded: unfilled };
}

// Batalkan SEMUA order aktif milik user (refund dana + item yang di-escrow).
function cancelAllOrders(guildId, userId) {
  const orders = econ.listOpenOrdersForUser(guildId, userId);
  let cancelled = 0, refundKzc = 0, refundItems = 0;
  for (const o of orders) {
    const unfilled = o.qty - o.filledQty;
    if (o.side === 'buy') { updateBalance(guildId, userId, o.price * unfilled); refundKzc += o.price * unfilled; }
    else { rdb.addItem(userId, o.itemId, unfilled); refundItems += unfilled; }
    econ.cancelOrder(o.id);
    cancelled++;
  }
  return { ok: true, cancelled, refundKzc, refundItems };
}

function getOrderBook(guildId, itemId) {
  const agg = (rows, desc) => {
    const map = {};
    for (const r of rows) {
      const left = r.qty - r.filledQty;
      if (left <= 0) continue;
      map[r.price] = (map[r.price] || 0) + left;
    }
    const out = Object.entries(map).map(([price, qty]) => ({ price: Number(price), qty })).sort((a, b) => desc ? b.price - a.price : a.price - b.price);
    return out;
  };
  return {
    bids: agg(econ.listOpenOrders(guildId, { itemId, side: 'buy' }), true),
    asks: agg(econ.listOpenOrders(guildId, { itemId, side: 'sell' }), false),
  };
}

function getOpenOrders(guildId, userId) {
  return econ.listOpenOrdersForUser(guildId, userId);
}
function getRecentFills(guildId, itemId = null, limit = 50) {
  return econ.listRecentFills(guildId, itemId, limit);
}

module.exports = { placeOrder, cancelOrder, cancelAllOrders, getOrderBook, getOpenOrders, getRecentFills };
