// ============================================================================
// EVENT: Member keluar (GOODBYE) — v2 mendukung gaya kartu (Gaya 2) + warna custom
// ============================================================================
const { getGuildConfig } = require('../database/db');
const { sendLog } = require('../utils/serverLog');
const { buildGoodbyePayload } = require('../utils/welcomeMessage');
const config = require('../config.json');

module.exports = {
  name: 'guildMemberRemove',
  async execute(member, client) {
    const cfg = getGuildConfig(member.guild.id);

    sendLog(member.guild, {
      title: 'Member Keluar',
      color: config.errorColor,
      author: { name: member.user.tag, iconURL: member.user.displayAvatarURL() },
      fields: [{ name: 'Sisa member', value: `${member.guild.memberCount}`, inline: true }],
      footer: `User ID: ${member.id}`,
    });

    if (!cfg.goodbyeEnabled || !cfg.goodbyeChannel) return;

    const channel = member.guild.channels.cache.get(cfg.goodbyeChannel);
    if (!channel) return;

    // Gaya goodbye (embed klasik / kartu gambar) ditentukan goodbyeStyle di guild_config,
    // dibangun di utils/welcomeMessage.js supaya SAMA PERSIS dengan preview di /welcome.
    buildGoodbyePayload(member)
      .then(payload => channel.send(payload))
      .catch(err => console.error('Gagal kirim goodbye message: ', err));
  },
};
