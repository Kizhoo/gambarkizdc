const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { safeDefer } = require('../../utils/interactionHelpers');
const { fetchExternal } = require('../../utils/httpClient');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder().setName('joke').setDescription('Dapatkan lelucon random (Bahasa Inggris)'),
  async execute(interaction) {
    const lang = guildLang(interaction);
    if (!(await safeDefer(interaction))) return;

    try {
      const res = await fetchExternal('https://v2.jokeapi.dev/joke/Any?blacklistFlags=racist,sexist,religious&safe-mode');
      if (!res.ok) throw new Error(`jokeapi.dev merespons status ${res.status}`);
      const data = await res.json();

      let description;
      if (data.type === 'single') {
        description = data.joke;
      } else {
        description = `${data.setup}\n\n||${data.delivery}||`;
      }

      return interaction.editReply({ embeds: [baseEmbed().setTitle('Random Joke').setDescription(description)] });
    } catch (err) {
      console.error('[joke] Gagal ambil lelucon:', err.message);
      return interaction.editReply({ embeds: [errorEmbed(t(lang, 'fun.fetch_fail'))] }).catch(() => {});
    }
  },
};
