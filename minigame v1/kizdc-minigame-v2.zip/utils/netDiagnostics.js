const { createCanvas } = require('@napi-rs/canvas');
const { baseEmbed } = require('./embeds');
const { BROWSER_USER_AGENT } = require('./httpClient');
const { db } = require('../database/db');

const TARGETS = [
  { group: 'Core', label: 'Discord API', url: 'https://discord.com/api/v10/gateway' },
  { group: 'Core', label: 'Internet / Cloudflare', url: 'https://www.cloudflare.com/cdn-cgi/trace' },
  { group: 'Games', label: 'Tebak Gambar', url: 'https://raw.githubusercontent.com/nazedev/database/refs/heads/master/games/tebakgambar.json' },
  { group: 'Games', label: 'PokéAPI', url: 'https://pokeapi.co/api/v2/pokemon/25' },
  { group: 'Games', label: 'REST Countries', url: 'https://restcountries.com/v3.1/alpha/id?fields=name,flags,capital' },
  { group: 'Games', label: 'Kitsu', url: 'https://kitsu.io/api/edge/anime?filter[text]=naruto&page[limit]=1' },
  { group: 'Games', label: 'Open Trivia DB', url: 'https://opentdb.com/api.php?amount=1&type=boolean' },
  { group: 'Games', label: 'Dog CEO', url: 'https://dog.ceo/api/breeds/image/random' },
  { group: 'Media', label: 'NekosAPI explicit', url: 'https://api.nekosapi.com/v4/images/random?rating=explicit&limit=1' },
  { group: 'Media', label: 'nekos.best SFW', url: 'https://nekos.best/api/v2/waifu' },
  { group: 'Media', label: 'Meme API', url: 'https://meme-api.com/gimme' },
  { group: 'Media', label: 'The Cat API', url: 'https://api.thecatapi.com/v1/images/search' },
  { group: 'Tools', label: 'Open-Meteo', url: 'https://api.open-meteo.com/v1/forecast?latitude=-5.14&longitude=119.41&current=temperature_2m' },
  { group: 'Tools', label: 'GitHub API', url: 'https://api.github.com/rate_limit' },
  { group: 'Tools', label: 'npm Registry', url: 'https://registry.npmjs.org/discord.js/latest' },
  { group: 'Tools', label: 'Dictionary API', url: 'https://api.dictionaryapi.dev/api/v2/entries/en/test' },
  { group: 'Tools', label: 'CoinGecko', url: 'https://api.coingecko.com/api/v3/ping' },
  { group: 'Tools', label: 'Spaceflight News', url: 'https://api.spaceflightnewsapi.net/v4/articles/?limit=1' },
  { group: 'Music', label: 'Lavalink Discovery', url: 'https://lavalink-list.ajieblogs.eu.org/SSL' },
];

async function testEndpoint(target) {
  const started = performance.now();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 7000);
  try {
    const response = await fetch(target.url, {
      signal: controller.signal,
      headers: { 'User-Agent': BROWSER_USER_AGENT, Accept: 'application/json, text/plain, */*' },
    });
    const ms = Math.round(performance.now() - started);
    await response.body?.cancel().catch(() => {});
    if (response.ok) return { ...target, state: ms > 2500 ? 'slow' : 'ok', status: response.status, ms };
    if ([401, 403, 429].includes(response.status)) return { ...target, state: 'blocked', status: response.status, ms };
    return { ...target, state: response.status >= 500 ? 'down' : 'error', status: response.status, ms };
  } catch (error) {
    const ms = Math.round(performance.now() - started);
    const reason = error.name === 'AbortError' ? 'timeout >7s' : (error.cause?.code || error.code || error.message || 'unknown');
    return { ...target, state: 'unreachable', reason, ms };
  } finally {
    clearTimeout(timeout);
  }
}

function localChecks(client, interaction) {
  const checks = [];
  try {
    db.prepare('SELECT 1 AS ok').get();
    checks.push({ label: 'SQLite database', state: 'ok', detail: 'read/write engine ready' });
  } catch (error) {
    checks.push({ label: 'SQLite database', state: 'error', detail: error.message });
  }
  try {
    const canvas = createCanvas(8, 8);
    const buffer = canvas.toBuffer('image/png');
    checks.push({ label: 'Canvas profile', state: buffer.length > 20 ? 'ok' : 'error', detail: `${buffer.length} bytes` });
  } catch (error) {
    checks.push({ label: 'Canvas profile', state: 'error', detail: error.message });
  }
  const ping = Math.max(0, Math.round(client.ws.ping));
  checks.push({ label: 'Discord WebSocket', state: ping < 1000 ? (ping > 300 ? 'slow' : 'ok') : 'error', detail: `${ping}ms` });
  const me = interaction.guild?.members?.me;
  const required = ['ManageChannels', 'ViewChannel', 'SendMessages', 'EmbedLinks', 'ManageMessages'];
  const missing = me ? required.filter(permission => !me.permissions.has(permission)) : [];
  checks.push({ label: 'Permission game', state: missing.length ? 'error' : 'ok', detail: missing.length ? `kurang: ${missing.join(', ')}` : 'lengkap' });
  const memory = process.memoryUsage();
  const heapMb = Math.round(memory.heapUsed / 1024 / 1024);
  checks.push({ label: 'Heap Node.js', state: heapMb > 768 ? 'slow' : 'ok', detail: `${heapMb} MB` });
  return checks;
}

function icon(state) {
  return { ok: '🟢', slow: '🟡', blocked: '🟠', down: '🔴', error: '🔴', unreachable: '⚫' }[state] || '⚪';
}

function endpointLine(result) {
  if (['ok', 'slow'].includes(result.state)) return `${icon(result.state)} **${result.label}** — ${result.ms}ms`;
  if (result.state === 'blocked') return `${icon(result.state)} **${result.label}** — HTTP ${result.status} (limit/blokir)`;
  if (result.state === 'unreachable') return `${icon(result.state)} **${result.label}** — ${result.reason}`;
  return `${icon(result.state)} **${result.label}** — HTTP ${result.status || 'error'}`;
}

function percentile(numbers, value) {
  if (!numbers.length) return 0;
  const sorted = [...numbers].sort((a, b) => a - b);
  return sorted[Math.min(sorted.length - 1, Math.ceil(value * sorted.length) - 1)];
}

async function runNetDiagnostics(client, interaction) {
  const started = Date.now();
  const [results, local] = await Promise.all([
    Promise.all(TARGETS.map(testEndpoint)),
    Promise.resolve(localChecks(client, interaction)),
  ]);
  const all = [...results, ...local];
  const healthy = all.filter(item => ['ok', 'slow'].includes(item.state)).length;
  const score = Math.round((healthy / all.length) * 100);
  const latency = results.filter(item => Number.isFinite(item.ms) && ['ok', 'slow'].includes(item.state)).map(item => item.ms);
  const failures = all.filter(item => !['ok', 'slow'].includes(item.state));
  const color = score >= 90 ? '#22C55E' : score >= 70 ? '#F59E0B' : '#EF4444';

  const embed = baseEmbed().setColor(color).setTitle('🩺 KizhooBot Network & System Diagnostics')
    .setDescription(`**Health score: ${score}%** • ${healthy}/${all.length} pemeriksaan sehat\nSelesai dalam **${Date.now() - started}ms** • Median API **${percentile(latency, 0.5)}ms** • P95 **${percentile(latency, 0.95)}ms**`);

  embed.addFields({
    name: '⚙️ Sistem Lokal',
    value: local.map(item => `${icon(item.state)} **${item.label}** — ${item.detail}`).join('\n'),
    inline: false,
  });
  for (const group of ['Core', 'Games', 'Media', 'Tools', 'Music']) {
    const groupResults = results.filter(item => item.group === group);
    embed.addFields({ name: `${group === 'Core' ? '🌐' : group === 'Games' ? '🎮' : group === 'Media' ? '🖼️' : group === 'Tools' ? '🧰' : '🎵'} ${group}`, value: groupResults.map(endpointLine).join('\n'), inline: false });
  }
  embed.addFields({
    name: failures.length ? '⚠️ Diagnosis' : '✅ Diagnosis',
    value: failures.length
      ? `${failures.length} pemeriksaan bermasalah. 🟠 berarti API merespons tetapi membatasi IP/rate; ⚫ berarti koneksi gagal/timeout; 🔴 berarti provider atau konfigurasi bermasalah.`
      : 'Seluruh sistem lokal dan penyedia utama dapat diakses dengan normal.',
    inline: false,
  }).setFooter({ text: `User-Agent: KizhooBot/2.0 • ${TARGETS.length} API eksternal • timeout 7 detik` });
  return embed;
}

module.exports = { TARGETS, testEndpoint, localChecks, runNetDiagnostics };
