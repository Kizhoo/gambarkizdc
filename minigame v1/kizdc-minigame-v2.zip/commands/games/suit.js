// ============================================================================
// SUIT (Batu-Gunting-Kertas) — duel 1v1, lawan member atau lawan AI
// ----------------------------------------------------------------------------
// Beda dari catur/tictactoe/connectfour (gantian per giliran), di sini KEDUA
// pemain milih SERENTAK tiap ronde tanpa lihat pilihan lawan dulu - makanya
// setiap klik tombol dibalas EPHEMERAL (cuma pemilik yang lihat konfirmasinya),
// dan ronde baru "dibuka" di pesan utama begitu KEDUA pilihan sudah masuk.
// Format: first to 3 menang (best of 5). Reuse gameTimeControl.js buat batas
// waktu per ronde, dan gameDifficulty.js buat kekuatan AI.
// ============================================================================
const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, EmbedBuilder } = require('discord.js');
const { errorEmbed } = require('../../utils/embeds');
const config = require('../../config.json');
const { pickTimeControl, collectorOptionsFor } = require('../../utils/gameTimeControl');
const { pickDifficulty } = require('../../utils/gameDifficulty');
const { t, guildLang } = require('../../utils/i18n');

const CHOICES = {
  rock: { label: 'Batu', emoji: '🪨' },
  paper: { label: 'Kertas', emoji: '📄' },
  scissors: { label: 'Gunting', emoji: '✂️' },
};
const BEATS = { rock: 'scissors', paper: 'rock', scissors: 'paper' }; // BEATS[x] = yang dikalahkan x
const WIN_TARGET = 3; // first to 3 = menang match (best of 5)

function buildChoiceRow(lang) {
  return new ActionRowBuilder().addComponents(
    Object.entries(CHOICES).map(([key, c]) => new ButtonBuilder().setCustomId(`suit_pick_${key}`).setLabel(t(lang, 'rps.' + key)).setEmoji(c.emoji).setStyle(ButtonStyle.Secondary)),
  );
}
function randomChoice() {
  const keys = Object.keys(CHOICES);
  return keys[Math.floor(Math.random() * keys.length)];
}
// AI belajar dari pola gerakan manusia (window makin panjang & noise makin kecil makin susah),
// bukan cuma tebak acak - jadi "difficulty" beneran kerasa bedanya, bukan sekadar label.
function pickAiMove(humanHistory, difficulty) {
  if (difficulty === 'easy' || humanHistory.length < 2) return randomChoice();
  const windowSize = { medium: 3, hard: 6, extreme: 10 }[difficulty] ?? 3;
  const noise = { medium: 0.5, hard: 0.25, extreme: 0.1 }[difficulty] ?? 0.5;
  if (Math.random() < noise) return randomChoice();
  const recent = humanHistory.slice(-windowSize);
  const freq = { rock: 0, paper: 0, scissors: 0 };
  recent.forEach(m => { freq[m] = (freq[m] || 0) + 1; });
  const predicted = Object.entries(freq).sort((a, b) => b[1] - a[1])[0][0];
  return Object.keys(BEATS).find(k => BEATS[k] === predicted) || randomChoice(); // yang ngalahin `predicted`
}
function resolveRound(a, b) {
  if (a === b) return 'tie';
  return BEATS[a] === b ? 'a' : 'b';
}

module.exports = {
  subcommandOf: 'games',
  data: new SlashCommandBuilder()
    .setName('suit')
    .setDescription('Batu-Gunting-Kertas — duel first-to-3, lawan member lain atau lawan AI')
    .addUserOption(o => o.setName('lawan').setDescription('Member yang diajak main (kosongkan buat lawan AI)')),

  async execute(interaction) {
    const lang = guildLang(interaction);
    const opponent = interaction.options.getUser('lawan');
    const vsAi = !opponent;
    if (!vsAi) {
      if (opponent.bot) return interaction.reply({ embeds: [errorEmbed(t(lang, 'game.cant_bot'))], ephemeral: true });
      if (opponent.id === interaction.user.id) return interaction.reply({ embeds: [errorEmbed(t(lang, 'game.cant_self'))], ephemeral: true });
    }

    const timeControl = await pickTimeControl(interaction, { gameTitle: 'Suit', prefix: 'suit', vsAi, opponentTag: vsAi ? null : `${opponent}` });
    if (timeControl.componentInteraction) await timeControl.componentInteraction.deferUpdate().catch(() => {});
    let challengeMsg = timeControl.message;

    let difficulty = { key: 'hard', label: 'Hard' };
    if (vsAi) {
      difficulty = await pickDifficulty(challengeMsg, interaction.user.id, { gameTitle: 'Suit', prefix: 'suit' });
      if (difficulty.componentInteraction) await difficulty.componentInteraction.deferUpdate().catch(() => {});
      challengeMsg = difficulty.message;
    }

    if (!vsAi) {
      const challengeRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('suit_accept').setLabel(t(lang, 'game.accept')).setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('suit_decline').setLabel(t(lang, 'game.decline')).setStyle(ButtonStyle.Danger),
      );
      challengeMsg = await challengeMsg.edit({
        embeds: [new EmbedBuilder().setColor(config.embedColor).setTitle(t(lang, 'suit.challenge'))
          .setDescription(t(lang, 'game.challenge', { p: `${interaction.user}`, o: `${opponent}`, game: 'Suit', tc: timeControl.label }))],
        components: [challengeRow],
      });
      const decision = await challengeMsg.awaitMessageComponent({ componentType: ComponentType.Button, time: 60000 }).catch(() => null);
      if (!decision || decision.customId === 'suit_decline') {
        const text = !decision ? t(lang, 'game.challenge_timeout') : t(lang, 'game.challenge_declined', { o: `${opponent}` });
        return challengeMsg.edit({ embeds: [errorEmbed(text)], components: [] }).catch(() => {});
      }
      if (decision.user.id !== opponent.id) {
        return decision.reply({ content: t(lang, 'game.only_challenged'), ephemeral: true });
      }
      await decision.deferUpdate();
    }

    const AI_PLAYER = { id: 'AI', username: 'AI', toString: () => '🤖 AI' };
    const players = { a: interaction.user, b: vsAi ? AI_PLAYER : opponent };
    const score = { a: 0, b: 0 };
    const humanHistory = []; // riwayat gerakan manusia (buat AI belajar), cuma relevan pas vsAi
    const rounds = []; // { aChoice, bChoice, winner }
    let picks = {};
    let finished = false;
    let roundNum = 1;

    const historyLine = () => rounds.map(r => `${CHOICES[r.aChoice].emoji}${r.winner === 'a' ? '◀' : r.winner === 'b' ? '▶' : '='}${CHOICES[r.bChoice].emoji}`).join(' ') || '-';
    const buildEmbed = (statusText) => new EmbedBuilder()
      .setColor(config.embedColor)
      .setTitle(t(lang, 'suit.title') + (vsAi ? ' (vs AI)' : ''))
      .setFooter({ text: t(lang, 'game.time_per_round', { t: timeControl.label }) + (vsAi ? ` • ${t(lang, 'game.difficulty', { d: difficulty.label })}` : '') })
      .setDescription(`${players.a} **${score.a}** — **${score.b}** ${players.b}\n${t(lang, 'suit.first_to', { n: WIN_TARGET })}\n\n${t(lang, 'suit.round', { n: roundNum })}: ${statusText}\n\n${t(lang, 'suit.history')}: ${historyLine()}`);

    const message = await challengeMsg.edit({ embeds: [buildEmbed(t(lang, 'suit.pick'))], components: [buildChoiceRow(lang)] });

    const collector = message.createMessageComponentCollector(collectorOptionsFor(timeControl.ms));

    async function resolveIfReady() {
      const aReady = picks[players.a.id] != null;
      const bReady = vsAi || picks[players.b.id] != null;
      if (!aReady || !bReady) return;
      if (vsAi) picks[players.b.id] = pickAiMove(humanHistory, difficulty.key);

      const aChoice = picks[players.a.id], bChoice = picks[players.b.id];
      humanHistory.push(aChoice);
      const winner = resolveRound(aChoice, bChoice);
      if (winner === 'a') score.a++; else if (winner === 'b') score.b++;
      rounds.push({ aChoice, bChoice, winner });
      picks = {};

      const winnerLine = winner === 'tie' ? t(lang, 'suit.seri_ronde') : t(lang, 'suit.round_win', { a: CHOICES[aChoice].emoji, b: CHOICES[bChoice].emoji, p: `${players[winner]}` });

      if (score.a >= WIN_TARGET || score.b >= WIN_TARGET) {
        finished = true;
        const matchWinner = score.a >= WIN_TARGET ? players.a : players.b;
        await message.edit({ embeds: [buildEmbed(`${winnerLine}\n\n${t(lang, 'suit.match_win', { p: `${matchWinner}` })}`)], components: [] }).catch(() => {});
        collector.stop('finished');
        return;
      }
      roundNum++;
      await message.edit({ embeds: [buildEmbed(`${winnerLine}\n\n${t(lang, 'suit.next_round', { n: roundNum })}`)], components: [buildChoiceRow(lang)] }).catch(() => {});
    }

    collector.on('collect', async (i) => {
      const validUser = i.user.id === players.a.id || (!vsAi && i.user.id === players.b.id);
      if (!validUser) return i.reply({ content: t(lang, 'game.not_your_turn'), ephemeral: true }).catch(() => {});
      const choiceKey = i.customId.split('_').pop();
      if (!CHOICES[choiceKey]) return;
      const already = picks[i.user.id] != null;
      picks[i.user.id] = choiceKey;
      await i.reply({ content: t(lang, 'suit.picked', { e: CHOICES[choiceKey].emoji, label: t(lang, 'rps.' + choiceKey), wait: vsAi ? '' : t(lang, 'suit.wait') }), ephemeral: true }).catch(() => {});
      await resolveIfReady();
    });

    collector.on('end', (collected, reason) => {
      if (!finished && (reason === 'time' || reason === 'idle')) {
        message.edit({ embeds: [buildEmbed('⏰ ' + t(lang, 'game.timeout', { p: '' }).trim())], components: [] }).catch(() => {});
      }
    });
  },
};
