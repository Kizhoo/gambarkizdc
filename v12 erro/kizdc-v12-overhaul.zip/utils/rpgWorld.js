// ============================================================================
// DATA DUNIA RPG WEB — KIZHOO ADVENTURE (server-authoritative)
// ----------------------------------------------------------------------------
// Sumber kebenaran SERVER untuk gameplay web yang butuh validasi/roll di sisi
// server: katalog monster web (24), tabel drop material, konfigurasi dungeon,
// tabel rarity loot peti, dan stat mimic. File web rpg.js punya SALINAN data
// yang sama untuk render — kalau mengubah di sini, samakan juga di rpg.js.
// ============================================================================

// ---------- Monster web (24) — stat identik dengan rpg.js ----------
const MONSTERS = [
  { id: 'slime',    name: 'Slime',           tier: 'normal', level: 3,  hp: 90,   atk: 12, def: 6,  xp: 60,  gold: 25 },
  { id: 'goblin',   name: 'Goblin Scout',    tier: 'normal', level: 6,  hp: 150,  atk: 20, def: 10, xp: 110, gold: 45 },
  { id: 'wolf',     name: 'Dire Wolf',       tier: 'normal', level: 10, hp: 240,  atk: 30, def: 14, xp: 180, gold: 70 },
  { id: 'skeleton', name: 'Kerangka Hidup',  tier: 'normal', level: 12, hp: 280,  atk: 34, def: 16, xp: 220, gold: 85 },
  { id: 'orc',      name: 'Orc Warrior',     tier: 'elite',  level: 16, hp: 480,  atk: 44, def: 22, xp: 340, gold: 140 },
  { id: 'golem',    name: 'Stone Golem',     tier: 'elite',  level: 24, hp: 900,  atk: 55, def: 40, xp: 620, gold: 260 },
  { id: 'wraith',   name: 'Shadow Wraith',   tier: 'elite',  level: 32, hp: 1200, atk: 78, def: 30, xp: 940, gold: 380 },
  { id: 'minotaur', name: 'Minotaur Boss',   tier: 'boss',   level: 40, hp: 3200, atk: 105,def: 55, xp: 2200,gold: 900 },
  { id: 'dragon',   name: 'Ancient Dragon',  tier: 'boss',   level: 60, hp: 7000, atk: 160,def: 80, xp: 5200,gold: 2400 },
  { id: 'demonlord',name: 'Demon Lord',      tier: 'worldboss', level: 80, hp: 20000, atk: 240, def: 120, xp: 14000, gold: 8000 },
  { id: 'rat',      name: 'Skeletal Rat',    tier: 'normal', level: 4,  hp: 100,  atk: 15, def: 7,  xp: 75,  gold: 30 },
  { id: 'bat',      name: 'Abyss Bat',       tier: 'normal', level: 5,  hp: 120,  atk: 18, def: 8,  xp: 95,  gold: 38 },
  { id: 'spider',   name: 'Giant Spider',    tier: 'normal', level: 7,  hp: 170,  atk: 24, def: 12, xp: 140, gold: 55 },
  { id: 'snake',    name: 'Raja Ular',       tier: 'normal', level: 8,  hp: 190,  atk: 25, def: 12, xp: 150, gold: 58 },
  { id: 'imp',      name: 'Fire Imp',        tier: 'normal', level: 9,  hp: 210,  atk: 27, def: 13, xp: 160, gold: 62 },
  { id: 'turtle',   name: 'Giant Turtle',    tier: 'elite',  level: 14, hp: 420,  atk: 30, def: 28, xp: 300, gold: 120 },
  { id: 'gargoyle', name: 'Abyss Gargoyle',  tier: 'elite',  level: 18, hp: 540,  atk: 48, def: 30, xp: 380, gold: 160 },
  { id: 'yeti',     name: 'Frost Yeti',      tier: 'boss',   level: 45, hp: 4200, atk: 120,def: 60, xp: 2600,gold: 1100 },
  { id: 'hyena',    name: 'Hyena Gurun',     tier: 'normal', level: 9,  hp: 205,  atk: 26, def: 12, xp: 155, gold: 60 },
  { id: 'scorpion', name: 'Kalajengking',    tier: 'normal', level: 11, hp: 235,  atk: 30, def: 16, xp: 185, gold: 72 },
  { id: 'vulture',  name: 'Burung Nasar',    tier: 'normal', level: 13, hp: 260,  atk: 34, def: 14, xp: 215, gold: 82 },
  { id: 'mummy',    name: 'Mumi Purba',      tier: 'elite',  level: 20, hp: 560,  atk: 50, def: 26, xp: 400, gold: 170 },
  { id: 'deceased', name: 'Mayat Hidup',     tier: 'elite',  level: 26, hp: 820,  atk: 60, def: 32, xp: 640, gold: 270 },
];
const monsterById = (id) => MONSTERS.find((m) => m.id === id) || null;

// ---------- Tabel drop material per monster ----------
const MONSTER_DROPS = {
  slime:     [{ id: 'm_slime_jelly', rate: 0.7 }],
  goblin:    [{ id: 'm_goblin_ear', rate: 0.6 }],
  wolf:      [{ id: 'm_wolf_pelt', rate: 0.6 }],
  skeleton:  [{ id: 'm_bone', rate: 0.7 }],
  orc:       [{ id: 'm_orc_tusk', rate: 0.5 }],
  golem:     [{ id: 'm_golem_core', rate: 0.4 }],
  wraith:    [{ id: 'm_wraith_ecto', rate: 0.4 }],
  minotaur:  [{ id: 'm_minotaur_horn', rate: 0.5 }],
  dragon:    [{ id: 'm_dragon_scale', rate: 0.6 }],
  demonlord: [{ id: 'm_demon_heart', rate: 0.7 }],
  rat:       [{ id: 'm_rat_tail', rate: 0.6 }],
  bat:       [{ id: 'm_bat_wing', rate: 0.6 }],
  spider:    [{ id: 'm_venom_sac', rate: 0.5 }],
  snake:     [{ id: 'm_venom_sac', rate: 0.5 }],
  imp:       [{ id: 'm_imp_ember', rate: 0.5 }],
  turtle:    [{ id: 'm_turtle_shell', rate: 0.5 }],
  gargoyle:  [{ id: 'm_gargoyle_shard', rate: 0.5 }],
  yeti:      [{ id: 'm_yeti_fur', rate: 0.6 }],
  hyena:     [{ id: 'm_hyena_fang', rate: 0.5 }],
  scorpion:  [{ id: 'm_venom_sac', rate: 0.5 }],
  vulture:   [{ id: 'm_vulture_feather', rate: 0.5 }],
  mummy:     [{ id: 'm_mummy_bandage', rate: 0.5 }],
  deceased:  [{ id: 'm_bone', rate: 0.5 }],
};

// ---------- Konfigurasi dungeon (identik rpg.js) ----------
const DUNGEON = {
  bossEvery: 5,
  minFloors: 8,
  maxFloors: 20,
  floors: [
    { from: 1,  to: 4,  pool: ['slime', 'goblin', 'wolf', 'rat', 'bat'] },
    { from: 5,  to: 9,  pool: ['skeleton', 'orc', 'wolf', 'snake', 'imp', 'spider', 'hyena', 'scorpion', 'vulture'] },
    { from: 10, to: 14, pool: ['golem', 'wraith', 'orc', 'turtle', 'gargoyle', 'spider', 'mummy'] },
    { from: 15, to: 99, pool: ['golem', 'wraith', 'gargoyle', 'minotaur', 'yeti', 'deceased'] },
  ],
};
function floorPool(floor) {
  return (DUNGEON.floors.find((r) => floor >= r.from && floor <= r.to) || DUNGEON.floors[0]).pool;
}
// Validasi: monster yang diklaim dibunuh harus masuk akal untuk lantai itu
// (anggotanya ada di pool lantai, atau boss tema lantai tsb).
function monsterValidForFloor(monsterId, floor) {
  if (monsterValidForFloor.isBoss == null) monsterValidForFloor.isBoss = new Set(['minotaur', 'yeti', 'dragon', 'demonlord']);
  const pool = floorPool(floor);
  if (pool.includes(monsterId)) return true;
  return monsterValidForFloor.isBoss.has(monsterId) && (floor % DUNGEON.bossEvery === 0);
}

// ---------- Rarity loot peti (roll SERVER — anti-cheat) ----------
const TIER_ORDER = ['common', 'uncommon', 'rare', 'epic', 'legendary', 'mythic'];
// Bobot dasar per lantai (index 0 = lantai rendah, 4 = lantai tinggi).
// Semakin tinggi lantai + semakin bagus peti (bias), rarity naik.
const TIER_WEIGHTS = [
  { common: 62, uncommon: 26, rare: 9,  epic: 2.4, legendary: 0.5, mythic: 0.08 },
  { common: 46, uncommon: 30, rare: 16, epic: 5.5, legendary: 1.6, mythic: 0.25 },
  { common: 32, uncommon: 30, rare: 23, epic: 10,  legendary: 3.4, mythic: 0.6 },
  { common: 20, uncommon: 27, rare: 28, epic: 16,  legendary: 6.2, mythic: 1.2 },
  { common: 12, uncommon: 22, rare: 30, epic: 22,  legendary: 10,  mythic: 2.4 },
];
function floorBand(floor) { return Math.min(4, Math.floor((floor - 1) / 5)); }
function rollTier(floor, bias = 0) {
  const w = { ...TIER_WEIGHTS[floorBand(floor)] };
  // bias > 0 (peti perak/emas) menggeser peluang ke rarity tinggi.
  for (let i = 0; i < bias; i++) {
    for (let t = TIER_ORDER.length - 1; t > 0; t--) {
      const shift = w[TIER_ORDER[t - 1]] * 0.18;
      w[TIER_ORDER[t - 1]] -= shift;
      w[TIER_ORDER[t]] += shift;
    }
  }
  const total = TIER_ORDER.reduce((s, t) => s + w[t], 0);
  let roll = Math.random() * total;
  for (const t of TIER_ORDER) { roll -= w[t]; if (roll <= 0) return t; }
  return 'common';
}
// Gold dari peti: basis lantai + pengali tier peti.
function rollChestGold(floor, chestTier) {
  const mult = chestTier === 'gold' ? 3 : chestTier === 'silver' ? 1.8 : 1;
  const base = 24 + floor * 11 + Math.floor(Math.random() * (18 + floor * 6));
  return Math.round(base * mult);
}
// Kandidat item per rarity (equipment + ramuan bagus). Material TIDAK ikut
// roll peti — material murni drop monster untuk forge.
const LOOT_POOL = {
  common:    ['w_rusty', 'w_wood_staff', 'w_rusty_dagger', 'w_short_bow', 'a_leather', 'a_padded_vest', 'c_lucky_coin', 'p_heal_s', 'p_heal_m', 'p_mana'],
  uncommon:  ['w_steel', 'w_iron_axe', 'w_flame_wand', 'w_hunt_longbow', 'w_sharp_katana', 'a_chain', 'a_ranger_coat', 'c_swift', 'c_crit', 'c_mana_ring', 'p_heal_m', 'p_mana', 'p_weaken'],
  rare:      ['w_elven', 'w_warhammer', 'w_arcane_orb', 'w_void_orb', 'w_venom_claw', 'w_twin_fang', 'w_recurve_bow', 'w_bone_bow', 'a_guardian', 'a_plate', 'a_mithril_mail', 'c_cloak', 'c_vital', 'c_blood_pendant', 'c_thorn_bracer', 'p_heal_l', 'p_mana_l', 'p_strength', 'p_swift', 'p_regen', 'p_manareg'],
  epic:      ['w_knight_spear', 'w_dragon', 'w_frost_staff', 'w_meteor_tome', 'w_shadow_bow', 'w_night_katana', 'w_elven_bow', 'a_dragon', 'a_titan_aegis', 'a_frost_bulwark', 'c_crown', 'c_storm_charm', 'c_guardian_angel', 'p_berserk', 'p_guard', 'p_poison', 'p_venom', 'p_paralyze', 'p_elixir'],
  legendary: ['w_dragon', 'w_elven_bow', 'a_dragon', 'a_titan_aegis', 'c_crown', 'p_elixir'],
  mythic:    ['w_omega', 'w_archstaff', 'w_phantom', 'w_windseeker', 'a_omega', 'a_void_shroud', 'a_phoenix_mail', 'c_phoenix', 'c_time_hourglass'],
};
function rollChestItem(tier) {
  const pool = LOOT_POOL[tier] || LOOT_POOL.common;
  return pool[Math.floor(Math.random() * pool.length)];
}
// Peluang sebuah lantai punya peti (lantai boss selalu punya).
function floorHasChest(floor) {
  if (floor % DUNGEON.bossEvery === 0) return true;
  return Math.random() < 0.55;
}
// ---------- PET LOOT (roll SERVER) ----------
// Peluang peti berisi pet (selain gold + item biasa). Naik di lantai tinggi &
// peti bagus. Duplikat ditangani rpgServer (dikonversi jadi camilan pet).
const D = require('./rpgData');
function petChance(floor, chestTier) {
  const tierMult = chestTier === 'gold' ? 2.2 : chestTier === 'silver' ? 1.5 : 1;
  return Math.min(0.14, (0.025 + floor * 0.0022) * tierMult);
}
// Pet yang bisa keluar mengikuti rarity hasil rollTier — makin tinggi lantai
// dan makin bagus petinya, makin besar peluang rarity atas.
function rollChestPet(floor, bias = 0) {
  if (Math.random() > petChance(floor, bias >= 2 ? 'gold' : bias === 1 ? 'silver' : 'wood')) return null;
  const tier = rollTier(floor, bias + 1); // +1: pet condong 1 tingkat lebih tinggi dari item
  const pool = (D.PET_BY_RARITY[tier] || D.PET_BY_RARITY.common);
  return pool[Math.floor(Math.random() * pool.length)];
}
// Peluang salah satu peti di lantai tsb adalah mimic (naik tipis per lantai).
function mimicChance(floor) { return Math.min(0.22, 0.06 + floor * 0.005); }
function mimicStats(floor) {
  return { hp: 60 + floor * 14, atk: 14 + floor * 2, def: 4, xp: 90 + floor * 20, gold: 120 + floor * 22 };
}

module.exports = {
  MONSTERS, monsterById, MONSTER_DROPS,
  DUNGEON, floorPool, monsterValidForFloor,
  TIER_ORDER, rollTier, rollChestGold, rollChestItem, floorHasChest, mimicChance, mimicStats,
  petChance, rollChestPet,
};
