// User-Agent yang jujur dan konsisten membantu penyedia API menghubungi owner bila ada
// masalah abuse/rate-limit. Isi PUBLIC_API_CONTACT dengan URL proyek atau email operasional.
const BROWSER_USER_AGENT = `KizhooBot/2.0 (${process.env.PUBLIC_API_CONTACT || 'Discord application'})`;

// Kode error ini biasanya sesaat/transient (DNS blip, koneksi putus sebentar) dan sering
// berhasil kalau dicoba lagi. Status HTTP (403, 404, dst) TIDAK termasuk di sini karena
// itu server dengan sengaja menolak - mengulang tidak akan mengubah hasilnya.
const RETRYABLE_ERROR_CODES = ['ENOTFOUND', 'ECONNREFUSED', 'ETIMEDOUT', 'ECONNRESET', 'EAI_AGAIN'];

async function fetchExternal(url, options = {}, retries = 2) {
  const fetchOptions = {
    ...options,
    headers: {
      'User-Agent': BROWSER_USER_AGENT,
      Accept: 'application/json, text/plain, */*',
      ...(options.headers || {}),
    },
  };

  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      return await fetch(url, fetchOptions);
    } catch (err) {
      const code = err.cause?.code || err.code;
      const isRetryable = RETRYABLE_ERROR_CODES.includes(code);
      const isLastAttempt = attempt === retries;

      if (!isRetryable || isLastAttempt) {
        throw err;
      }

      const delay = 500 * (attempt + 1);
      console.warn(`[httpClient] Fetch ke ${new URL(url).hostname} gagal (${code}), coba lagi dalam ${delay}ms... (percobaan ${attempt + 1}/${retries + 1})`);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
}

module.exports = { fetchExternal, BROWSER_USER_AGENT };
