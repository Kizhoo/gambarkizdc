// ============================================================================
// AUTO-REFRESH PO TOKEN LAVALINK — dengan TOGGLE on/off (config.json)
// ----------------------------------------------------------------------------
// Perubahan baru: fitur ini sekarang bisa di-NONAKTIFKAN / AKTIFKAN lewat
// config.json -> "potoken": { "enabled": true|false } (hot-reload lewat settings).
// Kalau dinonaktifkan, scheduler tidak jalan & refresh manual juga dilewati.
// ============================================================================

const fs = require('fs');
const os = require('os');
const path = require('path');
const cron = require('node-cron');
const { spawnSync } = require('child_process');
const { EmbedBuilder } = require('discord.js');
const settings = require('./settings');

const MAX_ATTEMPTS = Number(process.env.POTOKEN_MAX_ATTEMPTS || 3);
const RETRY_DELAY_MS = Number(process.env.POTOKEN_RETRY_DELAY_MS || 5000);
const FETCH_TIMEOUT_MS = Number(process.env.POTOKEN_FETCH_TIMEOUT_MS || 15000);
const CHILD_HEAP_MB = Number(process.env.POTOKEN_CHILD_HEAP_MB || 2048);
const CHILD_TIMEOUT_MS = Number(process.env.POTOKEN_CHILD_TIMEOUT_MS || 120000);
const CRON_SCHEDULE = process.env.POTOKEN_CRON || '0 */6 * * *'; // tiap 6 jam

// ==== TOGGLE: baca dari config.json (hot-reload) ====
function isPoTokenEnabled() {
  return settings.get('potoken.enabled', true) !== false;
}

function sleep(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }

function mask(str, visible = 6) {
  if (!str) return '(kosong)';
  return str.length <= visible ? str : `${str.slice(0, visible)}...`;
}

function normalizeUrl(url) {
  const trimmed = url.trim().replace(/\/+$/, '');
  return /^https?:\/\//i.test(trimmed) ? trimmed : `http://${trimmed}`;
}

function extractErrorSummary(stderr) {
  const lines = String(stderr || '').split('\n').map((l) => l.trim()).filter(Boolean);
  if (!lines.length) return null;
  const meaningful = lines.find((l) => /error|fatal/i.test(l) && !/DeprecationWarning|ExperimentalWarning/i.test(l));
  return (meaningful || lines[lines.length - 1]).slice(0, 300);
}

function runGenerateChild() {
  const scriptPath = path.join(__dirname, '..', 'scripts', 'potoken', 'generate-token.js');
  const outFile = path.join(os.tmpdir(), `po-token-${process.pid}-${Date.now()}.json`);

  try {
    const result = spawnSync(
      process.execPath,
      [`--max-old-space-size=${CHILD_HEAP_MB}`, scriptPath, outFile],
      { encoding: 'utf8', timeout: CHILD_TIMEOUT_MS, env: process.env },
    );

    if (result.error) {
      if (result.error.code === 'ETIMEDOUT') {
        throw new Error(`Timeout ${CHILD_TIMEOUT_MS / 1000}s — request ke YouTube kemungkinan diblok/dibuat lambat oleh IP server ini. Coba isi env POTOKEN_PROXY_URL (format: http://user:pass@ip:port).`);
      }
      throw new Error(`Gagal menjalankan proses generate: ${result.error.message}`);
    }
    if (result.signal) {
      throw new Error(`Proses generate mati oleh sinyal ${result.signal} (kemungkinan OOM — naikkan POTOKEN_CHILD_HEAP_MB).`);
    }
    if (result.status !== 0) {
      const summary = extractErrorSummary(result.stderr);
      throw new Error(`Proses generate keluar dengan kode ${result.status}${summary ? `: ${summary}` : ''}`);
    }
    if (!fs.existsSync(outFile)) throw new Error('Proses generate selesai tapi tidak menghasilkan output.');
    return JSON.parse(fs.readFileSync(outFile, 'utf8'));
  } finally {
    if (fs.existsSync(outFile)) fs.unlinkSync(outFile);
  }
}

async function generatePOWithRetry(log) {
  if (process.env.POTOKEN_PROXY_URL) {
    process.env.PROXY_URL = process.env.POTOKEN_PROXY_URL;
    log('🌐 Menggunakan proxy untuk request ke YouTube.');
  }
  let lastError;
  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    try {
      log(`🔄 Percobaan ${attempt}/${MAX_ATTEMPTS} generate PO Token (heap ${CHILD_HEAP_MB}MB)...`);
      const { poToken, visitorData } = runGenerateChild();
      if (!poToken || !visitorData) throw new Error('Hasil generate kosong');
      log(`✅ PO Token: ${mask(poToken)}`);
      log(`✅ Visitor Data: ${mask(visitorData)}`);
      return { poToken, visitorData };
    } catch (err) {
      lastError = err;
      log(`❌ Percobaan ${attempt} gagal: ${err.message}`);
      if (attempt < MAX_ATTEMPTS) { log(`⏳ Tunggu ${RETRY_DELAY_MS / 1000}s...`); await sleep(RETRY_DELAY_MS); }
    }
  }
  throw new Error(`Gagal generate PO Token setelah ${MAX_ATTEMPTS} percobaan: ${lastError.message}`);
}

async function postToLavalink(poToken, visitorData) {
  if (!process.env.LAVALINK_URL || !process.env.LAVALINK_PASSWORD) {
    throw new Error('LAVALINK_URL / LAVALINK_PASSWORD belum diisi di .env — lihat .env.example.');
  }
  const base = normalizeUrl(process.env.LAVALINK_URL);
  const url = `${base}/youtube`;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { Authorization: process.env.LAVALINK_PASSWORD, 'Content-Type': 'application/json' },
      body: JSON.stringify({ poToken, visitorData }),
      signal: controller.signal,
    });
    if (res.status === 204 || res.ok) return;
    const text = await res.text().catch(() => '');
    throw new Error(`Lavalink menolak update. HTTP ${res.status}${text ? `: ${text}` : ''}`);
  } catch (err) {
    if (err.name === 'AbortError') throw new Error(`Timeout ${FETCH_TIMEOUT_MS / 1000}s saat menghubungi Lavalink di ${base}`);
    throw err;
  } finally {
    clearTimeout(timeout);
  }
}

async function notifyDiscord(client, { success, poToken, visitorData, error }) {
  const embed = success
    ? new EmbedBuilder().setTitle('✅ PO Token Lavalink berhasil diperbarui').setColor(0x2ecc71)
        .addFields({ name: 'PO Token', value: `\`${mask(poToken)}\``, inline: true }, { name: 'Visitor Data', value: `\`${mask(visitorData)}\``, inline: true }).setTimestamp()
    : new EmbedBuilder().setTitle('❌ Gagal memperbarui PO Token Lavalink').setColor(0xe74c3c)
        .setDescription(`\`\`\`${String(error).slice(0, 500)}\`\`\``).setTimestamp();

  const webhook = process.env.DISCORD_WEBHOOK_URL;
  if (webhook) {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 10000);
      await fetch(webhook, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: 'Lavalink PO Token', embeds: [embed.toJSON()] }),
        signal: controller.signal,
      });
      clearTimeout(timeout);
      return;
    } catch (e) { console.error('[PoToken] Gagal kirim notifikasi webhook:', e.message); }
  }

  const ownerId = process.env.OWNER_ID;
  if (!ownerId) return;
  try {
    const owner = await client.users.fetch(ownerId);
    await owner.send({ embeds: [embed] });
  } catch (e) { console.error('[PoToken] Gagal kirim notifikasi DM:', e.message); }
}

let refreshing = false;

async function refreshPoToken(client) {
  // ==== Cek toggle dulu ====
  if (!isPoTokenEnabled()) {
    console.log('[PoToken] Dinonaktifkan lewat config (potoken.enabled = false) — refresh dilewati.');
    return { success: false, skipped: true, reason: 'disabled' };
  }
  if (refreshing) {
    console.log('[PoToken] Refresh sebelumnya masih berjalan, lewati siklus ini.');
    return { success: false, skipped: true };
  }
  refreshing = true;
  const log = (msg) => console.log(`[PoToken] ${msg}`);
  log('Mulai proses refresh PO Token...');

  try {
    const { poToken, visitorData } = await generatePOWithRetry(log);
    await postToLavalink(poToken, visitorData);
    log('🚀 PO Token berhasil dikirim ke Lavalink.');
    await notifyDiscord(client, { success: true, poToken, visitorData });
    return { success: true, poToken, visitorData };
  } catch (err) {
    console.error(`[PoToken] 💥 Gagal total: ${err.message}`);
    await notifyDiscord(client, { success: false, error: err.message });
    return { success: false, error: err.message };
  } finally {
    refreshing = false;
  }
}

function initPoTokenScheduler(client) {
  if (!isPoTokenEnabled()) {
    console.warn('[PoToken] Dinonaktifkan (config potoken.enabled = false) — scheduler tidak dijalankan.');
    return;
  }
  if (!process.env.LAVALINK_URL || !process.env.LAVALINK_PASSWORD) {
    console.warn('[PoToken] LAVALINK_URL/LAVALINK_PASSWORD belum diisi — auto-refresh PO Token dinonaktifkan.');
    return;
  }

  cron.schedule(CRON_SCHEDULE, () => {
    refreshPoToken(client).catch((e) => console.error('[PoToken] Error tak terduga:', e));
  });
  console.log(`[PoToken] Auto-refresh dijadwalkan (cron: ${CRON_SCHEDULE}).`);

  setTimeout(() => {
    refreshPoToken(client).catch((e) => console.error('[PoToken] Error tak terduga (initial run):', e));
  }, 50000);
}

module.exports = { initPoTokenScheduler, refreshPoToken, isPoTokenEnabled };
