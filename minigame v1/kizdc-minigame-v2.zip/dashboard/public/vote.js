// ============================================================================
// HALAMAN VOTE — isi link top.gg & DiscordBotList dari /api/public/stats
// (voteLinks diturunkan backend dari Discord application ID). Kalau owner
// belum set DISCORD_CLIENT_ID, tombol diganti pesan "belum tersedia" yang
// jujur, bukan link mati ke /bot/undefined.
// ============================================================================
function $(id) { return document.getElementById(id); }

async function loadVoteLinks() {
  try {
    const res = await fetch('/api/public/stats');
    if (!res.ok) throw new Error('bad response');
    const s = await res.json();

    if (s.avatar) {
      const nav = $('navAvatar');
      if (nav) { nav.textContent = ''; nav.style.backgroundImage = `url(${s.avatar})`; nav.style.backgroundSize = 'cover'; nav.style.backgroundPosition = 'center'; }
      const f = $('footerAvatar');
      if (f) { f.textContent = ''; f.style.backgroundImage = `url(${s.avatar})`; f.style.backgroundSize = 'cover'; f.style.backgroundPosition = 'center'; }
    }
    if (s.botName && s.botName !== 'KizhooBot') {
      document.querySelectorAll('.brand-name').forEach((el) => { el.textContent = s.botName; });
    }

    setVoteButton('btnTopgg', 'topggUnavailable', s.voteLinks && s.voteLinks.topgg);
    setVoteButton('btnDbl', 'dblUnavailable', s.voteLinks && s.voteLinks.discordbotlist);
  } catch (e) {
    // Kalau API gagal total, anggap voteLinks tidak tersedia (fallback jujur).
    setVoteButton('btnTopgg', 'topggUnavailable', null);
    setVoteButton('btnDbl', 'dblUnavailable', null);
  }
}

function setVoteButton(btnId, unavailableId, url) {
  const btn = $(btnId);
  const note = $(unavailableId);
  if (!btn) return;
  if (url) {
    btn.href = url;
    if (note) note.classList.add('hidden');
  } else {
    btn.classList.add('hidden');
    if (note) note.classList.remove('hidden');
  }
}

// ===== Pengalih bahasa (sama seperti landing.js) =====
function initI18n() {
  if (!window.WebI18n) return;
  window.WebI18n.apply();
  const sel = $('langSelect');
  if (sel) sel.addEventListener('change', () => { window.WebI18n.setLang(sel.value); window.WebI18n.apply(); });
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initI18n);
else initI18n();

loadVoteLinks();
