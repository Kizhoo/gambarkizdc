// ============================================================================
// AKSI ADMIN (owner-only) — dipakai bareng oleh /botadmin DAN Luna (tool admin_action)
// ----------------------------------------------------------------------------
// Logic-nya SATU tempat di sini biar /botadmin dan Luna selalu konsisten - bukan
// dua implementasi terpisah yang bisa nyimpang. Pemanggil (command/Luna) WAJIB
// sudah verifikasi isOwner() SEBELUM manggil apa pun di sini - modul ini sendiri
// tidak cek permission, itu tanggung jawab pemanggil.
// ============================================================================
const rdb = require('../database/rpgDb');
const D = require('./rpgData');
const engine = require('./rpgEngine');

// Batas wajar - bukan buat "melindungi dari owner" (owner memang boleh set apa saja secara
// prinsip), tapi buat jaga integritas game & DB dari nilai absurd yang bisa lolos entah dari
// AI yang salah paham jumlah/skala, maupun percobaan penyalahgunaan (mis. angka yang bikin
// overflow/aneh di leaderboard, canvas, dsb). Owner yang BENERAN mau nilai di luar ini masih
// bisa pakai /botadmin buat override manual langsung ke DB.
const MAX_GOLD = 1_000_000_000;
const MAX_LEVEL = 9999;
const MAX_QTY = 999;
const MAX_REP_DELTA = 100_000;
const MAX_POINTS = 9999;
function clamp(n, min, max) { return Math.max(min, Math.min(max, Math.round(Number(n) || 0))); }

function adminAddGold(userId, guildId, amount) {
  if (!rdb.getCharacter(userId)) return { ok: false, error: 'User itu belum punya karakter RPG.' };
  const wallet = rdb.addGold(userId, guildId, clamp(amount, -MAX_GOLD, MAX_GOLD));
  return { ok: true, newBalance: wallet.balance, amount };
}
// Aksi MASSAL - beda dari adminAddGold yang cuma 1 target. Dipakai buat permintaan kayak
// "tambahkan semua user disini gold 100". SEBELUM ini tidak ada jalur buat request semacam ini,
// jadi Luna diam-diam jatuh ke fallback targetUserId=diri sendiri (bug: cuma pemanggil yang
// kegold-in, bukan semua orang, tanpa ada error/peringatan apa pun).
// `guild` di sini harus objek Guild discord.js asli (butuh .members.fetch()), BUKAN cuma ID string.
async function adminAddGoldAllInGuild(guild, amount) {
  if (!guild || typeof guild.members?.fetch !== 'function') return { ok: false, error: 'Konteks guild tidak valid buat aksi massal ini.' };
  const safeAmount = clamp(amount, -MAX_GOLD, MAX_GOLD);
  const charUserIds = new Set(rdb.getAllCharacterUserIds());
  if (!charUserIds.size) return { ok: true, affected: 0, amount: safeAmount, note: 'Belum ada satupun user yang punya karakter RPG.' };
  let members;
  try { members = await guild.members.fetch(); }
  catch (e) { return { ok: false, error: `Gagal ambil daftar member guild: ${e.message}` }; }
  let affected = 0;
  for (const [memberId] of members) {
    if (!charUserIds.has(memberId)) continue; // member ada, tapi belum punya karakter RPG - skip
    rdb.addGold(memberId, guild.id, safeAmount);
    affected++;
  }
  return { ok: true, affected, amount: safeAmount, totalCharactersEverywhere: charUserIds.size };
}
function adminSetGold(userId, guildId, amount) {
  if (!rdb.getCharacter(userId)) return { ok: false, error: 'User itu belum punya karakter RPG.' };
  const current = rdb.getWallet(userId, guildId);
  const target = clamp(amount, 0, MAX_GOLD);
  const wallet = rdb.addGold(userId, guildId, target - current.gold);
  return { ok: true, newBalance: wallet.balance };
}
// Buat karakter untuk user LAIN (owner-only override - dipanggil dari admin_action, BUKAN dari
// create_character biasa yang cuma buat diri sendiri). SEBELUM ini tidak ada jalur seperti ini
// sama sekali: create_character SELALU pakai ID pemanggil sendiri walau owner eksplisit minta
// buatkan buat orang lain, jadi hasilnya selalu ngecek/ubah karakter OWNER sendiri sementara pesan
// balasannya (dikarang model) menyebut-nyebut nama target - itu sumber bug "sudah punya karakter"
// yang kontradiktif sama pengecekan sebelumnya.
function adminCreateCharacterFor(targetUserId, classKey) {
  const D = require('./rpgData');
  if (rdb.getCharacter(targetUserId)) return { ok: false, error: 'User itu sudah punya karakter RPG, tidak bisa dibuatkan lagi.' };
  const key = String(classKey || '').toLowerCase().trim();
  if (!D.CLASSES[key]) return { ok: false, error: `classKey tidak valid. Pilihan: ${D.CLASS_KEYS.join(', ')}` };
  const char = rdb.createCharacter(targetUserId, key);
  rdb.updateCharacter(targetUserId, { skillPoints: 1 });
  return { ok: true, class: D.CLASSES[key].name, level: char.level, rank: char.rankKey, skillPoints: 1 };
}
function adminSetLevel(userId, level, guildId) {
  const char = rdb.getCharacter(userId);
  if (!char) return { ok: false, error: 'User itu belum punya karakter RPG.' };
  level = clamp(level, 1, MAX_LEVEL);
  const res = engine.setLevel(userId, level, guildId);
  return { ok: true, level: res.level };
}
function adminSetRank(userId, rankKey) {
  const char = rdb.getCharacter(userId);
  if (!char) return { ok: false, error: 'User itu belum punya karakter RPG.' };
  const key = String(rankKey || '').toUpperCase();
  if (D.RANK_INDEX[key] == null) return { ok: false, error: `Rank tidak valid. Pilihan: ${D.RANKS.map(r => r.key).join(', ')}` };
  const updated = rdb.updateCharacter(userId, { rankKey: key });
  return { ok: true, rank: updated.rankKey };
}
function adminAddReputation(userId, amount) {
  const char = rdb.getCharacter(userId);
  if (!char) return { ok: false, error: 'User itu belum punya karakter RPG.' };
  const updated = rdb.incCharacter(userId, 'reputation', clamp(amount, -MAX_REP_DELTA, MAX_REP_DELTA));
  return { ok: true, reputation: updated.reputation };
}
function adminGiveItem(userId, itemId, qty = 1) {
  const items = require('./rpgItems');
  if (!items.getItem(itemId)) return { ok: false, error: `Item ID tidak dikenal. Pilihan: ${Object.keys(items.ITEMS).join(', ')}` };
  if (!rdb.getCharacter(userId)) return { ok: false, error: 'User itu belum punya karakter RPG.' };
  qty = clamp(qty, 1, MAX_QTY);
  rdb.addItem(userId, itemId, qty);
  return { ok: true, item: items.getItem(itemId).name, qty };
}

function adminAddXp(userId, amount, guildId) {
  if (!rdb.getCharacter(userId)) return { ok: false, error: 'User itu belum punya karakter RPG.' };
  // guildId disertakan supaya mirror leveling per-guild ikut disinkronkan (biar /rank
  // & leaderboard tidak menampilkan level lama yang "ganda").
  const res = engine.addExp(userId, clamp(amount, -1_000_000, 1_000_000), guildId);
  return { ok: true, level: res.toLevel, fromLevel: res.fromLevel, toLevel: res.toLevel, xpIntoLevel: res.xpIntoLevel, xpForNext: res.xpForNext, leveledUp: res.leveledUp };
}
function adminAddPoints(userId, kind, amount) {
  const char = rdb.getCharacter(userId);
  if (!char) return { ok: false, error: 'User itu belum punya karakter RPG.' };
  const field = kind === 'skill' ? 'skillPoints' : 'statPoints';
  const delta = clamp(amount, -MAX_POINTS, MAX_POINTS);
  const updated = rdb.updateCharacter(userId, { [field]: Math.max(0, char[field] + delta) });
  return { ok: true, [field]: updated[field] };
}
function adminRemoveItem(userId, itemId, qty = 1) {
  const items = require('./rpgItems');
  if (!items.getItem(itemId)) return { ok: false, error: `Item ID tidak dikenal. Pilihan: ${Object.keys(items.ITEMS).join(', ')}` };
  qty = clamp(qty, 1, MAX_QTY);
  if (!rdb.removeItem(userId, itemId, qty)) return { ok: false, error: 'User tidak punya item itu sebanyak itu di tasnya.' };
  return { ok: true, item: items.getItem(itemId).name, qty };
}
// DESTRUKTIF & PERMANEN - hapus karakter beserta semua data terkait (skill/inventory/quest
// progress/party). Dipakai kalau user minta reset total (mis. salah pilih class dari awal).
function adminResetCharacter(userId) {
  if (!rdb.getCharacter(userId)) return { ok: false, error: 'User itu memang belum punya karakter RPG.' };
  rdb.deleteCharacterCascade(userId);
  return { ok: true, reset: true };
}
// Lihat profil LENGKAP user (buat owner cek-cek, bukan buat ditampilkan mentah-mentah ke user lain).
function adminViewUser(userId, guildId) {
  const char = rdb.getCharacter(userId);
  if (!char) return { ok: false, error: 'User itu belum punya karakter RPG.' };
  const wallet = rdb.getWallet(userId, guildId);
  const inv = rdb.getInventory(userId);
  return {
    ok: true, level: char.level, xp: char.xp, class: char.className, rank: char.rankKey,
    reputation: char.reputation, gold: wallet.gold, silver: wallet.silver, copper: wallet.copper,
    statPoints: char.statPoints, skillPoints: char.skillPoints,
    quests: char.questsCompleted, monsters: char.monstersKilled, wins: char.wins,
    equipped: { weapon: char.equipWeapon, armor: char.equipArmor, accessory: char.equipAccessory },
    inventoryCount: inv.length,
  };
}

module.exports = {
  adminAddGold, adminAddGoldAllInGuild, adminSetGold, adminSetLevel, adminSetRank, adminAddReputation, adminGiveItem,
  adminAddXp, adminAddPoints, adminRemoveItem, adminResetCharacter, adminViewUser, adminCreateCharacterFor,
};
