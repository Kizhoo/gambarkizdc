// ============================================================================
// SPRITE PIXEL-ART RPG (digambar programatik di canvas, gaya "pixel²")
// ----------------------------------------------------------------------------
// Tiap sprite = array baris string; tiap huruf = warna dari PALETTE. Spasi/'.'
// = transparan. Digambar sebagai kotak-kotak besar (scale) supaya tampak pixel.
// Tidak butuh aset gambar eksternal → konsisten, instan, ringan.
//
// drawSprite(ctx, key, x, y, scale, { flip, tint }) — gambar sprite.
// spriteWidth/Height(key, scale) — ukuran.
// ============================================================================

const PALETTE = {
  ' ': null, '.': null,
  K: '#0b0b12', // outline hitam
  W: '#f8fafc', E: '#0f172a', // putih mata / pupil
  R: '#e23636', r: '#a11d1d', // merah
  G: '#3fbf5f', g: '#248a41', // hijau
  B: '#3b82f6', b: '#1e40af', // biru
  P: '#a855f7', p: '#6d28d9', // ungu
  Y: '#f2c94c', y: '#c9992e', // kuning
  O: '#e08a3c', o: '#a75f22', // oranye
  S: '#9aa4b2', s: '#5b6472', // abu batu
  N: '#7b4a2d', n: '#472a19', // coklat
  C: '#4de1c1', c: '#2bb39a', // cyan
  M: '#4b5563', m: '#1f2937', // abu gelap
  T: '#f4c8a0', t: '#d89f74', // kulit
  H: '#e11d48', // merah darah/HP
  L: '#f5f5f5', // highlight
};

// ---- Monster & hero (16 kolom, tinggi bervariasi) ----
const SPRITES = {
  // Slime — blob hijau lucu
  slime: [
    '                ',
    '                ',
    '                ',
    '     KKKKKK     ',
    '   KKGGGGGGKK   ',
    '  KGGGGGGGGGGK  ',
    ' KGGLGGGGGGLGGK ',
    ' KGGGGGGGGGGGGK ',
    ' KGWEGGGGGGWEGK ',
    ' KGWWGGGGGGWWGK ',
    ' KGGGGGGGGGGGGK ',
    ' KGGGGggggGGGGK ',
    '  KGGGggggGGGGK ',
    '  KKGGGGGGGGKK  ',
    '   KKKKKKKKKK   ',
    '                ',
  ],
  // Goblin — humanoid hijau bertelinga runcing
  goblin: [
    '                ',
    '     KKKK       ',
    '   KKgggKK  K   ',
    '  KgggggggK KK  ',
    '  KgGWEgWEgKgK  ',
    '  KgggnnngggK   ',
    '   Kgg  ggK     ',
    '  K KgggggK K   ',
    '  Kn KggK nK    ',
    '  KnnNgggNnnK   ',
    '   K NgggN K    ',
    '     ggggg      ',
    '    Kgg ggK     ',
    '    Kn   nK     ',
    '   KnK   KnK    ',
    '   KK     KK    ',
  ],
  // Wolf — serigala abu
  wolf: [
    '                ',
    ' K K            ',
    ' KsKK    KKKK   ',
    ' KsssKKKssssK   ',
    ' KsWEsssssssssK ',
    'KssssssssssssssK',
    'KsssKssssssssssK',
    ' KsssssssssssssK',
    '  KssssssssssssK',
    '   KsssssssssssK',
    '   Ks Kss Ksss K',
    '   Ks Kss Kss   ',
    '   KK KK  KK    ',
    '                ',
    '                ',
    '                ',
  ],
  // Golem — batu kotak
  golem: [
    '                ',
    '    KKKKKKKK    ',
    '   KSSSSSSSSK   ',
    '   KSsWEssWEK   ',
    '   KSSSSSSSSK   ',
    '   KSSssssSSK   ',
    '  KKSSSSSSSSKK  ',
    ' KSSKSSSSSSKSSK ',
    ' KSSKSSSSSSKSSK ',
    ' KSSKSssssSKSSK ',
    ' KKKKSSSSSSKKKK ',
    '    KSSKKSSK    ',
    '    KSSK KSSK   ',
    '    KSK   KSK   ',
    '    KKK   KKK   ',
    '                ',
  ],
  // Wraith — arwah ungu
  wraith: [
    '      KKKK      ',
    '    KKppppKK    ',
    '   KpPPPPPPpK   ',
    '  KpPWEPPWEPpK  ',
    '  KpPPPPPPPPpK  ',
    '  KpPPPPPPPPpK  ',
    '  KpPPPPPPPPpK  ',
    '   KpPPPPPPpK   ',
    '   KpPPPPPPpK   ',
    '   KpPPPPPPpK   ',
    '  KpPPpPPpPPpK  ',
    ' KpPP KpPK PPpK ',
    ' Kp K KpPK K pK ',
    '  K   KpK    K  ',
    '       K        ',
    '                ',
  ],
  // Minotaur — banteng coklat bertanduk
  minotaur: [
    '                ',
    '  W          W  ',
    '  WK  KKKK  KW  ',
    '  WKKNnnnnNKKW  ',
    '   KNNWEWEnNK   ',
    '   KNnnOOnnNK   ',
    '   KNNnnnnNNK   ',
    '    KKNNNNKK    ',
    '   KNNNNNNNNK   ',
    '  KNNrNNNNrNNK  ',
    '  KNNNNNNNNNNK  ',
    '  KNNK NN KNNK  ',
    '   KK KNNK KK   ',
    '     KnK KnK    ',
    '     KK  KK     ',
    '                ',
  ],
  // Dragon — naga merah bersayap
  dragon: [
    '            KK  ',
    '   KK      KrrK ',
    '  KrrK    KrRRK ',
    ' KrRRrKKKKrRRrK ',
    ' KrRRRRRRRRRRRK ',
    'KrRRWERRRRWERRrK',
    'KrRRRRRRRRRRRRRK',
    'KrRRRYYYYRRRRRrK',
    ' KrRRRRRRRRRRrK ',
    ' KKrRRRRRRRRrKK ',
    '  KKrRRRRRRrKK  ',
    '  KrrK KK KrrK  ',
    '  KrK  KK  KrK  ',
    '  KK   KK   KK  ',
    '       KK       ',
    '                ',
  ],
  // Demon Lord — bos merah gelap bertanduk
  demonlord: [
    '  K          K  ',
    '  rK        Kr  ',
    '  rrKKKKKKKKrr  ',
    '  KrrRRRRRRrrK  ',
    '  KRRHWEWEHRRK  ',
    '  KRRRrHHrRRRK  ',
    '  KRRHHHHHHRRK  ',
    '  KKRRRRRRRRKK  ',
    ' KrRRRRRRRRRRrK ',
    ' KrRRKRRRRKRRrK ',
    ' KrRRKRRRRKRRrK ',
    ' KKrRRRRRRRRrKK ',
    '   KrrK  KrrK   ',
    '   KrK    KrK   ',
    '   KK      KK   ',
    '                ',
  ],
  // Hero base (tinted per class via `tint`) — kesatria kecil
  hero: [
    '      KKKK      ',
    '    KKTTTTKK    ',
    '    KTTTTTTK    ',
    '    KTWETWEK    ',
    '    KTTTTTTK    ',
    '    KKTTTTKK    ',
    '   KBBBBBBBBK   ',
    '  KBBBLBBLBBBK  ',
    '  KBBBBBBBBBBK  ',
    '  KTKBBBBBBKTK  ',
    '  KTKBBBBBBKTK  ',
    '   KBBBKKBBBK   ',
    '   KBBK  KBBK   ',
    '   KNNK  KNNK   ',
    '   KKK    KKK   ',
    '                ',
  ],
};

// Tint: ganti warna biru default hero (B/b/L) jadi warna class.
function tintPaletteFor(tint) {
  if (!tint) return PALETTE;
  const p = { ...PALETTE };
  const { r, g, b } = hexToRgb(tint);
  p.B = tint;
  p.b = `rgb(${Math.round(r * 0.6)},${Math.round(g * 0.6)},${Math.round(b * 0.6)})`;
  p.L = `rgb(${Math.min(255, r + 60)},${Math.min(255, g + 60)},${Math.min(255, b + 60)})`;
  return p;
}
function hexToRgb(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex || '');
  if (!m) return { r: 59, g: 130, b: 246 };
  const n = parseInt(m[1], 16);
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}

function getSprite(key) { return SPRITES[key] || SPRITES.slime; }
function spriteCols(key) { return getSprite(key)[0].length; }
function spriteRows(key) { return getSprite(key).length; }
function spriteWidth(key, scale) { return spriteCols(key) * scale; }
function spriteHeight(key, scale) { return spriteRows(key) * scale; }

// Gambar sprite di (x,y) sudut kiri-atas. flip = cermin horizontal.
function drawRows(ctx, rows, x, y, scale, pal, flip) {
  const cols = rows[0].length;
  ctx.save();
  ctx.imageSmoothingEnabled = false;
  for (let row = 0; row < rows.length; row++) {
    const line = rows[row];
    for (let col = 0; col < line.length; col++) {
      const ch = line[col];
      const color = pal[ch];
      if (!color) continue;
      const px = flip ? x + (cols - 1 - col) * scale : x + col * scale;
      ctx.fillStyle = color;
      ctx.fillRect(px, y + row * scale, scale, scale);
    }
  }
  ctx.restore();
}
function drawSprite(ctx, key, x, y, scale = 6, { flip = false, tint = null } = {}) {
  drawRows(ctx, getSprite(key), x, y, scale, tintPaletteFor(tint), flip);
}

// ---------- HERO KUSTOM (rambut/ekspresi/baju/celana/sepatu) — /rpg customize + PvP ----------
// Turunan dari `hero` + 2 baris kosong di ATAS (ruang buat rambut). Sprite `hero` asli yang
// dipakai battle PvE (rpgCard.renderBattleScene, sudah teruji tests/battle_test.js) TIDAK
// disentuh sama sekali - ini array baru terpisah, jadi nol risiko regresi ke battle PvE.
// Baris sepatu (K polos di sprite asli) diganti karakter 'F' khusus (dedicated) supaya warna
// sepatu bisa direcolor independen dari border hitam 'K' yang dipakai di seluruh sprite lain.
const HERO_CUSTOM_BASE = [
  '                ',
  '                ',
  ...SPRITES.hero.slice(0, 14),
  '   FFF    FFF   ',
  SPRITES.hero[15],
];

// Overlay rambut: cuma diisi di baris yang SUDAH diverifikasi kosong di sprite dasar (2 baris
// atas + margin kolom 0-3/12-15 di baris kepala), jadi tidak pernah menimpa pixel wajah/badan.
const HAIR_OVERLAYS = {
  bald: null,
  short: ['      DDDD      ', '    DDDDDDDD    '],
  mohawk: ['       DD       ', '      DDDD      '],
  long: [
    '      DDDD      ', '    DDDDDDDD    ',
    '  D          D  ', '  D          D  ', '  D          D  ',
    '  D          D  ', '  D          D  ', '  D          D  ',
  ],
};

// Ekspresi = kombinasi alis (baris 4) + mulut (baris 6); null = pakai default (polos).
// netral=tanpa alis/mulut, senyum=mulut saja, garang=alis+cemberut, tegas=alis tanpa mulut.
const EXPRESSION_ROWS = {
  netral: { brow: null, mouth: null },
  senyum: { brow: null, mouth: '    KTTKKTTK    ' },
  garang: { brow: '    KKTTTTKK    ', mouth: '    KTKKKKTK    ' },
  tegas: { brow: '    KKTTTTKK    ', mouth: null },
};

function composeCustomHero({ hairStyle = 'short', expression = 'netral' } = {}) {
  const rows = [...HERO_CUSTOM_BASE];
  const expr = EXPRESSION_ROWS[expression] || EXPRESSION_ROWS.netral;
  if (expr.brow) rows[4] = expr.brow;
  if (expr.mouth) rows[6] = expr.mouth;
  const hair = HAIR_OVERLAYS[hairStyle];
  if (hair) {
    for (let i = 0; i < hair.length; i++) {
      const base = rows[i];
      let merged = '';
      for (let c = 0; c < 16; c++) merged += (hair[i][c] !== ' ' ? hair[i][c] : base[c]);
      rows[i] = merged;
    }
  }
  return rows;
}
function shade(hex, factor) {
  const { r, g, b } = hexToRgb(hex);
  const c = (v) => Math.max(0, Math.min(255, Math.round(v * factor)));
  return `rgb(${c(r)},${c(g)},${c(b)})`;
}
function customPaletteFor({ hairColor, outfitColor, pantsColor, shoesColor } = {}) {
  const p = { ...PALETTE };
  if (hairColor) p.D = hairColor;
  if (outfitColor) { p.B = outfitColor; p.b = shade(outfitColor, 0.6); p.L = shade(outfitColor, 1.3); }
  if (pantsColor) { p.N = pantsColor; p.n = shade(pantsColor, 0.6); }
  p.F = shoesColor || PALETTE.K;
  return p;
}
// customization: { hairStyle, hairColor, expression, outfitColor, pantsColor, shoesColor }
function drawCustomHero(ctx, x, y, scale, customization = {}, { flip = false } = {}) {
  drawRows(ctx, composeCustomHero(customization), x, y, scale, customPaletteFor(customization), flip);
}
function customHeroWidth(scale) { return 16 * scale; }
function customHeroHeight(scale) { return HERO_CUSTOM_BASE.length * scale; }

// Peta monster id -> sprite (beberapa monster berbagi archetype dgn tint beda).
const MONSTER_SPRITE = {
  slime: { key: 'slime' }, goblin: { key: 'goblin' }, wolf: { key: 'wolf' },
  orc: { key: 'goblin', tint: '#2f855a' }, golem: { key: 'golem' }, wraith: { key: 'wraith' },
  minotaur: { key: 'minotaur' }, dragon: { key: 'dragon' }, demonlord: { key: 'demonlord' },
};
function monsterSprite(id) { return MONSTER_SPRITE[id] || { key: 'slime' }; }

module.exports = { PALETTE, SPRITES, drawSprite, spriteWidth, spriteHeight, spriteCols, spriteRows, monsterSprite, hexToRgb, drawCustomHero, customHeroWidth, customHeroHeight };
