const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, EmbedBuilder } = require('discord.js');
const config = require('../../config.json');
const { t, guildLang } = require('../../utils/i18n');

const QUESTIONS = [
  { id: { a: 'Bisa terbang', b: 'Bisa membaca pikiran orang lain' }, en: { a: 'Could fly', b: "Could read other people's minds" } },
  { id: { a: 'Selalu telat 10 menit', b: 'Selalu terlalu awal 1 jam' }, en: { a: 'Always be 10 minutes late', b: 'Always be 1 hour early' } },
  { id: { a: 'Hidup tanpa internet seumur hidup', b: 'Hidup tanpa AC/kipas seumur hidup' }, en: { a: 'Live without the internet forever', b: 'Live without AC/fan forever' } },
  { id: { a: 'Makan makanan favorit tapi dingin selamanya', b: 'Makan makanan biasa tapi selalu hangat' }, en: { a: 'Eat your favorite food cold forever', b: 'Eat plain food but always warm' } },
  { id: { a: 'Punya 100 juta sekarang', b: 'Punya 10 juta per bulan seumur hidup' }, en: { a: 'Have 100 million now', b: 'Have 10 million a month for life' } },
  { id: { a: 'Bisa berbicara semua bahasa di dunia', b: 'Bisa bermain semua alat musik' }, en: { a: 'Speak every language in the world', b: 'Play every musical instrument' } },
  { id: { a: 'Kehilangan semua foto lama', b: 'Kehilangan semua kontak nomor HP' }, en: { a: 'Lose all your old photos', b: 'Lose all your phone contacts' } },
  { id: { a: 'Jadi orang terkenal tapi hidup sulit', b: 'Jadi orang biasa tapi hidup tenang' }, en: { a: 'Be famous but live a hard life', b: 'Be ordinary but live peacefully' } },
  { id: { a: 'Selalu menang tapi tidak ada yang percaya', b: 'Selalu kalah tapi selalu didukung' }, en: { a: 'Always win but nobody believes you', b: 'Always lose but always be supported' } },
  { id: { a: 'Bekerja sendiri seumur hidup', b: 'Selalu bekerja dalam tim seumur hidup' }, en: { a: 'Work alone for life', b: 'Always work in a team for life' } },
  { id: { a: 'Bisa mengulang satu hari berkali-kali', b: 'Bisa melompat 1 tahun ke depan' }, en: { a: 'Relive one day over and over', b: 'Jump 1 year into the future' } },
  { id: { a: 'Wifi cepat tapi kuota terbatas', b: 'Wifi lambat tapi kuota unlimited' }, en: { a: 'Fast wifi but limited data', b: 'Slow wifi but unlimited data' } },
  { id: { a: 'Jago masak tapi tidak bisa makan enak', b: 'Tidak bisa masak tapi selalu ditraktir' }, en: { a: "Be a great cook but can't eat well", b: "Can't cook but always get treated" } },
  { id: { a: 'Liburan ke gunung', b: 'Liburan ke pantai' }, en: { a: 'Vacation in the mountains', b: 'Vacation at the beach' } },
  { id: { a: 'Nonton film di bioskop', b: 'Nonton film di rumah dengan cemilan lengkap' }, en: { a: 'Watch a movie at the cinema', b: 'Watch a movie at home with full snacks' } },
];

module.exports = {
  subcommandOf: 'games',
  data: new SlashCommandBuilder().setName('wouldurather').setDescription('Would you rather - voting rame-rame pilih salah satu opsi'),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const question = QUESTIONS[Math.floor(Math.random() * QUESTIONS.length)];
    const q = lang === 'id' ? question.id : question.en;
    const votes = new Map();
    const votesWord = () => t(lang, 'game.votes', { n: '' }).trim();

    const buildEmbed = () => {
      const votesA = [...votes.values()].filter(v => v === 'a').length;
      const votesB = [...votes.values()].filter(v => v === 'b').length;
      const total = votesA + votesB;
      const pctA = total > 0 ? Math.round((votesA / total) * 100) : 0;
      const pctB = total > 0 ? Math.round((votesB / total) * 100) : 0;

      return new EmbedBuilder()
        .setColor(config.embedColor)
        .setTitle('Would You Rather?')
        .setDescription(
          `**A.** ${q.a}\n${t(lang, 'game.votes', { n: votesA })} (${pctA}%)\n\n` +
          `**B.** ${q.b}\n${t(lang, 'game.votes', { n: votesB })} (${pctB}%)\n\n` +
          `${t(lang, 'game.click_vote')} ${t(lang, 'bal.total')}: ${total} ${votesWord()}. ${t(lang, 'game.time_30')}`
        );
    };

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('wyr_a').setLabel(t(lang, 'game.pick_a')).setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('wyr_b').setLabel(t(lang, 'game.pick_b')).setStyle(ButtonStyle.Success),
    );

    await interaction.reply({ embeds: [buildEmbed()], components: [row] });
    const message = await interaction.fetchReply();

    const collector = message.createMessageComponentCollector({ componentType: ComponentType.Button, time: 30000 });

    collector.on('collect', async i => {
      votes.set(i.user.id, i.customId === 'wyr_a' ? 'a' : 'b');
      await i.update({ embeds: [buildEmbed()], components: [row] });
    });

    collector.on('end', () => {
      const disabledRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('wyr_a').setLabel(t(lang, 'game.pick_a')).setStyle(ButtonStyle.Primary).setDisabled(true),
        new ButtonBuilder().setCustomId('wyr_b').setLabel(t(lang, 'game.pick_b')).setStyle(ButtonStyle.Success).setDisabled(true),
      );
      message.edit({ embeds: [buildEmbed()], components: [disabledRow] }).catch(() => {});
    });
  },
};
