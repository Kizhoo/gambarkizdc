const { SlashCommandBuilder, AttachmentBuilder } = require('discord.js');
const { baseEmbed, successEmbed, errorEmbed } = require('../../utils/embeds');
const { safeDefer } = require('../../utils/interactionHelpers');
const { renderProfileCard } = require('../../utils/profileCard');
const { getUserProfile, setUserProfile, getUser, getEconomy, getInventory, getMarriage, getBirthday } = require('../../database/db');
const levelEngine = require('../../utils/levelEngine');
const { t, guildLang } = require('../../utils/i18n');

const targetOption = (o) => o.setName('target').setDescription('Member yang ingin dilihat');

function getBadges(user, member, registration, level, inventory, lang) {
  return [
    user.bot && t(lang, 'prof2.badge_bot'),
    user.id === member.guild.ownerId && t(lang, 'prof2.badge_owner'),
    member.permissions.has('Administrator') && t(lang, 'prof2.badge_admin'),
    member.premiumSinceTimestamp && t(lang, 'prof2.badge_booster'),
    registration && t(lang, 'prof2.badge_registered'),
    level.level >= 10 && t(lang, 'prof2.badge_lvl10'),
    level.level >= 25 && t(lang, 'prof2.badge_veteran'),
    inventory.length >= 10 && t(lang, 'prof2.badge_collector'),
    Date.now() - user.createdTimestamp > 1000 * 60 * 60 * 24 * 365 * 5 && t(lang, 'prof2.badge_senior'),
  ].filter(Boolean);
}

async function collectData(interaction, user) {
  const member = await interaction.guild.members.fetch(user.id).catch(() => null);
  // SATU sumber kebenaran level (RPG global) — bukan tabel leveling lama.
  const level = levelEngine.getLevel(user.id);
  return {
    user,
    member,
    guild: interaction.guild,
    profile: getUserProfile(user.id),
    registration: getUser(user.id),
    level,
    economy: getEconomy(interaction.guild.id, user.id),
    inventory: getInventory(interaction.guild.id, user.id),
    marriage: getMarriage(interaction.guild.id, user.id),
    birthday: getBirthday(interaction.guild.id, user.id),
  };
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('profile')
    .setDescription('Profil member lengkap dengan kartu canvas')
    .addSubcommand(s => s.setName('card').setDescription('Tampilkan kartu profil canvas premium').addUserOption(targetOption))
    .addSubcommand(s => s.setName('overview').setDescription('Tampilkan seluruh informasi profil').addUserOption(targetOption))
    .addSubcommand(s => s.setName('badges').setDescription('Lihat badge dan pencapaian member').addUserOption(targetOption))
    .addSubcommand(s => s.setName('set-bio').setDescription('Atur bio di kartu profil')
      .addStringOption(o => o.setName('bio').setDescription('Bio, maksimal 160 karakter').setRequired(true).setMaxLength(160)))
    .addSubcommand(s => s.setName('set-color').setDescription('Atur warna aksen profil')
      .addStringOption(o => o.setName('hex').setDescription('Warna hex, contoh #5865F2').setRequired(true).setMaxLength(7)))
    .addSubcommand(s => s.setName('set-pronouns').setDescription('Atur pronouns/panggilan')
      .addStringOption(o => o.setName('teks').setDescription('Maksimal 32 karakter').setRequired(true).setMaxLength(32)))
    .addSubcommand(s => s.setName('set-location').setDescription('Atur lokasi publik')
      .addStringOption(o => o.setName('lokasi').setDescription('Maksimal 40 karakter').setRequired(true).setMaxLength(40)))
    .addSubcommand(s => s.setName('reset').setDescription('Reset kustomisasi profil')),

  cooldown: 5,
  async execute(interaction) {
    const lang = guildLang(interaction);
    const sub = interaction.options.getSubcommand();
    if (sub.startsWith('set-') || sub === 'reset') {
      if (sub === 'set-bio') setUserProfile(interaction.user.id, { bio: interaction.options.getString('bio') });
      if (sub === 'set-pronouns') setUserProfile(interaction.user.id, { pronouns: interaction.options.getString('teks') });
      if (sub === 'set-location') setUserProfile(interaction.user.id, { location: interaction.options.getString('lokasi') });
      if (sub === 'set-color') {
        const color = interaction.options.getString('hex').toUpperCase();
        if (!/^#[0-9A-F]{6}$/.test(color)) return interaction.reply({ embeds: [errorEmbed(t(lang, 'prof2.color_fmt'))], ephemeral: true });
        setUserProfile(interaction.user.id, { color });
      }
      if (sub === 'reset') setUserProfile(interaction.user.id, { bio: '', color: '#5865F2', pronouns: '', location: '' });
      return interaction.reply({ embeds: [successEmbed(t(lang, 'prof2.updated'))], ephemeral: true });
    }

    const target = interaction.options.getUser('target') || interaction.user;
    const data = await collectData(interaction, target);
    if (!data.member) return interaction.reply({ embeds: [errorEmbed(t(lang, 'prof2.member_not_found'))], ephemeral: true });

    if (sub === 'card') {
      if (!(await safeDefer(interaction))) return;
      try {
        const image = await renderProfileCard(data);
        const file = new AttachmentBuilder(image, { name: `profile-${target.id}.png` });
        return interaction.editReply({ files: [file] });
      } catch (error) {
        console.error('[profile card]', error);
        return interaction.editReply({ embeds: [errorEmbed(t(lang, 'prof2.card_fail', { err: error.message }))] });
      }
    }

    const badges = getBadges(target, data.member, data.registration, data.level, data.inventory, lang);
    if (sub === 'badges') {
      return interaction.reply({ embeds: [baseEmbed()
        .setTitle(t(lang, 'prof2.f_badges') + ' — ' + data.member.displayName)
        .setThumbnail(target.displayAvatarURL({ size: 256 }))
        .setDescription(badges.length ? badges.map(x => `• ${x}`).join('\n') : t(lang, 'prof2.no_badges'))] });
    }

    const roles = data.member.roles.cache.filter(r => r.id !== interaction.guild.id).sort((a, b) => b.position - a.position);
    const relation = data.marriage ? `<@${data.marriage.partnerId}>` : t(lang, 'prof2.not_married');
    return interaction.reply({ embeds: [baseEmbed()
      .setAuthor({ name: target.tag, iconURL: target.displayAvatarURL() })
      .setTitle(t(lang, 'prof2.title', { name: data.member.displayName }))
      .setThumbnail(target.displayAvatarURL({ size: 512 }))
      .setDescription(data.profile.bio || t(lang, 'prof2.no_bio'))
      .addFields(
        { name: t(lang, 'prof2.f_identity'), value: `ID: \`${target.id}\`\n${t(lang, 'prof2.f_pronouns')} ${data.profile.pronouns || '—'}\n${t(lang, 'prof2.f_location')} ${data.profile.location || '—'}`, inline: true },
        { name: t(lang, 'prof2.f_progress'), value: `${t(lang, 'prof2.f_level')} **${data.level.level}**\n${t(lang, 'prof2.f_xp')} **${data.level.xp}/${data.level.needed}**\n${t(lang, 'prof2.f_badges')} **${badges.length}**`, inline: true },
        { name: t(lang, 'prof2.f_economy'), value: `${t(lang, 'prof2.f_cash')} **${data.economy.balance.toLocaleString('id-ID')}**\n${t(lang, 'prof2.f_bank')} **${data.economy.bank.toLocaleString('id-ID')}**\n${t(lang, 'prof2.f_items')} **${data.inventory.length}**`, inline: true },
        { name: t(lang, 'prof2.f_time'), value: `${t(lang, 'prof2.f_created')} <t:${Math.floor(target.createdTimestamp / 1000)}:R>\n${t(lang, 'prof2.f_joined')} <t:${Math.floor(data.member.joinedTimestamp / 1000)}:R>`, inline: false },
        { name: t(lang, 'prof2.f_social'), value: `${t(lang, 'prof2.f_partner')} ${relation}\n${t(lang, 'prof2.f_birthday')} ${data.birthday ? `${data.birthday.day}/${data.birthday.month}` : t(lang, 'prof2.f_not_set')}`, inline: true },
        { name: t(lang, 'prof2.f_roles', { n: roles.size }), value: roles.first(12).join(' ') || t(lang, 'prof2.f_no_roles'), inline: false },
      )] });
  },
  // Diekspor agar panel /register bisa memakai ulang pengumpulan data + render kartu profil.
  collectData,
};
