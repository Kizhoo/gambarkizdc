// ============================================================================
// KARTU CANVAS RPG — level-up card & rank emblem
// ----------------------------------------------------------------------------
// Dibuat 100% dengan @napi-rs/canvas (sama seperti profileCard.js) supaya
// konsisten, instan, dan tidak bergantung aset gambar eksternal yang rapuh.
//   - renderLevelUpCard(data) -> Buffer PNG (notif naik level, jauh lebih niat)
//   - renderRankEmblem(rankKey, size) -> Buffer PNG (logo tiap rank)
//   - renderProfileRpgCard(data) -> Buffer PNG (kartu profil RPG lengkap)
// ============================================================================
const { createCanvas, loadImage } = require('@napi-rs/canvas');
const path = require('path');
const D = require('./rpgData');
const sprites = require('./rpgSprites');
const items = require('./rpgItems');
const currency = require('./currency');

// ----------------------------------------------------------------------------
// ATLAS 0x72 DungeonTileset II (CC0) — sumber sprite hero & monster untuk kartu
// canvas (konsisten dengan tampilan web RPG). Fallback ke sprite string-art lama
// bila file atlas tidak ada.
// ----------------------------------------------------------------------------
const ATLAS_PATH = path.join(__dirname, '..', 'dashboard', 'public', 'assets', 'atlas.png');
let _atlasJson = null, _atlasImg = null;
function getAtlasJson() {
  if (_atlasJson === null) {
    try { _atlasJson = require('../dashboard/public/assets/atlas.json'); } catch (_) { _atlasJson = false; }
  }
  return _atlasJson || null;
}
async function getAtlasImg() {
  if (_atlasImg !== null) return _atlasImg;
  try { _atlasImg = await loadImage(ATLAS_PATH); } catch (_) { _atlasImg = false; }
  return _atlasImg || null;
}
const HERO_ATLAS = {
  warrior: 'knight_m_idle_anim_f0', mage: 'wizzard_m_idle_anim_f0',
  assassin: 'elf_m_idle_anim_f0', archer: 'elf_m_idle_anim_f0',
};
const MONSTER_ATLAS = {
  slime: { base: 'slug_anim_f0', tint: [0.39, 0.85, 0.56] },
  rat: { base: 'tiny_slug_anim_f0', tint: [0.73, 0.71, 0.68] },
  bat: { base: 'imp_idle_anim_f0', tint: [0.56, 0.60, 1.0] },
  spider: { base: 'goblin_idle_anim_f0', tint: [0.24, 0.27, 0.34] },
  snake: { base: 'muddy_anim_f0', tint: [0.45, 0.70, 0.29] },
  wolf: { base: 'chort_idle_anim_f0', tint: [0.60, 0.65, 0.74] },
  goblin: { base: 'goblin_idle_anim_f0', tint: null },
  skeleton: { base: 'skelet_idle_anim_f0', tint: [0.95, 0.96, 0.97] },
  imp: { base: 'imp_idle_anim_f0', tint: null },
  turtle: { base: 'swampy_anim_f0', tint: [0.18, 0.77, 0.69] },
  hyena: { base: 'wogol_idle_anim_f0', tint: [0.85, 0.70, 0.49] },
  scorpion: { base: 'tiny_zombie_idle_anim_f0', tint: [0.77, 0.48, 0.18] },
  vulture: { base: 'imp_idle_anim_f0', tint: [0.60, 0.42, 0.23] },
  orc: { base: 'orc_warrior_idle_anim_f0', tint: null },
  gargoyle: { base: 'masked_orc_idle_anim_f0', tint: [0.56, 0.60, 0.66] },
  mummy: { base: 'zombie_anim_f0', tint: [0.85, 0.76, 0.57] },
  deceased: { base: 'zombie_anim_f0', tint: [0.54, 0.57, 0.61] },
  golem: { base: 'big_zombie_idle_anim_f0', tint: [0.55, 0.52, 0.47] },
  wraith: { base: 'necromancer_anim_f0', tint: [0.69, 0.55, 1.0] },
  minotaur: { base: 'ogre_idle_anim_f0', tint: [0.79, 0.55, 0.29] },
  yeti: { base: 'big_zombie_idle_anim_f0', tint: [0.93, 0.96, 1.0] },
  dragon: { base: 'big_demon_idle_anim_f0', tint: [0.88, 0.34, 0.29] },
  demonlord: { base: 'big_demon_idle_anim_f0', tint: null },
};

// Gambar satu frame atlas di (x, yBawah) — yBawah = garis KAKI sprite (anchor bawah),
// jadi karakter selalu berdiri pas di garis tanah/portrait, tidak pernah "melayang".
// tint = [r,g,b] faktor 0..1 (pergantian warna arketipe), flip = cermin horizontal.
async function drawAtlasSprite(ctx, frameName, x, yBottom, scale, { flip = false, tint = null } = {}) {
  const atlas = getAtlasJson();
  const img = await getAtlasImg();
  if (!atlas || !img) return 0;
  const fr = atlas.frames[frameName];
  if (!fr) return 0;
  const { x: sx, y: sy, w, h } = fr.frame;
  const dw = w * scale, dh = h * scale;
  ctx.save();
  ctx.imageSmoothingEnabled = false;
  if (tint) {
    // gambar frame ke canvas kecil, lalu warnai (source-atop), baru tempel — cara aman
    // "tint" di canvas node tanpa dependensi tambahan.
    const tmp = createCanvas(Math.max(1, Math.round(w)), Math.max(1, Math.round(h)));
    const tctx = tmp.getContext('2d');
    tctx.imageSmoothingEnabled = false;
    tctx.drawImage(img, sx, sy, w, h, 0, 0, w, h);
    tctx.globalCompositeOperation = 'source-atop';
    tctx.fillStyle = `rgba(${Math.round(tint[0] * 255)},${Math.round(tint[1] * 255)},${Math.round(tint[2] * 255)},0.72)`;
    tctx.fillRect(0, 0, w, h);
    tctx.globalCompositeOperation = 'source-over';
    // kembali menggambar frame asli dgn alpha utk detail, lalu overlay tint
    tctx.globalAlpha = 0.45;
    tctx.drawImage(img, sx, sy, w, h, 0, 0, w, h);
    tctx.globalAlpha = 1;
    if (flip) { ctx.translate(x + dw, yBottom); ctx.scale(-1, 1); ctx.drawImage(tmp, 0, -dh, dw, dh); }
    else ctx.drawImage(tmp, x, yBottom - dh, dw, dh);
  } else if (flip) {
    ctx.translate(x + dw, yBottom);
    ctx.scale(-1, 1);
    ctx.drawImage(img, sx, sy, w, h, 0, -dh, dw, dh);
  } else {
    ctx.drawImage(img, sx, sy, w, h, x, yBottom - dh, dw, dh);
  }
  ctx.restore();
  return dh;
}

// ukuran frame atlas (lebar/tinggi asli) — null bila atlas/frame tidak tersedia.
function atlasFrameSize(frameName) {
  const atlas = getAtlasJson();
  if (!atlas || !atlas.frames[frameName]) return null;
  const f = atlas.frames[frameName].frame;
  return { w: f.w, h: f.h };
}

function rr(ctx, x, y, w, h, r) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + w, y, x + w, y + h, radius);
  ctx.arcTo(x + w, y + h, x, y + h, radius);
  ctx.arcTo(x, y + h, x, y, radius);
  ctx.arcTo(x, y, x + w, y, radius);
  ctx.closePath();
}
function hexToRgb(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex || '');
  if (!m) return { r: 88, g: 101, b: 242 };
  const n = parseInt(m[1], 16);
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}
function withAlpha(hex, a) { const { r, g, b } = hexToRgb(hex); return `rgba(${r},${g},${b},${a})`; }
function lighten(hex, amt) {
  const { r, g, b } = hexToRgb(hex);
  const f = v => Math.round(v + (255 - v) * amt);
  return `rgb(${f(r)},${f(g)},${f(b)})`;
}
function darken(hex, amt) {
  const { r, g, b } = hexToRgb(hex);
  const f = v => Math.max(0, Math.round(v * (1 - amt)));
  return `rgb(${f(r)},${f(g)},${f(b)})`;
}
// ---------- PANEL RETRO PIXEL (ganti "kartu kaca" gradient/blur ala dashboard AI generik) ----------
// Sudut dipotong (notch) bukan dibulatkan, border keras + garis bevel highlight/shadow satu
// pixel - bahasa visual klasik menu game 16-bit, sengaja BUKAN glassmorphism/soft-glow yang
// jadi ciri khas tampilan "buatan AI".
function pixelPanel(ctx, x, y, w, h, { fill = '#131b2c', border = '#3a4864', notch = 8 } = {}) {
  x = Math.round(x); y = Math.round(y); w = Math.round(w); h = Math.round(h);
  ctx.fillStyle = fill;
  ctx.beginPath();
  ctx.moveTo(x + notch, y); ctx.lineTo(x + w - notch, y); ctx.lineTo(x + w, y + notch);
  ctx.lineTo(x + w, y + h - notch); ctx.lineTo(x + w - notch, y + h); ctx.lineTo(x + notch, y + h);
  ctx.lineTo(x, y + h - notch); ctx.lineTo(x, y + notch);
  ctx.closePath(); ctx.fill();
  ctx.strokeStyle = border; ctx.lineWidth = 2; ctx.stroke();
  ctx.strokeStyle = 'rgba(255,255,255,0.12)'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(x + notch, y + 1.5); ctx.lineTo(x + w - notch, y + 1.5); ctx.stroke();
  ctx.strokeStyle = 'rgba(0,0,0,0.4)';
  ctx.beginPath(); ctx.moveTo(x + notch, y + h - 1.5); ctx.lineTo(x + w - notch, y + h - 1.5); ctx.stroke();
}
// Latar bertekstur titik dither, ganti radial-gradient "glow" halus yang generik.
function pixelDither(ctx, x, y, w, h, color, spacing = 20) {
  ctx.save(); ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip();
  ctx.fillStyle = color;
  for (let yy = y; yy < y + h; yy += spacing) {
    const offset = ((yy - y) / spacing) % 2 === 0 ? 0 : spacing / 2;
    for (let xx = x + offset; xx < x + w; xx += spacing) ctx.fillRect(xx, yy, 2, 2);
  }
  ctx.restore();
}
// Bar progress bergaya pixel (blok kotak-kotak, bukan gradasi mulus).
function pixelBar(ctx, x, y, w, h, pct, color) {
  ctx.fillStyle = '#0b0f1a'; ctx.fillRect(x - 2, y - 2, w + 4, h + 4);
  ctx.fillStyle = '#1b2438'; ctx.fillRect(x, y, w, h);
  const filled = Math.max(0, Math.min(w, Math.round(w * Math.max(0, Math.min(1, pct)))));
  const seg = 6;
  ctx.fillStyle = color;
  for (let i = 0; i < filled; i += seg) ctx.fillRect(x + i, y, Math.min(seg - 1, filled - i), h);
}

async function safeAvatar(url, size) {
  try { if (url) return await loadImage(url); } catch { /* ignore */ }
  return null;
}
function drawAvatarCircle(ctx, img, cx, cy, r, ringColor, initial) {
  ctx.save();
  ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.closePath();
  ctx.lineWidth = 6; ctx.strokeStyle = ringColor; ctx.stroke();
  ctx.clip();
  if (img) ctx.drawImage(img, cx - r, cy - r, r * 2, r * 2);
  else {
    ctx.fillStyle = '#1E293B'; ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
    ctx.fillStyle = '#E2E8F0'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.font = `700 ${r}px sans-serif`; ctx.fillText((initial || '?').toUpperCase(), cx, cy + 2);
  }
  ctx.restore();
}

// ---------- RANK EMBLEM (logo hexagon per rank) ----------
function drawHexPath(ctx, cx, cy, r) {
  ctx.beginPath();
  for (let i = 0; i < 6; i++) {
    const a = Math.PI / 180 * (60 * i - 90);
    const x = cx + r * Math.cos(a), y = cy + r * Math.sin(a);
    i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
  }
  ctx.closePath();
}
function renderRankEmblem(rankKey, size = 256) {
  const rank = D.getRank(rankKey);
  const canvas = createCanvas(size, size);
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingEnabled = false;
  const cx = size / 2, cy = size / 2, r = size * 0.42;
  ctx.fillStyle = '#0A0F1C'; ctx.fillRect(0, 0, size, size);
  pixelDither(ctx, 0, 0, size, size, withAlpha(rank.color, 0.10), Math.round(size / 12));
  // outer hex - fill DATAR, bukan gradient
  drawHexPath(ctx, cx, cy, r);
  ctx.fillStyle = rank.color; ctx.fill();
  ctx.lineWidth = size * 0.025; ctx.strokeStyle = darken(rank.color, 0.35); ctx.stroke();
  // inner hex
  drawHexPath(ctx, cx, cy, r * 0.78);
  ctx.fillStyle = '#0F172A'; ctx.fill();
  // rank letter
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillStyle = lighten(rank.color, 0.55);
  const letterSize = rank.key.length >= 3 ? size * 0.26 : size * 0.4;
  ctx.font = `800 ${letterSize}px sans-serif`;
  ctx.fillText(rank.key, cx, cy - size * 0.02);
  // tier stars (index in ranks)
  const tierCount = Math.min(6, D.RANK_INDEX[rank.key] + 1);
  ctx.font = `${size * 0.07}px sans-serif`; ctx.fillStyle = lighten(rank.color, 0.6);
  ctx.fillText('★'.repeat(Math.min(tierCount, 6)), cx, cy + size * 0.32);
  return canvas.toBuffer('image/png');
}

// ---------- RANK LADDER (canvas versi /rpg rank info) ----------
const REQ_LABEL = {
  level: 'Level', quests: 'Quest', monsters: 'Monster', dungeons: 'Dungeon',
  reputation: 'Reputasi', partyLed: 'Party Dipimpin', bosses: 'Boss', worldQuests: 'World Quest',
};
function reqLineFor(rank) {
  if (rank.req.note) return rank.req.note;
  return Object.entries(rank.req).map(([k, v]) => `${REQ_LABEL[k] || k} ${v}`).join('  •  ');
}
function renderRankLadderCard({ currentRankKey } = {}) {
  const ranks = D.RANKS;
  const W = 1040;
  const rowH = 92;
  const headerH = 150;
  const footerH = 92;
  const H = headerH + ranks.length * rowH + footerH;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingEnabled = false;

  // backdrop: warna datar + tekstur titik dither (BUKAN radial-glow gradient halus)
  ctx.fillStyle = '#0A0F1C'; ctx.fillRect(0, 0, W, H);
  pixelDither(ctx, 0, 0, W, H, 'rgba(255,255,255,0.035)', 22);

  // header
  ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = '#F8FAFC'; ctx.font = '800 38px sans-serif';
  ctx.fillText('TINGKATAN RANK', 40, 58);
  ctx.fillStyle = '#64748B'; ctx.font = '600 18px sans-serif';
  ctx.fillText('Kizhoo Adventure  •  G → Ω, dari termuda sampai legenda', 40, 92);
  // garis putus-putus pixel, ganti garis solid tipis
  ctx.fillStyle = 'rgba(148,163,184,0.35)';
  for (let x = 40; x < W - 40; x += 10) ctx.fillRect(x, 112, 5, 3);

  ranks.forEach((rank, i) => {
    const y = headerH + i * rowH;
    const isCurrent = currentRankKey && rank.key === currentRankKey;
    pixelPanel(ctx, 24, y + 6, W - 48, rowH - 12, {
      fill: isCurrent ? withAlpha(rank.color, 0.14) : (i % 2 === 0 ? '#101828' : '#0d1420'),
      border: isCurrent ? rank.color : '#232f47',
      notch: 10,
    });

    // mini hex emblem - fill DATAR (bukan gradient) + garis tebal, ala ikon game pixel
    const cx = 78, cy = y + rowH / 2;
    const r = 30;
    drawHexPath(ctx, cx, cy, r);
    ctx.fillStyle = rank.color; ctx.fill();
    ctx.lineWidth = 3; ctx.strokeStyle = darken(rank.color, 0.35); ctx.stroke();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#0B1120'; ctx.font = `800 ${rank.key.length >= 3 ? 16 : 22}px sans-serif`;
    ctx.fillText(rank.key, cx, cy + 1);

    // nama rank
    ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
    ctx.fillStyle = isCurrent ? lighten(rank.color, 0.6) : '#E2E8F0';
    ctx.font = '700 26px sans-serif';
    ctx.fillText(rank.name, 128, cy - 2);
    const nameW = ctx.measureText(rank.name).width;
    if (rank.promo !== 'grind') {
      ctx.font = '700 14px sans-serif';
      const tag = rank.promo === 'prestige' ? 'PRESTASI' : 'LEGENDARIS';
      const tw = ctx.measureText(tag).width;
      const bx = 128 + nameW + 14;
      ctx.fillStyle = withAlpha(rank.color, 0.22);
      ctx.fillRect(bx, cy - 22, tw + 16, 22);
      ctx.strokeStyle = withAlpha(rank.color, 0.7); ctx.lineWidth = 1;
      ctx.strokeRect(bx + 0.5, cy - 21.5, tw + 15, 21);
      ctx.fillStyle = lighten(rank.color, 0.5);
      ctx.fillText(tag, bx + 8, cy - 6);
    }
    // requirement line
    ctx.font = '400 18px sans-serif'; ctx.fillStyle = '#8B96AB';
    ctx.fillText(reqLineFor(rank), 128, cy + 24);
    if (isCurrent) {
      ctx.textAlign = 'right'; ctx.font = '700 15px sans-serif'; ctx.fillStyle = lighten(rank.color, 0.6);
      ctx.fillText('◀ KAMU DI SINI', W - 48, cy + 5);
      ctx.textAlign = 'left';
    }
  });

  // footer note
  pixelPanel(ctx, 24, H - footerH + 12, W - 48, footerH - 28, { fill: 'rgba(239,68,68,0.10)', border: '#7f1d1d', notch: 8 });
  ctx.fillStyle = '#FCA5A5'; ctx.font = '700 17px sans-serif'; ctx.textAlign = 'left';
  ctx.fillText('PERINGATAN: Promosi TIDAK otomatis — ajukan lewat /rpg rank request atau minta bantuan Luna, lalu di-ACC staff.', 40, H - footerH + 42);

  return canvas.toBuffer('image/png');
}

// ---------- LATAR KARTU RANK (kustomisasi profil) ----------
// Sama dengan daftar di dashboard/public/profile.html (RANK_BG). Key latar + URL foto custom.
const CARD_BG = {
  senja: ['#1e1b4b', '#7c2d92', '#f97316'], aurora: ['#0b1120', '#14532d', '#38bdf8'],
  laut: ['#020617', '#0c4a6e', '#22d3ee'], hutan: ['#052e16', '#166534', '#4ade80'],
  nebula: ['#1e1b4b', '#7c3aed', '#ec4899'], emas: ['#451a03', '#b45309', '#fbbf24'],
  salju: ['#1e293b', '#475569', '#e2e8f0'], gurun: ['#431407', '#c2410c', '#fbbf24'],
  obsidian: ['#0a0a0a', '#1f2937', '#4b5563'], kristal: ['#0f172a', '#155e75', '#a5f3fc'],
};
async function drawCardBackground(ctx, W, H, cardBg, cardBgUrl) {
  if (cardBgUrl && /^https?:\/\//i.test(cardBgUrl)) {
    try {
      const img = await loadImage(cardBgUrl);
      if (img) {
        const iw = img.width, ih = img.height;
        const scale = Math.max(W / iw, H / ih);
        const dw = iw * scale, dh = ih * scale;
        ctx.drawImage(img, (W - dw) / 2, (H - dh) / 2, dw, dh);
        ctx.fillStyle = 'rgba(0,0,0,0.32)'; ctx.fillRect(0, 0, W, H); // biar teks terbaca
        return;
      }
    } catch (_) { /* fallback ke gradient */ }
  }
  const c = CARD_BG[cardBg] || CARD_BG.senja;
  const g = ctx.createLinearGradient(0, 0, W, H);
  g.addColorStop(0, c[0]); g.addColorStop(0.5, c[1]); g.addColorStop(1, c[2]);
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
}

// ---------- LEVEL-UP CARD ----------
async function renderLevelUpCard({ user, className, rankKey, fromLevel, toLevel, xpInto, xpForNext, skillPointsGained, statPointsGained, customization = {}, cardBg, cardBgUrl }) {
  const W = 1000, H = 420;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');
  const rank = D.getRank(rankKey);
  const cls = D.CLASSES[className] || D.CLASSES.warrior;
  const accent = cls.color;

  // background: latar kustomisasi (gradient/foto) + garis aksen kiri
  ctx.imageSmoothingEnabled = false;
  await drawCardBackground(ctx, W, H, cardBg, cardBgUrl);
  ctx.fillStyle = accent; ctx.fillRect(0, 0, 12, H);

  // portrait: karakter pixel-art hasil kustomisasi (fallback ke warna kelas kalau belum diset)
  const pX = 40, pY = 46, pW = 176, pH = 176;
  pixelPanel(ctx, pX, pY, pW, pH, { fill: '#0D1420', border: darken(accent, 0.2), notch: 10 });
  const heroScale = 8;
  const cust = {
    hairStyle: customization.hairStyle || 'short', hairColor: customization.hairColor || '#1f2937',
    expression: customization.expression || 'netral', outfitColor: customization.outfitColor || accent,
    pantsColor: customization.pantsColor || '#472a19', shoesColor: customization.shoesColor || '#0b0b12',
  };
  const heroW = sprites.customHeroWidth(heroScale), heroH = sprites.customHeroHeight(heroScale);
  sprites.drawCustomHero(ctx, pX + (pW - heroW) / 2, pY + (pH - heroH) / 2 + 6, heroScale, cust);

  // rank emblem (top-right)
  try {
    const emblem = await loadImage(renderRankEmblem(rankKey, 140));
    ctx.drawImage(emblem, W - 160, 30, 120, 120);
  } catch { /* ignore */ }

  // texts
  const infoX = pX + pW + 28;
  ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = accent; ctx.font = '800 34px sans-serif';
  ctx.fillText('LEVEL UP!', infoX, 78);
  ctx.fillStyle = '#F8FAFC'; ctx.font = '700 27px sans-serif';
  ctx.fillText(`${user?.displayName || user?.username || 'Petualang'}`, infoX, 116);
  ctx.fillStyle = '#8B96AB'; ctx.font = '700 17px sans-serif';
  ctx.fillText(`${cls.name.toUpperCase()}  •  RANK ${rank.key}`, infoX, 142);

  // big level transition
  ctx.textAlign = 'center';
  ctx.fillStyle = '#4B5670'; ctx.font = '800 80px sans-serif';
  ctx.fillText(String(fromLevel), infoX + 60, 260);
  ctx.fillStyle = accent; ctx.font = '700 50px sans-serif';
  ctx.fillText('→', infoX + 168, 252);
  ctx.fillStyle = lighten(accent, 0.4); ctx.font = '800 100px sans-serif';
  ctx.fillText(String(toLevel), infoX + 290, 268);
  ctx.textAlign = 'left';

  // XP bar pixel
  const barX = infoX, barY = 300, barW = W - 60 - infoX, barH = 24;
  const pct = isFinite(xpForNext) && xpForNext > 0 ? Math.max(0.02, Math.min(1, xpInto / xpForNext)) : 1;
  pixelBar(ctx, barX, barY, barW, barH, pct, accent);
  ctx.fillStyle = '#8B96AB'; ctx.font = '600 17px sans-serif';
  ctx.fillText(isFinite(xpForNext) ? `${xpInto}/${xpForNext} XP` : 'XP MAX', barX + 4, barY + barH + 26);

  // reward chips (skill/stat points)
  let chipY = 232;
  const chip = (label, val, color) => {
    const w = 200, h = 42, x = W - 60 - w;
    pixelPanel(ctx, x, chipY, w, h, { fill: withAlpha(color, 0.16), border: color, notch: 6 });
    ctx.fillStyle = color; ctx.font = '700 19px sans-serif'; ctx.textAlign = 'left';
    ctx.fillText(`${label} +${val}`, x + 16, chipY + 27);
    chipY += h + 10;
  };
  if (skillPointsGained) chip('SKILL POINT', skillPointsGained, '#A855F7');
  if (statPointsGained) chip('STAT POINT', statPointsGained, '#22D3EE');

  return canvas.toBuffer('image/png');
}

// ---------- PAPAN QUEST (canvas ala kertas quest robek gaya anime/game — bukan embed teks polos) ----------
// Monster di quest sekarang jauh lebih variatif (40+ jenis, lihat utils/rpgQuestGenerator.js) tapi
// sprite pixel-art yang tersedia cuma segelintir (lihat utils/rpgSprites.js) - gambar sprite baru
// satu-satu buat tiap monster tidak realistis/berisiko kualitasnya tidak konsisten. Sebagai
// gantinya, monsterHint (nama musuh ASLI yang jadi seed quest ini, disimpan pas quest dibuat -
// BUKAN ditebak dari teks bebas AI) dipetakan ke sprite yang paling dekat temanya lewat kata kunci.
const MONSTER_SPRITE_KEYWORDS = [
  // urutan penting: dicek dari atas, yang match PERTAMA yang dipakai
  { sprite: 'dragon', words: ['naga', 'wyvern', 'griffin', 'hydra', 'basilisk', 'chimera', 'manticore'] },
  { sprite: 'demonlord', words: ['lich', 'iblis', 'setan', 'demon'] },
  { sprite: 'wraith', words: ['hantu', 'kerangka', 'zombie', 'vampir', 'banshee', 'siren', 'penyihir', 'kultus', 'roh'] },
  { sprite: 'golem', words: ['golem', 'gargoyle', 'troll', 'mimic', 'batu', 'laba-laba', 'spider', 'elemental es', 'es'] },
  { sprite: 'wolf', words: ['serigala', 'wolf', 'werewolf'] },
  { sprite: 'minotaur', words: ['minotaur', 'orc', 'ogre', 'bandit', 'perompak', 'elemental api', 'api'] },
  { sprite: 'goblin', words: ['goblin', 'kobold', 'tikus', 'harpy'] },
  { sprite: 'slime', words: ['slime'] },
];
function resolveMonsterSprite(monsterHint, isBoss) {
  const text = String(monsterHint || '').toLowerCase();
  for (const entry of MONSTER_SPRITE_KEYWORDS) {
    if (entry.words.some(w => text.includes(w))) return entry.sprite;
  }
  return isBoss ? 'demonlord' : 'goblin'; // fallback wajar kalau monsterHint kosong (quest lama sebelum kolom ini ada)
}

// Seed pseudo-random DETERMINISTIK per quest (bukan Math.random() - biar tepian robek kertas
// yang sama tetap identik tiap kali quest yang sama dirender ulang, tidak "berkedip" beda-beda).
function seededRand(seed) {
  let s = seed % 2147483647; if (s <= 0) s += 2147483646;
  return () => { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; };
}
// Path kertas dengan tepi robek (jagged) - kesan "disobek dari papan pengumuman", bukan kotak rapi.
function tornPaperPath(ctx, x, y, w, h, rand, jag = 5) {
  ctx.beginPath();
  const step = 14;
  let started = false;
  const pt = (px, py) => { if (!started) { ctx.moveTo(px, py); started = true; } else ctx.lineTo(px, py); };
  for (let px = 0; px <= w; px += step) pt(x + px, y + (rand() - 0.5) * jag);
  for (let py = 0; py <= h; py += step) pt(x + w + (rand() - 0.5) * jag, y + py);
  for (let px = w; px >= 0; px -= step) pt(x + px, y + h + (rand() - 0.5) * jag);
  for (let py = h; py >= 0; py -= step) pt(x + (rand() - 0.5) * jag, y + py);
  ctx.closePath();
}
function parchmentTexture(ctx, x, y, w, h) {
  ctx.fillStyle = '#C9AD7F'; ctx.fillRect(x, y, w, h);
  pixelDither(ctx, x, y, w, h, 'rgba(90,58,26,0.14)', 9);
  pixelDither(ctx, x, y, w, h, 'rgba(255,247,222,0.16)', 15);
}
// Badge lilin (wax seal) di pojok kertas - warnanya beda buat harian/mingguan, isinya huruf singkat.
function drawWaxSeal(ctx, cx, cy, r, color, letter) {
  ctx.save();
  ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fill();
  ctx.beginPath(); ctx.arc(cx - 1, cy - 1, r, 0, Math.PI * 2);
  ctx.fillStyle = color; ctx.fill();
  ctx.beginPath(); ctx.arc(cx - 1, cy - 1, r * 0.62, 0, Math.PI * 2);
  ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 1.5; ctx.stroke();
  ctx.fillStyle = 'rgba(255,255,255,0.9)'; ctx.font = `800 ${Math.round(r * 0.95)}px serif`;
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(letter, cx - 1, cy);
  ctx.restore();
}
function wrapText(ctx, text, maxWidth, maxLines) {
  const words = String(text).split(/\s+/);
  const lines = [];
  let line = '';
  for (const word of words) {
    const test = line ? `${line} ${word}` : word;
    if (ctx.measureText(test).width > maxWidth && line) {
      lines.push(line);
      line = word;
      if (lines.length === maxLines) break;
    } else {
      line = test;
    }
  }
  if (lines.length < maxLines && line) lines.push(line);
  if (lines.length === maxLines) {
    let last = lines[maxLines - 1];
    while (ctx.measureText(last + '...').width > maxWidth && last.length > 1) last = last.slice(0, -1);
    lines[maxLines - 1] = last + '...';
  }
  return lines;
}
function renderQuestBoardCard(quests) {
  const W = 1040;
  const COLS = 2;
  const cardW = 478, cardH = 224, gapX = 24, gapY = 18;
  const headerH = 104, footerH = 50;
  const rows = Math.ceil(quests.length / COLS);
  const H = headerH + rows * (cardH + gapY) - gapY + footerH;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingEnabled = false;

  // latar papan kayu gelap dengan sedikit vignette + beberapa paku dekoratif tersebar acak
  // (deterministik, bukan Math.random() polos, biar tidak "berkedip" beda tiap render papan yang
  // isinya sama) - ini yang bikin kesan "papan pengumuman" alih-alih daftar/list biasa.
  ctx.fillStyle = '#1C130D'; ctx.fillRect(0, 0, W, H);
  pixelDither(ctx, 0, 0, W, H, 'rgba(0,0,0,0.3)', 10);
  pixelDither(ctx, 0, 0, W, H, 'rgba(90,58,26,0.12)', 17);
  const bgRand = seededRand(42);
  for (let i = 0; i < 14; i++) {
    const bx = bgRand() * W, by = headerH * 0.6 + bgRand() * (H - headerH);
    ctx.beginPath(); ctx.arc(bx, by, 2.4, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(230,200,150,0.10)'; ctx.fill();
  }

  ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = '#F3E3C3'; ctx.font = '800 38px serif';
  ctx.fillText('⚔ PAPAN QUEST GUILD', 34, 56);
  ctx.fillStyle = '#8C7657'; ctx.font = '600 15px sans-serif';
  ctx.fillText('Kertas quest ditempel di papan - ambil misi lewat tombol di bawah', 34, 80);

  quests.forEach((q, i) => {
    const col = i % COLS, row = Math.floor(i / COLS);
    const cellX = 30 + col * (cardW + gapX);
    const cellY = headerH + row * (cardH + gapY);
    const rand = seededRand(q.questId * 7919 + 13); // prima biar sebarannya bagus, deterministik per quest

    // sedikit jitter posisi & rotasi PER KARTU (bukan cuma alternating rapi) biar kerasa "ditempel
    // manual satu-satu" - tapi tetap dalam batas sel gridnya sendiri, tidak nabrak kartu tetangga,
    // jadi hasil akhirnya tetap rapi/terbaca walau tidak berbaris kaku.
    const jitterX = (rand() - 0.5) * 10, jitterY = (rand() - 0.5) * 8;
    const angle = (rand() - 0.5) * 0.045;
    const px = cellX + jitterX, py = cellY + jitterY, pw = cardW - 20, ph = cardH - 20;

    ctx.save();
    ctx.translate(px + pw / 2, py + ph / 2);
    ctx.rotate(angle);
    ctx.translate(-(px + pw / 2), -(py + ph / 2));

    // bayangan tipis di belakang kertas biar kesan "ditempel", baru gambar kertasnya sendiri
    // dengan tepi robek (bukan kotak rapi).
    ctx.save();
    tornPaperPath(ctx, px + 4, py + 5, pw, ph, seededRand(q.questId * 7919 + 13), 5);
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fill();
    ctx.restore();

    tornPaperPath(ctx, px, py, pw, ph, rand, 5);
    ctx.save(); ctx.clip();
    parchmentTexture(ctx, px, py, pw, ph);
    ctx.restore();
    ctx.strokeStyle = 'rgba(74,44,18,0.55)'; ctx.lineWidth = 2; ctx.stroke();

    // paku/pin di tengah-atas kertas (bukan cuma wax seal) - detail kecil yang bikin lebih
    // "kertas nempel di papan" ketimbang kotak info biasa.
    ctx.beginPath(); ctx.arc(px + pw / 2, py + 3, 6, 0, Math.PI * 2);
    ctx.fillStyle = '#7A7A82'; ctx.fill();
    ctx.beginPath(); ctx.arc(px + pw / 2 - 1.5, py + 1.5, 2, 0, Math.PI * 2);
    ctx.fillStyle = '#D4D4DC'; ctx.fill();

    // ilustrasi monster (cocok sama monster quest-nya lewat monsterHint, bukan rotasi sprite tetap)
    const isBoss = q.objectiveType === 'bossesDefeated';
    const spriteKey = resolveMonsterSprite(q.monsterHint, isBoss);
    const iconX = px + 18, iconY = py + 34, iconSize = 84;
    ctx.fillStyle = 'rgba(74,44,18,0.18)'; ctx.fillRect(iconX, iconY, iconSize, iconSize);
    ctx.strokeStyle = 'rgba(74,44,18,0.6)'; ctx.lineWidth = 2; ctx.strokeRect(iconX + 1, iconY + 1, iconSize - 2, iconSize - 2);
    try {
      const mScale = Math.floor(iconSize / sprites.spriteCols(spriteKey));
      const mw = sprites.spriteWidth(spriteKey, mScale), mh = sprites.spriteHeight(spriteKey, mScale);
      sprites.drawSprite(ctx, spriteKey, iconX + (iconSize - mw) / 2, iconY + (iconSize - mh) / 2, mScale);
    } catch { /* ignore kalau sprite gagal, kotak bingkai kosong tetap oke */ }
    if (isBoss) {
      ctx.strokeStyle = '#B4392B'; ctx.lineWidth = 3; ctx.strokeRect(iconX - 2, iconY - 2, iconSize + 4, iconSize + 4);
    }

    // wax seal pojok kiri-atas: HIJAU/H = harian, UNGU/M = mingguan
    drawWaxSeal(ctx, px + 20, py + 20, 14, q.type === 'weekly' ? '#5B3A8E' : '#3F6B2E', q.type === 'weekly' ? 'M' : 'H');
    if (q.source === 'ai') drawWaxSeal(ctx, px + pw - 20, py + 20, 12, '#6B4A1E', 'AI');

    // teks quest (dibungkus 2 baris - kartu sekarang lebih sempit dari versi list lama)
    const tx = iconX + iconSize + 16;
    const textMaxW = px + pw - 14 - tx;
    ctx.fillStyle = '#3A2410'; ctx.font = '800 19px serif';
    wrapText(ctx, `#${q.questId} ${q.title}`, textMaxW, 2).forEach((line, li) => ctx.fillText(line, tx, py + 32 + li * 22));
    ctx.font = '700 12px sans-serif'; ctx.fillStyle = isBoss ? '#7F1D1D' : '#4A5C2E';
    ctx.fillText(isBoss ? 'MISI BOSS' : 'MISI BURUAN', tx, py + 78);
    ctx.font = '400 13px serif'; ctx.fillStyle = '#5A4326';
    wrapText(ctx, q.description, textMaxW, 2).forEach((line, li) => ctx.fillText(line, tx, py + 96 + li * 17));
    ctx.font = '700 13px sans-serif'; ctx.fillStyle = '#241811';
    ctx.fillText(`Target ${q.objectiveTarget}x ${isBoss ? 'Boss' : 'Monster'} • Rank ${q.minRank}+`, tx, py + 148);
    ctx.font = '800 14px sans-serif'; ctx.fillStyle = '#5B3A0E';
    ctx.fillText(`+${q.rewardXp} XP  +${q.rewardGold} KZC  +${q.rewardRep} Rep`, tx, py + 168);
    ctx.restore();
  });

  ctx.fillStyle = '#8C7657'; ctx.font = '600 15px sans-serif'; ctx.textAlign = 'left';
  ctx.fillText('Terima quest lewat tombol di bawah pesan ini.', 34, H - footerH / 2 + 5);

  return canvas.toBuffer('image/png');
}

// ---------- IKON ITEM (canvas ala pixel — /rpg shop & /rpg inventory) ----------
// Bukan 1 gambar unik per item (18+ item, tidak realistis digambar tangan satu-satu di canvas
// tanpa preview visual buat dicek) - tapi tiap KATEGORI punya siluet ikon sendiri yang jelas
// beda bentuknya (pedang/perisai/permata/botol ramuan), lalu warnanya ikut warna rarity item
// itu sendiri. Jauh lebih jelas dibanding cuma teks nama doang.
function drawItemIcon(ctx, x, y, size, category, tintHex) {
  const s = size;
  ctx.save();
  ctx.translate(x, y);
  ctx.imageSmoothingEnabled = false;
  const main = tintHex || '#94A3B8';
  const dark = darken(main, 0.35);
  const light = lighten(main, 0.4);
  const unit = s / 16;
  const px = (n) => Math.round(n * unit);

  if (category === 'weapon') {
    // pedang: bilah vertikal + gagang + cross-guard, khas siluet pixel RPG
    ctx.fillStyle = light; ctx.fillRect(px(7), px(1), px(2), px(9));
    ctx.fillStyle = main; ctx.fillRect(px(7.5), px(1), px(1), px(9));
    ctx.fillStyle = dark; ctx.fillRect(px(4), px(9), px(8), px(2));
    ctx.fillStyle = '#4A2E14'; ctx.fillRect(px(6.5), px(11), px(3), px(4));
  } else if (category === 'armor') {
    // perisai: bentuk pentagon sederhana lewat path pixel-block
    ctx.fillStyle = main;
    ctx.fillRect(px(3), px(2), px(10), px(6));
    ctx.fillRect(px(4), px(8), px(8), px(3));
    ctx.fillRect(px(5), px(11), px(6), px(2));
    ctx.fillRect(px(7), px(13), px(2), px(2));
    ctx.fillStyle = dark;
    ctx.fillRect(px(3), px(2), px(10), px(2));
    ctx.fillStyle = light; ctx.fillRect(px(6), px(4), px(4), px(4));
  } else if (category === 'accessory') {
    // cincin + permata di atasnya
    ctx.strokeStyle = main; ctx.lineWidth = px(2);
    ctx.beginPath(); ctx.arc(px(8), px(11), px(4), 0, Math.PI * 2); ctx.stroke();
    ctx.fillStyle = light;
    ctx.beginPath();
    ctx.moveTo(px(8), px(1)); ctx.lineTo(px(11), px(5)); ctx.lineTo(px(8), px(8)); ctx.lineTo(px(5), px(5));
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = dark; ctx.fillRect(px(7), px(4), px(2), px(2));
  } else if (category === 'potion') {
    // botol ramuan: leher + badan bulat, cairan warna tint
    ctx.fillStyle = '#CBD5E1'; ctx.fillRect(px(6.5), px(1), px(3), px(3));
    ctx.fillStyle = '#475569'; ctx.fillRect(px(6), px(0.5), px(4), px(1));
    ctx.fillStyle = light;
    ctx.fillRect(px(4), px(4), px(8), px(2));
    ctx.fillRect(px(3), px(6), px(10), px(8));
    ctx.fillStyle = main;
    ctx.fillRect(px(3), px(9), px(10), px(5));
    ctx.fillStyle = 'rgba(255,255,255,0.5)'; ctx.fillRect(px(4.5), px(7), px(1.5), px(5));
  } else {
    ctx.fillStyle = main; ctx.fillRect(px(4), px(4), px(8), px(8));
  }
  ctx.restore();
}

function renderShopCategoryCard(categoryKey, list, char) {
  const cat = items.CATEGORIES[categoryKey];
  const W = 1000, rowH = 108, headerH = 84, footerH = 40;
  const H = headerH + list.length * rowH + footerH;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingEnabled = false;

  ctx.fillStyle = '#0A0F1C'; ctx.fillRect(0, 0, W, H);
  pixelDither(ctx, 0, 0, W, H, 'rgba(250,204,21,0.04)', 22);
  ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = '#F8FAFC'; ctx.font = '800 32px sans-serif';
  ctx.fillText(`TOKO GUILD — ${cat.label.toUpperCase()}`, 30, 42);
  drawWallet(ctx, 30, 66, { gold: char.gold, silver: char.silver || 0, copper: char.copper || 0 }, { coinR: 11 });

  const TIER_COLOR = ['#9CA3AF', '#4ADE80', '#38BDF8', '#A855F7', '#FACC15'];
  list.forEach((it, i) => {
    const y = headerH + i * rowH;
    const afford = char.gold >= it.price;
    const rankOk = !it.minRank || D.RANK_INDEX[char.rankKey] >= D.RANK_INDEX[it.minRank];
    const tier = TIER_COLOR[i % TIER_COLOR.length];
    pixelPanel(ctx, 24, y + 6, W - 48, rowH - 14, { fill: (!afford || !rankOk) ? 'rgba(255,255,255,0.02)' : '#101828', border: withAlpha(tier, 0.5), notch: 8 });
    const iconBox = 78;
    pixelPanel(ctx, 40, y + 15, iconBox, iconBox, { fill: 'rgba(0,0,0,0.3)', border: withAlpha(tier, 0.6), notch: 8 });
    drawItemIcon(ctx, 40 + 7, y + 15 + 7, iconBox - 14, categoryKey, tier);

    const tx = 40 + iconBox + 22;
    ctx.fillStyle = afford && rankOk ? '#F8FAFC' : '#64748B'; ctx.font = '700 22px sans-serif';
    ctx.fillText(it.name, tx, y + 38);
    ctx.fillStyle = '#8B96AB'; ctx.font = '400 15px sans-serif';
    ctx.fillText(it.desc, tx, y + 60);
    const extra = it.stats ? Object.entries(it.stats).map(([k, v]) => `+${v} ${k.toUpperCase()}`).join('  ') : (it.effect ? describeEffectPlain(it.effect) : '');
    ctx.fillStyle = tier; ctx.font = '700 15px sans-serif';
    ctx.fillText(extra, tx, y + 82);

    ctx.textAlign = 'right'; ctx.fillStyle = '#FACC15'; ctx.font = '800 22px sans-serif';
    ctx.fillText(`${it.price.toLocaleString('id-ID')}g`, W - 44, y + 38);
    if (it.minRank) { ctx.fillStyle = rankOk ? '#8B96AB' : '#EF4444'; ctx.font = '600 13px sans-serif'; ctx.fillText(`min rank ${it.minRank}`, W - 44, y + 58); }
    ctx.textAlign = 'left';
  });

  ctx.fillStyle = '#64748B'; ctx.font = '600 14px sans-serif';
  ctx.fillText('Klik tombol Beli di bawah pesan ini.', 30, H - footerH / 2 + 5);
  return canvas.toBuffer('image/png');
}
function describeEffectPlain(effect) {
  const parts = [];
  if (effect.heal) parts.push(`+${effect.heal} HP`);
  if (effect.mana) parts.push(`+${effect.mana} MP`);
  if (effect.healPct) parts.push('Full HP');
  if (effect.manaPct) parts.push('Full MP');
  return parts.join('  ');
}
function renderInventoryCard(char, inv) {
  const W = 1000;
  const slots = [['equipWeapon', 'weapon', 'Senjata'], ['equipArmor', 'armor', 'Zirah'], ['equipAccessory', 'accessory', 'Aksesoris']];
  const bagRows = inv.length || 1;
  const H = 242 + bagRows * 66 + 40;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingEnabled = false;
  ctx.fillStyle = '#0A0F1C'; ctx.fillRect(0, 0, W, H);
  pixelDither(ctx, 0, 0, W, H, 'rgba(255,255,255,0.03)', 22);

  ctx.textAlign = 'left'; ctx.fillStyle = '#F8FAFC'; ctx.font = '800 30px sans-serif';
  ctx.fillText('INVENTORY', 30, 42);
  drawWallet(ctx, 30, 66, { gold: char.gold, silver: char.silver || 0, copper: char.copper || 0 }, { coinR: 11 });

  // slot equipment
  const slotW = (W - 60 - 2 * 16) / 3;
  slots.forEach(([col, catKey, label], i) => {
    const x = 30 + i * (slotW + 16), y = 94;
    const it = char[col] && items.getItem(char[col]);
    pixelPanel(ctx, x, y, slotW, 110, { fill: '#101828', border: it ? withAlpha('#38BDF8', 0.6) : '#233046', notch: 8 });
    ctx.fillStyle = '#8B96AB'; ctx.font = '700 13px sans-serif'; ctx.fillText(label.toUpperCase(), x + 12, y + 20);
    if (it) {
      drawItemIcon(ctx, x + 12, y + 28, 56, catKey, '#38BDF8');
      ctx.fillStyle = '#F8FAFC'; ctx.font = '700 15px sans-serif';
      wrapFillText(ctx, it.name, x + 78, y + 46, slotW - 88, 16);
    } else {
      ctx.fillStyle = '#475569'; ctx.font = '500 14px sans-serif'; ctx.fillText('kosong', x + 12, y + 60);
    }
  });

  // tas
  ctx.fillStyle = '#F8FAFC'; ctx.font = '800 20px sans-serif'; ctx.fillText('TAS', 30, 232);
  if (!inv.length) {
    ctx.fillStyle = '#64748B'; ctx.font = '500 15px sans-serif'; ctx.fillText('Kosong. Beli sesuatu di /rpg shop.', 30, 260);
  } else {
    inv.forEach((row, i) => {
      const it = items.getItem(row.itemId);
      if (!it) return;
      const y = 244 + i * 66;
      pixelPanel(ctx, 30, y, W - 60, 56, { fill: '#101828', border: '#233046', notch: 6 });
      drawItemIcon(ctx, 38, y + 6, 44, it.category, '#94A3B8');
      ctx.fillStyle = '#F8FAFC'; ctx.font = '700 17px sans-serif'; ctx.fillText(`${it.name}  x${row.qty}`, 92, y + 26);
      ctx.fillStyle = '#8B96AB'; ctx.font = '400 13px sans-serif'; ctx.fillText(it.desc, 92, y + 44);
    });
  }
  return canvas.toBuffer('image/png');
}
function wrapFillText(ctx, text, x, y, maxWidth, lineHeight) {
  const words = text.split(' ');
  let line = '', yy = y;
  for (const w of words) {
    const test = line ? `${line} ${w}` : w;
    if (ctx.measureText(test).width > maxWidth && line) { ctx.fillText(line, x, yy); line = w; yy += lineHeight; }
    else line = test;
  }
  if (line) ctx.fillText(line, x, yy);
}

// ---------- KOIN (tembaga/perak/gold) — ganti tampilan angka polos jadi dompet visual ----------
const COIN_STYLE = {
  gold: { base: '#F2C230', edge: '#8A5A0A', shine: '#FFF3C4', engrave: '#8A5A0A' },
  silver: { base: '#C9D2DB', edge: '#5B6672', shine: '#F4F7FA', engrave: '#5B6672' },
  copper: { base: '#C4713C', edge: '#6B3A18', shine: '#F0B98A', engrave: '#6B3A18' },
};
// Tiap jenis koin punya UKIRAN beda di tengahnya (bukan cuma warna beda) - gold: mahkota
// kecil, perak: bulan sabit, tembaga: palu - biar beneran "beda bentuk" bukan cuma tint.
function drawCoin(ctx, cx, cy, r, kind) {
  const style = COIN_STYLE[kind] || COIN_STYLE.copper;
  ctx.save();
  ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fillStyle = style.base; ctx.fill();
  ctx.lineWidth = Math.max(1.5, r * 0.14); ctx.strokeStyle = style.edge; ctx.stroke();
  ctx.beginPath(); ctx.arc(cx, cy, r * 0.72, 0, Math.PI * 2);
  ctx.lineWidth = Math.max(1, r * 0.06); ctx.strokeStyle = style.edge; ctx.stroke();
  ctx.beginPath(); ctx.arc(cx - r * 0.32, cy - r * 0.32, r * 0.22, 0, Math.PI * 2);
  ctx.fillStyle = style.shine; ctx.globalAlpha = 0.7; ctx.fill(); ctx.globalAlpha = 1;

  ctx.fillStyle = style.engrave; ctx.strokeStyle = style.engrave; ctx.lineWidth = Math.max(1, r * 0.1);
  if (kind === 'gold') {
    // mahkota kecil
    ctx.beginPath();
    ctx.moveTo(cx - r * 0.32, cy + r * 0.15); ctx.lineTo(cx - r * 0.32, cy - r * 0.05);
    ctx.lineTo(cx - r * 0.14, cy + r * 0.08); ctx.lineTo(cx, cy - r * 0.22);
    ctx.lineTo(cx + r * 0.14, cy + r * 0.08); ctx.lineTo(cx + r * 0.32, cy - r * 0.05);
    ctx.lineTo(cx + r * 0.32, cy + r * 0.15); ctx.closePath(); ctx.fill();
  } else if (kind === 'silver') {
    // bulan sabit
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.32, 0.3 * Math.PI, 1.7 * Math.PI); ctx.stroke();
  } else {
    // palu kecil
    ctx.fillRect(cx - r * 0.06, cy - r * 0.28, r * 0.12, r * 0.5);
    ctx.fillRect(cx - r * 0.26, cy - r * 0.32, r * 0.52, r * 0.18);
  }
  ctx.restore();
}
// Dompet: gambar N koin tiap jenis (dibatasi biar gak kebanyakan) + angka, disusun horizontal.
function drawWallet(ctx, x, y, wallet, { coinR = 16, scale = 1 } = {}) {
  const entries = [['gold', wallet.gold], ['silver', wallet.silver], ['copper', wallet.copper]].filter(([, v]) => v > 0);
  if (!entries.length) entries.push(['gold', 0]);
  let cx = x;
  for (const [kind, val] of entries) {
    drawCoin(ctx, cx + coinR * scale, y, coinR * scale, kind);
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.font = `700 ${Math.round(15 * scale)}px sans-serif`;
    ctx.fillStyle = COIN_STYLE[kind].shine;
    const label = val.toLocaleString('id-ID');
    ctx.fillText(label, cx + coinR * scale * 2 + 4, y);
    cx += coinR * scale * 2 + 10 + ctx.measureText(label).width + 22 * scale;
  }
}

function renderShopHomeCard(wallet) {
  const W = 900, H = 360;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingEnabled = false;
  ctx.fillStyle = '#0A0F1C'; ctx.fillRect(0, 0, W, H);
  pixelDither(ctx, 0, 0, W, H, 'rgba(250,204,21,0.05)', 22);

  ctx.textAlign = 'center'; ctx.fillStyle = '#F8FAFC'; ctx.font = '800 34px sans-serif';
  ctx.fillText('TOKO GUILD', W / 2, 56);
  ctx.textAlign = 'left';
  drawWallet(ctx, W / 2 - 140, 90, wallet);

  const cats = items.allCategories();
  const cw = (W - 60 - (cats.length - 1) * 16) / cats.length;
  const iconMap = { weapon: 'weapon', armor: 'armor', accessory: 'accessory', potion: 'potion' };
  cats.forEach((cat, i) => {
    const x = 30 + i * (cw + 16), y = 140, h = 180;
    pixelPanel(ctx, x, y, cw, h, { fill: '#101828', border: '#334155', notch: 10 });
    drawItemIcon(ctx, x + cw / 2 - 30, y + 20, 60, iconMap[cat.key] || 'weapon', '#94A3B8');
    ctx.textAlign = 'center'; ctx.fillStyle = '#F8FAFC'; ctx.font = '700 18px sans-serif';
    ctx.fillText(cat.label, x + cw / 2, y + 110);
    ctx.fillStyle = '#64748B'; ctx.font = '500 13px sans-serif';
    ctx.fillText(`${items.listByCategory(cat.key).length} barang`, x + cw / 2, y + 132);
  });
  ctx.fillStyle = '#64748B'; ctx.font = '500 14px sans-serif'; ctx.textAlign = 'left';
  ctx.fillText('Pilih kategori lewat tombol di bawah.', 30, H - 20);
  return canvas.toBuffer('image/png');
}

function drawClassEmblem(ctx, cx, cy, r, classKey, color) {
  ctx.save();
  ctx.strokeStyle = color; ctx.fillStyle = color; ctx.lineWidth = Math.max(2, r * 0.14);
  ctx.lineJoin = 'round';
  if (classKey === 'warrior') {
    ctx.beginPath();
    ctx.moveTo(cx, cy - r); ctx.lineTo(cx + r * 0.2, cy - r * 0.4); ctx.lineTo(cx + r * 0.2, cy + r * 0.5);
    ctx.lineTo(cx - r * 0.2, cy + r * 0.5); ctx.lineTo(cx - r * 0.2, cy - r * 0.4); ctx.closePath(); ctx.fill();
    ctx.fillRect(cx - r * 0.45, cy + r * 0.5, r * 0.9, r * 0.16);
    ctx.fillRect(cx - r * 0.1, cy + r * 0.66, r * 0.2, r * 0.34);
  } else if (classKey === 'mage') {
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.6, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.24, 0, Math.PI * 2); ctx.fill();
  } else if (classKey === 'assassin') {
    ctx.beginPath(); ctx.moveTo(cx + r, cy - r * 0.7); ctx.lineTo(cx - r * 0.5, cy + r * 0.5); ctx.lineTo(cx - r * 0.28, cy + r * 0.8); ctx.closePath(); ctx.fill();
    ctx.fillRect(cx - r * 0.5, cy + r * 0.42, r * 0.42, r * 0.18);
  } else if (classKey === 'archer') {
    // Busur: lengkung + tali + anak panah.
    ctx.strokeStyle = ctx.fillStyle;
    ctx.lineWidth = Math.max(2, r * 0.14);
    ctx.beginPath(); ctx.arc(cx - r * 0.25, cy, r * 0.72, -Math.PI / 2.4, Math.PI / 2.4); ctx.stroke();
    ctx.lineWidth = Math.max(1, r * 0.07);
    ctx.beginPath(); ctx.moveTo(cx - r * 0.02, cy - r * 0.62); ctx.lineTo(cx - r * 0.02, cy + r * 0.62); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(cx - r * 0.55, cy); ctx.lineTo(cx + r * 0.85, cy); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(cx + r * 0.85, cy - r * 0.18); ctx.lineTo(cx + r, cy); ctx.lineTo(cx + r * 0.85, cy + r * 0.18); ctx.closePath(); ctx.fill();
  }
  ctx.restore();
}

// ---------- CLASS SELECTION (canvas versi /rpg mulai) ----------
function renderClassSelectionCard() {
  const classes = D.CLASS_KEYS.map(k => D.CLASSES[k]);
  const W = 1020;
  const cardW = 480, cardH = 316, gap = 24;
  const headerH = 120;
  const H = headerH + (cardH + gap) * 2 + gap + 34;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingEnabled = false;
  ctx.fillStyle = '#0A0F1C'; ctx.fillRect(0, 0, W, H);
  pixelDither(ctx, 0, 0, W, H, 'rgba(255,255,255,0.035)', 22);

  ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = '#F8FAFC'; ctx.font = '800 40px sans-serif';
  ctx.fillText('PILIH CLASS', W / 2, 54);
  ctx.fillStyle = '#64748B'; ctx.font = '600 18px sans-serif';
  ctx.fillText('Tiap class punya stat dasar dan skill tree yang berbeda', W / 2, 88);

  const maxStat = {};
  ['hp', 'mp', 'atk', 'def', 'spd', 'crit'].forEach(s => { maxStat[s] = Math.max(...classes.map(c => c.base[s])); });

  classes.forEach((c, i) => {
    const col = i % 2, row = Math.floor(i / 2);
    const x = 24 + col * (cardW + gap);
    const y = headerH + row * (cardH + gap);
    pixelPanel(ctx, x, y, cardW, cardH, { fill: '#101828', border: withAlpha(c.color, 0.5), notch: 12 });

    ctx.fillStyle = withAlpha(c.color, 0.18);
    ctx.fillRect(x + 12, y + 12, cardW - 24, 56);
    drawClassEmblem(ctx, x + 58, y + 40, 25, c.key, c.color);

    ctx.textAlign = 'left';
    ctx.fillStyle = lighten(c.color, 0.45); ctx.font = '800 30px sans-serif';
    ctx.fillText(c.name, x + 100, y + 46);
    ctx.fillStyle = '#8B96AB'; ctx.font = '600 16px sans-serif';
    ctx.fillText(c.role, x + 100, y + 68);

    const statLabels = [['hp', 'HP'], ['mp', 'MP'], ['atk', 'ATK'], ['def', 'DEF'], ['spd', 'SPD'], ['crit', 'CRIT']];
    const barX = x + 24, barY = y + 92, barW = cardW - 48;
    statLabels.forEach(([k, label], si) => {
      const by = barY + si * 32;
      ctx.fillStyle = '#8B96AB'; ctx.font = '600 14px sans-serif'; ctx.textAlign = 'left';
      ctx.fillText(label, barX, by + 16);
      pixelBar(ctx, barX + 44, by + 5, barW - 90, 13, c.base[k] / maxStat[k], c.color);
      ctx.fillStyle = '#E2E8F0'; ctx.textAlign = 'right';
      ctx.fillText(String(Math.round(c.base[k])), x + cardW - 24, by + 16);
    });

    const lines = wrapText(ctx, c.description, cardW - 48, 2);
    ctx.fillStyle = '#94A3B8'; ctx.font = '500 14px sans-serif'; ctx.textAlign = 'left';
    lines.forEach((ln, li) => ctx.fillText(ln, x + 24, y + cardH - 30 + li * 19));
  });

  ctx.fillStyle = '#64748B'; ctx.font = '500 15px sans-serif'; ctx.textAlign = 'center';
  ctx.fillText('Klik tombol class di bawah untuk memulai.', W / 2, H - 14);
  return canvas.toBuffer('image/png');
}

// ---------- SKILL TREE (canvas versi /rpg skill tree) ----------
function renderSkillTreeCard({ char, owned }) {
  const cls = D.CLASSES[char.className] || D.CLASSES.warrior;
  const tree = D.SKILL_TREES[char.className] || [];
  const ownedMap = {};
  (owned || []).forEach(s => { ownedMap[s.skillId] = s.level; });
  const byTier = {};
  for (const s of tree) (byTier[s.tier] = byTier[s.tier] || []).push(s);
  const tiers = Object.keys(byTier).map(Number).sort((a, b) => a - b);

  const W = 1040;
  const headerH = 132;
  const rowH = 150;
  const footerH = 54;
  const H = headerH + tiers.length * rowH + footerH;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingEnabled = false;
  ctx.fillStyle = '#0A0F1C'; ctx.fillRect(0, 0, W, H);
  pixelDither(ctx, 0, 0, W, H, 'rgba(255,255,255,0.035)', 22);

  ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = '#F8FAFC'; ctx.font = '800 34px sans-serif';
  ctx.fillText('SKILL TREE', 40, 52);
  ctx.fillStyle = cls.color; ctx.font = '700 22px sans-serif';
  ctx.fillText(cls.name, 40, 84);
  ctx.fillStyle = '#64748B'; ctx.font = '600 16px sans-serif';
  ctx.fillText(`Skill point: ${char.skillPoints}  •  buka lewat /rpg skill unlock <id>`, 40, 112);

  // legend (kanan)
  const legend = [['#3a2a06', '#F59E0B', 'Maks'], ['#334155', '#64748B', 'Terkunci'], ['#101828', '#3B82F6', 'Siap dibuka']];
  let lx = W - 40;
  legend.forEach(([fill, border, label]) => {
    ctx.fillStyle = fill; ctx.strokeStyle = border; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.rect(lx - 14, 28, 14, 14); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#94A3B8'; ctx.font = '600 13px sans-serif'; ctx.textAlign = 'right';
    ctx.fillText(label, lx - 22, 40);
    lx -= 22 + ctx.measureText(label).width + 22;
  });

  // posisi node
  const nodeR = 26;
  const pos = {};
  tiers.forEach((tier, ti) => {
    const nodes = byTier[tier];
    const y = headerH + ti * rowH + rowH / 2;
    const spacing = (W - 140) / nodes.length;
    nodes.forEach((s, si) => {
      const x = 70 + spacing * si + spacing / 2;
      pos[s.id] = { x, y, s };
    });
  });

  // garis prasyarat (dari node induk ke node anak)
  ctx.strokeStyle = '#334155'; ctx.lineWidth = 2;
  for (const s of tree) {
    const me = pos[s.id];
    for (const req of s.requires || []) {
      const parent = pos[req];
      if (!parent) continue;
      ctx.beginPath();
      ctx.moveTo(parent.x, parent.y + nodeR);
      ctx.lineTo(parent.x, me.y - nodeR);
      ctx.lineTo(me.x, me.y - nodeR);
      ctx.stroke();
    }
  }

  // node
  for (const s of tree) {
    const { x, y } = pos[s.id];
    const lvl = ownedMap[s.id] || 0;
    const locked = char.level < s.reqLevel || (s.requires || []).some(r => (ownedMap[r] || 0) < 1);
    const isMax = lvl >= s.maxLevel;
    let fill, border, textCol;
    if (isMax) { fill = '#3a2a06'; border = '#F59E0B'; textCol = '#FBBF24'; }
    else if (lvl > 0) { fill = withAlpha(cls.color, 0.5); border = cls.color; textCol = lighten(cls.color, 0.5); }
    else if (!locked) { fill = '#101828'; border = '#3B82F6'; textCol = '#E2E8F0'; }
    else { fill = '#0d1420'; border = '#334155'; textCol = '#4B5563'; }

    pixelPanel(ctx, x - nodeR, y - nodeR, nodeR * 2, nodeR * 2, { fill, border, notch: 6 });
    const glyph = s.id.includes('_') ? s.id.split('_')[1].slice(0, 2).toUpperCase() : s.id.slice(0, 2).toUpperCase();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = textCol; ctx.font = `800 ${nodeR}px sans-serif`;
    ctx.fillText(glyph, x, y + 1);

    ctx.textBaseline = 'alphabetic';
    ctx.fillStyle = locked ? '#4B5563' : '#E2E8F0';
    ctx.font = '700 15px sans-serif';
    ctx.fillText(s.name, x, y + nodeR + 20);
    ctx.fillStyle = '#64748B'; ctx.font = '600 12px sans-serif';
    ctx.fillText(isMax ? 'MAX' : (lvl > 0 ? `Lv${lvl}/${s.maxLevel}` : `Lv${s.reqLevel}+ • ${s.cost} SP`), x, y + nodeR + 38);
  }

  ctx.fillStyle = '#64748B'; ctx.font = '500 14px sans-serif'; ctx.textAlign = 'left';
  ctx.fillText('Garis = prasyarat. Buka skill dari tier bawah ke atas.', 40, H - 20);
  return canvas.toBuffer('image/png');
}

module.exports = { renderRankEmblem, renderRankLadderCard, renderLevelUpCard, renderProfileRpgCard, renderQuestBoardCard, renderShopCategoryCard, renderShopHomeCard, renderInventoryCard, renderBattleScene, renderClassSelectionCard, renderSkillTreeCard, drawWallet, drawCoin, getBattleBackgrounds: () => BATTLE_BACKGROUNDS };

// ---------- PROFILE CARD (canvas versi /rpg profil) ----------
function statBox(ctx, x, y, w, h, label, value, color) {
  pixelPanel(ctx, x, y, w, h, { fill: '#101828', border: withAlpha(color, 0.55), notch: 7 });
  // Aksen kotak kecil warna stat, ganti ikon emoji (emoji butuh font warna khusus yang sering
  // tidak ada di host server -> muncul kotak kosong). Bentuk sederhana ini pasti kegambar.
  ctx.fillStyle = color; ctx.fillRect(x + 10, y + 11, 8, 8);
  ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = '#8B96AB'; ctx.font = '700 13px sans-serif';
  ctx.fillText(label.toUpperCase(), x + 26, y + 20);
  ctx.fillStyle = color; ctx.font = '800 25px sans-serif';
  ctx.fillText(String(value), x + 14, y + 50);
}
function trackChip(ctx, x, y, w, accentColor, label, value) {
  ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = accentColor; ctx.fillRect(x + w / 2 - 4, y + 8, 8, 8);
  ctx.fillStyle = '#F8FAFC'; ctx.font = '800 20px sans-serif';
  ctx.fillText(String(value), x + w / 2, y + 54);
  ctx.fillStyle = '#64748B'; ctx.font = '700 12px sans-serif';
  ctx.fillText(label.toUpperCase(), x + w / 2, y + 72);
  ctx.textAlign = 'left';
}

// data: { user:{username,displayName,avatarURL}, char:{level,xp,statPoints,skillPoints,gold,
//   questsCompleted,monstersKilled,dungeonsCleared,bossesDefeated,wins,reputation,rankKey,className,
//   hairStyle,hairColor,expression,outfitColor,pantsColor,shoesColor}, stats:{hp,mp,atk,def,spd,crit},
//   xpForNext, promoText }
async function renderProfileRpgCard({ user, char, stats, xpForNext, promoText, cardBg, cardBgUrl }) {
  const W = 1000, H = 640;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingEnabled = false;
  const rank = D.getRank(char.rankKey);
  const cls = D.CLASSES[char.className] || D.CLASSES.warrior;
  const rep = D.reputationTier(char.reputation);
  const accent = cls.color;

  // latar kustomisasi (gradient/foto), lalu panel gelap semi-transparan di atasnya
  // supaya SEMUA elemen kontras & rapi (kartu tidak lagi terlihat "acak-acak").
  await drawCardBackground(ctx, W, H, cardBg, cardBgUrl);
  ctx.fillStyle = 'rgba(8,12,22,0.55)'; ctx.fillRect(0, 0, W, H);

  // ===== HEADER: nama + kelas + level + rank (semua rata kiri, satu garis dasar) =====
  ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = '#F8FAFC'; ctx.font = '800 40px sans-serif';
  const dispName = user?.displayName || user?.username || 'Petualang';
  ctx.fillText(dispName, 48, 78);
  const nameW = Math.min(ctx.measureText(dispName).width, 560);
  ctx.fillStyle = lighten(accent, 0.35); ctx.font = '700 22px sans-serif';
  const subTxt = `${cls.name.toUpperCase()}  •  LEVEL ${char.level}`;
  const subW = ctx.measureText(subTxt).width;
  ctx.fillText(subTxt, 48, 112);
  ctx.font = '700 15px sans-serif'; ctx.fillStyle = '#94A3B8';
  ctx.fillText(`${rank.name}  •  ${rep.name}`, 48 + subW + 18, 112);
  // chip rank di samping nama
  ctx.font = '800 18px sans-serif';
  const chipTxt = `RANK ${rank.key}`;
  const chipW = ctx.measureText(chipTxt).width + 28;
  pixelPanel(ctx, 56 + nameW + 18, 44, chipW, 40, { fill: withAlpha(rank.color, 0.25), border: rank.color, notch: 8 });
  ctx.fillStyle = lighten(rank.color, 0.5);
  ctx.fillText(chipTxt, 56 + nameW + 32, 71);

  // garis pemisah tegas di bawah header
  ctx.fillStyle = withAlpha(accent, 0.85); ctx.fillRect(48, 134, W - 96, 3);
  ctx.fillStyle = 'rgba(255,255,255,0.10)'; ctx.fillRect(48, 139, W - 96, 1);

  // ===== POTRET: hero class dari atlas 0x72 (konsisten dengan web), berdiri pas di dasar panel =====
  const portraitX = 48, portraitY = 168, portraitW = 200, portraitH = 232;
  pixelPanel(ctx, portraitX, portraitY, portraitW, portraitH, { fill: '#0D1420', border: darken(accent, 0.2), notch: 10 });
  pixelDither(ctx, portraitX + 3, portraitY + 3, portraitW - 6, portraitH - 6, withAlpha(accent, 0.12), 14);
  const heroScale = 7;
  const heroDrawn = await drawAtlasSprite(ctx, HERO_ATLAS[char.className] || HERO_ATLAS.warrior,
    portraitX + portraitW / 2 - (16 * heroScale) / 2, portraitY + portraitH - 26, heroScale);
  if (!heroDrawn) {
    // fallback: hero prosedural kustomisasi (bila atlas tidak tersedia di host)
    const heroScale2 = 8;
    const cust = {
      hairStyle: char.hairStyle || 'short', hairColor: char.hairColor || '#1f2937',
      expression: char.expression || 'netral', outfitColor: char.outfitColor || accent,
      pantsColor: char.pantsColor || '#472a19', shoesColor: char.shoesColor || '#0b0b12',
    };
    const heroW = sprites.customHeroWidth(heroScale2), heroH = sprites.customHeroHeight(heroScale2);
    sprites.drawCustomHero(ctx, portraitX + (portraitW - heroW) / 2, portraitY + (portraitH - heroH) / 2 + 6, heroScale2, cust);
  }
  ctx.textAlign = 'center'; ctx.fillStyle = '#8B96AB'; ctx.font = '700 13px sans-serif';
  ctx.fillText(cls.role.toUpperCase(), portraitX + portraitW / 2, portraitY + portraitH - 9);
  ctx.textAlign = 'left';

  // rank emblem kecil di pojok kanan atas
  try {
    const emblem = await loadImage(renderRankEmblem(char.rankKey, 120));
    ctx.drawImage(emblem, W - 152, 34, 104, 104);
  } catch { /* ignore */ }

  // ===== XP BAR + label =====
  const infoX = portraitX + portraitW + 28;
  const barX = infoX, barY = 192, barW = W - 152 - infoX, barH = 22;
  const pct = isFinite(xpForNext) && xpForNext > 0 ? Math.max(0.02, Math.min(1, char.xp / xpForNext)) : 1;
  ctx.fillStyle = '#8B96AB'; ctx.font = '700 15px sans-serif';
  ctx.fillText('PROGRESS XP', barX, barY - 12);
  ctx.textAlign = 'right';
  ctx.fillText(isFinite(xpForNext) ? `${fmtInt(char.xp)} / ${fmtInt(xpForNext)}` : 'XP MAX', barX + barW, barY - 12);
  ctx.textAlign = 'left';
  pixelBar(ctx, barX, barY, barW, barH, pct, accent);

  // ===== COMBAT STAT GRID (3 kolom × 2 baris) =====
  const statsList = [
    ['HP', stats.hp, '#EF4444'], ['MP', stats.mp, '#38BDF8'], ['ATK', stats.atk, '#F97316'],
    ['DEF', stats.def, '#22C55E'], ['SPD', stats.spd, '#EAB308'], ['CRIT', `${stats.crit}%`, '#EC4899'],
  ];
  const gridY = 248, gx = infoX, gw = (barW - 2 * 14) / 3, gh = 62;
  statsList.forEach(([label, val, color], i) => {
    const col = i % 3, row = Math.floor(i / 3);
    statBox(ctx, gx + col * (gw + 14), gridY + row * (gh + 12), gw, gh, label, val, color);
  });

  // ===== POINTS + GOLD (sejajar dengan grid stat) =====
  const pointsY = gridY + 2 * (gh + 12) + 6;
  statBox(ctx, gx, pointsY, gw, gh, 'Stat Point', char.statPoints, '#22D3EE');
  statBox(ctx, gx + gw + 14, pointsY, gw, gh, 'Skill Point', char.skillPoints, '#A855F7');
  statBox(ctx, gx + 2 * (gw + 14), pointsY, gw, gh, 'Gold', fmtInt(char.gold), '#FACC15');

  // ===== TRACK RECORD STRIP =====
  const trackY = pointsY + gh + 18;
  pixelPanel(ctx, 48, trackY, W - 96, 84, { fill: '#0D1420', border: '#232f47', notch: 10 });
  const tw = (W - 96) / 5;
  trackChip(ctx, 48 + tw * 0, trackY + 8, tw, '#38BDF8', 'Quest', char.questsCompleted);
  trackChip(ctx, 48 + tw * 1, trackY + 8, tw, '#22C55E', 'Monster', char.monstersKilled);
  trackChip(ctx, 48 + tw * 2, trackY + 8, tw, '#A78BFA', 'Dungeon', char.dungeonsCleared);
  trackChip(ctx, 48 + tw * 3, trackY + 8, tw, '#F97316', 'Boss', char.bossesDefeated);
  trackChip(ctx, 48 + tw * 4, trackY + 8, tw, '#FACC15', 'Menang', char.wins);

  // promotion footer note
  if (promoText) {
    pixelPanel(ctx, 48, trackY + 96, W - 96, 42, { fill: withAlpha(rank.color, 0.12), border: darken(rank.color, 0.2), notch: 8 });
    ctx.fillStyle = lighten(rank.color, 0.55); ctx.font = '600 16px sans-serif'; ctx.textAlign = 'left';
    ctx.fillText(promoText.length > 92 ? promoText.slice(0, 89) + '...' : promoText, 64, trackY + 123);
  }

  return canvas.toBuffer('image/png');
}

// util kecil format angka (dipakai kartu)
function fmtInt(n) { return (Math.round(Number(n) || 0)).toLocaleString('id-ID'); }

// ============================================================================
// BATTLE SCENE PIXEL-ART (Tahap 3)
// ============================================================================
const BATTLE_BACKGROUNDS = ['forest', 'cave', 'ruins', 'night', 'volcano', 'snow'];

function drawPixelBackground(ctx, W, H, variant) {
  const groundY = H - 90;
  const themes = {
    forest:  { top: '#1e3a2f', bot: '#0f2417', ground: '#2f5233', accent: '#3fbf5f' },
    cave:    { top: '#1f2937', bot: '#0b1120', ground: '#374151', accent: '#6b7280' },
    ruins:   { top: '#3b2f4a', bot: '#1a1424', ground: '#4b4257', accent: '#a78bfa' },
    night:   { top: '#0b1a3a', bot: '#050b1a', ground: '#14204a', accent: '#3b82f6' },
    volcano: { top: '#3a1414', bot: '#160707', ground: '#4a1c14', accent: '#e23636' },
    snow:    { top: '#2a3a4a', bot: '#0f1a24', ground: '#c9d6e2', accent: '#e0f2ff' },
  };
  const t = themes[variant] || themes.forest;
  const sky = ctx.createLinearGradient(0, 0, 0, groundY);
  sky.addColorStop(0, t.top); sky.addColorStop(1, t.bot);
  ctx.fillStyle = sky; ctx.fillRect(0, 0, W, groundY);
  // pixel stars/dots for night/cave
  if (variant === 'night' || variant === 'cave') {
    ctx.fillStyle = variant === 'night' ? '#cbd5e1' : '#4b5563';
    for (let i = 0; i < 40; i++) { const x = (i * 137) % W, y = (i * 71) % (groundY - 40); ctx.fillRect(x, y, 3, 3); }
  }
  // distant blocky hills / structures
  ctx.fillStyle = t.accent + (t.accent.length === 7 ? '55' : '');
  for (let x = -20; x < W + 40; x += 90) {
    const h = 60 + ((x * 13) % 50);
    ctx.globalAlpha = 0.25; ctx.fillRect(x, groundY - h, 70, h); ctx.globalAlpha = 1;
  }
  // ground
  ctx.fillStyle = t.ground; ctx.fillRect(0, groundY, W, H - groundY);
  // ground pixel texture rows
  ctx.fillStyle = 'rgba(0,0,0,0.18)';
  for (let y = groundY + 12; y < H; y += 16) for (let x = 0; x < W; x += 24) ctx.fillRect(x + ((y / 16) % 2) * 12, y, 12, 6);
  return groundY;
}

function drawBar(ctx, x, y, w, h, pct, color, label) {
  ctx.fillStyle = '#0b1120'; roundedPix(ctx, x - 2, y - 2, w + 4, h + 4);
  ctx.fillStyle = '#1e293b'; roundedPix(ctx, x, y, w, h);
  ctx.fillStyle = color; roundedPix(ctx, x, y, Math.max(2, Math.round(w * Math.max(0, Math.min(1, pct)))), h);
  if (label) { ctx.fillStyle = '#f8fafc'; ctx.font = '700 15px sans-serif'; ctx.textAlign = 'left'; ctx.fillText(label, x + 2, y - 8); }
}
function roundedPix(ctx, x, y, w, h) { ctx.fillRect(x, y, w, h); }

async function renderBattleScene(state, { bg } = {}) {
  const W = 960, H = 520;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingEnabled = false;
  const variant = bg || BATTLE_BACKGROUNDS[Math.floor(Math.random() * BATTLE_BACKGROUNDS.length)];
  const groundY = drawPixelBackground(ctx, W, H, variant) + 40;

  const p = state.player, e = state.enemy;
  const pcls = D.CLASSES[p.classKey] || D.CLASSES.warrior;
  const pCustFallback = p.customization || { hairStyle: 'short', hairColor: '#1f2937', expression: 'netral', outfitColor: pcls.color, pantsColor: '#472a19', shoesColor: '#0b0b12' };

  // ---- ukuran dari ATLAS 0x72 (konsisten dengan web). Fallback ke sprite lama bila atlas tidak ada.
  const heroFrame = HERO_ATLAS[p.classKey] || HERO_ATLAS.warrior;
  const heroSize = atlasFrameSize(heroFrame);
  const pScale = 7;
  const pW = heroSize ? heroSize.w * pScale : sprites.customHeroWidth(10);
  const pH = heroSize ? heroSize.h * pScale : sprites.customHeroHeight(10);
  const archetype = (sprites.monsterSprite(e.spriteKey) || {}).key || 'slime';
  const mDef = MONSTER_ATLAS[archetype] || MONSTER_ATLAS.slime;
  const mSize = atlasFrameSize(mDef.base);
  const eScale = ({ normal: 6, elite: 7.5, boss: 9.5, worldboss: 11 }[e.tier] || 6) * (mSize && mSize.w > 24 ? 0.75 : 1);
  const eW = mSize ? mSize.w * eScale : sprites.spriteWidth(archetype, 10);
  const eH = mSize ? mSize.h * eScale : sprites.spriteHeight(archetype, 10);

  // shadows
  ctx.fillStyle = 'rgba(0,0,0,0.35)';
  ctx.fillRect(190, groundY + 8, pW - 20, 14);
  ctx.fillRect(W - eW - 140 + 10, groundY + 8, eW - 20, 16);

  // draw sprites standing EXACTLY on ground line (anchor = kaki), hero menghadap kanan,
  // musuh menghadap kiri (flip). Bila atlas gagal, pakai sprite string-art lama.
  let heroOk = false;
  if (heroSize) {
    await drawAtlasSprite(ctx, heroFrame, 200, groundY + 10, pScale);
    heroOk = true;
  }
  if (!heroOk) {
    sprites.drawCustomHero(ctx, 200, groundY - pH + 10, 10, pCustFallback);
  }
  let monOk = false;
  if (mSize) {
    await drawAtlasSprite(ctx, mDef.base, W - 140 - eW, groundY + 12, eScale, { flip: true, tint: mDef.tint });
    monOk = true;
  }
  if (!monOk) sprites.drawSprite(ctx, archetype, W - eW - 120, groundY - eH + 12, 10, { flip: true, tint: e.tint });

  // ---- HUD atas: panel notch per sisi (bukan bar ngambang telanjang di langit) ----
  const hudW = 380, hudH = 92;
  pixelPanel(ctx, 30, 24, hudW, hudH, { fill: 'rgba(10,15,28,0.82)', border: withAlpha(pcls.color, 0.7), notch: 10 });
  pixelPanel(ctx, W - 30 - hudW, 24, hudW, hudH, { fill: 'rgba(10,15,28,0.82)', border: 'rgba(239,68,68,0.7)', notch: 10 });

  // mini portrait kiri (hero class dari atlas, skala kecil)
  ctx.save(); ctx.beginPath(); ctx.rect(40, 34, 60, 72); ctx.clip();
  const miniOk = heroSize ? await drawAtlasSprite(ctx, heroFrame, 40 + (60 - heroSize.w * 2.6) / 2, 34 + 70, 2.6) : 0;
  if (!miniOk) {
    const miniScale = 3;
    const miniW = sprites.customHeroWidth(miniScale), miniH = sprites.customHeroHeight(miniScale);
    sprites.drawCustomHero(ctx, 40 + (60 - miniW) / 2, 34 + 72 - miniH, miniScale, pCustFallback);
  }
  ctx.restore();
  ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = '#F8FAFC'; ctx.font = '700 16px sans-serif';
  ctx.fillText(`${pcls.name} • Lv${p.level}`, 112, 46);
  pixelBar(ctx, 112, 54, 280, 14, p.hp / p.hpMax, '#ef4444');
  ctx.fillStyle = '#F8FAFC'; ctx.font = '600 12px sans-serif'; ctx.textAlign = 'right';
  ctx.fillText(`${p.hp}/${p.hpMax}`, 392, 51);
  ctx.textAlign = 'left';
  pixelBar(ctx, 112, 76, 280, 11, p.mp / p.mpMax, '#3b82f6');
  ctx.fillStyle = '#93c5fd'; ctx.font = '600 11px sans-serif';
  ctx.fillText(`${p.mp}/${p.mpMax} MP${p.shield > 0 ? `   +${p.shield} shield` : ''}`, 112, 100);

  // mini portrait kanan (monster dari atlas)
  const emScale = mSize ? Math.max(1.2, Math.min(60 / mSize.w, 68 / mSize.h)) : Math.max(2, Math.floor(60 / sprites.spriteCols(archetype)));
  ctx.save(); ctx.beginPath(); ctx.rect(W - 30 - hudW + 10, 34, 60, 72); ctx.clip();
  const emOk = mSize ? await drawAtlasSprite(ctx, mDef.base, W - 30 - hudW + 10 + (60 - mSize.w * emScale) / 2, 34 + 70, emScale, { tint: mDef.tint }) : 0;
  if (!emOk) {
    const emW2 = sprites.spriteWidth(archetype, emScale), emH2 = sprites.spriteHeight(archetype, emScale);
    sprites.drawSprite(ctx, archetype, W - 30 - hudW + 10 + (60 - emW2) / 2, 34 + 72 - emH2, emScale, { tint: e.tint });
  }
  ctx.restore();
  ctx.textAlign = 'left';
  ctx.fillStyle = '#F8FAFC'; ctx.font = '700 16px sans-serif';
  ctx.fillText(`${e.name} • Lv${e.level}`, W - 30 - hudW + 82, 46);
  pixelBar(ctx, W - 30 - hudW + 82, 54, hudW - 92, 14, e.hp / e.hpMax, '#ef4444');
  ctx.fillStyle = '#F8FAFC'; ctx.font = '600 12px sans-serif'; ctx.textAlign = 'right';
  ctx.fillText(`${e.hp}/${e.hpMax}`, W - 30 - 10, 51);
  ctx.textAlign = 'left';

  // round badge tengah (panel notch, bukan kotak hitam polos)
  const badgeW = 130, badgeH = 36;
  pixelPanel(ctx, W / 2 - badgeW / 2, 26, badgeW, badgeH, { fill: 'rgba(10,15,28,0.9)', border: '#4b5670', notch: 8 });
  ctx.textAlign = 'center'; ctx.fillStyle = '#F8FAFC'; ctx.font = '700 17px sans-serif';
  ctx.fillText(`RONDE ${state.round}`, W / 2, 26 + badgeH / 2 + 6);

  return canvas.toBuffer('image/png');
}
