#!/usr/bin/env python3
"""
Unduh ikon skill (aset gratis) ke folder assets/skills/.

Sumber: game-icons.net (lisensi CC BY 3.0 — bebas dipakai dengan atribusi).
Ikon diekspor warna putih (ffffff) dengan latar transparan, ukuran 512x512.

Cara pakai (dari folder dashboard/public):
    python3 download-assets.py
"""
import os
import urllib.request

SKILL_ICONS = {
    # key  : author/icon-name di game-icons.net
    "sword-clash":        "lorc/sword-clash",
    "crossed-swords":     "lorc/crossed-swords",
    "burning-passion":    "lorc/burning-passion",
    "fireball":           "lorc/fireball",
    "snowflake-1":        "lorc/snowflake-1",
    "comet-spark":        "lorc/comet-spark",
    "backstab":           "lorc/backstab",
    "poison-bottle":      "lorc/poison-bottle",
    "skull-crossed-bones":"lorc/skull-crossed-bones",
    "health-normal":      "sbed/health-normal",
    "shield":             "sbed/shield",
    "holy-symbol":        "lorc/holy-symbol",
}

BASE = "https://game-icons.net/icons/ffffff/transparent/1x1/{}.png"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "skills")


def main():
    os.makedirs(OUT, exist_ok=True)
    for name, path in SKILL_ICONS.items():
        url = BASE.format(path)
        dest = os.path.join(OUT, f"{name}.png")
        print(f"Unduh {name}.png ...", end=" ")
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=30) as r, open(dest, "wb") as f:
                f.write(r.read())
            print("OK")
        except Exception as e:  # noqa: BLE001
            print(f"GAGAL ({e})")
    print(f"\nSelesai. Ikon tersimpan di: {OUT}")


if __name__ == "__main__":
    main()
