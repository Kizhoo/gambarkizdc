// ============================================================================
// KIZDEFENSE v2 — Merge Turret Defense (KizhooBot web minigame)
// ----------------------------------------------------------------------------
// Gameplay: beli menara -> taruh di barisan bunker (5 slot aktif) ->
// gabungkan dua menara setingkat (di bunker ATAU inventaris 2x5) menjadi
// tier berikutnya (T1..T20). Bertahan 10 gelombang per bab, bos di
// gelombang 5 & 10, latar berganti tiap bab.
//
// Arsitektur: vanilla canvas penuh (TANPA DOM UI di dalam game, TANPA CDN,
// TANPA engine pihak ketiga) supaya mustahil layar putih karena vendor.
// Aset dimuat toleran-gagal: PNG gagal -> placeholder prosedural.
// ============================================================================

// ============================== KONFIGURASI ==============================
var BUILD = '2026.09.29-2';
var W = 720, H = 1248;

// ---- Tata letak slot (hasil audit piksel Ground-Base kit) ----
var BASE_Y = 761;                                    // offset gambar base
var BUNKER_Y = 831;                                  // y slot bunker
var GRID_YS = [937, 1015];                           // y baris inventaris
var SLOT_XS = [200, 280, 360, 440, 519];             // x kolom (5)
var SLOT_R = 62;                                     // radius sentuh slot
var DEF_LINE = 806;                                  // musuh mencapai pertahanan
var SLOT_KEYS = ['B0','B1','B2','B3','B4',
                 'G0','G1','G2','G3','G4','G5','G6','G7','G8','G9'];
function slotPos(k) {
  if (k[0] === 'B') return { x: SLOT_XS[+k[1]], y: BUNKER_Y, active: true };
  var i = +k[1];
  return { x: SLOT_XS[i % 5], y: GRID_YS[(i / 5) | 0], active: false };
}

// ---- Balance (CERMIN utils/minigameServer.js — jubah satu sumber) ----
var MAX_TIER = 20;
function turretDamage(t) { return Math.round(8 * Math.pow(1.62, t - 1)); }
function turretFireRate(t) { return Math.max(0.5, 1.16 - 0.028 * (t - 1)); } // detik/tembak
function turretRange(t) { return 300 + 14 * t; }
function projFor(tier) { return tier < 7 ? 1 : (tier < 14 ? 2 : 3); }

function buyLevelFor(chapter) { return Math.min(MAX_TIER, 1 + Math.floor((chapter - 1) * 2)); }
function buyCost(level) { return Math.round(90 * Math.pow(1.95, level - 1) / 10) * 10; }
function sellRefund(tier) { return Math.round(buyCost(tier) * 0.5); }

var REWARD = {
  killCoins: function (wave, chapter) { return Math.round((2 + wave * 0.8) * (1 + 0.5 * (chapter - 1))); },
  waveCoins: function (wave, chapter) { return Math.round((40 + wave * 10) * (1 + 0.4 * (chapter - 1))); },
  bossCoins: function (wave, chapter) { return Math.round((120 + wave * 14) * (1 + 0.6 * (chapter - 1))); },
  chapterCoins: function (chapter) { return 300 * chapter; },
  loseConsolation: function (wavesInChapter, chapter) { return 15 * wavesInChapter * chapter; },
  kizcoPerWave: 25, claimMinWaves: 10, claimMaxKizco: 2500,
  claimCooldownMs: 5 * 60 * 1000, saveCooldownMs: 4000,
  coinsMaxGainPerSave: 250000,
};
var BONUS = { cooldownMs: 90 * 1000, tierPlus: 2, luckyChance: 0.12 };
var MILESTONES = { 5: 2000, 10: 10000, 15: 40000, 20: 150000 };
var FEVER = { need: 100, gain: 5, decay: 2.2, duration: 8, rateMult: 1.6 };

// ---- Musuh: hp = hpBase * (1+0.28*(waveInCh-1)) * 1.85^(chapter-1) ----
// kind: ground | fly | boss
var ENEMY_TYPES = [
  { key: 'GreenBeetle',  dir: 'ground', kind: 'ground', hpBase: 13, speed: 52, size: 96,  coins: 1.0, dmg: 5,  chapter: 1 },
  { key: 'OrangeBeetle', dir: 'ground', kind: 'ground', hpBase: 10, speed: 58, size: 92,  coins: 0.8, dmg: 4,  chapter: 1 },
  { key: 'BlackBeetle',  dir: 'ground', kind: 'ground', hpBase: 20, speed: 36, size: 106, coins: 1.3, dmg: 7,  chapter: 1 },
  { key: 'FlyingBrown',  dir: 'fly',    kind: 'fly',   hpBase: 12, speed: 50, size: 94,  coins: 1.1, dmg: 5,  chapter: 1 },
  { key: 'BlueBeetle',   dir: 'ground', kind: 'ground', hpBase: 30, speed: 33, size: 104, coins: 1.6, dmg: 8,  chapter: 2 },
  { key: 'RedBeetle',    dir: 'ground', kind: 'ground', hpBase: 26, speed: 40, size: 104, coins: 1.4, dmg: 7,  chapter: 2 },
  { key: 'FlyingBlue',   dir: 'fly',    kind: 'fly',   hpBase: 22, speed: 56, size: 96,  coins: 1.5, dmg: 6,  chapter: 2 },
  { key: 'PurpleBeetle', dir: 'ground', kind: 'ground', hpBase: 38, speed: 44, size: 106, coins: 1.9, dmg: 9,  chapter: 3 },
  { key: 'FlyingOrange', dir: 'fly',    kind: 'fly',   hpBase: 30, speed: 46, size: 100, coins: 1.8, dmg: 7,  chapter: 3 },
  { key: 'DarkBeetle',   dir: 'ground', kind: 'ground', hpBase: 60, speed: 26, size: 114, coins: 2.6, dmg: 12, chapter: 3 },
  { key: 'HornBeetle',   dir: 'ground', kind: 'ground', hpBase: 85, speed: 21, size: 118, coins: 3.4, dmg: 15, chapter: 4 },
];
var BOSS_TYPES = [
  { key: 'HybridRed',   hpBase: 480,  speed: 17, size: 205, dmg: 28, coins: 9 },
  { key: 'HybridBlue',  hpBase: 640,  speed: 16, size: 212, dmg: 34, coins: 11 },
  { key: 'HybridGreen', hpBase: 820,  speed: 15, size: 219, dmg: 40, coins: 13 },
  { key: 'HybridPur',   hpBase: 1050, speed: 14, size: 226, dmg: 48, coins: 16 },
];

// Latar per bab (urutan file bg: salju, gurun, luar angkasa, lava)
var BG_ORDER = [3, 4, 2, 1];
var CHAPTER_NAMES = ['Dataran Salju', 'Gurun Pasir', 'Angkasa Gelap', 'Tanah Lava'];

function waveInChapter(w) { return ((w - 1) % 10) + 1; }
function chapterOf(w) { return Math.floor((w - 1) / 10) + 1; }
function enemyCountFor(w) {
  var wc = waveInChapter(w), ch = chapterOf(w);
  return Math.min(26, 3 + wc + Math.floor(ch / 2));
}
function spawnIntervalFor(w) { return Math.max(0.55, 1.5 - waveInChapter(w) * 0.06); }
function enemyHpMult(w) { return (1 + 0.28 * (waveInChapter(w) - 1)) * Math.pow(1.85, chapterOf(w) - 1); }
function enemySpeedMult(w) { return 1 + 0.012 * (w - 1); }

// ============================== STATE ==============================
var S = {
  booted: false, user: null, guilds: [], guildId: null,
  wave: 1, bestWave: 0, coins: 300, totalKills: 0,
  slots: {},                       // 'B0'..'G9' -> {tier}
  defHp: 100, defHpMax: 100,
  enemies: [], projectiles: [], booms: [], texts: [], muzzles: [], sparks: [],
  spawning: null,                  // {queue:[{type,boss?}], t, interval}
  waveState: 'intro',              // intro | fighting | cleared | chapterWin | lost
  waveTimer: 0, speedX: 1, paused: false,
  fever: { meter: 0, active: false, t: 0 },
  streak: { merges: 0, t: 0 },
  milestones: {},                  // tier -> true
  bonusAt: 0,                      // timestamp tersedianya bonus
  claim: { eligibleWaves: 0, canClaim: false, estimateKizco: 0 },
  tutorialStep: 0,                 // 0=selesai; 1..4 langkah
  settings: { music: true, sound: true, vibra: true, tips: true, volume: 0.7 },
  popup: null,                     // 'settings' | 'win' | 'lose' | null
  cratePick: null, drag: null, selected: null,
  lastSaveAt: 0, dirty: false, idleEarned: 0,
  shake: 0, flashT: 0, t: 0,
};

// ============================== DOM & UTIL ==============================
var $ = function (id) { return document.getElementById(id); };
var cv = $('cv'), ctx = cv.getContext('2d');
function fmt(n) { n = Math.floor(n); return n >= 1e6 ? (n / 1e6).toFixed(2).replace('.', ',') + 'jt' : n.toLocaleString('id-ID'); }
function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
function dist2(ax, ay, bx, by) { var dx = ax - bx, dy = ay - by; return dx * dx + dy * dy; }
function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function lerp(a, b, t) { return a + (b - a) * t; }

function toast(msg, cls) {
  var d = document.createElement('div');
  d.className = 'toast' + (cls ? ' ' + cls : '');
  d.textContent = msg;
  $('toasts').appendChild(d);
  setTimeout(function () { d.remove(); }, 3300);
}
function vibrate(ms) { if (S.settings.vibra && navigator.vibrate) { try { navigator.vibrate(ms); } catch (e) {} } }

// teks gaya game: outline hitam tebal + isi
function gameText(txt, x, y, size, fill, align, strokeW) {
  ctx.font = '700 ' + size + 'px Silkscreen, "Trebuchet MS", sans-serif';
  ctx.textAlign = align || 'center';
  ctx.textBaseline = 'middle';
  ctx.lineJoin = 'round';
  ctx.strokeStyle = 'rgba(15,10,25,.95)';
  ctx.lineWidth = strokeW || Math.max(3, size * 0.16);
  ctx.strokeText(txt, x, y);
  ctx.fillStyle = fill || '#fff';
  ctx.fillText(txt, x, y);
}
function gameText2(txt, x, y, size, fill, strokeW) { gameText(txt, x, y, size, fill, 'center', strokeW); }

// ============================== LOADER ASET ==============================
var A = { img: {}, failed: {}, count: 0, total: 0 };
var MAN = null;

function loadJSON(url) {
  return fetch(url, { cache: 'no-store' }).then(function (r) { return r.json(); });
}
function loadImg(path) {
  return new Promise(function (res) {
    var im = new Image();
    im.onload = function () { A.img[path] = im; A.count++; res(true); };
    im.onerror = function () { A.failed[path] = true; A.count++; res(false); };
    im.src = path;
  });
}
// daftar aset yang wajib ada (sisanya opsional)
function assetList() {
  var L = [], base = '/assets/minigame/';
  L.push(base + 'base.png');
  for (var t = 1; t <= MAX_TIER; t++) L.push(base + 'turrets/T' + t + '.png');
  ENEMY_TYPES.forEach(function (e) { L.push(base + 'enemies/' + e.dir + '/' + e.key + '.png'); });
  BOSS_TYPES.forEach(function (b) { L.push(base + 'enemies/hybrid/' + b.key + '.png'); });
  BG_ORDER.forEach(function (b) { L.push(base + 'bg/' + b + '.jpg'); });
  ['shoot', 'exp1', 'exp2'].forEach(function (f) { L.push(base + 'fx/' + f + '.png'); });
  [1, 2, 3].forEach(function (i) { L.push(base + 'proj/' + i + '.png'); });
  MAN.ui.forEach(function (u) { L.push(base + 'ui/' + u); });
  L.push(base + 'logo.png');
  return L;
}
function img(path) { return A.img[path] || null; }
function has(path) { return !!A.img[path]; }

// placeholder prosedural bila aset gagal — game tetap jalan
function ph(color) {
  var c = document.createElement('canvas'); c.width = 64; c.height = 64;
  var g = c.getContext('2d');
  g.fillStyle = color; g.fillRect(8, 8, 48, 48);
  g.strokeStyle = '#fff'; g.lineWidth = 4; g.strokeRect(8, 8, 48, 48);
  return c;
}

// ============================== AUDIO (WebAudio synth) ==============================
var AU = { ctx: null, master: null, musicGain: null, musicTimer: null, step: 0 };
function auInit() {
  if (AU.ctx) return;
  try {
    var AC = window.AudioContext || window.webkitAudioContext;
    AU.ctx = new AC();
    AU.master = AU.ctx.createGain();
    AU.master.gain.value = S.settings.volume;
    AU.master.connect(AU.ctx.destination);
    AU.musicGain = AU.ctx.createGain();
    AU.musicGain.gain.value = 0.16;
    AU.musicGain.connect(AU.master);
  } catch (e) { AU.ctx = null; }
}
function auResume() { if (AU.ctx && AU.ctx.state === 'suspended') AU.ctx.resume(); }
function tone(freq, dur, type, vol, slide) {
  if (!AU.ctx || !S.settings.sound) return;
  try {
    var t0 = AU.ctx.currentTime;
    var o = AU.ctx.createOscillator(), g = AU.ctx.createGain();
    o.type = type || 'square';
    o.frequency.setValueAtTime(freq, t0);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, slide), t0 + dur);
    g.gain.setValueAtTime((vol || 0.14), t0);
    g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
    o.connect(g); g.connect(AU.master);
    o.start(t0); o.stop(t0 + dur + 0.02);
  } catch (e) {}
}
function noise(dur, vol, low) {
  if (!AU.ctx || !S.settings.sound) return;
  try {
    var t0 = AU.ctx.currentTime;
    var n = Math.floor(AU.ctx.sampleRate * dur);
    var buf = AU.ctx.createBuffer(1, n, AU.ctx.sampleRate);
    var d = buf.getChannelData(0);
    for (var i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);
    var src = AU.ctx.createBufferSource(); src.buffer = buf;
    var g = AU.ctx.createGain(); g.gain.value = vol || 0.2;
    var f = AU.ctx.createBiquadFilter();
    f.type = 'lowpass'; f.frequency.value = low || 900;
    src.connect(f); f.connect(g); g.connect(AU.master);
    src.start(t0);
  } catch (e) {}
}
var SND = {
  shoot: function (tier) { tone(520 + tier * 14, 0.07, 'square', 0.05, 240); },
  hit:   function () { noise(0.05, 0.08, 1400); },
  boom:  function () { noise(0.28, 0.24, 500); tone(90, 0.25, 'sine', 0.2, 40); },
  merge: function () { tone(440, 0.09, 'triangle', 0.16); setTimeout(function () { tone(554, 0.09, 'triangle', 0.16); }, 70); setTimeout(function () { tone(659, 0.14, 'triangle', 0.18); }, 140); },
  coin:  function () { tone(1180, 0.06, 'square', 0.07); setTimeout(function () { tone(1560, 0.09, 'square', 0.06); }, 50); },
  buy:   function () { tone(300, 0.06, 'square', 0.1, 420); },
  err:   function () { tone(160, 0.16, 'sawtooth', 0.1, 110); },
  boss:  function () { tone(70, 0.5, 'sawtooth', 0.24, 45); noise(0.4, 0.16, 300); },
  win:   function () { [523, 659, 784, 1046].forEach(function (f, i) { setTimeout(function () { tone(f, 0.16, 'triangle', 0.16); }, i * 130); }); },
  lose:  function () { [392, 330, 262, 196].forEach(function (f, i) { setTimeout(function () { tone(f, 0.2, 'sawtooth', 0.12); }, i * 160); }); },
  fever: function () { [660, 880, 660, 1100].forEach(function (f, i) { setTimeout(function () { tone(f, 0.08, 'square', 0.1); }, i * 70); }); },
};
// musik latar: arpeggio lembut 8-langkah
var MUSIC_SEQ = [196, 247, 294, 247, 196, 233, 294, 370];
function musicTick() {
  if (!AU.ctx || !S.settings.music || S.paused) return;
  try {
    var t0 = AU.ctx.currentTime;
    var f = MUSIC_SEQ[AU.step % MUSIC_SEQ.length];
    var o = AU.ctx.createOscillator(), g = AU.ctx.createGain();
    o.type = 'triangle'; o.frequency.value = f;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.linearRampToValueAtTime(0.5, t0 + 0.03);
    g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.55);
    o.connect(g); g.connect(AU.musicGain);
    o.start(t0); o.stop(t0 + 0.6);
    if (AU.step % 4 === 0) { // bass
      var o2 = AU.ctx.createOscillator(), g2 = AU.ctx.createGain();
      o2.type = 'sine'; o2.frequency.value = f / 2;
      g2.gain.setValueAtTime(0.4, t0);
      g2.gain.exponentialRampToValueAtTime(0.001, t0 + 0.5);
      o2.connect(g2); g2.connect(AU.musicGain);
      o2.start(t0); o2.stop(t0 + 0.55);
    }
    AU.step++;
  } catch (e) {}
}
function musicStart() {
  auInit(); auResume();
  if (AU.musicTimer) clearInterval(AU.musicTimer);
  AU.musicTimer = setInterval(musicTick, 300);
}

// ============================== SIMPAN & MUAT ==============================
var DEMO_KEY = 'kizdefense_demo_v2';

function demoSave() {
  try {
    localStorage.setItem(DEMO_KEY, JSON.stringify({
      wave: S.wave, bestWave: S.bestWave, coins: S.coins, totalKills: S.totalKills,
      slots: S.slots, defHp: S.defHp, defHpMax: S.defHpMax,
      milestones: S.milestones, bonusAt: S.bonusAt, tutorialStep: S.tutorialStep,
    }));
  } catch (e) {}
}
function demoLoad() {
  try {
    var raw = localStorage.getItem(DEMO_KEY);
    if (!raw) return false;
    var d = JSON.parse(raw);
    S.wave = Math.max(1, d.wave || 1);
    S.bestWave = d.bestWave || 0;
    S.coins = Math.max(0, d.coins || 0);
    S.totalKills = d.totalKills || 0;
    S.slots = sanitizeSlots(d.slots);
    S.defHpMax = clamp(d.defHpMax || 100, 100, 400);
    S.defHp = clamp(d.defHp || S.defHpMax, 1, S.defHpMax);
    S.milestones = d.milestones || {};
    S.bonusAt = d.bonusAt || 0;
    S.tutorialStep = d.tutorialStep || 0;
    return true;
  } catch (e) { return false; }
}
function sanitizeSlots(raw) {
  var out = {};
  if (!raw || typeof raw !== 'object') return out;
  SLOT_KEYS.forEach(function (k) {
    var v = raw[k];
    if (v && typeof v === 'object') {
      var t = Math.floor(Number(v.tier));
      if (t >= 1 && t <= MAX_TIER) out[k] = { tier: t };
    }
  });
  return out;
}
function countSlots() { return Object.keys(S.slots).length; }

function api(path, opts) {
  return fetch(path, Object.assign({ credentials: 'same-origin', cache: 'no-store' }, opts))
    .then(function (r) { return r.json().then(function (j) { return { status: r.status, json: j }; }); });
}

// Muat progres server; bila akun BARU dan ada progres demo -> IMPOR sekali
// (fix: koin "hilang" setelah login padahal di mode demo sudah ada)
function serverLoad() {
  return api('/api/minigame/state').then(function (r) {
    if (!r.json || !r.json.ok) throw new Error('state gagal');
    var p = r.json.progress;
    var fresh = !p.bestWave && !p.totalKills && !p.coins && !Object.keys(p.turrets || {}).length;
    var demo = null;
    try { demo = JSON.parse(localStorage.getItem(DEMO_KEY) || 'null'); } catch (e) {}
    if (fresh && demo && (demo.bestWave || demo.coins || Object.keys(demo.slots || {}).length)) {
      // impor satu kali: demo -> akun
      return api('/api/minigame/import', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          wave: demo.wave, bestWave: demo.bestWave, coins: demo.coins,
          totalKills: demo.totalKills, slots: demo.slots,
        }),
      }).then(function () { return api('/api/minigame/state'); });
    }
    return r;
  }).then(function (r) {
    var p = r.json.progress;
    S.wave = Math.max(1, p.wave || 1);
    S.bestWave = p.bestWave || 0;
    S.coins = Math.max(0, p.coins || 0);
    S.totalKills = p.totalKills || 0;
    S.slots = sanitizeSlots(p.turrets);
    S.idleEarned = p.idleEarned || 0;
    if (S.idleEarned > 0) {
      setTimeout(function () { toast('Penghasilan idle: +' + fmt(S.idleEarned) + ' koin', 'gold'); }, 900);
    }
    if (r.json.claim) S.claim = r.json.claim;
    if (p.tutorialStep !== undefined) S.tutorialStep = p.tutorialStep;
  });
}

function serverSave(force) {
  if (!S.user) return Promise.resolve();
  var now = Date.now();
  if (!force && now - S.lastSaveAt < REWARD.saveCooldownMs + 1000) return Promise.resolve();
  S.lastSaveAt = now; S.dirty = false;
  return api('/api/minigame/save', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      wave: S.wave, bestWave: S.bestWave, coins: S.coins, totalKills: S.totalKills,
      turrets: S.slots,
      stats: { tutorialStep: S.tutorialStep, defHpMax: S.defHpMax, milestones: S.milestones, bonusAt: S.bonusAt },
    }),
  }).then(function (r) {
    if (r.json && r.json.ok && r.json.claim) S.claim = r.json.claim;
  }).catch(function () {});
}

// ============================== GELOMBANG & MUSUH ==============================

function enemiesForWave(w) {
  var ch = chapterOf(w);
  var pool = ENEMY_TYPES.filter(function (e) { return e.chapter <= ch; });
  var n = enemyCountFor(w);
  var q = [];
  for (var i = 0; i < n; i++) q.push({ def: pick(pool) });
  var wc = waveInChapter(w);
  if (wc === 5) q.splice(Math.floor(n / 2), 0, { def: BOSS_TYPES[(ch - 1) % 4], boss: 'mini' });
  if (wc === 10) q.push({ def: BOSS_TYPES[(ch - 1) % 4], boss: 'big' });
  return q;
}

function startWave(w) {
  S.wave = w;
  S.waveState = 'fighting';
  S.waveTimer = 0;
  var q = enemiesForWave(w);
  S.spawning = { queue: q, t: 1.2, interval: spawnIntervalFor(w), total: q.length, done: 0 };
  S.bestWave = Math.max(S.bestWave, w);
  S.dirty = true;
  var wc = waveInChapter(w);
  if (wc === 5 || wc === 10) {
    banner('BOSS MENDEKAT!', '#ff5a4a');
    SND.boss(); vibrate(120);
  } else {
    banner('GELOMBANG ' + wc + '/10', '#ffd76e');
  }
}

function banner(text, color) {
  S.texts.push({ kind: 'banner', text: text, color: color || '#fff', t: 0, life: 2.0, x: W / 2, y: 330 });
}

function spawnEnemy(item) {
  var d = item.def;
  var hpMult = enemyHpMult(S.wave) * (item.boss === 'big' ? 1.6 : item.boss === 'mini' ? 0.8 : 1);
  var lane = pick(SLOT_XS) + (Math.random() * 36 - 18);
  var e = {
    def: d, boss: item.boss || null,
    x: lane, y: -70 - Math.random() * 40,
    hp: Math.round(d.hpBase * hpMult),
    hpMax: Math.round(d.hpBase * hpMult),
    speed: d.speed * enemySpeedMult(S.wave),
    size: d.size * (item.boss === 'big' ? 1.12 : 1),
    anim: Math.random() * 10, hitT: 0,
    fly: d.kind === 'fly',
    phase: Math.random() * Math.PI * 2,
    state: 'walk',           // walk | startfly | fly (khusus boss)
    stateT: 0,
  };
  if (e.boss) { e.hp = Math.round(e.hp * (1 + 0.12 * (chapterOf(S.wave) - 1))); e.hpMax = e.hp; }
  S.enemies.push(e);
}

function enemyFrame(e, dt) {
  e.anim += dt * (e.fly || e.state === 'fly' ? 14 : 9);
  e.hitT = Math.max(0, e.hitT - dt);
  // gerak
  var sp = e.speed * (e.state === 'fly' ? 1.6 : 1);
  e.y += sp * dt;
  if (e.fly || e.state === 'fly') {
    e.phase += dt * 2.2;
    e.x += Math.sin(e.phase) * 36 * dt;
  } else {
    e.x += Math.sin(e.anim * 0.35) * 10 * dt;
  }
  e.x = clamp(e.x, 48, W - 48);
  // bos: lepas landasan saat HP < 50%
  if (e.boss && e.state === 'walk' && e.hp < e.hpMax * 0.5) { e.state = 'startfly'; e.stateT = 0; }
  if (e.state === 'startfly') {
    e.stateT += dt;
    if (e.stateT > 1.1) { e.state = 'fly'; }
  }
  // mencapai pertahanan -> ledakan + damage
  if (e.y >= DEF_LINE) {
    damageBase(e);
    return false;
  }
  return true;
}

function damageBase(e) {
  var dmg = e.boss ? e.def.dmg * 1.5 : e.def.dmg;
  S.defHp = Math.max(0, S.defHp - Math.round(dmg));
  boom(e.x, DEF_LINE - 24, e.boss ? 1.4 : 0.8, e.boss ? 'exp2' : 'exp1');
  S.shake = Math.min(18, S.shake + (e.boss ? 14 : 6));
  vibrate(e.boss ? 150 : 60);
  noise(0.3, 0.25, 400);
  S.texts.push({ kind: 'dmg', text: '-' + Math.round(dmg), color: '#ff6b5e', x: W / 2, y: DEF_LINE - 60, t: 0, life: 0.9, vy: -46 });
  if (S.defHp <= 0) gameOver();
}

function killEnemy(e, idx) {
  S.enemies.splice(idx, 1);
  S.totalKills++;
  var coins = e.boss
    ? Math.round(REWARD.bossCoins(S.wave, chapterOf(S.wave)) * (1 + 0.15 * (chapterOf(S.wave) - 1)))
    : Math.round(REWARD.killCoins(S.wave, chapterOf(S.wave)) * e.def.coins);
  S.coins += coins;
  boom(e.x, e.y, e.boss ? 1.5 : 0.75, e.boss ? 'exp2' : 'exp1');
  S.texts.push({ kind: 'coin', text: '+' + coins, color: '#ffd76e', x: e.x, y: e.y - 20, t: 0, life: 0.8, vy: -60 });
  if (e.boss) { S.shake = Math.min(20, S.shake + 12); SND.boom(); vibrate(120); }
  else SND.boom();
  // meter demam
  if (!S.fever.active) {
    S.fever.meter = Math.min(FEVER.need, S.fever.meter + FEVER.gain);
    if (S.fever.meter >= FEVER.need) startFever();
  }
  S.dirty = true;
}

function startFever() {
  S.fever.active = true; S.fever.t = FEVER.duration;
  S.fever.meter = 0;
  banner('AMUKAN! TEMBAK RAPAT', '#7dff8a');
  SND.fever();
}

function gameOver() {
  S.waveState = 'lost';
  S.popup = 'lose';
  var wc = waveInChapter(S.wave) - 1;
  var consolation = REWARD.loseConsolation(Math.max(0, wc), chapterOf(S.wave));
  S.coins += consolation;
  S.consolation = consolation;
  SND.lose(); vibrate(300);
  S.dirty = true;
  if (S.user) serverSave(true);
  else demoSave();
}

function waveCleared() {
  var wc = waveInChapter(S.wave), ch = chapterOf(S.wave);
  var bonus = REWARD.waveCoins(S.wave, ch);
  S.coins += bonus;
  S.texts.push({ kind: 'coin', text: '+' + bonus + ' koin', color: '#ffd76e', x: W / 2, y: 400, t: 0, life: 1.4, vy: -40 });
  SND.coin();
  S.dirty = true;
  if (wc === 10) {
    // bab tamat -> popup menang + pilihan peti
    S.waveState = 'chapterWin';
    S.popup = 'win';
    S.defHp = S.defHpMax; // pulih penuh
    SND.win();
    if (S.user) serverSave(true); else demoSave();
  } else {
    S.waveState = 'cleared';
    S.wave = S.wave + 1;   // LANJUT ke gelombang berikutnya
    S.waveTimer = 1.6; // jeda singkat lalu lanjut otomatis
  }
}

// ============================== MENARA & TEMBAKAN ==============================

function activeTurrets() {
  var out = [];
  for (var i = 0; i < 5; i++) {
    var k = 'B' + i;
    if (S.slots[k]) out.push({ key: k, t: S.slots[k].tier });
  }
  return out;
}

var fireCooldowns = {}; // slotKey -> sisa detik
function turretsUpdate(dt) {
  var rate = S.fever.active ? FEVER.rateMult : 1;
  activeTurrets().forEach(function (tr) {
    var cd = fireCooldowns[tr.key] || 0;
    if (cd > 0) { fireCooldowns[tr.key] = cd - dt; return; }
    var p = slotPos(tr.key);
    // target: musuh terdekat menuju pertahanan dalam jangkauan
    var best = null, bestY = -1;
    var rng = turretRange(tr.t);
    for (var i = 0; i < S.enemies.length; i++) {
      var e = S.enemies[i];
      if (e.y < -40) continue;
      if (e.y > p.y - 30) continue;          // hanya yang di atas menara
      if (dist2(e.x, e.y, p.x, p.y) > rng * rng) continue;
      if (e.y > bestY) { bestY = e.y; best = e; }
    }
    if (best) {
      fireCooldowns[tr.key] = turretFireRate(tr.t) / rate;
      var mz = p.y - 46;
      S.projectiles.push({
        x: p.x, y: mz, target: best,
        speed: 640, dmg: turretDamage(tr.t) * (S.fever.active ? 1.25 : 1),
        tier: tr.t, rot: -Math.PI / 2,
      });
      S.muzzles.push({ x: p.x, y: mz - 8, t: 0 });
      SND.shoot(tr.t);
    }
  });
}

function projectilesUpdate(dt) {
  for (var i = S.projectiles.length - 1; i >= 0; i--) {
    var p = S.projectiles[i];
    var e = p.target;
    if (!e || e.hp <= 0 || S.enemies.indexOf(e) < 0) { S.projectiles.splice(i, 1); continue; }
    var dx = e.x - p.x, dy = e.y - p.y;
    var d = Math.sqrt(dx * dx + dy * dy);
    if (d < 26) {
      // KENA
      e.hp -= p.dmg;
      e.hitT = 0.12;
      SND.hit();
      S.sparks.push({ x: p.x, y: p.y, t: 0 });
      S.texts.push({ kind: 'dmg', text: fmt(p.dmg), color: '#fff', x: e.x + (Math.random() * 20 - 10), y: e.y - e.size * 0.3, t: 0, life: 0.55, vy: -70 });
      S.projectiles.splice(i, 1);
      if (e.hp <= 0) {
        var idx = S.enemies.indexOf(e);
        if (idx >= 0) killEnemy(e, idx);
      }
      continue;
    }
    var vx = dx / d * p.speed, vy = dy / d * p.speed;
    p.x += vx * dt; p.y += vy * dt;
    p.rot = Math.atan2(vy, vx);
  }
}

// ============================== BELI / GABUNG / JUAL ==============================

function freeSlot() {
  // beli/bonus masuk INVENTARIS dulu (G*) — pemain yang menaruhnya ke bunker,
  // sesuai game referensi; bunker baru terpakai bila inventaris penuh.
  var grid = SLOT_KEYS.filter(function (k) { return k[0] === 'G' && !S.slots[k]; });
  if (grid.length) return grid[0];
  for (var i = 0; i < 5; i++) { if (!S.slots['B' + i]) return 'B' + i; }
  return null;
}

function buyTurret() {
  var lvl = buyLevelFor(chapterOf(S.wave));
  var cost = buyCost(lvl);
  if (S.coins < cost) { SND.err(); toast('Koin tidak cukup butuh ' + fmt(cost), 'bad'); return; }
  var slot = freeSlot();
  if (!slot) { SND.err(); toast('Papan penuh! Gabungkan atau jual menara', 'bad'); return; }
  var tier = lvl;
  if (Math.random() < BONUS.luckyChance && lvl < MAX_TIER) tier = lvl + 1;
  S.coins -= cost;
  S.slots[slot] = { tier: tier };
  var p = slotPos(slot);
  S.sparks.push({ x: p.x, y: p.y, t: 0, big: true });
  SND.buy();
  if (tier > lvl) toast('HOKI! Dapat Level ' + tier, 'gold');
  checkMilestone(tier);
  S.dirty = true;
  if (S.tutorialStep === 1) S.tutorialStep = 2;
}

function bonusTurret() {
  var now = Date.now();
  if (now < S.bonusAt) { SND.err(); return; }
  var slot = freeSlot();
  if (!slot) { SND.err(); toast('Papan penuh! Gabungkan atau jual menara', 'bad'); return; }
  var lvl = Math.min(MAX_TIER, buyLevelFor(chapterOf(S.wave)) + BONUS.tierPlus);
  S.slots[slot] = { tier: lvl };
  S.bonusAt = now + BONUS.cooldownMs;
  var p = slotPos(slot);
  S.sparks.push({ x: p.x, y: p.y, t: 0, big: true });
  SND.merge();
  toast('Bonus menara Level ' + lvl + '!', 'good');
  checkMilestone(lvl);
  S.dirty = true;
}

function tryMerge(fromKey, toKey) {
  var a = S.slots[fromKey], b = S.slots[toKey];
  if (!a || !b || a.tier !== b.tier || a.tier >= MAX_TIER) return false;
  var newTier = a.tier + 1;
  delete S.slots[fromKey];
  S.slots[toKey] = { tier: newTier };
  var p = slotPos(toKey);
  boom(p.x, p.y - 10, 0.8, 'exp2');
  S.sparks.push({ x: p.x, y: p.y, t: 0, big: true });
  S.texts.push({ kind: 'up', text: 'T' + newTier + '!', color: '#7dd6ff', x: p.x, y: p.y - 60, t: 0, life: 1.0, vy: -55 });
  S.shake = Math.min(10, S.shake + 4);
  SND.merge();
  // rangkaian gabung: bonus koin bila cepat berturut-turut
  S.streak.t = 4;
  S.streak.merges++;
  if (S.streak.merges >= 2) {
    var bonusCoins = 25 * S.streak.merges * chapterOf(S.wave);
    S.coins += bonusCoins;
    S.texts.push({ kind: 'coin', text: 'KOMBO x' + S.streak.merges + ' +' + bonusCoins, color: '#ffd76e', x: W / 2, y: 480, t: 0, life: 1.1, vy: -40 });
  }
  checkMilestone(newTier);
  S.dirty = true;
  if (S.tutorialStep === 3) S.tutorialStep = 0; // selesai tutorial
  return true;
}

function sellTurret(key) {
  var v = S.slots[key];
  if (!v) return;
  var refund = sellRefund(v.tier);
  delete S.slots[key];
  S.coins += refund;
  var p = slotPos(key);
  S.texts.push({ kind: 'coin', text: '+' + refund, color: '#ffd76e', x: p.x, y: p.y, t: 0, life: 0.9, vy: -55 });
  SND.coin();
  S.dirty = true;
}

function autoMerge() {
  // gabung semua pasangan setingkat (berulang) — QoL
  var did = 0;
  var changed = true;
  while (changed) {
    changed = false;
    var byTier = {};
    SLOT_KEYS.forEach(function (k) {
      var v = S.slots[k];
      if (!v || v.tier >= MAX_TIER) return;
      (byTier[v.tier] = byTier[v.tier] || []).push(k);
    });
    Object.keys(byTier).forEach(function (t) {
      var keys = byTier[t];
      if (keys.length >= 2 && !changed) {
        // prioritaskan pasangan di inventaris agar slot bunker tetap terisi
        keys.sort(function (a, b) { return (a[0] === 'B' ? 1 : 0) - (b[0] === 'B' ? 1 : 0); });
        if (tryMerge(keys[0], keys[1])) { did++; changed = true; }
      }
    });
  }
  if (!did) { SND.err(); toast('Tidak ada pasangan setingkat', 'bad'); }
  else toast('Auto-gabung: ' + did + ' kali', 'good');
}

function checkMilestone(tier) {
  if (MILESTONES[tier] && !S.milestones[tier]) {
    S.milestones[tier] = true;
    S.coins += MILESTONES[tier];
    banner('MILESTONE T' + tier + '! +' + fmt(MILESTONES[tier]) + ' koin', '#ffd76e');
    SND.win();
  }
}

// ============================== EFEK VISUAL ==============================
function boom(x, y, scale, which) {
  S.booms.push({ x: x, y: y, t: 0, life: 0.5, scale: scale || 1, which: which || 'exp1' });
}
function fxUpdate(dt) {
  for (var i = S.booms.length - 1; i >= 0; i--) {
    var b = S.booms[i]; b.t += dt;
    if (b.t > b.life) S.booms.splice(i, 1);
  }
  for (i = S.muzzles.length - 1; i >= 0; i--) {
    var m = S.muzzles[i]; m.t += dt;
    if (m.t > 0.09) S.muzzles.splice(i, 1);
  }
  for (i = S.sparks.length - 1; i >= 0; i--) {
    var sp = S.sparks[i]; sp.t += dt;
    if (sp.t > 0.5) S.sparks.splice(i, 1);
  }
  for (i = S.texts.length - 1; i >= 0; i--) {
    var tx = S.texts[i]; tx.t += dt; tx.y += (tx.vy || -50) * dt;
    if (tx.t > tx.life) S.texts.splice(i, 1);
  }
  S.shake = Math.max(0, S.shake - dt * 26);
  S.flashT = Math.max(0, S.flashT - dt * 3);
}

// ============================== RENDER ==============================
var turretAnim = {}; // slotKey -> waktu animasi

function sheetDraw(path, cols, rows, idx, x, y, w, h, rot) {
  var im = img(path);
  if (!im) { im = ph('#888'); }
  var cw = im.width / cols, chh = im.height / rows;
  var r = Math.floor(idx / cols), c = idx % cols;
  ctx.save();
  ctx.translate(x, y);
  if (rot) ctx.rotate(rot);
  ctx.drawImage(im, c * cw, r * chh, cw, chh, -w / 2, -h / 2, w, h);
  ctx.restore();
}

function render() {
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, W, H);
  // guncangan layar
  if (S.shake > 0) {
    ctx.translate((Math.random() - 0.5) * S.shake, (Math.random() - 0.5) * S.shake);
  }

  renderBg();
  renderEnemies();
  renderProjectiles();
  renderBooms();
  renderBase();
  renderSlots();
  renderHUD();
  renderActionBar();
  renderTexts();

  // overlay demam
  if (S.fever.active) {
    ctx.fillStyle = 'rgba(255,120,40,' + (0.06 + 0.03 * Math.sin(S.t * 12)) + ')';
    ctx.fillRect(-20, -20, W + 40, H + 40);
  }
  if (S.flashT > 0) {
    ctx.fillStyle = 'rgba(255,255,255,' + (S.flashT * 0.35) + ')';
    ctx.fillRect(-20, -20, W + 40, H + 40);
  }

  if (S.popup === 'settings') renderSettings();
  else if (S.popup === 'win') renderWin();
  else if (S.popup === 'lose') renderLose();
  renderTutorial();
  ctx.setTransform(1, 0, 0, 1, 0, 0);
}

function renderBg() {
  var ch = chapterOf(S.wave);
  var file = BG_ORDER[(ch - 1) % 4];
  var p = '/assets/minigame/bg/' + file + '.jpg';
  var im = img(p);
  if (im) ctx.drawImage(im, 0, 0, W, H);
  else { ctx.fillStyle = ['#cfd8dc', '#d9c08a', '#3a2a5e', '#e2703a'][file - 1]; ctx.fillRect(0, 0, W, H); }
  // gradasi halus atas biar HUD terbaca
  var g = ctx.createLinearGradient(0, 0, 0, 120);
  g.addColorStop(0, 'rgba(10,8,20,.55)');
  g.addColorStop(1, 'rgba(10,8,20,0)');
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, 120);
}

function renderEnemies() {
  S.enemies.forEach(function (e) {
    var d = e.def;
    var path = '/assets/minigame/enemies/' + (e.boss ? 'hybrid/' + d.key : d.dir + '/' + d.key) + '.png';
    var bob = e.fly || e.state === 'fly' ? Math.sin(e.anim * 0.6) * 7 : Math.sin(e.anim * 0.5) * 3;
    // bayangan
    ctx.fillStyle = 'rgba(0,0,0,.28)';
    ctx.beginPath();
    ctx.ellipse(e.x, e.y + e.size * 0.42, e.size * 0.36, e.size * 0.12, 0, 0, Math.PI * 2);
    ctx.fill();
    var idx;
    if (e.boss) {
      var base = e.state === 'walk' ? 0 : (e.state === 'startfly' ? 30 : 50);
      var len = e.state === 'walk' ? 30 : 20;
      idx = base + (Math.floor(e.anim) % len);
      sheetDraw(path, 10, 7, idx, e.x, e.y + bob, e.size, e.size);
    } else {
      idx = Math.floor(e.anim) % 20;
      sheetDraw(path, 5, 4, idx, e.x, e.y + bob, e.size, e.size);
    }
    // kilat kena tembak
    if (e.hitT > 0) {
      ctx.save();
      ctx.globalAlpha = clamp(e.hitT * 6, 0, 0.75);
      ctx.globalCompositeOperation = 'lighter';
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.arc(e.x, e.y + bob, e.size * 0.42, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
    // HP bar musuh (hanya bila terluka / bos)
    if (e.hp < e.hpMax || e.boss) {
      var bw = e.boss ? e.size * 0.7 : 46;
      var bx = e.x - bw / 2, by = e.y - e.size * 0.52 + bob - 8;
      ctx.fillStyle = 'rgba(10,8,16,.8)';
      rr(bx - 2, by - 2, bw + 4, 10, 5); ctx.fill();
      ctx.fillStyle = e.boss ? '#ff7a4a' : '#7de08a';
      rr(bx, by, bw * clamp(e.hp / e.hpMax, 0, 1), 6, 3); ctx.fill();
    }
  });
}

function rr(x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function renderProjectiles() {
  S.projectiles.forEach(function (p) {
    var path = '/assets/minigame/proj/' + projFor(p.tier) + '.png';
    var im = img(path);
    if (im) {
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rot + Math.PI / 2);
      ctx.drawImage(im, -14, -18, 28, 36);
      ctx.restore();
    }
  });
  S.muzzles.forEach(function (m) {
    var idx = Math.min(4, Math.floor(m.t / 0.09 * 5));
    sheetDraw('/assets/minigame/fx/shoot.png', 5, 3, idx, m.x, m.y, 64, 100);
  });
}

function renderBooms() {
  S.booms.forEach(function (b) {
    var total = b.which === 'exp2' ? 20 : 19;
    var idx = Math.min(total - 1, Math.floor(b.t / b.life * total));
    var size = (b.which === 'exp2' ? 230 : 170) * b.scale;
    sheetDraw('/assets/minigame/fx/' + b.which + '.png', 5, 4, idx, b.x, b.y, size, size);
  });
  S.sparks.forEach(function (sp) {
    var k = sp.t / 0.5;
    ctx.save();
    ctx.globalAlpha = 1 - k;
    ctx.strokeStyle = sp.big ? '#ffe08a' : '#fff';
    ctx.lineWidth = 3;
    for (var i = 0; i < (sp.big ? 10 : 6); i++) {
      var ang = i / (sp.big ? 10 : 6) * Math.PI * 2;
      var r0 = 12 + k * (sp.big ? 70 : 40), r1 = r0 + (sp.big ? 22 : 12);
      ctx.beginPath();
      ctx.moveTo(sp.x + Math.cos(ang) * r0, sp.y + Math.sin(ang) * r0);
      ctx.lineTo(sp.x + Math.cos(ang) * r1, sp.y + Math.sin(ang) * r1);
      ctx.stroke();
    }
    ctx.restore();
  });
}

function renderBase() {
  var im = img('/assets/minigame/base.png');
  if (im) ctx.drawImage(im, 0, BASE_Y, W, im.height * (W / im.width));
  else { ctx.fillStyle = '#4a4a55'; ctx.fillRect(0, BASE_Y, W, 290); }
}

function drawTurretSprite(tier, x, y, size, frameIdx) {
  var path = '/assets/minigame/turrets/T' + tier + '.png';
  sheetDraw(path, 5, 3, frameIdx || 0, x, y, size, size);
}

function renderSlots() {
  var dragKey = S.drag ? S.drag.from : null;
  var dragTier = dragKey && S.slots[dragKey] ? S.slots[dragKey].tier : 0;

  SLOT_KEYS.forEach(function (k) {
    var p = slotPos(k);
    var v = S.slots[k];
    // highlight target saat menyeret
    if (S.drag && k !== dragKey) {
      if (!v) {
        ctx.strokeStyle = 'rgba(255,255,255,.5)';
        ctx.lineWidth = 3;
        ctx.setLineDash([7, 6]);
        ctx.beginPath(); ctx.arc(p.x, p.y, 46, 0, Math.PI * 2); ctx.stroke();
        ctx.setLineDash([]);
      } else if (v.tier === dragTier && v.tier < MAX_TIER) {
        // target gabung: cincin hijau + panah naik kit
        ctx.fillStyle = 'rgba(90,220,120,.25)';
        ctx.beginPath(); ctx.arc(p.x, p.y, 52, 0, Math.PI * 2); ctx.fill();
        var up = img('/assets/minigame/ui/upbar3.png');
        if (up) ctx.drawImage(up, p.x - 22, p.y - 92, 44, 65);
        else gameText2('▲', p.x, p.y - 70, 34, '#7dff8a');
      }
    }
    if (!v || k === dragKey) return; // yang diseret digambar sebagai ghost
    // animasi tembak hanya utk bunker
    var fi = 0;
    if (p.active) {
      var at = turretAnim[k] || 0;
      fi = Math.floor(at * 14) % 15;
    }
    drawTurretSprite(v.tier, p.x, p.y - 6, 106, fi);
    // lencana tier
    ctx.fillStyle = 'rgba(16,12,28,.92)';
    ctx.beginPath(); ctx.arc(p.x + 34, p.y + 30, 15, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = v.tier >= 15 ? '#ffd76e' : (v.tier >= 8 ? '#7dd6ff' : '#b9a8e0');
    ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.arc(p.x + 34, p.y + 30, 15, 0, Math.PI * 2); ctx.stroke();
    gameText2(String(v.tier), p.x + 34, p.y + 31, 15, '#fff', 3);
  });

  // ghost menara yang diseret
  if (S.drag && S.slots[dragKey]) {
    var t = S.slots[dragKey].tier;
    ctx.save();
    ctx.globalAlpha = 0.92;
    ctx.fillStyle = 'rgba(0,0,0,.3)';
    ctx.beginPath(); ctx.ellipse(S.drag.x, S.drag.y + 46, 44, 13, 0, 0, Math.PI * 2); ctx.fill();
    drawTurretSprite(t, S.drag.x, S.drag.y, 118, 0);
    ctx.restore();
  }
}

// ============================== HUD ATAS ==============================
function ui(path) { return img('/assets/minigame/ui/' + path); }

function renderHUD() {
  // ---- uang (kiri) ----
  var mb = ui('moneybar.png');
  if (mb) ctx.drawImage(mb, 10, 10, 216, 73);
  else { ctx.fillStyle = '#2a2140'; rr(10, 10, 216, 73, 18); ctx.fill(); }
  var mi = ui('moneyicon.png');
  if (mi) ctx.drawImage(mi, 26, 26, 44, 44);
  gameText(fmt(S.coins), 118, 47, 21, '#ffe9a8', 'center', 4);

  // ---- gelombang (tengah) ----
  var wb = ui('wavebar_bg.png');
  var wwc = waveInChapter(S.wave);
  var wx = W / 2 - 148, wy = 16;
  if (wb) ctx.drawImage(wb, wx, wy, 296, 41);
  else { ctx.fillStyle = '#3a2412'; rr(wx, wy, 296, 41, 12); ctx.fill(); }
  var wr = ui('wavebar_red.png');
  var prog = S.spawning ? (S.spawning.done / S.spawning.total) : 1;
  if (wr) {
    var fw = 264 * clamp(prog, 0, 1);
    if (fw > 2) ctx.drawImage(wr, 0, 0, wr.width * clamp(prog, 0, 1), wr.height, wx + 16, wy + 10, fw, 21);
  }
  gameText('GEL. ' + wwc + '/10', W / 2, wy + 20, 17, '#fff', 'center', 4);

  // ---- tombol kecepatan + pengaturan (kanan) ----
  var sx = W - 66, sy2 = 12;
  var si = ui('setting_icon.png');
  if (si) ctx.drawImage(si, sx, sy2, 52, 55);
  else { ctx.fillStyle = '#e8862a'; rr(sx, sy2, 52, 55, 12); ctx.fill(); }
  // kecepatan 2x
  var bx = W - 130;
  ctx.fillStyle = S.speedX === 2 ? '#ffcf4d' : '#5a4a78';
  rr(bx, 16, 54, 46, 12); ctx.fill();
  ctx.strokeStyle = 'rgba(15,10,25,.8)'; ctx.lineWidth = 3; rr(bx, 16, 54, 46, 12); ctx.stroke();
  gameText2(S.speedX + 'x', bx + 27, 40, 17, S.speedX === 2 ? '#4a2c05' : '#d8ccf2', 3);

  // ---- bar pertahanan (di atas bunker) ----
  var dbw = 560, dbx = (W - dbw) / 2, dby = 736;
  var db = ui('defbar_bg.png');
  if (db) ctx.drawImage(db, dbx, dby, dbw, 15);
  else { ctx.fillStyle = '#20182e'; rr(dbx, dby, dbw, 15, 7); ctx.fill(); }
  var dg = ui('defbar_green.png');
  var hpf = clamp(S.defHp / S.defHpMax, 0, 1);
  if (dg && hpf > 0.01) ctx.drawImage(dg, 0, 0, dg.width * hpf, dg.height, dbx + 3, dby + 3, (dbw - 6) * hpf, 9);
  var di = ui('defbar_icon.png');
  if (di) ctx.drawImage(di, dbx - 46, dby - 16, 42, 45);
  gameText(S.defHp + '/' + S.defHpMax, W / 2, dby - 12, 14, '#c8f5cf', 'center', 4);

  // ---- meter demam (tipis, bawah bar pertahanan) ----
  if (!S.fever.active) {
    var fw2 = 300 * clamp(S.fever.meter / FEVER.need, 0, 1);
    ctx.fillStyle = 'rgba(20,14,30,.7)'; rr(W / 2 - 152, dby + 22, 304, 10, 5); ctx.fill();
    if (fw2 > 3) {
      var fg = ctx.createLinearGradient(W / 2 - 150, 0, W / 2 + 150, 0);
      fg.addColorStop(0, '#ffb347'); fg.addColorStop(1, '#ff5a3c');
      ctx.fillStyle = fg; rr(W / 2 - 150, dby + 24, fw2, 6, 3); ctx.fill();
    }
  } else {
    gameText2('AMUKAN ' + S.fever.t.toFixed(1) + 's', W / 2, dby + 28, 15, '#ffb347', 4);
  }
}

// ============================== BAR AKSI BAWAH ==============================
var BTNS = {
  buy:    { x: 14,  y: 1096, w: 310, h: 136 },
  bonus:  { x: 336, y: 1092, w: 182, h: 84 },
  auto:   { x: 528, y: 1092, w: 182, h: 84 },
  trash:  { x: 336, y: 1186, w: 182, h: 56 },
  kizco:  { x: 528, y: 1186, w: 182, h: 56 },
};

function renderActionBar() {
  // panel gelap
  var g = ctx.createLinearGradient(0, 1072, 0, H);
  g.addColorStop(0, 'rgba(16,11,28,.0)');
  g.addColorStop(0.25, 'rgba(16,11,28,.92)');
  g.addColorStop(1, 'rgba(10,7,18,.98)');
  ctx.fillStyle = g; ctx.fillRect(0, 1072, W, H - 1072);

  // ---- BELI ----
  var b = BTNS.buy;
  var lvl = buyLevelFor(chapterOf(S.wave));
  var cost = buyCost(lvl);
  var afford = S.coins >= cost;
  var bo = ui(afford ? 'btn_orange.png' : 'btn_orange_pressed.png');
  if (bo) ctx.drawImage(bo, b.x, b.y + 10, b.w, 116);
  else { ctx.fillStyle = afford ? '#e8862a' : '#7a5636'; rr(b.x, b.y + 10, b.w, 116, 20); ctx.fill(); }
  drawTurretSprite(lvl, b.x + 62, b.y + 66, 88, 0);
  gameText('BELI', b.x + 128, b.y + 38, 19, '#fff');
  gameText('LEVEL ' + lvl, b.x + 128, b.y + 68, 15, '#ffe9a8');
  var mi2 = ui('moneyicon.png');
  if (mi2) ctx.drawImage(mi2, b.x + 128, b.y + 84, 26, 26);
  gameText(fmt(cost), b.x + 160, b.y + 98, 16, '#ffe9a8', 'left', 3);

  // ---- BONUS (cooldown) ----
  var bb = BTNS.bonus;
  var now = Date.now();
  var ready = now >= S.bonusAt;
  var bi = ui(ready ? 'bonus_btn.png' : 'bonus_btn_disable.png');
  if (bi) ctx.drawImage(bi, bb.x, bb.y, bb.w, bb.h);
  else { ctx.fillStyle = ready ? '#d95b3a' : '#6a4a3a'; rr(bb.x, bb.y, bb.w, bb.h, 16); ctx.fill(); }
  if (ready) {
    gameText('BONUS', bb.x + bb.w / 2, bb.y + 28, 17, '#fff');
    gameText('MENARA GRATIS', bb.x + bb.w / 2, bb.y + 56, 10, '#ffe0c9');
  } else {
    var rem = Math.ceil((S.bonusAt - now) / 1000);
    gameText('BONUS', bb.x + bb.w / 2, bb.y + 26, 15, '#d8c8c0');
    gameText2(rem + 's', bb.x + bb.w / 2, bb.y + 55, 18, '#ffb347', 4);
  }

  // ---- AUTO GABUNG ----
  var ab = BTNS.auto;
  var ag = ui('btn_green.png');
  if (ag) ctx.drawImage(ag, ab.x, ab.y, ab.w, ab.h);
  else { ctx.fillStyle = '#4fae6a'; rr(ab.x, ab.y, ab.w, ab.h, 16); ctx.fill(); }
  gameText('AUTO', ab.x + ab.w / 2, ab.y + 30, 17, '#eafff0');
  gameText('GABUNG', ab.x + ab.w / 2, ab.y + 58, 13, '#c8f5d4');

  // ---- JUAL (tempat sampah) ----
  var tb = BTNS.trash;
  var hot = S.drag ? true : false;
  ctx.fillStyle = hot ? 'rgba(255,120,90,.25)' : 'rgba(60,40,60,.55)';
  rr(tb.x, tb.y, tb.w, tb.h, 14); ctx.fill();
  ctx.strokeStyle = hot ? '#ff8a6a' : 'rgba(255,255,255,.25)';
  ctx.lineWidth = 3; rr(tb.x, tb.y, tb.w, tb.h, 14); ctx.stroke();
  var tr = ui('trash_btn.png');
  if (tr) ctx.drawImage(tr, tb.x + 16, tb.y + 4, 48, 48);
  gameText('JUAL', tb.x + 84, tb.y + 29, 15, hot ? '#ffd7cf' : '#d8ccc8', 'left', 3);

  // ---- KIZCO ----
  var kb = BTNS.kizco;
  ctx.fillStyle = 'rgba(90,70,30,.75)';
  rr(kb.x, kb.y, kb.w, kb.h, 14); ctx.fill();
  ctx.strokeStyle = S.claim.canClaim ? '#ffd76e' : 'rgba(255,255,255,.25)';
  ctx.lineWidth = 3; rr(kb.x, kb.y, kb.w, kb.h, 14); ctx.stroke();
  gameText('KIZCO', kb.x + 22, kb.y + 29, 15, '#ffd76e', 'left', 3);
  gameText(S.claim.canClaim ? 'KLAIM!' : fmt(S.claim.estimateKizco), kb.x + 108, kb.y + 29, 13, '#fff', 'left', 3);
}

// ============================== TEKS MELAYANG ==============================
function renderTexts() {
  S.texts.forEach(function (t) {
    var k = t.t / t.life;
    ctx.save();
    ctx.globalAlpha = clamp(1.2 - k, 0, 1);
    if (t.kind === 'banner') {
      var yy = t.y - Math.sin(clamp(k, 0, 1) * Math.PI) * 18;
      ctx.globalAlpha = k < 0.85 ? 1 : (1 - k) / 0.15;
      gameText(t.text, t.x, yy, 40, t.color, 'center', 8);
      gameText(t.text, t.x, yy, 40, t.color, 'center', 8);
    } else {
      var sz = t.kind === 'up' ? 30 : (t.kind === 'coin' ? 19 : 16);
      gameText(t.text, t.x, t.y, sz, t.color, 'center', sz * 0.18);
    }
    ctx.restore();
  });
}

// ============================== POPUP ==============================
function dimScreen(alpha) {
  ctx.fillStyle = 'rgba(8,6,16,' + (alpha || 0.72) + ')';
  ctx.fillRect(-30, -30, W + 60, H + 60);
}

function renderSettings() {
  dimScreen(0.78);
  var pw = 560, ph = 780, px = (W - pw) / 2, py = 200;
  var pb = ui('popup_box.png');
  if (pb) ctx.drawImage(pb, px, py, pw, ph);
  else { ctx.fillStyle = '#241b3a'; rr(px, py, pw, ph, 26); ctx.fill(); }
  var cb = ui('btn_close.png');
  if (cb) ctx.drawImage(cb, px + pw - 62, py + 18, 44, 44);
  SET.closeBtn = { x: px + pw - 62, y: py + 18, w: 44, h: 44 };
  gameText('PENGATURAN', px + pw / 2 - 10, py + 44, 24, '#ffe9a8');

  // toggles: musik / suara / getar / tips
  var items = [
    ['music', 'btn_music_on.png', 'MUSIK'],
    ['sound', 'btn_sound_' + (S.settings.sound ? 'on' : 'off') + '.png', 'SUARA'],
    ['vibra', 'btn_vibra_' + (S.settings.vibra ? 'on' : 'off') + '.png', 'GETAR'],
    ['tips', 'btn_tips_' + (S.settings.tips ? 'on' : 'off') + '.png', 'TIPS'],
  ];
  SET.toggles = [];
  items.forEach(function (it, i) {
    var tx = px + 62 + i * 118, ty = py + 96;
    var im = ui(it[1]);
    ctx.save();
    if (!S.settings[it[0]]) { ctx.globalAlpha = 0.45; ctx.filter = 'grayscale(80%)'; }
    if (im) ctx.drawImage(im, tx, ty, 78, 80);
    ctx.restore();
    if (!im) { ctx.fillStyle = '#e8862a'; rr(tx, ty, 78, 80, 16); ctx.fill(); }
    gameText(it[2], tx + 39, ty + 104, 11, '#d8ccf2');
    SET.toggles.push({ key: it[0], x: tx, y: ty, w: 78, h: 80 });
  });

  // volume
  var vx = px + 80, vy = py + 240, vw = pw - 160;
  gameText('VOLUME', px + pw / 2, vy - 18, 14, '#d8ccf2');
  var vb = ui('volume_bar.png');
  if (vb) ctx.drawImage(vb, vx, vy, vw, 74);
  else { ctx.fillStyle = '#382a52'; rr(vx, vy, vw, 74, 20); ctx.fill(); }
  var vg = ui('volume_green.png');
  if (vg) ctx.drawImage(vg, vx + 30, vy + 34, (vw - 60) * S.settings.volume, 18);
  var vh = ui('volume_handle.png');
  var hx = vx + 30 + (vw - 60) * S.settings.volume;
  if (vh) ctx.drawImage(vh, hx - 16, vy + 18, 42, 44);
  else { ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(hx, vy + 43, 18, 0, Math.PI * 2); ctx.fill(); }
  SET.volume = { x: vx + 30, y: vy + 26, w: vw - 60, h: 34 };

  // klaim Kizco
  var cy = py + 360;
  gameText('KLAIM KIZCO', px + pw / 2, cy, 17, '#ffd76e');
  gameText('Gelombang siap: ' + S.claim.eligibleWaves + ' (min ' + S.claim.minWaves + ')', px + pw / 2, cy + 30, 12, '#d8ccf2');
  gameText('Estimasi: ' + fmt(S.claim.estimateKizco) + ' KZC', px + pw / 2, cy + 54, 13, '#fff');
  var cg = ui(S.claim.canClaim ? 'btn_green.png' : 'btn_green_pressed.png');
  var cgb = { x: px + pw / 2 - 120, y: cy + 74, w: 240, h: 72 };
  if (cg) ctx.drawImage(cg, cgb.x, cgb.y, cgb.w, cgb.h);
  else { ctx.fillStyle = S.claim.canClaim ? '#4fae6a' : '#3a6a4a'; rr(cgb.x, cgb.y, cgb.w, cgb.h, 16); ctx.fill(); }
  gameText('KLAIM', cgb.x + 120, cgb.y + 37, 19, '#eafff0');
  SET.claimBtn = cgb;

  // papan peringkat mini (5 teratas dimuat malas)
  var ly = cy + 170;
  gameText('PAPAN PERINGKAT', px + pw / 2, ly, 15, '#7dd6ff');
  if (S.leaderboard && S.leaderboard.length) {
    S.leaderboard.slice(0, 5).forEach(function (row, i) {
      var yy = ly + 32 + i * 34;
      gameText((i + 1) + '.', px + 90, yy, 13, '#b9a8e0', 'left', 3);
      gameText(String(row.name).slice(0, 14), px + 120, yy, 13, '#fff', 'left', 3);
      gameText('Gel. ' + row.bestWave, px + pw - 90, yy, 13, '#ffd76e', 'left', 3);
    });
  } else {
    gameText('Belum ada data', px + pw / 2, ly + 36, 12, '#8a7aa8');
  }
  // status akun + tombol masuk utk tamu
  var ay = py + ph - 44;
  if (S.user) {
    gameText('Masuk sebagai ' + String(S.user.username || S.user.id).slice(0, 18), px + pw / 2, ay, 11, '#8a7aa8');
  } else {
    var lb = { x: px + pw / 2 - 150, y: ay - 62, w: 300, h: 64 };
    var li = ui('btn_green.png');
    if (li) ctx.drawImage(li, lb.x, lb.y, lb.w, lb.h);
    else { ctx.fillStyle = '#5865F2'; rr(lb.x, lb.y, lb.w, lb.h, 14); ctx.fill(); }
    gameText('MASUK DENGAN DISCORD', lb.x + 150, lb.y + 33, 13, '#fff');
    gameText('Mode tamu — progres tersimpan di perangkat', px + pw / 2, ay + 8, 10, '#8a7aa8');
    SET.loginBtn = lb;
  }
}

function renderWin() {
  dimScreen(0.72);
  var wb = ui('win_bg.png');
  var ww = 340, wh = 880, wx = (W - ww) / 2, wy = 150;
  if (wb) ctx.drawImage(wb, wx, wy, ww, wh);
  else { ctx.fillStyle = '#2a5a3a'; rr(wx, wy, ww, wh, 30); ctx.fill(); }
  var b1 = ui('win_bar1.png'), b2 = ui('win_bar2.png');
  if (b1) ctx.drawImage(b1, W / 2 - 230, wy + 60, 460, 74);
  if (b2) ctx.drawImage(b2, W / 2 - 230, wy + wh - 140, 460, 74);
  gameText('BAB ' + chapterOf(S.wave) + ' TAMAT!', W / 2, wy + 100, 27, '#ffe9a8', 'center', 6);
  gameText(CHAPTER_NAMES[(chapterOf(S.wave) - 1) % 4] + ' aman', W / 2, wy + 148, 14, '#d8f5dc');

  // pilihan peti (3 tombol)
  gameText('PILIH SATU HADIAH', W / 2, wy + 210, 16, '#fff');
  var crates = crateOptions();
  SET.crates = [];
  crates.forEach(function (c, i) {
    var cw = 260, chh = 118, cx = W / 2 - cw / 2, cy2 = wy + 250 + i * 136;
    var bi = ui('btn_green.png');
    if (bi) ctx.drawImage(bi, cx, cy2, cw, chh);
    else { ctx.fillStyle = '#4fae6a'; rr(cx, cy2, cw, chh, 20); ctx.fill(); }
    gameText(c.title, W / 2, cy2 + 38, 17, '#eafff0');
    gameText(c.desc, W / 2, cy2 + 68, 12, '#c8f5d4');
    gameText2(c.icon, W / 2, cy2 + 94, 16, '#ffe9a8');
    SET.crates.push({ idx: i, x: cx, y: cy2, w: cw, h: chh });
  });
}

function crateOptions() {
  var ch = chapterOf(S.wave);
  return [
    { id: 'coins', icon: '$', title: 'PETI KOIN', desc: '+' + fmt(REWARD.chapterCoins(ch)) + ' koin' },
    { id: 'turret', icon: 'T', title: 'PETI MENARA', desc: 'Menara Level ' + Math.min(MAX_TIER, buyLevelFor(ch) + 3) + ' gratis' },
    { id: 'defense', icon: '+', title: 'PETI BENTENG', desc: 'HP pertahanan +25 & pulih penuh' },
  ];
}

function renderLose() {
  dimScreen(0.75);
  var lb = ui('lose_bg.png');
  var lw = 340, lh = 760, lx = (W - lw) / 2, ly = 190;
  if (lb) ctx.drawImage(lb, lx, ly, lw, lh);
  else { ctx.fillStyle = '#5a2a2a'; rr(lx, ly, lw, lh, 30); ctx.fill(); }
  var b1 = ui('lose_bar1.png'), b2 = ui('lose_bar2.png');
  if (b1) ctx.drawImage(b1, W / 2 - 230, ly + 60, 460, 74);
  if (b2) ctx.drawImage(b2, W / 2 - 230, ly + lh - 140, 460, 74);
  gameText('PERTAHANAN JATUH', W / 2, ly + 100, 22, '#ff9a8a', 'center', 6);
  gameText('Gelombang ' + waveInChapter(S.wave) + ' Bab ' + chapterOf(S.wave), W / 2, ly + 146, 14, '#f5d8d4');
  gameText('Menara & koin tetap aman', W / 2, ly + 176, 12, '#d8c0bc');
  if (S.consolation > 0) {
    gameText('Trofi keberanian:', W / 2, ly + 240, 13, '#ffd76e');
    gameText('+' + fmt(S.consolation) + ' koin', W / 2, ly + 272, 20, '#ffe9a8');
  }
  var rb = { x: W / 2 - 120, y: ly + lh - 190, w: 240, h: 80 };
  var bi = ui('btn_green.png');
  if (bi) ctx.drawImage(bi, rb.x, rb.y, rb.w, rb.h);
  else { ctx.fillStyle = '#4fae6a'; rr(rb.x, rb.y, rb.w, rb.h, 18); ctx.fill(); }
  gameText('COBA LAGI', W / 2, rb.y + 41, 19, '#eafff0');
  SET.retryBtn = rb;
}

// ============================== TUTORIAL ==============================
function renderTutorial() {
  if (!S.tutorialStep || S.popup) return;
  var step = S.tutorialStep;
  dimScreen(0.55);
  ctx.save();
  ctx.globalCompositeOperation = 'destination-out';
  ctx.fillStyle = '#fff';
  var target = null;
  if (step === 1) target = BTNS.buy;
  else if (step === 2) {
    // slot pertama yang berisi menara
    SLOT_KEYS.forEach(function (k) { if (!target && S.slots[k]) { var p = slotPos(k); target = { x: p.x - 55, y: p.y - 55, w: 110, h: 110 }; } });
  } else if (step === 3) {
    target = { x: 60, y: 770, w: 600, h: 280 };
  }
  if (target) {
    rr(target.x, target.y, target.w, target.h, 26);
    ctx.fill();
  }
  ctx.restore();
  // panah + teks
  var msg = step === 1 ? 'Ketuk BELI untuk menara pertamamu!'
        : step === 2 ? 'Tarik menara ke barisan BUNKER (atas) supaya menembak'
        : 'Gabungkan 2 menara SETINGKAT jadi lebih kuat!';
  var ty = step === 1 ? 940 : (step === 2 ? 700 : 660);
  var bx2 = step === 1 ? BTNS.buy.x + BTNS.buy.w / 2 : W / 2;
  ctx.fillStyle = 'rgba(14,10,26,.92)';
  rr(W / 2 - 260, ty - 44, 520, 78, 18); ctx.fill();
  ctx.strokeStyle = '#ffd76e'; ctx.lineWidth = 3; rr(W / 2 - 260, ty - 44, 520, 78, 18); ctx.stroke();
  ctx.font = '700 15px Silkscreen, "Trebuchet MS", sans-serif';
  ctx.fillStyle = '#ffe9a8'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  wrapText(msg, W / 2, ty - 14, 480, 19);
  // panah menunjuk
  ctx.fillStyle = '#ffd76e';
  ctx.beginPath();
  ctx.moveTo(bx2, ty + 38);
  ctx.lineTo(bx2 - 14, ty + 62);
  ctx.lineTo(bx2 + 14, ty + 62);
  ctx.closePath(); ctx.fill();
}
function wrapText(txt, x, y, maxW, lh) {
  var words = txt.split(' '), lines = [], cur = '';
  words.forEach(function (w2) {
    var test = cur ? cur + ' ' + w2 : w2;
    if (ctx.measureText(test).width > maxW && cur) { lines.push(cur); cur = w2; }
    else cur = test;
  });
  if (cur) lines.push(cur);
  lines.forEach(function (l, i) { ctx.fillText(l, x, y + i * lh); });
}
var SET = {}; // registry area klik popup (diisi saat render)

// ============================== INPUT ==============================
function toCanvas(ev) {
  var r = cv.getBoundingClientRect();
  return {
    x: (ev.clientX - r.left) / r.width * W,
    y: (ev.clientY - r.top) / r.height * H,
  };
}
function inRect(p, r) { return p.x >= r.x && p.x <= r.x + r.w && p.y >= r.y && p.y <= r.y + r.h; }

function onDown(ev) {
  auResume();
  if (!S.booted) return;
  var p = toCanvas(ev);
  ev.preventDefault();

  // ----- popup menang input penuh -----
  if (S.popup === 'settings') return settingsDown(p);
  if (S.popup === 'win') return winDown(p);
  if (S.popup === 'lose') return loseDown(p);

  // ----- tutorial: langkah 1 hanya tombol beli -----
  if (S.tutorialStep === 1) {
    if (inRect(p, BTNS.buy)) buyTurret();
    return;
  }

  // ----- tombol bar aksi -----
  if (inRect(p, BTNS.buy)) { buyTurret(); return; }
  if (inRect(p, BTNS.bonus)) { bonusTurret(); return; }
  if (inRect(p, BTNS.auto)) { autoMerge(); return; }
  if (inRect(p, BTNS.trash)) { toast('Tarik menara ke tombol JUAL untuk menjual (50% harga)', 'bad'); return; }
  if (inRect(p, BTNS.kizco)) { openSettings(); return; }

  // ----- HUD -----
  if (p.x > W - 130 && p.y < 70) {
    if (p.x < W - 74) { // kecepatan
      S.speedX = S.speedX === 2 ? 1 : 2;
      toast(S.speedX === 2 ? 'Kecepatan 2x aktif' : 'Kecepatan normal');
      return;
    }
    openSettings(); return;
  }

  // ----- mulai seret menara -----
  var bestK = null, bestD = SLOT_R * SLOT_R;
  SLOT_KEYS.forEach(function (k) {
    if (!S.slots[k]) return;
    var sp = slotPos(k);
    var d = dist2(p.x, p.y, sp.x, sp.y);
    if (d < bestD) { bestD = d; bestK = k; }
  });
  if (bestK) {
    S.drag = { from: bestK, x: p.x, y: p.y - 30 };
  }
}

function onMove(ev) {
  if (!S.drag) return;
  ev.preventDefault();
  var p = toCanvas(ev);
  S.drag.x = p.x; S.drag.y = p.y - 30;
}

function onUp(ev) {
  if (!S.drag) return;
  ev.preventDefault();
  var p = toCanvas(ev);
  var from = S.drag.from;
  var drag = S.drag;
  S.drag = null;

  // jual?
  if (inRect(p, BTNS.trash) || (p.y > 1150 && p.x > 320 && p.y < 1250)) {
    sellTurret(from);
    return;
  }
  // cari slot tujuan
  var bestK = null, bestD = SLOT_R * SLOT_R;
  SLOT_KEYS.forEach(function (k) {
    if (k === from) return;
    var sp = slotPos(k);
    var d = dist2(p.x, p.y, sp.x, sp.y);
    if (d < bestD) { bestD = d; bestK = k; }
  });
  if (bestK) {
    var a = S.slots[from], b = S.slots[bestK];
    if (!b) { // pindah
      S.slots[bestK] = a; delete S.slots[from];
      SND.buy();
      if (S.tutorialStep === 2 && bestK[0] === 'B') S.tutorialStep = 3;
      S.dirty = true;
    } else if (b.tier === a.tier && a.tier < MAX_TIER) {
      tryMerge(from, bestK);
    } else { // tukar
      S.slots[bestK] = a; S.slots[from] = b;
      SND.buy();
      S.dirty = true;
    }
  }
}

function openSettings() {
  S.paused = true;
  S.popup = 'settings';
  SND.buy();
  if (S.user) {
    api('/api/minigame/leaderboard').then(function (r) {
      if (r.json && r.json.ok) S.leaderboard = r.json.leaderboard;
    }).catch(function () {});
  }
}

function settingsDown(p) {
  if (SET.closeBtn && inRect(p, SET.closeBtn)) { S.popup = null; S.paused = false; SND.buy(); return; }
  if (SET.loginBtn && inRect(p, SET.loginBtn)) {
    // progres demo otomatis diimpor saat kembali setelah login
    location.href = '/auth/login?next=' + encodeURIComponent('/kizdefense');
    return;
  }
  if (SET.toggles) {
    for (var i = 0; i < SET.toggles.length; i++) {
      var t = SET.toggles[i];
      if (inRect(p, t)) {
        S.settings[t.key] = !S.settings[t.key];
        SND.buy();
        try { localStorage.setItem('kizdefense_settings', JSON.stringify(S.settings)); } catch (e) {}
        if (t.key === 'music' && S.settings.music) musicStart();
        return;
      }
    }
  }
  if (SET.volume && p.y > SET.volume.y - 14) {
    var f = clamp((p.x - SET.volume.x) / SET.volume.w, 0, 1);
    S.settings.volume = Math.round(f * 10) / 10;
    if (AU.master) AU.master.gain.value = S.settings.volume;
    SET.volDrag = true;
    return;
  }
  if (SET.claimBtn && inRect(p, SET.claimBtn)) { doClaim(); return; }
}
function settingsMove(p) {
  if (SET.volDrag && SET.volume) {
    var f = clamp((p.x - SET.volume.x) / SET.volume.w, 0, 1);
    S.settings.volume = Math.round(f * 10) / 10;
    if (AU.master) AU.master.gain.value = S.settings.volume;
  }
}
function doClaim() {
  if (!S.user) { toast('Masuk dengan Discord dulu lewat tombol di bawah', 'bad'); return; }
  if (!S.claim.canClaim) { toast('Butuh minimal ' + S.claim.minWaves + ' gelombang sejak klaim terakhir', 'bad'); return; }
  var guildId = S.guildId || (S.guilds[0] && S.guilds[0].id);
  if (!guildId) { toast('Bot belum ada di server Discord-mu', 'bad'); return; }
  api('/api/minigame/claim', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ guildId: guildId }),
  }).then(function (r) {
    if (r.json && r.json.ok) {
      S.claim.eligibleWaves = 0; S.claim.canClaim = false;
      toast('+' + fmt(r.json.amount) + ' KZC masuk saldo bot!', 'gold');
      SND.win();
    } else toast((r.json && r.json.error) || 'Klaim gagal', 'bad');
  }).catch(function () { toast('Koneksi gagal', 'bad'); });
}

function winDown(p) {
  if (!SET.crates) return;
  for (var i = 0; i < SET.crates.length; i++) {
    if (inRect(p, SET.crates[i])) { pickCrate(i); return; }
  }
}
function pickCrate(i) {
  var c = crateOptions()[i];
  var ch = chapterOf(S.wave);
  if (c.id === 'coins') {
    S.coins += REWARD.chapterCoins(ch);
    toast('+' + fmt(REWARD.chapterCoins(ch)) + ' koin!', 'gold');
  } else if (c.id === 'turret') {
    var slot = freeSlot();
    var tier = Math.min(MAX_TIER, buyLevelFor(ch) + 3);
    if (slot) { S.slots[slot] = { tier: tier }; toast('Menara Level ' + tier + ' diperoleh!', 'good'); checkMilestone(tier); }
    else { S.coins += 500 * ch; toast('Papan penuh — diganti ' + fmt(500 * ch) + ' koin', 'gold'); }
  } else {
    S.defHpMax = Math.min(300, S.defHpMax + 25);
    S.defHp = S.defHpMax;
    toast('Pertahanan menguat! HP ' + S.defHpMax, 'good');
  }
  SND.win();
  S.popup = null;
  S.waveState = 'cleared';
  S.waveTimer = 2.0;
  S.wave = chapterOf(S.wave) * 10 + 1; // bab berikutnya
  S.dirty = true;
  if (S.user) serverSave(true); else demoSave();
}

function loseDown(p) {
  if (SET.retryBtn && inRect(p, SET.retryBtn)) {
    // ulang bab ini dari gelombang 1, pertahanan pulih
    S.popup = null;
    S.wave = (chapterOf(S.wave) - 1) * 10 + 1;
    S.defHp = S.defHpMax;
    S.enemies = []; S.projectiles = []; S.spawning = null;
    S.waveState = 'cleared'; S.waveTimer = 1.2;
    SND.buy();
  }
}

cv.addEventListener('pointerdown', onDown, { passive: false });
cv.addEventListener('pointermove', onMove, { passive: false });
cv.addEventListener('pointerup', onUp, { passive: false });
cv.addEventListener('pointercancel', onUp, { passive: false });
document.addEventListener('pointermove', function (ev) { if (S.popup === 'settings') settingsMove(toCanvas(ev)); }, { passive: true });
document.addEventListener('pointerup', function () { if (SET.volDrag) { SET.volDrag = false; try { localStorage.setItem('kizdefense_settings', JSON.stringify(S.settings)); } catch (e) {} } });

// ============================== LOOP UTAMA ==============================
var lastT = 0;
function frame(ts) {
  requestAnimationFrame(frame);
  if (!S.booted) return;
  var real = Math.min(0.05, (ts - lastT) / 1000 || 0.016);
  lastT = ts;
  S.t += real;

  var dt = real * S.speedX;
  if (!S.paused && !S.popup) {
    // mesin gelombang
    if (S.waveState === 'fighting') {
      if (S.spawning && S.spawning.queue.length) {
        S.spawning.t -= dt;
        if (S.spawning.t <= 0) {
          spawnEnemy(S.spawning.queue.shift());
          S.spawning.done++;
          S.spawning.t = S.spawning.interval;
        }
      }
      for (var i = S.enemies.length - 1; i >= 0; i--) {
        if (!enemyFrame(S.enemies[i], dt)) S.enemies.splice(i, 1);
      }
      turretsUpdate(dt);
      projectilesUpdate(dt);
      if (!S.spawning.queue.length && !S.enemies.length && S.waveState === 'fighting') {
        waveCleared();
      }
    } else if (S.waveState === 'cleared') {
      S.waveTimer -= real;
      if (S.waveTimer <= 0) startWave(S.wave);
    }
    // demam
    if (S.fever.active) {
      S.fever.t -= real;
      if (S.fever.t <= 0) { S.fever.active = false; S.fever.meter = 0; }
    } else if (S.fever.meter > 0) {
      S.fever.meter = Math.max(0, S.fever.meter - FEVER.decay * real);
    }
    // rangkaian gabung meluruh
    if (S.streak.t > 0) { S.streak.t -= real; if (S.streak.t <= 0) S.streak.merges = 0; }
    // animasi menara bunker
    Object.keys(fireCooldowns).forEach(function (k) {
      if (fireCooldowns[k] > 0) turretAnim[k] = (turretAnim[k] || 0) + dt;
    });
  }
  fxUpdate(real);

  // autosave berkala
  if (S.dirty && Date.now() - S.lastSaveAt > 15000) {
    if (S.user) serverSave(); else demoSave();
  }
  render();
}

// ============================== BOOT ==============================
function boot() {
  var bar = $('bootBar'), pct = $('bootPct'), err = $('bootErr'), retry = $('bootRetry');
  function fail(msg) {
    err.style.display = 'block';
    err.textContent = 'Gagal memuat: ' + msg;
    retry.style.display = 'inline-block';
  }
  loadJSON('/assets/minigame/manifest.json').then(function (man) {
    MAN = man;
    var list = assetList();
    A.total = list.length;
    var i = 0;
    function step() {
      var batch = list.slice(i, i + 12);
      i += 12;
      return Promise.all(batch.map(loadImg)).then(function () {
        var k = Math.round(A.count / A.total * 100);
        bar.style.width = k + '%';
        pct.textContent = 'MEMUAT ASET... ' + k + '%';
        if (i < list.length) return step();
      });
    }
    return step();
  }).then(function () {
    // font siap?
    if (document.fonts && document.fonts.ready) return document.fonts.ready;
  }).then(function () {
    // pengaturan lokal
    try {
      var st = JSON.parse(localStorage.getItem('kizdefense_settings') || 'null');
      if (st) S.settings = Object.assign(S.settings, st);
    } catch (e) {}
    // sesi login
    return api('/api/me').then(function (r) {
      if (r.json && r.json.userId) {
        S.user = { id: r.json.userId, username: r.json.username };
        if (Array.isArray(r.json.guilds) && r.json.guilds.length) S.guilds = r.json.guilds;
        return api('/api/me/guilds').then(function (g) {
          if (g.json && g.json.ok && Array.isArray(g.json.guilds)) S.guilds = g.json.guilds;
          return serverLoad();
        }).catch(function () { return serverLoad(); });
      }
      demoLoad();
    }).catch(function () { demoLoad(); });
  }).then(function () {
    if (!S.user) {
      try {
        if (!localStorage.getItem(DEMO_KEY)) {
          S.coins = 350;
          S.tutorialStep = 1;
        }
      } catch (e) {}
    }
    if (!Object.keys(S.slots).length && S.tutorialStep === 1 && S.coins < 90) S.coins = 350;
    startWave(S.wave);
    S.booted = true;
    $('boot').classList.add('hide');
    musicStart();
    if (S.tutorialStep) toast('Ikuti panduan singkat untuk mulai bermain!', 'good');
  }).catch(function (e) {
    fail((e && e.message) || 'kesalahan tidak diketahui');
  });
  requestAnimationFrame(frame);
}

// simpan saat tab ditutup / disembunyikan
document.addEventListener('visibilitychange', function () {
  if (document.hidden && S.booted) {
    if (S.user) serverSave(true); else demoSave();
  }
});
window.addEventListener('beforeunload', function () {
  if (S.booted) { if (S.user) serverSave(true); else demoSave(); }
});

boot();
