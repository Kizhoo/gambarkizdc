// Util logging server terstandar. Semua event log memakai ini agar konsisten.
// Aktif hanya bila modLogEnabled ON dan logChannel diatur.
const { EmbedBuilder } = require('discord.js');
const { getGuildConfig } = require('../database/db');
const settings = require('./settings');

async function sendLog(guild, { title, description, color, fields, author, footer }) {
  if (!guild) return;
  const cfg = getGuildConfig(guild.id);
  if (!cfg.modLogEnabled || !cfg.logChannel) return;
  const channel = guild.channels.cache.get(cfg.logChannel);
  if (!channel) return;

  const embed = new EmbedBuilder()
    .setColor(color || settings.get('embedColor', '#2b2d31'))
    .setTitle(title)
    .setTimestamp();
  if (description) embed.setDescription(description.slice(0, 4000));
  if (fields?.length) embed.addFields(fields);
  if (author) embed.setAuthor(author);
  if (footer) embed.setFooter({ text: footer });

  channel.send({ embeds: [embed] }).catch(() => {});
}

module.exports = { sendLog };
