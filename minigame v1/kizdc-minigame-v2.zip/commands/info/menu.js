const {
  SlashCommandBuilder, EmbedBuilder, ActionRowBuilder,
  StringSelectMenuBuilder, ComponentType,
} = require('discord.js');
const CATEGORY_INFO = require('../../utils/categoryInfo');
const config = require('../../config.json');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('menu')
    .setDescription('Tampilkan menu interaktif semua command dan fitur bot'),
  async execute(interaction, client) {
    const lang = guildLang(interaction);
    const activeCategories = client.categories.filter(cat =>
      [...client.commands.values()].some(c => c.category === cat)
    );

    const buildHomeEmbed = () => {
      const embed = new EmbedBuilder()
        .setColor(config.embedColor)
        .setTitle(t(lang, 'menu.title', { bot: client.user.username }))
        .setThumbnail(client.user.displayAvatarURL({ size: 256 }))
        .setDescription(t(lang, 'menu.desc', { n: client.commands.size, c: activeCategories.length }))
        .setFooter({ text: config.footer });

      for (const category of activeCategories) {
        const count = [...client.commands.values()].filter(c => c.category === category).length;
        const info = CATEGORY_INFO[category] || { label: category };
        embed.addFields({ name: info.label, value: t(lang, 'menu.commands_count', { n: count }), inline: true });
      }
      return embed;
    };

    const buildCategoryEmbed = (category) => {
      const cmds = [...client.commands.values()]
        .filter(c => c.category === category)
        .sort((a, b) => a.data.name.localeCompare(b.data.name));
      const info = CATEGORY_INFO[category] || { label: category, desc: '' };

      return new EmbedBuilder()
        .setColor(config.embedColor)
        .setTitle(info.label)
        .setDescription(
          (info.desc ? `*${info.desc}*\n\n` : '') +
          cmds.map(c => `**/${c.data.name}** — ${c.data.description}`).join('\n')
        )
        .setFooter({ text: t(lang, 'menu.footer', { n: cmds.length, footer: config.footer }) });
    };

    const buildSelectMenu = (disabled = false) => {
      const menu = new StringSelectMenuBuilder()
        .setCustomId('menu_select')
        .setPlaceholder(disabled ? t(lang, 'menu.expired') : t(lang, 'menu.placeholder'))
        .setDisabled(disabled)
        .addOptions([
          { label: t(lang, 'menu.home'), value: 'home', description: t(lang, 'menu.home_desc') },
          ...activeCategories.map(cat => {
            const info = CATEGORY_INFO[cat] || { label: cat };
            const count = [...client.commands.values()].filter(c => c.category === cat).length;
            return {
              label: info.label,
              value: cat,
              description: t(lang, 'menu.commands_count', { n: count }),
            };
          }),
        ]);
      return new ActionRowBuilder().addComponents(menu);
    };

    await interaction.reply({ embeds: [buildHomeEmbed()], components: [buildSelectMenu()] });
    const sent = await interaction.fetchReply();

    const collector = sent.createMessageComponentCollector({
      componentType: ComponentType.StringSelect,
      time: 180000,
    });

    collector.on('collect', async i => {
      if (i.user.id !== interaction.user.id) {
        return i.reply({ content: t(lang, 'menu.not_yours'), ephemeral: true });
      }

      const value = i.values[0];
      const embed = value === 'home' ? buildHomeEmbed() : buildCategoryEmbed(value);
      await i.update({ embeds: [embed], components: [buildSelectMenu()] });
    });

    collector.on('end', () => {
      sent.edit({ components: [buildSelectMenu(true)] }).catch(() => {});
    });
  },
};
