const { EmbedBuilder } = require('discord.js');
const { getGuildConfig } = require('../database/db');
const settings = require('../utils/settings');

module.exports = {
  name: 'voiceStateUpdate',
  async execute(oldState, newState, client) {
    const guild = newState.guild || oldState.guild;
    if (!guild) return;
    const member = newState.member || oldState.member;
    if (!member || member.user.bot) return;

    const cfg = getGuildConfig(guild.id);
    if (!cfg.voiceLogChannel) return;
    const logCh = guild.channels.cache.get(cfg.voiceLogChannel);
    if (!logCh) return;

    const embed = new EmbedBuilder().setTimestamp()
      .setAuthor({ name: member.user.tag, iconURL: member.user.displayAvatarURL() });

    let desc = null;
    if (!oldState.channelId && newState.channelId) {
      desc = `Masuk voice ${newState.channel}`;
      embed.setColor(settings.get('successColor', '#57F287'));
    } else if (oldState.channelId && !newState.channelId) {
      desc = `Keluar dari voice ${oldState.channel}`;
      embed.setColor(settings.get('errorColor', '#ED4245'));
    } else if (oldState.channelId !== newState.channelId) {
      desc = `Pindah dari ${oldState.channel} ke ${newState.channel}`;
      embed.setColor(settings.get('warnColor', '#FEE75C'));
    } else if (!oldState.selfStream && newState.selfStream) {
      desc = `Mulai streaming / share layar di ${newState.channel}`;
      embed.setColor('#9146FF');
    } else if (oldState.selfStream && !newState.selfStream) {
      desc = `Berhenti streaming di ${newState.channel}`;
      embed.setColor(settings.get('embedColor', '#2b2d31'));
    } else if (!oldState.selfVideo && newState.selfVideo) {
      desc = `Menyalakan kamera di ${newState.channel}`;
      embed.setColor('#9146FF');
    } else {
      return; // perubahan mute/deafen tidak dilog agar tidak spam
    }

    embed.setDescription(desc);
    logCh.send({ embeds: [embed] }).catch(() => {});
  },
};
