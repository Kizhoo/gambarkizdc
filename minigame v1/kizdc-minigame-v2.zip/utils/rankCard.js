// ============================================================================
// KARTU RANK — kartu canvas untuk /rank (era pasca-RPG)
// ----------------------------------------------------------------------------
// Dibuat 100% dengan @napi-rs/canvas: avatar, nama, level + bar XP, saldo KZC,
// dan latar kustom per-user (cardBg key / cardBgUrl dari webDb). Tidak
// bergantung pada aset RPG — hanya avatar Discord (dengan fallback inisial).
// ============================================================================
const { createCanvas, loadImage } = require('@napi-rs/canvas');

const THEMES = {
  senja:    ['#1e1b4b', '#7c2d92', '#f97316'],
  aurora:   ['#0b1120', '#14532d', '#38bdf8'],
  laut:     ['#020617', '#0c4a6e', '#22d3ee'],
  hutan:    ['#052e16', '#166534', '#4ade80'],
  nebula:   ['#1e1b4b', '#7c3aed', '#ec4899'],
  emas:     ['#451a03', '#b45309', '#fbbf24'],
  salju:    ['#1e293b', '#475569', '#e2e8f0'],
  gurun:    ['#431407', '#c2410c', '#fbbf24'],
  obsidian: ['#0a0a0a', '#1f2937', '#4b5563'],
  kristal:  ['#0f172a', '#155e75', '#a5f3fc'],
};

function rr(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

/**
 * renderRankCard({
 *   user: { username, displayName, avatarURL },
 *   level, xp, needed, balance, bank,
 *   accent, cardBg, cardBgUrl
 * }) -> Buffer PNG
 */
async function renderRankCard(data) {
  const W = 900, H = 320;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  const theme = THEMES[data.cardBg] || THEMES.senja;

  // --- latar ---
  if (data.cardBgUrl) {
    try {
      const bg = await loadImage(data.cardBgUrl);
      const s = Math.max(W / bg.width, H / bg.height);
      ctx.drawImage(bg, (W - bg.width * s) / 2, (H - bg.height * s) / 2, bg.width * s, bg.height * s);
      ctx.fillStyle = 'rgba(4,7,15,.45)';
      ctx.fillRect(0, 0, W, H);
    } catch (_) { drawGradient(ctx, theme, W, H); }
  } else {
    drawGradient(ctx, theme, W, H);
  }

  // --- panel kaca ---
  ctx.fillStyle = 'rgba(8,12,24,.72)';
  rr(ctx, 24, 24, W - 48, H - 48, 26); ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,.14)';
  ctx.lineWidth = 2;
  rr(ctx, 24, 24, W - 48, H - 48, 26); ctx.stroke();

  // --- avatar ---
  const ax = 66, ay = 68, as = 176;
  ctx.save();
  rr(ctx, ax, ay, as, as, 28); ctx.clip();
  ctx.fillStyle = '#0b1120';
  ctx.fillRect(ax, ay, as, as);
  let avatarOk = false;
  if (data.user?.avatarURL) {
    try { const av = await loadImage(data.user.avatarURL); ctx.drawImage(av, ax, ay, as, as); avatarOk = true; } catch (_) {}
  }
  if (!avatarOk) {
    ctx.fillStyle = '#f2c230';
    ctx.font = '700 84px sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(String((data.user?.username || 'K').charAt(0)).toUpperCase(), ax + as / 2, ay + as / 2 + 6);
  }
  ctx.restore();
  ctx.strokeStyle = data.accent || '#f2c230';
  ctx.lineWidth = 5;
  rr(ctx, ax, ay, as, as, 28); ctx.stroke();

  // --- nama ---
  const nx = 280;
  ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = '#f8fafc';
  ctx.font = '700 44px sans-serif';
  ctx.fillText(String(data.user?.displayName || data.user?.username || 'Pemain').slice(0, 18), nx, 120);
  ctx.fillStyle = 'rgba(226,232,240,.55)';
  ctx.font = '400 22px sans-serif';
  ctx.fillText('@' + String(data.user?.username || '').slice(0, 22), nx, 152);

  // --- level besar ---
  ctx.fillStyle = data.accent || '#f2c230';
  ctx.font = '800 58px sans-serif';
  ctx.fillText('Lv ' + (data.level ?? 1), nx, 226);

  // --- bar XP ---
  const bx = nx, by = 248, bw = 380, bh = 18;
  const pct = data.needed ? Math.max(0, Math.min(1, (data.xp || 0) / data.needed)) : 1;
  ctx.fillStyle = 'rgba(2,6,16,.85)';
  rr(ctx, bx, by, bw, bh, 9); ctx.fill();
  const grad = ctx.createLinearGradient(bx, 0, bx + bw, 0);
  grad.addColorStop(0, '#fde68a');
  grad.addColorStop(1, data.accent || '#f2c230');
  ctx.fillStyle = grad;
  rr(ctx, bx + 2, by + 2, Math.max(10, (bw - 4) * pct), bh - 4, 7); ctx.fill();
  ctx.fillStyle = 'rgba(248,250,252,.85)';
  ctx.font = '600 16px sans-serif';
  ctx.fillText(`${(data.xp || 0).toLocaleString('id-ID')} / ${data.needed === Infinity ? 'MAX' : data.needed.toLocaleString('id-ID')} XP`, bx, by + 40);

  // --- saldo kanan ---
  const rx = W - 66;
  ctx.textAlign = 'right';
  ctx.fillStyle = 'rgba(226,232,240,.6)';
  ctx.font = '600 18px sans-serif';
  ctx.fillText('SALDO KIZCO', rx, 92);
  ctx.fillStyle = '#f2c230';
  ctx.font = '800 40px sans-serif';
  ctx.fillText((data.balance || 0).toLocaleString('id-ID') + ' KZC', rx, 134);
  ctx.fillStyle = 'rgba(226,232,240,.6)';
  ctx.font = '600 18px sans-serif';
  ctx.fillText('BANK', rx, 176);
  ctx.fillStyle = '#a5b4fc';
  ctx.font = '700 26px sans-serif';
  ctx.fillText((data.bank || 0).toLocaleString('id-ID') + ' KZC', rx, 206);

  // --- footer ---
  ctx.textAlign = 'left';
  ctx.fillStyle = 'rgba(148,163,184,.75)';
  ctx.font = '500 16px sans-serif';
  ctx.fillText('KizhooBot — level & XP terunifikasi (web + Discord)', 66, H - 44);

  return canvas.toBuffer('image/png');
}

function drawGradient(ctx, theme, W, H) {
  const g = ctx.createLinearGradient(0, 0, W, H);
  g.addColorStop(0, theme[0]);
  g.addColorStop(0.55, theme[1]);
  g.addColorStop(1, theme[2]);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
}

module.exports = { renderRankCard };
