// ============================================================================
// TTS — bot join voice channel lalu "bicara" sesuai teks (prank/announcement)
// ----------------------------------------------------------------------------
// Pakai TTS gratis StreamElements (tanpa API key) → hasil MP3 → dimainkan lewat
// @discordjs/voice. Butuh dependency tambahan (lihat README): @discordjs/voice,
// @discordjs/opus (atau opusscript), prism-media, ffmpeg-static.
// ============================================================================

const TTS_VOICES = ['Brian', 'Amy', 'Emma', 'Geraint', 'Russell', 'Nicole', 'Joey', 'Matthew', 'Joanna'];

// --- TTS gratis (tanpa API key), dengan fallback berlapis ---
// Google Translate TTS = sumber utama (stabil, mendukung Bahasa Indonesia).
// StreamElements = cadangan (kadang HTTP 401 kalau layanan publiknya ditutup).
async function fetchTtsBuffer(text, voice = 'Brian', lang = 'id') {
  const errors = [];

  // 1) Google Translate TTS (MP3, tanpa key)
  try {
    const url = `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&q=${encodeURIComponent(text)}&tl=${encodeURIComponent(lang)}`;
    const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' } });
    if (res.ok) {
      const buf = Buffer.from(await res.arrayBuffer());
      if (buf.length > 300) return buf; // >300 byte = ada audio nyata
    }
    errors.push(`Google TTS HTTP ${res.status}`);
  } catch (e) { errors.push(`Google TTS: ${e.message}`); }

  // 2) StreamElements (cadangan)
  try {
    const url = `https://api.streamelements.com/kappa/v2/speech?voice=${encodeURIComponent(voice)}&text=${encodeURIComponent(text)}`;
    const res = await fetch(url);
    if (res.ok) return Buffer.from(await res.arrayBuffer());
    errors.push(`StreamElements HTTP ${res.status}`);
  } catch (e) { errors.push(`StreamElements: ${e.message}`); }

  throw new Error(`TTS gagal (semua provider gagal): ${errors.join(' | ')}`);
}

// Join + mainkan TTS, lalu keluar setelah selesai.
async function playTts(client, guildId, voiceChannelId, text, voice = 'Brian') {
  let voiceMod;
  try {
    voiceMod = require('@discordjs/voice');
  } catch {
    throw new Error('Dependency @discordjs/voice belum diinstall. Jalankan: npm i @discordjs/voice @discordjs/opus prism-media ffmpeg-static');
  }

  const guild = client.guilds.cache.get(guildId);
  if (!guild) throw new Error('Guild tidak ditemukan (bot tidak ada di server itu?)');
  const channel = guild.channels.cache.get(voiceChannelId);
  if (!channel || channel.type !== 2) throw new Error('Voice channel tidak ditemukan');

  const buffer = await fetchTtsBuffer(text, voice);

  const { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus, StreamType } = voiceMod;
  const { Readable } = require('stream');

  const connection = joinVoiceChannel({
    channelId: voiceChannelId,
    guildId,
    adapterCreator: guild.voiceAdapterCreator,
    selfDeaf: true,
  });

  const player = createAudioPlayer();
  const resource = createAudioResource(Readable.from(buffer), { inputType: StreamType.Arbitrary });
  player.play(resource);
  connection.subscribe(player);

  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      try { connection.destroy(); } catch {}
      resolve({ ok: true, truncated: true });
    }, 30000); // jaga-jaga kalau stuck

    player.on(AudioPlayerStatus.Idle, () => {
      clearTimeout(timeout);
      try { connection.destroy(); } catch {}
      resolve({ ok: true });
    });
    player.on('error', (err) => {
      clearTimeout(timeout);
      try { connection.destroy(); } catch {}
      reject(err);
    });
  });
}

module.exports = { playTts, fetchTtsBuffer, TTS_VOICES };
