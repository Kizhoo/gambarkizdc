const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed, errorEmbed, successEmbed } = require('../../utils/embeds');
const settings = require('../../utils/settings');
const { t, guildLang } = require('../../utils/i18n');

const WORDS = [
  { id: { word: 'KUCING', hint: 'Hewan peliharaan yang suka mengeong' }, en: { word: 'CAT', hint: 'A pet that meows' } },
  { id: { word: 'GITAR', hint: 'Alat musik berdawai yang dipetik' }, en: { word: 'GUITAR', hint: 'A stringed instrument you pluck' } },
  { id: { word: 'SEKOLAH', hint: 'Tempat belajar dan mengajar' }, en: { word: 'SCHOOL', hint: 'A place for learning and teaching' } },
  { id: { word: 'KOMPUTER', hint: 'Perangkat elektronik untuk mengetik dan browsing' }, en: { word: 'COMPUTER', hint: 'An electronic device for typing and browsing' } },
  { id: { word: 'MATAHARI', hint: 'Bintang pusat tata surya kita' }, en: { word: 'SUN', hint: 'The star at the center of our solar system' } },
  { id: { word: 'GUNUNG', hint: 'Dataran tinggi yang menjulang' }, en: { word: 'MOUNTAIN', hint: 'A tall landform that towers up' } },
  { id: { word: 'LAUTAN', hint: 'Perairan luas dan asin' }, en: { word: 'OCEAN', hint: 'A vast body of saltwater' } },
  { id: { word: 'PELANGI', hint: 'Muncul setelah hujan, banyak warna' }, en: { word: 'RAINBOW', hint: 'Appears after rain, full of colors' } },
  { id: { word: 'PERPUSTAKAAN', hint: 'Tempat menyimpan dan meminjam buku' }, en: { word: 'LIBRARY', hint: 'A place to store and borrow books' } },
  { id: { word: 'DISCORD', hint: 'Aplikasi chat tempat bot ini berjalan' }, en: { word: 'DISCORD', hint: 'The chat app where this bot runs' } },
  { id: { word: 'INDONESIA', hint: 'Negara kepulauan terbesar di dunia' }, en: { word: 'INDONESIA', hint: 'The largest archipelago country in the world' } },
  { id: { word: 'SEPATU', hint: 'Alas kaki buat jalan-jalan' }, en: { word: 'SHOES', hint: 'Footwear for walking around' } },
  { id: { word: 'JENDELA', hint: 'Bagian rumah tempat cahaya masuk' }, en: { word: 'WINDOW', hint: 'The part of a house where light enters' } },
  { id: { word: 'PAYUNG', hint: 'Pelindung dari hujan' }, en: { word: 'UMBRELLA', hint: 'Protection from rain' } },
  { id: { word: 'KALKULATOR', hint: 'Alat bantu hitung' }, en: { word: 'CALCULATOR', hint: 'A tool for counting' } },
  { id: { word: 'TELEVISI', hint: 'Alat elektronik untuk menonton acara' }, en: { word: 'TELEVISION', hint: 'An electronic device for watching shows' } },
  { id: { word: 'SEPEDA', hint: 'Kendaraan roda dua tanpa mesin' }, en: { word: 'BICYCLE', hint: 'A two-wheeled vehicle without an engine' } },
  { id: { word: 'BINTANG', hint: 'Benda langit yang berkelip di malam hari' }, en: { word: 'STAR', hint: 'A celestial body twinkling at night' } },
  { id: { word: 'KOPI', hint: 'Minuman hitam pahit yang bikin melek' }, en: { word: 'COFFEE', hint: 'A bitter black drink that keeps you awake' } },
  { id: { word: 'PISANG', hint: 'Buah kuning yang disukai monyet' }, en: { word: 'BANANA', hint: 'A yellow fruit monkeys love' } },
];

function scramble(word) {
  const letters = word.split('');
  let scrambled;
  do {
    for (let i = letters.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [letters[i], letters[j]] = [letters[j], letters[i]];
    }
    scrambled = letters.join('');
  } while (scrambled === word && word.length > 1);
  return scrambled;
}

module.exports = {
  subcommandOf: 'games',
  data: new SlashCommandBuilder().setName('wordscramble').setDescription('Tebak kata acak rame-rame, siapa cepat menjawab menang'),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const entry = WORDS[Math.floor(Math.random() * WORDS.length)];
    const item = lang === 'id' ? entry.id : entry.en;
    const scrambled = scramble(item.word);

    const durationSeconds = settings.get('games.wordScrambleSeconds', 30);
    const embed = baseEmbed()
      .setTitle(t(lang, 'ws.title'))
      .setDescription(t(lang, 'ws.desc', { s: scrambled.split('').join(' '), hint: item.hint, d: durationSeconds }));

    await interaction.reply({ embeds: [embed] });
    const channel = interaction.channel;

    const collector = channel.createMessageCollector({
      filter: m => !m.author.bot && m.content.toUpperCase().trim() === item.word,
      time: durationSeconds * 1000,
      max: 1,
    });

    collector.on('collect', async m => {
      await m.reply({ embeds: [successEmbed(t(lang, 'ws.correct', { w: item.word, m: `${m.author}` }))] });
    });

    collector.on('end', collected => {
      if (collected.size === 0) {
        channel.send({ embeds: [errorEmbed(t(lang, 'ws.timeout', { w: item.word }))] }).catch(() => {});
      }
    });
  },
};
