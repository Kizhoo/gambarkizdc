// ============================================================================
// PUSAT EMOJI BRAND — emoji premium + bisa override pakai emoji animasi custom
// ----------------------------------------------------------------------------
// Cara pakai:
//   emojis.get('play')  -> kembalikan emoji custom (kalau di-set di config.json)
//                          ATAU emoji Unicode default yang bagus.
//
// Untuk pakai emoji ANIMASI (custom Discord), upload emoji ke server bot kamu,
// lalu dapatkan format "<a:nama:id>" (kirim \:nama: di Discord), isi di config.json:
//   "emojis": { "play": "<a:play:123456789012345678>" }
// Emoji custom di-render DI SEMUA server (pakai ID), jadi aman lintas guild.
// ============================================================================
const settings = require('./settings');

// === EMOJI DEFAULT (Unicode, dipilih yang "premium"/bagus) ===
const DEFAULTS = {
  // --- Kontrol musik (tombol) ---
  play: '▶️',
  pause: '⏸️',
  resume: '▶️',
  skip: '⏭️',
  previous: '⏮️',
  stop: '⏹️',
  volup: '🔊',
  voldown: '🔉',
  mute: '🔇',
  loop: '🔁',
  loopOne: '🔂',
  shuffle: '🔀',
  queue: '🎧',

  // --- Field info musik ---
  artist: '🎤',
  duration: '⏳',
  source: '🌐',
  requester: '✨',
  volume: '🎚️',
  position: '📌',
  queueCount: '🎶',

  // --- Status musik ---
  playing: '🎵',
  paused: '⏸️',
  live: '🔴',

  // --- Welcome / goodbye ---
  welcome: '👋',
  goodbye: '💔',
  members: '👥',
  accountAge: '🕰️',
  sparkle: '✨',
  crown: '👑',

  // --- Reaksi premium (dipakai emojiImporter) ---
  heart: '❤️',
  fire: '🔥',
  wave: '👋',
  dance: '💃',
  cool: '😎',
  yes: '✅',
  no: '❌',
  party: '🎉',
  join: '🚪',
  warn: '⚠️',
  up: '⬆️',

  // --- Titik warna (dipakai tombol warna border) ---
  dot_green: '🟢',
  dot_red: '🔴',
  dot_blue: '🔵',
  dot_purple: '🟣',
  dot_gold: '🟡',
  dot_pink: '🩷',
  dot_orange: '🟠',
  dot_cyan: '🔷',
  dot_white: '⚪',
};

function get(key, fallback = null) {
  // 1) cek override custom di config.json (emoji animasi/dll)
  const custom = settings.get(`emojis.${key}`, null);
  if (custom) return custom;
  // 2) fallback ke default Unicode
  return DEFAULTS[key] || fallback || '❔';
}

// Ambil emoji field info lengkap: "<emoji> Label" (buat nama field embed)
function field(key, label) {
  return `${get(key)} ${label}`;
}

module.exports = { get, field, DEFAULTS };
