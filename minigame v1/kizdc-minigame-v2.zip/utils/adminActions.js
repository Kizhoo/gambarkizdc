// ============================================================================
// ADMIN ACTIONS — aksi owner bot (pengganti rpgAdminActions pasca-RPG)
// ----------------------------------------------------------------------------
// Hanya aksi yang masih relevan: saldo ekonomi, level/XP terunifikasi,
// inventaris item (pasar), dan ringkasan user. Aksi spesifik-RPG (rank,
// reputasi, skill/stat point, reset karakter) sudah pensiun bersama RPG.
// ============================================================================
const { getEconomy, updateBalance, updateBank } = require('../database/db');
const webDb = require('../database/webDb');
const levelEngine = require('./levelEngine');
const shopManager = require('./shopManager');

// ---- Saldo ----
function adminAddGold(userId, guildId, amount) {
  amount = Math.floor(Number(amount) || 0);
  if (!amount) return { ok: false, error: 'Jumlah tidak boleh nol.' };
  const eco = updateBalance(guildId, userId, amount);
  return { ok: true, newBalance: eco.balance };
}
// Tambah gold ke SEMUA user yang punya baris ekonomi di server ini (aksi massal —
// pemanggil wajib sudah minta konfirmasi eksplisit, lihat requireConfirm di lunaAgent).
async function adminAddGoldAllInGuild(guild, amount) {
  if (!guild || typeof guild.members?.fetch !== 'function') return { ok: false, error: 'Konteks guild tidak valid buat aksi massal ini.' };
  const safeAmount = Math.floor(Number(amount) || 0);
  if (!safeAmount) return { ok: false, error: 'Jumlah tidak boleh nol.' };
  const dbCore = require('../database/db');
  const rows = dbCore.db.prepare('SELECT DISTINCT userId FROM economy WHERE guildId = ?').all(guild.id);
  if (!rows.length) return { ok: true, affected: 0, amount: safeAmount, note: 'Belum ada user terdaftar di ekonomi server ini.' };
  let affected = 0;
  for (const r of rows) {
    updateBalance(guild.id, r.userId, safeAmount);
    affected++;
  }
  return { ok: true, affected, amount: safeAmount };
}
function adminSetGold(userId, guildId, amount) {
  amount = Math.floor(Number(amount));
  if (!Number.isFinite(amount) || amount < 0) return { ok: false, error: 'Jumlah tidak valid (minimal 0).' };
  const cur = getEconomy(guildId, userId);
  updateBalance(guildId, userId, amount - cur.balance);
  return { ok: true, newBalance: amount };
}

// ---- Level & XP (terunifikasi, web_users) ----
function adminSetLevel(userId, level, guildId) {
  const lv = Math.floor(Number(level));
  if (!Number.isFinite(lv) || lv < 0 || lv > levelEngine.LEVEL_CAP) {
    return { ok: false, error: `Level harus 0-${levelEngine.LEVEL_CAP}.` };
  }
  const res = levelEngine.setLevel(userId, lv, guildId);
  return { ok: true, level: res.level };
}
function adminAddXp(userId, amount, guildId) {
  amount = Math.floor(Number(amount) || 0);
  if (!amount) return { ok: false, error: 'Jumlah XP tidak boleh nol.' };
  const res = levelEngine.addExp(userId, amount, guildId);
  const lv = levelEngine.getLevel(userId);
  return { ok: true, level: lv.level, xpIntoLevel: res.xpIntoLevel, xpForNext: res.xpForNext, leveledUp: res.leveledUp, toLevel: res.toLevel };
}

// ---- Inventaris item (pasar web + bot) ----
function adminGiveItem(userId, itemId, qty = 1) {
  qty = Math.max(1, Math.floor(Number(qty) || 1));
  const item = shopManager.getItem(itemId);
  if (!item) return { ok: false, error: `Item \`${itemId}\` tidak dikenal.` };
  webDb.addItem(userId, itemId, qty);
  return { ok: true, item: item.name, qty };
}
function adminRemoveItem(userId, itemId, qty = 1) {
  qty = Math.max(1, Math.floor(Number(qty) || 1));
  const item = shopManager.getItem(itemId);
  if (!item) return { ok: false, error: `Item \`${itemId}\` tidak dikenal.` };
  const ok = webDb.removeItem(userId, itemId, qty);
  if (!ok) return { ok: false, error: `Tas user cuma punya ${webDb.getItemQty(userId, itemId)}x item itu.` };
  return { ok: true, item: item.name, qty };
}

// ---- Ringkasan user ----
function adminViewUser(userId, guildId) {
  const lv = levelEngine.getLevel(userId);
  const eco = getEconomy(guildId, userId);
  const inv = webDb.getInventory(userId);
  const mg = webDb.getProgress(userId);
  return {
    ok: true,
    level: lv.level, xp: lv.xp,
    balance: eco.balance, bank: eco.bank,
    inventoryCount: inv.length,
    minigame: mg ? { wave: mg.wave, bestWave: mg.bestWave, totalKills: mg.totalKills } : null,
  };
}

module.exports = { adminAddGold, adminAddGoldAllInGuild, adminSetGold, adminSetLevel, adminAddXp, adminGiveItem, adminRemoveItem, adminViewUser };
