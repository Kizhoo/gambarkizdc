const { EmbedBuilder } = require('discord.js');
const settings = require('./settings');

// Kandidat cadangan statis (dicoba SETELAH discovery internet gagal). Node publik komunitas
// SIFATNYA VOLATILE - bisa mati/ganti alamat kapan aja (kebukti berkali-kali di sesi debugging
// kita sendiri), makanya daftar ini SENGAJA dibikin panjang (20+) biar peluang dapet yang masih
// hidup makin besar, dan yang mati otomatis di-skip aja sama probeNode()/tryConnect() yang sudah
// ada - tidak bikin error, cuma dilewati. Update manual kalau perlu dari:
// https://lavalink.darrennathanael.com/SSL/Lavalink-SSL/ atau https://lavalink-list.ajieblogs.eu.org/
const CANDIDATE_NODES = [
  { name: 'candidate-jirayu', url: 'lavalink.jirayu.net:443', auth: 'youshallnotpass', secure: true },
  { name: 'candidate-serenetia', url: 'lavalinkv4.serenetia.com:443', auth: 'https://dsc.gg/ajidevserver', secure: true },
  { name: 'candidate-ajie-all', url: 'lava-all.ajieblogs.eu.org:80', auth: 'https://dsc.gg/ajidevserver', secure: false },
  { name: 'candidate-ajie-v4', url: 'lava-v4.ajieblogs.eu.org:443', auth: 'https://dsc.gg/ajidevserver', secure: true },
  { name: 'candidate-devxcode', url: 'lavalink.devxcode.in:443', auth: 'DevXcode', secure: true },
  { name: 'candidate-micium', url: 'lavalink.micium.host:2333', auth: 'micium', secure: false },
  { name: 'candidate-clxud', url: 'lavalink.clxud.dev:2333', auth: 'youshallnotpass', secure: false },
  { name: 'candidate-alfari', url: 'lava.alfari.id:443', auth: 'catfein', secure: true },
  { name: 'candidate-inzeworld', url: 'lava.inzeworld.com:3128', auth: 'saher.dev', secure: false },
  { name: 'candidate-fastpanel', url: 'lavalink.fastpanel.top:2000', auth: 'lavalink', secure: false },
  { name: 'candidate-noahmg', url: 'lavalink.noahmg.eu.org:443', auth: 'youshallnotpass', secure: true },
  { name: 'candidate-imnyx', url: 'imnyx.us.to:6900', auth: 'https://dsc.gg/ajidevserver', secure: false },
  { name: 'candidate-plusa', url: 'lava.plusa.dev:443', auth: 'plusa', secure: true },
  { name: 'candidate-rwn', url: 'lavalink.rwn.moe:2333', auth: 'youshallnotpass', secure: false },
  { name: 'candidate-nezumi', url: 'nezumi.hs.vc:443', auth: 'https://dsc.gg/ajidevserver', secure: true },
  { name: 'candidate-lexo', url: 'lava.lexnet.cc:443', auth: 'lexnet', secure: true },
  { name: 'candidate-kylenw', url: 'lavalink.kylenw.dev:2333', auth: 'youshallnotpass', secure: false },
  { name: 'candidate-oceanity', url: 'node.oceanity.dev:443', auth: 'oceanity', secure: true },
  { name: 'candidate-appujet', url: 'lava.appujet.site:433', auth: 'https://appujet.site/jerry', secure: true },
  { name: 'candidate-blackfyre', url: 'lavalink.blackfyre.moe:443', auth: 'blackfyre', secure: true },
  { name: 'candidate-projectlounge', url: 'lava.projectlounge.pw:443', auth: 'lavalink', secure: true },
  { name: 'candidate-poopranger', url: 'lavalink.poopranger.com:80', auth: 'youshallnotpass', secure: false },
];

const connectedNodes = new Set();

function markConnected(name) { connectedNodes.add(name); }
function markDisconnected(name) { connectedNodes.delete(name); }
function healthyNodeCount() { return connectedNodes.size; }

async function notifyOwner(client, description, color) {
  const ownerId = process.env.OWNER_ID;
  if (!ownerId) return;
  try {
    const owner = await client.users.fetch(ownerId);
    const embed = new EmbedBuilder()
      .setColor(color || settings.get('warnColor', '#FEE75C'))
      .setTitle('Monitoring Musik')
      .setDescription(description)
      .setTimestamp();
    await owner.send({ embeds: [embed] }).catch(() => {});
  } catch (err) {
    console.error('[NodeHealth] Gagal DM owner:', err.message);
  }
}

function tryAddCandidate(kazagumo, candidate) {
  return new Promise((resolve) => {
    const timeout = setTimeout(() => { cleanup(); resolve(false); }, 12000);
    function cleanup() {
      clearTimeout(timeout);
      kazagumo.shoukaku.off('ready', onReady);
      kazagumo.shoukaku.off('error', onNodeError);
    }
    function onReady(name) { if (name === candidate.name) { cleanup(); resolve(true); } }
    function onNodeError(name) { if (name === candidate.name) { cleanup(); resolve(false); } }
    kazagumo.shoukaku.on('ready', onReady);
    kazagumo.shoukaku.on('error', onNodeError);
    try { kazagumo.shoukaku.addNode(candidate); } catch { cleanup(); resolve(false); }
  });
}

async function checkAndHeal(client) {
  const kazagumo = client.kazagumo;
  if (!kazagumo) return;
  if (healthyNodeCount() > 0) return; // masih ada node sehat

  console.warn('[NodeHealth] Tidak ada node Lavalink sehat. Memulai penyembuhan otomatis...');
  await notifyOwner(client, 'Semua node Lavalink musik down. Mencoba cari node online baru dari internet + kandidat cadangan...');

  // 1) DISCOVERY INTERNET (kalau diaktifkan di config)
  if (settings.get('music.autoDiscoverNodes', true)) {
    try {
      const { autoDiscoverAndConnect } = require('./nodeManager');
      const result = await autoDiscoverAndConnect(client, 6);
      if (result.connected) {
        console.log(`[NodeHealth] Node online ditemukan & tersambung: ${result.connected.name}`);
        await notifyOwner(
          client,
          `Berhasil menemukan node ONLINE dari internet dan tersambung: **${result.connected.name}** (\`${result.connected.url}\`).\nNode ini otomatis tersimpan ke config.json.`,
          settings.get('successColor', '#57F287'),
        );
        return;
      }
      console.warn(`[NodeHealth] Discovery internet gagal (mencoba ${result.tried} node). Lanjut ke kandidat statis...`);
    } catch (e) {
      console.error('[NodeHealth] Error discovery internet:', e.message);
    }
  }

  // 2) KANDIDAT STATIS
  const existingNames = new Set([...kazagumo.shoukaku.nodes.keys()]);
  for (const candidate of CANDIDATE_NODES) {
    if (existingNames.has(candidate.name)) continue;
    console.log(`[NodeHealth] Mencoba kandidat statis: ${candidate.name}`);
    const success = await tryAddCandidate(kazagumo, candidate);
    if (success) {
      await notifyOwner(client, `Berhasil pindah ke node cadangan statis: **${candidate.name}**.`, settings.get('successColor', '#57F287'));
      return;
    }
    try { kazagumo.shoukaku.removeNode(candidate.name); } catch {}
  }

  console.error('[NodeHealth] Semua opsi node gagal.');
  await notifyOwner(
    client,
    'Semua node Lavalink (discovery internet + kandidat cadangan) tidak bisa diakses saat ini. Musik kemungkinan mati sampai ada node yang online.\n\nCek manual: https://lavalink.darrennathanael.com/ atau tambahkan node sendiri dengan `/node add`.',
    settings.get('errorColor', '#ED4245'),
  );
}

module.exports = { checkAndHeal, markConnected, markDisconnected, healthyNodeCount, CANDIDATE_NODES };
