const { EmbedBuilder } = require('discord.js');
const { generateText } = require('./aiProvider');
const config = require('../config.json');

// Dedup sederhana supaya error yang sama berulang-ulang dalam waktu singkat tidak
// membanjiri DM owner - cuma dilaporkan sekali per 5 menit untuk error yang identik.
const alertedRecently = new Set();
const DEDUP_WINDOW_MS = 5 * 60 * 1000;

async function alertOwner(client, error, context = 'Tidak diketahui') {
  const ownerId = process.env.OWNER_ID;
  if (!ownerId) {
    console.warn('[ErrorAlert] OWNER_ID belum diisi di .env — auto error report ke owner dinonaktifkan. Isi OWNER_ID agar fitur ini aktif.');
    return;
  }

  const rawMessage = error?.message || String(error);
  const errorKey = `${context}:${rawMessage.slice(0, 100)}`;
  if (alertedRecently.has(errorKey)) return;
  alertedRecently.add(errorKey);
  setTimeout(() => alertedRecently.delete(errorKey), DEDUP_WINDOW_MS);

  try {
    const owner = await client.users.fetch(ownerId);
    const stack = (error?.stack || rawMessage || 'Tidak ada detail').slice(0, 1500);

    let explanation = 'AI tidak tersedia untuk menjelaskan error ini (cek CLOUDFLARE_ACCOUNT_ID/CLOUDFLARE_API_TOKEN di .env kalau ingin fitur ini aktif).';
    try {
      explanation = await generateText([
        {
          role: 'system',
          content: 'Jelaskan error Node.js berikut dalam Bahasa Indonesia yang singkat dan mudah dipahami, maksimal 4 kalimat: apa kemungkinan penyebabnya dan saran perbaikan singkat.',
        },
        { role: 'user', content: stack },
      ]);
    } catch (aiErr) {
      console.error('[ErrorAlert] Gagal minta penjelasan AI:', aiErr.message);
    }

    const embed = new EmbedBuilder()
      .setColor(config.errorColor)
      .setTitle('Bot Mengalami Error')
      .addFields(
        { name: 'Konteks', value: context.slice(0, 200) },
        { name: 'Pesan Error', value: `\`\`\`${stack.slice(0, 1000)}\`\`\`` },
        { name: 'Penjelasan AI', value: explanation.slice(0, 1000) },
      )
      .setFooter({ text: 'Pakai /botadmin explain untuk analisis manual lebih lanjut' })
      .setTimestamp();

    await owner.send({ embeds: [embed] }).catch(() => {});
  } catch (err) {
    console.error('[ErrorAlert] Gagal kirim DM ke owner:', err.message);
  }
}

module.exports = { alertOwner };
