# ASET WEB KIZHOOBOT

Struktur folder aset publik (`dashboard/public/assets/`):

```
assets/
  minigame/   — aset Minigame KizDefense (idle turret defense)
      bg/       bg1.jpg, bg2.jpg (latar bab), base.png (overlay benteng 15 slot)
      turrets/  8 tier (T1,T3,T5,T7,T10,T13,T16,T20) x 15 frame animasi tembak
      enemies/  ground/ (8 x 10 frame), fly/ (3 x 10), hybrid/ (4 x 12, bos)
      fx/       exp1/ exp2/ (ledakan 20 frame), shoot/ (muzzle flash 15 frame)
      proj/     p1.png p2.png p3.png (proyektil menara)
      ui/       tombol, bar, popup, ikon koin (subset CraftPix)
      manifest.json — inventaris aset hasil build
  icons/      — ikon item untuk halaman market (PNG per item)
  fonts/      — Silkscreen (OFL), Press Start 2P (OFL)
```

## Minigame — cara rebuild aset
Aset minigame adalah HASIL OLAH dari CraftPix Free Idle Turret Defense Kit.
Pipeline: `python3 scripts/build_minigame_assets.py` (repo root; sumber kit
disimpan lokal, tidak ikut di-repo). Jangan mengedit PNG di `minigame/`
secara manual — ubah konfigurasi di skrip build lalu jalankan ulang.

## Ikon market
`item-icons.js` menggambar ikon prosedural (canvas) sebagai fallback;
PNG di `icons/` dipakai kalau ada (dipilih via `itemIconKey` di market.js).
