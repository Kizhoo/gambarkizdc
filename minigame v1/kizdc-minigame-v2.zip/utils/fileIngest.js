// ============================================================================
// FILE INGEST - baca lampiran user (termasuk .zip) untuk dijadikan konteks AI
// ----------------------------------------------------------------------------
// Dipakai oleh /ai chat saat user menempelkan file. Menghasilkan teks ringkas
// yang aman dikirim ke model (dibatasi ukuran) plus ringkasan buat ditampilkan
// di embed balasan. Semua batas diatur lewat config.json -> ai.attachments,
// jadi bisa diubah tanpa ubah kode kalau kuota/model berubah.
// ============================================================================
const AdmZip = require('adm-zip');
const path = require('path');
const settings = require('./settings');

function cfg() {
  return settings.get('ai.attachments', {
    enabled: true,
    maxFileSizeMB: 8,
    maxCharsPerFile: 12000,
    maxTotalChars: 20000,
    maxZipEntries: 40,
    allowedTextExtensions: ['txt', 'md', 'json', 'js', 'ts', 'py', 'log', 'csv'],
  });
}

function extOf(filename) {
  const ext = path.extname(filename || '').replace('.', '').toLowerCase();
  return ext || path.basename(filename || '').toLowerCase(); // tangani "Dockerfile" tanpa ekstensi
}

function isTextExtension(filename, allowedList) {
  const ext = extOf(filename);
  return allowedList.includes(ext);
}

// Deteksi sederhana biner vs teks: kalau ada byte NUL di awal buffer, hampir pasti bukan teks.
function looksBinary(buffer) {
  const sample = buffer.subarray(0, Math.min(buffer.length, 4096));
  return sample.includes(0);
}

function decodeText(buffer) {
  return buffer.toString('utf8').replace(/\r\n/g, '\n');
}

function truncate(text, max) {
  if (text.length <= max) return { text, truncated: false };
  return { text: text.slice(0, max), truncated: true };
}

async function downloadAttachment(attachment) {
  const res = await fetch(attachment.url);
  if (!res.ok) throw new Error(`Gagal mengunduh lampiran (HTTP ${res.status}).`);
  const arrayBuffer = await res.arrayBuffer();
  return Buffer.from(arrayBuffer);
}

function ingestZip(buffer, options) {
  let zip;
  try {
    zip = new AdmZip(buffer);
  } catch (e) {
    throw new Error('File zip tidak valid atau rusak.');
  }
  const entries = zip.getEntries().filter(e => !e.isDirectory);

  // Proteksi zip-bomb: tolak arsip yang KLAIM hasil ekstraknya jauh lebih besar dari wajar
  // sebelum kita panggil getData() (yang men-decompress ke memori). Header size bisa saja
  // "bohong", tapi ini cukup untuk menyaring kasus umum tanpa perlu decompress dulu.
  const maxSingleBytes = (options.maxSingleEntryUncompressedMB || 25) * 1024 * 1024;
  const maxTotalBytes = (options.maxTotalUncompressedMB || 150) * 1024 * 1024;
  const declaredTotal = entries.reduce((sum, e) => sum + (e.header?.size || 0), 0);
  if (declaredTotal > maxTotalBytes) {
    throw new Error(`Arsip zip ini mencurigakan: total ukuran hasil ekstrak (${(declaredTotal / 1024 / 1024).toFixed(0)} MB) jauh melebihi batas aman (${options.maxTotalUncompressedMB} MB). Ditolak demi keamanan.`);
  }

  const tree = entries.slice(0, options.maxZipEntries).map(e => `${e.entryName} (${(e.header.size / 1024).toFixed(1)} KB)`);
  const overflowCount = Math.max(0, entries.length - options.maxZipEntries);

  let combined = '';
  const readFiles = [];
  const skipped = [];
  let budget = options.maxTotalChars;

  for (const entry of entries.slice(0, options.maxZipEntries)) {
    if (budget <= 0) { skipped.push(entry.entryName); continue; }
    if (!isTextExtension(entry.entryName, options.allowedTextExtensions)) { skipped.push(entry.entryName); continue; }
    if ((entry.header?.size || 0) > maxSingleBytes) { skipped.push(`${entry.entryName} (terlalu besar setelah diekstrak)`); continue; }

    let data;
    try { data = entry.getData(); } catch (e) { skipped.push(entry.entryName); continue; }
    if (looksBinary(data)) { skipped.push(entry.entryName); continue; }

    const text = decodeText(data);
    const perFileLimit = Math.min(options.maxCharsPerFile, budget);
    const { text: cut, truncated } = truncate(text, perFileLimit);
    combined += `\n--- ${entry.entryName}${truncated ? ' (dipotong)' : ''} ---\n${cut}\n`;
    budget -= cut.length;
    readFiles.push(entry.entryName);
  }

  return {
    kind: 'zip',
    entryCount: entries.length,
    treePreview: tree,
    treeOverflow: overflowCount,
    readFiles,
    skipped,
    contextText: combined.trim() || '(tidak ada file teks yang bisa dibaca di dalam arsip ini)',
  };
}

function ingestPlainText(buffer, filename, options) {
  if (looksBinary(buffer)) {
    return { kind: 'unsupported', reason: 'File terdeteksi biner, bukan teks yang bisa dibaca langsung.' };
  }
  const text = decodeText(buffer);
  const { text: cut, truncated } = truncate(text, Math.min(options.maxCharsPerFile, options.maxTotalChars));
  return {
    kind: 'text',
    contextText: `--- ${filename}${truncated ? ' (dipotong)' : ''} ---\n${cut}`,
    truncated,
  };
}

/**
 * Proses satu Discord Attachment. Melempar Error dengan pesan ramah user kalau gagal/ditolak.
 */
async function ingestAttachment(attachment) {
  const options = cfg();
  if (!options.enabled) throw new Error('Fitur baca lampiran sedang dimatikan lewat pengaturan bot.');

  const maxBytes = options.maxFileSizeMB * 1024 * 1024;
  if (attachment.size > maxBytes) {
    throw new Error(`File terlalu besar (${(attachment.size / 1024 / 1024).toFixed(2)} MB). Batas saat ini ${options.maxFileSizeMB} MB.`);
  }

  const buffer = await downloadAttachment(attachment);
  const ext = extOf(attachment.name);

  let result;
  if (ext === 'zip') {
    result = ingestZip(buffer, options);
  } else if (isTextExtension(attachment.name, options.allowedTextExtensions)) {
    result = ingestPlainText(buffer, attachment.name, options);
  } else {
    result = {
      kind: 'unsupported',
      reason: `Tipe file \`.${ext || '?'}\` belum didukung untuk dibaca sebagai teks. Yang didukung: dokumen teks/kode umum dan \`.zip\`.`,
    };
  }

  return { name: attachment.name, sizeBytes: attachment.size, ...result };
}

module.exports = { ingestAttachment, extOf };
