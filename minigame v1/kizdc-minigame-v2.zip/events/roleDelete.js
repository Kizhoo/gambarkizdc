const { sendLog } = require('../utils/serverLog');
const config = require('../config.json');

module.exports = {
  name: 'roleDelete',
  async execute(role) {
    sendLog(role.guild, {
      title: 'Role Dihapus',
      color: config.errorColor,
      fields: [{ name: 'Role', value: `${role.name}` }],
      footer: `Role ID: ${role.id}`,
    });
  },
};
