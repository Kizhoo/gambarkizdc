// ============================================================================
// EVENT: guildCreate — bot ditambahkan ke server baru
// ----------------------------------------------------------------------------
// Kirim notifikasi ke server OWNER (lihat utils/ownerNotifications.js) DAN
// kartu perkenalan bot ke channel sistem server tersebut (lihat utils/botIntro.js).
// Pakai joinedTimestamp buat bedain "join baru" vs "reconnect saat restart" —
// supaya tidak spam notifikasi ke semua guild setiap kali bot restart.
// ============================================================================
const { sendGuildJoinNotification } = require('../utils/ownerNotifications');
const { buildBotIntro } = require('../utils/botIntro');

const notified = new Set(); // dedup dalam 1 sesi proses

// Cari channel yang cocok buat kirim kartu perkenalan: channel sistem, lalu
// channel teks pertama yang bot punya izin kirim pesan + embed.
async function findIntroChannel(guild) {
  const me = guild.members.me || (await guild.members.fetchMe().catch(() => null));
  if (!me) return null;

  const candidates = [
    guild.systemChannel,
    guild.rulesChannel,
    ...guild.channels.cache.filter((c) => c.type === 0).sort((a, b) => a.position - b.position).values(),
  ].filter(Boolean);

  for (const ch of candidates) {
    if (ch.type === 0 && ch.permissionsFor(me)?.has(['ViewChannel', 'SendMessages', 'EmbedLinks'])) {
      return ch;
    }
  }
  return null;
}

module.exports = {
  name: 'guildCreate',
  async execute(guild, client) {
    if (notified.has(guild.id)) return;
    // Fresh join = joinedTimestamp mendekati sekarang. Reconnect (restart) = timestamp lama.
    const freshJoin = (Date.now() - (guild.joinedTimestamp || 0)) < 5 * 60 * 1000;
    if (!freshJoin) return;

    notified.add(guild.id);
    await sendGuildJoinNotification(client, guild).catch((err) => {
      console.error('[ownerNotifications] Gagal kirim notif guild baru:', err.message);
    });

    // Kartu perkenalan bot (fitur + tombol CTA) ke channel sistem server baru.
    try {
      const channel = await findIntroChannel(guild);
      if (channel) await channel.send(buildBotIntro(client, guild));
    } catch (err) {
      console.error('[botIntro] Gagal kirim kartu perkenalan:', err.message);
    }
  },
};
