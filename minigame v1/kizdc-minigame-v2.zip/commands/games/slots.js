const { SlashCommandBuilder } = require('discord.js');
const { getEconomy, updateBalance } = require('../../database/db');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

const SYMBOLS = [
  { emoji: '🍒', weight: 30, multiplier: 2 },
  { emoji: '🍋', weight: 25, multiplier: 3 },
  { emoji: '🍇', weight: 20, multiplier: 4 },
  { emoji: '🔔', weight: 15, multiplier: 6 },
  { emoji: '💎', weight: 7, multiplier: 10 },
  { emoji: '7️⃣', weight: 3, multiplier: 25 },
];

function spinReel() {
  const totalWeight = SYMBOLS.reduce((sum, s) => sum + s.weight, 0);
  let rand = Math.random() * totalWeight;
  for (const symbol of SYMBOLS) {
    if (rand < symbol.weight) return symbol;
    rand -= symbol.weight;
  }
  return SYMBOLS[0];
}

module.exports = {
  subcommandOf: 'games',
  data: new SlashCommandBuilder()
    .setName('slots')
    .setDescription('Main slot machine, pakai cash kamu')
    .addIntegerOption(o => o.setName('taruhan').setDescription('Jumlah cash yang dipertaruhkan').setRequired(true).setMinValue(10)),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const bet = interaction.options.getInteger('taruhan');
    const eco = getEconomy(interaction.guild.id, interaction.user.id);

    if (eco.balance < bet) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'bj.no_cash', { bal: eco.balance }))], ephemeral: true });
    }

    const reels = [spinReel(), spinReel(), spinReel()];
    const display = reels.map(r => r.emoji).join(' | ');

    let resultText;
    let payout = -bet;

    if (reels[0].emoji === reels[1].emoji && reels[1].emoji === reels[2].emoji) {
      const winnings = bet * reels[0].multiplier;
      payout = winnings - bet;
      resultText = t(lang, 'slot.jackpot', { e: reels[0].emoji, w: winnings });
    } else if (reels[0].emoji === reels[1].emoji || reels[1].emoji === reels[2].emoji || reels[0].emoji === reels[2].emoji) {
      const winnings = Math.floor(bet * 1.5);
      payout = winnings - bet;
      resultText = t(lang, 'slot.pair', { w: winnings });
    } else {
      resultText = t(lang, 'slot.lose', { bet });
    }

    updateBalance(interaction.guild.id, interaction.user.id, payout);

    const embed = baseEmbed()
      .setTitle('🎰 Slot Machine')
      .setDescription(`**[ ${display} ]**\n\n${resultText}`)
      .setFooter({ text: t(lang, 'bj.bet', { bet }) });

    return interaction.reply({ embeds: [embed] });
  },
};
