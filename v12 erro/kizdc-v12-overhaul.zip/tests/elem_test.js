#!/usr/bin/env node
/* ============================================================================
 * tests/elem_test.js — v12 §9-C5: unit test SEGITIGA ELEMEN.
 * Mengetes BLOK SUMBER ASLI rpg.js (diekstrak + dieval), BUKAN salinan —
 * kalau balance di rpg.js berubah, test ini otomatis mengikuti / gagal.
 * Jalankan: node tests/elem_test.js
 * ========================================================================== */
const fs = require('fs');
const path = require('path');

const src = fs.readFileSync(path.join(__dirname, '..', 'dashboard', 'public', 'rpg.js'), 'utf8');

// Ekstrak blok murni: ELEM_GROUP .. akhir elemAdvantageInfo (tanpa FX/Phaser).
const m = src.match(/const ELEM_GROUP = \{[\s\S]*?\};\s*\nconst ELEM_BEATS[\s\S]*?\nfunction elemAdvantageInfo[\s\S]*?\n\}/);
if (!m) { console.error('GAGAL: blok ELEM tidak ditemukan di rpg.js'); process.exit(1); }

// Isolasi: fungsi murni dipaten di scope lokal.
const sandbox = new Function(m[0] + '\nreturn { ELEM_GROUP, ELEM_BEATS, elemGroup, elemAdvantage, elemAdvantageInfo };')();
const { ELEM_GROUP, elemAdvantage, elemAdvantageInfo } = sandbox;

let pass = 0, fail = 0;
function eq(actual, expected, label) {
  const ok = Math.abs(actual - expected) < 1e-9;
  if (ok) { pass++; console.log('  OK ' + label); }
  else { fail++; console.error('  GAGAL ' + label + ': dapat ' + actual + ', harus ' + expected); }
}

console.log('== segitiga elemen: siklus api > alam > listrik > air > api ==');
eq(elemAdvantage('fire', 'nature'), 1.25, 'api(membara) > alam');
eq(elemAdvantage('nature', 'bolt'), 1.25, 'alam(membumikan) > listrik');
eq(elemAdvantage('bolt', 'water'), 1.25, 'listrik(menghantar) > air');
eq(elemAdvantage('water', 'fire'), 1.25, 'air(memadamkan) > api');
eq(elemAdvantage('nature', 'fire'), 0.8, 'alam < api (kelemahan berlaku dua arah)');
eq(elemAdvantage('fire', 'water'), 0.8, 'api < air');

console.log('== dualitas cahaya <-> bayang ==');
eq(elemAdvantage('light', 'dark'), 1.2, 'cahaya vs bayang');
eq(elemAdvantage('dark', 'light'), 1.2, 'bayang vs cahaya');
eq(elemAdvantage('void', 'holy'), 1.2, 'void(bayang) vs suci(cahaya)');

console.log('== netral / identik / tak dikenal ==');
eq(elemAdvantage('fire', 'fire'), 1, 'api vs api');
eq(elemAdvantage('fire', 'light'), 1, 'api vs cahaya (tak bersinggungan)');
eq(elemAdvantage('fire', null), 1, 'elemen lawan kosong');
eq(elemAdvantage(undefined, 'fire'), 1, 'elemen penyerang kosong');
eq(elemAdvantage('gelap-gelapan', 'fire'), 1, 'elemen tak dikenal');

console.log('== pemetaan grup (14 elemen -> 6 grup) ==');
eq(elemAdvantage('darkfire', 'poison'), 1.25, 'darkfire(api) > poison(alam)');
eq(elemAdvantage('solar', 'earth'), 1.25, 'solar(api) > earth(alam)');
eq(elemAdvantage('ice', 'fire'), 1.25, 'ice(air) > fire(api)');
eq(elemAdvantage('wind', 'ice'), 1.25, 'wind(listrik) > ice(air)');
eq(elemAdvantage('poison', 'wind'), 1.25, 'poison(alam) > wind(listrik)');
eq(elemAdvantage('wind', 'poison'), 0.8, 'wind(listrik) < poison(alam)');
eq(elemAdvantage('holy', 'void'), 1.2, 'holy(cahaya) vs void(bayang)');

console.log('== info telegraf ==');
const up = elemAdvantageInfo('fire', 'nature');
eq(up.mult, 1.25, 'info.mult unggul');
if (up.adv === 'up' && up.group && up.group.name === 'API') { pass++; console.log('  OK info telegraf unggul menyertakan nama grup (colorblind-safe)'); }
else { fail++; console.error('  GAGAL info telegraf tidak menyertakan grup'); }
const down = elemAdvantageInfo('nature', 'fire');
eq(down.adv === 'down', 1, 'info.adv lemah terdeteksi');
const flat = elemAdvantageInfo('fire', 'fire');
eq(flat.adv === null, 1, 'info.adv netral = null');

console.log('== integrasi rumus damage (contoh) ==');
const base = 100;
eq(Math.max(1, Math.round(base * elemAdvantage('fire', 'nature'))), 125, '100 ATK unggul -> 125');
eq(Math.max(1, Math.round(base * elemAdvantage('nature', 'fire'))), 80, '100 ATK lemah -> 80');
eq(Math.max(1, Math.round(3 * elemAdvantage('fire', 'water'))), 2, 'damage minimum tidak di bawah 1');

console.log(`\n==== HASIL ELEM: ${pass} lulus, ${fail} gagal ====`);
process.exit(fail ? 1 : 0);
