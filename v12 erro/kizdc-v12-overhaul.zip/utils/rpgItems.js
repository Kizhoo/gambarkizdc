// ============================================================================
// KATALOG ITEM v3 — /rpg shop & /rpg inventory & market & web RPG (rpg.js)
// ----------------------------------------------------------------------------
// Katalog RESMI 90 item (dirampingkan dari ratusan item generator lama).
// Semua kategori dibagi rata:
//   Senjata 28 (Warrior 8, Mage 7, Assassin 7, Archer 6)
//   Zirah 13 · Aksesoris 13 · Ramuan/Racun 16 · Bahan 20
// SETIAP item punya EFEK sendiri (equip: efek pasif saat terpasang; consumable:
// efek saat dipakai; material: efek kecil saat dikonsumsi). ID = ID web (rpg.js),
// jadi tidak butuh pemetaan di rpgServer.js untuk item baru. ID lama bot tetap
// bisa dibaca lewat ALIASES supaya inventori pemain lama tidak rusak.
// Tier: common → uncommon → rare → epic → mythic (legendary = alias tampilan lama).
// ============================================================================
const CATEGORIES = {
  weapon:    { label: 'Senjata',  emoji_free: 'W', slot: 'equipWeapon' },
  armor:     { label: 'Zirah',    emoji_free: 'A', slot: 'equipArmor' },
  accessory: { label: 'Aksesoris',emoji_free: 'C', slot: 'equipAccessory' },
  potion:    { label: 'Ramuan',   emoji_free: 'P', slot: null },
  material:  { label: 'Bahan',    emoji_free: 'M', slot: null },
};

const TIERS = {
  common:    { name: 'Umum',       color: '#9CA3AF' },
  uncommon:  { name: 'Lumayan',    color: '#4ADE80' },
  rare:      { name: 'Langka',     color: '#38BDF8' },
  epic:      { name: 'Epik',       color: '#A855F7' },
  legendary: { name: 'Legendaris', color: '#FACC15' }, // alias tampilan tier lama
  mythic:    { name: 'Mistik',     color: '#FF4D8F' },
};

// ---------------------------------------------------------------------------
// KAMUS EFEK (dipakai rpgBattle.js & web DungeonScene):
//   cleave    {pct}       sabetan menyapu (arc lebih luas / strike ekstra)
//   lifesteal {pct}       menyerap HP sebesar pct dari damage
//   manaRegen {val}       regen MP pasif
//   execute   {pct}       damage ×1.8 vs musuh HP < pct
//   poison    {dot,turns} DoT % ATK per giliran
//   critDmg   {pct}       bonus multiplier critical
//   healBoost {pct}       ramuan heal lebih kuat
//   shield    {pct}       perisai % HP maks saat bertempur
//   thorns    {pct}       memantulkan damage ke penyerang
//   regen     {val}       regen HP pasif
//   dodge     {pct}       peluang menghindar
//   goldFind  {pct}       bonus gold dari monster
//   revive    {pct}       1× per battle/lantai: bangkit dengan % HP
// ---------------------------------------------------------------------------

// ========================= SENJATA — WARRIOR (8) =========================
// wtype dipakai ikon web (atlas) & bentuk render.
const ITEMS = {
  w_rusty:        { id: 'w_rusty', name: 'Pedang Karatan', category: 'weapon', type: 'equip', wtype: 'sword', class: 'warrior', tier: 'common', price: 80, minRank: 'G', emoji: '', stats: { atk: 3 }, effect: { kind: 'cleave', pct: 0.08 }, desc: 'Pedang tua, tapi masih bisa dipakai.' },
  w_steel:        { id: 'w_steel', name: 'Pedang Baja', category: 'weapon', type: 'equip', wtype: 'sword', class: 'warrior', tier: 'uncommon', price: 250, minRank: 'E', emoji: '', stats: { atk: 7 }, effect: { kind: 'critDmg', pct: 0.15 }, desc: 'Ditempa dari baja berkualitas — sisi tajamnya menkatkan critical.' },
  w_iron_axe:     { id: 'w_iron_axe', name: 'Kapak Besi', category: 'weapon', type: 'equip', wtype: 'axe', class: 'warrior', tier: 'uncommon', price: 280, minRank: 'E', emoji: '', stats: { atk: 9 }, effect: { kind: 'execute', pct: 0.12 }, desc: 'Kapak berat yang mudah menjatuhkan musuh lemah.' },
  w_elven:        { id: 'w_elven', name: 'Pedang Elf', category: 'weapon', type: 'equip', wtype: 'sword', class: 'warrior', tier: 'rare', price: 600, minRank: 'C', emoji: '', stats: { atk: 13, spd: 2 }, effect: { kind: 'lifesteal', pct: 0.06 }, desc: 'Ringan dan tajam, buatan pengrajin elf — sedikit menyerap nyawa.' },
  w_warhammer:    { id: 'w_warhammer', name: 'Palu Perang', category: 'weapon', type: 'equip', wtype: 'hammer', class: 'warrior', tier: 'rare', price: 650, minRank: 'C', emoji: '', stats: { atk: 14, def: 2 }, effect: { kind: 'cleave', pct: 0.3 }, desc: 'Ayunan palunya menyapu musuh di sekitar.' },
  w_knight_spear: { id: 'w_knight_spear', name: 'Tombak Ksatria', category: 'weapon', type: 'equip', wtype: 'spear', class: 'warrior', tier: 'epic', price: 1400, minRank: 'A', emoji: '', stats: { atk: 20, spd: 4 }, effect: { kind: 'cleave', pct: 0.35 }, desc: 'Jangkauan jauh — tebasan menyapu beberapa musuh sekaligus.' },
  w_dragon:       { id: 'w_dragon', name: 'Pedang Taring Naga', category: 'weapon', type: 'equip', wtype: 'sword', class: 'warrior', tier: 'epic', price: 1500, minRank: 'B', emoji: '', stats: { atk: 22 }, effect: { kind: 'lifesteal', pct: 0.15 }, desc: 'Ditempa dari taring naga asli. Menghisap nyawa musuh.' },
  w_omega:        { id: 'w_omega', name: 'Pedang Legenda Ω', category: 'weapon', type: 'equip', wtype: 'sword', class: 'warrior', tier: 'mythic', price: 4000, minRank: 'S', emoji: '', stats: { atk: 35, crit: 5 }, effect: { kind: 'cleave', pct: 0.5 }, desc: 'Senjata para legenda. Tebasannya menyapu seluruh medan.' },

  // ========================= SENJATA — MAGE (7) =========================
  w_wood_staff:   { id: 'w_wood_staff', name: 'Tongkat Kayu', category: 'weapon', type: 'equip', wtype: 'staff', class: 'mage', tier: 'common', price: 80, minRank: 'G', emoji: '', stats: { atk: 4 }, effect: { kind: 'manaRegen', val: 3 }, desc: 'Tongkat sederhana yang mengalirkan mana perlahan.' },
  w_flame_wand:   { id: 'w_flame_wand', name: 'Tongkat Api', category: 'weapon', type: 'equip', wtype: 'wand', class: 'mage', tier: 'uncommon', price: 260, minRank: 'E', emoji: '', stats: { atk: 8 }, effect: { kind: 'poison', dot: 0.1, turns: 2 }, desc: 'Ujungnya menyala — serangan membakar musuh (damage per giliran).' },
  w_arcane_orb:   { id: 'w_arcane_orb', name: 'Bola Arcanum', category: 'weapon', type: 'equip', wtype: 'orb', class: 'mage', tier: 'rare', price: 620, minRank: 'C', emoji: '', stats: { atk: 13, crit: 3 }, effect: { kind: 'critDmg', pct: 0.3 }, desc: 'Kristal arcanum yang memusatkan energi ke satu titik lemah.' },
  w_void_orb:     { id: 'w_void_orb', name: 'Bola Kehampaan', category: 'weapon', type: 'equip', wtype: 'orb', class: 'mage', tier: 'rare', price: 640, minRank: 'C', emoji: '', stats: { atk: 12, spd: 2 }, effect: { kind: 'manaRegen', val: 8 }, desc: 'Menyerap energi kehampaan — MP pulih jauh lebih cepat.' },
  w_frost_staff:  { id: 'w_frost_staff', name: 'Tongkat Es', category: 'weapon', type: 'equip', wtype: 'staff', class: 'mage', tier: 'epic', price: 1450, minRank: 'A', emoji: '', stats: { atk: 20, spd: 3 }, effect: { kind: 'manaRegen', val: 6 }, desc: 'Dingin membekukan — memulihkan MP tiap giliran.' },
  w_meteor_tome:  { id: 'w_meteor_tome', name: 'Kitab Meteor', category: 'weapon', type: 'equip', wtype: 'tome', class: 'mage', tier: 'epic', price: 1550, minRank: 'A', emoji: '', stats: { atk: 23 }, effect: { kind: 'execute', pct: 0.25 }, desc: 'Kitab kuno. Siram musuh yang nyaris tumbang.' },
  w_archstaff:    { id: 'w_archstaff', name: 'Tongkat Archmage', category: 'weapon', type: 'equip', wtype: 'staff', class: 'mage', tier: 'mythic', price: 4100, minRank: 'SS', emoji: '', stats: { atk: 36, crit: 8 }, effect: { kind: 'manaRegen', val: 12 }, desc: 'Tongkat sang Archmage. Energi sihir mengalir tanpa henti.' },

  // ========================= SENJATA — ASSASSIN (7) =========================
  w_rusty_dagger: { id: 'w_rusty_dagger', name: 'Belati Karatan', category: 'weapon', type: 'equip', wtype: 'dagger', class: 'assassin', tier: 'common', price: 80, minRank: 'G', emoji: '', stats: { atk: 3, spd: 2 }, effect: { kind: 'poison', dot: 0.06, turns: 2 }, desc: 'Belati kecil berkarat — sisa racunnya masih menusuk.' },
  w_sharp_katana: { id: 'w_sharp_katana', name: 'Katana Tajam', category: 'weapon', type: 'equip', wtype: 'katana', class: 'assassin', tier: 'uncommon', price: 270, minRank: 'E', emoji: '', stats: { atk: 7, spd: 2 }, effect: { kind: 'critDmg', pct: 0.2 }, desc: 'Bilah ramping setajam silet — critical terasa lebih sakit.' },
  w_venom_claw:   { id: 'w_venom_claw', name: 'Cakar Beracun', category: 'weapon', type: 'equip', wtype: 'claw', class: 'assassin', tier: 'rare', price: 640, minRank: 'C', emoji: '', stats: { atk: 12, crit: 3 }, effect: { kind: 'poison', dot: 0.15, turns: 3 }, desc: 'Cakar berlapis racun — meracuni lawan tiap serangan.' },
  w_twin_fang:    { id: 'w_twin_fang', name: 'Belati Taring Kembar', category: 'weapon', type: 'equip', wtype: 'dagger', class: 'assassin', tier: 'rare', price: 660, minRank: 'C', emoji: '', stats: { atk: 11, spd: 4 }, effect: { kind: 'cleave', pct: 0.25 }, desc: 'Sepasang belati viper — tebasan ganda menyapu ke depan.' },
  w_shadow_bow:   { id: 'w_shadow_bow', name: 'Busur Bayangan', category: 'weapon', type: 'equip', wtype: 'bow', class: 'assassin', tier: 'epic', price: 1450, minRank: 'A', emoji: '', stats: { atk: 20, crit: 6 }, effect: { kind: 'critDmg', pct: 0.25 }, desc: 'Panah bayangan yang selalu menemukan titik lemah.' },
  w_night_katana: { id: 'w_night_katana', name: 'Katana Malam', category: 'weapon', type: 'equip', wtype: 'katana', class: 'assassin', tier: 'epic', price: 1500, minRank: 'A', emoji: '', stats: { atk: 21, spd: 5 }, effect: { kind: 'execute', pct: 0.2 }, desc: 'Ditempa di bawah bulan — mematikan bagi musuh sekarat.' },
  w_phantom:      { id: 'w_phantom', name: 'Belati Phantom', category: 'weapon', type: 'equip', wtype: 'dagger', class: 'assassin', tier: 'mythic', price: 4000, minRank: 'S', emoji: '', stats: { atk: 33, crit: 12, spd: 8 }, effect: { kind: 'execute', pct: 0.3 }, desc: 'Belati yang menembus bayangan dan jantung sekaligus.' },

  // ========================= SENJATA — ARCHER (6) =========================
  // Catatan migrasi: ini dulunya senjata HEALER. ID lama dipetakan lewat ALIASES
  // ke senjata archer baru supaya inventori pemain lama otomatis terkonversi.
  w_short_bow:    { id: 'w_short_bow', name: 'Busur Pemburu', category: 'weapon', type: 'equip', wtype: 'bow', class: 'archer', tier: 'common', price: 80, minRank: 'G', emoji: '', stats: { atk: 4 }, effect: { kind: 'critDmg', pct: 0.1 }, desc: 'Busur kayu lurus. Berat tarikannya jujur, panahnya juga.' },
  w_hunt_longbow: { id: 'w_hunt_longbow', name: 'Longbow Pemburu', category: 'weapon', type: 'equip', wtype: 'bow', class: 'archer', tier: 'uncommon', price: 260, minRank: 'E', emoji: '', stats: { atk: 8, spd: 2 }, effect: { kind: 'critDmg', pct: 0.15 }, desc: 'Lengkung tinggi warisan pemburu tua — bidikan sedikit lebih tajam.' },
  w_recurve_bow:  { id: 'w_recurve_bow', name: 'Busur Recurve', category: 'weapon', type: 'equip', wtype: 'bow', class: 'archer', tier: 'rare', price: 620, minRank: 'C', emoji: '', stats: { atk: 13, crit: 3 }, effect: { kind: 'critDmg', pct: 0.25 }, desc: 'Ujungnya melengkung dua arah. Tenang menembus angin.' },
  w_bone_bow:     { id: 'w_bone_bow', name: 'Busur Tulang', category: 'weapon', type: 'equip', wtype: 'bow', class: 'archer', tier: 'rare', price: 640, minRank: 'C', emoji: '', stats: { atk: 12, spd: 4 }, effect: { kind: 'poison', dot: 0.08, turns: 3 }, desc: 'Dirangkai dari tulang makhluk gua. Lukanya suka bernanah.' },
  w_elven_bow:    { id: 'w_elven_bow', name: 'Busur Elf', category: 'weapon', type: 'equip', wtype: 'bow', class: 'archer', tier: 'epic', price: 1400, minRank: 'A', emoji: '', stats: { atk: 20, crit: 5 }, effect: { kind: 'critDmg', pct: 0.3 }, desc: 'Kayu elf yang selalu ingat ke mana panah harus pergi.' },
  w_windseeker:   { id: 'w_windseeker', name: 'Windseeker', category: 'weapon', type: 'equip', wtype: 'bow', class: 'archer', tier: 'mythic', price: 4000, minRank: 'S', emoji: '', stats: { atk: 34, crit: 10, spd: 6 }, effect: { kind: 'critDmg', pct: 0.4 }, desc: 'Busur legendaris yang menembak sebelum kamu sempat berpikir.' },

  // ========================= ZIRAH (13) =========================
  a_leather:      { id: 'a_leather', name: 'Baju Kulit', category: 'armor', type: 'equip', atype: 'light', tier: 'common', price: 80, minRank: 'G', emoji: '', stats: { def: 3 }, effect: { kind: 'regen', val: 1 }, desc: 'Perlindungan dasar yang memulihkan luka perlahan.' },
  a_padded_vest:  { id: 'a_padded_vest', name: 'Rompi Empuk', category: 'armor', type: 'equip', atype: 'light', tier: 'common', price: 85, minRank: 'G', emoji: '', stats: { def: 2, hp: 10 }, effect: { kind: 'thorns', pct: 0.05 }, desc: 'Rompi tebal yang memantulkan sedikit pukulan.' },
  a_chain:        { id: 'a_chain', name: 'Baju Rantai', category: 'armor', type: 'equip', atype: 'mail', tier: 'uncommon', price: 250, minRank: 'E', emoji: '', stats: { def: 7 }, effect: { kind: 'thorns', pct: 0.08 }, desc: 'Anyaman rantai yang memantulkan serangan.' },
  a_ranger_coat:  { id: 'a_ranger_coat', name: 'Jaket Ranger', category: 'armor', type: 'equip', atype: 'coat', tier: 'uncommon', price: 260, minRank: 'E', emoji: '', stats: { def: 5, spd: 3 }, effect: { kind: 'dodge', pct: 0.06 }, desc: 'Jaket pelari rimba — serangan musuh kadang meleset.' },
  a_guardian:     { id: 'a_guardian', name: 'Zirah Penjaga', category: 'armor', type: 'equip', atype: 'plate', tier: 'rare', price: 620, minRank: 'D', emoji: '', stats: { def: 12, hp: 20 }, effect: { kind: 'shield', pct: 0.12 }, desc: 'Zirah penjaga yang memberi perisai di awal bertempur.' },
  a_plate:        { id: 'a_plate', name: 'Baju Pelat', category: 'armor', type: 'equip', atype: 'plate', tier: 'rare', price: 600, minRank: 'C', emoji: '', stats: { def: 13 }, effect: { kind: 'thorns', pct: 0.15 }, desc: 'Pelat baja tebal — musuh yang menyerang ikut terluka.' },
  a_mithril_mail: { id: 'a_mithril_mail', name: 'Zirah Mithril', category: 'armor', type: 'equip', atype: 'mail', tier: 'rare', price: 640, minRank: 'C', emoji: '', stats: { def: 11, spd: 2, mp: 10 }, effect: { kind: 'manaRegen', val: 4 }, desc: 'Ringan berkilau — mana mengalir lebih lancar.' },
  a_dragon:       { id: 'a_dragon', name: 'Zirah Sisik Naga', category: 'armor', type: 'equip', atype: 'scale', tier: 'epic', price: 1500, minRank: 'B', emoji: '', stats: { def: 22 }, effect: { kind: 'thorns', pct: 0.25 }, desc: 'Sisik naga memantulkan seperempat damage ke penyerang.' },
  a_titan_aegis:  { id: 'a_titan_aegis', name: 'Aegis Titan', category: 'armor', type: 'equip', atype: 'aegis', tier: 'epic', price: 1450, minRank: 'A', emoji: '', stats: { def: 18, hp: 40 }, effect: { kind: 'shield', pct: 0.2 }, desc: 'Perisai raksasa para titan — pelindung awal yang tebal.' },
  a_frost_bulwark:{ id: 'a_frost_bulwark', name: 'Benteng Beku', category: 'armor', type: 'equip', atype: 'bulwark', tier: 'epic', price: 1500, minRank: 'A', emoji: '', stats: { def: 20, mp: 15 }, effect: { kind: 'regen', val: 5 }, desc: 'Kegelapan es yang terus memulihkan tubuhnya.' },
  a_omega:        { id: 'a_omega', name: 'Zirah Suci Ω', category: 'armor', type: 'equip', atype: 'aegis', tier: 'mythic', price: 4000, minRank: 'S', emoji: '', stats: { def: 35, spd: 5 }, effect: { kind: 'shield', pct: 0.25 }, desc: 'Diberkati guild tertinggi. Memberi perisai saat bertempur.' },
  a_void_shroud:  { id: 'a_void_shroud', name: 'Selubung Kehampaan', category: 'armor', type: 'equip', atype: 'shroud', tier: 'mythic', price: 4200, minRank: 'S', emoji: '', stats: { def: 26, spd: 6 }, effect: { kind: 'dodge', pct: 0.12 }, desc: 'Tubuhmu setengah ada di dimensi lain — serangan menembus kosong.' },
  a_phoenix_mail: { id: 'a_phoenix_mail', name: 'Zirah Phoenix', category: 'armor', type: 'equip', atype: 'scale', tier: 'mythic', price: 4400, minRank: 'S', emoji: '', stats: { def: 30, hp: 50 }, effect: { kind: 'revive', pct: 0.3 }, desc: 'Seperti phoenix: bangkit sekali dari kematian dengan 30% HP.' },

  // ========================= AKSESORIS (13) =========================
  c_lucky_coin:   { id: 'c_lucky_coin', name: 'Koin Keberuntungan', category: 'accessory', type: 'equip', ctype: 'coin', tier: 'common', price: 120, minRank: 'G', emoji: '', stats: { spd: 1 }, effect: { kind: 'goldFind', pct: 0.1 }, desc: 'Koin kuno yang selalu menarik emas ke arahmu.' },
  c_swift:        { id: 'c_swift', name: 'Cincin Gesit', category: 'accessory', type: 'equip', ctype: 'ring', tier: 'uncommon', price: 100, minRank: 'G', emoji: '', stats: { spd: 3 }, effect: { kind: 'dodge', pct: 0.04 }, desc: 'Gerakanmu lebih ringan — sedikit peluang menghindar.' },
  c_crit:         { id: 'c_crit', name: 'Anting Kritis', category: 'accessory', type: 'equip', ctype: 'earring', tier: 'uncommon', price: 100, minRank: 'G', emoji: '', stats: { crit: 3 }, effect: { kind: 'critDmg', pct: 0.15 }, desc: 'Menajamkan insting — critical lebih berdarah.' },
  c_mana_ring:    { id: 'c_mana_ring', name: 'Cincin Mana', category: 'accessory', type: 'equip', ctype: 'ring', tier: 'uncommon', price: 180, minRank: 'E', emoji: '', stats: { mp: 15 }, effect: { kind: 'manaRegen', val: 3 }, desc: 'Cincin safir yang meneteskan mana perlahan.' },
  c_cloak:        { id: 'c_cloak', name: 'Jubah Bayangan', category: 'accessory', type: 'equip', ctype: 'cloak', tier: 'rare', price: 400, minRank: 'D', emoji: '', stats: { spd: 6, crit: 2 }, effect: { kind: 'dodge', pct: 0.08 }, desc: 'Menyatu dengan bayangan — serangan meleset lebih sering.' },
  c_vital:        { id: 'c_vital', name: 'Gelang Vitalitas', category: 'accessory', type: 'equip', ctype: 'bracelet', tier: 'rare', price: 420, minRank: 'D', emoji: '', stats: { hp: 40 }, effect: { kind: 'regen', val: 2 }, desc: 'Menguatkan daya tahan tubuh dan memulihkannya.' },
  c_blood_pendant:{ id: 'c_blood_pendant', name: 'Liontin Darah', category: 'accessory', type: 'equip', ctype: 'necklace', tier: 'rare', price: 450, minRank: 'D', emoji: '', stats: { atk: 6 }, effect: { kind: 'lifesteal', pct: 0.08 }, desc: 'Berdenyut seperti jantung — menyerap nyawa musuh.' },
  c_thorn_bracer: { id: 'c_thorn_bracer', name: 'Deker Duri', category: 'accessory', type: 'equip', ctype: 'bracer', tier: 'rare', price: 440, minRank: 'D', emoji: '', stats: { def: 4 }, effect: { kind: 'thorns', pct: 0.12 }, desc: 'Duri hitam yang melukai siapa pun yang menyerangmu.' },
  c_crown:        { id: 'c_crown', name: 'Mahkota Raja', category: 'accessory', type: 'equip', ctype: 'crown', tier: 'epic', price: 1200, minRank: 'A', emoji: '', stats: { spd: 10, crit: 5 }, effect: { kind: 'goldFind', pct: 0.15 }, desc: 'Harta karun para raja — emas mengalir lebih deras.' },
  c_storm_charm:  { id: 'c_storm_charm', name: 'Jimat Badai', category: 'accessory', type: 'equip', ctype: 'charm', tier: 'epic', price: 1250, minRank: 'A', emoji: '', stats: { crit: 8 }, effect: { kind: 'critDmg', pct: 0.4 }, desc: 'Listrik badai meledak di setiap critical.' },
  c_guardian_angel:{ id: 'c_guardian_angel', name: 'Pelindung Malaikat', category: 'accessory', type: 'equip', ctype: 'amulet', tier: 'epic', price: 1300, minRank: 'A', emoji: '', stats: { def: 6, hp: 30 }, effect: { kind: 'shield', pct: 0.15 }, desc: 'Sayap halus membentuk perisai cahaya di awal bertempur.' },
  c_phoenix:      { id: 'c_phoenix', name: 'Kalung Phoenix', category: 'accessory', type: 'equip', ctype: 'necklace', tier: 'mythic', price: 4000, minRank: 'S', emoji: '', stats: { hp: 50, crit: 8 }, effect: { kind: 'lifesteal', pct: 0.12 }, desc: 'Abu phoenix — menghidupkan kembali semangatmu.' },
  c_time_hourglass:{ id: 'c_time_hourglass', name: 'Jam Pasir Waktu', category: 'accessory', type: 'equip', ctype: 'hourglass', tier: 'mythic', price: 4200, minRank: 'S', emoji: '', stats: { spd: 8 }, effect: { kind: 'revive', pct: 0.25 }, desc: 'Mengulang sekejap waktu — bangkit sekali dengan 25% HP.' },

  // ========================= RAMUAN & RACUN (16, consumable) =========================
  p_heal_s:   { id: 'p_heal_s', name: 'Ramuan Kecil', category: 'potion', type: 'consumable', kind: 'heal', tier: 'common', price: 20, emoji: '', effect: { kind: 'heal', val: 40 }, desc: 'Pulihkan 40 HP.' },
  p_heal_m:   { id: 'p_heal_m', name: 'Ramuan Sedang', category: 'potion', type: 'consumable', kind: 'heal', tier: 'uncommon', price: 50, emoji: '', effect: { kind: 'heal', val: 100 }, desc: 'Pulihkan 100 HP.' },
  p_heal_l:   { id: 'p_heal_l', name: 'Ramuan Besar', category: 'potion', type: 'consumable', kind: 'heal', tier: 'rare', price: 120, emoji: '', effect: { kind: 'heal', val: 250 }, desc: 'Pulihkan 250 HP.' },
  p_mana:     { id: 'p_mana', name: 'Ramuan Mana', category: 'potion', type: 'consumable', kind: 'mana', tier: 'uncommon', price: 40, emoji: '', effect: { kind: 'mana', val: 50 }, desc: 'Pulihkan 50 MP.' },
  p_mana_l:   { id: 'p_mana_l', name: 'Ramuan Mana Besar', category: 'potion', type: 'consumable', kind: 'mana', tier: 'rare', price: 95, emoji: '', effect: { kind: 'mana', val: 120 }, desc: 'Pulihkan 120 MP.' },
  p_strength: { id: 'p_strength', name: 'Ramuan Kekuatan', category: 'potion', type: 'consumable', kind: 'strength', tier: 'rare', price: 90, emoji: '', effect: { kind: 'strength', val: 0.35, turns: 3 }, desc: 'ATK +35% selama 3 giliran.' },
  p_berserk:  { id: 'p_berserk', name: 'Ramuan Amuk', category: 'potion', type: 'consumable', kind: 'berserk', tier: 'epic', price: 140, emoji: '', effect: { kind: 'berserk', val: 0.6, turns: 2 }, desc: 'ATK +60% selama 2 giliran — amukan total.' },
  p_swift:    { id: 'p_swift', name: 'Ramuan Kilat', category: 'potion', type: 'consumable', kind: 'swift', tier: 'rare', price: 85, emoji: '', effect: { kind: 'swift', val: 0.25, turns: 3 }, desc: 'Peluang menghindar +25% selama 3 giliran.' },
  p_regen:    { id: 'p_regen', name: 'Ramuan Regenerasi', category: 'potion', type: 'consumable', kind: 'regen', tier: 'rare', price: 80, emoji: '', effect: { kind: 'regen', val: 25, turns: 4 }, desc: 'Regen +25 HP/giliran selama 4 giliran.' },
  p_manareg:  { id: 'p_manareg', name: 'Ramuan Fokus', category: 'potion', type: 'consumable', kind: 'manaRegen', tier: 'rare', price: 70, emoji: '', effect: { kind: 'manaRegen', val: 15, turns: 4 }, desc: 'Regen +15 MP/giliran selama 4 giliran.' },
  p_guard:    { id: 'p_guard', name: 'Ramuan Pelindung', category: 'potion', type: 'consumable', kind: 'shield', tier: 'epic', price: 130, emoji: '', effect: { kind: 'shield', val: 0.3 }, desc: 'Perisai 30% HP maks seketika.' },
  p_poison:   { id: 'p_poison', name: 'Racun Mematikan', category: 'potion', type: 'consumable', kind: 'poison', tier: 'epic', price: 110, emoji: '', effect: { kind: 'poison', val: 30, turns: 3 }, desc: 'Racuni musuh: -30 HP/giliran selama 3 giliran.' },
  p_venom:    { id: 'p_venom', name: 'Racun Viper', category: 'potion', type: 'consumable', kind: 'venom', tier: 'epic', price: 160, emoji: '', effect: { kind: 'venom', val: 55, turns: 3 }, desc: 'Racun super: -55 HP/giliran selama 3 giliran.' },
  p_weaken:   { id: 'p_weaken', name: 'Racun Pelemah', category: 'potion', type: 'consumable', kind: 'weaken', tier: 'uncommon', price: 85, emoji: '', effect: { kind: 'weaken', val: 0.4, turns: 3 }, desc: 'Melemahkan ATK musuh -40% selama 3 giliran.' },
  p_paralyze: { id: 'p_paralyze', name: 'Racun Lumpuh', category: 'potion', type: 'consumable', kind: 'paralyze', tier: 'epic', price: 180, emoji: '', effect: { kind: 'paralyze', val: 1, turns: 2 }, desc: 'Lumpuhkan musuh — ia melewatkan 2 giliran.' },
  p_elixir:   { id: 'p_elixir', name: 'Elixir', category: 'potion', type: 'consumable', kind: 'elixir', tier: 'epic', price: 300, emoji: '', effect: { kind: 'elixir' }, desc: 'Pulihkan HP & MP sepenuhnya.' },

  // ========================= BAHAN (20, material — bisa dipakai utk efek kecil) =========================
  m_slime_jelly:    { id: 'm_slime_jelly', name: 'Jeli Slime', category: 'material', type: 'material', mtype: 'jelly', tier: 'common', price: 12, emoji: '', use: { kind: 'heal', val: 15 }, desc: 'Gumpalan jeli lengket. Dimakan: pulihkan 15 HP.' },
  m_rat_tail:       { id: 'm_rat_tail', name: 'Ekor Tikus', category: 'material', type: 'material', mtype: 'bone', tier: 'common', price: 10, emoji: '', use: { kind: 'mana', val: 10 }, desc: 'Ekor kering tikus kerangka. Dimakan: pulihkan 10 MP.' },
  m_bat_wing:       { id: 'm_bat_wing', name: 'Sayap Kelelawar', category: 'material', type: 'material', mtype: 'wing', tier: 'common', price: 12, emoji: '', use: { kind: 'swift', val: 0.1, turns: 2 }, desc: 'Sayap tipis jurang. Konsumsi: hindar +10% (2 giliran).' },
  m_goblin_ear:     { id: 'm_goblin_ear', name: 'Telinga Goblin', category: 'material', type: 'material', mtype: 'organ', tier: 'common', price: 15, emoji: '', use: { kind: 'heal', val: 20 }, desc: 'Telinga runcing goblin. Dimakan: pulihkan 20 HP.' },
  m_bone:           { id: 'm_bone', name: 'Tulang', category: 'material', type: 'material', mtype: 'bone', tier: 'common', price: 10, emoji: '', use: { kind: 'strength', val: 0.1, turns: 2 }, desc: 'Tulang kerangka hidup. Digerus: ATK +10% (2 giliran).' },
  m_wolf_pelt:      { id: 'm_wolf_pelt', name: 'Bulu Serigala', category: 'material', type: 'material', mtype: 'pelt', tier: 'uncommon', price: 22, emoji: '', use: { kind: 'shield', val: 0.1 }, desc: 'Bulu tebal serigala. Dililitkan: perisai 10% HP maks.' },
  m_venom_sac:      { id: 'm_venom_sac', name: 'Kantong Racun', category: 'material', type: 'material', mtype: 'organ', tier: 'uncommon', price: 26, emoji: '', use: { kind: 'poison', val: 12, turns: 2 }, desc: 'Kantong racun laba-laba. Konsumsi: racun 12/giliran (2 giliran).' },
  m_imp_ember:      { id: 'm_imp_ember', name: 'Bara Iblis Kecil', category: 'material', type: 'material', mtype: 'ember', tier: 'uncommon', price: 24, emoji: '', use: { kind: 'strength', val: 0.15, turns: 2 }, desc: 'Bara yang masih menyala. Konsumsi: ATK +15% (2 giliran).' },
  m_hyena_fang:     { id: 'm_hyena_fang', name: 'Taring Hyena', category: 'material', type: 'material', mtype: 'bone', tier: 'uncommon', price: 22, emoji: '', use: { kind: 'heal', val: 25 }, desc: 'Taring tajam hyena gurun. Dimakan: pulihkan 25 HP.' },
  m_vulture_feather:{ id: 'm_vulture_feather', name: 'Bulu Nasar', category: 'material', type: 'material', mtype: 'wing', tier: 'uncommon', price: 22, emoji: '', use: { kind: 'swift', val: 0.12, turns: 2 }, desc: 'Bulu burung nasar. Konsumsi: hindar +12% (2 giliran).' },
  m_turtle_shell:   { id: 'm_turtle_shell', name: 'Tempurung Kura', category: 'material', type: 'material', mtype: 'shell', tier: 'rare', price: 40, emoji: '', use: { kind: 'shield', val: 0.15 }, desc: 'Tempurung kura raksasa. Dipakai: perisai 15% HP maks.' },
  m_gargoyle_shard: { id: 'm_gargoyle_shard', name: 'Pecahan Gargoyle', category: 'material', type: 'material', mtype: 'shard', tier: 'rare', price: 42, emoji: '', use: { kind: 'strength', val: 0.12, turns: 3 }, desc: 'Pecahan batu gargoyle. Digerus: ATK +12% (3 giliran).' },
  m_mummy_bandage:  { id: 'm_mummy_bandage', name: 'Perban Mumi', category: 'material', type: 'material', mtype: 'bandage', tier: 'rare', price: 40, emoji: '', use: { kind: 'regen', val: 15, turns: 3 }, desc: 'Perban kuno. Dililitkan: regen 15 HP/giliran (3 giliran).' },
  m_orc_tusk:       { id: 'm_orc_tusk', name: 'Taring Orc', category: 'material', type: 'material', mtype: 'bone', tier: 'rare', price: 45, emoji: '', use: { kind: 'strength', val: 0.2, turns: 2 }, desc: 'Taring besar orc. Digerus: ATK +20% (2 giliran).' },
  m_golem_core:     { id: 'm_golem_core', name: 'Inti Golem', category: 'material', type: 'material', mtype: 'core', tier: 'rare', price: 50, emoji: '', use: { kind: 'shield', val: 0.2 }, desc: 'Inti batu berenergi. Dipakai: perisai 20% HP maks.' },
  m_wraith_ecto:    { id: 'm_wraith_ecto', name: 'Ektoplasma', category: 'material', type: 'material', mtype: 'ecto', tier: 'epic', price: 70, emoji: '', use: { kind: 'mana', val: 60 }, desc: 'Arwah yang membeku. Konsumsi: pulihkan 60 MP.' },
  m_yeti_fur:       { id: 'm_yeti_fur', name: 'Bulu Yeti', category: 'material', type: 'material', mtype: 'pelt', tier: 'epic', price: 80, emoji: '', use: { kind: 'regen', val: 20, turns: 3 }, desc: 'Bulu tebal yeti salju. Dipakai: regen 20 HP/giliran (3 giliran).' },
  m_minotaur_horn:  { id: 'm_minotaur_horn', name: 'Tanduk Minotaur', category: 'material', type: 'material', mtype: 'horn', tier: 'epic', price: 95, emoji: '', use: { kind: 'berserk', val: 0.4, turns: 2 }, desc: 'Tanduk sang minotaur. Digerus: ATK +40% (2 giliran).' },
  m_dragon_scale:   { id: 'm_dragon_scale', name: 'Sisik Naga', category: 'material', type: 'material', mtype: 'scale', tier: 'epic', price: 110, emoji: '', use: { kind: 'shield', val: 0.25 }, desc: 'Sisik naga purba. Dipakai: perisai 25% HP maks.' },
  m_demon_heart:    { id: 'm_demon_heart', name: 'Jantung Iblis', category: 'material', type: 'material', mtype: 'heart', tier: 'mythic', price: 220, emoji: '', use: { kind: 'elixir' }, desc: 'Masih berdetak. Dikonsumsi: pulihkan HP & MP penuh.' },
};

// ---------- ITEM PET ----------
// Seruling: dikonsumsi -> MEMANGGIL pet acak sesuai tingkat seruling (roll SERVER,
// sama seperti loot peti). Camilan: memberi XP pada pet aktif. Duplikat pet yang
// sudah dimiliki otomatis dikonversi jadi camilan supaya tidak sia-sia.
const PET_ITEMS = {
  m_whistle_cracked: { id: 'm_whistle_cracked', name: 'Seruling Retak',  category: 'material', type: 'use', mtype: 'whistle', tier: 'uncommon', price: 350,  emoji: '', use: { kind: 'petroll', pool: ['common'] },                  desc: 'Suaranya serak. Ditukar jadi 70 permata gacha + pecahan bintang.' },
  m_whistle_silver:  { id: 'm_whistle_silver',  name: 'Seruling Perak',  category: 'material', type: 'use', mtype: 'whistle', tier: 'rare',     price: 900,  emoji: '', use: { kind: 'petroll', pool: ['common', 'uncommon', 'rare'] },    desc: 'Nada peraknya menembus jauh. Ditukar jadi 170 permata gacha + pecahan.' },
  m_whistle_gold:    { id: 'm_whistle_gold',    name: 'Seruling Emas',   category: 'material', type: 'use', mtype: 'whistle', tier: 'epic',     price: 2200, emoji: '', use: { kind: 'petroll', pool: ['rare', 'epic'] },                desc: 'Gema keemasan. Ditukar jadi 260 permata gacha + pecahan bintang.' },
  m_whistle_mythic:  { id: 'm_whistle_mythic',  name: 'Seruling Mistik', category: 'material', type: 'use', mtype: 'whistle', tier: 'mythic',   price: 5000, emoji: '', use: { kind: 'petroll', pool: ['epic', 'legendary'] },            desc: 'Pusaka purba. Ditukar jadi 550 permata gacha + banyak pecahan bintang.' },
  m_snack:           { id: 'm_snack',           name: 'Camilan Pet',     category: 'material', type: 'use', mtype: 'snack',   tier: 'common',   price: 60,   emoji: '', use: { kind: 'petxp', val: 50 },  desc: 'Biskuit ikan kering. Pet aktif +50 XP.' },
  m_snack_l:         { id: 'm_snack_l',         name: 'Hidangan Pet',    category: 'material', type: 'use', mtype: 'snack',   tier: 'rare',     price: 200,  emoji: '', use: { kind: 'petxp', val: 150 }, desc: 'Sajian lengkap berbahan langka. Pet aktif +150 XP.' },
};
for (const [k, v] of Object.entries(PET_ITEMS)) ITEMS[k] = v;

// Alias ID LAMA bot → ID kanonik (web). Inventori/equipment pemain lama tetap valid.
// Termasuk konversi senjata HEALER (class lama) → senjata ARCHER (class baru).
const ALIASES = {
  w_rusty_sword: 'w_rusty', w_steel_sword: 'w_steel', w_elven_blade: 'w_elven',
  w_dragon_fang: 'w_dragon', w_omega_blade: 'w_omega',
  a_leather_armor: 'a_leather', a_chain_armor: 'a_chain', a_plate_armor: 'a_plate',
  a_dragon_armor: 'a_dragon', a_omega_armor: 'a_omega',
  c_swift_ring: 'c_swift', c_crit_earring: 'c_crit', c_shadow_cloak: 'c_cloak', c_royal_crown: 'c_crown',
  p_small_potion: 'p_heal_s', p_medium_potion: 'p_heal_m', p_large_potion: 'p_heal_l', p_mana_potion: 'p_mana',
  // Healer (lama) → Archer (baru)
  w_wood_scepter: 'w_short_bow', w_holy_tome: 'w_hunt_longbow', w_moon_chalice: 'w_recurve_bow',
  w_blessed_relic: 'w_bone_bow', w_divine_staff: 'w_elven_bow', w_seraph: 'w_windseeker',
};

function getItem(id) { return ITEMS[id] || ITEMS[ALIASES[id]] || null; }
function listByCategory(category) { return Object.values(ITEMS).filter(it => it.category === category); }
function allCategories() { return Object.entries(CATEGORIES).map(([key, v]) => ({ key, ...v })); }

// Senjata yang boleh dipakai sebuah class (untuk filter inventory/forge + validasi equip).
function itemsForClass(classKey, category = 'weapon') {
  return Object.values(ITEMS).filter(it => it.category === category && (!it.class || it.class === classKey));
}
// Efek khusus item equip (senjata/zirah/aksesoris).
function weaponEffect(id) { const it = ITEMS[id]; return it && it.effect && (it.type === 'equip') ? it.effect : null; }
// Validasi kelas boleh memakai item (senjata class-bound).
function classAllowed(classKey, item) {
  if (!item || item.category !== 'weapon') return true;
  return !item.class || item.class === classKey;
}
// Gabungkan efek SEMUA equipment yang terpasang (senjata + zirah + aksesoris)
// jadi satu objek efek gabungan — dipakai battle engine & web dungeon.
function equipEffects(char) {
  const merged = {};
  for (const slot of ['equipWeapon', 'equipArmor', 'equipAccessory']) {
    const it = char && char[slot] && getItem(char[slot]);
    if (!it || !it.effect) continue;
    const e = it.effect;
    if (e.kind === 'cleave') merged.cleave = Math.max(merged.cleave || 0, e.pct);
    else if (e.kind === 'lifesteal') merged.lifesteal = (merged.lifesteal || 0) + e.pct;
    else if (e.kind === 'manaRegen') merged.manaRegen = (merged.manaRegen || 0) + e.val;
    else if (e.kind === 'execute') merged.execute = Math.max(merged.execute || 0, e.pct);
    else if (e.kind === 'poison') merged.poison = Math.max(merged.poison || 0, e.dot);
    else if (e.kind === 'critDmg') merged.critDmg = (merged.critDmg || 0) + e.pct;
    else if (e.kind === 'healBoost') merged.healBoost = (merged.healBoost || 0) + e.pct;
    else if (e.kind === 'shield') merged.shield = Math.max(merged.shield || 0, e.pct);
    else if (e.kind === 'thorns') merged.thorns = Math.max(merged.thorns || 0, e.pct);
    else if (e.kind === 'regen') merged.regen = (merged.regen || 0) + e.val;
    else if (e.kind === 'dodge') merged.dodge = (merged.dodge || 0) + e.pct;
    else if (e.kind === 'goldFind') merged.goldFind = (merged.goldFind || 0) + e.pct;
    else if (e.kind === 'revive') merged.revive = Math.max(merged.revive || 0, e.pct);
  }
  return merged;
}

// Resep FORGE (material → item). ID output = ID kanonik (sama dengan web rpg.js).
// Terbagi tiga kategori: senjata, zirah, aksesoris — pandai besi yang lengkap.
const FORGE_RECIPES = [
  // --- Senjata ---
  { out: 'w_iron_axe', cost: { m_slime_jelly: 4, m_bone: 2 } },
  { out: 'w_steel', cost: { m_goblin_ear: 4, m_imp_ember: 2 } },
  { out: 'w_arcane_orb', cost: { m_golem_core: 3, m_wraith_ecto: 1 } },
  { out: 'w_venom_claw', cost: { m_venom_sac: 4, m_bat_wing: 2 } },
  { out: 'w_warhammer', cost: { m_orc_tusk: 3, m_bone: 4 } },
  { out: 'w_hunt_longbow', cost: { m_wolf_pelt: 3, m_bat_wing: 2 } },
  { out: 'w_frost_staff', cost: { m_yeti_fur: 3, m_golem_core: 1 } },
  { out: 'w_knight_spear', cost: { m_orc_tusk: 5, m_minotaur_horn: 1 } },
  { out: 'w_shadow_bow', cost: { m_vulture_feather: 4, m_wraith_ecto: 2 } },
  { out: 'w_recurve_bow', cost: { m_turtle_shell: 2, m_vulture_feather: 3 } },
  { out: 'w_bone_bow', cost: { m_bone: 6, m_gargoyle_shard: 2 } },
  { out: 'w_meteor_tome', cost: { m_imp_ember: 5, m_gargoyle_shard: 2 } },
  { out: 'w_dragon', cost: { m_dragon_scale: 4, m_minotaur_horn: 1 } },
  { out: 'w_void_orb', cost: { m_gargoyle_shard: 3, m_wraith_ecto: 2 } },
  { out: 'w_twin_fang', cost: { m_hyena_fang: 4, m_venom_sac: 2 } },
  { out: 'w_elven_bow', cost: { m_yeti_fur: 3, m_dragon_scale: 2 } },
  { out: 'w_phantom', cost: { m_wraith_ecto: 5, m_demon_heart: 1 } },
  { out: 'w_omega', cost: { m_demon_heart: 3, m_dragon_scale: 5 } },
  { out: 'w_archstaff', cost: { m_wraith_ecto: 6, m_demon_heart: 2 } },
  { out: 'w_windseeker', cost: { m_dragon_scale: 3, m_gargoyle_shard: 3, m_demon_heart: 1 } },
  // --- Zirah ---
  { out: 'a_chain', cost: { m_wolf_pelt: 3, m_bone: 3 } },
  { out: 'a_ranger_coat', cost: { m_wolf_pelt: 4, m_bat_wing: 3 } },
  { out: 'a_guardian', cost: { m_turtle_shell: 3, m_golem_core: 1 } },
  { out: 'a_plate', cost: { m_gargoyle_shard: 4, m_orc_tusk: 2 } },
  { out: 'a_mithril_mail', cost: { m_golem_core: 2, m_gargoyle_shard: 3 } },
  { out: 'a_dragon', cost: { m_dragon_scale: 4, m_minotaur_horn: 1 } },
  { out: 'a_titan_aegis', cost: { m_minotaur_horn: 2, m_golem_core: 3 } },
  { out: 'a_phoenix_mail', cost: { m_demon_heart: 2, m_dragon_scale: 4 } },
  // --- Aksesoris ---
  { out: 'c_vital', cost: { m_mummy_bandage: 3, m_slime_jelly: 4 } },
  { out: 'c_blood_pendant', cost: { m_venom_sac: 3, m_wraith_ecto: 2 } },
  { out: 'c_thorn_bracer', cost: { m_hyena_fang: 3, m_gargoyle_shard: 2 } },
  { out: 'c_storm_charm', cost: { m_imp_ember: 4, m_wraith_ecto: 3 } },
  { out: 'c_guardian_angel', cost: { m_mummy_bandage: 4, m_yeti_fur: 3 } },
  { out: 'c_time_hourglass', cost: { m_demon_heart: 2, m_wraith_ecto: 5 } },
  // --- Item pet ---
  { out: 'm_snack',      cost: { m_slime_jelly: 2, m_goblin_ear: 1 } },
  { out: 'm_snack_l',    cost: { m_yeti_fur: 1, m_mummy_bandage: 2 } },
  { out: 'm_whistle_cracked', cost: { m_bone: 4, m_bat_wing: 3 } },
  { out: 'm_whistle_silver',  cost: { m_golem_core: 2, m_vulture_feather: 4 } },
  { out: 'm_whistle_gold',    cost: { m_minotaur_horn: 1, m_dragon_scale: 3 } },
  { out: 'm_whistle_mythic',  cost: { m_demon_heart: 1, m_wraith_ecto: 6, m_dragon_scale: 3 } },
];

module.exports = { ITEMS, ALIASES, CATEGORIES, TIERS, PET_ITEMS, getItem, listByCategory, allCategories, itemsForClass, weaponEffect, classAllowed, equipEffects, FORGE_RECIPES };
