const { SlashCommandBuilder } = require('discord.js');
const { isOwner } = require('../../utils/ownerCheck');
const { sendBackupToOwner } = require('../../utils/backup');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { safeDefer } = require('../../utils/interactionHelpers');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('backup')
    .setDescription('[Owner] Backup penuh file penting bot & kirim ke DM owner sekarang'),

  async execute(interaction, client) {
    const lang = guildLang(interaction);
    if (!isOwner(interaction.user.id)) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'util.owner_only'))], ephemeral: true });
    }
    if (!(await safeDefer(interaction, { ephemeral: true }))) return;
    try {
      const { archive, files } = await sendBackupToOwner(client, 'manual /backup');
      return interaction.editReply({ embeds: [successEmbed(t(lang, 'backup.ok', { detail: archive ? '1 arsip .tar.gz' : files.length + ' file' }))] });
    } catch (e) {
      return interaction.editReply({ embeds: [errorEmbed(t(lang, 'backup.fail', { e: e.message }))] }).catch(() => {});
    }
  },
};
