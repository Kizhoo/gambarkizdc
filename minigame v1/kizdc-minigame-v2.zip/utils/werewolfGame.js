const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionFlagsBits,
  PermissionsBitField, UserSelectMenuBuilder,
} = require('discord.js');
const { baseEmbed, successEmbed, errorEmbed } = require('./embeds');
const { t, guildLang } = require('./i18n');
const {
  saveWerewolfSession, getWerewolfSessionByGuild, listWerewolfSessions, deleteWerewolfSession,
} = require('../database/db');

// Bahasa aktif untuk sebuah sesi game (default id).
function gameLang(game) {
  return guildLang({ id: game.guildId });
}

// Nama & deskripsi role terjemahan (ROLE_DEFS tetap dipakai untuk logika team/emoji).
function roleName(lang, role) { return t(lang, `ww.role.${role}.name`); }
function roleDesc(lang, role) { return t(lang, `ww.role.${role}.desc`); }
function teamName(lang, team) { return t(lang, team === 'wolf' ? 'ww.team.wolf' : 'ww.team.village'); }

const games = new Map();
const timers = new Map();
const locks = new Map();

const ROLE_DEFS = {
  werewolf: { name: 'Werewolf', emoji: '🐺', team: 'wolf', description: 'Setiap malam pilih korban. Menang jika jumlah kelompok serigala menyamai warga.' },
  alpha: { name: 'Alpha Wolf', emoji: '🌑', team: 'wolf', description: 'Pemimpin kawanan. Pilihan bunuhmu berbobot 2 suara dan kamu mengetahui sesama serigala.' },
  seer: { name: 'Seer', emoji: '🔮', team: 'village', description: 'Setiap malam selidiki satu pemain untuk mengetahui apakah ia anggota kawanan serigala.' },
  doctor: { name: 'Doctor', emoji: '🩺', team: 'village', description: 'Setiap malam lindungi satu pemain dari serangan kawanan. Kamu boleh melindungi diri.' },
  hunter: { name: 'Hunter', emoji: '🏹', team: 'village', description: 'Saat tereliminasi, kamu mendapat satu kesempatan menembak pemain lain sebelum pergi.' },
  witch: { name: 'Witch', emoji: '🧪', team: 'village', description: 'Memiliki satu ramuan penyembuh dan satu racun. Setiap ramuan hanya dapat dipakai sekali.' },
  guardian: { name: 'Guardian', emoji: '🛡️', team: 'village', description: 'Lindungi pemain dari serangan malam, tetapi tidak boleh diri sendiri atau target yang sama dua malam berturut-turut.' },
  villager: { name: 'Villager', emoji: '🧑‍🌾', team: 'village', description: 'Tidak punya skill malam. Gunakan analisis, diskusi, dan voting untuk menemukan kawanan.' },
};

const ROLE_DECKS = {
  4: ['werewolf', 'seer', 'doctor', 'villager'],
  5: ['werewolf', 'seer', 'doctor', 'hunter', 'villager'],
  6: ['werewolf', 'seer', 'doctor', 'hunter', 'witch', 'villager'],
  7: ['werewolf', 'alpha', 'seer', 'doctor', 'hunter', 'witch', 'villager'],
  8: ['werewolf', 'alpha', 'seer', 'doctor', 'hunter', 'witch', 'guardian', 'villager'],
};

function shuffle(items) {
  const output = [...items];
  for (let i = output.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [output[i], output[j]] = [output[j], output[i]];
  }
  return output;
}

function makeId() {
  return `${Date.now().toString(36).slice(-5)}${Math.random().toString(36).slice(2, 5)}`;
}

function roleDeck(count) {
  if (!ROLE_DECKS[count]) throw new Error('Werewolf membutuhkan 4–8 pemain.');
  return shuffle(ROLE_DECKS[count]);
}

function alivePlayers(game) {
  return game.players.filter(player => player.alive);
}

function determineWinner(game) {
  const alive = alivePlayers(game);
  const wolves = alive.filter(player => ROLE_DEFS[player.role]?.team === 'wolf').length;
  const village = alive.length - wolves;
  if (wolves === 0) return 'village';
  if (wolves >= village) return 'wolf';
  return null;
}

function tally(values, weights = {}) {
  const counts = {};
  for (const [voter, target] of Object.entries(values || {})) {
    if (!target) continue;
    counts[target] = (counts[target] || 0) + (weights[voter] || 1);
  }
  const ordered = Object.entries(counts).sort((a, b) => b[1] - a[1]);
  if (!ordered.length) return { target: null, tied: false, counts };
  const tied = ordered.length > 1 && ordered[0][1] === ordered[1][1];
  return { target: tied ? null : ordered[0][0], tied, counts };
}

function save(game) {
  game.updatedAt = Date.now();
  saveWerewolfSession(game);
}

function clearGameTimer(gameId) {
  const timer = timers.get(gameId);
  if (timer) clearTimeout(timer);
  timers.delete(gameId);
}

function withLock(gameId, fn) {
  const previous = locks.get(gameId) || Promise.resolve();
  const next = previous.catch(() => {}).then(fn);
  locks.set(gameId, next);
  return next.finally(() => {
    if (locks.get(gameId) === next) locks.delete(gameId);
  });
}

function schedule(game, deadline, callback) {
  clearGameTimer(game.id);
  game.phaseEndsAt = deadline;
  save(game);
  const delay = Math.max(1000, Math.min(2147483647, deadline - Date.now()));
  const timer = setTimeout(() => withLock(game.id, async () => {
    const current = games.get(game.id);
    if (!current) return;
    await callback(current);
  }).catch(error => console.error(`[werewolf:${game.id}] timer`, error)), delay);
  timer.unref?.();
  timers.set(game.id, timer);
}

function canControl(interaction, game) {
  return interaction.user.id === game.hostId || interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild);
}

function playerName(game, userId) {
  return game.players.find(player => player.id === userId)?.name || `User ${userId}`;
}

function playerMention(userId) {
  return `<@${userId}>`;
}

function lobbyRows(game, disabled = false) {
  const lang = gameLang(game);
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`ww:join:${game.id}`).setLabel(t(lang, 'ww.btn.join')).setEmoji('➕').setStyle(ButtonStyle.Success).setDisabled(disabled || game.players.length >= 8),
    new ButtonBuilder().setCustomId(`ww:leave:${game.id}`).setLabel(t(lang, 'ww.btn.leave')).setEmoji('➖').setStyle(ButtonStyle.Secondary).setDisabled(disabled),
    new ButtonBuilder().setCustomId(`ww:start:${game.id}`).setLabel(t(lang, 'ww.btn.start')).setEmoji('🐺').setStyle(ButtonStyle.Primary).setDisabled(disabled || game.players.length < 4),
    new ButtonBuilder().setCustomId(`ww:cancel:${game.id}`).setLabel(t(lang, 'ww.btn.cancel')).setEmoji('✖️').setStyle(ButtonStyle.Danger).setDisabled(disabled),
  )];
}

function lobbyEmbed(game) {
  const lang = gameLang(game);
  const list = game.players.map((player, index) => `${index + 1}. ${playerMention(player.id)}${player.id === game.hostId ? ' 👑' : ''}`).join('\n');
  const remaining = Math.max(0, 4 - game.players.length);
  return baseEmbed()
    .setColor(game.players.length >= 4 ? '#22C55E' : '#F59E0B')
    .setTitle(t(lang, 'ww.lobby.title'))
    .setDescription(t(lang, 'ww.lobby.desc'))
    .addFields(
      { name: t(lang, 'ww.lobby.players', { n: game.players.length }), value: list || t(lang, 'ww.lobby.none'), inline: false },
      { name: t(lang, 'ww.lobby.status'), value: remaining ? t(lang, 'ww.lobby.waiting', { n: remaining }) : t(lang, 'ww.lobby.ready'), inline: true },
      { name: t(lang, 'ww.lobby.phase'), value: t(lang, 'ww.status.sec', { n: game.phaseSeconds }), inline: true },
      { name: t(lang, 'ww.lobby.host'), value: playerMention(game.hostId), inline: true },
      { name: t(lang, 'ww.lobby.roles'), value: Object.entries(ROLE_DEFS).map(([key, role]) => `${role.emoji} ${roleName(lang, key)}`).join(' • '), inline: false },
    )
    .setFooter({ text: t(lang, 'ww.lobby.footer', { id: game.id }) });
}

async function updateLobby(game) {
  const channel = await gameClient(game)?.channels.fetch(game.lobbyChannelId).catch(() => null);
  const message = channel ? await channel.messages.fetch(game.lobbyMessageId).catch(() => null) : null;
  if (message) await message.edit({ embeds: [lobbyEmbed(game)], components: lobbyRows(game) }).catch(() => {});
}

let clientRef = null;
function gameClient() { return clientRef; }

function channelOverwrites(guild, allowedIds = [], everyoneCanView = false) {
  const allow = [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.EmbedLinks];
  return [
    { id: guild.roles.everyone.id, allow: everyoneCanView ? [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory] : [], deny: everyoneCanView ? [PermissionFlagsBits.SendMessages] : [PermissionFlagsBits.ViewChannel] },
    { id: guild.members.me.id, allow: [...allow, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ManageMessages] },
    ...allowedIds.map(id => ({ id, allow })),
  ];
}

async function createLobby(interaction, client) {
  clientRef = client;
  const lang = guildLang(interaction);
  const existing = getWerewolfSessionByGuild(interaction.guildId);
  if (existing) {
    const channel = existing.lobbyChannelId || existing.gameChannelId;
    return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.existing', { state: existing.phase === 'ended' ? 'yang sedang dibersihkan' : 'aktif', channel: channel ? `<#${channel}>` : `game ID \`${existing.id}\`` }))], ephemeral: true });
  }
  const required = new PermissionsBitField([
    PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ViewChannel,
    PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageMessages,
  ]);
  if (!interaction.guild.members.me.permissions.has(required)) {
    return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.perm'))], ephemeral: true });
  }

  await interaction.deferReply({ ephemeral: true });
  const game = {
    id: makeId(), guildId: interaction.guildId, hostId: interaction.user.id,
    phase: 'creating', round: 0, phaseSeconds: interaction.options.getInteger('durasi') || 60,
    createdAt: Date.now(), updatedAt: Date.now(), phaseEndsAt: Date.now() + 600000,
    categoryId: null, lobbyChannelId: null, lobbyMessageId: null, gameChannelId: null,
    wolfChannelId: null, channelIds: [], players: [{ id: interaction.user.id, name: interaction.member.displayName, alive: true, role: null, channelId: null }],
    actions: {}, votes: {}, roleState: { witchHealUsed: false, witchPoisonUsed: false, hunterUsed: false },
    pendingHunterId: null, hunterResume: null, announcement: null,
  };

  try {
    const category = await interaction.guild.channels.create({
      name: `🐺・werewolf-${game.id}`,
      type: ChannelType.GuildCategory,
      permissionOverwrites: channelOverwrites(interaction.guild),
      reason: `Werewolf dibuat oleh ${interaction.user.tag}`,
    });
    game.categoryId = category.id;
    games.set(game.id, game);
    save(game);
    const lobby = await interaction.guild.channels.create({
      name: `lobby-${game.id}`,
      type: ChannelType.GuildText, parent: category.id,
      topic: `Kizhoo Werewolf lobby • game:${game.id}`,
      permissionOverwrites: channelOverwrites(interaction.guild, [], true),
      reason: `Werewolf lobby ${game.id}`,
    });
    game.lobbyChannelId = lobby.id;
    game.channelIds.push(lobby.id);
    const message = await lobby.send({ embeds: [lobbyEmbed(game)], components: lobbyRows(game) });
    game.lobbyMessageId = message.id;
    game.phase = 'lobby';
    games.set(game.id, game);
    schedule(game, game.phaseEndsAt, expireLobby);
    return interaction.editReply({ embeds: [successEmbed(t(lang, 'ww.created', { lobby: `${lobby}` }))] });
  } catch (error) {
    console.error('[werewolf create]', error);
    await cleanupGame(game, 'Gagal membuat arena').catch(() => {});
    return interaction.editReply({ embeds: [errorEmbed(`Arena gagal dibuat: ${error.message}`)] });
  }
}

async function expireLobby(game) {
  if (game.phase !== 'lobby') return;
  const channel = await clientRef.channels.fetch(game.lobbyChannelId).catch(() => null);
  if (channel) await channel.send({ embeds: [errorEmbed(t(gameLang(game), 'ww.lobby_expired'))] }).catch(() => {});
  await cleanupGame(game, 'Lobby kedaluwarsa');
}

async function cleanupGame(game, reason = 'Game selesai') {
  clearGameTimer(game.id);
  games.delete(game.id);
  deleteWerewolfSession(game.id);
  const client = clientRef;
  if (!client) return;
  const ids = [...new Set(game.channelIds || [])];
  for (const id of ids.reverse()) {
    const channel = await client.channels.fetch(id).catch(() => null);
    if (channel) await channel.delete(`Werewolf ${game.id}: ${reason}`).catch(() => {});
  }
  const category = await client.channels.fetch(game.categoryId).catch(() => null);
  if (category) await category.delete(`Werewolf ${game.id}: ${reason}`).catch(() => {});
}

function gameControlRow(game) {
  const lang = gameLang(game);
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`ww:status:${game.id}`).setLabel(t(lang, 'ww.btn.status')).setEmoji('📊').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`ww:abort:${game.id}`).setLabel(t(lang, 'ww.btn.abort')).setEmoji('🛑').setStyle(ButtonStyle.Danger),
  )];
}

function roleButtons(game, player) {
  const lang = gameLang(game);
  const make = (action, label, emoji, style = ButtonStyle.Primary, disabled = false) => new ButtonBuilder()
    .setCustomId(`ww:skill:${game.id}:${action}`).setLabel(label).setEmoji(emoji).setStyle(style).setDisabled(disabled);
  if (['werewolf', 'alpha'].includes(player.role)) return [new ActionRowBuilder().addComponents(make('wolf', t(lang, 'ww.btn.wolf'), '🐺', ButtonStyle.Danger))];
  if (player.role === 'seer') return [new ActionRowBuilder().addComponents(make('seer', t(lang, 'ww.btn.seer'), '🔮'))];
  if (player.role === 'doctor') return [new ActionRowBuilder().addComponents(make('doctor', t(lang, 'ww.btn.doctor'), '🩺', ButtonStyle.Success))];
  if (player.role === 'guardian') return [new ActionRowBuilder().addComponents(make('guardian', t(lang, 'ww.btn.guardian'), '🛡️', ButtonStyle.Success))];
  if (player.role === 'witch') return [new ActionRowBuilder().addComponents(
    make('witch-heal', t(lang, 'ww.btn.witch_heal'), '💚', ButtonStyle.Success, game.roleState.witchHealUsed),
    make('witch-poison', t(lang, 'ww.btn.witch_poison'), '☠️', ButtonStyle.Danger, game.roleState.witchPoisonUsed),
  )];
  return [];
}

function roleEmbed(game, player) {
  const lang = gameLang(game);
  const role = ROLE_DEFS[player.role];
  const teammates = game.players.filter(p => p.id !== player.id && ROLE_DEFS[p.role]?.team === 'wolf').map(p => playerMention(p.id));
  return baseEmbed().setColor(role.team === 'wolf' ? '#DC2626' : '#2563EB')
    .setTitle(`${role.emoji} ${t(lang, 'ww.role.title')}: ${roleName(lang, player.role)}`)
    .setDescription(`${roleDesc(lang, player.role)}\n\n**${t(lang, 'ww.role.team_label')}:** ${teamName(lang, role.team)}${teammates.length ? `\n**${t(lang, 'ww.role.wolves')}:** ${teammates.join(', ')}` : ''}`)
    .addFields(
      { name: '🔐 Channel Pribadi', value: t(lang, 'ww.role.private'), inline: false },
      { name: '⚠️ Fair Play', value: t(lang, 'ww.role.fairplay'), inline: false },
    )
    .setFooter({ text: t(lang, 'ww.role.footer', { id: game.id }) });
}

async function startGame(game, interaction) {
  const lang = gameLang(game);
  const verifiedPlayers = [];
  for (const player of game.players) {
    const member = await interaction.guild.members.fetch(player.id).catch(() => null);
    if (member && !member.user.bot) verifiedPlayers.push({ ...player, name: member.displayName });
  }
  game.players = verifiedPlayers;
  if (game.players.length < 4 || game.players.length > 8) throw new Error('Jumlah pemain aktif di server harus 4–8 orang.');
  if (!game.players.some(player => player.id === game.hostId)) game.hostId = game.players[0].id;
  const guild = interaction.guild;
  const roles = roleDeck(game.players.length);
  game.players = shuffle(game.players).map((player, index) => ({ ...player, role: roles[index], alive: true, channelId: null, lastProtected: null }));
  game.phase = 'starting';
  save(game);

  const participantIds = game.players.map(player => player.id);
  const main = await guild.channels.create({
    name: `permainan-${game.id}`, type: ChannelType.GuildText, parent: game.categoryId,
    topic: `Kizhoo Werewolf arena • game:${game.id}`,
    permissionOverwrites: channelOverwrites(guild, participantIds), reason: `Werewolf game ${game.id}`,
  });
  game.gameChannelId = main.id;
  game.channelIds.push(main.id);
  save(game);

  for (let index = 0; index < game.players.length; index++) {
    const player = game.players[index];
    const privateChannel = await guild.channels.create({
      name: `role-${index + 1}-${player.name}`.toLowerCase().replace(/[^a-z0-9-]/g, '-').slice(0, 90),
      type: ChannelType.GuildText, parent: game.categoryId,
      topic: `Kizhoo Werewolf private • game:${game.id} • player:${player.id}`,
      permissionOverwrites: channelOverwrites(guild, [player.id]), reason: `Werewolf private role ${game.id}`,
    });
    player.channelId = privateChannel.id;
    game.channelIds.push(privateChannel.id);
    save(game);
  }

  const wolves = game.players.filter(player => ROLE_DEFS[player.role].team === 'wolf');
  if (wolves.length > 1) {
    const pack = await guild.channels.create({
      name: `wolf-pack-${game.id}`, type: ChannelType.GuildText, parent: game.categoryId,
      topic: `Kizhoo Werewolf pack • game:${game.id}`,
      permissionOverwrites: channelOverwrites(guild, wolves.map(player => player.id)), reason: `Werewolf pack ${game.id}`,
    });
    game.wolfChannelId = pack.id;
    game.channelIds.push(pack.id);
    save(game);
    await pack.send({ embeds: [baseEmbed().setColor('#DC2626').setTitle(t(lang, 'ww.wolfpack.title')).setDescription(t(lang, 'ww.wolfpack.desc', { wolves: wolves.map(player => playerMention(player.id)).join(', ') }))] });
  }

  for (const player of game.players) {
    const channel = await clientRef.channels.fetch(player.channelId);
    await channel.send({ content: playerMention(player.id), embeds: [roleEmbed(game, player)], components: roleButtons(game, player) });
  }

  const lobby = await clientRef.channels.fetch(game.lobbyChannelId).catch(() => null);
  if (lobby) {
    const message = await lobby.messages.fetch(game.lobbyMessageId).catch(() => null);
    if (message) await message.edit({ embeds: [lobbyEmbed(game).setColor('#64748B').setFooter({ text: `Game ${game.id} sudah dimulai` })], components: lobbyRows(game, true) }).catch(() => {});
    await lobby.send({ embeds: [successEmbed(t(lang, 'ww.started', { n: game.players.length }))] }).catch(() => {});
    setTimeout(() => lobby.delete('Werewolf lobby selesai').catch(() => {}), 5000).unref?.();
  }

  await main.send({ embeds: [baseEmbed().setTitle(t(lang, 'ww.start.title')).setDescription(t(lang, 'ww.start.welcome', { players: game.players.map(player => playerMention(player.id)).join(', ') })).addFields(
    { name: t(lang, 'ww.start.rules_title'), value: t(lang, 'ww.start.rules'), inline: false },
    { name: t(lang, 'ww.start.composition'), value: t(lang, 'ww.start.composition_val', { wolves: wolves.length, village: game.players.length - wolves.length }), inline: true },
    { name: t(lang, 'ww.lobby.phase'), value: t(lang, 'ww.status.sec', { n: game.phaseSeconds }), inline: true },
  )], components: gameControlRow(game) });
  save(game);
  await startNight(game);
}

async function setMainChat(game, enabled) {
  const channel = await clientRef.channels.fetch(game.gameChannelId).catch(() => null);
  if (!channel) return;
  await Promise.allSettled(game.players.map(player => channel.permissionOverwrites.edit(player.id, { SendMessages: enabled && player.alive }, { reason: `Werewolf ${game.phase}` })));
}

async function startNight(game) {
  const lang = gameLang(game);
  game.phase = 'night';
  game.round += 1;
  game.actions = {};
  game.votes = {};
  game.announcement = null;
  await setMainChat(game, false);
  const main = await clientRef.channels.fetch(game.gameChannelId).catch(() => null);
  if (main) await main.send({ embeds: [baseEmbed().setColor('#111827').setTitle(t(lang, 'ww.night.title', { round: game.round })).setDescription(t(lang, 'ww.night.desc', { sec: game.phaseSeconds, players: alivePlayers(game).map(p => playerMention(p.id)).join(', ') }))] });
  for (const player of alivePlayers(game)) {
    const channel = await clientRef.channels.fetch(player.channelId).catch(() => null);
    if (!channel) continue;
    const rows = roleButtons(game, player);
    await channel.send({ embeds: [baseEmbed().setColor('#111827').setTitle(t(lang, 'ww.night.title', { round: game.round })).setDescription(rows.length ? t(lang, 'ww.night.skill', { role: roleName(lang, player.role) }) : t(lang, 'ww.night.no_action'))], components: rows }).catch(() => {});
  }
  schedule(game, Date.now() + game.phaseSeconds * 1000, resolveNight);
}

function chooseWolfTarget(game) {
  const votes = {};
  const weights = {};
  for (const player of alivePlayers(game).filter(p => ROLE_DEFS[p.role].team === 'wolf')) {
    const target = game.actions[player.id]?.type === 'wolf' ? game.actions[player.id].targetId : null;
    if (target) {
      votes[player.id] = target;
      weights[player.id] = player.role === 'alpha' ? 2 : 1;
    }
  }
  return tally(votes, weights).target;
}

async function resolveNight(game) {
  if (game.phase !== 'night') return;
  const lang = gameLang(game);
  clearGameTimer(game.id);
  const wolfTarget = chooseWolfTarget(game);
  const protectedIds = new Set();
  let poisonTarget = null;
  for (const player of alivePlayers(game)) {
    const action = game.actions[player.id];
    if (action?.type === 'doctor' || action?.type === 'guardian') protectedIds.add(action.targetId);
    const heal = game.actions[`${player.id}:witch-heal`];
    const poison = game.actions[`${player.id}:witch-poison`];
    if (heal && !game.roleState.witchHealUsed) {
      protectedIds.add(heal.targetId);
      game.roleState.witchHealUsed = true;
    }
    if (poison && !game.roleState.witchPoisonUsed) {
      poisonTarget = poison.targetId;
      game.roleState.witchPoisonUsed = true;
    }
    if (action?.type === 'guardian') player.lastProtected = action.targetId;
  }

  const deaths = [];
  if (wolfTarget && !protectedIds.has(wolfTarget)) deaths.push(wolfTarget);
  if (poisonTarget && !deaths.includes(poisonTarget)) deaths.push(poisonTarget);
  for (const id of deaths) {
    const player = game.players.find(p => p.id === id);
    if (player) player.alive = false;
  }

  game.announcement = deaths.length
    ? t(lang, 'ww.night.deaths', { names: deaths.map(id => `**${playerName(game, id)}**`).join(' dan ') })
    : wolfTarget ? t(lang, 'ww.night.saved') : t(lang, 'ww.night.none');
  save(game);
  if (await beginHunterIfNeeded(game, deaths, 'day')) return;
  if (await finishIfWon(game)) return;
  await beginDay(game);
}

async function beginDay(game) {
  const lang = gameLang(game);
  game.phase = 'day-discussion';
  await setMainChat(game, true);
  const main = await clientRef.channels.fetch(game.gameChannelId).catch(() => null);
  if (main) await main.send({ embeds: [baseEmbed().setColor('#F59E0B').setTitle(t(lang, 'ww.day.title', { round: game.round })).setDescription(t(lang, 'ww.day.desc', { announcement: game.announcement || t(lang, 'ww.day.default_announcement'), sec: game.phaseSeconds, players: alivePlayers(game).map(p => playerMention(p.id)).join(', ') }))] });
  schedule(game, Date.now() + game.phaseSeconds * 1000, beginVote);
}

function voteRow(game) {
  const lang = gameLang(game);
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`ww:vote:${game.id}`).setLabel(t(lang, 'ww.btn.vote')).setEmoji('🗳️').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(`ww:force-vote:${game.id}`).setLabel(t(lang, 'ww.btn.force_vote')).setEmoji('⏩').setStyle(ButtonStyle.Secondary),
  )];
}

async function beginVote(game) {
  if (!['day-discussion', 'day-vote'].includes(game.phase)) return;
  const lang = gameLang(game);
  game.phase = 'day-vote';
  game.votes = {};
  const main = await clientRef.channels.fetch(game.gameChannelId).catch(() => null);
  if (main) await main.send({ embeds: [baseEmbed().setColor('#2563EB').setTitle(t(lang, 'ww.vote.title')).setDescription(t(lang, 'ww.vote.desc', { sec: game.phaseSeconds }))], components: voteRow(game) });
  schedule(game, Date.now() + game.phaseSeconds * 1000, resolveVote);
}

async function resolveVote(game) {
  if (game.phase !== 'day-vote') return;
  const lang = gameLang(game);
  clearGameTimer(game.id);
  const validVotes = {};
  for (const [voter, target] of Object.entries(game.votes || {})) {
    if (game.players.find(p => p.id === voter)?.alive && game.players.find(p => p.id === target)?.alive) validVotes[voter] = target;
  }
  const result = tally(validVotes);
  const main = await clientRef.channels.fetch(game.gameChannelId).catch(() => null);
  if (!result.target) {
    if (main) await main.send({ embeds: [baseEmbed().setColor('#64748B').setTitle(t(lang, 'ww.vote.done')).setDescription(result.tied ? t(lang, 'ww.vote.tied') : t(lang, 'ww.vote.no_votes'))] });
    if (await finishIfWon(game)) return;
    return startNight(game);
  }
  const eliminated = game.players.find(player => player.id === result.target);
  eliminated.alive = false;
  if (main) await main.send({ embeds: [baseEmbed().setColor('#DC2626').setTitle(t(lang, 'ww.vote.result_title')).setDescription(t(lang, 'ww.vote.result_desc', { player: playerMention(eliminated.id), votes: result.counts[eliminated.id], role: `${ROLE_DEFS[eliminated.role].emoji} ${roleName(lang, eliminated.role)}` }))] });
  save(game);
  if (await beginHunterIfNeeded(game, [eliminated.id], 'night')) return;
  if (await finishIfWon(game)) return;
  return startNight(game);
}

async function beginHunterIfNeeded(game, deaths, resume) {
  const lang = gameLang(game);
  const hunter = game.players.find(player => deaths.includes(player.id) && player.role === 'hunter');
  if (!hunter || game.roleState.hunterUsed) return false;
  game.phase = 'hunter-shot';
  game.pendingHunterId = hunter.id;
  game.hunterResume = resume;
  const channel = await clientRef.channels.fetch(hunter.channelId).catch(() => null);
  if (channel) await channel.send({ content: playerMention(hunter.id), embeds: [baseEmbed().setColor('#DC2626').setTitle(t(lang, 'ww.hunter.title')).setDescription(t(lang, 'ww.hunter.desc'))], components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`ww:hunter:${game.id}`).setLabel(t(lang, 'ww.hunter.btn')).setEmoji('🏹').setStyle(ButtonStyle.Danger))] });
  const main = await clientRef.channels.fetch(game.gameChannelId).catch(() => null);
  if (main) await main.send({ embeds: [baseEmbed().setTitle(t(lang, 'ww.hunter.eliminated')).setDescription(t(lang, 'ww.hunter.eliminated_desc'))] });
  schedule(game, Date.now() + 30000, finishHunterPhase);
  return true;
}

async function finishHunterPhase(game) {
  if (game.phase !== 'hunter-shot') return;
  game.roleState.hunterUsed = true;
  const resume = game.hunterResume;
  game.pendingHunterId = null;
  game.hunterResume = null;
  if (await finishIfWon(game)) return;
  if (resume === 'day') return beginDay(game);
  return startNight(game);
}

async function finishIfWon(game) {
  const winner = determineWinner(game);
  if (!winner) return false;
  await endGame(game, winner);
  return true;
}

async function endGame(game, winner) {
  const lang = gameLang(game);
  clearGameTimer(game.id);
  game.phase = 'ended';
  game.phaseEndsAt = Date.now() + 120000;
  const main = await clientRef.channels.fetch(game.gameChannelId).catch(() => null);
  const reveal = game.players.map(player => `${player.alive ? '🟢' : '⚫'} ${playerMention(player.id)} — ${ROLE_DEFS[player.role].emoji} **${roleName(lang, player.role)}**`).join('\n');
  if (main) {
    await setMainChat(game, false);
    await main.send({ embeds: [baseEmbed().setColor(winner === 'wolf' ? '#DC2626' : '#22C55E').setTitle(winner === 'wolf' ? t(lang, 'ww.win.wolf') : t(lang, 'ww.win.village')).setDescription(`${winner === 'wolf' ? t(lang, 'ww.win.wolf_desc') : t(lang, 'ww.win.village_desc')}\n\n**${t(lang, 'ww.win.roles')}**\n${reveal}\n\n${t(lang, 'ww.win.cleanup')}`)], components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`ww:cleanup:${game.id}`).setLabel(t(lang, 'ww.btn.cleanup')).setEmoji('🧹').setStyle(ButtonStyle.Secondary))] });
  }
  save(game);
  schedule(game, game.phaseEndsAt, current => cleanupGame(current, 'Game selesai'));
}

function targetPrompt(game, action, userId) {
  const lang = gameLang(game);
  const titleKey = {
    wolf: 'ww.btn.wolf', seer: 'ww.btn.seer', doctor: 'ww.btn.doctor', guardian: 'ww.btn.guardian',
    'witch-heal': 'ww.btn.witch_heal', 'witch-poison': 'ww.btn.witch_poison', vote: 'ww.btn.vote', hunter: 'ww.btn.hunter',
  }[action] || 'ww.btn.wolf';
  const emoji = { wolf: '🐺', seer: '🔮', doctor: '🩺', guardian: '🛡️', 'witch-heal': '💚', 'witch-poison': '☠️', vote: '🗳️', hunter: '🏹' }[action] || '🎯';
  const title = `${emoji} ${t(lang, titleKey)}`;
  const description = t(lang, action === 'vote' ? 'ww.vote.desc' : 'ww.btn.wolf');
  const select = new UserSelectMenuBuilder().setCustomId(`ww:target:${game.id}:${action}`).setPlaceholder('Pilih satu pemain hidup…').setMinValues(1).setMaxValues(1);
  return { embeds: [baseEmbed().setTitle(title).setDescription(description)], components: [new ActionRowBuilder().addComponents(select)], ephemeral: true };
}

async function handleLobbyButton(interaction, game, action) {
  const lang = guildLang(interaction);
  if (game.phase !== 'lobby') return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.inactive'))], ephemeral: true });
  if (action === 'join') {
    if (interaction.user.bot) return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.bot'))], ephemeral: true });
    if (game.players.some(player => player.id === interaction.user.id)) return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.already'))], ephemeral: true });
    if (game.players.length >= 8) return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.full'))], ephemeral: true });
    game.players.push({ id: interaction.user.id, name: interaction.member.displayName, alive: true, role: null, channelId: null });
    save(game);
    await updateLobby(game);
    return interaction.reply({ embeds: [successEmbed(t(lang, 'ww.joined', { n: game.players.length }))], ephemeral: true });
  }
  if (action === 'leave') {
    const index = game.players.findIndex(player => player.id === interaction.user.id);
    if (index < 0) return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.not_in_lobby'))], ephemeral: true });
    game.players.splice(index, 1);
    if (!game.players.length) {
      await interaction.reply({ embeds: [successEmbed(t(lang, 'ww.lobby_empty'))], ephemeral: true });
      return cleanupGame(game, 'Semua pemain keluar');
    }
    if (game.hostId === interaction.user.id) game.hostId = game.players[0].id;
    save(game);
    await updateLobby(game);
    return interaction.reply({ embeds: [successEmbed(t(lang, 'ww.left'))], ephemeral: true });
  }
  if (action === 'start') {
    if (!canControl(interaction, game)) return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.host_only'))], ephemeral: true });
    if (game.players.length < 4) return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.min_players'))], ephemeral: true });
    await interaction.deferReply({ ephemeral: true });
    try {
      await startGame(game, interaction);
      return interaction.editReply({ embeds: [successEmbed(t(lang, 'ww.started', { n: game.players.length }))] });
    } catch (error) {
      console.error(`[werewolf:${game.id}] start`, error);
      await cleanupGame(game, 'Gagal memulai game');
      return interaction.editReply({ embeds: [errorEmbed(`Game gagal dimulai dan arena dibersihkan: ${error.message}`)] });
    }
  }
  if (action === 'cancel') {
    if (!canControl(interaction, game)) return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.host_only'))], ephemeral: true });
    await interaction.reply({ embeds: [successEmbed(t(lang, 'ww.cancelled'))], ephemeral: true });
    return cleanupGame(game, `Dibatalkan oleh ${interaction.user.tag}`);
  }
}

async function handleButton(interaction, client) {
  clientRef = client;
  const lang = guildLang(interaction);
  const parts = interaction.customId.split(':');
  const action = parts[1];
  const gameId = parts[2];
  const game = games.get(gameId);
  if (!game) return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.session'))], ephemeral: true });
  return withLock(gameId, async () => {
    if (['join', 'leave', 'start', 'cancel'].includes(action)) return handleLobbyButton(interaction, game, action);
    if (action === 'skill') {
      const skill = parts[3];
      const player = game.players.find(p => p.id === interaction.user.id);
      if (!player?.alive) return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.dead'))], ephemeral: true });
      if (game.phase !== 'night') return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.night_only'))], ephemeral: true });
      const allowed = { wolf: ['werewolf', 'alpha'], seer: ['seer'], doctor: ['doctor'], guardian: ['guardian'], 'witch-heal': ['witch'], 'witch-poison': ['witch'] };
      if (!allowed[skill]?.includes(player.role)) return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.no_skill'))], ephemeral: true });
      if (skill === 'seer' && game.actions[player.id]?.type === 'seer') return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.seer_once'))], ephemeral: true });
      if (skill === 'witch-heal' && game.roleState.witchHealUsed) return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.heal_used'))], ephemeral: true });
      if (skill === 'witch-poison' && game.roleState.witchPoisonUsed) return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.poison_used'))], ephemeral: true });
      return interaction.reply(targetPrompt(game, skill, interaction.user.id));
    }
    if (action === 'vote') {
      const player = game.players.find(p => p.id === interaction.user.id);
      if (game.phase !== 'day-vote' || !player?.alive) return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.vote_inactive'))], ephemeral: true });
      return interaction.reply(targetPrompt(game, 'vote', interaction.user.id));
    }
    if (action === 'force-vote') {
      if (!canControl(interaction, game)) return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.force_vote'))], ephemeral: true });
      await interaction.deferReply({ ephemeral: true });
      await resolveVote(game);
      return interaction.editReply({ embeds: [successEmbed(t(lang, 'ww.vote_ended'))] });
    }
    if (action === 'hunter') {
      if (game.phase !== 'hunter-shot' || game.pendingHunterId !== interaction.user.id) return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.hunter_none'))], ephemeral: true });
      return interaction.reply(targetPrompt(game, 'hunter', interaction.user.id));
    }
    if (action === 'status') {
      const player = game.players.find(p => p.id === interaction.user.id);
      if (!player && !interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.not_participant'))], ephemeral: true });
      const remaining = Math.max(0, Math.ceil(((game.phaseEndsAt || Date.now()) - Date.now()) / 1000));
      return interaction.reply({ embeds: [baseEmbed().setTitle(t(lang, 'ww.status.title')).addFields(
        { name: t(lang, 'ww.status.phase'), value: game.phase, inline: true },
        { name: t(lang, 'ww.status.round'), value: String(game.round), inline: true },
        { name: t(lang, 'ww.status.time'), value: t(lang, 'ww.status.sec', { n: remaining }), inline: true },
        { name: t(lang, 'ww.status.alive', { n: alivePlayers(game).length }), value: alivePlayers(game).map(p => playerMention(p.id)).join(', ') || t(lang, 'ww.status.none'), inline: false },
      )], ephemeral: true });
    }
    if (action === 'abort') {
      if (!canControl(interaction, game)) return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.host_only'))], ephemeral: true });
      return interaction.reply({ embeds: [baseEmbed().setColor('#EF4444').setTitle(t(lang, 'ww.abort.title')).setDescription(t(lang, 'ww.abort.desc'))], components: [new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`ww:confirm-abort:${game.id}`).setLabel(t(lang, 'ww.btn.abort_yes')).setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId(`ww:cancel-abort:${game.id}`).setLabel(t(lang, 'ww.btn.back')).setStyle(ButtonStyle.Secondary),
      )], ephemeral: true });
    }
    if (action === 'confirm-abort') {
      if (!canControl(interaction, game)) return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.no_perm'))], ephemeral: true });
      await interaction.update({ embeds: [successEmbed(t(lang, 'ww.stopped'))], components: [] });
      return cleanupGame(game, `Dihentikan oleh ${interaction.user.tag}`);
    }
    if (action === 'cancel-abort') return interaction.update({ embeds: [successEmbed(t(lang, 'ww.resumed'))], components: [] });
    if (action === 'cleanup') {
      if (!canControl(interaction, game)) return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.host_only'))], ephemeral: true });
      await interaction.reply({ embeds: [successEmbed(t(lang, 'ww.cleaning'))], ephemeral: true });
      return cleanupGame(game, `Dibersihkan oleh ${interaction.user.tag}`);
    }
  });
}

async function handleTarget(interaction, client) {
  clientRef = client;
  const lang = guildLang(interaction);
  const [, , gameId, action] = interaction.customId.split(':');
  const game = games.get(gameId);
  if (!game) return interaction.reply({ embeds: [errorEmbed(t(lang, 'ww.err.session_inactive'))], ephemeral: true });
  return withLock(gameId, async () => {
    const actor = game.players.find(player => player.id === interaction.user.id);
    const targetId = interaction.values[0];
    const target = game.players.find(player => player.id === targetId);
    if (!actor || !target?.alive) return interaction.update({ embeds: [errorEmbed(t(lang, 'ww.err.target_invalid'))], components: [] });

    if (action === 'vote') {
      if (game.phase !== 'day-vote' || !actor.alive) return interaction.update({ embeds: [errorEmbed(t(lang, 'ww.err.vote_inactive'))], components: [] });
      if (actor.id === target.id) return interaction.update({ embeds: [errorEmbed(t(lang, 'ww.err.self_vote'))], components: [] });
      game.votes[actor.id] = target.id;
      save(game);
      return interaction.update({ embeds: [successEmbed(t(lang, 'ww.vote_cast', { name: target.name }))], components: [] });
    }

    if (action === 'hunter') {
      if (game.phase !== 'hunter-shot' || game.pendingHunterId !== actor.id || actor.role !== 'hunter' || target.id === actor.id) return interaction.update({ embeds: [errorEmbed(t(lang, 'ww.err.hunter_target'))], components: [] });
      target.alive = false;
      game.roleState.hunterUsed = true;
      const resume = game.hunterResume;
      game.pendingHunterId = null;
      game.hunterResume = null;
      const main = await client.channels.fetch(game.gameChannelId).catch(() => null);
      if (main) await main.send({ embeds: [baseEmbed().setColor('#DC2626').setTitle(t(lang, 'ww.hunter.title')).setDescription(t(lang, 'ww.hunter.shot', { actor: playerMention(actor.id), target: playerMention(target.id), role: `${ROLE_DEFS[target.role].emoji} ${roleName(lang, target.role)}` }))] });
      await interaction.update({ embeds: [successEmbed(`Tembakan mengenai **${target.name}**.`)], components: [] });
      if (await finishIfWon(game)) return;
      if (resume === 'day') return beginDay(game);
      return startNight(game);
    }

    if (game.phase !== 'night' || !actor.alive) return interaction.update({ embeds: [errorEmbed(t(lang, 'ww.err.night_over'))], components: [] });
    const roleAllowed = {
      wolf: ['werewolf', 'alpha'], seer: ['seer'], doctor: ['doctor'], guardian: ['guardian'],
      'witch-heal': ['witch'], 'witch-poison': ['witch'],
    };
    if (!roleAllowed[action]?.includes(actor.role)) return interaction.update({ embeds: [errorEmbed(t(lang, 'ww.err.no_action_role'))], components: [] });
    if (action === 'seer' && game.actions[actor.id]?.type === 'seer') return interaction.update({ embeds: [errorEmbed(t(lang, 'ww.err.seer_once'))], components: [] });
    if (action === 'wolf' && ROLE_DEFS[target.role].team === 'wolf') return interaction.update({ embeds: [errorEmbed(t(lang, 'ww.err.wolf_self'))], components: [] });
    if (action === 'seer' && actor.id === target.id) return interaction.update({ embeds: [errorEmbed(t(lang, 'ww.err.seer_self'))], components: [] });
    if (action === 'guardian' && (actor.id === target.id || actor.lastProtected === target.id)) return interaction.update({ embeds: [errorEmbed(t(lang, 'ww.err.guardian'))], components: [] });
    if (action === 'witch-heal' && game.roleState.witchHealUsed) return interaction.update({ embeds: [errorEmbed(t(lang, 'ww.err.heal_used'))], components: [] });
    if (action === 'witch-poison' && game.roleState.witchPoisonUsed) return interaction.update({ embeds: [errorEmbed(t(lang, 'ww.err.poison_used'))], components: [] });

    const key = action.startsWith('witch-') ? `${actor.id}:${action}` : actor.id;
    game.actions[key] = { type: action, targetId: target.id };
    save(game);
    if (action === 'seer') {
      const isWolf = ROLE_DEFS[target.role].team === 'wolf';
      return interaction.update({ embeds: [baseEmbed().setColor(isWolf ? '#DC2626' : '#22C55E').setTitle(t(lang, 'ww.seer.title')).setDescription(t(lang, 'ww.seer.desc', { name: target.name, result: isWolf ? t(lang, 'ww.seer.wolf') : t(lang, 'ww.seer.village') }))], components: [] });
    }
    return interaction.update({ embeds: [successEmbed(t(lang, 'ww.action_saved', { action, name: target.name }))], components: [] });
  });
}

async function recoverSessions(client) {
  clientRef = client;
  for (const game of listWerewolfSessions()) {
    try {
      const guild = await client.guilds.fetch(game.guildId).catch(() => null);
      const category = guild ? await guild.channels.fetch(game.categoryId).catch(() => null) : null;
      if (!guild || !category) {
        deleteWerewolfSession(game.id);
        continue;
      }
      games.set(game.id, game);
      const delayDeadline = Math.max(Date.now() + 3000, game.phaseEndsAt || Date.now() + 3000);
      const callbacks = {
        creating: current => cleanupGame(current, 'Pembuatan arena terputus saat restart'),
        lobby: expireLobby, starting: current => cleanupGame(current, 'Setup terputus saat restart'),
        night: resolveNight, 'day-discussion': beginVote,
        'day-vote': resolveVote, 'hunter-shot': finishHunterPhase,
        ended: current => cleanupGame(current, 'Game selesai saat restart'),
      };
      const callback = callbacks[game.phase];
      if (callback) schedule(game, delayDeadline, callback);
      console.log(`[Werewolf] Memulihkan game ${game.id} pada fase ${game.phase}.`);
    } catch (error) {
      console.error(`[Werewolf] Gagal memulihkan ${game.id}:`, error.message);
    }
  }
}

module.exports = {
  createLobby, handleButton, handleTarget, recoverSessions, cleanupGame,
  ROLE_DEFS, roleDeck, determineWinner, tally, chooseWolfTarget,
  _games: games,
};
