// Uji battle engine end-to-end + render scene.
process.env.KIZHOO_DB_PATH = '/tmp/kizhoo_battle_test.sqlite';
require('fs').rmSync(process.env.KIZHOO_DB_PATH, { force: true });
const rdb = require('../database/rpgDb');
const engine = require('../utils/rpgEngine');
const battle = require('../utils/rpgBattle');
const { renderBattleScene } = require('../utils/rpgCard');
const fs = require('fs');

const U = 'hero1', G = 'g1';
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) { pass++; console.log('  ✓', m); } else { fail++; console.log('  ✗ FAIL', m); } };

// buat karakter kuat + skill aktif
rdb.createCharacter(U, 'mage');
rdb.updateCharacter(U, { level: 20, skillPoints: 10 });
engine.unlockOrUpgradeSkill(U, 'm_fire');
engine.unlockOrUpgradeSkill(U, 'm_focus');
engine.unlockOrUpgradeSkill(U, 'm_fire'); // upgrade
engine.unlockOrUpgradeSkill(U, 'm_frost');

console.log('1) Start battle vs slime (harusnya menang)');
let r = battle.startBattle(U, G, 'slime');
ok(r.state && r.state.enemy.id === 'slime', 'battle dimulai vs slime');
ok(r.state.player.actives.length >= 2, `punya ${r.state.player.actives.length} skill aktif`);

console.log('2) Simulasi giliran sampai selesai');
let guard = 0;
while (!battle.getBattle(U)?.over && guard++ < 40) {
  const st = battle.getBattle(U);
  if (!st) break;
  // pakai fireball kalau MP cukup, else serang
  const fire = st.player.actives.find(s => s.id === 'm_fire');
  if (fire && st.player.mp >= fire.mp) battle.playerAction(U, 'skill', { skillId: 'm_fire' });
  else battle.playerAction(U, 'attack');
}
const final = battle.getBattle(U);
ok(final && final.over, `battle selesai (result: ${final?.result})`);
ok(final.result === 'win', 'menang lawan slime');
const charAfter = rdb.getCharacter(U);
ok(charAfter.monstersKilled === 1 && charAfter.wins === 1, `counter: kill ${charAfter.monstersKilled}, win ${charAfter.wins}`);
// Gold RPG sudah disatukan ke wallet /economy per-server (bukan kolom lama di karakter).
const walletAfter = rdb.getWallet(U, G);
ok(walletAfter.gold > 0, `dapat gold (wallet): ${walletAfter.gold}`);

console.log('3) Render battle scene (semua background)');
(async () => {
  battle.endBattle(U);
  const r2 = battle.startBattle(U, G, 'dragon');
  const bgs = ['forest','cave','ruins','night','volcano','snow'];
  const { createCanvas } = require('@napi-rs/canvas');
  // render satu scene per bg dan tempel jadi grid 2x3
  const scenes = [];
  for (const bg of bgs) scenes.push(await renderBattleScene(r2.state, { bg }));
  const { loadImage } = require('@napi-rs/canvas');
  const one = await loadImage(scenes[0]);
  const cols = 2, rows = 3;
  const cw = 480, ch = 240;
  const c = createCanvas(cols*cw, rows*ch); const ctx = c.getContext('2d');
  for (let i = 0; i < scenes.length; i++) { const img = await loadImage(scenes[i]); ctx.drawImage(img, (i%cols)*cw, Math.floor(i/cols)*ch, cw, ch); }
  fs.writeFileSync('/tmp/battle_grid.png', c.toBuffer('image/png'));
  fs.writeFileSync('/tmp/battle_single.png', scenes[4]); // volcano vs dragon
  ok(scenes.every(s => s.length > 1000), 'semua 6 background ter-render');
  console.log(`\n==== HASIL: ${pass} lulus, ${fail} gagal ====`);
  process.exit(fail ? 1 : 0);
})();
