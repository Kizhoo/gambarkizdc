const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('dice')
    .setDescription('Lempar dadu')
    .addIntegerOption(o => o.setName('sisi').setDescription('Jumlah sisi dadu (default 6)').setMinValue(2).setMaxValue(1000)),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const sides = interaction.options.getInteger('sisi') || 6;
    const result = Math.floor(Math.random() * sides) + 1;
    return interaction.reply({ embeds: [baseEmbed().setTitle(t(lang, 'dice.title')).setDescription(t(lang, 'dice.result', { s: sides, r: result }))] });
  },
};
