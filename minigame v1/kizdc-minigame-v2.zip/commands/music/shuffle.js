const { SlashCommandBuilder } = require('discord.js');
const { getValidPlayer } = require('../../utils/musicGuard');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder().setName('shuffle').setDescription('Acak urutan antrian musik'),
  async execute(interaction, client) {
    const lang = guildLang(interaction);
    const player = await getValidPlayer(interaction, client);
    if (!player) return;

    if (player.queue.length < 3) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'music.queue_short'))], ephemeral: true });
    }

    if (typeof player.queue.shuffle !== 'function') {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'music.shuffle_unavailable'))], ephemeral: true });
    }

    player.queue.shuffle();
    return interaction.reply({ embeds: [successEmbed(t(lang, 'music.shuffled'))] });
  },
};
