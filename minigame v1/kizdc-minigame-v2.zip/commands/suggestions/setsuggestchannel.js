const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { updateGuildConfig } = require('../../database/db');
const { successEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setsuggestchannel')
    .setDescription('[Admin] Atur channel untuk menampung saran/suggestion')
    .addChannelOption(o => o.setName('channel').setDescription('Channel suggestion').addChannelTypes(ChannelType.GuildText).setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const channel = interaction.options.getChannel('channel');
    updateGuildConfig(interaction.guild.id, { suggestChannelId: channel.id });
    return interaction.reply({ embeds: [successEmbed(t(lang, 'sugg.channel_set', { channel: `${channel}` }))] });
  },
};
