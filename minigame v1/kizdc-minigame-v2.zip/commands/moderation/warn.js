const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { addWarning, getWarnings, clearWarnings } = require('../../database/db');
const { successEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');
const config = require('../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Kelola peringatan member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addSubcommand(sub => sub.setName('add').setDescription('Beri peringatan ke member')
      .addUserOption(o => o.setName('target').setDescription('Member yang akan diwarn').setRequired(true))
      .addStringOption(o => o.setName('alasan').setDescription('Alasan warn').setRequired(true)))
    .addSubcommand(sub => sub.setName('list').setDescription('Lihat daftar peringatan seorang member')
      .addUserOption(o => o.setName('target').setDescription('Member yang ingin dicek').setRequired(true)))
    .addSubcommand(sub => sub.setName('clear').setDescription('Hapus semua peringatan seorang member')
      .addUserOption(o => o.setName('target').setDescription('Member yang akan dihapus peringatannya').setRequired(true))),

  async execute(interaction) {
    const lang = guildLang(interaction);
    const sub = interaction.options.getSubcommand();
    const target = interaction.options.getUser('target');

    if (sub === 'add') {
      const reason = interaction.options.getString('alasan');
      addWarning(interaction.guild.id, target.id, interaction.user.id, reason);
      const total = getWarnings(interaction.guild.id, target.id).length;
      await target.send(t(lang, 'mod.warn_dm', { server: interaction.guild.name, reason, total, reason_label: t(lang, 'mod.reason') })).catch(() => {});
      return interaction.reply({ embeds: [successEmbed(t(lang, 'mod.warn_ok', { user: target.tag, reason, total, reason_label: t(lang, 'mod.reason') }))] });
    }

    if (sub === 'list') {
      const warnings = getWarnings(interaction.guild.id, target.id);
      const embed = new EmbedBuilder()
        .setColor(config.embedColor)
        .setAuthor({ name: t(lang, 'mod.warn_list_author', { user: target.tag }), iconURL: target.displayAvatarURL() })
        .setFooter({ text: config.footer })
        .setTimestamp();

      if (warnings.length === 0) {
        embed.setDescription(t(lang, 'mod.warn_empty'));
      } else {
        embed.setDescription(
          warnings.slice(0, 15).map(w => `**#${w.id}** — <t:${Math.floor(w.timestamp / 1000)}:R>\n${t(lang, 'mod.by')}: <@${w.moderatorId}>\n${t(lang, 'mod.reason')}: ${w.reason}`).join('\n\n')
        );
        embed.setTitle(t(lang, 'mod.warn_total', { n: warnings.length }));
      }
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'clear') {
      const removed = clearWarnings(interaction.guild.id, target.id);
      return interaction.reply({ embeds: [successEmbed(t(lang, 'mod.warn_cleared', { n: removed, user: target.tag }))] });
    }
  },
};
