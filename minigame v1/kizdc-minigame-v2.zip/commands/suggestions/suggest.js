const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getGuildConfig, addSuggestion } = require('../../database/db');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const settings = require('../../utils/settings');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('suggest')
    .setDescription('Kirim saran untuk server ini')
    .addStringOption(o => o.setName('saran').setDescription('Isi saran kamu').setRequired(true)),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const cfg = getGuildConfig(interaction.guild.id);
    const content = interaction.options.getString('saran');

    const targetChannel = cfg.suggestChannelId
      ? interaction.guild.channels.cache.get(cfg.suggestChannelId)
      : interaction.channel;

    if (!targetChannel) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'sugg.not_found'))], ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(settings.get('embedColor', '#2b2d31'))
      .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
      .setTitle(t(lang, 'sugg.title'))
      .setDescription(content)
      .addFields({ name: t(lang, 'sugg.status'), value: t(lang, 'sugg.pending') })
      .setFooter({ text: `User ID: ${interaction.user.id}` })
      .setTimestamp();

    const sent = await targetChannel.send({ embeds: [embed] });
    await sent.react('👍').catch(() => {});
    await sent.react('👎').catch(() => {});

    const id = addSuggestion(interaction.guild.id, interaction.user.id, sent.id, content);

    // Tombol approve/reject untuk admin (customId membawa suggestion id)
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`sug_approve_${id}`).setLabel(t(lang, 'sugg.approve')).setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`sug_reject_${id}`).setLabel(t(lang, 'sugg.reject')).setStyle(ButtonStyle.Danger),
    );
    await sent.edit({ embeds: [embed], components: [row] }).catch(() => {});

    return interaction.reply({ embeds: [successEmbed(t(lang, 'sugg.sent', { channel: `${targetChannel}` }))], ephemeral: true });
  },
};
