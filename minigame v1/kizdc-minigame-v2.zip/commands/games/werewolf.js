const { createLobby } = require('../../utils/werewolfGame');

module.exports = {
  subcommandOf: 'games',
  async execute(interaction, client) {
    return createLobby(interaction, client);
  },
};
