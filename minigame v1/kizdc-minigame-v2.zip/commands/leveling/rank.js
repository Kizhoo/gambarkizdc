const { SlashCommandBuilder, AttachmentBuilder } = require('discord.js');
const { getEconomy, getUserProfile } = require('../../database/db');
const levelEngine = require('../../utils/levelEngine');
const webDb = require('../../database/webDb');
const { baseEmbed } = require('../../utils/embeds');
const { renderRankCard } = require('../../utils/rankCard');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rank')
    .setDescription('Lihat level, XP progress bar, dan kartu rank kamu')
    .addUserOption(o => o.setName('target').setDescription('User yang ingin dicek levelnya')),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const target = interaction.options.getUser('target') || interaction.user;

    // Level terunifikasi (web_users) + saldo /economy per-server.
    const lv = levelEngine.getLevel(target.id);
    const econ = getEconomy(interaction.guild.id, target.id);
    const prof = getUserProfile(target.id) || {};
    const accent = prof.color || '#f2c230';
    const webUser = webDb.getUser(target.id) || {};

    try {
      const member = await interaction.guild.members.fetch(target.id).catch(() => null);
      const png = await renderRankCard({
        user: { username: target.username, displayName: member?.displayName || target.username, avatarURL: target.displayAvatarURL({ extension: 'png', size: 256 }) },
        level: lv.level, xp: lv.xp, needed: lv.needed,
        balance: econ.balance, bank: econ.bank,
        accent, cardBg: webUser.cardBg || null, cardBgUrl: webUser.cardBgUrl || null,
      });
      const file = new AttachmentBuilder(png, { name: 'rank.png' });
      const embed = baseEmbed().setColor(accent).setImage('attachment://rank.png');
      return interaction.reply({ embeds: [embed], files: [file] });
    } catch (e) {
      // Fallback teks (kalau canvas gagal di host).
      const pct = lv.needed === Infinity ? 100 : Math.min(100, Math.floor((lv.xp / (lv.needed || 1)) * 100));
      const len = 15;
      const filled = Math.round((pct / 100) * len);
      const bar = '█'.repeat(filled) + '░'.repeat(len - filled);
      const embed = baseEmbed()
        .setAuthor({ name: `${target.username} — Level ${lv.level}`, iconURL: target.displayAvatarURL() })
        .setColor(accent)
        .setDescription(`${bar}\n**${lv.xp}/${lv.needed === Infinity ? 'MAX' : lv.needed} XP** (${pct}%)\n🪙 ${econ.balance.toLocaleString('id-ID')} KZC • 🏦 ${econ.bank.toLocaleString('id-ID')} KZC`);
      return interaction.reply({ embeds: [embed] });
    }
  },
};
