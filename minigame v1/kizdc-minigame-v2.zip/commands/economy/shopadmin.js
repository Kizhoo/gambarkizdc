const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { addShopItem, removeShopItem } = require('../../database/db');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const kizco = require('../../utils/kizco');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('shopadmin')
    .setDescription('[Admin] Kelola item toko server')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub => sub.setName('add').setDescription('Tambah item ke toko server')
      .addStringOption(o => o.setName('id').setDescription('ID unik item (tanpa spasi)').setRequired(true))
      .addStringOption(o => o.setName('nama').setDescription('Nama item').setRequired(true))
      .addIntegerOption(o => o.setName('harga').setDescription('Harga item').setRequired(true).setMinValue(1))
      .addStringOption(o => o.setName('deskripsi').setDescription('Deskripsi item'))
      .addRoleOption(o => o.setName('role').setDescription('Role yang akan diberikan saat dibeli (opsional)')))
    .addSubcommand(sub => sub.setName('remove').setDescription('Hapus item dari toko server')
      .addStringOption(o => o.setName('id').setDescription('ID item yang akan dihapus').setRequired(true))),

  async execute(interaction) {
    const lang = guildLang(interaction);
    const sub = interaction.options.getSubcommand();

    if (sub === 'add') {
      const itemId = interaction.options.getString('id').replace(/\s+/g, '_').toLowerCase();
      const name = interaction.options.getString('nama');
      const price = interaction.options.getInteger('harga');
      const description = interaction.options.getString('deskripsi') || '';
      const role = interaction.options.getRole('role');

      addShopItem(interaction.guild.id, itemId, name, price, description, role?.id || null);
      return interaction.reply({ embeds: [successEmbed(t(lang, 'shopadmin.add_ok', { item: name, id: itemId, price: kizco.format(price) }))] });
    }

    if (sub === 'remove') {
      const itemId = interaction.options.getString('id').toLowerCase();
      const removed = removeShopItem(interaction.guild.id, itemId);
      if (!removed) return interaction.reply({ embeds: [errorEmbed(t(lang, 'shopadmin.not_found'))], ephemeral: true });
      return interaction.reply({ embeds: [successEmbed(t(lang, 'shopadmin.remove_ok', { id: itemId }))] });
    }
  },
};
