// QA server game: mount rpgServer + static + seed data kaya buat verifikasi visual.
process.env.KIZHOO_DB_PATH = '/tmp/kiz_game_qa.sqlite';
require('fs').rmSync('/tmp/kiz_game_qa.sqlite', { force: true });
const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const rpgDb = require('../database/rpgDb');
const rpgItems = require('../utils/rpgItems');
const { mountRpg } = require('../utils/rpgServer');
const { attachRealtime } = require('../utils/rpgRealtime');

const app = express();
app.use(express.json());
app.use((req, res, next) => { res.setHeader('Cache-Control', 'no-store'); next(); });
app.use(express.static(path.join(__dirname, '..', 'dashboard', 'public')));
const sessions = {};
const auth = (req, res, next) => {
  const sid = String(req.headers.cookie || '').replace(/.*kz_sid=([^;]*).*/, '$1');
  if (sessions[sid]) { req.session = sessions[sid]; return next(); }
  return res.status(401).json({ error: 'belum login' });
};
const client = { guilds: { cache: new Map() }, users: { cache: new Map(), fetch: async () => null } };
client.guilds.cache.set('g1', { id: 'g1' });
client.users.cache.set('42', { id: '42', username: 'PengujaPanah' });
mountRpg(app, { auth, resolveUserId: (req) => (req.session && req.session.userId) || null, client });

const server = http.createServer(app);
// Realtime (presence/chat/lobby) ikut dipasang supaya QA browser mencakup
// jalur WebSocket sungguhan — termasuk status "realtime aktif" di UI.
attachRealtime(server, { client });

server.listen(8791, async () => {
  console.log('QA game server di http://127.0.0.1:8791/rpg');
  // ---- SEED ----
  // createCharacter(userId, className) — HANYA 2 parameter (dulu seed salah
  // kirim 3 argumen sehingga className='g1' dan hero tak pernah dirender).
  const U = '42', G = 'g1';
  rpgDb.createCharacter(U, 'archer');
  // Tandai class sudah dipilih (mirip alur produksi POST /api/rpg/class,
  // yang set appearance.choseClass — tanpa ini classKey=null & hero tak
  // pernah dirender di lobby).
  rpgDb.updateCharacter(U, { appearance: JSON.stringify({ choseClass: 1 }) });
  const char = rpgDb.getCharacter(U);
  rpgDb.updateCharacter(U, { level: 25, xp: 100, gold: 20000, skillPoints: 6, statPoints: 10 });
  rpgDb.addGold(U, G, 60000);
  rpgDb.addGems(U, 5200);
  rpgDb.addPetShards(U, 900);
  // Equipment lengkap: senjata rare + zirah chain + aksesori.
  rpgDb.addItem(U, 'w_recurve_bow', 1);
  rpgDb.addItem(U, 'a_chain', 1);
  rpgDb.addItem(U, 'c_ring', 1);
  rpgDb.equipItem(U, 'w_recurve_bow', 'equipWeapon');
  rpgDb.equipItem(U, 'a_chain', 'equipArmor');
  rpgDb.equipItem(U, 'c_ring', 'equipAccessory');
  // Pet: ember level 12 (siap evolusi), nyx, solara mythic.
  rpgDb.grantPet(U, 'ember');
  for (let i = 0; i < 30; i++) rpgDb.addPetXp(U, 'ember', 9999);
  rpgDb.grantPet(U, 'nyx');
  rpgDb.grantPet(U, 'solara');
  rpgDb.setActivePet(U, 'ember');
  // Skill archer beberapa level.
  rpgDb.setSkillLevel(U, 'ar_aim', 3);
  rpgDb.setSkillLevel(U, 'ar_eye', 2);
  // Material & ramuan.
  for (const m of ['m_slime_jelly', 'm_bone', 'm_wolf_pelt', 'm_goblin_ear']) rpgDb.addItem(U, m, 5);
  rpgDb.addItem(U, 'p_heal_s', 5);
  rpgDb.addItem(U, 'p_mana', 5);
  // Teman + lelang + world boss dgn kontribusi.
  rpgDb.createCharacter('99', 'mage');
  rpgDb.updateCharacter('99', { level: 30, gameName: 'KawanUji', appearance: JSON.stringify({ choseClass: 1 }) });
  rpgDb.addFriend(U, '99');
  rpgDb.addGold('99', G, 30000);
  rpgDb.addItem('99', 'p_heal_m', 4);
  rpgDb.createAuction('99', 'p_heal_m', 2, 180);
  rpgDb.addItem('99', 'w_staff', 1);
  rpgDb.createAuction('99', 'w_staff', 1, 900);
  const wk = rpgDb.weekKeyNow();
  rpgDb.damageWorldBoss(wk, '99', 540000);
  // Hadiah masuk.
  rpgDb.createGift({ fromUserId: '99', toUserId: U, kind: 'gems', gems: 25, message: 'Selamat mencoba!' });
  // Session default.
  sessions['qa'] = { userId: U, username: 'PengujaPanah', avatar: null, guilds: [{ id: 'g1', name: 'QA' }] };
  rpgDb.saveSession('qa', sessions['qa']);
  console.log('SEED OK — buka http://127.0.0.1:8791/rpg dengan cookie kz_sid=qa');
});
