const { SlashCommandBuilder, AttachmentBuilder } = require('discord.js');
const { generateText, generateImage, resolveTextTarget } = require('../../utils/aiProvider');
const { ingestAttachment } = require('../../utils/fileIngest');
const { getAiHistory, addAiMessage, clearAiHistory } = require('../../database/db');
const { baseEmbed, errorEmbed, successEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');
const { safeDefer } = require('../../utils/interactionHelpers');
const { promptView } = require('../../utils/aiChannelHandler');
const settings = require('../../utils/settings');

// Cooldown ringan per user supaya satu orang tidak memborong kuota AI (gratis & terbatas
// dari sisi Cloudflare) buat semua orang di server. Disimpan di memori, cukup untuk kebutuhan
// ini - tidak perlu tabel database terpisah.
const lastUsedAt = new Map(); // userId -> timestamp

function checkCooldown(userId) {
  const seconds = settings.get('ai.cooldownSeconds', 6);
  const last = lastUsedAt.get(userId) || 0;
  const remaining = last + seconds * 1000 - Date.now();
  if (remaining > 0) return Math.ceil(remaining / 1000);
  lastUsedAt.set(userId, Date.now());
  return 0;
}

const SAFE_DESC_LIMIT = 3800; // sisakan ruang di bawah limit 4096 karakter Discord buat catatan pemotongan
const EMBED_FIELD_LIMIT = 1024;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ai')
    .setDescription('Ngobrol dengan AI atau buat gambar pakai AI')
    .addSubcommand(sub => sub.setName('chat').setDescription('Ngobrol dengan AI')
      .addStringOption(o => o.setName('pesan').setDescription('Pesan kamu ke AI').setRequired(true))
      .addStringOption(o => o.setName('model').setDescription('Pilih model AI (opsional)').setAutocomplete(true))
      .addAttachmentOption(o => o.setName('file').setDescription('Lampirkan file buat dibaca AI (teks/kode, atau .zip)')))
    .addSubcommand(sub => sub.setName('imagine').setDescription('Buat gambar dari deskripsi teks')
      .addStringOption(o => o.setName('deskripsi').setDescription('Deskripsi gambar yang ingin dibuat').setRequired(true)))
    .addSubcommand(sub => sub.setName('reset').setDescription('Hapus riwayat obrolan AI kamu (tersimpan di database)'))
    .addSubcommand(sub => sub.setName('models').setDescription('Lihat daftar model AI yang tersedia'))
    .addSubcommand(sub => sub.setName('channel').setDescription('Buat channel privat buat ngobrol AI - ketik langsung tanpa command')),

  async autocomplete(interaction) {
    const focused = interaction.options.getFocused().toLowerCase();
    const ai = settings.get('ai', {});
    const all = [];
    for (const [prov, list] of Object.entries(ai.models || {})) {
      for (const m of list) all.push({ name: `[${prov}] ${m}`, value: `${prov}:${m}` });
    }
    const filtered = all.filter(c => c.name.toLowerCase().includes(focused)).slice(0, 25);
    await interaction.respond(filtered);
  },

  async execute(interaction) {
    const lang = guildLang(interaction);
    const sub = interaction.options.getSubcommand();

    if (sub === 'models') {
      const ai = settings.get('ai', {});
      const activeModel = ai.premiumEnabled ? ai.premiumModel : ai.model;
      const embed = baseEmbed().setTitle(t(lang, 'ai.models_title'));
      for (const [prov, list] of Object.entries(ai.models || {})) {
        embed.addFields({
          name: prov.toUpperCase(),
          value: list.map(m => (m === activeModel ? `**\`${m}\`** — ${t(lang, 'ai.active_now')}` : `\`${m}\``)).join('\n') || '-',
        });
      }
      embed.setFooter({ text: t(lang, 'ai.mode', { mode: ai.premiumEnabled ? 'Premium' : 'Standar' }) });
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === 'channel') {
      return interaction.reply(promptView(interaction));
    }

    if (sub === 'reset') {
      clearAiHistory(interaction.user.id);
      return interaction.reply({ embeds: [successEmbed(t(lang, 'ai.reset_ok'))], ephemeral: true });
    }

    if (sub === 'chat') {
      const remaining = checkCooldown(interaction.user.id);
      if (remaining > 0) {
        return interaction.reply({ embeds: [errorEmbed(t(lang, 'ai.cooldown_chat', { sec: remaining }))], ephemeral: true });
      }

      const message = interaction.options.getString('pesan');
      const modelOpt = interaction.options.getString('model'); // "provider:model" atau null
      const attachment = interaction.options.getAttachment('file');
      if (!(await safeDefer(interaction))) return;

      let override = {};
      if (modelOpt && modelOpt.includes(':')) {
        const [provider, ...rest] = modelOpt.split(':');
        override = { provider, model: rest.join(':') };
      }

      // Baca lampiran dulu (kalau ada) sebelum manggil AI, supaya kalau gagal kita tidak
      // buang-buang panggilan API buat sesuatu yang toh bakal error.
      let fileInfo = null;
      if (attachment) {
        try {
          fileInfo = await ingestAttachment(attachment);
          if (fileInfo.kind === 'unsupported') {
            return interaction.editReply({ embeds: [errorEmbed(fileInfo.reason)] }).catch(() => {});
          }
        } catch (err) {
          return interaction.editReply({ embeds: [errorEmbed(t(lang, 'ai.read_fail', { err: err.message }))] }).catch(() => {});
        }
      }

      try {
        const maxHistory = settings.get('ai.maxHistory', 12);
        const history = getAiHistory(interaction.user.id, maxHistory);
        const userContent = fileInfo
          ? `${message}\n\n[Lampiran: ${fileInfo.name}]\n${fileInfo.contextText}`
          : message;
        const messages = [
          { role: 'system', content: settings.get('ai.systemPrompt', 'Kamu asisten AI ramah.') },
          ...history,
          { role: 'user', content: userContent },
        ];

        const response = await generateText(messages, override);

        // Yang disimpan ke riwayat cukup pesan aslinya (bukan seluruh isi file) supaya
        // history tidak cepat penuh dan boros token di obrolan berikutnya.
        addAiMessage(interaction.user.id, 'user', fileInfo ? `${message} [lampiran: ${fileInfo.name}]` : message);
        addAiMessage(interaction.user.id, 'assistant', response);

        const { provider, model } = resolveTextTarget(override);
        const embed = baseEmbed()
          .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL() })
          .setFooter({ text: t(lang, 'ai.footer', { model: `${provider}/${model}` }) });

        const files = [];
        if (response.length > SAFE_DESC_LIMIT) {
          files.push(new AttachmentBuilder(Buffer.from(response, 'utf8'), { name: 'jawaban-ai.txt' }));
          embed.setDescription(`${response.slice(0, SAFE_DESC_LIMIT)}...\n\n*Jawaban lengkap dilampirkan sebagai file karena terlalu panjang buat ditampilkan langsung (${response.length} karakter).*`);
        } else {
          embed.setDescription(response || t(lang, 'ai.no_reply'));
        }

        if (fileInfo?.kind === 'zip') {
          const treeLines = fileInfo.treePreview.join('\n') + (fileInfo.treeOverflow > 0 ? `\n... dan ${fileInfo.treeOverflow} entri lain (tidak ditampilkan)` : '');
          const skippedNote = fileInfo.skipped.length ? `\nDilewati: ${fileInfo.skipped.length} entri (biner/tipe tidak didukung/kena limit ukuran)` : '';
          embed.addFields({
            name: `Lampiran: ${fileInfo.name} (${fileInfo.entryCount} entri)`,
            value: `${treeLines}${skippedNote}\nDibaca sebagai konteks: ${fileInfo.readFiles.length} file`.slice(0, EMBED_FIELD_LIMIT),
          });
        } else if (fileInfo?.kind === 'text') {
          embed.addFields({
            name: `Lampiran: ${fileInfo.name}`,
            value: fileInfo.truncated ? 'Dibaca sebagai konteks (isi dipotong karena panjang).' : 'Dibaca penuh sebagai konteks.',
          });
        }

        return interaction.editReply({ embeds: [embed], files });
      } catch (err) {
        console.error('[ai chat] Gagal:', err.message);
        return interaction.editReply({ embeds: [errorEmbed(t(lang, 'ai.response_fail', { err: err.message }))] }).catch(() => {});
      }
    }

    if (sub === 'imagine') {
      const remaining = checkCooldown(interaction.user.id);
      if (remaining > 0) {
        return interaction.reply({ embeds: [errorEmbed(t(lang, 'ai.cooldown_img', { sec: remaining }))], ephemeral: true });
      }

      const prompt = interaction.options.getString('deskripsi');
      if (!(await safeDefer(interaction))) return;

      try {
        const imageBuffer = await generateImage(prompt);
        const attachment = new AttachmentBuilder(imageBuffer, { name: 'ai-image.png' });
        const embed = baseEmbed()
          .setTitle(t(lang, 'ai.img_title'))
          .setDescription(t(lang, 'ai.img_prompt', { prompt }))
          .setImage('attachment://ai-image.png')
          .setFooter({ text: t(lang, 'ai.img_by', { user: interaction.user.username }) });
        return interaction.editReply({ embeds: [embed], files: [attachment] });
      } catch (err) {
        console.error('[ai imagine] Gagal:', err.message);
        return interaction.editReply({ embeds: [errorEmbed(t(lang, 'ai.img_fail', { err: err.message }))] }).catch(() => {});
      }
    }
  },
};
