const { getReactionRole } = require('../database/db');
const { reactionKey } = require('../utils/emojiUtil');

module.exports = {
  name: 'messageReactionRemove',
  async execute(reaction, user) {
    if (user.bot) return;

    try {
      if (reaction.partial) await reaction.fetch();
      if (reaction.message.partial) await reaction.message.fetch();
    } catch (err) {
      return;
    }

    const message = reaction.message;
    if (!message.guild) return;

    const key = reactionKey(reaction);
    const mapping = getReactionRole(message.guild.id, message.id, key);
    if (mapping) {
      const member = await message.guild.members.fetch(user.id).catch(() => null);
      const role = message.guild.roles.cache.get(mapping.roleId);
      if (member && role) {
        member.roles.remove(role).catch(() => {});
      }
    }
  },
};
