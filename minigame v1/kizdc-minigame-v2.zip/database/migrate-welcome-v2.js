// ============================================================================
// MIGRASI WELCOME/GOODBYE v2 — tambah kolom warna & gaya goodbye
// ----------------------------------------------------------------------------
// Jalankan SEKALI (idempotent, aman dijalankan ulang) untuk menambah kolom:
//   - welcomeColor  TEXT  (warna border kartu welcome, default 'green')
//   - goodbyeStyle  TEXT  ('embed' | 'card')
//   - goodbyeColor  TEXT  (warna border kartu goodbye, default ikut welcomeColor)
//
// Cara pakai:
//   node database/migrate-welcome-v2.js
// ============================================================================
const Database = require('better-sqlite3');
const path = require('path');

const DB_PATH = process.env.KIZHOO_DB_PATH
  ? path.resolve(process.env.KIZHOO_DB_PATH)
  : path.join(__dirname, 'kizhoobot.sqlite');

const db = new Database(DB_PATH);
db.pragma('busy_timeout = 5000');

function ensureColumn(table, column, definition) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all().map(c => c.name);
  if (!cols.includes(column)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
    console.log(`✅ Tambah kolom ${table}.${column} (${definition})`);
  } else {
    console.log(`⏭️  Kolom ${table}.${column} sudah ada, dilewati.`);
  }
}

ensureColumn('guild_config', 'welcomeColor', "TEXT DEFAULT 'green'");
ensureColumn('guild_config', 'goodbyeStyle', "TEXT DEFAULT 'embed'");
ensureColumn('guild_config', 'goodbyeColor', 'TEXT');

console.log('\n✨ Migrasi selesai.');
db.close();
