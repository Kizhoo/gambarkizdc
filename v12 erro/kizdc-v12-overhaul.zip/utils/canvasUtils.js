// ============================================================================
// HELPER CANVAS BERSAMA — dipakai welcomeCard.js & nowPlayingCard.js (yang baru butuh
// gambar background/cover-fit/blur). profileCard.js/rpgCard.js/chessCard.js SENGAJA tidak
// disentuh/dipindah ke sini biar tidak ada risiko fitur lama yang sudah stabil ikut berubah.
// ============================================================================
const { createCanvas, loadImage } = require('@napi-rs/canvas');
const { fetchExternal } = require('./httpClient');

function roundedRect(ctx, x, y, w, h, r) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + w, y, x + w, y + h, radius);
  ctx.arcTo(x + w, y + h, x, y + h, radius);
  ctx.arcTo(x, y + h, x, y, radius);
  ctx.arcTo(x, y, x + w, y, radius);
  ctx.closePath();
}

function fitText(ctx, text, maxWidth, startSize, weight = 700, minSize = 14) {
  let size = startSize;
  do {
    ctx.font = `${weight} ${size}px sans-serif`;
    if (ctx.measureText(text).width <= maxWidth) break;
    size -= 2;
  } while (size > minSize);
  return size;
}

function clippedText(ctx, text, maxWidth) {
  let value = String(text || '—');
  if (ctx.measureText(value).width <= maxWidth) return value;
  while (value.length > 1 && ctx.measureText(`${value}…`).width > maxWidth) value = value.slice(0, -1);
  return `${value}…`;
}

// "background-size: cover" manual — gambar apa pun rasio & resolusi aslinya (termasuk di atas
// 1080p/4K, wajar buat foto HP jaman sekarang) dipotong-tengah lalu diskalakan biar PAS nutupin
// kotak target tanpa gepeng/terdistorsi. Ini yang bikin background custom dari admin server selalu
// rapi berapa pun ukuran file yang mereka upload - tidak perlu mereka crop manual dulu.
function drawImageCover(ctx, img, x, y, w, h) {
  const imgRatio = img.width / img.height;
  const boxRatio = w / h;
  let sx, sy, sw, sh;
  if (imgRatio > boxRatio) {
    sh = img.height;
    sw = sh * boxRatio;
    sx = (img.width - sw) / 2;
    sy = 0;
  } else {
    sw = img.width;
    sh = sw / boxRatio;
    sx = 0;
    sy = (img.height - sh) / 2;
  }
  ctx.drawImage(img, sx, sy, sw, sh, x, y, w, h);
}

// Blur ala "poor man's" — versi @napi-rs/canvas yang dipakai project ini TIDAK dijamin dukung
// ctx.filter (baru stabil di build skia yang lebih baru), jadi daripada gambling pakai API yang
// belum tentu ada di semua environment deploy (Pterodactyl/Docker beda-beda versi), blur
// disimulasikan: gambar digambar ke canvas kecil dulu (detail halus otomatis hilang karena
// downscale) lalu digambar ulang membesar ke canvas asli. Hasilnya "buram" tanpa dependensi
// tambahan & pasti jalan di semua versi.
function drawBlurredCover(ctx, img, x, y, w, h, quality = 20) {
  const small = createCanvas(Math.max(1, Math.round(w / quality)), Math.max(1, Math.round(h / quality)));
  const sctx = small.getContext('2d');
  drawImageCover(sctx, img, 0, 0, small.width, small.height);
  ctx.drawImage(small, x, y, w, h);
}

async function downloadImage(url) {
  const response = await fetchExternal(url, {}, 1);
  if (!response.ok) throw new Error(`Gagal memuat gambar (${response.status})`);
  return loadImage(Buffer.from(await response.arrayBuffer()));
}

module.exports = { roundedRect, fitText, clippedText, drawImageCover, drawBlurredCover, downloadImage };
