// ============================================================================
// NOTIFIKASI OWNER — registrasi user baru & bot ditambahkan ke server baru
// ----------------------------------------------------------------------------
// Semua notifikasi dikirim ke SATU channel (server owner) yang diatur lewat
// /panel → "Notifikasi Owner" (khusus owner). Kombinasi CANVAS (kartu gambar)
// + EMBED (teks detail). Config tersimpan di config.json "ownerNotifications".
// ============================================================================
const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { createCanvas } = require('@napi-rs/canvas');
const { roundedRect, fitText, clippedText, drawImageCover, downloadImage } = require('./canvasUtils');
const settings = require('./settings');

function getConfig() {
  return settings.get('ownerNotifications', {});
}

async function getNotifyChannel(client) {
  const cfg = getConfig();
  if (cfg.enabled === false || !cfg.channelId) return null;
  return client.channels.fetch(cfg.channelId).catch(() => null);
}

// ============================================================================
// KARTU CANVAS (horizontal, profesional)
// ============================================================================
const CARD_W = 800;
const CARD_H = 220;
const IMG = 140;
const IMG_X = 34;
const IMG_Y = 40;

async function renderNotifyCard({ kicker, title, subtitle, footer, imageUrl, accent }) {
  const canvas = createCanvas(CARD_W, CARD_H);
  const ctx = canvas.getContext('2d');

  // background gradient gelap
  const grad = ctx.createLinearGradient(0, 0, CARD_W, CARD_H);
  grad.addColorStop(0, '#0B0F1A');
  grad.addColorStop(1, '#151B2C');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, CARD_W, CARD_H);

  // glow aksen di pojok kanan atas
  ctx.globalAlpha = 0.15;
  ctx.fillStyle = accent;
  ctx.beginPath(); ctx.arc(CARD_W - 40, -20, 220, 0, Math.PI * 2); ctx.fill();
  ctx.globalAlpha = 1;

  // strip aksen kiri
  ctx.fillStyle = accent;
  roundedRect(ctx, 0, 0, 6, CARD_H, 3);
  ctx.fill();

  // gambar (avatar / icon server)
  let img = null;
  if (imageUrl) img = await downloadImage(imageUrl).catch(() => null);
  if (img) {
    const glow = ctx.createRadialGradient(IMG_X + IMG / 2, IMG_Y + IMG / 2, IMG * 0.3, IMG_X + IMG / 2, IMG_Y + IMG / 2, IMG * 0.9);
    glow.addColorStop(0, `${accent}50`);
    glow.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = glow;
    ctx.fillRect(IMG_X - 30, IMG_Y - 30, IMG + 60, IMG + 60);

    ctx.save();
    roundedRect(ctx, IMG_X, IMG_Y, IMG, IMG, 18); ctx.clip();
    drawImageCover(ctx, img, IMG_X, IMG_Y, IMG, IMG);
    ctx.restore();
  } else {
    ctx.fillStyle = '#1E293B';
    roundedRect(ctx, IMG_X, IMG_Y, IMG, IMG, 18); ctx.fill();
    ctx.fillStyle = '#5A5D63';
    ctx.font = '700 48px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('•', IMG_X + IMG / 2, IMG_Y + IMG / 2 + 16);
    ctx.textAlign = 'left';
  }
  ctx.strokeStyle = accent; ctx.lineWidth = 3;
  roundedRect(ctx, IMG_X, IMG_Y, IMG, IMG, 18); ctx.stroke();

  // teks
  const CX = IMG_X + IMG + 34;
  const CW = CARD_W - CX - 30;

  ctx.fillStyle = accent;
  ctx.font = '800 18px sans-serif';
  ctx.fillText(String(kicker).toUpperCase(), CX, 66);

  const titleSize = fitText(ctx, title, CW, 34, 800, 18);
  ctx.font = `800 ${titleSize}px sans-serif`;
  ctx.fillStyle = '#F8FAFC';
  ctx.fillText(clippedText(ctx, title, CW), CX, 108);

  ctx.font = '500 20px sans-serif';
  ctx.fillStyle = '#CBD5E1';
  ctx.fillText(clippedText(ctx, subtitle, CW), CX, 140);

  ctx.strokeStyle = 'rgba(255,255,255,0.12)'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(CX, 172); ctx.lineTo(CARD_W - 30, 172); ctx.stroke();

  ctx.font = '500 16px sans-serif';
  ctx.fillStyle = '#94A3B8';
  ctx.fillText(clippedText(ctx, footer, CW), CX, 198);

  return canvas.toBuffer('image/png');
}

// ============================================================================
// NOTIFIKASI: REGISTRASI USER BARU
// ============================================================================
async function sendRegisterNotification(client, { user, guild, age }) {
  const channel = await getNotifyChannel(client);
  if (!channel) return;
  if (getConfig().notifyRegister === false) return;

  const accent = '#57F287';
  const now = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Makassar' });

  const card = await renderNotifyCard({
    kicker: 'Pendaftaran Baru',
    title: user.username,
    subtitle: `Umur ${age} tahun  •  Server: ${guild.name}`,
    footer: `ID ${user.id}  •  ${now}`,
    imageUrl: user.displayAvatarURL({ extension: 'png', size: 256 }),
    accent,
  }).catch(() => null);

  const embed = new EmbedBuilder()
    .setColor(accent)
    .setTitle('Pendaftaran User Baru')
    .addFields(
      { name: 'User', value: `<@${user.id}> (\`${user.username}\`)`, inline: true },
      { name: 'Umur', value: `${age} tahun`, inline: true },
      { name: 'Server', value: `${guild.name} (\`${guild.id}\`)`, inline: false },
      { name: 'User ID', value: `\`${user.id}\``, inline: true },
      { name: 'Member server', value: `${guild.memberCount}`, inline: true },
    )
    .setTimestamp();

  const payload = { embeds: [embed] };
  if (card) {
    const file = new AttachmentBuilder(card, { name: 'register.png' });
    embed.setImage('attachment://register.png');
    payload.files = [file];
  }
  return channel.send(payload).catch(() => {});
}

// ============================================================================
// NOTIFIKASI: BOT DITAMBAHKAN KE SERVER BARU
// ============================================================================
async function sendGuildJoinNotification(client, guild) {
  const channel = await getNotifyChannel(client);
  if (!channel) return;
  if (getConfig().notifyGuildJoin === false) return;

  const accent = '#5865F2';
  const now = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Makassar' });

  let owner;
  try { owner = await guild.fetchOwner().catch(() => null); } catch { owner = null; }

  const card = await renderNotifyCard({
    kicker: 'Bot Ditambahkan ke Server Baru',
    title: guild.name,
    subtitle: `Member ${guild.memberCount}  •  Owner: ${owner?.user?.username || 'tidak diketahui'}`,
    footer: `ID ${guild.id}  •  ${now}`,
    imageUrl: guild.iconURL({ extension: 'png', size: 256 }),
    accent,
  }).catch(() => null);

  const embed = new EmbedBuilder()
    .setColor(accent)
    .setTitle('Bot Ditambahkan ke Server Baru')
    .setThumbnail(guild.iconURL({ size: 256 }) || null)
    .addFields(
      { name: 'Server', value: `${guild.name} (\`${guild.id}\`)`, inline: false },
      { name: 'Member', value: `${guild.memberCount}`, inline: true },
      { name: 'Owner', value: `${owner?.user?.tag || 'tidak diketahui'}`, inline: true },
      { name: 'Dibuat', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:R>`, inline: true },
    )
    .setTimestamp();

  const payload = { embeds: [embed] };
  if (card) {
    const file = new AttachmentBuilder(card, { name: 'guildjoin.png' });
    embed.setImage('attachment://guildjoin.png');
    payload.files = [file];
  }
  return channel.send(payload).catch(() => {});
}

module.exports = { sendRegisterNotification, sendGuildJoinNotification, renderNotifyCard, getConfig };
