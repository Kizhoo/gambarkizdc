const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('slowmode')
    .setDescription('Atur slowmode channel ini')
    .addIntegerOption(o => o.setName('detik').setDescription('Durasi slowmode dalam detik (0 = matikan)').setRequired(true).setMinValue(0).setMaxValue(21600))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const seconds = interaction.options.getInteger('detik');
    await interaction.channel.setRateLimitPerUser(seconds);

    if (seconds === 0) {
      return interaction.reply({ embeds: [successEmbed(t(lang, 'mod.slowmode_off'))] });
    }
    return interaction.reply({ embeds: [successEmbed(t(lang, 'mod.slowmode_on', { sec: seconds }))] });
  },
};
