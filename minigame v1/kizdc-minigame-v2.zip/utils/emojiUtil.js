function parseEmojiKey(emojiInput) {
  const customMatch = emojiInput.match(/<a?:\w+:(\d+)>/);
  if (customMatch) return customMatch[1]; // pakai ID untuk custom emoji
  return emojiInput.trim(); // unicode emoji apa adanya
}

function reactionKey(reaction) {
  return reaction.emoji.id || reaction.emoji.name;
}

module.exports = { parseEmojiKey, reactionKey };
