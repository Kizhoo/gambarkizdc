const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embeds');
const { getMarriage } = require('../../database/db');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  subcommandOf: true,
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('Lihat informasi seorang user')
    .addUserOption(o => o.setName('target').setDescription('User yang ingin dilihat')),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const user = interaction.options.getUser('target') || interaction.user;
    const member = interaction.guild.members.cache.get(user.id);

    const embed = baseEmbed()
      .setAuthor({ name: user.tag, iconURL: user.displayAvatarURL() })
      .setThumbnail(user.displayAvatarURL({ dynamic: true, size: 256 }))
      .addFields(
        { name: 'ID', value: user.id, inline: true },
        { name: 'Bot?', value: user.bot ? t(lang, 'common.yes') : t(lang, 'common.no'), inline: true },
        { name: t(lang, 'info.account_created'), value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`, inline: false },
      );

    if (member) {
      embed.addFields(
        { name: t(lang, 'info.joined'), value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`, inline: false },
        { name: `${t(lang, 'info.roles')} (${member.roles.cache.size - 1})`, value: member.roles.cache.filter(r => r.id !== interaction.guild.id).map(r => `${r}`).join(' ') || t(lang, 'info.none') },
      );
    }

    const marriage = getMarriage(interaction.guild.id, user.id);
    if (marriage) {
      embed.addFields({ name: t(lang, 'info.marriage_status'), value: t(lang, 'info.married', { p: `<@${marriage.partnerId}>`, ts: Math.floor(marriage.marriedAt / 1000) }) });
    }

    return interaction.reply({ embeds: [embed] });
  },
};
