const Database = require('better-sqlite3');
const path = require('path');

const DB_PATH = process.env.KIZHOO_DB_PATH
  ? path.resolve(process.env.KIZHOO_DB_PATH)
  : path.join(__dirname, 'kizhoobot.sqlite');
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('synchronous = NORMAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');

// ================== SCHEMA ==================
db.exec(`
CREATE TABLE IF NOT EXISTS guild_config (
  guildId TEXT PRIMARY KEY,
  welcomeChannel TEXT,
  welcomeMessage TEXT,
  welcomeEnabled INTEGER DEFAULT 1,
  goodbyeChannel TEXT,
  goodbyeMessage TEXT,
  goodbyeEnabled INTEGER DEFAULT 1,
  autoroleId TEXT,
  logChannel TEXT,
  levelUpChannel TEXT,
  automodEnabled INTEGER DEFAULT 0,
  antiLinkEnabled INTEGER DEFAULT 0,
  antiSpamEnabled INTEGER DEFAULT 0,
  ticketCategoryId TEXT,
  ticketLogChannel TEXT,
  ticketCounter INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS levels (
  guildId TEXT NOT NULL,
  userId TEXT NOT NULL,
  xp INTEGER DEFAULT 0,
  level INTEGER DEFAULT 0,
  lastXpTimestamp INTEGER DEFAULT 0,
  PRIMARY KEY (guildId, userId)
);

CREATE TABLE IF NOT EXISTS economy (
  guildId TEXT NOT NULL,
  userId TEXT NOT NULL,
  balance INTEGER DEFAULT 0,
  bank INTEGER DEFAULT 0,
  lastDaily INTEGER DEFAULT 0,
  lastWork INTEGER DEFAULT 0,
  lastRob INTEGER DEFAULT 0,
  PRIMARY KEY (guildId, userId)
);

CREATE TABLE IF NOT EXISTS warnings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT NOT NULL,
  userId TEXT NOT NULL,
  moderatorId TEXT NOT NULL,
  reason TEXT,
  timestamp INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS banned_words (
  guildId TEXT NOT NULL,
  word TEXT NOT NULL,
  PRIMARY KEY (guildId, word)
);

CREATE TABLE IF NOT EXISTS giveaways (
  messageId TEXT PRIMARY KEY,
  guildId TEXT NOT NULL,
  channelId TEXT NOT NULL,
  prize TEXT NOT NULL,
  winnerCount INTEGER NOT NULL,
  endTime INTEGER NOT NULL,
  hostId TEXT NOT NULL,
  ended INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS shop_items (
  guildId TEXT NOT NULL,
  itemId TEXT NOT NULL,
  name TEXT NOT NULL,
  price INTEGER NOT NULL,
  description TEXT,
  roleId TEXT,
  PRIMARY KEY (guildId, itemId)
);

CREATE TABLE IF NOT EXISTS inventory (
  guildId TEXT NOT NULL,
  userId TEXT NOT NULL,
  itemId TEXT NOT NULL,
  quantity INTEGER DEFAULT 1,
  PRIMARY KEY (guildId, userId, itemId)
);

CREATE TABLE IF NOT EXISTS reminders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  userId TEXT NOT NULL,
  channelId TEXT NOT NULL,
  guildId TEXT,
  message TEXT,
  remindAt INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS afk (
  guildId TEXT NOT NULL,
  userId TEXT NOT NULL,
  reason TEXT,
  timestamp INTEGER NOT NULL,
  PRIMARY KEY (guildId, userId)
);

CREATE TABLE IF NOT EXISTS reaction_roles (
  guildId TEXT NOT NULL,
  messageId TEXT NOT NULL,
  emoji TEXT NOT NULL,
  roleId TEXT NOT NULL,
  PRIMARY KEY (guildId, messageId, emoji)
);

CREATE TABLE IF NOT EXISTS starboard_posts (
  guildId TEXT NOT NULL,
  originalMessageId TEXT NOT NULL,
  starboardMessageId TEXT NOT NULL,
  PRIMARY KEY (guildId, originalMessageId)
);

CREATE TABLE IF NOT EXISTS suggestions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT NOT NULL,
  userId TEXT NOT NULL,
  messageId TEXT,
  content TEXT NOT NULL,
  status TEXT DEFAULT 'pending',
  timestamp INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS birthdays (
  guildId TEXT NOT NULL,
  userId TEXT NOT NULL,
  day INTEGER NOT NULL,
  month INTEGER NOT NULL,
  lastAnnouncedYear INTEGER DEFAULT 0,
  PRIMARY KEY (guildId, userId)
);

CREATE TABLE IF NOT EXISTS level_rewards (
  guildId TEXT NOT NULL,
  level INTEGER NOT NULL,
  roleId TEXT NOT NULL,
  PRIMARY KEY (guildId, level)
);

CREATE TABLE IF NOT EXISTS marriages (
  guildId TEXT NOT NULL,
  userId TEXT NOT NULL,
  partnerId TEXT NOT NULL,
  marriedAt INTEGER NOT NULL,
  PRIMARY KEY (guildId, userId)
);
`);

// ================== AUTO-MIGRATION (aman untuk database lama) ==================
function ensureColumn(table, column, definition) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all().map(c => c.name);
  if (!cols.includes(column)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
  }
}

ensureColumn('guild_config', 'modLogEnabled', 'INTEGER DEFAULT 0');
ensureColumn('guild_config', 'antiraidEnabled', 'INTEGER DEFAULT 0');
ensureColumn('guild_config', 'minAccountAgeDays', 'INTEGER DEFAULT 3');
ensureColumn('guild_config', 'verifyRoleId', 'TEXT');
ensureColumn('guild_config', 'verifyChannelId', 'TEXT');
ensureColumn('guild_config', 'suggestChannelId', 'TEXT');
ensureColumn('guild_config', 'confessionChannelId', 'TEXT');
ensureColumn('guild_config', 'confessionCounter', 'INTEGER DEFAULT 0');
ensureColumn('guild_config', 'starboardChannelId', 'TEXT');
ensureColumn('guild_config', 'starboardThreshold', 'INTEGER DEFAULT 3');
ensureColumn('guild_config', 'voiceLogChannel', 'TEXT');
ensureColumn('guild_config', 'welcomeStyle', "TEXT DEFAULT 'embed'"); // 'embed' (klasik) atau 'card' (kartu gambar, lihat utils/welcomeCard.js)
ensureColumn('guild_config', 'welcomeColor', "TEXT DEFAULT 'green'"); // warna border kartu welcome (key preset di utils/welcomeCard.js)
ensureColumn('guild_config', 'goodbyeStyle', "TEXT DEFAULT 'embed'"); // 'embed' atau 'card'
ensureColumn('guild_config', 'goodbyeColor', 'TEXT'); // warna border kartu goodbye (default ikut welcomeColor)
ensureColumn('guild_config', 'econChannelId', 'TEXT'); // channel tujuan notifikasi ekonomi Kizco
ensureColumn('guild_config', 'econNotifyEnabled', 'INTEGER DEFAULT 0'); // toggle notifikasi ekonomi
ensureColumn('guild_config', 'econLastNotifyCycle', 'INTEGER DEFAULT 0'); // dedup siklus notif terakhir
ensureColumn('guild_config', 'language', "TEXT DEFAULT 'id'"); // bahasa server (kode ISO, default Indonesia)

// ================== TABEL BARU: REGISTRASI USER + HISTORY AI ==================
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  userId TEXT PRIMARY KEY,
  username TEXT NOT NULL,
  age INTEGER NOT NULL,
  registeredAt INTEGER NOT NULL,
  banned INTEGER DEFAULT 0,
  notes TEXT
);

CREATE TABLE IF NOT EXISTS ai_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  userId TEXT NOT NULL,
  role TEXT NOT NULL,
  content TEXT NOT NULL,
  timestamp INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ai_history_user ON ai_history (userId, id);

CREATE TABLE IF NOT EXISTS werewolf_sessions (
  gameId TEXT PRIMARY KEY,
  guildId TEXT NOT NULL UNIQUE,
  stateJson TEXT NOT NULL,
  updatedAt INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_werewolf_guild ON werewolf_sessions (guildId);

CREATE TABLE IF NOT EXISTS user_profiles (
  userId TEXT PRIMARY KEY,
  bio TEXT DEFAULT '',
  color TEXT DEFAULT '#5865F2',
  pronouns TEXT DEFAULT '',
  location TEXT DEFAULT '',
  updatedAt INTEGER NOT NULL
);

-- ===== Auto-update anime =====
-- Config per server: channel tujuan + toggle 2 jenis auto-post (jadwal harian & anime baru musim ini).
CREATE TABLE IF NOT EXISTS anime_config (
  guildId TEXT PRIMARY KEY,
  channelId TEXT,
  dailyDigestEnabled INTEGER DEFAULT 0,
  newSeasonAlertEnabled INTEGER DEFAULT 0,
  lastDigestDate TEXT
);
-- Dedup global (bukan per-server), LAMA - sudah tidak dipakai sejak alert diganti jadi per-episode
-- (lihat anime_episode_seen di bawah). Dibiarkan ada (bukan di-drop) supaya tidak perlu migrasi.
CREATE TABLE IF NOT EXISTS anime_seen (
  malId INTEGER PRIMARY KEY,
  title TEXT,
  firstSeenAt INTEGER NOT NULL
);
-- Dedup global per EPISODE (bukan per-anime) - satu judul anime bisa punya banyak baris di sini,
-- satu per episode yang sudah diumumkan, supaya episode baru tetap ke-notif walau anime-nya lama.
CREATE TABLE IF NOT EXISTS anime_episode_seen (
  malId INTEGER NOT NULL,
  episode INTEGER NOT NULL,
  seenAt INTEGER NOT NULL,
  PRIMARY KEY (malId, episode)
);

-- ===== Sinyal & info crypto =====
-- Config per server: channel tujuan, toggle auto-signal, dan watchlist simbol (disimpan
-- sebagai string dipisah koma, contoh: "BTCUSDT,ETHUSDT").
CREATE TABLE IF NOT EXISTS crypto_config (
  guildId TEXT PRIMARY KEY,
  channelId TEXT,
  signalEnabled INTEGER DEFAULT 0,
  watchlist TEXT DEFAULT 'BTCUSDT,ETHUSDT'
);
-- Simpan state indikator terakhir per (server, simbol) supaya auto-signal cuma kirim
-- notifikasi pas ada PERUBAHAN kondisi (mis. netral -> overbought), bukan spam tiap cek.
CREATE TABLE IF NOT EXISTS crypto_signal_state (
  guildId TEXT NOT NULL,
  symbol TEXT NOT NULL,
  lastState TEXT,
  updatedAt INTEGER NOT NULL,
  PRIMARY KEY (guildId, symbol)
);

-- ===== AI Channel (workspace privat ala ChatGPT/Claude) =====
-- Satu baris = satu channel privat AI milik satu user. channelId adalah ID channel Discord-nya
-- sendiri (dibuat lewat guild.channels.create), jadi kalau channel dihapus manual di Discord,
-- baris ini jadi "orphan" - dibersihkan lewat event channelDelete atau saat user buka /ai channel lagi.
CREATE TABLE IF NOT EXISTS ai_channels (
  channelId TEXT PRIMARY KEY,
  guildId TEXT NOT NULL,
  userId TEXT NOT NULL,
  provider TEXT NOT NULL,
  model TEXT NOT NULL,
  createdAt INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ai_channels_user ON ai_channels (guildId, userId);

-- Riwayat obrolan PER CHANNEL (beda dari ai_history yang per-user, dipakai /ai chat biasa).
CREATE TABLE IF NOT EXISTS ai_channel_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  channelId TEXT NOT NULL,
  role TEXT NOT NULL,
  content TEXT NOT NULL,
  timestamp INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ai_channel_history ON ai_channel_history (channelId, id);

-- Kategori tempat semua channel AI dikumpulkan, satu per server (dibuat otomatis kalau belum ada).
CREATE TABLE IF NOT EXISTS ai_category (
  guildId TEXT PRIMARY KEY,
  categoryId TEXT NOT NULL
);

-- Watchlist trading per user (aset yang dibintangi di terminal trading).
-- Disimpan di database, BUKAN localStorage, supaya ikut user walau ganti perangkat/browser.
CREATE TABLE IF NOT EXISTS user_watchlist (
  userId TEXT NOT NULL,
  itemId TEXT NOT NULL,
  createdAt INTEGER NOT NULL,
  PRIMARY KEY (userId, itemId)
);
`);

// ================== PROFIL USER ==================
function getUserProfile(userId) {
  const existing = db.prepare('SELECT * FROM user_profiles WHERE userId = ?').get(userId);
  return existing || { userId, bio: '', color: '#5865F2', pronouns: '', location: '', updatedAt: 0 };
}

function setUserProfile(userId, changes) {
  const allowed = ['bio', 'color', 'pronouns', 'location'];
  const current = getUserProfile(userId);
  const next = { ...current };
  for (const [key, value] of Object.entries(changes || {})) {
    if (!allowed.includes(key)) throw new Error(`Field profil tidak valid: ${key}`);
    if (key === 'color') {
      // Normalisasi ke lowercase biar konsisten dengan <input type="color"> (yang selalu
      // return lowercase) dan kartu canvas yang pakai regex lowercase.
      const c = String(value || '');
      next[key] = /^#[0-9a-fA-F]{6}$/.test(c) ? c.toLowerCase() : current.color;
    } else {
      next[key] = String(value || '');
    }
  }
  db.prepare(`INSERT INTO user_profiles (userId, bio, color, pronouns, location, updatedAt)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(userId) DO UPDATE SET bio=excluded.bio, color=excluded.color,
      pronouns=excluded.pronouns, location=excluded.location, updatedAt=excluded.updatedAt`)
    .run(userId, next.bio, next.color, next.pronouns, next.location, Date.now());
  return getUserProfile(userId);
}

// ================== WEREWOLF SESSION ==================
function saveWerewolfSession(game) {
  const stateJson = JSON.stringify(game);
  db.prepare(`INSERT INTO werewolf_sessions (gameId, guildId, stateJson, updatedAt)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(gameId) DO UPDATE SET guildId=excluded.guildId, stateJson=excluded.stateJson, updatedAt=excluded.updatedAt`)
    .run(game.id, game.guildId, stateJson, Date.now());
}

function getWerewolfSessionByGuild(guildId) {
  const row = db.prepare('SELECT * FROM werewolf_sessions WHERE guildId = ?').get(guildId);
  if (!row) return null;
  try { return JSON.parse(row.stateJson); } catch (_) { return null; }
}

function listWerewolfSessions() {
  return db.prepare('SELECT stateJson FROM werewolf_sessions').all().map(row => {
    try { return JSON.parse(row.stateJson); } catch (_) { return null; }
  }).filter(Boolean);
}

function deleteWerewolfSession(gameId) {
  return db.prepare('DELETE FROM werewolf_sessions WHERE gameId = ?').run(gameId).changes;
}

// ================== USER REGISTRATION ==================
function registerUser(userId, username, age) {
  db.prepare(`INSERT INTO users (userId, username, age, registeredAt, banned, notes)
    VALUES (?, ?, ?, ?, 0, NULL)
    ON CONFLICT(userId) DO UPDATE SET username=excluded.username, age=excluded.age`)
    .run(userId, username, age, Date.now());
  return getUser(userId);
}

function getUser(userId) {
  return db.prepare('SELECT * FROM users WHERE userId = ?').get(userId);
}

function isRegistered(userId) {
  const u = getUser(userId);
  return !!u && !u.banned;
}

function deleteUser(userId) {
  return db.prepare('DELETE FROM users WHERE userId = ?').run(userId).changes;
}

function setUserBanned(userId, banned) {
  return db.prepare('UPDATE users SET banned = ? WHERE userId = ?').run(banned ? 1 : 0, userId).changes;
}

function setUserField(userId, field, value) {
  const allowed = ['username', 'age', 'notes'];
  if (!allowed.includes(field)) throw new Error('Field tidak valid');
  return db.prepare(`UPDATE users SET ${field} = ? WHERE userId = ?`).run(value, userId).changes;
}

function resetEconomyForGuild(guildId, userId) {
  getEconomy(guildId, userId);
  return db.prepare('UPDATE economy SET balance = 0, bank = 0 WHERE guildId = ? AND userId = ?').run(guildId, userId).changes;
}
// NOTE: nama resetEconomyForGuild di atas menyesatkan - fungsi itu cuma reset SATU user (butuh
// userId), BUKAN semua user di guild. Ini fungsi yang BENERAN reset economy SEMUA user sekaligus
// di 1 guild - dipakai Luna buat tool "reset economy semua user di server ini".
function resetEconomyForAllInGuild(guildId) {
  return db.prepare('UPDATE economy SET balance = 0, bank = 0 WHERE guildId = ?').run(guildId).changes;
}

function listUsers(limit = 25, offset = 0) {
  return db.prepare('SELECT * FROM users ORDER BY registeredAt DESC LIMIT ? OFFSET ?').all(limit, offset);
}

function countUsers() {
  return db.prepare('SELECT COUNT(*) AS c FROM users').get().c;
}

// ================== AI HISTORY (persisten di DB) ==================
function addAiMessage(userId, role, content) {
  db.prepare('INSERT INTO ai_history (userId, role, content, timestamp) VALUES (?, ?, ?, ?)')
    .run(userId, role, content, Date.now());
}

function getAiHistory(userId, limit = 12) {
  const rows = db.prepare('SELECT role, content FROM ai_history WHERE userId = ? ORDER BY id DESC LIMIT ?').all(userId, limit);
  return rows.reverse();
}

function clearAiHistory(userId) {
  return db.prepare('DELETE FROM ai_history WHERE userId = ?').run(userId).changes;
}

// ================== SUGGESTION (tambahan) ==================
function getSuggestionByMessageId(messageId) {
  return db.prepare('SELECT * FROM suggestions WHERE messageId = ?').get(messageId);
}

function getPendingSuggestions(guildId, limit = 25) {
  return db.prepare("SELECT * FROM suggestions WHERE guildId = ? AND status = 'pending' ORDER BY id DESC LIMIT ?").all(guildId, limit);
}

// ================== GUILD CONFIG ==================
function getGuildConfig(guildId) {
  let row = db.prepare('SELECT * FROM guild_config WHERE guildId = ?').get(guildId);
  if (!row) {
    db.prepare('INSERT INTO guild_config (guildId) VALUES (?)').run(guildId);
    row = db.prepare('SELECT * FROM guild_config WHERE guildId = ?').get(guildId);
  }
  return row;
}

function updateGuildConfig(guildId, fields) {
  getGuildConfig(guildId); // pastikan row ada
  const keys = Object.keys(fields);
  if (keys.length === 0) return;
  const setClause = keys.map(k => `${k} = @${k}`).join(', ');
  db.prepare(`UPDATE guild_config SET ${setClause} WHERE guildId = @guildId`).run({ guildId, ...fields });
}

// ================== LEVELING ==================
function getLevel(guildId, userId) {
  let row = db.prepare('SELECT * FROM levels WHERE guildId = ? AND userId = ?').get(guildId, userId);
  if (!row) {
    db.prepare('INSERT INTO levels (guildId, userId) VALUES (?, ?)').run(guildId, userId);
    row = db.prepare('SELECT * FROM levels WHERE guildId = ? AND userId = ?').get(guildId, userId);
  }
  return row;
}

function xpForLevel(level) {
  // Sama dengan kurva XP levelEngine (web) supaya level chat & web pakai SATU formula.
  if (level >= 100) return Infinity;
  return Math.floor(50 * level * level + 150 * level + 50);
}

function addXp(guildId, userId, amount) {
  const current = getLevel(guildId, userId);
  let newXp = current.xp + amount;
  let newLevel = current.level;
  let leveledUp = false;
  while (newXp >= xpForLevel(newLevel)) {
    newXp -= xpForLevel(newLevel);
    newLevel++;
    leveledUp = true;
  }
  db.prepare('UPDATE levels SET xp = ?, level = ?, lastXpTimestamp = ? WHERE guildId = ? AND userId = ?')
    .run(newXp, newLevel, Date.now(), guildId, userId);
  return { leveledUp, newLevel, newXp };
}

function setLevel(guildId, userId, level) {
  getLevel(guildId, userId);
  db.prepare('UPDATE levels SET level = ?, xp = 0 WHERE guildId = ? AND userId = ?').run(level, guildId, userId);
}

// Sinkronkan level & XP tabel leveling per-guild ke nilai level TERUNIFIKASI (RPG global).
// Dipakai supaya /rank, leaderboard, dan kartu profil menampilkan level yang SAMA dengan RPG.
// CATATAN: TIDAK menyentuh lastXpTimestamp — cooldown XP chat dipisah dari sync level
// supaya aktivitas RPG (battle/quest/hunt) tidak ikut mem-blok XP dari ngetik pesan.
function syncLevel(guildId, userId, level, xp) {
  getLevel(guildId, userId); // pastikan row ada
  db.prepare('UPDATE levels SET level = ?, xp = ? WHERE guildId = ? AND userId = ?')
    .run(level, xp, guildId, userId);
  return getLevel(guildId, userId);
}

// Catat waktu terakhir user dapat XP CHAT (cooldown anti-spam XP, terpisah dari level).
function touchXpCooldown(guildId, userId) {
  getLevel(guildId, userId);
  db.prepare('UPDATE levels SET lastXpTimestamp = ? WHERE guildId = ? AND userId = ?')
    .run(Date.now(), guildId, userId);
  return getLevel(guildId, userId);
}

function getLevelLeaderboard(guildId, limit = 10) {
  return db.prepare('SELECT * FROM levels WHERE guildId = ? ORDER BY level DESC, xp DESC LIMIT ?').all(guildId, limit);
}

// ================== ECONOMY ==================
function getEconomy(guildId, userId) {
  let row = db.prepare('SELECT * FROM economy WHERE guildId = ? AND userId = ?').get(guildId, userId);
  if (!row) {
    db.prepare('INSERT INTO economy (guildId, userId) VALUES (?, ?)').run(guildId, userId);
    row = db.prepare('SELECT * FROM economy WHERE guildId = ? AND userId = ?').get(guildId, userId);
  }
  return row;
}

function updateBalance(guildId, userId, amount) {
  getEconomy(guildId, userId);
  db.prepare('UPDATE economy SET balance = balance + ? WHERE guildId = ? AND userId = ?').run(amount, guildId, userId);
  return getEconomy(guildId, userId);
}

function updateBank(guildId, userId, amount) {
  getEconomy(guildId, userId);
  db.prepare('UPDATE economy SET bank = bank + ? WHERE guildId = ? AND userId = ?').run(amount, guildId, userId);
  return getEconomy(guildId, userId);
}

function setLastAction(guildId, userId, column, timestamp) {
  const allowed = ['lastDaily', 'lastWork', 'lastRob'];
  if (!allowed.includes(column)) throw new Error('Kolom tidak valid');
  getEconomy(guildId, userId);
  db.prepare(`UPDATE economy SET ${column} = ? WHERE guildId = ? AND userId = ?`).run(timestamp, guildId, userId);
}

function getEconomyLeaderboard(guildId, limit = 10) {
  return db.prepare('SELECT *, (balance + bank) as total FROM economy WHERE guildId = ? ORDER BY total DESC LIMIT ?').all(guildId, limit);
}

// ================== WARNINGS ==================
function addWarning(guildId, userId, moderatorId, reason) {
  db.prepare('INSERT INTO warnings (guildId, userId, moderatorId, reason, timestamp) VALUES (?, ?, ?, ?, ?)')
    .run(guildId, userId, moderatorId, reason, Date.now());
}

function getWarnings(guildId, userId) {
  return db.prepare('SELECT * FROM warnings WHERE guildId = ? AND userId = ? ORDER BY timestamp DESC').all(guildId, userId);
}

function clearWarnings(guildId, userId) {
  return db.prepare('DELETE FROM warnings WHERE guildId = ? AND userId = ?').run(guildId, userId).changes;
}

function removeWarningById(id, guildId) {
  return db.prepare('DELETE FROM warnings WHERE id = ? AND guildId = ?').run(id, guildId).changes;
}

// ================== BANNED WORDS ==================
function addBannedWord(guildId, word) {
  db.prepare('INSERT OR IGNORE INTO banned_words (guildId, word) VALUES (?, ?)').run(guildId, word.toLowerCase());
}

function removeBannedWord(guildId, word) {
  return db.prepare('DELETE FROM banned_words WHERE guildId = ? AND word = ?').run(guildId, word.toLowerCase()).changes;
}

function getBannedWords(guildId) {
  return db.prepare('SELECT word FROM banned_words WHERE guildId = ?').all(guildId).map(r => r.word);
}

// ================== GIVEAWAYS ==================
function createGiveaway(data) {
  db.prepare(`INSERT INTO giveaways (messageId, guildId, channelId, prize, winnerCount, endTime, hostId, ended)
    VALUES (@messageId, @guildId, @channelId, @prize, @winnerCount, @endTime, @hostId, 0)`).run(data);
}

function getGiveaway(messageId) {
  return db.prepare('SELECT * FROM giveaways WHERE messageId = ?').get(messageId);
}

function endGiveaway(messageId) {
  db.prepare('UPDATE giveaways SET ended = 1 WHERE messageId = ?').run(messageId);
}

function getActiveGiveaways() {
  return db.prepare('SELECT * FROM giveaways WHERE ended = 0').all();
}

// ================== SHOP / INVENTORY ==================
function addShopItem(guildId, itemId, name, price, description, roleId = null) {
  db.prepare(`INSERT OR REPLACE INTO shop_items (guildId, itemId, name, price, description, roleId)
    VALUES (?, ?, ?, ?, ?, ?)`).run(guildId, itemId, name, price, description, roleId);
}

function removeShopItem(guildId, itemId) {
  return db.prepare('DELETE FROM shop_items WHERE guildId = ? AND itemId = ?').run(guildId, itemId).changes;
}

function getShopItems(guildId) {
  return db.prepare('SELECT * FROM shop_items WHERE guildId = ?').all(guildId);
}

function getShopItem(guildId, itemId) {
  return db.prepare('SELECT * FROM shop_items WHERE guildId = ? AND itemId = ?').get(guildId, itemId);
}

function addInventoryItem(guildId, userId, itemId, quantity = 1) {
  const existing = db.prepare('SELECT * FROM inventory WHERE guildId = ? AND userId = ? AND itemId = ?').get(guildId, userId, itemId);
  if (existing) {
    db.prepare('UPDATE inventory SET quantity = quantity + ? WHERE guildId = ? AND userId = ? AND itemId = ?')
      .run(quantity, guildId, userId, itemId);
  } else {
    db.prepare('INSERT INTO inventory (guildId, userId, itemId, quantity) VALUES (?, ?, ?, ?)').run(guildId, userId, itemId, quantity);
  }
}

function getInventory(guildId, userId) {
  return db.prepare(`SELECT inventory.*, shop_items.name, shop_items.description
    FROM inventory JOIN shop_items ON inventory.itemId = shop_items.itemId AND inventory.guildId = shop_items.guildId
    WHERE inventory.guildId = ? AND inventory.userId = ?`).all(guildId, userId);
}

// ================== REMINDERS ==================
function addReminder(userId, channelId, guildId, message, remindAt) {
  const info = db.prepare('INSERT INTO reminders (userId, channelId, guildId, message, remindAt) VALUES (?, ?, ?, ?, ?)')
    .run(userId, channelId, guildId, message, remindAt);
  return info.lastInsertRowid;
}

function getDueReminders(now) {
  return db.prepare('SELECT * FROM reminders WHERE remindAt <= ?').all(now);
}

function deleteReminder(id) {
  db.prepare('DELETE FROM reminders WHERE id = ?').run(id);
}

// ================== AFK ==================
function setAfk(guildId, userId, reason) {
  db.prepare('INSERT OR REPLACE INTO afk (guildId, userId, reason, timestamp) VALUES (?, ?, ?, ?)')
    .run(guildId, userId, reason || 'AFK', Date.now());
}

function getAfk(guildId, userId) {
  return db.prepare('SELECT * FROM afk WHERE guildId = ? AND userId = ?').get(guildId, userId);
}

function removeAfk(guildId, userId) {
  return db.prepare('DELETE FROM afk WHERE guildId = ? AND userId = ?').run(guildId, userId).changes;
}

// ================== REACTION ROLES ==================
function addReactionRole(guildId, messageId, emoji, roleId) {
  db.prepare('INSERT OR REPLACE INTO reaction_roles (guildId, messageId, emoji, roleId) VALUES (?, ?, ?, ?)')
    .run(guildId, messageId, emoji, roleId);
}

function removeReactionRole(guildId, messageId, emoji) {
  return db.prepare('DELETE FROM reaction_roles WHERE guildId = ? AND messageId = ? AND emoji = ?').run(guildId, messageId, emoji).changes;
}

function getReactionRole(guildId, messageId, emoji) {
  return db.prepare('SELECT * FROM reaction_roles WHERE guildId = ? AND messageId = ? AND emoji = ?').get(guildId, messageId, emoji);
}

function getReactionRolesForMessage(guildId, messageId) {
  return db.prepare('SELECT * FROM reaction_roles WHERE guildId = ? AND messageId = ?').all(guildId, messageId);
}

// ================== STARBOARD ==================
function addStarboardPost(guildId, originalMessageId, starboardMessageId) {
  db.prepare('INSERT OR REPLACE INTO starboard_posts (guildId, originalMessageId, starboardMessageId) VALUES (?, ?, ?)')
    .run(guildId, originalMessageId, starboardMessageId);
}

function getStarboardPost(guildId, originalMessageId) {
  return db.prepare('SELECT * FROM starboard_posts WHERE guildId = ? AND originalMessageId = ?').get(guildId, originalMessageId);
}

// ================== SUGGESTIONS ==================
function addSuggestion(guildId, userId, messageId, content) {
  const info = db.prepare('INSERT INTO suggestions (guildId, userId, messageId, content, status, timestamp) VALUES (?, ?, ?, ?, ?, ?)')
    .run(guildId, userId, messageId, content, 'pending', Date.now());
  return info.lastInsertRowid;
}

function updateSuggestionStatus(id, status) {
  return db.prepare('UPDATE suggestions SET status = ? WHERE id = ?').run(status, id).changes;
}

function getSuggestion(id) {
  return db.prepare('SELECT * FROM suggestions WHERE id = ?').get(id);
}

// ================== BIRTHDAYS ==================
function setBirthday(guildId, userId, day, month) {
  db.prepare('INSERT OR REPLACE INTO birthdays (guildId, userId, day, month, lastAnnouncedYear) VALUES (?, ?, ?, ?, COALESCE((SELECT lastAnnouncedYear FROM birthdays WHERE guildId = ? AND userId = ?), 0))')
    .run(guildId, userId, day, month, guildId, userId);
}

function getBirthday(guildId, userId) {
  return db.prepare('SELECT * FROM birthdays WHERE guildId = ? AND userId = ?').get(guildId, userId);
}

function removeBirthday(guildId, userId) {
  return db.prepare('DELETE FROM birthdays WHERE guildId = ? AND userId = ?').run(guildId, userId).changes;
}

function getBirthdaysToday(day, month) {
  return db.prepare('SELECT * FROM birthdays WHERE day = ? AND month = ?').all(day, month);
}

function markBirthdayAnnounced(guildId, userId, year) {
  db.prepare('UPDATE birthdays SET lastAnnouncedYear = ? WHERE guildId = ? AND userId = ?').run(year, guildId, userId);
}

function getUpcomingBirthdays(guildId) {
  return db.prepare('SELECT * FROM birthdays WHERE guildId = ? ORDER BY month, day').all(guildId);
}

// ================== LEVEL REWARDS ==================
function addLevelReward(guildId, level, roleId) {
  db.prepare('INSERT OR REPLACE INTO level_rewards (guildId, level, roleId) VALUES (?, ?, ?)').run(guildId, level, roleId);
}

function removeLevelReward(guildId, level) {
  return db.prepare('DELETE FROM level_rewards WHERE guildId = ? AND level = ?').run(guildId, level).changes;
}

function getLevelRewards(guildId) {
  return db.prepare('SELECT * FROM level_rewards WHERE guildId = ? ORDER BY level ASC').all(guildId);
}

function getLevelRewardForLevel(guildId, level) {
  return db.prepare('SELECT * FROM level_rewards WHERE guildId = ? AND level = ?').get(guildId, level);
}

// ================== MARRIAGE ==================
function getMarriage(guildId, userId) {
  return db.prepare('SELECT * FROM marriages WHERE guildId = ? AND userId = ?').get(guildId, userId);
}

function createMarriage(guildId, userId, partnerId) {
  const now = Date.now();
  const insert = db.prepare('INSERT INTO marriages (guildId, userId, partnerId, marriedAt) VALUES (?, ?, ?, ?)');
  const transaction = db.transaction(() => {
    insert.run(guildId, userId, partnerId, now);
    insert.run(guildId, partnerId, userId, now);
  });
  transaction();
}

function removeMarriage(guildId, userId) {
  const existing = getMarriage(guildId, userId);
  if (!existing) return false;
  const del = db.prepare('DELETE FROM marriages WHERE guildId = ? AND userId = ?');
  const transaction = db.transaction(() => {
    del.run(guildId, userId);
    del.run(guildId, existing.partnerId);
  });
  transaction();
  return true;
}

// ================== ANIME (auto-update) ==================
function getAnimeConfig(guildId) {
  let row = db.prepare('SELECT * FROM anime_config WHERE guildId = ?').get(guildId);
  if (!row) {
    db.prepare('INSERT INTO anime_config (guildId) VALUES (?)').run(guildId);
    row = db.prepare('SELECT * FROM anime_config WHERE guildId = ?').get(guildId);
  }
  return row;
}

function updateAnimeConfig(guildId, fields) {
  getAnimeConfig(guildId); // pastikan row ada
  const keys = Object.keys(fields);
  if (keys.length === 0) return;
  const setClause = keys.map(k => `${k} = @${k}`).join(', ');
  db.prepare(`UPDATE anime_config SET ${setClause} WHERE guildId = @guildId`).run({ guildId, ...fields });
}

// Server yang punya minimal satu fitur auto-post anime aktif (dipakai job di ready.js
// biar tidak perlu loop semua guild config tiap kali cek).
function getAnimeConfigsWithAnyFeature() {
  return db.prepare('SELECT * FROM anime_config WHERE channelId IS NOT NULL AND (dailyDigestEnabled = 1 OR newSeasonAlertEnabled = 1)').all();
}

function filterUnseenAnime(items) {
  if (!items.length) return [];
  const placeholders = items.map(() => '?').join(',');
  const seenIds = new Set(db.prepare(`SELECT malId FROM anime_seen WHERE malId IN (${placeholders})`).all(...items.map(i => i.malId)).map(r => r.malId));
  return items.filter(i => !seenIds.has(i.malId));
}

function markAnimeSeen(items) {
  if (!items.length) return;
  const now = Date.now();
  const insert = db.prepare('INSERT OR IGNORE INTO anime_seen (malId, title, firstSeenAt) VALUES (?, ?, ?)');
  const transaction = db.transaction(() => { for (const i of items) insert.run(i.malId, i.title, now); });
  transaction();
}

// Dedup per EPISODE - beda dengan filterUnseenAnime (yang cuma sekali per judul selamanya),
// ini butuh (malId, episode) MATCH PERSIS supaya episode 5 yang baru tetap ke-notif walau
// episode 1-4 anime yang sama sudah pernah diumumkan sebelumnya.
function filterUnseenEpisodes(items) {
  if (!items.length) return [];
  const placeholders = items.map(() => '?').join(',');
  const rows = db.prepare(`SELECT malId, episode FROM anime_episode_seen WHERE malId IN (${placeholders})`).all(...items.map(i => i.malId));
  const seenKeys = new Set(rows.map(r => `${r.malId}:${r.episode}`));
  return items.filter(i => !seenKeys.has(`${i.malId}:${i.episode}`));
}

function markEpisodesSeen(items) {
  if (!items.length) return;
  const now = Date.now();
  const insert = db.prepare('INSERT OR IGNORE INTO anime_episode_seen (malId, episode, seenAt) VALUES (?, ?, ?)');
  const transaction = db.transaction(() => { for (const i of items) insert.run(i.malId, i.episode, now); });
  transaction();
}

// ================== CRYPTO (info & sinyal) ==================
function getCryptoConfig(guildId) {
  let row = db.prepare('SELECT * FROM crypto_config WHERE guildId = ?').get(guildId);
  if (!row) {
    db.prepare('INSERT INTO crypto_config (guildId) VALUES (?)').run(guildId);
    row = db.prepare('SELECT * FROM crypto_config WHERE guildId = ?').get(guildId);
  }
  return row;
}

function updateCryptoConfig(guildId, fields) {
  getCryptoConfig(guildId);
  const keys = Object.keys(fields);
  if (keys.length === 0) return;
  const setClause = keys.map(k => `${k} = @${k}`).join(', ');
  db.prepare(`UPDATE crypto_config SET ${setClause} WHERE guildId = @guildId`).run({ guildId, ...fields });
}

function getCryptoConfigsWithSignalEnabled() {
  return db.prepare('SELECT * FROM crypto_config WHERE channelId IS NOT NULL AND signalEnabled = 1').all();
}

function getCryptoSignalState(guildId, symbol) {
  return db.prepare('SELECT * FROM crypto_signal_state WHERE guildId = ? AND symbol = ?').get(guildId, symbol);
}

function setCryptoSignalState(guildId, symbol, lastState) {
  db.prepare(`
    INSERT INTO crypto_signal_state (guildId, symbol, lastState, updatedAt) VALUES (?, ?, ?, ?)
    ON CONFLICT(guildId, symbol) DO UPDATE SET lastState = excluded.lastState, updatedAt = excluded.updatedAt
  `).run(guildId, symbol, lastState, Date.now());
}

// ================== AI CHANNEL (workspace privat) ==================
function createAiChannel({ channelId, guildId, userId, provider, model }) {
  db.prepare('INSERT INTO ai_channels (channelId, guildId, userId, provider, model, createdAt) VALUES (?, ?, ?, ?, ?, ?)')
    .run(channelId, guildId, userId, provider, model, Date.now());
}

function getAiChannel(channelId) {
  return db.prepare('SELECT * FROM ai_channels WHERE channelId = ?').get(channelId);
}

function listAiChannelsForUser(guildId, userId) {
  return db.prepare('SELECT * FROM ai_channels WHERE guildId = ? AND userId = ? ORDER BY createdAt ASC').all(guildId, userId);
}

function setAiChannelModel(channelId, { provider, model }) {
  db.prepare('UPDATE ai_channels SET provider = ?, model = ? WHERE channelId = ?').run(provider, model, channelId);
}

// Hapus baris channel + seluruh riwayatnya. Dipanggil baik saat user hapus lewat tombol,
// maupun saat ketahuan "orphan" (channel Discord-nya sudah tidak ada tapi baris DB masih ada).
function deleteAiChannel(channelId) {
  const transaction = db.transaction(() => {
    db.prepare('DELETE FROM ai_channel_history WHERE channelId = ?').run(channelId);
    db.prepare('DELETE FROM ai_channels WHERE channelId = ?').run(channelId);
  });
  transaction();
}

function addAiChannelMessage(channelId, role, content) {
  db.prepare('INSERT INTO ai_channel_history (channelId, role, content, timestamp) VALUES (?, ?, ?, ?)')
    .run(channelId, role, content, Date.now());
}

function getAiChannelHistory(channelId, limit = 20) {
  const rows = db.prepare('SELECT role, content FROM ai_channel_history WHERE channelId = ? ORDER BY id DESC LIMIT ?').all(channelId, limit);
  return rows.reverse();
}

function clearAiChannelHistory(channelId) {
  return db.prepare('DELETE FROM ai_channel_history WHERE channelId = ?').run(channelId).changes;
}

function getAiCategoryId(guildId) {
  return db.prepare('SELECT categoryId FROM ai_category WHERE guildId = ?').get(guildId)?.categoryId || null;
}

// ================== WATCHLIST TRADING ==================
function getWatchlist(userId) {
  return db.prepare('SELECT itemId FROM user_watchlist WHERE userId = ? ORDER BY createdAt ASC').all(userId).map(r => r.itemId);
}

// Toggle satu item (tambah kalau belum ada, hapus kalau sudah ada).
// Mengembalikan daftar watchlist terbaru supaya frontend cukup sekali round-trip.
function toggleWatchlistItem(userId, itemId) {
  const existing = db.prepare('SELECT 1 FROM user_watchlist WHERE userId = ? AND itemId = ?').get(userId, itemId);
  if (existing) {
    db.prepare('DELETE FROM user_watchlist WHERE userId = ? AND itemId = ?').run(userId, itemId);
  } else {
    db.prepare('INSERT INTO user_watchlist (userId, itemId, createdAt) VALUES (?, ?, ?)').run(userId, itemId, Date.now());
  }
  return getWatchlist(userId);
}

function setAiCategoryId(guildId, categoryId) {
  db.prepare(`
    INSERT INTO ai_category (guildId, categoryId) VALUES (?, ?)
    ON CONFLICT(guildId) DO UPDATE SET categoryId = excluded.categoryId
  `).run(guildId, categoryId);
}

module.exports = {
  db,
  getGuildConfig, updateGuildConfig,
  getLevel, addXp, setLevel, syncLevel, touchXpCooldown, getLevelLeaderboard, xpForLevel,
  getEconomy, updateBalance, updateBank, setLastAction, getEconomyLeaderboard,
  addWarning, getWarnings, clearWarnings, removeWarningById,
  addBannedWord, removeBannedWord, getBannedWords,
  createGiveaway, getGiveaway, endGiveaway, getActiveGiveaways,
  addShopItem, removeShopItem, getShopItems, getShopItem, addInventoryItem, getInventory,
  addReminder, getDueReminders, deleteReminder,
  setAfk, getAfk, removeAfk,
  addReactionRole, removeReactionRole, getReactionRole, getReactionRolesForMessage,
  addStarboardPost, getStarboardPost,
  addSuggestion, updateSuggestionStatus, getSuggestion, getSuggestionByMessageId, getPendingSuggestions,
  setBirthday, getBirthday, removeBirthday, getBirthdaysToday, markBirthdayAnnounced, getUpcomingBirthdays,
  addLevelReward, removeLevelReward, getLevelRewards, getLevelRewardForLevel,
  getMarriage, createMarriage, removeMarriage,
  registerUser, getUser, isRegistered, deleteUser, setUserBanned, setUserField, resetEconomyForGuild, resetEconomyForAllInGuild, listUsers, countUsers,
  getUserProfile, setUserProfile,
  saveWerewolfSession, getWerewolfSessionByGuild, listWerewolfSessions, deleteWerewolfSession,
  addAiMessage, getAiHistory, clearAiHistory,
  getAnimeConfig, updateAnimeConfig, getAnimeConfigsWithAnyFeature, filterUnseenAnime, markAnimeSeen,
  filterUnseenEpisodes, markEpisodesSeen,
  getCryptoConfig, updateCryptoConfig, getCryptoConfigsWithSignalEnabled, getCryptoSignalState, setCryptoSignalState,
  createAiChannel, getAiChannel, listAiChannelsForUser, setAiChannelModel, deleteAiChannel,
  addAiChannelMessage, getAiChannelHistory, clearAiChannelHistory, getAiCategoryId, setAiCategoryId,
  getWatchlist, toggleWatchlistItem,
};
