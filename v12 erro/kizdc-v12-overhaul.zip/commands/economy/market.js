const { SlashCommandBuilder } = require('discord.js');
const shop = require('../../utils/shopManager');
const engine = require('../../utils/economyEngine');
const econ = require('../../database/economyDb');
const rdb = require('../../database/rpgDb');
const B = require('../../utils/economyButtons');
const kizco = require('../../utils/kizco');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('market')
    .setDescription('Pasar Kizco — barang dengan harga dinamis (tombol interaktif)')
    .addSubcommand(sub => sub.setName('view').setDescription('Buka pasar interaktif (dengan tombol kategori & beli)'))
    .addSubcommand(sub => sub.setName('trends').setDescription('Analisis permintaan pasar'))
    .addSubcommand(sub => sub.setName('chart').setDescription('Grafik riwayat harga sebuah item')
      .addStringOption(o => o.setName('item').setDescription('ID item').setRequired(true)))
    .addSubcommand(sub => sub.setName('buy').setDescription('Beli barang dari pasar (lewat teks)')
      .addStringOption(o => o.setName('item').setDescription('ID item (lihat /market view)').setRequired(true))
      .addIntegerOption(o => o.setName('jumlah').setDescription('Jumlah (default 1)').setMinValue(1)))
    .addSubcommand(sub => sub.setName('sell').setDescription('Jual barang dari tasmu ke pasar')
      .addStringOption(o => o.setName('item').setDescription('ID item dari tasmu').setRequired(true))
      .addIntegerOption(o => o.setName('jumlah').setDescription('Jumlah (default 1)').setMinValue(1))),

  async execute(interaction) {
    const lang = guildLang(interaction);
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    const userId = interaction.user.id;

    if (sub === 'view') return interaction.reply(B.renderMarketHome(guildId));
    if (sub === 'trends') return interaction.reply(B.renderMarketTrends(guildId));
    if (sub === 'chart') {
      const itemId = interaction.options.getString('item').toLowerCase();
      return interaction.reply(B.renderItemChart(guildId, itemId));
    }

    if (sub === 'buy') {
      const itemId = interaction.options.getString('item').toLowerCase();
      const qty = interaction.options.getInteger('jumlah') || 1;
      const item = shop.getItem(itemId);
      if (!item) return interaction.reply({ embeds: [errorEmbed(t(lang, 'market.unknown'))], ephemeral: true });

      const price = shop.buyPrice(guildId, itemId);
      const total = price * qty;
      const { getEconomy } = require('../../database/db');
      const eco = getEconomy(guildId, userId);
      if (eco.balance < total) return interaction.reply({ embeds: [errorEmbed(t(lang, 'market.no_funds', { need: kizco.format(total), have: kizco.format(eco.balance) }))], ephemeral: true });

      engine.debitPlayer(guildId, userId, total, { type: 'purchase', note: `Beli ${qty}x ${item.name}` });
      rdb.addItem(userId, itemId, qty);
      econ.bumpDemand(guildId, itemId, qty);
      econ.recordItemPrice(guildId, itemId, price);

      return interaction.reply({ embeds: [successEmbed(t(lang, 'market.buy_ok', { qty, item: item.name, price: kizco.format(total) }))] });
    }

    if (sub === 'sell') {
      const itemId = interaction.options.getString('item').toLowerCase();
      const qty = interaction.options.getInteger('jumlah') || 1;
      const item = shop.getItem(itemId);
      if (!item) return interaction.reply({ embeds: [errorEmbed(t(lang, 'market.unknown'))], ephemeral: true });
      if (rdb.getItemQty(userId, itemId) < qty) return interaction.reply({ embeds: [errorEmbed(t(lang, 'market.no_item', { item: item.name }))], ephemeral: true });

      const buyP = shop.buyPrice(guildId, itemId);
      const sellPrice = Math.max(1, Math.round(buyP * 0.5));
      const total = sellPrice * qty;

      rdb.removeItem(userId, itemId, qty);
      const { updateBalance } = require('../../database/db');
      updateBalance(guildId, userId, total);
      econ.recordTransaction(guildId, { type: 'sell', actorId: userId, amount: total, note: `Jual ${qty}x ${item.name}` });
      econ.bumpDemand(guildId, itemId, -qty);
      econ.recordItemPrice(guildId, itemId, sellPrice);

      return interaction.reply({ embeds: [successEmbed(t(lang, 'market.sell_ok', { qty, item: item.name, price: kizco.format(total) }))] });
    }
  },
};
