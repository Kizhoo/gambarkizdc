function applyPlaceholders(template, { member, guild }) {
  if (!template) return null;
  return template
    .replaceAll('{user}', `<@${member.id}>`)
    .replaceAll('{username}', member.user.username)
    .replaceAll('{tag}', member.user.tag)
    .replaceAll('{server}', guild.name)
    .replaceAll('{membercount}', guild.memberCount.toString());
}

module.exports = { applyPlaceholders };
