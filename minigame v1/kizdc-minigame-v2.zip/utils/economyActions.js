// ============================================================================
// AKSI ECONOMY YANG DIPAKAI BERSAMA — commands/economy/*.js DAN Luna
// ----------------------------------------------------------------------------
// SATU sumber kebenaran untuk aksi ekonomi dasar. Semua reward sekarang lewat
// engine.creditPlayer() (kebijakan moneter + pajak) dan semua pergerakan uang
// dicatat ke buku besar (economyDb.recordTransaction) agar masuk metrik
// makroekonomi & feed dashboard.
// ============================================================================
const { getEconomy, updateBalance, updateBank, setLastAction, getEconomyLeaderboard } = require('../database/db');
const econ = require('../database/economyDb');
const engine = require('./economyEngine');
const config = require('../config.json');

const DAY_MS = 24 * 60 * 60 * 1000;
const WORK_COOLDOWN_MS = 60 * 60 * 1000;
const ROB_COOLDOWN_MS = 2 * 60 * 60 * 1000;
const JOBS = [
  'Jadi tukang parkir', 'Ngoding bot Discord', 'Jualan es teh', 'Jadi kurir paket', 'Streaming game', 'Jadi content creator',
];

function claimDaily(guildId, userId) {
  const eco = getEconomy(guildId, userId);
  const now = Date.now();
  if (now - eco.lastDaily < DAY_MS) {
    const remaining = DAY_MS - (now - eco.lastDaily);
    return { ok: false, error: `Sudah klaim daily. Coba lagi dalam ${Math.floor(remaining / 3600000)}j ${Math.floor((remaining % 3600000) / 60000)}m.` };
  }
  const { gross, tax, net } = engine.creditPlayer(guildId, userId, config.dailyAmount, { type: 'daily', note: 'Klaim daily' });
  setLastAction(guildId, userId, 'lastDaily', now);
  return { ok: true, amount: net, gross, tax };
}

function doWork(guildId, userId) {
  const eco = getEconomy(guildId, userId);
  const now = Date.now();
  if (now - eco.lastWork < WORK_COOLDOWN_MS) {
    const remaining = WORK_COOLDOWN_MS - (now - eco.lastWork);
    return { ok: false, error: `Masih capek. Coba lagi dalam ${Math.floor(remaining / 60000)} menit.` };
  }
  const base = Math.floor(Math.random() * (config.workMax - config.workMin + 1)) + config.workMin;
  const job = JOBS[Math.floor(Math.random() * JOBS.length)];
  const { gross, tax, net } = engine.creditPlayer(guildId, userId, base, { type: 'work', note: job });
  setLastAction(guildId, userId, 'lastWork', now);
  return { ok: true, job, earnings: net, gross, tax };
}

function attemptRob(guildId, robberId, targetId) {
  if (robberId === targetId) return { ok: false, error: 'Tidak bisa merampok diri sendiri.' };
  const robberEco = getEconomy(guildId, robberId);
  const now = Date.now();
  if (now - robberEco.lastRob < ROB_COOLDOWN_MS) {
    return { ok: false, error: `Masih dalam masa buron. Coba lagi dalam ${Math.floor((ROB_COOLDOWN_MS - (now - robberEco.lastRob)) / 60000)} menit.` };
  }
  const targetEco = getEconomy(guildId, targetId);
  if (targetEco.balance < 50) return { ok: false, error: 'Target tidak punya cukup Kizco untuk dirampok (minimal 50).' };
  setLastAction(guildId, robberId, 'lastRob', now);
  const success = Math.random() < (config.robSuccessRate ?? 0.4);
  if (success) {
    const stolen = Math.floor(targetEco.balance * (Math.random() * 0.3 + 0.1));
    updateBalance(guildId, targetId, -stolen);
    updateBalance(guildId, robberId, stolen);
    econ.recordTransaction(guildId, { type: 'rob', actorId: robberId, targetId, amount: stolen, note: 'Perampokan' });
    return { ok: true, success: true, stolen };
  }
  const fine = Math.min(Math.floor(Math.random() * 200) + 50, robberEco.balance);
  updateBalance(guildId, robberId, -fine);
  econ.recordTransaction(guildId, { type: 'fine', actorId: robberId, amount: -fine, note: 'Denda perampokan gagal' });
  return { ok: true, success: false, fine };
}

function payUser(guildId, fromId, toId, amount) {
  if (fromId === toId) return { ok: false, error: 'Tidak bisa transfer ke diri sendiri.' };
  amount = Math.max(1, Math.round(Number(amount) || 0));
  const eco = getEconomy(guildId, fromId);
  if (eco.balance < amount) return { ok: false, error: `Dompet tidak cukup. Dompet saat ini: ${eco.balance}` };
  updateBalance(guildId, fromId, -amount);
  updateBalance(guildId, toId, amount);
  econ.recordTransaction(guildId, { type: 'pay', actorId: fromId, targetId: toId, amount, note: 'Transfer Kizco' });
  return { ok: true, amount };
}

function bankDeposit(guildId, userId, amountInput) {
  const eco = getEconomy(guildId, userId);
  const amount = String(amountInput).toLowerCase() === 'all' ? eco.balance : Math.round(Number(amountInput));
  if (!amount || amount <= 0) return { ok: false, error: 'Jumlah tidak valid.' };
  if (amount > eco.balance) return { ok: false, error: `Dompet tidak cukup. Dompet saat ini: ${eco.balance}` };
  updateBalance(guildId, userId, -amount);
  updateBank(guildId, userId, amount);
  econ.recordTransaction(guildId, { type: 'bank', actorId: userId, amount: -amount, note: 'Setor bank' });
  econ.addBankLog({ guildId, userId, type: 'deposit', amount, note: 'Setor ke Bank Kizaria' });
  return { ok: true, amount };
}

function bankWithdraw(guildId, userId, amountInput) {
  const eco = getEconomy(guildId, userId);
  const amount = String(amountInput).toLowerCase() === 'all' ? eco.bank : Math.round(Number(amountInput));
  if (!amount || amount <= 0) return { ok: false, error: 'Jumlah tidak valid.' };
  if (amount > eco.bank) return { ok: false, error: `Saldo bank tidak cukup. Bank saat ini: ${eco.bank}` };
  updateBank(guildId, userId, -amount);
  updateBalance(guildId, userId, amount);
  econ.recordTransaction(guildId, { type: 'bank', actorId: userId, amount, note: 'Tarik bank' });
  econ.addBankLog({ guildId, userId, type: 'withdraw', amount: -amount, note: 'Tarik dari Bank Kizaria' });
  return { ok: true, amount };
}

module.exports = { claimDaily, doWork, attemptRob, payUser, bankDeposit, bankWithdraw, getEconomy, getEconomyLeaderboard };
