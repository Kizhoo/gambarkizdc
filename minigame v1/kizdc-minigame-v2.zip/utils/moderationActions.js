// ============================================================================
// AKSI MODERASI YANG DIPAKAI BERSAMA — commands/moderation/*.js DAN Luna
// ----------------------------------------------------------------------------
// Sama seperti economyActions.js: logic ditarik dari command asli (kick/ban/
// timeout/unban/warn) biar konsisten. Pengecekan izin (kickable/bannable/
// moderatable) TETAP dijalankan di sini persis seperti command aslinya - jadi
// Luna tidak bisa melakukan hal yang command aslinya sendiri juga tidak bisa
// lakukan (mis. kick/ban orang dengan role lebih tinggi dari bot).
//
// PENTING (keamanan): fungsi di sini TIDAK melakukan pengecekan owner/konfirmasi
// sendiri - itu tanggung jawab PEMANGGIL (lihat admin_action di lunaAgent.js,
// yang menerapkan isOwner() + gerbang konfirmasi buat kick/ban/timeout/clear
// warnings, persis pola yang sudah dipakai buat resetcharacter/addgold_all).
// ============================================================================
const { addWarning, getWarnings, clearWarnings, removeWarningById, addBannedWord, removeBannedWord, getBannedWords } = require('../database/db');

async function doKick(guild, targetId, reason) {
  const member = await guild.members.fetch(targetId).catch(() => null);
  if (!member) return { ok: false, error: 'Member tidak ditemukan di server ini.' };
  if (!member.kickable) return { ok: false, error: 'Tidak bisa kick member ini (role lebih tinggi/sama dengan bot).' };
  await member.send(`Kamu telah di-kick dari **${guild.name}**.\nAlasan: ${reason}`).catch(() => {});
  await member.kick(reason);
  return { ok: true, target: member.user.tag };
}

async function doBan(guild, targetId, reason, deleteMessageDays = 0) {
  const member = await guild.members.fetch(targetId).catch(() => null);
  if (member && !member.bannable) return { ok: false, error: 'Tidak bisa ban member ini (role lebih tinggi/sama dengan bot).' };
  const user = member?.user || await guild.client.users.fetch(targetId).catch(() => null);
  if (!user) return { ok: false, error: 'User tidak ditemukan.' };
  await user.send(`Kamu telah di-ban dari **${guild.name}**.\nAlasan: ${reason}`).catch(() => {});
  await guild.members.ban(targetId, { reason, deleteMessageSeconds: Math.max(0, Math.min(7, deleteMessageDays)) * 86400 });
  return { ok: true, target: user.tag };
}

async function doUnban(guild, targetId) {
  try {
    const banInfo = await guild.bans.fetch(targetId);
    await guild.members.unban(targetId);
    return { ok: true, target: banInfo.user.tag };
  } catch {
    return { ok: false, error: 'User tidak ditemukan dalam daftar ban, atau ID salah.' };
  }
}

async function doTimeout(guild, targetId, minutes, reason) {
  const member = await guild.members.fetch(targetId).catch(() => null);
  if (!member) return { ok: false, error: 'Member tidak ditemukan.' };
  if (!member.moderatable) return { ok: false, error: 'Tidak bisa timeout member ini.' };
  minutes = Math.max(1, Math.min(40320, Math.round(minutes)));
  await member.timeout(minutes * 60 * 1000, reason);
  return { ok: true, target: member.user.tag, minutes };
}

async function doRemoveTimeout(guild, targetId) {
  const member = await guild.members.fetch(targetId).catch(() => null);
  if (!member) return { ok: false, error: 'Member tidak ditemukan.' };
  if (!member.communicationDisabledUntil) return { ok: false, error: 'Member ini sedang tidak ditimeout.' };
  await member.timeout(null);
  return { ok: true, target: member.user.tag };
}

function warnUser(guildId, targetId, moderatorId, reason) {
  addWarning(guildId, targetId, moderatorId, reason || 'Tidak ada alasan');
  return { ok: true, warnings: getWarnings(guildId, targetId).length };
}
function listWarnings(guildId, targetId) {
  return { ok: true, warnings: getWarnings(guildId, targetId).map(w => ({ id: w.id, reason: w.reason, at: w.timestamp })) };
}
function clearUserWarnings(guildId, targetId) {
  const removed = clearWarnings(guildId, targetId);
  return { ok: true, removed };
}
function removeOneWarning(guildId, warningId) {
  const removed = removeWarningById(warningId, guildId);
  return removed ? { ok: true } : { ok: false, error: 'Warning dengan ID itu tidak ditemukan.' };
}
function addWord(guildId, word) { addBannedWord(guildId, word); return { ok: true, word }; }
function removeWord(guildId, word) {
  const removed = removeBannedWord(guildId, word);
  return removed ? { ok: true } : { ok: false, error: 'Kata itu tidak ada di daftar.' };
}
function listWords(guildId) { return { ok: true, words: getBannedWords(guildId) }; }

async function purgeMessages(channel, amount, fromUserId) {
  amount = Math.max(1, Math.min(100, Math.round(amount)));
  const messages = await channel.messages.fetch({ limit: 100 });
  const toDelete = fromUserId ? messages.filter(m => m.author.id === fromUserId).first(amount) : messages.first(amount);
  if (!toDelete || toDelete.length === 0) return { ok: false, error: 'Tidak ada pesan yang bisa dihapus.' };
  try {
    const deleted = await channel.bulkDelete(toDelete, true);
    return { ok: true, deleted: deleted.size };
  } catch (e) {
    if (e.message?.includes('14 days')) return { ok: false, error: 'Discord tidak mengizinkan hapus massal untuk pesan lebih tua dari 14 hari.' };
    return { ok: false, error: e.message };
  }
}
async function setChannelLock(channel, locked) {
  await channel.permissionOverwrites.edit(channel.guild.roles.everyone, { SendMessages: locked ? false : null });
  return { ok: true, locked };
}
async function setSlowmode(channel, seconds) {
  seconds = Math.max(0, Math.min(21600, Math.round(seconds)));
  await channel.setRateLimitPerUser(seconds);
  return { ok: true, seconds };
}
async function setNickname(guild, targetId, newName) {
  const member = await guild.members.fetch(targetId).catch(() => null);
  if (!member) return { ok: false, error: 'Member tidak ditemukan.' };
  if (!member.manageable) return { ok: false, error: 'Tidak bisa ubah nickname member ini (role lebih tinggi/sama, atau dia owner server).' };
  await member.setNickname(newName || null);
  return { ok: true, target: member.user.tag, newName: newName || null };
}

module.exports = {
  doKick, doBan, doUnban, doTimeout, doRemoveTimeout,
  warnUser, listWarnings, clearUserWarnings, removeOneWarning,
  addWord, removeWord, listWords,
  purgeMessages, setChannelLock, setSlowmode, setNickname,
};
