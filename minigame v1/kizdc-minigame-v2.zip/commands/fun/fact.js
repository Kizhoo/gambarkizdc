const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

const FACTS = [
  { id: 'Madu tidak pernah basi. Arkeolog pernah menemukan madu berusia 3000 tahun di makam Mesir yang masih layak dimakan.', en: 'Honey never spoils. Archaeologists found 3,000-year-old honey in Egyptian tombs that was still edible.' },
  { id: 'Jantung udang berada di kepalanya, bukan di badan.', en: "A shrimp's heart is located in its head, not its body." },
  { id: 'Satu hari di planet Venus lebih lama daripada satu tahun di Venus.', en: 'A day on Venus is longer than a year on Venus.' },
  { id: 'Bank memori komputer pertama seukuran lemari es hanya untuk menyimpan beberapa kilobyte data.', en: 'The first computer memory banks were the size of a refrigerator, holding only a few kilobytes of data.' },
  { id: 'Gurita punya tiga jantung dan darah berwarna biru.', en: 'An octopus has three hearts and blue blood.' },
  { id: 'Kata "OK" adalah salah satu kata yang paling banyak dikenali di seluruh dunia.', en: 'The word "OK" is one of the most recognized words in the world.' },
  { id: 'Manusia berbagi sekitar 60% DNA dengan pisang.', en: 'Humans share about 60% of their DNA with bananas.' },
  { id: 'Bintang laut tidak punya otak sama sekali.', en: 'A starfish has no brain at all.' },
  { id: 'Suara petir bisa mencapai suhu 5 kali lebih panas dari permukaan matahari.', en: 'A lightning bolt can reach temperatures five times hotter than the surface of the sun.' },
  { id: 'Ada lebih banyak kemungkinan susunan kartu remi dibanding jumlah atom di planet Bumi.', en: 'There are more possible shuffles of a deck of cards than atoms on Earth.' },
  { id: 'Wombat buang air besar berbentuk kubus.', en: 'Wombats produce cube-shaped poop.' },
  { id: 'Otak manusia menggunakan sekitar 20% energi tubuh meski cuma 2% dari berat badan.', en: "The human brain uses about 20% of the body's energy despite being only 2% of its weight." },
  { id: 'Belut listrik bisa menghasilkan kejutan listrik hingga 600 volt.', en: 'Electric eels can generate shocks up to 600 volts.' },
  { id: 'Kucing menghabiskan sekitar 70% hidupnya untuk tidur.', en: 'Cats spend about 70% of their lives sleeping.' },
  { id: 'Awan raksasa bisa memiliki berat lebih dari satu juta kilogram.', en: 'A giant cloud can weigh over a million kilograms.' },
  { id: 'Discord awalnya dibuat khusus untuk komunitas gamer sebelum berkembang jadi platform komunikasi umum.', en: 'Discord was originally made for gaming communities before growing into a general communication platform.' },
  { id: 'Air panas bisa membeku lebih cepat daripada air dingin dalam kondisi tertentu, fenomena ini disebut efek Mpemba.', en: 'Hot water can freeze faster than cold water under certain conditions, a phenomenon called the Mpemba effect.' },
];

module.exports = {
  data: new SlashCommandBuilder().setName('fact').setDescription('Dapatkan fakta unik secara acak'),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const fact = FACTS[Math.floor(Math.random() * FACTS.length)];
    const embed = baseEmbed().setTitle(t(lang, 'fact.title')).setDescription(lang === 'id' ? fact.id : fact.en);
    return interaction.reply({ embeds: [embed] });
  },
};
