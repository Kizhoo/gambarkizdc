// ============================================================================
// TUNNEL — expose dashboard lokal ke publik pakai Cloudflare Quick Tunnel.
// ----------------------------------------------------------------------------
// Dipakai kalau hosting-nya gak izinin akses langsung ke port dashboard
// (misal MonkeyBytes/panel gratis lain yang reset koneksi ke port non-bot).
// Gak perlu akun Cloudflare — otomatis generate URL acak *.trycloudflare.com
// tiap kali bot start.
//
// Catatan implementasi: dijalanin manual (spawn binary + baca output),
// BUKAN pakai helper tinggi-level dari package "cloudflared" (versi
// tunnel()-nya kadang gak konsisten antar rilis). Pakai fungsi low-level
// "bin" (path binary) & "install" (download binary) yang lebih stabil.
//
// Aktifkan lewat .env: ENABLE_TUNNEL=true
// ============================================================================

const fs = require('fs');
const { spawn } = require('child_process');

const URL_REGEX = /https:\/\/[a-zA-Z0-9-]+\.trycloudflare\.com/;

let activeChild = null;

async function startTunnel(port, onReady) {
  // Pengaman v6: di lingkungan panel Pterodactyl/MonkeyBytes (folder /home/container
  // ada), tunnel SELALU ditolak walau ENABLE_TUNNEL=true tertinggal dari .env lama -
  // ToS hosting melarang tunneling dan pelanggarannya berujung suspend/ban akun.
  if (require('fs').existsSync('/home/container')) {
    console.warn('[Tunnel] Lingkungan panel hosting terdeteksi (/home/container) - tunnel DITOLAK demi kepatuhan ToS. Gunakan tunnel hanya di dev lokal / hosting lain yang mengizinkan.');
    return;
  }
  // PERINGATAN ToS: banyak shared hosting (termasuk MonkeyBytes Hosting)
  // MELARANG tunneling/proxy lewat infrastruktur mereka. Aktifkan fitur ini
  // HANYA di mesin lokal atau hosting yang mengizinkan. Lihat HOSTING.md.
  console.warn('[Tunnel] PERINGATAN: tunneling dilarang di banyak shared hosting (mis. MonkeyBytes).');
  console.warn('[Tunnel] Pastikan hosting-mu mengizinkannya sebelum lanjut (lihat HOSTING.md).');
  let bin, install;
  try {
    ({ bin, install } = require('cloudflared'));
  } catch {
    console.error('[Tunnel] Package "cloudflared" belum diinstall. Jalankan: npm i cloudflared');
    return null;
  }

  try {
    if (!fs.existsSync(bin)) {
      console.log('[Tunnel] Mengunduh binary cloudflared (sekali saja)...');
      await install(bin);
    }
  } catch (err) {
    console.error('[Tunnel] Gagal mengunduh binary cloudflared:', err.message || err);
    return null;
  }

  console.log('[Tunnel] Memulai Cloudflare Quick Tunnel...');
  const child = spawn(bin, ['tunnel', '--url', `http://localhost:${port}`]);
  activeChild = child;

  let found = false;
  const handleOutput = (data) => {
    if (found) return;
    const text = data.toString();
    const match = text.match(URL_REGEX);
    if (match) {
      found = true;
      console.log(`[Tunnel] Dashboard publik siap: ${match[0]}`);
      if (typeof onReady === 'function') onReady(match[0]);
    }
  };

  // cloudflared biasanya nulis URL-nya ke stderr, bukan stdout — dengerin dua-duanya.
  child.stdout.on('data', handleOutput);
  child.stderr.on('data', handleOutput);

  child.on('error', (err) => {
    console.error('[Tunnel] Gagal menjalankan cloudflared:', err.message || err);
  });

  child.on('exit', (code) => {
    console.log(`[Tunnel] Proses cloudflared berhenti (code ${code}).`);
    activeChild = null;
  });

  return child;
}

function stopTunnel() {
  if (activeChild) {
    activeChild.kill();
    activeChild = null;
  }
}

module.exports = { startTunnel, stopTunnel };
