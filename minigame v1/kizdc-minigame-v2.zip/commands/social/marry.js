const { SlashCommandBuilder } = require('discord.js');
const { getMarriage, createMarriage } = require('../../database/db');
const { errorEmbed } = require('../../utils/embeds');
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('marry')
    .setDescription('Ajak member lain menikah (perlu konfirmasi dari yang diajak)')
    .addUserOption(o => o.setName('pasangan').setDescription('Orang yang ingin kamu ajak menikah').setRequired(true)),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const proposer = interaction.user;
    const target = interaction.options.getUser('pasangan');

    if (target.id === proposer.id) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'marry.self'))], ephemeral: true });
    }
    if (target.bot) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'marry.bot'))], ephemeral: true });
    }

    const proposerMarriage = getMarriage(interaction.guild.id, proposer.id);
    if (proposerMarriage) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'marry.already', { p: proposerMarriage.partnerId }))], ephemeral: true });
    }

    const targetMarriage = getMarriage(interaction.guild.id, target.id);
    if (targetMarriage) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'marry.taken', { t: target.username }))], ephemeral: true });
    }

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('marry_accept').setLabel(t(lang, 'marry.accept')).setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('marry_decline').setLabel(t(lang, 'marry.decline')).setStyle(ButtonStyle.Danger),
    );

    await interaction.reply({
      content: t(lang, 'marry.propose', { t: target.toString(), p: proposer.toString() }),
      components: [row],
    });
    const message = await interaction.fetchReply();

    const collector = message.createMessageComponentCollector({ componentType: ComponentType.Button, time: 60000, max: 1 });

    collector.on('collect', async i => {
      if (i.user.id !== target.id) {
        return i.reply({ content: t(lang, 'marry.only_target'), ephemeral: true });
      }

      if (i.customId === 'marry_accept') {
        const proposerCheck = getMarriage(interaction.guild.id, proposer.id);
        const targetCheck = getMarriage(interaction.guild.id, target.id);
        if (proposerCheck || targetCheck) {
          return i.update({ content: t(lang, 'marry.fail'), components: [] });
        }
        createMarriage(interaction.guild.id, proposer.id, target.id);
        return i.update({ content: t(lang, 'marry.ok', { p: proposer.toString(), t: target.toString() }), components: [] });
      }

      return i.update({ content: t(lang, 'marry.declined', { t: target.toString(), p: proposer.toString() }), components: [] });
    });

    collector.on('end', collected => {
      if (collected.size === 0) {
        interaction.editReply({ content: t(lang, 'marry.timeout'), components: [] }).catch(() => {});
      }
    });
  },
};
