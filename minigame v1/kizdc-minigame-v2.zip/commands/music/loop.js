const { SlashCommandBuilder } = require('discord.js');
const { getValidPlayer, safePlayerAction } = require('../../utils/musicGuard');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('loop')
    .setDescription('Atur mode pengulangan musik')
    .addStringOption(o => o.setName('mode').setDescription('Mode loop').setRequired(true)
      .addChoices(
        { name: 'Mati', value: 'none' },
        { name: 'Lagu Ini', value: 'track' },
        { name: 'Semua Antrian', value: 'queue' },
      )),
  async execute(interaction, client) {
    const lang = guildLang(interaction);
    const player = await getValidPlayer(interaction, client);
    if (!player) return;

    const mode = interaction.options.getString('mode');

    if (typeof player.setLoop !== 'function') {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'music.loop_unavailable'))], ephemeral: true });
    }

    const labels = { none: t(lang, 'music.loop_none'), track: t(lang, 'music.loop_track'), queue: t(lang, 'music.loop_queue') };
    return safePlayerAction(interaction, () => player.setLoop(mode), { embeds: [successEmbed(t(lang, 'music.loop_set', { m: labels[mode] }))] });
  },
};
