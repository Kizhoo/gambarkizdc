const { EmbedBuilder } = require('discord.js');
const { getReactionRole, getGuildConfig, getStarboardPost, addStarboardPost } = require('../database/db');
const { reactionKey } = require('../utils/emojiUtil');
const config = require('../config.json');

module.exports = {
  name: 'messageReactionAdd',
  async execute(reaction, user) {
    if (user.bot) return;

    try {
      if (reaction.partial) await reaction.fetch();
      if (reaction.message.partial) await reaction.message.fetch();
    } catch (err) {
      return; // pesan/reaction sudah dihapus, abaikan
    }

    const message = reaction.message;
    if (!message.guild) return;

    // ===== REACTION ROLES =====
    const key = reactionKey(reaction);
    const mapping = getReactionRole(message.guild.id, message.id, key);
    if (mapping) {
      const member = await message.guild.members.fetch(user.id).catch(() => null);
      const role = message.guild.roles.cache.get(mapping.roleId);
      if (member && role) {
        member.roles.add(role).catch(() => {});
      }
    }

    // ===== STARBOARD =====
    if (reaction.emoji.name === '⭐') {
      const cfg = getGuildConfig(message.guild.id);
      if (!cfg.starboardChannelId) return;
      if (message.author?.bot) return;

      const starCount = reaction.count;
      const threshold = cfg.starboardThreshold || 3;
      if (starCount < threshold) return;

      const starboardChannel = message.guild.channels.cache.get(cfg.starboardChannelId);
      if (!starboardChannel) return;

      const existing = getStarboardPost(message.guild.id, message.id);
      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL() })
        .setDescription(message.content || '*(tidak ada teks)*')
        .addFields({ name: 'Sumber', value: `[Lompat ke pesan](${message.url})` })
        .setFooter({ text: `⭐ ${starCount} | #${message.channel.name}` })
        .setTimestamp(message.createdAt);

      const imageAttachment = [...message.attachments.values()].find(a => a.contentType?.startsWith('image/'));
      if (imageAttachment) embed.setImage(imageAttachment.url);

      if (existing) {
        const starMsg = await starboardChannel.messages.fetch(existing.starboardMessageId).catch(() => null);
        if (starMsg) {
          await starMsg.edit({ content: `⭐ **${starCount}** | ${message.channel}`, embeds: [embed] }).catch(() => {});
        }
      } else {
        const sent = await starboardChannel.send({ content: `⭐ **${starCount}** | ${message.channel}`, embeds: [embed] }).catch(() => null);
        if (sent) addStarboardPost(message.guild.id, message.id, sent.id);
      }
    }
  },
};
