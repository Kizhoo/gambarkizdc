const { sendLog } = require('../utils/serverLog');
const config = require('../config.json');

module.exports = {
  name: 'messageDeleteBulk',
  async execute(messages) {
    const first = messages.first();
    if (!first?.guild) return;
    sendLog(first.guild, {
      title: 'Pesan Dihapus Massal',
      color: config.errorColor,
      fields: [
        { name: 'Jumlah', value: `${messages.size} pesan`, inline: true },
        { name: 'Channel', value: `${first.channel}`, inline: true },
      ],
    });
  },
};
