const { createCanvas, loadImage } = require('@napi-rs/canvas');
const { fetchExternal } = require('./httpClient');
const fs = require('fs');
const { drawImageCover } = require('./canvasUtils');
const { hasCustomBackground, backgroundPathFor, resolveAccent } = require('./welcomeCard');
const { t } = require('./i18n');

function roundedRect(ctx, x, y, w, h, r) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + w, y, x + w, y + h, radius);
  ctx.arcTo(x + w, y + h, x, y + h, radius);
  ctx.arcTo(x, y + h, x, y, radius);
  ctx.arcTo(x, y, x + w, y, radius);
  ctx.closePath();
}

function fitText(ctx, text, maxWidth, startSize, weight = 700) {
  let size = startSize;
  do {
    ctx.font = `${weight} ${size}px sans-serif`;
    if (ctx.measureText(text).width <= maxWidth) break;
    size -= 2;
  } while (size > 18);
  return size;
}

function clippedText(ctx, text, maxWidth) {
  let value = String(text || '—');
  if (ctx.measureText(value).width <= maxWidth) return value;
  while (value.length > 1 && ctx.measureText(`${value}…`).width > maxWidth) value = value.slice(0, -1);
  return `${value}…`;
}

function field(ctx, label, value, x, y, width, accent) {
  ctx.fillStyle = '#94A3B8';
  ctx.font = '600 17px sans-serif';
  ctx.fillText(label.toUpperCase(), x, y);
  ctx.fillStyle = '#F8FAFC';
  ctx.font = '700 23px sans-serif';
  ctx.fillText(clippedText(ctx, value, width), x, y + 31);
  ctx.fillStyle = accent;
  ctx.fillRect(x, y + 43, Math.min(width, 52), 3);
}

async function downloadImage(url) {
  const response = await fetchExternal(url, {}, 1);
  if (!response.ok) throw new Error(`Gagal memuat avatar (${response.status})`);
  return loadImage(Buffer.from(await response.arrayBuffer()));
}

async function renderProfileCard({ user, member, guild, profile, registration, level, economy, inventory, marriage, birthday }) {
  const width = 1200;
  const height = 675;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');
  const accent = /^#[0-9a-f]{6}$/i.test(profile.color) ? profile.color : '#5865F2';

  const gradient = ctx.createLinearGradient(0, 0, width, height);
  gradient.addColorStop(0, '#08111F');
  gradient.addColorStop(0.55, '#111827');
  gradient.addColorStop(1, '#050816');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);

  ctx.globalAlpha = 0.18;
  ctx.fillStyle = accent;
  ctx.beginPath(); ctx.arc(1080, 60, 300, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc(80, 650, 240, 0, Math.PI * 2); ctx.fill();
  ctx.globalAlpha = 1;

  roundedRect(ctx, 42, 38, 1116, 599, 32);
  ctx.fillStyle = 'rgba(15, 23, 42, .82)';
  ctx.fill();
  ctx.strokeStyle = 'rgba(148, 163, 184, .20)';
  ctx.lineWidth = 2;
  ctx.stroke();

  ctx.fillStyle = accent;
  roundedRect(ctx, 42, 38, 1116, 11, 6); ctx.fill();

  const avatar = await downloadImage(user.displayAvatarURL({ extension: 'png', size: 512 }));
  ctx.save();
  ctx.beginPath(); ctx.arc(190, 182, 100, 0, Math.PI * 2); ctx.clip();
  ctx.drawImage(avatar, 90, 82, 200, 200);
  ctx.restore();
  ctx.strokeStyle = accent; ctx.lineWidth = 8;
  ctx.beginPath(); ctx.arc(190, 182, 105, 0, Math.PI * 2); ctx.stroke();

  const statusColor = member?.presence?.status === 'online' ? '#22C55E'
    : member?.presence?.status === 'idle' ? '#F59E0B'
      : member?.presence?.status === 'dnd' ? '#EF4444' : '#64748B';
  ctx.fillStyle = statusColor; ctx.beginPath(); ctx.arc(265, 252, 22, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = '#0F172A'; ctx.lineWidth = 7; ctx.stroke();

  const displayName = member?.displayName || user.globalName || user.username;
  fitText(ctx, displayName, 690, 48, 800);
  ctx.fillStyle = '#F8FAFC'; ctx.fillText(displayName, 330, 128);
  ctx.font = '500 23px sans-serif'; ctx.fillStyle = '#94A3B8';
  ctx.fillText(`@${user.username}  •  ${user.id}`, 332, 165);

  const chips = [
    user.bot ? 'BOT' : 'MEMBER',
    `LEVEL ${level.level}`,
    registration ? 'REGISTERED' : 'GUEST',
    member?.premiumSinceTimestamp ? 'BOOSTER' : null,
  ].filter(Boolean);
  let chipX = 330;
  for (const chip of chips) {
    ctx.font = '700 15px sans-serif';
    const chipW = ctx.measureText(chip).width + 28;
    roundedRect(ctx, chipX, 190, chipW, 35, 18);
    ctx.fillStyle = `${accent}33`; ctx.fill();
    ctx.strokeStyle = `${accent}AA`; ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = '#E2E8F0'; ctx.fillText(chip, chipX + 14, 213);
    chipX += chipW + 10;
  }

  ctx.fillStyle = '#CBD5E1'; ctx.font = '500 20px sans-serif';
  const bio = profile.bio || 'Belum ada bio. Gunakan /profile set-bio untuk menambahkannya.';
  ctx.fillText(clippedText(ctx, bio, 790), 330, 263);

  field(ctx, 'XP', `${level.xp.toLocaleString('id-ID')} / ${level.needed.toLocaleString('id-ID')}`, 92, 354, 240, accent);
  field(ctx, 'Cash', economy.balance.toLocaleString('id-ID'), 370, 354, 205, accent);
  field(ctx, 'Bank', economy.bank.toLocaleString('id-ID'), 614, 354, 205, accent);
  field(ctx, 'Inventory', `${inventory.length} item`, 858, 354, 205, accent);

  field(ctx, 'Bergabung', member?.joinedTimestamp ? new Date(member.joinedTimestamp).toLocaleDateString('id-ID') : '—', 92, 458, 240, accent);
  field(ctx, 'Akun dibuat', new Date(user.createdTimestamp).toLocaleDateString('id-ID'), 370, 458, 205, accent);
  field(ctx, 'Pronouns', profile.pronouns || '—', 614, 458, 205, accent);
  field(ctx, 'Lokasi', profile.location || '—', 858, 458, 205, accent);

  const relations = marriage ? `Pasangan: ${marriage.partnerId}` : 'Belum menikah';
  const birthdayText = birthday ? `${birthday.day}/${birthday.month}` : 'Belum diatur';
  const topRole = member?.roles?.highest?.name && member.roles.highest.id !== guild.id ? member.roles.highest.name : 'Member';
  ctx.fillStyle = '#94A3B8'; ctx.font = '500 16px sans-serif';
  ctx.fillText(clippedText(ctx, `${topRole}  •  ${relations}  •  Ultah: ${birthdayText}  •  ${guild.name}`, 1000), 92, 594);

  return canvas.toBuffer('image/png');
}

// ---------- NOTIF NAIK LEVEL (level GABUNG: chat & RPG pakai level yang sama) ----------
// Background & warna aksen disinkronkan dengan kartu welcome supaya konsisten:
// Latar kartu rank per-user (sama dengan dashboard profile RANK_BG + foto custom).
const CARD_BG = {
  senja: ['#1e1b4b', '#7c2d92', '#f97316'], aurora: ['#0b1120', '#14532d', '#38bdf8'],
  laut: ['#020617', '#0c4a6e', '#22d3ee'], hutan: ['#052e16', '#166534', '#4ade80'],
  nebula: ['#1e1b4b', '#7c3aed', '#ec4899'], emas: ['#451a03', '#b45309', '#fbbf24'],
  salju: ['#1e293b', '#475569', '#e2e8f0'], gurun: ['#431407', '#c2410c', '#fbbf24'],
  obsidian: ['#0a0a0a', '#1f2937', '#4b5563'], kristal: ['#0f172a', '#155e75', '#a5f3fc'],
};
async function drawCardBackground(ctx, width, height, cardBg, cardBgUrl) {
  if (cardBgUrl && /^https?:\/\//i.test(cardBgUrl)) {
    try {
      const img = await loadImage(cardBgUrl);
      if (img) { drawImageCover(ctx, img, 0, 0, width, height); return; }
    } catch (_) { /* fallback */ }
  }
  const c = CARD_BG[cardBg] || CARD_BG.senja;
  const g = ctx.createLinearGradient(0, 0, width, height);
  g.addColorStop(0, c[0]); g.addColorStop(0.5, c[1]); g.addColorStop(1, c[2]);
  ctx.fillStyle = g; ctx.fillRect(0, 0, width, height);
}

// kalau admin set background welcome, notif level-up otomatis ikut pakai background itu.
async function renderLevelUpNotifCard({ user, member, oldLevel, newLevel, xp, needed, goldBonus, newBalance, roleName, guildId, accent, language = 'id', cardBg, cardBgUrl }) {
  const width = 1000, height = 380;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');
  const color = resolveAccent(accent) || '#57F287';

  // ===== BACKGROUND: prioritas foto custom > latar kartu rank > welcome > gradient =====
  let bgImg = null;
  if (!cardBgUrl && !cardBg && guildId && hasCustomBackground(guildId)) {
    try { bgImg = await loadImage(fs.readFileSync(backgroundPathFor(guildId))); } catch { bgImg = null; }
  }
  if (cardBgUrl || cardBg) {
    await drawCardBackground(ctx, width, height, cardBg, cardBgUrl);
    const overlay = ctx.createLinearGradient(0, 0, width, 0);
    overlay.addColorStop(0, 'rgba(3,6,14,0.72)'); overlay.addColorStop(1, 'rgba(3,6,14,0.35)');
    ctx.fillStyle = overlay; ctx.fillRect(0, 0, width, height);
  } else if (bgImg) {
    drawImageCover(ctx, bgImg, 0, 0, width, height);
    const overlay = ctx.createLinearGradient(0, 0, width, 0);
    overlay.addColorStop(0, 'rgba(3,6,14,0.92)');
    overlay.addColorStop(1, 'rgba(3,6,14,0.55)');
    ctx.fillStyle = overlay; ctx.fillRect(0, 0, width, height);
  } else {
    const gradient = ctx.createLinearGradient(0, 0, width, height);
    gradient.addColorStop(0, '#0B1120'); gradient.addColorStop(1, '#111827');
    ctx.fillStyle = gradient; ctx.fillRect(0, 0, width, height);
    const glow = ctx.createRadialGradient(160, 130, 30, 160, 130, 480);
    glow.addColorStop(0, `${color}55`); glow.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = glow; ctx.fillRect(0, 0, width, height);
  }

  // frame tipis + strip aksen kiri
  ctx.strokeStyle = 'rgba(255,255,255,0.08)'; ctx.lineWidth = 2;
  roundedRect(ctx, 8, 8, width - 16, height - 16, 26); ctx.stroke();
  ctx.fillStyle = color; roundedRect(ctx, 0, 0, 12, height, 6); ctx.fill();

  const avatar = await downloadImage(user.displayAvatarURL({ extension: 'png', size: 256 }));
  ctx.save();
  ctx.beginPath(); ctx.arc(150, 150, 80, 0, Math.PI * 2); ctx.clip();
  ctx.drawImage(avatar, 70, 70, 160, 160);
  ctx.restore();
  ctx.strokeStyle = color; ctx.lineWidth = 6;
  ctx.beginPath(); ctx.arc(150, 150, 83, 0, Math.PI * 2); ctx.stroke();

  ctx.fillStyle = color; ctx.font = '800 34px sans-serif';
  ctx.fillText(t(language, 'levelup.kicker'), 270, 78);
  ctx.fillStyle = '#F8FAFC'; ctx.font = '700 28px sans-serif';
  ctx.fillText(member?.displayName || user.username, 270, 118);

  ctx.textAlign = 'center';
  ctx.fillStyle = '#64748B'; ctx.font = '800 70px sans-serif';
  ctx.fillText(String(oldLevel), 330, 235);
  ctx.fillStyle = color; ctx.font = '700 46px sans-serif';
  ctx.fillText('→', 430, 227);
  ctx.fillStyle = '#86EFAC'; ctx.font = '800 88px sans-serif';
  ctx.fillText(String(newLevel), 545, 240);
  ctx.textAlign = 'left';

  const barX = 270, barY = 260, barW = 420, barH = 20;
  ctx.fillStyle = '#1E293B'; roundedRect(ctx, barX, barY, barW, barH, 10); ctx.fill();
  const pct = needed > 0 ? Math.max(0.02, Math.min(1, xp / needed)) : 1;
  ctx.fillStyle = color; roundedRect(ctx, barX, barY, barW * pct, barH, 10); ctx.fill();
  ctx.fillStyle = '#CBD5E1'; ctx.font = '600 15px sans-serif';
  ctx.fillText(`${xp.toLocaleString('id-ID')}/${needed.toLocaleString('id-ID')} XP`, barX, barY + barH + 22);

  // gold bonus chip — penghubung level ke economy
  const chipW = 250, chipY = 258;
  roundedRect(ctx, 720, chipY, chipW, 60, 14);
  ctx.fillStyle = 'rgba(250, 204, 21, 0.16)'; ctx.fill();
  ctx.strokeStyle = 'rgba(250, 204, 21, 0.55)'; ctx.lineWidth = 2;
  roundedRect(ctx, 720, chipY, chipW, 60, 14); ctx.stroke();
  ctx.beginPath(); ctx.arc(736, chipY + 19, 6, 0, Math.PI * 2); ctx.fillStyle = '#FACC15'; ctx.fill();
  ctx.fillStyle = '#FACC15'; ctx.font = '800 22px sans-serif';
  ctx.fillText(t(language, 'levelup.gold_bonus', { amount: goldBonus.toLocaleString('id-ID') }), 750, chipY + 26);
  ctx.fillStyle = '#94A3B8'; ctx.font = '500 15px sans-serif';
  ctx.fillText(t(language, 'levelup.saldo', { amount: newBalance.toLocaleString('id-ID') }), 736, chipY + 48);

  if (roleName) {
    ctx.fillStyle = '#94A3B8'; ctx.font = '500 17px sans-serif';
    ctx.fillText(t(language, 'levelup.role_new', { role: roleName }), 270, 345);
  }

  return canvas.toBuffer('image/png');
}

module.exports = { renderProfileCard, renderLevelUpNotifCard };
