const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getGuildConfig, updateGuildConfig } = require('../../database/db');
const { successEmbed, errorEmbed, baseEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('admin')
    .setDescription('Konfigurasi & tools admin server')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub => sub.setName('autorole-set').setDescription('Atur role otomatis untuk member baru')
      .addRoleOption(o => o.setName('role').setDescription('Role yang akan diberikan otomatis').setRequired(true)))
    .addSubcommand(sub => sub.setName('autorole-remove').setDescription('Matikan role otomatis untuk member baru'))
    .addSubcommand(sub => sub.setName('logchannel-set').setDescription('Atur channel log server')
      .addChannelOption(o => o.setName('channel').setDescription('Channel untuk log').addChannelTypes(ChannelType.GuildText).setRequired(true)))
    .addSubcommand(sub => sub.setName('togglemodlog').setDescription('Nyalakan/matikan log otomatis (edit/hapus pesan, ban/unban)'))
    .addSubcommand(sub => sub.setName('config').setDescription('Lihat semua konfigurasi bot di server ini'))
    .addSubcommand(sub => sub.setName('role-add').setDescription('Beri role ke member')
      .addUserOption(o => o.setName('target').setDescription('Member yang akan diberi role').setRequired(true))
      .addRoleOption(o => o.setName('role').setDescription('Role yang akan diberikan').setRequired(true)))
    .addSubcommand(sub => sub.setName('role-remove').setDescription('Cabut role dari member')
      .addUserOption(o => o.setName('target').setDescription('Member yang akan dicabut rolenya').setRequired(true))
      .addRoleOption(o => o.setName('role').setDescription('Role yang akan dicabut').setRequired(true)))
    .addSubcommand(sub => sub.setName('verify-setup').setDescription('Kirim panel verifikasi member baru di channel ini')
      .addRoleOption(o => o.setName('role').setDescription('Role yang diberikan setelah verifikasi').setRequired(true))),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    // ===== AUTOROLE =====
    if (sub === 'autorole-set') {
      const role = interaction.options.getRole('role');
      updateGuildConfig(interaction.guild.id, { autoroleId: role.id });
      return interaction.reply({ embeds: [successEmbed(`Autorole diatur ke ${role}. Member baru otomatis dapat role ini.`)] });
    }

    if (sub === 'autorole-remove') {
      updateGuildConfig(interaction.guild.id, { autoroleId: null });
      return interaction.reply({ embeds: [successEmbed('Autorole berhasil dimatikan.')] });
    }

    // ===== LOG CHANNEL =====
    if (sub === 'logchannel-set') {
      const channel = interaction.options.getChannel('channel');
      updateGuildConfig(interaction.guild.id, { logChannel: channel.id });
      return interaction.reply({ embeds: [successEmbed(`Log channel diatur ke ${channel}.`)] });
    }

    if (sub === 'togglemodlog') {
      const cfg = getGuildConfig(interaction.guild.id);
      if (!cfg.logChannel) {
        return interaction.reply({ embeds: [errorEmbed('Atur log channel dulu dengan `/admin logchannel-set`.')], ephemeral: true });
      }
      const newState = cfg.modLogEnabled ? 0 : 1;
      updateGuildConfig(interaction.guild.id, { modLogEnabled: newState });
      return interaction.reply({ embeds: [successEmbed(`Mod log sekarang **${newState ? 'AKTIF' : 'NONAKTIF'}**.`)] });
    }

    // ===== CONFIG VIEW =====
    if (sub === 'config') {
      const cfg = getGuildConfig(interaction.guild.id);
      const fmt = (id, type = 'channel') => {
        if (!id) return '*Belum diatur*';
        return type === 'channel' ? `<#${id}>` : `<@&${id}>`;
      };

      const embed = baseEmbed()
        .setTitle(`Konfigurasi ${interaction.guild.name}`)
        .addFields(
          { name: 'Welcome Channel', value: `${fmt(cfg.welcomeChannel)} (${cfg.welcomeEnabled ? 'Aktif' : 'Nonaktif'})`, inline: true },
          { name: 'Goodbye Channel', value: `${fmt(cfg.goodbyeChannel)} (${cfg.goodbyeEnabled ? 'Aktif' : 'Nonaktif'})`, inline: true },
          { name: 'Autorole', value: fmt(cfg.autoroleId, 'role'), inline: true },
          { name: 'Log Channel', value: fmt(cfg.logChannel), inline: true },
          { name: 'Mod Log', value: cfg.modLogEnabled ? 'Aktif' : 'Nonaktif', inline: true },
          { name: 'Level Up Channel', value: fmt(cfg.levelUpChannel), inline: true },
          { name: 'Automod', value: cfg.automodEnabled ? 'Aktif' : 'Nonaktif', inline: true },
          { name: 'Anti-Link', value: cfg.antiLinkEnabled ? 'Aktif' : 'Nonaktif', inline: true },
          { name: 'Anti-Spam', value: cfg.antiSpamEnabled ? 'Aktif' : 'Nonaktif', inline: true },
          { name: 'Anti-Raid', value: `${cfg.antiraidEnabled ? 'Aktif' : 'Nonaktif'} (min ${cfg.minAccountAgeDays || 3} hari)`, inline: true },
          { name: 'Ticket Category', value: fmt(cfg.ticketCategoryId), inline: true },
          { name: 'Starboard', value: fmt(cfg.starboardChannelId), inline: true },
        );
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    // ===== ROLE ADD/REMOVE =====
    if (sub === 'role-add' || sub === 'role-remove') {
      const target = interaction.options.getMember('target');
      const role = interaction.options.getRole('role');

      if (role.position >= interaction.guild.members.me.roles.highest.position) {
        return interaction.reply({ embeds: [errorEmbed('Aku tidak bisa mengubah role ini karena posisinya lebih tinggi dariku.')], ephemeral: true });
      }

      if (sub === 'role-add') {
        await target.roles.add(role);
        return interaction.reply({ embeds: [successEmbed(`Role ${role} berhasil diberikan ke **${target.user.tag}**.`)] });
      } else {
        await target.roles.remove(role);
        return interaction.reply({ embeds: [successEmbed(`Role ${role} berhasil dicabut dari **${target.user.tag}**.`)] });
      }
    }

    // ===== VERIFY SETUP =====
    if (sub === 'verify-setup') {
      const role = interaction.options.getRole('role');
      if (role.position >= interaction.guild.members.me.roles.highest.position) {
        return interaction.reply({ embeds: [errorEmbed('Aku tidak bisa memberi role ini karena posisinya lebih tinggi dariku.')], ephemeral: true });
      }

      updateGuildConfig(interaction.guild.id, { verifyRoleId: role.id, verifyChannelId: interaction.channel.id });

      const embed = new EmbedBuilder()
        .setColor('#2b2d31')
        .setTitle('Verifikasi Member')
        .setDescription('Klik tombol di bawah untuk verifikasi dan dapatkan akses penuh ke server ini.');

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('verify_button').setLabel('Verifikasi Saya').setStyle(ButtonStyle.Success)
      );

      await interaction.channel.send({ embeds: [embed], components: [row] });
      return interaction.reply({ embeds: [successEmbed(`Panel verifikasi berhasil dikirim. Role ${role} akan diberikan setelah klik tombol.`)], ephemeral: true });
    }
  },
};
