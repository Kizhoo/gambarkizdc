const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const CATEGORY_INFO = require('../../utils/categoryInfo');
const { getGuildConfig } = require('../../database/db');
const { t } = require('../../utils/i18n');

function commandLabel(command) {
  const json = command.data.toJSON();
  const subcommands = (json.options || []).filter(option => option.type === 1).length;
  return `**/${json.name}**${subcommands ? ` — ${json.description} · ${subcommands} subcommand` : ` — ${json.description}`}`;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Lihat semua command dan subcommand yang tersedia')
    .addStringOption(option => option.setName('kategori').setDescription('Pilih kategori command').setAutocomplete(true)),

  async autocomplete(interaction, client) {
    const query = interaction.options.getFocused().toLowerCase();
    const choices = client.categories
      .filter(category => category.includes(query) || (CATEGORY_INFO[category]?.label || '').toLowerCase().includes(query))
      .slice(0, 25)
      .map(category => ({ name: CATEGORY_INFO[category]?.label || category, value: category }));
    return interaction.respond(choices);
  },

  async execute(interaction, client) {
    const lang = getGuildConfig(interaction.guild.id).language || 'id';
    const categoryFilter = interaction.options.getString('kategori')?.toLowerCase();
    if (categoryFilter && !client.categories.includes(categoryFilter)) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'help.not_found', { cat: categoryFilter }))], ephemeral: true });
    }

    const embed = baseEmbed().setTitle(`${t(lang, 'help.title')} — ${client.user.username}`);
    if (categoryFilter) {
      const commands = [...client.commands.values()].filter(command => command.category === categoryFilter).sort((a, b) => a.data.name.localeCompare(b.data.name));
      const info = CATEGORY_INFO[categoryFilter];
      embed.setTitle(info?.label || categoryFilter)
        .setDescription(commands.map(commandLabel).join('\n') || t(lang, 'help.none'))
        .setFooter({ text: t(lang, 'help.footer_count', { n: commands.length }) });
    } else {
      for (const category of client.categories) {
        const commands = [...client.commands.values()].filter(command => command.category === category);
        if (!commands.length) continue;
        const info = CATEGORY_INFO[category];
        embed.addFields({
          name: `${info?.label || category} (${commands.length})`,
          value: commands.sort((a, b) => a.data.name.localeCompare(b.data.name)).map(command => `\`/${command.data.name}\``).join(' '),
        });
      }
      embed.setDescription(t(lang, 'help.desc', { n: client.commands.size, c: client.categories.length }))
        .setFooter({ text: t(lang, 'help.footer_slots', { n: 100 - client.commands.size }) });
    }
    return interaction.reply({ embeds: [embed] });
  },
};
