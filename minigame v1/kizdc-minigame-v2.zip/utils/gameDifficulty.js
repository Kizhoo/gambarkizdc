// ============================================================================
// PILIH DIFFICULTY LAWAN AI — dipakai bareng oleh chess/tictactoe/connectfour
// ----------------------------------------------------------------------------
// Cuma relevan buat mode "vs AI" (lawan member manusia tidak butuh difficulty -
// yang beda-beda kekuatannya cuma AI-nya). Ditampilkan lewat tombol Easy/Medium/
// Hard/Extreme SETELAH pemilihan batas waktu (lihat gameTimeControl.js), pakai
// message yang sama (message.edit) biar tidak numpuk banyak pesan buat 1 game.
// ============================================================================
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, EmbedBuilder } = require('discord.js');
const settings = require('./settings');

const DIFFICULTIES = [
  { key: 'easy', label: 'Easy', desc: 'Santai, AI sering asal jalan - cocok buat pemula.' },
  { key: 'medium', label: 'Medium', desc: 'AI mikir tapi masih suka salah langkah.' },
  { key: 'hard', label: 'Hard', desc: 'AI jarang blunder, main cukup serius.' },
  { key: 'extreme', label: 'Extreme', desc: 'AI main sekuat mungkin, nyaris tidak pernah salah.' },
];
const DIFFICULTY_KEYS = DIFFICULTIES.map(d => d.key);
const STYLE_BY_KEY = { easy: ButtonStyle.Success, medium: ButtonStyle.Primary, hard: ButtonStyle.Danger, extreme: ButtonStyle.Danger };

function buildDifficultyRow(prefix) {
  const row = new ActionRowBuilder();
  for (const d of DIFFICULTIES) {
    row.addComponents(new ButtonBuilder().setCustomId(`${prefix}_diff_${d.key}`).setLabel(d.label).setStyle(STYLE_BY_KEY[d.key]));
  }
  return row;
}

// Tampilkan pilihan difficulty lewat message yang SUDAH ADA (hasil dari pickTimeControl),
// pakai message.edit + awaitMessageComponent di message yang sama. Return { key, label, message }.
async function pickDifficulty(message, authorId, { gameTitle, prefix }) {
  const defaultKey = DIFFICULTY_KEYS.includes(settings.get('games.defaultAiDifficulty')) ? settings.get('games.defaultAiDifficulty') : 'hard';
  const defaultLabel = DIFFICULTIES.find(d => d.key === defaultKey)?.label || 'Hard';
  const embed = new EmbedBuilder()
    .setColor('#5865F2')
    .setTitle(`${gameTitle} — Pilih Difficulty AI`)
    .setDescription(DIFFICULTIES.map(d => `**${d.label}** — ${d.desc}`).join('\n') + `\n\nTidak pilih dalam 30 detik = default **${defaultLabel}** (bisa diubah owner di panel).`);
  await message.edit({ embeds: [embed], components: [buildDifficultyRow(prefix)] });

  const picked = await message.awaitMessageComponent({
    componentType: ComponentType.Button,
    time: 30000,
    filter: (i) => i.user.id === authorId,
  }).catch(() => null);

  if (!picked) return { key: defaultKey, label: `${defaultLabel} (default)`, message, componentInteraction: null };
  const key = picked.customId.split('_').pop();
  const found = DIFFICULTIES.find(d => d.key === key) || DIFFICULTIES[2];
  return { key: found.key, label: found.label, message, componentInteraction: picked };
}

module.exports = { DIFFICULTIES, DIFFICULTY_KEYS, buildDifficultyRow, pickDifficulty };
