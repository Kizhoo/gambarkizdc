/* ============================================================================
 * KIZDC SECURITY SUITE — pertahanan berlapis untuk dashboard + web RPG
 * ----------------------------------------------------------------------------
 * Dipasang dari dashboard/server.js (applySecurity) dan dipakai juga oleh
 * utils/rpgServer.js (guard API RPG) & utils/rpgRealtime.js (guard WebSocket).
 *
 * Lapisan yang disediakan:
 *   1.  securityHeaders  — CSP, X-Frame-Options, nosniff, referrer-policy,
 *                          permissions-policy, COOP/CORP, HSTS (https saja).
 *   2.  hostGuard        — ANTI-KLON: hanya domain terdaftar yang boleh
 *                          meng-host situs (Host header divalidasi).
 *   3.  originGuard      — ANTI-KLON + ANTI-CSRF: mutasi (POST/PUT/DELETE)
 *                          dari Origin asing ditolak; situs kloningan yang
 *                          memanggil API kita langsung mati.
 *   4.  hotlinkGuard     — ANTI-HOTLINK: aset (/assets/*) tidak boleh
 *                          dimuat dari halaman domain lain.
 *   5.  scannerGuard     — deteksi scanner/honeypot (.env, wp-admin, dll)
 *                          + blokir user-agent tool serangan (sqlmap, nikto).
 *   6.  wafLite          — tapisan query/body berbahaya (path traversal,
 *                          union select, tag script, prototype pollution).
 *   7.  rateLimiters     — limit global per-IP + lockout brute-force login.
 *   8.  blocklist        — ban otomatis sementara untuk IP nakal.
 *   9.  auditLog         — semua kejadian mencurigakan dicatat ke tabel
 *                          rpg_security_log (bisa dilihat owner via API).
 *   10. manifest         — /api/security/manifest: info domain resmi untuk
 *                          client-side security-lock.js (anti-klon kedua).
 *   11. safeEqual        — perbandingan token anti timing-attack.
 *   12. scrubBody        — pembersih prototype-pollution + panjang input.
 *
 * Konfigurasi (.env):
 *   ALLOWED_DOMAINS  — tambahan domain resmi, pisah koma (mis. "kizdc.com,www.kizdc.com")
 *   OFFICIAL_URL     — URL resmi untuk redirect kalau ketemu situs kloningan
 *   SECURITY_SECRET  — secret HMAC manifest (opsional; auto-derived kalau kosong)
 *   OWNER_ID         — Discord ID owner (untuk endpoint status keamanan)
 * ========================================================================== */
const crypto = require('crypto');

// ---------------------------------------------------------------------------
// KONFIGURASI DOMAIN — sumber kebenaran ANTI-KLON
// ---------------------------------------------------------------------------
function stripHost(u) {
  try { return new URL(u).hostname.toLowerCase(); } catch (_) { return null; }
}

function buildAllowedHosts() {
  const hosts = new Set();
  // Default lokal (development / testing).
  hosts.add('localhost');
  hosts.add('127.0.0.1');
  hosts.add('::1');
  hosts.add('*.localhost');
  // Tunnel Cloudflare bawaan bot (ENABLE_TUNNEL=true) — subdomain acak.
  hosts.add('*.trycloudflare.com');
  // Sandbox preview internal.
  hosts.add('*.space-z.ai');
  // Domain resmi user: diambil dari DASHBOARD_REDIRECT_URL + ALLOWED_DOMAINS.
  const fromRedirect = stripHost(process.env.DASHBOARD_REDIRECT_URL || '');
  if (fromRedirect) hosts.add(fromRedirect);
  String(process.env.ALLOWED_DOMAINS || '')
    .split(',').map((s) => s.trim().toLowerCase()).filter(Boolean)
    .forEach((h) => hosts.add(h));
  return hosts;
}

const ALLOWED_HOSTS = buildAllowedHosts();

function hostAllowed(hostHeader) {
  if (!hostHeader) return false;
  let host = String(hostHeader).toLowerCase();
  // Buang port (IPv6 hati-hati: [::1]:3000).
  if (host.startsWith('[')) host = host.slice(0, host.indexOf(']') + 1).replace(/[[\]]/g, '');
  else host = host.split(':')[0];
  if (!host) return false;
  for (const pat of ALLOWED_HOSTS) {
    if (pat.startsWith('*.')) { if (host.endsWith(pat.slice(1))) return true; }
    else if (host === pat) return true;
  }
  // Akses jaringan lokal (LAN) diperbolehkan — owner sah membuka dashboard
  // dari HP/laptop lain di rumah. Kloner internet pakai domain publik, bukan IP privat.
  if (/^10\.\d+\.\d+\.\d+$/.test(host)) return true;
  if (/^192\.168\.\d+\.\d+$/.test(host)) return true;
  if (/^172\.(1[6-9]|2\d|3[01])\.\d+\.\d+$/.test(host)) return true;
  if (host.endsWith('.local') || host.endsWith('.lan') || host.endsWith('.internal')) return true;
  return false;
}

const OFFICIAL_URL = (() => {
  const u = String(process.env.OFFICIAL_URL || '').trim();
  if (u) return u;
  const r = String(process.env.DASHBOARD_REDIRECT_URL || '').trim();
  if (r) return r.replace(/\/auth\/callback.*$/, '').replace(/\/+$/, '');
  return '';
})();

// Secret stabil antar-restart (tidak hardcoded di repo).
const SECURITY_SECRET = process.env.SECURITY_SECRET ||
  crypto.createHash('sha256').update(`kizdc-sec-v1|${process.env.DASHBOARD_TOKEN || ''}|${process.env.DISCORD_CLIENT_ID || ''}`).digest('hex');

// ---------------------------------------------------------------------------
// UTIL
// ---------------------------------------------------------------------------
function clientIp(req) {
  const xf = req.headers['x-forwarded-for'];
  if (xf) return String(xf).split(',')[0].trim();
  return (req.socket && req.socket.remoteAddress) || '0.0.0.0';
}

function safeEqual(a, b) {
  const ba = Buffer.from(String(a || ''));
  const bb = Buffer.from(String(b || ''));
  if (ba.length !== bb.length) {
    // Samakan panjang agar durasi perbandingan tidak membocorkan panjang token.
    crypto.timingSafeEqual(crypto.createHash('sha256').update(ba).digest(), crypto.createHash('sha256').update(bb).digest());
    return false;
  }
  return crypto.timingSafeEqual(ba, bb);
}

function originHost(header) { return stripHost(header || ''); }

function hostOfUrl(u) {
  try { return new URL(u).hostname.toLowerCase(); } catch (_) { return null; }
}

// ---------------------------------------------------------------------------
// AUDIT LOG — persist ke rpgDb (di-inject applySecurity agar tidak require-cycle)
// ---------------------------------------------------------------------------
let _logSecurity = null; // (ip, kind, path, detail) => void
function setAuditLogger(fn) { _logSecurity = fn; }
function audit(ip, kind, path, detail) {
  try { if (_logSecurity) _logSecurity(String(ip).slice(0, 64), kind, String(path || '').slice(0, 180), String(detail || '').slice(0, 240)); } catch (_) {}
  const line = `[SECURITY] ${kind} ip=${ip} path=${path}${detail ? ' detail=' + detail : ''}`;
  if (kind === 'bad_host' || kind === 'bad_origin' || kind === 'hotlink') console.warn(line);
  else console.warn(line);
}

// ---------------------------------------------------------------------------
// BLOCKLIST — ban sementara per IP (in-memory; cukup untuk 1 proses)
// ---------------------------------------------------------------------------
const blocklist = new Map(); // ip -> { until, reason }
const strikes = new Map();   // ip -> [ {at, kind} ] (untuk eskalasi)

function banIp(ip, ms, reason) {
  blocklist.set(ip, { until: Date.now() + ms, reason });
  audit(ip, 'auto_ban', '-', `${reason} selama ${Math.round(ms / 60000)} menit`);
  if (blocklist.size > 5000) { // safety valve
    const now = Date.now();
    for (const [k, v] of blocklist) if (v.until < now) blocklist.delete(k);
  }
}
function isBanned(ip) {
  const b = blocklist.get(ip);
  if (!b) return null;
  if (b.until < Date.now()) { blocklist.delete(ip); return null; }
  return b;
}
function addStrike(ip, kind) {
  const now = Date.now();
  const arr = (strikes.get(ip) || []).filter((s) => now - s.at < 10 * 60000);
  arr.push({ at: now, kind });
  strikes.set(ip, arr);
  if (arr.length >= 5) { banIp(ip, 15 * 60000, 'strikes:' + kind); strikes.delete(ip); }
  if (strikes.size > 5000) strikes.clear();
}

// ---------------------------------------------------------------------------
// RATE LIMITER — sliding window per IP
// ---------------------------------------------------------------------------
function makeLimiter(max, windowMs) {
  const buckets = new Map(); // ip -> [ts]
  return function hit(ip) {
    const now = Date.now();
    const arr = (buckets.get(ip) || []).filter((t) => now - t < windowMs);
    if (arr.length >= max) { buckets.set(ip, arr); return false; }
    arr.push(now); buckets.set(ip, arr);
    if (buckets.size > 8000) buckets.clear(); // safety valve
    return true;
  };
}
const globalHit = makeLimiter(600, 60 * 1000);      // 600 req/menit per IP (halaman+api+aset)
const loginHit = makeLimiter(20, 10 * 60 * 1000);   // 20 percobaan login / 10 menit

// Brute force: catat kegagalan login per IP -> lockout.
const loginFails = new Map(); // ip -> [ts]
function noteLoginFail(ip) {
  const now = Date.now();
  const arr = (loginFails.get(ip) || []).filter((t) => now - t < 10 * 60000);
  arr.push(now); loginFails.set(ip, arr);
  if (arr.length >= 8) { banIp(ip, 15 * 60000, 'brute-force login'); audit(ip, 'bruteforce', '/api/login', arr.length + ' kegagalan'); loginFails.delete(ip); }
}
function noteLoginOk(ip) { loginFails.delete(ip); }

// ---------------------------------------------------------------------------
// MIDDLEWARE 1 — security headers
// ---------------------------------------------------------------------------
function cspFor(res, opts = {}) {
  const scriptSrc = opts.nonce
    ? `'self' 'nonce-${opts.nonce}'`
    : `'self' 'unsafe-inline'`; // halaman statis publik masih pakai inline kecil
  return [
    "default-src 'self'",
    `script-src ${scriptSrc}`,
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' data: https://fonts.gstatic.com",
    "img-src 'self' data: blob: https://cdn.discordapp.com",
    "connect-src 'self' ws: wss:",
    "worker-src 'self' blob:",
    "frame-ancestors 'none'",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
  ].join('; ');
}

function securityHeaders(req, res, next) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=(), usb=(), interest-cohort=()');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
  res.setHeader('X-DNS-Prefetch-Control', 'off');
  res.setHeader('X-Permitted-Cross-Domain-Policies', 'none');
  const proto = String(req.headers['x-forwarded-proto'] || '') || (req.socket && req.socket.encrypted ? 'https' : '');
  if (proto === 'https') res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  if (!res.getHeader('Content-Security-Policy')) res.setHeader('Content-Security-Policy', cspFor(res));
  next();
}

// ---------------------------------------------------------------------------
// MIDDLEWARE 2 — hostGuard (ANTI-KLON lapis server)
// ---------------------------------------------------------------------------
function hostGuard(req, res, next) {
  const ip = clientIp(req);
  if (!req.headers.host) { audit(ip, 'bad_host', req.originalUrl, 'tanpa Host header'); return res.status(400).send('Permintaan tidak valid.'); }
  if (!hostAllowed(req.headers.host)) {
    audit(ip, 'bad_host', req.originalUrl, 'host=' + req.headers.host);
    addStrike(ip, 'host');
    return res.status(403).send('Domain tidak terdaftar. Situs ini hanya tersedia di domain resmi.');
  }
  next();
}

// ---------------------------------------------------------------------------
// MIDDLEWARE 3 — originGuard (ANTI-KLON + ANTI-CSRF untuk mutasi & WS)
// ---------------------------------------------------------------------------
function originGuardForReq(req, res, next) {
  const method = String(req.method || 'GET').toUpperCase();
  if (method === 'GET' || method === 'HEAD' || method === 'OPTIONS') return next();
  const ip = clientIp(req);
  const origin = req.headers.origin;
  if (!origin) return next(); // klien non-browser (test/server-to-server) — cookie tetap wajib utk auth
  if (origin === 'null') {
    audit(ip, 'bad_origin', req.originalUrl, 'origin=null (sandboxed iframe)');
    addStrike(ip, 'origin');
    return res.status(403).json({ error: 'Permintaan ditolak.' });
  }
  const oh = originHost(origin);
  if (oh && hostAllowed(oh)) return next();
  audit(ip, 'bad_origin', req.originalUrl, 'origin=' + origin);
  addStrike(ip, 'origin');
  return res.status(403).json({ error: 'Permintaan dari domain tidak dikenal ditolak.' });
}

// Untuk upgrade WebSocket: kembalikan true kalau boleh.
function wsOriginOk(req) {
  const origin = req.headers.origin;
  if (!origin) return true;        // klien non-browser
  if (origin === 'null') return false;
  const oh = originHost(origin);
  return !!(oh && hostAllowed(oh));
}

// ---------------------------------------------------------------------------
// MIDDLEWARE 4 — hotlinkGuard (aset tidak boleh dipakai domain lain)
// ---------------------------------------------------------------------------
function hotlinkGuard(req, res, next) {
  const ref = req.headers.referer;
  if (!ref) return next(); // akses langsung / privacy mode -> boleh
  const rh = hostOfUrl(ref);
  if (!rh) return next();
  if (hostAllowed(rh) || rh === (req.headers.host || '').toLowerCase().split(':')[0]) return next();
  audit(clientIp(req), 'hotlink', req.originalUrl, 'referer=' + rh);
  addStrike(clientIp(req), 'hotlink');
  return res.status(403).send('Aset dilindungi — dilarang hotlink dari domain lain.');
}

// ---------------------------------------------------------------------------
// MIDDLEWARE 5 — scannerGuard + UA filter (honeypot)
// ---------------------------------------------------------------------------
const HONEYPOT = [
  '/.env', '/.git', '/.svn', '/.hg', '/.DS_Store', '/.htaccess', '/.htpasswd',
  '/.aws', '/.ssh', '/.dockerenv', '/.bash_history',
  '/wp-admin', '/wp-login.php', '/wp-content', '/xmlrpc.php', '/wordpress',
  '/phpmyadmin', '/pma', '/adminer', '/mysql', '/sql',
  '/vendor/phpunit', '/cgi-bin', '/actuator', '/config.php', '/configuration.php',
  '/shell', '/cmd', '/backup.sql', '/db.sql', '/dump.sql', '/database.sql',
  '/etc/passwd', '/etc/shadow', '/proc/self', '/boaform', '/HNAP1',
];
const BAD_UA = /sqlmap|nikto|masscan|zgrab|nessus|dirbuster|dirb|gobuster|wpscan|acunetix|nuclei|hydra|metasploit|burpsuite|wfuzz|whatweb|openvas|arachni/i;

function scannerGuard(req, res, next) {
  const ip = clientIp(req);
  const ua = String(req.headers['user-agent'] || '');
  if (ua && BAD_UA.test(ua)) {
    audit(ip, 'bad_ua', req.originalUrl, 'ua=' + ua.slice(0, 60));
    banIp(ip, 60 * 60000, 'tool scanner');
    return res.status(403).send('Akses ditolak.');
  }
  const p = String(req.originalUrl || '').split('?')[0].toLowerCase();
  if (HONEYPOT.some((h) => p === h || p.startsWith(h + '/') || p.startsWith(h + '?'))) {
    audit(ip, 'scanner', req.originalUrl, 'honeypot');
    banIp(ip, 30 * 60000, 'menyentuh honeypot');
    return res.status(403).send('Akses ditolak.');
  }
  next();
}

// ---------------------------------------------------------------------------
// MIDDLEWARE 6 — WAF lite (query & body pattern berbahaya)
// ---------------------------------------------------------------------------
const BAD_QUERY = /(\.\.\/|\.\.%2f|%2e%2e%2f|union[\s+]+select|drop[\s+]+table|<script|javascript:|onerror\s*=|document\.cookie|eval\(|base64_decode|sleep\(\d+)/i;

function wafLite(req, res, next) {
  const ip = clientIp(req);
  const q = String(req.originalUrl || '');
  const qi = q.indexOf('?');
  if (qi > -1 && BAD_QUERY.test(decodeURIComponentSafe(q.slice(qi + 1)))) {
    audit(ip, 'waf', q.slice(0, 160), 'query mencurigakan');
    addStrike(ip, 'waf');
    return res.status(400).json({ error: 'Permintaan mengandung pola berbahaya.' });
  }
  next();
}
function decodeURIComponentSafe(s) { try { return decodeURIComponent(s); } catch (_) { return s; } }

// ---------------------------------------------------------------------------
// MIDDLEWARE 7 — global rate limit + blocklist check
// ---------------------------------------------------------------------------
function gateGlobal(req, res, next) {
  const ip = clientIp(req);
  const banned = isBanned(ip);
  if (banned) {
    res.setHeader('Retry-After', String(Math.max(1, Math.ceil((banned.until - Date.now()) / 1000))));
    return res.status(403).send('Akses ditolak sementara.');
  }
  if (!globalHit(ip)) {
    audit(ip, 'rate_global', req.originalUrl, 'limit 600/menit');
    addStrike(ip, 'rate');
    res.setHeader('Retry-After', '30');
    return res.status(429).json({ error: 'Terlalu banyak permintaan. Tunggu sebentar.' });
  }
  next();
}

// ---------------------------------------------------------------------------
// MIDDLEWARE 8 — scrubBody (prototype pollution + ukuran input)
// ---------------------------------------------------------------------------
const BAD_KEYS = ['__proto__', 'constructor', 'prototype'];
function scrubValue(v, depth) {
  if (depth > 6 || v == null) return v;
  if (Array.isArray(v)) { if (v.length > 500) v.length = 500; return v.map((x) => scrubValue(x, depth + 1)); }
  if (typeof v === 'object') {
    for (const k of Object.keys(v)) {
      if (BAD_KEYS.includes(k)) { delete v[k]; continue; }
      v[k] = scrubValue(v[k], depth + 1);
    }
    return v;
  }
  if (typeof v === 'string' && v.length > 20000) return v.slice(0, 20000);
  return v;
}
function scrubBody(req, res, next) {
  if (req.body && typeof req.body === 'object') req.body = scrubValue(req.body, 0) || {};
  next();
}

// ---------------------------------------------------------------------------
// COOKIE helper — flag Secure otomatis di belakang HTTPS/proxy
// ---------------------------------------------------------------------------
function cookieFlags(req) {
  const proto = String(req.headers['x-forwarded-proto'] || '') || (req.socket && req.socket.encrypted ? 'https' : '');
  return proto === 'https' ? '; Secure' : '';
}

// ---------------------------------------------------------------------------
// MANIFEST — dibaca client security-lock.js (domain resmi + tanda tangan)
// ---------------------------------------------------------------------------
function manifestPayload() {
  const domains = [...ALLOWED_HOSTS].filter((h) => !h.startsWith('*.') || h === '*.trycloudflare.com');
  const ts = Math.floor(Date.now() / 3600000); // per jam
  const sig = crypto.createHmac('sha256', SECURITY_SECRET).update(`${OFFICIAL_URL}|${domains.join(',')}|${ts}`).digest('hex').slice(0, 32);
  return { official: OFFICIAL_URL, domains, allowSub: ['trycloudflare.com', 'space-z.ai', 'localhost'], ts, sig };
}

// ---------------------------------------------------------------------------
// APPLY — pasang semua lapisan ke app Express
// ---------------------------------------------------------------------------
function applySecurity(app, { rpgDb } = {}) {
  if (rpgDb && typeof rpgDb.logSecurity === 'function') setAuditLogger(rpgDb.logSecurity);

  app.disable('x-powered-by');
  app.set('query parser', 'simple');

  // Urutan penting: blocklist/rate dulu, lalu scanner, host, headers, WAF,
  // origin-check utk semua mutasi (anti-CSRF + anti-klon).
  app.use(gateGlobal);
  app.use(scannerGuard);
  app.use(hostGuard);
  app.use(securityHeaders);
  app.use(wafLite);
  app.use(originGuardForReq);
  app.use(scrubBody); // untuk rute yang pakai express.json sebelum ini tidak apply — dipasang ulang setelah parser
}

// Pembersihan berkala (dipanggil applySecurity dengan setInterval).
// Catatan: interval janitor TIDAK ditaruh di rpgDb.js karena saat process.exit
// kombinasi setInterval + finalizer better-sqlite3 memicu crash native di Node 24.
function startJanitor(rpgDb) {
  const t = setInterval(() => {
    const now = Date.now();
    for (const [k, v] of blocklist) if (v.until < now) blocklist.delete(k);
    for (const [k, arr] of strikes) { const a = arr.filter((s) => now - s.at < 10 * 60000); if (!a.length) strikes.delete(k); else strikes.set(k, a); }
    try { if (rpgDb && typeof rpgDb.trimSecurityLog === 'function') rpgDb.trimSecurityLog(); } catch (_) {}
  }, 30 * 60000);
  if (t.unref) t.unref();
}

// HANYA UNTUK TEST SUITE — reset state blocklist/strike (jangan dipakai di produksi).
// (Rate limiter global tidak di-reset — test flood memang ditaruh paling akhir.)
function _testReset() {
  blocklist.clear(); strikes.clear(); loginFails.clear();
}

module.exports = {
  ALLOWED_HOSTS, OFFICIAL_URL, SECURITY_SECRET,
  hostAllowed, wsOriginOk, clientIp, safeEqual, cookieFlags,
  securityHeaders, hostGuard, originGuardForReq, hotlinkGuard, scannerGuard, wafLite, gateGlobal, scrubBody,
  makeLimiter, globalHit, loginHit, noteLoginFail, noteLoginOk,
  isBanned, banIp, audit, manifestPayload, cspFor,
  applySecurity, startJanitor, _testReset,
};
