require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.GuildVoiceStates,
  ],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction, Partials.GuildMember, Partials.User],
});

// ===== Sistem Musik (Shoukaku + Kazagumo, pakai node Lavalink publik) =====
const { initMusic } = require('./utils/musicSetup');
client.kazagumo = initMusic(client);

// ===== Web Dashboard (opsional; butuh npm i express ws @discordjs/voice) =====
try {
  const { startDashboard } = require('./dashboard/server');
  startDashboard(client);
} catch (e) {
  console.warn('[Dashboard] Tidak bisa start (dependency belum diinstall?):', e.message);
}

client.commands = new Collection();
client.cooldowns = new Collection();
client.config = require('./config.json');

// ===== Load semua command dari folder commands/<kategori>/*.js =====
const commandsPath = path.join(__dirname, 'commands');
const categoryFolders = fs.readdirSync(commandsPath).filter(f =>
  fs.statSync(path.join(commandsPath, f)).isDirectory()
);

client.categories = categoryFolders;

for (const category of categoryFolders) {
  const categoryPath = path.join(commandsPath, category);
  const commandFiles = fs.readdirSync(categoryPath).filter(f => f.endsWith('.js'));
  for (const file of commandFiles) {
    const command = require(path.join(categoryPath, file));
    if (command.subcommandOf) continue; // logika sub-command, dimuat oleh command induk
    if (!command.data || !command.execute) {
      console.warn(`[WARN] Command ${file} di kategori ${category} tidak punya "data" atau "execute".`);
      continue;
    }
    command.category = category;
    if (client.commands.has(command.data.name)) {
      throw new Error(`Nama command duplikat: /${command.data.name} (${category}/${file})`);
    }
    // Validasi schema saat startup agar error option/subcommand ditemukan sebelum deploy.
    command.data.toJSON();
    client.commands.set(command.data.name, command);
  }
}

// ===== Load semua event dari folder events/*.js =====
const eventsPath = path.join(__dirname, 'events');
const eventFiles = fs.readdirSync(eventsPath).filter(f => f.endsWith('.js'));
for (const file of eventFiles) {
  const event = require(path.join(eventsPath, file));
  if (event.once) {
    client.once(event.name, (...args) => event.execute(...args, client));
  } else {
    client.on(event.name, (...args) => event.execute(...args, client));
  }
}

if (client.commands.size > 100) {
  throw new Error(`Discord membatasi 100 top-level command; saat ini ada ${client.commands.size}. Kelompokkan command baru sebagai subcommand.`);
}
console.log(`[KizhooBot] ${client.commands.size} command berhasil dimuat dari ${categoryFolders.length} kategori (${100 - client.commands.size} slot tersisa).`);

if (!process.env.DISCORD_TOKEN) {
  console.error('[KizhooBot] DISCORD_TOKEN belum diisi. Salin .env.example menjadi .env lalu isi token.');
  process.exitCode = 1;
} else {
  client.login(process.env.DISCORD_TOKEN).catch(error => {
    console.error('[KizhooBot] Login Discord gagal:', error.message);
    process.exitCode = 1;
  });
}

const { alertOwner } = require('./utils/errorAlert');
const { db } = require('./database/db');

let shuttingDown = false;
async function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`[KizhooBot] ${signal} diterima, mematikan bot dengan aman...`);
  try { client.destroy(); } catch (_) {}
  try { db.close(); } catch (_) {}
  process.exit(0);
}
process.once('SIGINT', () => shutdown('SIGINT'));
process.once('SIGTERM', () => shutdown('SIGTERM'));

process.on('unhandledRejection', (error) => {
  console.error('Unhandled promise rejection: ', error);
  alertOwner(client, error, 'Unhandled Promise Rejection').catch(() => {});
});

process.on('uncaughtException', (error) => {
  console.error('Uncaught exception: ', error);
  alertOwner(client, error, 'Uncaught Exception').catch(() => {});
});
