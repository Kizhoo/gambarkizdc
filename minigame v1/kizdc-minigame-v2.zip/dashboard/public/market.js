// ============================================================================
// MARKET KIZCO — katalog aset (pagination) + lelang (auction house P2P).
// ============================================================================
const $ = (id) => document.getElementById(id);
// Identitas user dari session OAuth (cookie), bukan localStorage.
let TOKEN = '';
let MY_USER_ID = '';
let guilds = [];
let guildId = '';
let page = 1;
let totalPages = 1;
let categories = [];
let myItems = [];
let catalogItems = [];

function authHeaders() { return { 'Authorization': `Bearer ${TOKEN}`, 'Content-Type': 'application/json' }; }
function fmtFull(n) { return (Math.round(Number(n) || 0)).toLocaleString('id-ID'); }
function fmtCompact(n) {
  if (window.WebI18n && window.WebI18n.compact) return window.WebI18n.compact(n);
  const v = Number(n) || 0, abs = Math.abs(v), s = v < 0 ? '-' : '';
  const trim = (x) => x.replace(/\.0$/, '');
  if (abs >= 1e12) return s + trim((abs / 1e12).toFixed(1)) + 'T';
  if (abs >= 1e9) return s + trim((abs / 1e9).toFixed(1)) + 'B';
  if (abs >= 1e6) return s + trim((abs / 1e6).toFixed(1)) + 'M';
  if (abs >= 1e3) return s + trim((abs / 1e3).toFixed(1)) + 'K';
  return s + Math.round(abs);
}
function fmtPct(n) { const v = Number(n) || 0; return (v > 0 ? '+' : '') + v.toFixed(2) + '%'; }
function t(key, params) { return window.WebI18n ? window.WebI18n.t(window.WebI18n.currentLang(), key, params) : key; }
function escapeHtml(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
// Tier/raritas item (dipakai badge di kartu & modal).
const TIER_META = {
  common: { name: 'Umum', color: '#9CA3AF' },
  uncommon: { name: 'Lumayan', color: '#4ADE80' },
  rare: { name: 'Langka', color: '#38BDF8' },
  epic: { name: 'Epik', color: '#A855F7' },
  legendary: { name: 'Legendaris', color: '#FACC15' },
};
function effectText(special) {
  if (!special) return '';
  const pct = special.pct != null ? Math.round(special.pct * 100) + '%' : '';
  switch (special.kind) {
    case 'lifesteal': return 'Menghisap nyawa ' + pct + ' dari damage';
    case 'cleave': return 'Serangan menyapu (' + pct + ' ke semua musuh)';
    case 'poison': return 'Racuni musuh (' + Math.round(special.dot * 100) + '% ATK)';
    case 'execute': return 'Eksekusi +' + pct + ' vs musuh sekarat';
    case 'critDmg': return 'Critical damage +' + pct;
    case 'manaRegen': return 'Regenerasi +' + special.val + ' MP/giliran';
    case 'shield': return 'Perisai ' + pct + ' HP maks saat bertarung';
    case 'healBoost': return 'Penyembuhan +' + pct;
    case 'thorns': return 'Memantulkan ' + pct + ' damage';
    case 'regen': return 'Regenerasi +' + special.val + ' HP/giliran';
    case 'dodge': return 'Hindar +' + pct;
    case 'goldFind': return 'Perolehan KZC +' + pct;
    case 'revive': return 'Bangkit 1x dengan ' + pct + ' HP';
    case 'petroll': return 'Memanggil pet acak saat dipakai';
    case 'petxp': return 'Pet aktif +' + special.val + ' XP';
    default: return '';
  }
}
const CLASS_NAMES = { warrior: 'Warrior', mage: 'Mage', assassin: 'Assassin', archer: 'Archer' };
// Kunci ikon PNG (assets/icons/) — cermin itemIconKey di rpg.js.
function iconKeyFor(it) {
  if (!it) return null;
  const id = String(it.id || '');
  const cat = it.category || it.cat || '';
  if (cat === 'weapon') {
    return { sword: 'w_sword', axe: 'w_axe', hammer: 'w_hammer', spear: 'w_spear', staff: 'w_staff', wand: 'w_wand', orb: 'w_orb', tome: 'w_tome', dagger: 'w_dagger', katana: 'w_katana', claw: 'w_claw', bow: 'w_bow' }[it.wtype || it.type] || 'w_sword';
  }
  if (cat === 'armor') return { light: 'a_light', medium: 'a_chain', heavy: 'a_plate', shield: 'a_shield' }[it.wtype || it.type] || 'a_chain';
  if (cat === 'accessory') {
    if (/crown/i.test(id)) return 'c_crown';
    if (/cloak/i.test(id)) return 'c_cloak';
    if (/ring/i.test(id)) return 'c_ring';
    if (/earring|crit/i.test(id)) return 'c_earring';
    if (/pendant|blood/i.test(id)) return 'c_pendant';
    if (/bracer|thorn/i.test(id)) return 'c_bracer';
    if (/charm|storm/i.test(id)) return 'c_charm';
    if (/angel/i.test(id)) return 'c_angel';
    if (/hourglass|time/i.test(id)) return 'c_hourglass';
    if (/coin|lucky/i.test(id)) return 'c_coin';
    return 'c_ring';
  }
  if (cat === 'potion') {
    if (/heal/.test(id)) return 'p_heal';
    if (/mana/.test(id)) return 'p_mana';
    if (/elixir/.test(id)) return 'p_elixir';
    if (/strength|berserk/.test(id)) return 'p_str';
    if (/swift/.test(id)) return 'p_spd';
    if (/guard/.test(id)) return 'p_def';
    if (/poison|venom|weaken|paralyze/.test(id)) return 'p_poison';
    if (/regen/.test(id)) return 'p_regen';
    return 'p_heal';
  }
  if (cat === 'material') {
    if (/jelly/.test(id)) return 'm_jelly';
    if (/tail/.test(id)) return 'm_tail';
    if (/wing/.test(id)) return 'm_wing';
    if (/ear/.test(id)) return 'm_ear';
    if (/bone/.test(id)) return 'm_bone';
    if (/pelt|fur/.test(id)) return 'm_pelt';
    if (/venom/.test(id)) return 'm_venom';
    if (/ember/.test(id)) return 'm_ember';
    if (/fang/.test(id)) return 'm_fang';
    if (/feather/.test(id)) return 'm_feather';
    if (/shell/.test(id)) return 'm_shell';
    if (/shard/.test(id)) return 'm_shard';
    if (/bandage/.test(id)) return 'm_bandage';
    if (/tusk/.test(id)) return 'm_tusk';
    if (/core/.test(id)) return 'm_core';
    if (/ecto/.test(id)) return 'm_ecto';
    if (/yeti/.test(id)) return 'm_fur';
    if (/horn/.test(id)) return 'm_horn';
    if (/scale/.test(id)) return 'm_scale';
    if (/heart/.test(id)) return 'm_heart';
    if (/whistle/.test(id)) return 'm_whistle';
    if (/snack/.test(id)) return 'm_snack';
    return 'm_bone';
  }
  return null;
}
// Ikon item: PNG asli dari assets/icons (dengan glow rarity), fallback canvas lama.
function iconImgHtml(it, size) {
  const key = iconKeyFor(it);
  const tier = TIER_META[it && it.tier] || TIER_META.common;
  if (key) {
    return `<span class="icpng" style="width:${size}px;height:${size}px;border:2px solid ${tier.color};border-radius:10px;background:rgba(11,18,32,.85)"><img src="assets/icons/${key}.png" style="width:${size - 12}px;height:${size - 12}px" alt="" loading="lazy" onerror="this.parentNode.classList.add('icfallback');this.remove()"></span>`;
  }
  return `<span class="ic" data-ic="${it ? it.id : ''}" data-cat="${it ? (it.category || it.cat) : ''}"></span>`;
}
function hydrateCanvasIcons(root) {
  root.querySelectorAll('.ic').forEach(el => {
    if (!window.ItemIcons || el.querySelector('canvas')) return;
    const c = document.createElement('canvas');
    window.ItemIcons.draw(c, el.dataset.ic, el.dataset.cat, el.classList.contains('big') ? 64 : 44);
    el.appendChild(c);
  });
  // Fallback bila PNG gagal: gambar ulang dengan canvas prosedural.
  root.querySelectorAll('.icpng.icfallback').forEach(el => {
    el.classList.remove('icfallback');
    el.classList.add('ic');
    el.dataset.ic = el.dataset.ic || '';
    el.dataset.cat = el.dataset.cat || '';
  });
}
function itemStatLines(it) {
  const e = it.effect || {};
  const s = it.stats || {};
  const equip = it.category === 'weapon' || it.category === 'armor' || it.category === 'accessory';
  const lines = [];
  if (equip) {
    const labels = { atk: 'ATK', def: 'DEF', spd: 'SPD', crit: 'Crit', hp: 'HP', mp: 'MP' };
    for (const [k, l] of Object.entries(labels)) if (s[k] != null) lines.push({ t: l + ' +' + s[k], k: 'stat' });
    const sp = effectText(e);
    if (sp) lines.push({ t: sp, k: 'fx' });
  } else {
    if (e.heal) lines.push({ t: 'Pulihkan ' + e.heal + ' HP', k: 'stat' });
    if (e.mana) lines.push({ t: 'Pulihkan ' + e.mana + ' MP', k: 'stat' });
    if (e.healPct) lines.push({ t: 'Pulihkan HP & MP penuh', k: 'stat' });
    if (e.poison) lines.push({ t: 'Racun -' + e.poison + ' HP/giliran', k: 'fx' });
    if (e.venom) lines.push({ t: 'Racun kuat -' + e.venom + ' HP/giliran', k: 'fx' });
    if (e.weaken) lines.push({ t: 'Lemahkan ATK musuh -' + Math.round(e.weaken * 100) + '%', k: 'fx' });
    if (e.paralyze) lines.push({ t: 'Lumpuhkan musuh ' + e.paralyze + ' giliran', k: 'fx' });
    if (e.shield) lines.push({ t: 'Perisai ' + Math.round(e.shield * 100) + '% HP', k: 'stat' });
    if (e.kind === 'petroll') lines.push({ t: 'Memanggil pet acak saat dipakai', k: 'fx' });
    if (e.kind === 'petxp') lines.push({ t: 'Pet aktif +' + e.val + ' XP', k: 'stat' });
    // Material: efek saat dikonsumsi dari data `use`.
    if (it.use && !lines.length) {
      const u = it.use;
      if (u.kind === 'heal') lines.push({ t: 'Dimakan: pulihkan ' + u.val + ' HP', k: 'stat' });
      else if (u.kind === 'mana') lines.push({ t: 'Konsumsi: pulihkan ' + u.val + ' MP', k: 'stat' });
      else if (u.kind === 'petroll') lines.push({ t: 'Memanggil pet acak saat dipakai', k: 'fx' });
      else if (u.kind === 'petxp') lines.push({ t: 'Pet aktif +' + u.val + ' XP', k: 'stat' });
      else if (u.kind === 'elixir') lines.push({ t: 'Pulihkan HP & MP penuh', k: 'stat' });
      else if (u.val != null) lines.push({ t: 'Efek konsumsi: ' + u.kind + ' ' + u.val, k: 'fx' });
    }
  }
  return lines;
}
function setStatus(id, text, cls) { const el = $(id); el.textContent = text; el.className = 'status ' + (cls || ''); }

// ---------- LOGIN ----------
// ---------- LOGIN (hanya via Discord) ----------
if ($('btnLogin')) {
  $('btnLogin').addEventListener('click', async () => {
    const token = ($('token') ? $('token').value : '').trim();
    if (!token) return ($('loginError') ? ($('loginError').textContent = t('market.enter_token')) : null);
    const res = await fetch('/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token }) });
    if (res.ok) { TOKEN = token; showApp(); }
    else if ($('loginError')) $('loginError').textContent = t('market.wrong_token');
  });
}

async function init() {
  let me = null;
  for (let i = 0; i < 6; i++) {
    try { me = await (await fetch('/api/me')).json(); } catch {}
    if (me && me.userId) break;
    await new Promise(r => setTimeout(r, 400));
  }
  if (me && me.userId) { MY_USER_ID = me.userId; showApp(); return; }
  if (TOKEN) showApp();
}

function showApp() {
  $('login').classList.add('hidden');
  $('app').classList.remove('hidden');
  loadGuilds();
}

// ---------- GUILDS ----------
async function loadGuilds() {
  const res = await fetch('/api/guilds', { headers: authHeaders() });
  guilds = await res.json();
  $('guildSelect').innerHTML = '<option value="">' + t('ui.select_server') + '</option>' + guilds.map(g => `<option value="${g.id}">${escapeHtml(g.name)}</option>`).join('');
}
$('guildSelect').addEventListener('change', () => {
  guildId = $('guildSelect').value;
  page = 1;
  if (activeView === 'catalog') loadPage(); else loadAuction();
});

// ---------- TAB ----------
let activeView = 'catalog';
document.querySelectorAll('.mtab').forEach(t => t.addEventListener('click', () => {
  activeView = t.dataset.view;
  document.querySelectorAll('.mtab').forEach(x => x.classList.toggle('active', x === t));
  $('view-catalog').classList.toggle('hidden', activeView !== 'catalog');
  $('view-auction').classList.toggle('hidden', activeView !== 'auction');
  if (!guildId) return;
  if (activeView === 'catalog') loadPage(); else loadAuction();
}));

// ---------- CATALOG ----------
async function loadPage() {
  if (!guildId) return;
  const q = ($('search').value || '').trim();
  const cat = $('category').value;
  const params = new URLSearchParams({ guildId, page: String(page), perPage: '12' });
  if (q) params.set('q', q);
  if (cat) params.set('category', cat);
  const res = await fetch('/api/market/items?' + params.toString(), { headers: authHeaders() });
  const d = await res.json();
  totalPages = d.totalPages || 1;
  page = d.page || 1;
  if (d.categories) { categories = d.categories; fillCategories(); }
  if (d.state) $('marketMeta').textContent = `${d.total} aset • Indeks ${Number(d.state.priceIndex).toFixed(1)}`;
  renderGrid(d.items || []);
  renderPagination();
  loadBalance();
}

function fillCategories() {
  const sel = $('category');
  const cur = sel.value;
  sel.innerHTML = '<option value="">' + t('market.all_categories') + '</option>' + categories.map(c => `<option value="${c.key}" ${c.key === cur ? 'selected' : ''}>${escapeHtml(c.label)}</option>`).join('');
}

function renderGrid(items) {
  const grid = $('grid');
  catalogItems = items;
  if (!items.length) { grid.innerHTML = '<div class="empty">' + t('market.no_assets') + '</div>'; return; }
  grid.innerHTML = items.map(it => {
    const chg = it.change24hPct || 0;
    const cls = chg >= 0 ? 'up' : 'down';
    const catLabel = (categories.find(c => c.key === it.category) || {}).label || it.category;
    const tier = TIER_META[it.tier] || TIER_META.common;
    const stats = itemStatLines(it).slice(0, 3);
    const classNote = it.class ? `<span class="tier-badge" style="color:#67e8f9;border:1px solid #67e8f9">${CLASS_NAMES[it.class] || it.class}</span>` : '';
    const statHtml = stats.map(s => `<div class="mline ${s.k === 'fx' ? 'fx' : ''}">${escapeHtml(s.t)}</div>`).join('');
    return `<div class="card rarity-${it.tier || 'common'}" data-id="${it.id}" role="button" tabindex="0" style="border-color:${tier.color}55">
      <div class="top">
        ${iconImgHtml(it, 48)}
        <div class="title"><div class="name">${escapeHtml(it.name)}</div><div class="cat">${escapeHtml(catLabel)} <span class="tier-badge" style="color:${tier.color};border:1px solid ${tier.color}">${tier.name}</span> ${classNote}</div></div>
      </div>
      <div class="statbox">${statHtml || '<div class="mline muted">' + escapeHtml((it.desc || '').slice(0, 64)) + '</div>'}</div>
      <div class="priceRow"><span class="price num">${fmtCompact(it.price)} <span class="small muted">KZC</span></span><span class="chg num ${cls}">${fmtPct(chg)}</span></div>
    </div>`;
  }).join('');
  hydrateCanvasIcons(grid);
  grid.querySelectorAll('.card').forEach(card => {
    card.addEventListener('click', () => openModal(card.dataset.id));
  });
}

function renderPagination() {
  const pg = $('pagination');
  pg.innerHTML = `
    <button id="btnPrev" class="btn" ${page <= 1 ? 'disabled' : ''}>${t('market.prev')}</button>
    <span class="info">${t('market.page', { p: page, t: totalPages })}</span>
    <button id="btnNext" class="btn" ${page >= totalPages ? 'disabled' : ''}>${t('market.next')}</button>`;
  $('btnPrev').addEventListener('click', () => { if (page > 1) { page--; loadPage(); } });
  $('btnNext').addEventListener('click', () => { if (page < totalPages) { page++; loadPage(); } });
}

// ---------- AUCTION ----------
async function loadAuction() {
  if (!guildId) return;
  await Promise.all([loadMyItems(), loadListings()]);
  loadBalance();
}
async function loadMyItems() {
  try {
    const res = await fetch('/api/market/my-items', { headers: authHeaders() });
    const d = await res.json();
    myItems = d.items || [];
    $('sellItem').innerHTML = '<option value="">' + t('market.select_asset') + '</option>' + myItems.map(i => `<option value="${i.itemId}">${escapeHtml(i.name)} (x${i.qty})</option>`).join('');
  } catch {}
}
async function loadListings() {
  const res = await fetch('/api/market/listings?guildId=' + guildId, { headers: authHeaders() });
  const d = await res.json();
  renderListings(d.listings || []);
}
function renderListings(list) {
  const box = $('listings');
  $('auctionMeta').textContent = t('market.active_listings', { n: list.length });
  if (!list.length) { box.innerHTML = '<div class="empty-list">' + t('market.no_listings') + '</div>'; return; }
  box.innerHTML = list.map(l => `
    <div class="listing" data-id="${l.id}">
      ${iconImgHtml({ id: l.itemId, category: l.category }, 40)}
      <div class="info">
        <div class="name">${escapeHtml(l.itemName)}</div>
        <div class="sub">x${l.qty} • ${t('market.seller', { id: shortId(l.sellerId) })}</div>
      </div>
      <div class="price num">${fmtCompact(l.pricePerUnit)} <span class="small muted">KZC/unit</span></div>
      <div class="actions">
        ${l.sellerId === MY_USER_ID ? `<button class="btn danger" data-act="cancel">${t('ui.cancel')}</button>` : `<button class="btn primary" data-act="buy">${t('ui.buy')}</button>`}
      </div>
    </div>`).join('');
  hydrateCanvasIcons(box);
  box.querySelectorAll('[data-act]').forEach(b => b.addEventListener('click', () => {
    const id = Number(b.closest('.listing').dataset.id);
    if (b.dataset.act === 'buy') buyListing(id);
    else cancelListing(id);
  }));
}
function shortId(id) { const s = String(id || ''); return s.length > 10 ? s.slice(0, 6) + '...' + s.slice(-4) : s; }

$('btnSell').addEventListener('click', async () => {
  if (!guildId) return setStatus('sellStatus', t('ui.pick_server_first'), 'err');
  if (!MY_USER_ID) return setStatus('sellStatus', t('ui.login_discord_first'), 'err');
  const itemId = $('sellItem').value;
  const qty = Number($('sellQty').value) || 0;
  const price = Number($('sellPrice').value) || 0;
  if (!itemId) return setStatus('sellStatus', t('market.select_asset'), 'err');
  if (qty <= 0 || price <= 0) return setStatus('sellStatus', t('trade.fill_qty'), 'err');
  const res = await fetch('/api/market/listings', { method: 'POST', headers: authHeaders(), body: JSON.stringify({ guildId, itemId, qty, pricePerUnit: price }) });
  const d = await res.json();
  if (res.ok) { setStatus('sellStatus', t('market.listing_placed'), 'ok'); loadAuction(); }
  else setStatus('sellStatus', t('ui.failed', { err: d.error }), 'err');
});
async function buyListing(id) {
  const res = await fetch(`/api/market/listings/${id}/buy`, { method: 'POST', headers: authHeaders(), body: JSON.stringify({ guildId, qty: 1 }) });
  const d = await res.json();
  if (res.ok) loadAuction(); else alert(d.error);
}
async function cancelListing(id) {
  const res = await fetch(`/api/market/listings/${id}/cancel`, { method: 'POST', headers: authHeaders(), body: JSON.stringify({ guildId }) });
  const d = await res.json();
  if (res.ok) loadAuction(); else alert(d.error);
}

// ---------- BALANCE ----------
async function loadBalance() {
  try {
    if (!MY_USER_ID) return;
    const res = await fetch(`/api/trade/${guildId}/portfolio?userId=${MY_USER_ID}`, { headers: authHeaders() });
    const d = await res.json();
    if (d.balance != null) $('balancePill').textContent = fmtCompact(d.balance);
  } catch {}
}

// ---------- FILTER ----------
$('search').addEventListener('input', debounce(() => { page = 1; loadPage(); }, 350));
$('category').addEventListener('change', () => { page = 1; loadPage(); });
function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }

// ---------- MODAL DETAIL & BELI ----------
let currentModalItemId = '';

function openModal(itemId) {
  currentModalItemId = itemId;
  const it = catalogItems.find(i => i.id === itemId);
  if (!it) return;
  $('modalName').textContent = it.name;
  const catLabel = (categories.find(c => c.key === it.category) || {}).label || it.category;
  const tier = TIER_META[it.tier] || TIER_META.common;
  $('modalCategory').innerHTML = `${escapeHtml(catLabel)} &middot; <span style="color:${tier.color}">${tier.name}</span>${it.class ? ` &middot; <span style="color:#67e8f9">Khusus ${CLASS_NAMES[it.class] || it.class}</span>` : ''}`;
  $('modalDesc').textContent = it.desc || t('market.no_desc');
  $('modalPrice').textContent = fmtCompact(it.price);
  $('modalQty').value = 1;
  setStatus('modalStatus', '', '');
  const wrap = $('modalIconWrap');
  wrap.innerHTML = iconImgHtml(it, 72);
  wrap.classList.add('big');
  hydrateCanvasIcons(wrap);
  const statRows = itemStatLines(it).map((s) => `<div class="mstat"><span class="k">${escapeHtml(s.t)}</span><span class="v ${s.k === 'fx' ? 'fx' : ''}"></span></div>`).join('');
  $('modalStats').innerHTML =
    statRows +
    `<div class="mstat"><span class="k">${t('market.demand')}</span><span class="v">${escapeHtml(it.trend || 'stabil')}</span></div>` +
    `<div class="mstat"><span class="k">${t('market.24h')}</span><span class="v ${(it.change24hPct || 0) >= 0 ? 'up' : 'down'}">${fmtPct(it.change24hPct)}</span></div>`;
  $('itemModal').classList.remove('hidden');
}

function closeModal() { $('itemModal').classList.add('hidden'); }

$('modalClose').addEventListener('click', closeModal);
$('itemModal').addEventListener('click', (e) => { if (e.target === $('itemModal')) closeModal(); });

$('modalBuy').addEventListener('click', async () => {
  if (!guildId) return setStatus('modalStatus', t('ui.pick_server_first'), 'err');
  if (!MY_USER_ID) return setStatus('modalStatus', t('ui.login_discord_first'), 'err');
  const qty = Math.max(1, Math.round(Number($('modalQty').value) || 1));
  setStatus('modalStatus', t('market.processing'), '');
  const res = await fetch('/api/market/buy', { method: 'POST', headers: authHeaders(), body: JSON.stringify({ guildId, itemId: currentModalItemId, qty }) });
  const d = await res.json();
  if (res.ok) {
    setStatus('modalStatus', t('market.bought', { qty: d.qty, name: d.item.name }), 'ok');
    loadBalance();
    if (activeView === 'catalog') loadPage(); else loadAuction();
  } else setStatus('modalStatus', t('ui.failed', { err: d.error }), 'err');
});

init();
