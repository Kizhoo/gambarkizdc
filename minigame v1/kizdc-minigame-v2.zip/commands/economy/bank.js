const { SlashCommandBuilder } = require('discord.js');
const { getEconomy, updateBalance, updateBank } = require('../../database/db');
const econ = require('../../database/economyDb');
const engine = require('../../utils/economyEngine');
const { successEmbed, errorEmbed, baseEmbed } = require('../../utils/embeds');
const kizco = require('../../utils/kizco');
const { t, guildLang } = require('../../utils/i18n');

const BANK_NAME = 'Bank Kizaria';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('bank')
    .setDescription(`Kelola tabungan Kizco di ${BANK_NAME}`)
    .addSubcommand(sub => sub.setName('deposit').setDescription('Simpan Kizco ke bank')
      .addStringOption(o => o.setName('jumlah').setDescription('Jumlah Kizco atau "all"').setRequired(true)))
    .addSubcommand(sub => sub.setName('withdraw').setDescription('Tarik Kizco dari bank')
      .addStringOption(o => o.setName('jumlah').setDescription('Jumlah Kizco atau "all"').setRequired(true)))
    .addSubcommand(sub => sub.setName('statement').setDescription('Lihat mutasi rekening & bunga')),

  async execute(interaction) {
    const lang = guildLang(interaction);
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    const userId = interaction.user.id;
    const eco = getEconomy(guildId, userId);

    if (sub === 'deposit') {
      const input = interaction.options.getString('jumlah');
      const amount = input.toLowerCase() === 'all' ? eco.balance : parseInt(input);
      if (!amount || isNaN(amount) || amount <= 0) return interaction.reply({ embeds: [errorEmbed(t(lang, 'bank.invalid'))], ephemeral: true });
      if (amount > eco.balance) return interaction.reply({ embeds: [errorEmbed(t(lang, 'bank.no_wallet', { amount: kizco.format(eco.balance) }))], ephemeral: true });

      updateBalance(guildId, userId, -amount);
      updateBank(guildId, userId, amount);
      econ.addBankLog({ guildId, userId, type: 'deposit', amount, note: 'Setor' });
      return interaction.reply({ embeds: [successEmbed(t(lang, 'bank.deposit_ok', { amount: kizco.format(amount), bank: BANK_NAME }))] });
    }

    if (sub === 'withdraw') {
      const input = interaction.options.getString('jumlah');
      const amount = input.toLowerCase() === 'all' ? eco.bank : parseInt(input);
      if (!amount || isNaN(amount) || amount <= 0) return interaction.reply({ embeds: [errorEmbed(t(lang, 'bank.invalid'))], ephemeral: true });
      if (amount > eco.bank) return interaction.reply({ embeds: [errorEmbed(t(lang, 'bank.no_bank', { amount: kizco.format(eco.bank) }))], ephemeral: true });

      updateBank(guildId, userId, -amount);
      updateBalance(guildId, userId, amount);
      econ.addBankLog({ guildId, userId, type: 'withdraw', amount: -amount, note: 'Tarik' });
      return interaction.reply({ embeds: [successEmbed(t(lang, 'bank.withdraw_ok', { amount: kizco.format(amount), bank: BANK_NAME }))] });
    }

    if (sub === 'statement') {
      const rows = econ.getBankLog(guildId, userId, 15);
      const s = engine.summary(guildId);
      const ICON = { deposit: '⬇️', withdraw: '⬆️', interest: '💰' };
      const lines = rows.length
        ? rows.map(r => `${ICON[r.type] || '•'} ${r.type === 'deposit' ? '+' : r.type === 'withdraw' ? '-' : '+'}${kizco.format(Math.abs(r.amount))} _(${r.note || r.type})_ • <t:${Math.floor(r.timestamp / 1000)}:R>`).join('\n')
        : t(lang, 'bank.no_history');
      return interaction.reply({ embeds: [baseEmbed()
        .setTitle(t(lang, 'bank.statement_title', { bank: BANK_NAME }))
        .setDescription(t(lang, 'bank.statement_desc', { balance: kizco.format(eco.bank), rate: s.bankInterestRatePct, lines }))
        .setFooter({ text: t(lang, 'bank.interest_footer') })] });
    }
  },
};
