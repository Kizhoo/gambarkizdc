const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  subcommandOf: true,
  data: new SlashCommandBuilder()
    .setName('avatar')
    .setDescription('Lihat avatar user dalam ukuran penuh')
    .addUserOption(o => o.setName('target').setDescription('User yang ingin dilihat avatarnya')),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const user = interaction.options.getUser('target') || interaction.user;
    const embed = baseEmbed()
      .setTitle(t(lang, 'avatar.title', { user: user.username }))
      .setImage(user.displayAvatarURL({ dynamic: true, size: 1024 }));
    return interaction.reply({ embeds: [embed] });
  },
};
