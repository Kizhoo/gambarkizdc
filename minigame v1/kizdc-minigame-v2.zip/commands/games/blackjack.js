const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, ComponentType } = require('discord.js');
const { getEconomy, updateBalance } = require('../../database/db');
const { createDeck, handValue, formatHand } = require('../../utils/cardGame');
const { errorEmbed } = require('../../utils/embeds');
const config = require('../../config.json');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  subcommandOf: 'games',
  data: new SlashCommandBuilder()
    .setName('blackjack')
    .setDescription('Main blackjack melawan bot, pakai cash kamu')
    .addIntegerOption(o => o.setName('taruhan').setDescription('Jumlah cash yang dipertaruhkan').setRequired(true).setMinValue(10)),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const bet = interaction.options.getInteger('taruhan');
    const eco = getEconomy(interaction.guild.id, interaction.user.id);

    if (eco.balance < bet) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'bj.no_cash', { bal: eco.balance }))], ephemeral: true });
    }

    const deck = createDeck();
    const playerHand = [deck.pop(), deck.pop()];
    const dealerHand = [deck.pop(), deck.pop()];

    updateBalance(interaction.guild.id, interaction.user.id, -bet); // tahan taruhan dulu

    const buildEmbed = (reveal = false, resultText = null) => {
      const embed = new EmbedBuilder()
        .setColor(config.embedColor)
        .setTitle('🃏 Blackjack')
        .addFields(
          { name: t(lang, 'bj.card_you', { v: handValue(playerHand) }), value: formatHand(playerHand) },
          {
            name: reveal ? t(lang, 'bj.card_bot', { v: handValue(dealerHand) }) : t(lang, 'bj.card_hidden'),
            value: reveal ? formatHand(dealerHand) : `${dealerHand[0].rank}${dealerHand[0].suit} 🂠`,
          },
        )
        .setFooter({ text: t(lang, 'bj.bet', { bet }) });
      if (resultText) embed.setDescription(resultText);
      return embed;
    };

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('bj_hit').setLabel(t(lang, 'bj.hit')).setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('bj_stand').setLabel(t(lang, 'bj.stand')).setStyle(ButtonStyle.Secondary),
    );

    // Blackjack alami langsung menang
    if (handValue(playerHand) === 21) {
      const payout = Math.floor(bet * 2.5);
      updateBalance(interaction.guild.id, interaction.user.id, payout);
      return interaction.reply({ embeds: [buildEmbed(true, t(lang, 'bj.blackjack', { p: payout }))] });
    }

    await interaction.reply({ embeds: [buildEmbed()], components: [row] });
    const sent = await interaction.fetchReply();

    const collector = sent.createMessageComponentCollector({
      componentType: ComponentType.Button,
      filter: i => i.user.id === interaction.user.id,
      time: 60000,
    });

    collector.on('collect', async i => {
      if (i.customId === 'bj_hit') {
        playerHand.push(deck.pop());
        const total = handValue(playerHand);

        if (total > 21) {
          collector.stop('bust');
          return i.update({ embeds: [buildEmbed(true, t(lang, 'bj.bust', { bet }))], components: [] });
        }
        if (total === 21) {
          collector.stop('twentyone');
        }
        return i.update({ embeds: [buildEmbed()], components: [row] });
      }

      if (i.customId === 'bj_stand') {
        collector.stop('stand');
      }
    });

    collector.on('end', async (collected, reason) => {
      if (reason === 'bust') return; // sudah dihandle di atas

      if (reason === 'time') {
        sent.edit({ embeds: [buildEmbed(true, t(lang, 'bj.timeout', { bet }))], components: [] }).catch(() => {});
        return;
      }

      // Giliran dealer (bot) - hit sampai >= 17
      while (handValue(dealerHand) < 17) {
        dealerHand.push(deck.pop());
      }

      const playerTotal = handValue(playerHand);
      const dealerTotal = handValue(dealerHand);
      let resultText;
      let payout = 0;

      if (dealerTotal > 21 || playerTotal > dealerTotal) {
        payout = bet * 2;
        resultText = t(lang, 'bj.win', { p: playerTotal, d: dealerTotal, pay: payout });
      } else if (playerTotal === dealerTotal) {
        payout = bet;
        resultText = t(lang, 'bj.draw', { p: playerTotal, d: dealerTotal });
      } else {
        resultText = t(lang, 'bj.lose', { p: playerTotal, d: dealerTotal, bet });
      }

      if (payout > 0) updateBalance(interaction.guild.id, interaction.user.id, payout);
      sent.edit({ embeds: [buildEmbed(true, resultText)], components: [] }).catch(() => {});
    });
  },
};
