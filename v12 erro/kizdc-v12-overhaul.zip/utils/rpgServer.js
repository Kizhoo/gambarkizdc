/* ============================================================================
 * KIZHOO ADVENTURE — API SERVER RPG WEB (v2, server-authoritative)
 * ----------------------------------------------------------------------------
 * Semua mutasi penting (xp/gold/loot/craft/skill/stat) DIVALIDASI & DIROLL di
 * server — angka dari browser tidak dipercaya (anti-cheat). Dipasang lewat
 * mountRpg(app, { auth, resolveUserId, client }) dari dashboard/server.js.
 *
 * Route utama:
 *   GET  /rpg                       -> halaman game (WAJIB login Discord)
 *   GET  /api/rpg/me                -> data karakter lengkap (+stats/skill/ach)
 *   POST /api/rpg/class             -> pilih / ganti class
 *   POST /api/rpg/save              -> simpan kustomisasi & nama
 *   GET  /api/rpg/quests            -> daftar quest aktif
 *   POST /api/rpg/quest/accept      -> terima quest
 *   POST /api/rpg/battle            -> hasil battle quest (reward dihitung server)
 *   POST /api/rpg/dungeon/kill      -> bunuh monster dungeon (xp/gold/drop server)
 *   POST /api/rpg/dungeon/chest     -> buka peti (roll rarity server)
 *   POST /api/rpg/dungeon/floor     -> selesaikan lantai (tanpa hadiah)
 *   POST /api/rpg/craft             -> tempa item di pandai besi
 *   POST /api/rpg/item/use|equip|unequip|sell
 *   POST /api/rpg/stat              -> alokasi stat point
 *   POST /api/rpg/skill             -> buka / upgrade skill
 *   GET  /api/rpg/leaderboard       -> papan peringkat (nama asli, bukan ID)
 *   GET/POST /api/rpg/achievements(/claim)
 *   GET/POST /api/rpg/friends/*     -> daftar/tambah/terima/tolak/hapus
 *   GET  /api/rpg/chat/global|dm    -> riwayat chat
 *   POST /api/rpg/profile           -> nama panggung & title
 * ============================================================================
 */
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const D = require('../utils/rpgData');
const World = require('../utils/rpgWorld');
const rpgItems = require('../utils/rpgItems');
const rpgDb = require('../database/rpgDb');
const rpgEngine = require('../utils/rpgEngine');

// ---------- DEPLOY GUARD: identitas build server ----------
// WAJIB identik dengan KZ_BUILD di dashboard/public/rpg.js dan
// <meta name="kz-build"> di dashboard/public/rpg.html. Client membandingkan
// lewat GET /api/rpg/build-info; tidak cocok = ada file campur versi.
const GAME_BUILD = '2026.09.27-2';

// ---------- Pemetaan lokasi quest -> key background game ----------
const LOCATION_KEYWORDS = [
  ['bridge', ['jembatan']],
  ['forest', ['hutan', 'ladang', 'padang rumput', 'pohon']],
  ['cave', ['gua', 'goa', 'tambang', 'katakomba']],
  ['ruins', ['reruntuhan', 'kuil', 'kastil', 'menara']],
  ['night', ['malam', 'pasar malam']],
  ['volcano', ['gunung', 'lereng', 'api', 'gunung berapi']],
  ['snow', ['salju', 'bersalju', 'puncak']],
  ['lake', ['danau', 'air terjun', 'rawa', 'dermaga', 'pelabuhan']],
  ['desert', ['gurun', 'pasir']],
  ['mountain', ['pegunungan', 'jalan pegunungan']],
];
const MONSTER_KEYWORDS = [
  ['skeleton', ['undead', 'kerangka', 'zombie', 'hantu', 'wraith', 'vampir', 'banshee', 'siren', 'penyihir', 'kultus', 'roh', 'lich']],
  ['dragon', ['naga', 'wyvern', 'griffin', 'hydra', 'basilisk', 'chimera', 'manticore']],
  ['demonlord', ['iblis', 'setan', 'demon', 'demon lord']],
  ['golem', ['golem', 'gargoyle', 'troll', 'mimic', 'batu', 'laba-laba', 'elemental es', 'elemental api']],
  ['wolf', ['serigala', 'werewolf']],
  ['minotaur', ['minotaur', 'orc', 'ogre', 'bandit', 'perompak']],
  ['goblin', ['goblin', 'kobold', 'tikus', 'harpy']],
  ['slime', ['slime']],
];
function resolveLocation(text) {
  const t = String(text || '').toLowerCase();
  for (const [key, words] of LOCATION_KEYWORDS) if (words.some((w) => t.includes(w))) return key;
  return 'forest';
}
function resolveMonster(text) {
  const t = String(text || '').toLowerCase();
  for (const [key, words] of MONSTER_KEYWORDS) if (words.some((w) => t.includes(w))) return key;
  return 'goblin';
}

// ---------- appearance JSON helper ----------
function getAppearance(char) {
  try { return (char && char.appearance && JSON.parse(char.appearance)) || {}; } catch (_) { return {}; }
}
function setAppearance(userId, patch) {
  const char = rpgDb.getCharacter(userId);
  if (!char) return null;
  const merged = { ...getAppearance(char), ...patch };
  rpgDb.updateCharacter(userId, { appearance: JSON.stringify(merged) });
  return merged;
}

// ---------- Guild pemain: server mana yang dipakai dompetnya ----------
// MASALAH LAMA: wallet web selalu pakai guild PERTAMA yang di-join bot, sedangkan
// saldo /economy itu PER-SERVER — jadi angka di web beda dengan /balance di bot.
// Sekarang: pakai guild pertama yang SAMA-SAMA di-join user (OAuth) & bot.
function pickGuildId(req, client) {
  // Pilihan server dompet dari klien (guild switcher) — sudah divalidasi mutual.
  if (req.rpgGuildId) return req.rpgGuildId;
  try {
    if (req.session && Array.isArray(req.session.guilds)) {
      const ids = typeof client.guilds.cache.map === 'function'
        ? client.guilds.cache.map((g) => g.id)
        : [...client.guilds.cache.values()].map((g) => g.id);
      const botSet = new Set(ids);
      const mutual = req.session.guilds.find((g) => botSet.has(g.id));
      if (mutual) return mutual.id;
    }
  } catch (_) {}
  try {
    const first = typeof client.guilds.cache.first === 'function'
      ? client.guilds.cache.first()
      : (client.guilds.cache.values().next().value || null);
    return first ? first.id : null;
  } catch (_) {}
  return null;
}

// Guild ekonomi untuk user: mutual guild (OAuth) -> guild pertama bot ->
// guild tersimpan di karakter. TIDAK PERNAH null — insert economy punya
// constraint NOT NULL (bug 500 "economy.guildId" kalau user login Discord
// tapi belum join server mana pun yang ada bot-nya).
function safeGuildId(userId, req, client) {
  const picked = pickGuildId(req, client);
  if (picked) return picked;
  const char = rpgDb.getCharacter(userId);
  return (char && char.guildId) || 'solo';
}

// ---------- Cache username Discord (leaderboard & teman) ----------
const nameCache = new Map(); // userId -> { name, at }
async function displayName(client, userId, fallback) {
  const nowTs = Date.now();
  const hit = nameCache.get(userId);
  if (hit && nowTs - hit.at < 10 * 60 * 1000) return hit.name;
  let name = null;
  try {
    const u = client.users.cache.get(userId);
    if (u && u.username) name = u.username;
    else {
      const fetched = await client.users.fetch(userId).catch(() => null);
      if (fetched && fetched.username) name = fetched.username;
    }
  } catch (_) {}
  if (!name) name = fallback || (rpgDb.getCharacter(userId) || {}).gameName || ('Petualang ' + String(userId).slice(-4));
  nameCache.set(userId, { name, at: nowTs });
  return name;
}

// ---------- Rate limiter sederhana per user (anti spam endpoint dungeon) ----------
const rateBuckets = new Map(); // userId:action -> [timestamps]
function rateLimit(userId, action, max, windowMs) {
  const key = userId + ':' + action;
  const nowTs = Date.now();
  const arr = (rateBuckets.get(key) || []).filter((t) => nowTs - t < windowMs);
  if (arr.length >= max) return false;
  arr.push(nowTs);
  rateBuckets.set(key, arr);
  if (rateBuckets.size > 5000) rateBuckets.clear(); // safety valve
  return true;
}

function parseHex(v) {
  if (!v) return null;
  const m = /^#?([0-9a-f]{6})$/i.exec(String(v));
  return m ? parseInt(m[1], 16) : null;
}
function toHex(n) { return '#' + Number(n).toString(16).padStart(6, '0'); }

// ---------- Bentuk karakter utk game ----------
function charForGame(userId, guildId) {
  const char = rpgDb.getCharacter(userId);
  if (!char) return null;
  const wallet = rpgDb.getWallet(userId, guildId);
  const app = getAppearance(char);
  const inv = rpgDb.getInventory(userId);
  const inventory = {};
  for (const row of inv) inventory[row.itemId] = row.qty;
  const skills = rpgDb.getSkills(userId).map((s) => ({ id: s.skillId, level: s.level }));
  const stats = rpgEngine.computeStats(char);
  const ach = rpgDb.getAchievements(userId);
  const ownedPets = rpgDb.getPets(userId);
  const petActive = ownedPets.find((p) => p.petId === char.activePetId) || null;
  return {
    name: app.name || char.gameName || null,
    classKey: app.choseClass ? char.className : null,
    className: char.className,
    level: char.level,
    xp: char.xp,
    xpForNext: D.xpForLevel(char.level),
    gold: wallet.gold,
    silver: wallet.silver,
    copper: wallet.copper,
    rankKey: char.rankKey,
    statPoints: char.statPoints,
    skillPoints: char.skillPoints,
    reputation: char.reputation,
    monstersKilled: char.monstersKilled,
    questsCompleted: char.questsCompleted,
    dungeonsCleared: char.dungeonsCleared,
    bossesDefeated: char.bossesDefeated,
    wins: char.wins,
    losses: char.losses,
    floorsCleared: char.floorsCleared,
    chestsOpened: char.chestsOpened,
    mimicsKilled: char.mimicsKilled,
    itemsCrafted: char.itemsCrafted,
    friendId: rpgDb.ensureFriendId(userId),
    title: char.title || '',
    unlockedTitles: app.titles || [],
    customization: {
      skin: parseHex(app.skin) || 0xf1c27d,
      hairStyle: char.hairStyle || 'short',
      hairColor: parseHex(char.hairColor) || 0x1f2937,
      outfit: parseHex(char.outfitColor) || parseHex((D.CLASSES[char.className] || {}).color) || 0xdc2626,
      pants: parseHex(char.pantsColor) || 0x472a19,
      shoes: parseHex(char.shoesColor) || 0x0b0b12,
    },
    equipped: { weapon: char.equipWeapon, armor: char.equipArmor, accessory: char.equipAccessory },
    inventory,
    skills,
    stats,
    dungeon: { cleared: app.dungeonCleared || char.dungeonsCleared || 0, unlocked: app.dungeonUnlocked || 1 },
    // SELALU array: karakter baru belum punya progres dungeon (null di appearance).
    // Klien menormalkan array kosong jadi daftar dungeon default via afterLoad().
    dungeons: Array.isArray(app.dungeons) ? app.dungeons : [],
    cardBg: app.cardBg || null,
    cardBgUrl: app.cardBgUrl || null,
    activeQuests: app.activeQuests || [],
    completedQuestIds: app.completedQuestIds || [],
    pet: petActive ? { id: petActive.petId, level: petActive.level, xp: petActive.xp, stage: petActive.stage || 1 } : null,
    pets: ownedPets.map((p) => ({ id: p.petId, level: p.level, xp: p.xp, stage: p.stage || 1 })),
    gems: char.gems || 0,
    petShards: char.petShards || 0,
    gacha: {
      pulled: char.gachaPulled || 0,
      pityEpic: char.pitySinceEpic || 0,
      pityLegendary: char.pitySinceLegendary || 0,
      pityMythic: char.pitySinceMythic || 0,
    },
    towerBest: char.towerBest || 0,
    prestigeLevel: char.prestigeLevel || 0,
    bestCombo: char.bestCombo || 0,
  };
}

// ---------- Evaluasi achievement (progress dihitung dari data hidup) ----------
function computeAchievements(userId) {
  const char = rpgDb.getCharacter(userId);
  if (!char) return [];
  const inv = rpgDb.getInventory(userId);
  const skills = rpgDb.getSkills(userId);
  const friendsCount = rpgDb.getFriends(userId).length;
  const unlocked = new Map(rpgDb.getAchievements(userId).map((a) => [a.achId, a]));
  const petsOwned = rpgDb.getPets(userId).length;
  const petMaxLevel = rpgDb.getPets(userId).reduce((m, p) => Math.max(m, p.level), 0);

  // Agregat inventory untuk kondisi koleksi.
  const tierIdx = { common: 0, uncommon: 1, rare: 2, epic: 3, legendary: 4, mythic: 5 };
  let bestTier = -1, matKinds = 0;
  for (const row of inv) {
    const it = rpgItems.getItem(row.itemId);
    if (!it) continue;
    if (it.category === 'material') matKinds++;
    if (tierIdx[it.tier] != null && tierIdx[it.tier] > bestTier) bestTier = tierIdx[it.tier];
  }
  let maxedSkills = 0;
  for (const s of skills) {
    const def = D.skillById(char.className, s.skillId);
    if (def && s.level >= def.maxLevel) maxedSkills++;
  }

  const specialValues = {
    friends: friendsCount,
    tierItem: bestTier, // index tier tertinggi yang dimiliki
    matKinds,
    gold: rpgDb.getCharacter(userId).gold || 0, // gold RPG kolom lama (bukan economy) — sisa
    maxedSkills,
    rankAtLeast: D.RANK_INDEX[char.rankKey] || 0,
    petsOwned,
    petMaxLevel,
  };

  const out = [];
  const newlyUnlocked = [];
  for (const def of D.ACHIEVEMENTS) {
    let current = 0, target = 1, done = false;
    if (def.cond.type === 'counter') {
      current = Math.min(char[def.cond.stat] || 0, def.cond.target);
      target = def.cond.target;
      done = (char[def.cond.stat] || 0) >= def.cond.target;
    } else {
      const key = def.cond.key;
      if (key === 'tierItem' || key === 'rankAtLeast') {
        const map = key === 'tierItem' ? tierIdx : D.RANK_INDEX;
        current = specialValues[key];
        target = map[def.cond.target] != null ? map[def.cond.target] : 1;
        done = current >= target;
      } else {
        target = def.cond.target;
        current = Math.min(specialValues[key] || 0, target);
        done = (specialValues[key] || 0) >= target;
      }
    }
    const rec = unlocked.get(def.id);
    if (done && !rec) {
      rpgDb.unlockAchievement(userId, def.id);
      newlyUnlocked.push(def.id);
      out.push({ ...def, progress: { current: target, target }, unlocked: true, claimed: false, justNow: true });
    } else if (rec) {
      out.push({ ...def, progress: { current: target, target }, unlocked: true, claimed: !!rec.claimed });
    } else {
      out.push({ ...def, progress: { current, target }, unlocked: false, claimed: false });
    }
  }
  return { list: out, newlyUnlocked };
}

/* ============================================================================
 * MOUNT ROUTES
 * ========================================================================== */
function mountRpg(app, { auth, resolveUserId, client }) {
  const jsonError = (res, code, msg) => res.status(code).json({ error: msg });

  // --- GUILD SWITCHER: server dompet pilihan pemain ------------------------
  // KZC RPG memakai saldo /economy yang PER-SERVER. Dulu web selalu membawa
  // saldo guild mutual PERTAMA sehingga beda dengan /balance di server lain
  // ("uang di web gak sinkron sama bot"). Klien mengirim header X-RPG-Guild;
  // divalidasi terhadap daftar guild OAuth session — hanya guild mutual sah.
  app.use('/api/rpg', (req, res, next) => {
    try {
      const want = String(req.get('x-rpg-guild') || '').trim();
      if (want) {
        const cookies = {};
        String(req.headers.cookie || '').split(';').forEach((p) => {
          const i = p.indexOf('=');
          if (i > -1) cookies[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
        });
        const session = cookies.kz_sid ? rpgDb.getSession(cookies.kz_sid) : null;
        const guilds = (session && Array.isArray(session.guilds)) ? session.guilds.map((g) => g.id) : [];
        if (guilds.includes(want)) req.rpgGuildId = want;
      }
    } catch (_) {}
    next();
  });

  // --- Halaman game: WAJIB login Discord dulu (redirect ke OAuth) ---
  app.get('/rpg', (req, res) => {
    const candidates = [
      path.join(__dirname, '..', 'dashboard', 'public', 'rpg.html'),
      path.join(__dirname, 'public', 'rpg.html'),
    ];
    const file = candidates.find((p) => fs.existsSync(p));
    if (!file) return res.status(404).send('rpg.html tidak ditemukan di dashboard/public/');
    // Cek session cookie (kz_sid) — kalau tidak ada, arahkan login dulu.
    const cookies = {};
    String(req.headers.cookie || '').split(';').forEach((p) => {
      const i = p.indexOf('=');
      if (i > -1) cookies[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
    });
    const session = cookies.kz_sid ? rpgDb.getSession(cookies.kz_sid) : null;
    if (!session) return res.redirect('/auth/login?next=' + encodeURIComponent('/rpg'));
    try {
      let html = fs.readFileSync(file, 'utf8');
      // CSP nonce: setiap serve, semua <script> inline rpg.html diberi nonce
      // acak dan header CSP hanya mengizinkan script bernonce itu (script-src
      // tanpa 'unsafe-inline') — injected script oleh kloner/MITM tidak jalan.
      const Sec = require('./security');
      const nonce = crypto.randomBytes(16).toString('base64');
      html = html.replace(/<script>/g, `<script nonce="${nonce}">`);
      html = html.replace('server: false', 'server: true');
      // Suntik identitas user supaya game tahu siapa yang main (tanpa round-trip).
      const cfg = { server: true, userId: session.userId, username: session.username, avatar: session.avatar || null, apiBase: '' };
      html = html.replace('window.RPG_CONFIG = window.RPG_CONFIG || { server: false, userId: null, guildId: null, apiBase: \'\'; }',
        'window.RPG_CONFIG = ' + JSON.stringify(cfg).replace(/</g, '\\u003c') + ';');
      html = html.replace(/window\.RPG_CONFIG = window\.RPG_CONFIG \|\| \{[^}]*\};/, 'window.RPG_CONFIG = ' + JSON.stringify(cfg).replace(/</g, '\\u003c') + ';');
      // Suntik daftar domain resmi — dibaca SECURITY GATE di dalam rpg.js
      // (sumber verifikasi kedua, tak bisa dipalsukan situs kloningan statis).
      const bake = JSON.stringify({ domains: Sec.manifestPayload().domains }).replace(/</g, '\\u003c');
      html = html.replace('</head>', `<script nonce="${nonce}">window.__KZ_SEC_BAKE = ${bake};</script>\n</head>`);
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.setHeader('Content-Security-Policy', Sec.cspFor(res, { nonce }));
      res.setHeader('Cache-Control', 'no-store');
      return res.send(html);
    } catch (_) {
      return res.status(500).send('Gagal memuat rpg.html');
    }
  });

  const requireChar = (req, res) => {
    const userId = resolveUserId(req);
    if (!userId) { jsonError(res, 400, 'Identitas user tidak diketahui (login Discord dulu)'); return null; }
    return userId;
  };

  // --- DEPLOY GUARD: info build (publik — diagnostik pasca-deploy, tanpa data sensitif) ---
  app.get('/api/rpg/build-info', (req, res) => {
    res.json({ ok: true, game: 'kizhoo-adventure', build: GAME_BUILD });
  });

  // --- DEPLOY GUARD: integritas aset game (publik — cek kelengkapan file) ---
  // Dipakai untuk memverifikasi upload ke hosting TIDAK terpotong / campur
  // versi lama. Buka langsung: /api/rpg/asset-integrity setelah deploy.
  // v10: daftar lobby via REST — fallback saat hosting tidak meneruskan WebSocket
  // (mode hemat): UI multiplayer tetap bisa menampilkan lobby terbuka.
  app.get('/api/rpg/mp/lobbies', auth, (req, res) => {
    const lobbies = global.__rpgLobbies;
    const out = [];
    if (lobbies) {
      for (const lob of lobbies.values()) {
        out.push({ code: lob.code, name: lob.name, count: lob.members ? lob.members.size : 1, max: 4 });
      }
    }
    res.json({ ok: true, lobbies: out });
  });

  app.get('/api/rpg/asset-integrity', (req, res) => {
    const pub = path.join(__dirname, '..', 'dashboard', 'public');
    const missing = [];
    // File kritis satu-per-satu (game rusak total tanpa ini).
    ['assets/atlas.png', 'assets/atlas.json', 'assets/vendor/phaser.min.js',
     'assets/hero/archer_sheet.png', 'assets/hero/assassin_sheet.png',
     'assets/hero/warrior.png', 'assets/hero/mage.png', 'assets/hero/assassin.png', 'assets/hero/archer.png',
     'rpg.html', 'rpg.js', 'rpg.min.js', 'security-lock.js',
     // v9: UI kit + objek interaksi (sistem interact & tampilan bergantung ini).
     'assets/ui/btn.png', 'assets/ui/panel.png', 'assets/ui/prompt.png', 'assets/ui/orb.png',
     'assets/ui/key_e.png', 'assets/ui/bar_fill.png', 'assets/ui/vignette.png',
     'assets/interact/chest_wood.png', 'assets/interact/chest_mimic.png', 'assets/interact/merchant.png',
     'assets/interact/portal.png', 'assets/interact/altar.png', 'assets/interact/smith.png',
     'assets/backgrounds/bg_lobby.png', 'assets/backgrounds/bg_forge.png',
     // v10: font self-host + api unggun + sprite interaksi baru.
     'fonts/press-start-2p.woff2', 'fonts/silkscreen-400.woff2', 'fonts/silkscreen-700.woff2',
     'assets/deco/campfire.png', 'assets/interact/merchant_stall.png', 'assets/interact/secret_crack.png',
     // v11: VFX skill animasi aset internet + sheet pet baru + kredit aset.
     'assets/fx/vfx_fire.png', 'assets/fx/vfx_ice.png', 'assets/fx/vfx_water.png', 'assets/fx/vfx_arcane.png',
     'assets/fx/vfx_slash.png', 'assets/fx/vfx_circle.png', 'assets/fx/vfx_aura_fire.png',
     'assets/fx/vfx_firelion.png', 'assets/fx/vfx_lightning.png', 'assets/fx/vfx_tornado.png',
     'assets/pets/ember.png', 'assets/pets/nyx.png', 'assets/pets/solara_evo.png',
     'assets/CREDITS-ASSETS.md',
     // v12: atlas pet (1 file untuk 30 sheet) + PWA.
     'assets/pets_atlas.png', 'assets/pets_atlas.json',
     'manifest.webmanifest', 'sw.js',
     'assets/icons-pwa/icon-192.png', 'assets/icons-pwa/icon-512.png',
    ].forEach((f) => { if (!fs.existsSync(path.join(pub, f))) missing.push(f); });
    // Folder aset: jumlah file minimal (upload terpotong -> jumlah berkurang).
    const expectDir = {
      'assets/fx': 28, 'assets/icons': 60, 'assets/pets': 30, 'assets/monsters': 23,
      'assets/backgrounds': 16, 'assets/backgrounds/strips': 7, 'assets/backgrounds/forest_layers': 4,
      'assets/gear': 21, 'assets/deco': 14, 'assets/deco/rocks': 10, 'assets/tiles': 2, 'assets/items': 5, 'assets/skills': 12,
      'assets/ui': 17, 'assets/ui/icons': 51, 'assets/interact': 10, 'fonts': 3,
    };
    let checked = 30;
    Object.entries(expectDir).forEach(([dir, min]) => {
      checked += min;
      const p = path.join(pub, dir);
      let n = 0;
      try { n = fs.readdirSync(p).filter((f) => f.endsWith('.png') || f.endsWith('.json') || f.endsWith('.js') || f.endsWith('.woff2')).length; } catch (_) {}
      if (n < min) missing.push(dir + '/ (hanya ' + n + ' file, minimal ' + min + ')');
    });
    res.status(missing.length ? 409 : 200).json({
      ok: missing.length === 0, build: GAME_BUILD, checked,
      missing: missing.slice(0, 40),
      hint: missing.length ? 'Deploy tidak lengkap: hapus folder lama di hosting lalu upload ulang zip terbaru PENUH.' : undefined,
    });
  });

  // --- Data karakter lengkap ---
  app.get('/api/rpg/me', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const guildId = safeGuildId(userId, req, client);
    const char = charForGame(userId, guildId);
    if (!char) return res.json({ char: null });
    if (!char.name && req.session) char.name = req.session.username;
    return res.json({ char, user: { username: req.session ? req.session.username : null, avatar: req.session ? req.session.avatar : null } });
  });

  // --- Pilih / ganti class ---
  app.post('/api/rpg/class', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const classKey = String((req.body && req.body.classKey) || '');
    if (!D.CLASSES[classKey]) return jsonError(res, 400, 'Class tidak dikenal.');
    let char = rpgDb.getCharacter(userId);
    if (!char) { char = rpgDb.createCharacter(userId, classKey); }
    const app0 = getAppearance(char);
    if (!app0.choseClass) {
      // Pemilihan pertama: set class + kasih modal skill point.
      rpgDb.updateCharacter(userId, { className: classKey, skillPoints: Math.max(char.skillPoints, 1) });
      setAppearance(userId, { choseClass: 1 });
    } else if (char.className !== classKey) {
      // Ganti class: pakai engine (refund skill & stat point).
      rpgEngine.changeClass(userId, classKey);
    }
    const guildId = safeGuildId(userId, req, client);
    return res.json({ ok: true, char: charForGame(userId, guildId) });
  });

  // --- Simpan kustomisasi/nama/latar/progres dungeon ---
  app.post('/api/rpg/save', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const c = (req.body && req.body.char) || req.body || {};
    const patch = {};
    if (c.name != null) {
      const clean = String(c.name).replace(/\s+/g, ' ').trim().slice(0, 16);
      if (clean) { patch.name = clean; rpgDb.updateCharacter(userId, { gameName: clean }); }
    }
    if (c.cardBg != null) patch.cardBg = String(c.cardBg).slice(0, 32);
    if (c.cardBgUrl != null) patch.cardBgUrl = String(c.cardBgUrl).slice(0, 400);
    const cust = c.customization || {};
    if (cust && typeof cust === 'object') {
      if (cust.skin != null) patch.skin = cust.skin;
      if (cust.hairStyle) rpgDb.updateCharacter(userId, { hairStyle: String(cust.hairStyle).slice(0, 16) });
      if (cust.hairColor != null) rpgDb.updateCharacter(userId, { hairColor: toHex(cust.hairColor) });
      if (cust.outfit != null) rpgDb.updateCharacter(userId, { outfitColor: toHex(cust.outfit) });
      if (cust.pants != null) rpgDb.updateCharacter(userId, { pantsColor: toHex(cust.pants) });
      if (cust.shoes != null) rpgDb.updateCharacter(userId, { shoesColor: toHex(cust.shoes) });
    }
    const dungeon = c.dungeon;
    if (dungeon && typeof dungeon === 'object') {
      if (dungeon.cleared != null) patch.dungeonCleared = Math.max(0, Math.floor(dungeon.cleared));
      if (dungeon.unlocked != null) patch.dungeonUnlocked = Math.max(1, Math.floor(dungeon.unlocked));
    }
    if (Array.isArray(c.dungeons)) patch.dungeons = c.dungeons.slice(0, 40);
    if (Array.isArray(c.activeQuests)) patch.activeQuests = c.activeQuests.slice(0, 30);
    if (Array.isArray(c.completedQuestIds)) patch.completedQuestIds = c.completedQuestIds.slice(0, 500);
    setAppearance(userId, patch);
    return res.json({ ok: true });
  });

  // --- Daftar quest ---
  app.get('/api/rpg/quests', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const guildId = safeGuildId(userId, req, client);
    rpgDb.deactivateExpiredQuests();
    let list = rpgDb.listActiveQuests('global', 20);
    if (!list.length && guildId) list = rpgDb.listActiveQuests(guildId, 20);
    const char = rpgDb.getCharacter(userId);
    const done = getAppearance(char || {}).completedQuestIds || [];
    const active = getAppearance(char || {}).activeQuests || [];
    const quests = list.map((q) => {
      const isBoss = q.objectiveType === 'bossesDefeated';
      const monster = resolveMonster(q.monsterHint || q.title + ' ' + q.description);
      const location = resolveLocation(q.description + ' ' + q.title);
      return {
        id: q.questId, title: q.title, desc: q.description, location, monster,
        count: q.objectiveTarget, tier: isBoss ? 'boss' : 'normal', minRank: q.minRank,
        rewardXp: q.rewardXp, rewardGold: q.rewardGold, rewardRep: q.rewardRep,
        accepted: active.includes(q.questId), done: done.includes(q.questId),
      };
    });
    return res.json({ quests });
  });

  app.post('/api/rpg/quest/accept', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const questId = Number(req.body && req.body.questId);
    const q = questId ? rpgDb.getQuest(questId) : null;
    if (!q || !rpgDb.isQuestOpen(q)) return jsonError(res, 400, 'Quest tidak tersedia.');
    const char = rpgDb.getCharacter(userId);
    const app0 = getAppearance(char || {});
    const active = app0.activeQuests || [];
    if (!active.includes(questId)) { active.push(questId); setAppearance(userId, { activeQuests: active.slice(0, 30) }); }
    return res.json({ ok: true });
  });

  // --- Hasil battle quest: reward dihitung SERVER dari data quest + monster ---
  app.post('/api/rpg/battle', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const guildId = safeGuildId(userId, req, client);
    // v12 §9-C3: rate limit — tanpa ini spam POST battle bisa memompa XP/gold
    // (dungeon/kill sudah punya, battle belum). 12 laporan/menit cukup longgar
    // untuk pemain normal, ketat untuk bot farming.
    if (!rateLimit(userId, 'battle', 12, 60 * 1000)) return jsonError(res, 429, 'Terlalu banyak laporan battle. Pelan-pelan.');
    const win = req.body && req.body.win === true;
    const questId = req.body && req.body.questId != null ? Number(req.body.questId) : null;

    if (!win) {
      rpgDb.incCharacter(userId, 'losses', 1);
      return res.json({ ok: true, rewards: { xp: 0, gold: 0, rep: 0 } });
    }
    rpgDb.incCharacter(userId, 'wins', 1);
    const q = questId != null ? rpgDb.getQuest(questId) : null;
    const awarded = { xp: 0, gold: 0, rep: 0, drops: [] };
    if (q && rpgDb.isQuestOpen(q)) {
      const mon = World.monsterById(resolveMonster(q.monsterHint || q.title + ' ' + q.description)) || { xp: 150, gold: 60 };
      const count = Math.max(1, Math.min(50, Math.floor(Number(q.objectiveTarget) || 1)));
      awarded.xp = (q.rewardXp || 0) + Math.floor(Number(mon.xp) || 0) * count;
      awarded.gold = (q.rewardGold || 0) + Math.floor(Number(mon.gold) || 0) * count;
      awarded.rep = q.rewardRep || 0;
      // Roll drop material server-side dari monster quest.
      const drops = World.MONSTER_DROPS[mon.id] || [];
      for (const d of drops) if (Math.random() < (d.rate || 0.5) * 0.8) { rpgDb.addItem(userId, d.id, 1); awarded.drops.push(d.id); }
      const lv = rpgEngine.addExp(userId, awarded.xp, guildId);
      rpgDb.addGold(userId, guildId, awarded.gold);
      rpgDb.incCharacter(userId, 'monstersKilled', count);
      if (q.rewardRep) rpgDb.incCharacter(userId, 'reputation', q.rewardRep);
      rpgDb.advanceQuestProgress(userId, q.objectiveType, q.objectiveTarget);
      rpgDb.incCharacter(userId, 'questsCompleted', 1);
      awarded.levelUp = lv.leveledUp ? { from: lv.fromLevel, to: lv.toLevel, skillPoints: lv.skillPointsGained, statPoints: lv.statPointsGained } : null;
      // Pet aktif ikut menyerap pengalaman (30% XP player).
      const ap = rpgDb.getActivePet(userId);
      if (ap) awarded.petXp = rpgDb.addPetXp(userId, ap.petId, Math.floor(awarded.xp * 0.3));
      // Tandai quest selesai di appearance (untuk papan quest web).
      const char2 = rpgDb.getCharacter(userId);
      const app2 = getAppearance(char2);
      const done = app2.completedQuestIds || [];
      if (!done.includes(q.questId)) done.push(q.questId);
      setAppearance(userId, { completedQuestIds: done.slice(0, 500), activeQuests: (app2.activeQuests || []).filter((x) => x !== q.questId) });
    } else {
      awarded.xp = 20; awarded.gold = 10;
      rpgDb.incCharacter(userId, 'monstersKilled', 1);
      rpgEngine.addExp(userId, awarded.xp, guildId);
      rpgDb.addGold(userId, guildId, awarded.gold);
      const ap0 = rpgDb.getActivePet(userId);
      if (ap0) awarded.petXp = rpgDb.addPetXp(userId, ap0.petId, Math.floor(awarded.xp * 0.3));
    }
    return res.json({ ok: true, rewards: awarded });
  });

  // --- Bunuh monster di DUNGEON: validasi + xp/gold/drop dihitung server ---
  app.post('/api/rpg/dungeon/kill', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const guildId = safeGuildId(userId, req, client);
    const char = rpgDb.getCharacter(userId);
    if (!char) return jsonError(res, 400, 'Karakter belum dibuat.');
    if (!rateLimit(userId, 'dkill', 40, 60 * 1000)) return jsonError(res, 429, 'Terlalu banyak aksi. Pelan-pelan.');

    const b = req.body || {};
    const floor = Math.max(1, Math.min(99, Math.floor(Number(b.floor) || 1)));
    const isMimic = b.isMimic === true;
    const isBoss = b.isBoss === true;
    const isChampion = b.isChampion === true;

    let mon;
    if (isMimic) {
      mon = World.mimicStats(floor);
      mon.id = 'mimic'; mon.name = 'Mimic'; mon.tier = 'elite';
    } else {
      mon = World.monsterById(String(b.monsterId || ''));
      if (!mon) return jsonError(res, 400, 'Monster tidak dikenal.');
      if (!World.monsterValidForFloor(mon.id, floor)) return jsonError(res, 400, 'Monster tidak cocok untuk lantai itu.');
    }

    // Reward dasar dari tabel monster (dungeon sedikit lebih hemat dari quest).
    let xp = Math.round(mon.xp * 0.8);
    let gold = Math.round(mon.gold * 0.8);
    if (isChampion) { xp = Math.round(xp * 2.2); gold = Math.round(gold * 2.2); }
    if (isBoss) { xp = Math.round(xp * 1.2); gold = Math.round(gold * 1.2); }

    // goldFind dari equipment (server-side, anti cheat).
    const eff = rpgItems.equipEffects(char);
    if (eff.goldFind) gold = Math.round(gold * (1 + eff.goldFind));

    // Roll drop material server-side.
    const drops = [];
    if (!isMimic) {
      const table = World.MONSTER_DROPS[mon.id] || [];
      for (const d of table) if (Math.random() < d.rate) { rpgDb.addItem(userId, d.id, 1); drops.push(d.id); }
      if (isChampion && table.length && Math.random() < 0.8) {
        const extra = table[0].id;
        rpgDb.addItem(userId, extra, 1); drops.push(extra);
      }
    } else {
      // Mimic menjatuhkan recehan emas ekstra + material acak.
      gold = Math.round(gold * 1.6);
      const mats = Object.keys(World.MONSTER_DROPS);
      const bonusMat = mats[Math.floor(Math.random() * mats.length)];
      rpgDb.addItem(userId, World.MONSTER_DROPS[bonusMat][0].id, 1);
      drops.push(World.MONSTER_DROPS[bonusMat][0].id);
    }

    rpgDb.incCharacter(userId, 'monstersKilled', 1);
    if (isMimic) rpgDb.incCharacter(userId, 'mimicsKilled', 1);
    if (isBoss && !isMimic) rpgDb.incCharacter(userId, 'bossesDefeated', 1);
    const lv = rpgEngine.addExp(userId, xp, guildId);
    rpgDb.addGold(userId, guildId, gold);
    // Boss menjatuhkan permata (bahan gacha).
    let gems = 0;
    if (isBoss && !isMimic) { gems = 4 + Math.floor(floor / 4); rpgDb.addGems(userId, gems); }
    else if (isChampion && Math.random() < 0.3) { gems = 1 + Math.floor(floor / 8); rpgDb.addGems(userId, gems); }
    // Pet aktif ikut menyerap pengalaman (30% XP player).
    const activePet = rpgDb.getActivePet(userId);
    const petXp = activePet ? rpgDb.addPetXp(userId, activePet.petId, Math.floor(xp * 0.3)) : null;

    return res.json({
      ok: true,
      rewards: { xp, gold, drops, gems, pet: petXp ? { id: activePet.petId, ...petXp } : null },
      levelUp: lv.leveledUp ? { from: lv.fromLevel, to: lv.toLevel, skillPoints: lv.skillPointsGained, statPoints: lv.statPointsGained } : null,
      wallet: rpgDb.getWallet(userId, guildId),
    });
  });

  // --- Buka peti dungeon: rarity & isi diROLL SERVER ---
  app.post('/api/rpg/dungeon/chest', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const guildId = safeGuildId(userId, req, client);
    if (!rpgDb.getCharacter(userId)) return jsonError(res, 400, 'Karakter belum dibuat.');
    if (!rateLimit(userId, 'dchest', 15, 5 * 60 * 1000)) return jsonError(res, 429, 'Terlalu banyak peti dibuka.');
    const b = req.body || {};
    const floor = Math.max(1, Math.min(99, Math.floor(Number(b.floor) || 1)));
    const chestTier = ['wood', 'silver', 'gold'].includes(b.tier) ? b.tier : 'wood';
    const bias = chestTier === 'gold' ? 2 : chestTier === 'silver' ? 1 : 0;

    const tier = World.rollTier(floor, bias);
    const gold = World.rollChestGold(floor, chestTier);
    // Peti kayu bisa kosong isinya (cuma gold); perak/emas selalu berisi item.
    let item = null;
    if (chestTier !== 'wood' || Math.random() < 0.65) item = World.rollChestItem(tier);
    // Pet HANYA dari gacha — peti memberi pecahan bintang + sesekali permata.
    let shards = 0, gems = 0;
    const shardBase = { wood: 2, silver: 4, gold: 8 }[chestTier] + Math.floor(floor / 8);
    shards = shardBase + Math.floor(Math.random() * (2 + bias * 2));
    if (Math.random() < 0.06 + bias * 0.05) gems = 3 + Math.floor(Math.random() * 4) + bias * 2;

    rpgDb.addGold(userId, guildId, gold);
    if (item) rpgDb.addItem(userId, item, 1);
    rpgDb.addPetShards(userId, shards);
    if (gems) rpgDb.addGems(userId, gems);
    rpgDb.incCharacter(userId, 'chestsOpened', 1);
    return res.json({ ok: true, loot: { gold, item, tier, shards, gems }, wallet: rpgDb.getWallet(userId, guildId) });
  });

  // --- Selesaikan lantai: TANPA hadiah (hadiah ada di peti & monster) ---
  app.post('/api/rpg/dungeon/floor', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const char = rpgDb.getCharacter(userId);
    if (!char) return jsonError(res, 400, 'Karakter belum dibuat.');
    const b = req.body || {};
    const floor = Math.max(1, Math.min(99, Math.floor(Number(b.floor) || 1)));
    const dungeons = getAppearance(char).dungeons || [];
    const d = dungeons.find((x) => String(x.id) === String(b.dungeonId || ''));
    const app0 = getAppearance(char);
    if (d) {
      d.cleared = Math.max(d.cleared || 0, floor);
      d.unlocked = Math.max(d.unlocked || 1, Math.min(d.floors || 20, floor + 1));
      if (floor >= (d.floors || 20) && !d.completed) {
        d.completed = true;
        rpgDb.incCharacter(userId, 'dungeonsCleared', 1);
      }
      setAppearance(userId, { dungeons });
    }
    rpgDb.incCharacter(userId, 'floorsCleared', 1);
    // Permata kecil tiap lantai dungeon (bahan gacha) + ekstra di lantai akhir.
    const gems = floor % 5 === 0 ? 4 : 2;
    rpgDb.addGems(userId, gems);
    return res.json({ ok: true, gems });
  });

  // --- Tempa item di pandai besi (validasi material server-side) ---
  app.post('/api/rpg/craft', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const char = rpgDb.getCharacter(userId);
    if (!char) return jsonError(res, 400, 'Karakter belum dibuat.');
    const out = String((req.body && req.body.out) || '');
    const recipe = rpgItems.FORGE_RECIPES.find((r) => r.out === out);
    if (!recipe) return jsonError(res, 400, 'Resep tidak dikenal.');
    const it = rpgItems.getItem(out);
    if (!it) return jsonError(res, 400, 'Item tidak dikenal.');
    // Cek bahan dulu — jangan kurangi separuh lalu gagal.
    for (const [mat, need] of Object.entries(recipe.cost)) {
      if (rpgDb.getItemQty(userId, mat) < need) {
        return jsonError(res, 400, 'Bahan kurang: ' + ((rpgItems.getItem(mat) || {}).name || mat));
      }
    }
    for (const [mat, need] of Object.entries(recipe.cost)) rpgDb.removeItem(userId, mat, need);
    rpgDb.addItem(userId, out, 1);
    rpgDb.incCharacter(userId, 'itemsCrafted', 1);
    return res.json({ ok: true, item: { id: it.id, name: it.name, tier: it.tier } });
  });

  // --- Pakai ramuan / material ber-effek / seruling pet / camilan pet ---
  app.post('/api/rpg/item/use', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const itemId = String((req.body && req.body.itemId) || '');
    const it = rpgItems.getItem(itemId);
    if (!it) return jsonError(res, 400, 'Item tidak dikenal.');
    const usable = (it.category === 'potion' && it.effect) || (it.category === 'material' && it.use);
    if (!usable) return jsonError(res, 400, 'Item ini tidak bisa dipakai.');
    if (rpgDb.getItemQty(userId, it.id) < 1) return jsonError(res, 400, 'Item tidak ada di tas.');

    // --- Seruling panggil pet: sekarang ditukar jadi permata gacha + pecahan ---
    // (pet hanya bisa didapat dari gacha; seruling lama tetap berharga)
    if (usable.kind === 'petroll') {
      rpgDb.removeItem(userId, it.id, 1);
      const gemTable = { common: 70, uncommon: 110, rare: 170, epic: 260, legendary: 400, mythic: 550 };
      const gems = gemTable[it.tier] || 70;
      const shards = 10 + Math.floor((gemTable[it.tier] || 70) / 10);
      rpgDb.addGems(userId, gems);
      rpgDb.addPetShards(userId, shards);
      return res.json({ ok: true, exchanged: { gems, shards }, effect: usable });
    }
    // --- Camilan: beri XP ke pet aktif ---
    if (usable.kind === 'petxp') {
      const ap = rpgDb.getActivePet(userId);
      if (!ap) return jsonError(res, 400, 'Tidak ada pet aktif. Aktifkan pet dulu di menu Pet.');
      rpgDb.removeItem(userId, it.id, 1);
      const r = rpgDb.addPetXp(userId, ap.petId, usable.val);
      return res.json({ ok: true, pet: { id: ap.petId, ...r }, effect: usable });
    }

    rpgDb.removeItem(userId, it.id, 1);
    if (it.category === 'potion') rpgDb.incCharacter(userId, 'potionsUsed', 1);
    return res.json({ ok: true, effect: usable });
  });

  // --- Koleksi & aktivasi PET ---
  app.get('/api/rpg/pets', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const owned = rpgDb.getPets(userId);
    const ownedMap = new Map(owned.map((p) => [p.petId, p]));
    const char = rpgDb.getCharacter(userId);
    const pets = D.PETS.map((p) => {
      const o = ownedMap.get(p.id);
      return {
        ...p,
        owned: !!o,
        level: o ? o.level : 0,
        xp: o ? o.xp : 0,
        stage: o ? (o.stage || 1) : 1,
        xpNeed: D.petXpForLevel(o ? o.level : 1),
        active: char.activePetId === p.id,
        evolution: D.PET_EVOLUTION[p.id] || null,
      };
    });
    return res.json({ ok: true, pets, activePetId: char.activePetId || null, levelCap: D.PET_LEVEL_CAP, petShards: char.petShards || 0 });
  });
  app.post('/api/rpg/pet/activate', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const petId = String((req.body && req.body.petId) || '');
    if (!D.PET_BY_ID[petId]) return jsonError(res, 400, 'Pet tidak dikenal.');
    const r = rpgDb.setActivePet(userId, petId);
    if (!r.ok) return jsonError(res, 400, r.error);
    return res.json({ ok: true, activePetId: petId });
  });

  /* ==========================================================================
   * GACHA PET — satu-satunya sumber pet. Rates + pity server-authoritative.
   * ======================================================================== */
  const RARITY_ORDER = ['common', 'uncommon', 'rare', 'epic', 'legendary', 'mythic'];
  function rollRarity(char) {
    const G = D.GACHA;
    // Pity berlapis: mythic -> legendary+ -> epic+.
    if ((char.pitySinceMythic || 0) + 1 >= G.pityMythicAt) return 'mythic';
    if ((char.pitySinceLegendary || 0) + 1 >= G.pityLegendaryAt) {
      return Math.random() < 0.12 ? 'mythic' : 'legendary';
    }
    if ((char.pitySinceEpic || 0) + 1 >= G.pityEpicAt) {
      const r = Math.random();
      if (r < 0.03) return 'mythic';
      if (r < 0.18) return 'legendary';
      return 'epic';
    }
    let roll = Math.random(), acc = 0;
    for (const k of RARITY_ORDER) { acc += G.rates[k]; if (roll < acc) return k; }
    return 'common';
  }
  app.get('/api/rpg/gacha', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const char = rpgDb.getCharacter(userId);
    return res.json({
      ok: true,
      gems: char.gems || 0,
      petShards: char.petShards || 0,
      config: {
        cost: D.GACHA.cost, cost10: D.GACHA.cost10, rates: D.GACHA.rates,
        pityEpicAt: D.GACHA.pityEpicAt, pityLegendaryAt: D.GACHA.pityLegendaryAt, pityMythicAt: D.GACHA.pityMythicAt,
        shardFromDupe: D.GACHA.shardFromDupe, goldToGems: D.GACHA.goldToGems,
      },
      pity: {
        epic: char.pitySinceEpic || 0,
        legendary: char.pitySinceLegendary || 0,
        mythic: char.pitySinceMythic || 0,
      },
      pulled: char.gachaPulled || 0,
    });
  });
  app.post('/api/rpg/gacha/pull', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const guildId = safeGuildId(userId, req, client);
    if (!rateLimit(userId, 'gacha', 12, 60 * 1000)) return jsonError(res, 429, 'Terlalu banyak tarikan, istirahat sebentar.');
    const count = Number(req.body && req.body.count) === 10 ? 10 : 1;
    const cost = count === 10 ? D.GACHA.cost10 : D.GACHA.cost;
    const spent = rpgDb.spendGems(userId, cost);
    if (!spent.ok) return jsonError(res, 400, 'Permata tidak cukup. Kumpulkan dari dungeon, tower, dan world boss.');

    const pulls = [];
    let totalShards = 0;
    for (let i = 0; i < count; i++) {
      let char = rpgDb.getCharacter(userId);
      const rarity = rollRarity(char);
      // Update pity & counter.
      const idx = RARITY_ORDER.indexOf(rarity);
      rpgDb.updateCharacter(userId, { gachaPulled: (char.gachaPulled || 0) + 1 });
      rpgDb.updateCharacter(userId, { pitySinceEpic: idx >= 3 ? 0 : (char.pitySinceEpic || 0) + 1 });
      rpgDb.updateCharacter(userId, { pitySinceLegendary: idx >= 4 ? 0 : (char.pitySinceLegendary || 0) + 1 });
      rpgDb.updateCharacter(userId, { pitySinceMythic: idx >= 5 ? 0 : (char.pitySinceMythic || 0) + 1 });

      const pool = D.PET_BY_RARITY[rarity] || D.PET_BY_RARITY.common;
      const petId = pool[Math.floor(Math.random() * pool.length)];
      const g = rpgDb.grantPet(userId, petId);
      let shards = 0;
      if (g.duplicate) {
        shards = D.GACHA.shardFromDupe[rarity] || 5;
        rpgDb.addPetShards(userId, shards);
        totalShards += shards;
      } else if (rarity === 'mythic') {
        rpgDb.incCharacter(userId, 'mythicPetsOwned', 1);
      }
      pulls.push({ petId, rarity, duplicate: g.duplicate, shards, isNew: !g.duplicate, level: g.duplicate ? undefined : 1 });
    }
    const fin = rpgDb.getCharacter(userId);
    return res.json({
      ok: true, pulls,
      gems: fin.gems || 0, petShards: fin.petShards || 0, totalShards,
      pity: { epic: fin.pitySinceEpic || 0, legendary: fin.pitySinceLegendary || 0, mythic: fin.pitySinceMythic || 0 },
    });
  });
  // Tukar gold jadi permata (kurs sengaja tidak murah).
  app.post('/api/rpg/gems/exchange', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const guildId = safeGuildId(userId, req, client);
    if (!rateLimit(userId, 'gemex', 10, 60 * 1000)) return jsonError(res, 429, 'Terlalu sering menukar.');
    const times = Math.max(1, Math.min(10, Math.floor(Number(req.body && req.body.times) || 1)));
    const needGold = D.GACHA.goldToGems.rate * times;
    const wallet = rpgDb.getWallet(userId, guildId);
    if (wallet.gold < needGold) return jsonError(res, 400, 'Gold tidak cukup (butuh ' + needGold + ').');
    rpgDb.addGold(userId, guildId, -needGold);
    rpgDb.addGems(userId, D.GACHA.goldToGems.gems * times);
    return res.json({ ok: true, gems: rpgDb.getCharacter(userId).gems, wallet: rpgDb.getWallet(userId, guildId) });
  });

  // --- EVOLUSI PET (stage 1 -> 2: tubuh, stat, dan skill berubah) ---
  app.post('/api/rpg/pet/evolve', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const guildId = safeGuildId(userId, req, client);
    const petId = String((req.body && req.body.petId) || '');
    const evo = D.PET_EVOLUTION[petId];
    if (!evo) return jsonError(res, 400, 'Pet ini tidak punya bentuk evolusi.');
    const pet = rpgDb.getPet(userId, petId);
    if (!pet) return jsonError(res, 400, 'Kamu belum memiliki pet itu.');
    if ((pet.stage || 1) >= 2) return jsonError(res, 400, 'Pet ini sudah berevolusi.');
    if (pet.level < evo.reqLevel) return jsonError(res, 400, 'Level pet belum ' + evo.reqLevel + '.');
    const char = rpgDb.getCharacter(userId);
    if ((char.petShards || 0) < evo.shards) return jsonError(res, 400, 'Pecahan bintang kurang (' + (char.petShards || 0) + '/' + evo.shards + ').');
    const wallet = rpgDb.getWallet(userId, guildId);
    if (wallet.gold < evo.gold) return jsonError(res, 400, 'Gold kurang untuk biaya evolusi.');

    rpgDb.spendPetShards(userId, evo.shards);
    rpgDb.addGold(userId, guildId, -evo.gold);
    const r = rpgDb.evolvePetToStage2(userId, petId);
    if (!r.ok) return jsonError(res, 400, r.error);
    return res.json({ ok: true, pet: { id: petId, stage: 2 }, evolution: evo, petShards: rpgDb.getCharacter(userId).petShards });
  });

  // --- MENARA TANPA UJUNG (endless tower) ---
  app.get('/api/rpg/tower', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const char = rpgDb.getCharacter(userId);
    return res.json({ ok: true, best: char.towerBest || 0 });
  });
  app.post('/api/rpg/tower/clear', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const guildId = safeGuildId(userId, req, client);
    if (!rateLimit(userId, 'tower', 20, 60 * 1000)) return jsonError(res, 429, 'Terlalu cepat untuk satu menara.');
    const char = rpgDb.getCharacter(userId);
    const floor = Math.max(1, Math.min(999, Math.floor(Number(req.body && req.body.floor) || 0)));
    if (floor !== (char.towerBest || 0) + 1) return jsonError(res, 400, 'Lantai menara tidak berurutan.');
    // Reward menanjak: gold + xp + permata tiap 5 lantai.
    const gold = 60 + floor * 26;
    const xp = 35 + floor * 16;
    const gems = floor % 5 === 0 ? 12 + Math.floor(floor / 5) * 3 : 2 + Math.floor(floor / 10);
    rpgDb.addGold(userId, guildId, gold);
    rpgDb.addGems(userId, gems);
    const lv = rpgEngine.addExp(userId, xp, guildId);
    rpgDb.recordTowerFloor(userId, floor);
    return res.json({
      ok: true, rewards: { gold, xp, gems },
      levelUp: lv.leveledUp ? { from: lv.fromLevel, to: lv.toLevel } : null,
      best: rpgDb.getCharacter(userId).towerBest,
    });
  });

  // --- WORLD BOSS MINGGUAN (HP bersama seluruh pemain) ---
  app.get('/api/rpg/worldboss', auth, async (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const weekKey = rpgDb.weekKeyNow();
    const row = rpgDb.getWorldBoss(weekKey);
    const bossDef = D.worldBossForWeek(weekKey);
    const board = rpgDb.getWorldBossLeaderboard(weekKey);
    const myRow = board.find((b) => b.userId === userId);
    const nameOf = async (u, fallback) => (await displayName(client, u, fallback));
    const boardNamed = [];
    for (const b of board) boardNamed.push({ ...b, name: await nameOf(b.userId, b.gameName || null) });
    return res.json({
      ok: true,
      boss: { ...bossDef, hp: row.hp, maxHp: row.maxHp, defeatedAt: row.defeatedAt, weekKey },
      leaderboard: boardNamed,
      my: myRow ? { damage: myRow.damage, hits: myRow.hits } : { damage: 0, hits: 0 },
    });
  });
  app.post('/api/rpg/worldboss/attack', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const guildId = safeGuildId(userId, req, client);
    if (!rateLimit(userId, 'wb', 30, 10 * 60 * 1000)) return jsonError(res, 429, 'Kelelahan menyerang world boss.');
    const char = rpgDb.getCharacter(userId);
    if (!char) return jsonError(res, 400, 'Karakter belum dibuat.');
    const stats = rpgEngine.computeStats(char);
    const maxDmg = Math.max(50, Math.round((stats.atk || 20) * 260));
    const dmg = Math.max(1, Math.min(maxDmg, Math.floor(Number(req.body && req.body.damage) || 0)));
    const weekKey = rpgDb.weekKeyNow();
    const r = rpgDb.damageWorldBoss(weekKey, userId, dmg);
    // Reward kontribusi: gold sebanding damage + peluang permata.
    const gold = Math.max(10, Math.floor(dmg / 40));
    const gems = Math.random() < 0.25 ? 1 + Math.floor(Math.random() * 3) : 0;
    rpgDb.addGold(userId, guildId, gold);
    if (gems) rpgDb.addGems(userId, gems);
    return res.json({ ok: true, applied: r.applied, boss: { hp: r.boss.hp, maxHp: r.boss.maxHp }, rewards: { gold, gems } });
  });

  // --- PRESTIGE (rebirth: reset level, bonus permanen) ---
  app.post('/api/rpg/prestige', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const guildId = safeGuildId(userId, req, client);
    const char = rpgDb.getCharacter(userId);
    if (!char) return jsonError(res, 400, 'Karakter belum dibuat.');
    if (char.level < 50) return jsonError(res, 400, 'Prestige terbuka di level 50.');
    const nextPrestige = (char.prestigeLevel || 0) + 1;
    // Reset progresi level (skill tree & stat ikut reset — biaya memilih jalan baru),
    // tapi SEMUA item, pet, gold, permata, towerBest, dan gelar tetap.
    rpgDb.updateCharacter(userId, {
      level: 1, xp: 0, skillPoints: 0, statPoints: 0,
      prestigeLevel: nextPrestige,
    });
    rpgDb.resetSkills(userId);
    // Gelar eksklusif tiap tingkat prestige.
    const prestigeTitles = [null, 'Yang Terlahir Kembali', 'Penjelajah Siklus', 'Mahkluk Abadi', 'Legenda Reinkarnasi'];
    const t = prestigeTitles[Math.min(nextPrestige, prestigeTitles.length - 1)];
    if (t) {
      const app0 = getAppearance(char);
      const titles = app0.titles || [];
      if (!titles.includes(t)) titles.push(t);
      setAppearance(userId, { titles });
    }
    return res.json({ ok: true, prestigeLevel: nextPrestige, title: t || null });
  });

  // --- RUMAH LELANG (jual-beli antar pemain) ---
  app.get('/api/rpg/auctions', auth, async (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const rows = rpgDb.listAuctions({ limit: 40 });
    const out = [];
    for (const a of rows) {
      const it = rpgItems.getItem(a.itemId) || null;
      out.push({
        id: a.id, itemId: a.itemId, qty: a.qty, price: a.price, createdAt: a.createdAt,
        sellerId: a.sellerId, mine: a.sellerId === userId,
        item: it ? { id: it.id, name: it.name, tier: it.tier, category: it.category, type: it.type, class: it.class, stats: it.stats, effect: it.effect, desc: it.desc } : null,
        sellerName: await displayName(client, a.sellerId, null),
      });
    }
    return res.json({ ok: true, auctions: out });
  });
  app.post('/api/rpg/auction/list', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    if (!rateLimit(userId, 'alist', 15, 10 * 60 * 1000)) return jsonError(res, 429, 'Terlalu banyak listing.');
    const itemId = String((req.body && req.body.itemId) || '');
    const qty = Math.max(1, Math.min(99, Math.floor(Number(req.body && req.body.qty) || 1)));
    const price = Math.max(10, Math.min(9999999, Math.floor(Number(req.body && req.body.price) || 0)));
    const it = rpgItems.getItem(itemId);
    if (!it) return jsonError(res, 400, 'Item tidak dikenal.');
    if (rpgDb.getItemQty(userId, itemId) < qty) return jsonError(res, 400, 'Jumlah item di tas tidak cukup.');
    rpgDb.removeItem(userId, itemId, qty);
    const a = rpgDb.createAuction(userId, itemId, qty, price);
    return res.json({ ok: true, auction: { id: a.id, itemId, qty, price } });
  });
  app.post('/api/rpg/auction/buy', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const guildId = safeGuildId(userId, req, client);
    const id = Math.floor(Number(req.body && req.body.id) || 0);
    const a = rpgDb.getAuction(id);
    if (!a || a.status !== 'active') return jsonError(res, 400, 'Lelang sudah ditutup.');
    if (a.sellerId === userId) return jsonError(res, 400, 'Tidak bisa membeli lelang sendiri.');
    const wallet = rpgDb.getWallet(userId, guildId);
    if (wallet.gold < a.price) return jsonError(res, 400, 'Gold tidak cukup.');
    rpgDb.addGold(userId, guildId, -a.price);
    rpgDb.addGold(a.sellerId, guildId, a.price);
    rpgDb.addItem(userId, a.itemId, a.qty);
    const r = rpgDb.buyAuction(id, userId);
    if (!r.ok) return jsonError(res, 400, r.error);
    return res.json({ ok: true, wallet: rpgDb.getWallet(userId, guildId) });
  });
  app.post('/api/rpg/auction/cancel', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const id = Math.floor(Number(req.body && req.body.id) || 0);
    const a = rpgDb.getAuction(id);
    if (!a || a.sellerId !== userId) return jsonError(res, 400, 'Bukan lelangmu.');
    const r = rpgDb.cancelAuction(id, userId);
    if (!r.ok) return jsonError(res, 400, r.error);
    rpgDb.addItem(userId, a.itemId, a.qty);
    return res.json({ ok: true });
  });

  // --- PEDAGANG MISTERIUS di dungeon: jual ramuan dgn gold (whitelist) ---
  app.post('/api/rpg/merchant/buy', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const guildId = safeGuildId(userId, req, client);
    if (!rateLimit(userId, 'merch', 20, 5 * 60 * 1000)) return jsonError(res, 429, 'Pedagangnya kabur dulu.');
    const itemId = String((req.body && req.body.itemId) || '');
    const it = rpgItems.getItem(itemId);
    if (!it || it.category !== 'potion') return jsonError(res, 400, 'Pedagang itu tidak menjual barang tsb.');
    const price = Math.max(5, Math.round((it.price || 50) * 1.25));
    const wallet = rpgDb.getWallet(userId, guildId);
    if (wallet.gold < price) return jsonError(res, 400, 'Gold tidak cukup.');
    rpgDb.addGold(userId, guildId, -price);
    rpgDb.addItem(userId, itemId, 1);
    return res.json({ ok: true, item: { id: it.id, name: it.name }, price, wallet: rpgDb.getWallet(userId, guildId) });
  });

  // --- HADIAH antar teman ---
  app.post('/api/rpg/gift/send', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const guildId = safeGuildId(userId, req, client);
    if (!rateLimit(userId, 'gift', 10, 10 * 60 * 1000)) return jsonError(res, 429, 'Terlalu banyak hadiah terkirim.');
    const b = req.body || {};
    const toUserId = String(b.toUserId || '');
    const kind = ['gold', 'gems', 'item'].includes(b.kind) ? b.kind : null;
    const message = b.message ? String(b.message).slice(0, 120) : null;
    if (!kind) return jsonError(res, 400, 'Jenis hadiah tidak valid.');
    const friends = rpgDb.getFriends(userId).map((f) => f.friendUserId);
    if (!friends.includes(toUserId)) return jsonError(res, 400, 'Hanya bisa mengirim hadiah ke teman.');
    const char = rpgDb.getCharacter(userId);
    if (kind === 'gold') {
      const amount = Math.max(1, Math.min(100000, Math.floor(Number(b.amount) || 0)));
      const wallet = rpgDb.getWallet(userId, guildId);
      if (wallet.gold < amount) return jsonError(res, 400, 'Gold tidak cukup.');
      rpgDb.addGold(userId, guildId, -amount);
      rpgDb.createGift({ fromUserId: userId, toUserId, kind, gold: amount, message });
    } else if (kind === 'gems') {
      const amount = Math.max(1, Math.min(5000, Math.floor(Number(b.amount) || 0)));
      if ((char.gems || 0) < amount) return jsonError(res, 400, 'Permata tidak cukup.');
      rpgDb.spendGems(userId, amount);
      rpgDb.createGift({ fromUserId: userId, toUserId, kind, gems: amount, message });
    } else {
      const itemId = String(b.itemId || '');
      const qty = Math.max(1, Math.min(99, Math.floor(Number(b.qty) || 1)));
      const it = rpgItems.getItem(itemId);
      if (!it) return jsonError(res, 400, 'Item tidak dikenal.');
      if (rpgDb.getItemQty(userId, itemId) < qty) return jsonError(res, 400, 'Item di tas tidak cukup.');
      rpgDb.removeItem(userId, itemId, qty);
      rpgDb.createGift({ fromUserId: userId, toUserId, kind, itemId, qty, message });
    }
    return res.json({ ok: true });
  });
  app.get('/api/rpg/gift/inbox', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const rows = rpgDb.getGiftInbox(userId);
    const out = rows.map((g) => ({
      id: g.id, from: g.fromUserId, kind: g.kind, itemId: g.itemId, qty: g.qty,
      gold: g.gold, gems: g.gems, message: g.message, claimed: !!g.claimed, createdAt: g.createdAt,
      itemName: g.itemId ? ((rpgItems.getItem(g.itemId) || {}).name || g.itemId) : null,
    }));
    return res.json({ ok: true, gifts: out });
  });
  app.post('/api/rpg/gift/claim', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const guildId = safeGuildId(userId, req, client);
    const id = Math.floor(Number(req.body && req.body.id) || 0);
    const r = rpgDb.claimGift(id, userId);
    if (!r.ok) return jsonError(res, 400, r.error);
    const g = r.gift;
    if (g.kind === 'gold') rpgDb.addGold(userId, guildId, g.gold);
    else if (g.kind === 'gems') rpgDb.addGems(userId, g.gems);
    else if (g.itemId) rpgDb.addItem(userId, g.itemId, g.qty);
    return res.json({ ok: true, gift: { id: g.id, kind: g.kind, gold: g.gold, gems: g.gems, itemId: g.itemId, qty: g.qty } });
  });

  // --- Pasang / lepas equipment ---
  app.post('/api/rpg/item/equip', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const itemId = String((req.body && req.body.itemId) || '');
    const it = rpgItems.getItem(itemId);
    if (!it || it.type !== 'equip') return jsonError(res, 400, 'Item ini tidak bisa dipasang.');
    const slot = { weapon: 'equipWeapon', armor: 'equipArmor', accessory: 'equipAccessory' }[it.category];
    const r = rpgDb.equipItem(userId, it.id, slot);
    if (!r.ok) return jsonError(res, 400, r.error);
    return res.json({ ok: true });
  });
  app.post('/api/rpg/item/unequip', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const slot = { weapon: 'equipWeapon', armor: 'equipArmor', accessory: 'equipAccessory' }[req.body && req.body.slot];
    if (!slot) return jsonError(res, 400, 'Slot tidak valid.');
    const r = rpgDb.unequipItem(userId, slot);
    if (!r.ok) return jsonError(res, 400, r.error);
    return res.json({ ok: true });
  });

  // --- Jual item (harga setengah katalog) ---
  app.post('/api/rpg/item/sell', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const guildId = safeGuildId(userId, req, client);
    const itemId = String((req.body && req.body.itemId) || '');
    const qty = Math.max(1, Math.min(99, Math.floor(Number(req.body && req.body.qty) || 1)));
    const it = rpgItems.getItem(itemId);
    if (!it) return jsonError(res, 400, 'Item tidak dikenal.');
    if (rpgDb.getItemQty(userId, it.id) < qty) return jsonError(res, 400, 'Jumlah tidak cukup.');
    const gain = Math.max(1, Math.floor((it.price || 10) / 2)) * qty;
    rpgDb.removeItem(userId, it.id, qty);
    rpgDb.addGold(userId, guildId, gain);
    return res.json({ ok: true, gold: gain, wallet: rpgDb.getWallet(userId, guildId) });
  });

  // --- Alokasi stat point (HP/MP/ATK/DEF/SPD/CRIT) ---
  app.post('/api/rpg/stat', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const stat = String((req.body && req.body.stat) || '');
    const points = Math.max(1, Math.min(50, Math.floor(Number(req.body && req.body.points) || 1)));
    const r = rpgEngine.allocateStat(userId, stat, points);
    if (!r.ok) return jsonError(res, 400, r.error);
    return res.json({ ok: true, stat: r.stat, added: r.added, statPoints: r.statPoints });
  });

  // --- Buka / upgrade skill ---
  app.post('/api/rpg/skill', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const skillId = String((req.body && req.body.skillId) || '');
    const r = rpgEngine.unlockOrUpgradeSkill(userId, skillId);
    if (!r.ok) return jsonError(res, 400, r.error);
    return res.json({ ok: true, skill: { id: r.skill.id, name: r.skill.name }, newLevel: r.newLevel, skillPoints: r.remainingPoints });
  });

  // --- Leaderboard: nama asli + class + rank, bukan cuma ID Discord ---
  app.get('/api/rpg/leaderboard', auth, async (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const category = ['level', 'gold', 'wins', 'reputation'].includes(req.query.category) ? req.query.category : 'level';
    const rows = rpgDb.getLeaderboard(30, category);
    const me = rpgDb.getCharacter(userId);
    const list = [];
    for (let i = 0; i < rows.length; i++) {
      const c = rows[i];
      const name = c.gameName || await displayName(client, c.userId, null);
      const val = category === 'level' ? c.level : category === 'wins' ? c.wins : category === 'reputation' ? c.reputation : c.gold;
      list.push({
        rank: i + 1, userId: c.userId, name,
        level: c.level, classKey: c.className, rankKey: c.rankKey, title: c.title || '',
        value: val, isMe: c.userId === userId,
      });
    }
    let myRank = null;
    if (me) {
      const myVal = category === 'level' ? me.level : category === 'wins' ? me.wins : category === 'reputation' ? me.reputation : me.gold;
      myRank = { rank: list.find((x) => x.isMe)?.rank || null, value: myVal, name: me.gameName || (req.session ? req.session.username : null) };
    }
    return res.json({ list, myRank, category });
  });

  // --- Achievement: daftar + progress (auto-unlock) ---
  app.get('/api/rpg/achievements', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const { list, newlyUnlocked } = computeAchievements(userId);
    return res.json({ list, newlyUnlocked, categories: D.ACH_CATEGORIES });
  });

  // --- Klaim reward achievement ---
  app.post('/api/rpg/achievements/claim', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const guildId = safeGuildId(userId, req, client);
    const achId = String((req.body && req.body.achId) || '');
    const def = D.ACH_BY_ID[achId];
    if (!def) return jsonError(res, 400, 'Achievement tidak dikenal.');
    const { list } = computeAchievements(userId);
    const rec = list.find((a) => a.id === achId);
    if (!rec || !rec.unlocked) return jsonError(res, 400, 'Syarat belum terpenuhi.');
    if (rec.claimed) return jsonError(res, 400, 'Reward sudah diambil.');
    rpgDb.claimAchievement(userId, achId);
    // Berikan reward.
    if (def.reward.gold) rpgDb.addGold(userId, guildId, def.reward.gold);
    if (def.reward.xp) rpgEngine.addExp(userId, def.reward.xp, guildId);
    if (def.reward.rep) rpgDb.incCharacter(userId, 'reputation', def.reward.rep);
    if (def.reward.gems) rpgDb.addGems(userId, def.reward.gems);
    if (def.reward.title) {
      const char = rpgDb.getCharacter(userId);
      const app0 = getAppearance(char);
      const titles = app0.titles || [];
      if (!titles.includes(def.reward.title)) titles.push(def.reward.title);
      setAppearance(userId, { titles });
    }
    return res.json({ ok: true, reward: def.reward });
  });

  // --- Profil: nama panggung & title ---
  app.post('/api/rpg/profile', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const b = req.body || {};
    const char = rpgDb.getCharacter(userId);
    if (!char) return jsonError(res, 400, 'Karakter belum dibuat.');
    if (b.gameName != null) {
      const clean = String(b.gameName).replace(/\s+/g, ' ').trim().slice(0, 16);
      if (!clean || clean.length < 2) return jsonError(res, 400, 'Nama minimal 2 huruf.');
      rpgDb.updateCharacter(userId, { gameName: clean });
      setAppearance(userId, { name: clean });
    }
    if (b.title != null) {
      const want = String(b.title).slice(0, 32);
      const titles = getAppearance(char).titles || [];
      if (want && !titles.includes(want)) return jsonError(res, 400, 'Title belum terbuka.');
      rpgDb.updateCharacter(userId, { title: want });
    }
    return res.json({ ok: true });
  });

  // --- Daftar server mutual (guild switcher dompet) ---
  // Sama dengan rute di dashboard/server.js — diduplikasi di sini supaya
  // chip "Dompet: ..." di lobby juga jalan di QA server / mount terpisah.
  // [...cache.values()] kompatibel dengan Collection discord.js MAUPUN Map polos.
  app.get('/api/me/guilds', auth, (req, res) => {
    if (!req.session) return res.json([]);
    try {
      const botSet = new Set([...client.guilds.cache.values()].map((g) => g.id));
      const list = (Array.isArray(req.session.guilds) ? req.session.guilds : []).filter((g) => botSet.has(g.id));
      return res.json(list.map((g) => ({ id: g.id, name: g.name })));
    } catch (_) { return res.json([]); }
  });

  // --- Teman: daftar (dengan status online dari realtime registry) ---
  app.get('/api/rpg/friends', auth, async (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const friends = rpgDb.getFriends(userId);
    const requests = rpgDb.getPendingRequests(userId);
    const onlineSet = (global.__rpgOnline || new Set());
    const toInfo = async (row) => {
      const c = rpgDb.getCharacter(row.friendUserId);
      const name = (c && c.gameName) || await displayName(client, row.friendUserId, null);
      return {
        userId: row.friendUserId, name,
        level: c ? c.level : 0, classKey: c ? c.className : null, rankKey: c ? c.rankKey : 'G',
        title: c ? (c.title || '') : '', online: onlineSet.has(row.friendUserId),
      };
    };
    const list = await Promise.all(friends.map(toInfo));
    // Permintaan masuk: barisnya (userId=pengirim, friendUserId=saya) — kebalikan
    // arah dari daftar teman. Tanpa remap ini, tombol Terima mengirim ID SENDIRI
    // dan selalu ditolak server ("tidak ada permintaan dari pemain itu").
    const reqList = await Promise.all(requests.map((row) => toInfo({ ...row, friendUserId: row.userId })));
    return res.json({ friends: list, requests: reqList });
  });

  // --- Teman: tambah (kirim permintaan) lewat friendId / userId / nama ---
  app.post('/api/rpg/friends/add', auth, async (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const query = String((req.body && req.body.query) || '').trim();
    if (!query) return jsonError(res, 400, 'Masukkan friend ID / nama pemain.');
    if (String(userId) === query) return jsonError(res, 400, 'Tidak bisa menambah diri sendiri.');
    // Cari target: friendId persis dulu, lalu userId persis, lalu nama.
    let target = rpgDb.searchPlayers(query, 20).find((p) =>
      (p.friendId && p.friendId.toUpperCase() === query.toUpperCase()) || p.userId === query) || null;
    if (!target) {
      const byName = rpgDb.searchPlayers(query, 20).filter((p) =>
        p.gameName && p.gameName.toLowerCase() === query.toLowerCase());
      if (byName.length === 1) target = byName[0];
      else if (byName.length > 1) return jsonError(res, 400, 'Nama dipakai banyak orang — pakai friend ID mereka.');
    }
    if (!target) {
      // Mungkin itu userId Discord murni yang belum punya karakter.
      if (/^\d{15,25}$/.test(query)) {
        const c = rpgDb.getCharacter(query);
        if (c) target = { userId: query };
      }
      if (!target) return jsonError(res, 404, 'Pemain tidak ditemukan. Minta friend ID mereka (contoh: KZ-AB12).');
    }
    if (target.userId === userId) return jsonError(res, 400, 'Tidak bisa menambah diri sendiri.');
    // Kalau DIA yang sudah mengajak kita → langsung jadi teman.
    const incoming = rpgDb.getPendingRequests(userId).find((r) => r.userId === target.userId);
    if (incoming) { rpgDb.addFriend(userId, target.userId); return res.json({ ok: true, status: 'accepted', userId: target.userId }); }
    rpgDb.requestFriend(userId, target.userId);
    return res.json({ ok: true, status: 'pending', userId: target.userId });
  });

  app.post('/api/rpg/friends/accept', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const target = String((req.body && req.body.userId) || '');
    const pending = rpgDb.getPendingRequests(userId).find((r) => r.userId === target);
    if (!pending) return jsonError(res, 400, 'Tidak ada permintaan dari pemain itu.');
    rpgDb.addFriend(userId, target);
    return res.json({ ok: true });
  });
  app.post('/api/rpg/friends/decline', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const target = String((req.body && req.body.userId) || '');
    rpgDb.removeFriend(userId, target);
    return res.json({ ok: true });
  });
  app.post('/api/rpg/friends/remove', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const target = String((req.body && req.body.userId) || '');
    rpgDb.removeFriend(userId, target);
    return res.json({ ok: true });
  });

  // --- Cari pemain (untuk UI cari teman) ---
  app.get('/api/rpg/players/search', auth, async (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const q = String(req.query.q || '').trim();
    const rows = rpgDb.searchPlayers(q, 12);
    const out = [];
    for (const p of rows) {
      if (p.userId === userId) continue;
      out.push({ userId: p.userId, name: p.gameName || await displayName(client, p.userId, null), friendId: p.friendId, level: p.level, classKey: p.className, rankKey: p.rankKey });
    }
    return res.json({ list: out });
  });

  // --- Riwayat chat ---
  const withNames = async (rows) => {
    const out = [];
    for (const m of rows) {
      const c = rpgDb.getCharacter(m.fromUserId);
      out.push({
        id: m.id, from: m.fromUserId, to: m.toUserId, message: m.message, at: m.createdAt,
        name: (c && c.gameName) || await displayName(client, m.fromUserId, null),
        classKey: c ? c.className : null,
      });
    }
    return out;
  };
  app.get('/api/rpg/chat/global', auth, async (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const before = req.query.before ? Number(req.query.before) : null;
    const rows = rpgDb.getChatHistory('global', { limit: 40, before });
    return res.json({ messages: await withNames(rows) });
  });
  app.get('/api/rpg/chat/dm', auth, async (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const other = String(req.query.with || '');
    if (!other) return jsonError(res, 400, 'Parameter with=userId wajib.');
    const rows = rpgDb.getDmHistory(userId, other, { limit: 60 });
    return res.json({ messages: await withNames(rows) });
  });

  // --- Kirim chat via REST — FALLBACK saat WebSocket diblokir proxy hosting ---
  // Aturan sama persis dengan jalur WS di rpgRealtime.js: teks dibersihkan,
  // maks 300 karakter, rate limit 10 pesan / 10 detik, DM hanya sesama teman.
  // Pesan tetap disiarkan ke semua klien WS lewat __rpgChatRelay, jadi user
  // yang realtimenya sehat tetap melihat pesan pengguna mode hemat ini.
  const cleanChatText = (s) => String(s || '')
    .replace(/[\u0000-\u0008\u000B-\u001F\u007F\u200B-\u200F\u2028\u2029\uFEFF]/g, '')
    .trim().slice(0, 300);
  app.post('/api/rpg/chat/global', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const text = cleanChatText(req.body && req.body.message);
    if (!text) return jsonError(res, 400, 'Pesan kosong.');
    if (!rateLimit(userId, 'chat_rest', 10, 10 * 1000)) return jsonError(res, 429, 'Terlalu cepat — tarik napas dulu.');
    const row = rpgDb.addChatMessage({ channel: 'global', fromUserId: userId, message: text });
    const c = rpgDb.getCharacter(userId);
    const senderName = (c && c.gameName) || (req.session && req.session.username) || 'Petualang';
    const payload = { t: 'chat.global', id: row.id, from: userId, name: senderName, message: text, at: row.createdAt, classKey: c ? c.className : null };
    if (global.__rpgChatRelay) { try { global.__rpgChatRelay.broadcast(payload); } catch (_) {} }
    return res.json({ ok: true, id: row.id, at: row.createdAt, name: senderName, classKey: payload.classKey, message: text });
  });
  app.post('/api/rpg/chat/dm', auth, (req, res) => {
    const userId = requireChar(req, res); if (!userId) return;
    const to = String((req.body && req.body.to) || '').replace(/\D/g, '').slice(0, 20);
    const text = cleanChatText(req.body && req.body.message);
    if (!to || !text || to === userId) return jsonError(res, 400, 'Pesan atau penerima tidak valid.');
    if (!rateLimit(userId, 'chat_rest', 10, 10 * 1000)) return jsonError(res, 429, 'Terlalu cepat — tarik napas dulu.');
    const isFriend = rpgDb.getFriends(userId).some((f) => f.friendUserId === to);
    if (!isFriend) return jsonError(res, 403, 'Hanya bisa chat dengan teman.');
    const row = rpgDb.addChatMessage({ channel: 'dm', fromUserId: userId, toUserId: to, message: text });
    const c = rpgDb.getCharacter(userId);
    const senderName = (c && c.gameName) || (req.session && req.session.username) || 'Petualang';
    const payload = { t: 'chat.dm', id: row.id, from: userId, to, name: senderName, message: text, at: row.createdAt };
    if (global.__rpgChatRelay) { try { global.__rpgChatRelay.toUser(to, payload); global.__rpgChatRelay.toUser(userId, payload); } catch (_) {} }
    return res.json({ ok: true, id: row.id, at: row.createdAt, name: payload.name, message: text });
  });
}

module.exports = { mountRpg, charForGame, resolveLocation, resolveMonster, computeAchievements };
