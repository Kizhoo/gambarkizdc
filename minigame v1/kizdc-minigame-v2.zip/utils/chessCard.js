// ============================================================================
// CANVAS PAPAN CATUR — commands/games/chess.js
// ----------------------------------------------------------------------------
// Simbol bidak pakai glyph Unicode catur standar (♔♕♖♗♘♙ / ♚♛♜♝♞♟) — BUKAN
// emoji berwarna, jadi tidak butuh font emoji khusus yang sering tidak ada di
// host server (pelajaran dari bug "kotak-kotak" sebelumnya). Simbol ini bagian
// dari blok Unicode simbol biasa, didukung hampir semua font sistem.
//
// PENTING soal nama font: JANGAN pakai family generik "serif"/"sans-serif" polos
// buat glyph ini. Sudah diverifikasi di server: font yang di-resolve dari "serif"
// (DejaVu Serif) TIDAK PUNYA satupun dari 12 glyph U+2654-U+265F, jadi Skia
// terpaksa nyari font pengganti SATU PER SATU KARAKTER dari font lain yang
// kebetulan punya glyph itu — dan penggantinya BISA BEDA per bidak (gaya/berat
// garis beda-beda), yang kelihatannya persis kayak bug "gajah jadi mirip pion"
// / "ratu ketuker kelihatan kayak raja kedua". "DejaVu Sans" punya ke-12 glyph
// itu LENGKAP & KONSISTEN dalam SATU file font yang sama — pakai itu eksplisit.
const { createCanvas } = require('@napi-rs/canvas');

const PIECE_FONT_FAMILY = 'DejaVu Sans';
const GLYPH = {
  w: { k: '♔', q: '♕', r: '♖', b: '♗', n: '♘', p: '♙' },
  b: { k: '♚', q: '♛', r: '♜', b: '♝', n: '♞', p: '♟' },
};
const LIGHT = '#EBD9B4', DARK = '#8B6A4A';
const FILES = 'abcdefgh';

function renderChessBoard(state, { selected = null, legalTargets = [], title = null } = {}) {
  const cell = 84, boardPx = cell * 8, pad = 46;
  const W = boardPx + pad * 2, H = boardPx + pad * 2 + (title ? 40 : 0);
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingEnabled = false;

  ctx.fillStyle = '#1B1410'; ctx.fillRect(0, 0, W, H);
  const boardY = pad + (title ? 40 : 0);
  if (title) {
    ctx.textAlign = 'center'; ctx.fillStyle = '#F3E3C3'; ctx.font = '700 24px sans-serif';
    ctx.fillText(title, W / 2, 30);
  }

  const lastMoveSquares = state.lastMove ? [state.lastMove.from, state.lastMove.to] : [];

  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const drawRow = 7 - r; // rank 8 di atas, rank 1 di bawah (orientasi standar)
      const x = pad + c * cell, y = boardY + drawRow * cell;
      const isLight = (r + c) % 2 === 1;
      ctx.fillStyle = isLight ? LIGHT : DARK;
      ctx.fillRect(x, y, cell, cell);

      if (lastMoveSquares.some(s => s.r === r && s.c === c)) {
        ctx.fillStyle = 'rgba(250, 204, 21, 0.35)'; ctx.fillRect(x, y, cell, cell);
      }
      if (selected && selected.r === r && selected.c === c) {
        ctx.strokeStyle = '#38BDF8'; ctx.lineWidth = 4; ctx.strokeRect(x + 2, y + 2, cell - 4, cell - 4);
      }
      if (legalTargets.some(t => t.r === r && t.c === c)) {
        ctx.beginPath(); ctx.arc(x + cell / 2, y + cell / 2, cell * 0.14, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(34,197,94,0.65)'; ctx.fill();
      }

      const piece = state.board[r][c];
      if (piece) {
        // Raja dapat cincin emas tipis di belakangnya - PENANDA TAMBAHAN yang tidak gantung ke
        // font/glyph sama sekali, jadi Raja tidak akan pernah bisa ketuker-keliatan sama Ratu lagi
        // (mahkota keduanya memang mirip sekilas di layar kecil, walau glyph-nya sudah beda).
        if (piece.type === 'k') {
          ctx.beginPath();
          ctx.arc(x + cell / 2, y + cell / 2, cell * 0.38, 0, Math.PI * 2);
          ctx.strokeStyle = '#F5C244'; ctx.lineWidth = 3.5; ctx.stroke();
        }
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.font = `${Math.round(cell * 0.72)}px "${PIECE_FONT_FAMILY}"`;
        // Outline tipis biar bidak putih tetap kebaca jelas di kotak terang.
        ctx.lineWidth = 3; ctx.strokeStyle = piece.color === 'w' ? '#1B1410' : '#F3E3C3';
        ctx.strokeText(GLYPH[piece.color][piece.type], x + cell / 2, y + cell / 2 + 2);
        ctx.fillStyle = piece.color === 'w' ? '#FDFDFD' : '#0B0B12';
        ctx.fillText(GLYPH[piece.color][piece.type], x + cell / 2, y + cell / 2 + 2);
      }
    }
  }

  // label file (a-h) & rank (1-8)
  ctx.fillStyle = '#B9A483'; ctx.font = '600 16px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
  for (let c = 0; c < 8; c++) ctx.fillText(FILES[c], pad + c * cell + cell / 2, boardY + boardPx + 24);
  ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
  for (let r = 0; r < 8; r++) ctx.fillText(String(r + 1), pad - 10, boardY + (7 - r) * cell + cell / 2);

  return canvas.toBuffer('image/png');
}

module.exports = { renderChessBoard };
