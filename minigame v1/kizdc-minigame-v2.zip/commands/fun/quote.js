const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

const QUOTES = [
  { id: 'Satu-satunya cara melakukan pekerjaan hebat adalah mencintai apa yang kamu kerjakan.', en: 'The only way to do great work is to love what you do.', author: 'Steve Jobs' },
  { id: 'Hidup itu seperti bersepeda. Agar tetap seimbang, kamu harus terus bergerak.', en: 'Life is like riding a bicycle. To keep your balance, you must keep moving.', author: 'Albert Einstein' },
  { id: 'Keberhasilan adalah kemampuan melangkah dari satu kegagalan ke kegagalan lain tanpa kehilangan semangat.', en: 'Success is the ability to go from one failure to another with no loss of enthusiasm.', author: 'Winston Churchill' },
  { id: 'Jangan tunggu kesempatan. Ciptakan kesempatan itu sendiri.', en: "Don't wait for opportunity. Create it.", author: 'George Bernard Shaw' },
  { id: 'Masa depan adalah milik mereka yang percaya pada keindahan mimpi mereka.', en: 'The future belongs to those who believe in the beauty of their dreams.', author: 'Eleanor Roosevelt' },
  { id: 'Kamu tidak akan pernah tahu seberapa kuat dirimu sampai menjadi kuat adalah satu-satunya pilihan.', en: 'You never know how strong you are until being strong is your only choice.', author: 'Bob Marley' },
  { id: 'Cara terbaik memprediksi masa depan adalah dengan menciptakannya.', en: 'The best way to predict the future is to create it.', author: 'Peter Drucker' },
  { id: 'Jangan takut gagal. Takutlah untuk tidak mencoba.', en: "Don't be afraid to fail. Be afraid not to try.", author: 'Anonymous' },
  { id: 'Kesuksesan bukanlah akhir, kegagalan bukanlah hal fatal, yang penting adalah keberanian untuk terus melangkah.', en: 'Success is not final, failure is not fatal: it is the courage to continue that counts.', author: 'Winston Churchill' },
  { id: 'Waktu terbaik menanam pohon adalah 20 tahun lalu. Waktu terbaik kedua adalah sekarang.', en: 'The best time to plant a tree was 20 years ago. The second best time is now.', author: 'Chinese Proverb' },
  { id: 'Kualitas bukanlah tindakan, itu adalah kebiasaan.', en: 'Quality is not an act, it is a habit.', author: 'Aristotle' },
  { id: 'Jangan hitung hari, buat hari itu berarti.', en: "Don't count the days, make the days count.", author: 'Muhammad Ali' },
  { id: 'Percayalah kamu bisa, maka kamu sudah setengah jalan menuju ke sana.', en: "Believe you can and you're halfway there.", author: 'Theodore Roosevelt' },
  { id: 'Hal yang paling sulit adalah keputusan untuk bertindak, sisanya hanyalah ketekunan.', en: 'The most difficult thing is the decision to act, the rest is merely tenacity.', author: 'Amelia Earhart' },
  { id: 'Kegagalan hanyalah kesempatan untuk memulai lagi, kali ini dengan lebih bijaksana.', en: 'Failure is simply the opportunity to begin again, this time more intelligently.', author: 'Henry Ford' },
];

module.exports = {
  data: new SlashCommandBuilder().setName('quote').setDescription('Dapatkan kutipan inspiratif secara acak'),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const quote = QUOTES[Math.floor(Math.random() * QUOTES.length)];
    const text = lang === 'id' ? quote.id : quote.en;
    const embed = baseEmbed().setDescription(`"${text}"\n\n— **${quote.author}**`);
    return interaction.reply({ embeds: [embed] });
  },
};
