// ============================================================================
// MESIN EKONOMI KIZCO — simulasi makroekonomi ala dunia nyata (per server)
// ----------------------------------------------------------------------------
// Model: teori kuantitas uang sederhana (MV = PY) yang diadaptasi jadi game.
//   - M = jumlah Kizco beredar (dompet + bank)
//   - Y = aktivitas ekonomi riil (transaksi produktif per jendela waktu)
//   - P = level harga umum (priceIndex, 100 = baseline)
//   - Inflasi ≈ pertumbuhan M dikurangi pertumbuhan Y
//
// Setiap siklus (`tick`):
//   1) Hitung M & Y baru, bandingkan dengan snapshot sebelumnya.
//   2) Hitung inflasi/deflasi, update priceIndex.
//   3) Tentukan fase siklus bisnis (ekspansi/puncak/resesi/pemulihan).
//   4) Terapkan kebijakan moneter (Taylor-rule + kebijakan AI) ke 3 tuas:
//      rewardMultiplier (creation), taxRate (sink), bankInterestRate (creation).
//   5) Bayar bunga bank, pungut pajak, catat harga & log.
//
// Yang membedakan "inflasi" dan "deflasi" beneran terjadi: reward menambah M,
// pembelian/pajak/denda mengurangi M, dan level harga mengikuti selisihnya —
// sehingga harga pasar OTOTMATIS naik saat inflasi dan turun saat deflasi.
// ============================================================================
const econ = require('../database/economyDb');
const { getEconomy, updateBalance, updateBank, db } = require('../database/db');
const settings = require('./settings');
const kizco = require('./kizco');

const PHASES = ['expansion', 'peak', 'recession', 'recovery'];
const PHASE_LABEL = { expansion: 'Ekspansi', peak: 'Puncak', recession: 'Resesi', recovery: 'Pemulihan' };

function cfg(dot, fallback) {
  return settings.get(`economy.${dot}`, fallback);
}

// ---------------- Kebijakan moneter (Taylor-rule sederhana) ----------------
// Target inflasi per siklus, netral rate, respons thd gap inflasi & output.
function computePolicy(inflationRate, moneyGrowth, activityGrowth) {
  const target = cfg('targetInflationPerCycle', 0.004);   // ~0.4%/siklus
  const neutral = cfg('neutralPolicyRate', 3.0);          // %/tahun (display)
  const phiInflation = cfg('phiInflation', 1.5);
  const phiOutput = cfg('phiOutput', 0.5);

  const inflGap = inflationRate - target;
  const outputGap = activityGrowth; // + = output naik (panas), - = melambat
  let policyRate = neutral + phiInflation * inflGap * 100 + phiOutput * outputGap * 100;
  policyRate = Math.max(0, Math.min(20, policyRate));

  // Terjemahan ke 3 tuas nyata sistem game.
  let rewardMultiplier = 1.0;
  let taxRate = cfg('baseTaxRate', 0.05);
  let bankInterestRate = cfg('baseBankInterestRate', 0.02);

  if (inflationRate > target) {
    // Inflasi tinggi -> kebijakan ketat: kurangi cetak uang, naikkan pajak (sink).
    const severity = Math.min(3, (inflationRate - target) / Math.max(target, 0.0001));
    rewardMultiplier = Math.max(0.5, 1.0 - severity * 0.15);
    taxRate = Math.min(0.5, cfg('baseTaxRate', 0.05) + severity * 0.05);
    bankInterestRate = Math.max(0.005, cfg('baseBankInterestRate', 0.02) - severity * 0.005);
  } else if (inflationRate < 0) {
    // Deflasi -> kebijakan longgar: cetak lebih banyak, turunkan pajak, naikkan bunga.
    const severity = Math.min(3, Math.abs(inflationRate) / 0.01);
    rewardMultiplier = Math.min(2.0, 1.0 + severity * 0.2);
    taxRate = Math.max(0.0, cfg('baseTaxRate', 0.05) - severity * 0.02);
    bankInterestRate = Math.min(0.08, cfg('baseBankInterestRate', 0.02) + severity * 0.01);
  }

  return {
    policyRate: Number(policyRate.toFixed(2)),
    rewardMultiplier: Number(rewardMultiplier.toFixed(3)),
    taxRate: Number(taxRate.toFixed(3)),
    bankInterestRate: Number(bankInterestRate.toFixed(3)),
  };
}

// ---------------- Fase siklus bisnis ----------------
function nextPhase(currentPhase, inflationRate, activityGrowth) {
  const hot = inflationRate > cfg('targetInflationPerCycle', 0.004) * 2 || activityGrowth > 0.1;
  const cold = inflationRate < 0 || activityGrowth < -0.1;
  const order = ['expansion', 'peak', 'recession', 'recovery'];
  const idx = order.indexOf(currentPhase);
  if (currentPhase === 'expansion' && hot) return 'peak';
  if (currentPhase === 'peak' && cold) return 'recession';
  if (currentPhase === 'peak' && !cold && inflationRate > 0.02) return 'recession';
  if (currentPhase === 'recession' && !cold) return 'recovery';
  if (currentPhase === 'recovery' && hot) return 'expansion';
  if (idx === -1) return 'expansion';
  return currentPhase;
}

// Skor kesehatan ekonomi 0-100 (buat dashboard). Menilai KESTABILAN harga:
// inflasi dekat target = sehat; hyperinflasi, deflasi, atau uang tumbuh lebih
// cepat dari output (gelembung) = tidak sehat. Aktivitas produktif naik = bonus.
function healthScore(inflationRate, moneyGrowth, activityGrowth) {
  const target = cfg('targetInflationPerCycle', 0.004);
  const inflPenalty = Math.min(50, Math.abs(inflationRate - target) * 500);
  const overheat = Math.max(0, moneyGrowth - activityGrowth - target);
  const overheatPenalty = Math.min(30, overheat * 300);
  const deflationPenalty = Math.min(20, Math.max(0, -moneyGrowth) * 200);
  const activityBonus = Math.min(15, Math.max(0, activityGrowth) * 150);
  const score = 100 - inflPenalty - overheatPenalty - deflationPenalty + activityBonus;
  return Math.max(0, Math.min(100, Math.round(score)));
}

// ---------- Skor peringkat KOMPREHENSIF (buat ranking publik) ----------
// Bukan cuma stabilitas harga, tapi gabungan 4 dimensi supaya peringkat
// mencerminkan "ekonomi yang benar-benar sehat DAN hidup":
//   - stability  (40%): kesehatan harga (health)
//   - activity   (35%): uang beredar (log) — ada transaksi riil
//   - community  (15%): jumlah member (log)
//   - maturity   (10%): sudah berapa siklus ekonomi berjalan
//   - penyesuaian fase: ekspansi/pemulihan +4, puncak 0, resesi -8
function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
function logScale(value, refMax) {
  if (!value || value <= 0) return 0;
  return Math.min(100, Math.round(Math.log10(value + 1) / Math.log10(refMax + 1) * 100));
}
function rankScore(summary, memberCount = 0) {
  const stability = clamp(Number(summary.health) || 0, 0, 100);
  const activity = logScale(Number(summary.moneySupply) || 0, 100000); // 100K KZC -> 100
  const community = logScale(memberCount || 0, 500); // 500 member -> 100
  const maturity = clamp(Math.round((Number(summary.cycle) || 0) / 50 * 100), 0, 100); // 50 siklus -> 100
  const phaseAdj = { expansion: 4, recovery: 4, peak: 0, recession: -8 }[summary.phase] || 0;

  const score = stability * 0.40 + activity * 0.35 + community * 0.15 + maturity * 0.10 + phaseAdj;
  return {
    score: Math.round(clamp(score, 0, 100)),
    stability,
    activity,
    community,
    maturity,
  };
}

// ---------------- TUAS PENGHASILAN / PENGELUARAN ----------------
// Reward NOMINAL = base × rewardMultiplier × (priceIndex/100). Pajak dipotong
// dari reward sebelum masuk dompet (sink -> deflasi).
function creditPlayer(guildId, userId, baseAmount, { type, note = null, taxable = true } = {}) {
  const st = econ.getState(guildId);
  const gross = kizco.scaleByPrice(baseAmount * st.rewardMultiplier, st.priceIndex);
  const tax = taxable ? Math.round(gross * st.taxRate) : 0;
  const net = Math.max(0, gross - tax);
  updateBalance(guildId, userId, net);
  econ.recordTransaction(guildId, { type, actorId: userId, amount: net, note });
  if (tax > 0) econ.recordTransaction(guildId, { type: 'tax', actorId: userId, amount: -tax, note: `Pajak ${(st.taxRate * 100).toFixed(1)}% dari ${type}` });
  // Minta state treasury naik (pajak disetor ke kas sistem, keluar sirkulasi).
  econ.updateState(guildId, { treasury: st.treasury + tax });
  return { gross, tax, net };
}

// Debit (uang keluar sirkulasi -> sink). Dipakai buat beli barang di toko.
function debitPlayer(guildId, userId, amount, { type, note = null } = {}) {
  const amt = Math.round(Number(amount) || 0);
  updateBalance(guildId, userId, -amt);
  econ.recordTransaction(guildId, { type, actorId: userId, amount: -amt, note });
  const st = econ.getState(guildId);
  econ.updateState(guildId, { treasury: st.treasury + amt });
  return { amount: amt };
}

// ---------------- SIKLUS UTAMA ----------------
function tick(guildId) {
  const prev = econ.getState(guildId);
  const M = econ.computeMoneySupply(guildId);
  // Baseline: tick pertama (atau state baru) HANYA mencatat snapshot M, tidak
  // menghitung inflasi dari basis 0 (mencegah lonjakan inflasi 50%+ palsu).
  const isBaseline = !prev.lastTickAt;
  const Mprev = prev.moneySupply || M || 1;

  const windowMs = cfg('cycleMinutes', 60) * 60000;
  const since = Date.now() - windowMs;
  const Y = econ.countProductiveTransactions(guildId, since);
  const Yprev = isBaseline ? Y : (prev.lastActivity || Math.max(Y, 1));

  const moneyGrowth = isBaseline ? 0 : Math.max(-1, Math.min(1, (M - Mprev) / Math.max(1, Mprev)));
  const activityGrowth = isBaseline ? 0 : Math.max(-1, Math.min(1, (Y - Yprev) / Math.max(1, Yprev)));

  // Inflasi = pertumbuhan uang - pertumbuhan output (dengan smoothing).
  const prevInflation = prev.inflationRate || 0;
  const rawInflation = isBaseline ? 0 : moneyGrowth - activityGrowth;
  let inflationRate = isBaseline ? 0 : prevInflation * cfg('inflationSmoothing', 0.5) + rawInflation * (1 - cfg('inflationSmoothing', 0.5));

  // Ekonomi masih kecil: uang beredar sedikit -> persentase gampang melonjak tanpa
  // arti (uang naik beberapa ratus KZC saja sudah terlihat 100%). Dampen inflasi
  // sampai ekonomi cukup besar, lalu cap biar harga tidak meledak tiap siklus.
  const minMoney = cfg('inflationMinMoney', 10000);
  const dampen = Math.min(1, Math.max(0.05, M / Math.max(1, minMoney)));
  inflationRate *= dampen;
  const inflationCap = cfg('inflationCap', 0.25);
  inflationRate = Math.max(-inflationCap, Math.min(inflationCap, inflationRate));

  // Cap indeks harga supaya harga barang tidak membengkak eksponensial tanpa batas
  // (dulu bisa mencapai 2.6e+34 dan tampil sebagai notasi ilmiah di market).
  const priceIndexCap = cfg('priceIndexCap', 100000); // 1000x baseline
  const newPriceIndex = Math.max(1, Math.min(priceIndexCap, prev.priceIndex * (1 + inflationRate)));

  const policy = computePolicy(inflationRate, moneyGrowth, activityGrowth);
  const phase = nextPhase(prev.phase, inflationRate, activityGrowth);
  const health = healthScore(inflationRate, moneyGrowth, activityGrowth);

  // Terapkan bunga bank (creation) ke semua penabung.
  if (policy.bankInterestRate > 0) {
    const savers = dbSavers(guildId);
    let totalInterest = 0;
    for (const s of savers) {
      if (s.bank <= 0) continue;
      const interest = Math.max(1, Math.round(s.bank * policy.bankInterestRate));
      updateBank(guildId, s.userId, interest);
      totalInterest += interest;
      econ.recordTransaction(guildId, { type: 'interest', actorId: s.userId, amount: interest, note: `Bunga bank ${(policy.bankInterestRate * 100).toFixed(2)}%` });
      econ.addBankLog({ guildId, userId: s.userId, type: 'interest', amount: interest, note: `Bunga majemuk ${(policy.bankInterestRate * 100).toFixed(2)}%/siklus` });
    }
    // Bunga menambah M; perbarui snapshot setelahnya.
    // (M sudah dihitung di atas; kecil selisihnya dan masuk hitungan siklus berikutnya — disengaja utk stabilitas.)
    void totalInterest;
  }

  const state = econ.updateState(guildId, {
    priceIndex: Number(newPriceIndex.toFixed(4)),
    inflationRate: Number(inflationRate.toFixed(6)),
    moneySupply: M,
    rewardMultiplier: policy.rewardMultiplier,
    taxRate: policy.taxRate,
    bankInterestRate: policy.bankInterestRate,
    policyRate: policy.policyRate,
    phase,
    health,
    cycle: prev.cycle + 1,
    lastActivity: Y,
    lastTickAt: Date.now(),
  });

  econ.addPricePoint(guildId, {
    priceIndex: state.priceIndex, moneySupply: M, inflationRate: state.inflationRate,
    phase, rewardMultiplier: state.rewardMultiplier, taxRate: state.taxRate, bankInterestRate: state.bankInterestRate,
  });

  return {
    state,
    metrics: { M, Mprev, Y, Yprev, moneyGrowth, activityGrowth, rawInflation, inflationRate },
    policy,
  };
}

// Ambil daftar penabung bank (balance bank > 0) utk bunga.
function dbSavers(guildId) {
  return require('../database/db').db.prepare('SELECT userId, bank FROM economy WHERE guildId = ? AND bank > 0').all(guildId);
}

// Harga nominal sebuah item di toko = basePrice × (priceIndex/100) × demandFactor.
function shopPrice(guildId, basePrice, demandScore = 0) {
  const st = econ.getState(guildId);
  const demandFactor = 1 + Math.min(0.5, Math.max(-0.3, demandScore * cfg('demandPriceSensitivity', 0.01)));
  const nominal = kizco.scaleByPrice(basePrice, st.priceIndex);
  return Math.max(1, Math.round(nominal * demandFactor));
}

// Label inflasi yang lebih kaya (istilah ekonomi seperti di dunia nyata).
function inflationLabel(pct) {
  const p = Number(pct) || 0;
  if (p >= 50) return 'Hiperinflasi';
  if (p >= 10) return 'Inflasi Ekstrem';
  if (p >= 3) return 'Inflasi Tinggi';
  if (p >= 0.5) return 'Inflasi';
  if (p > -0.5) return 'Stabil';
  if (p > -3) return 'Deflasi';
  return 'Deflasi Dalam';
}

function summary(guildId) {
  const st = econ.getState(guildId);
  return {
    ...st,
    moneySupply: econ.computeMoneySupply(guildId), // M live (bukan snapshot tick terakhir)
    phaseLabel: PHASE_LABEL[st.phase] || st.phase,
    inflationLabel: inflationLabel(st.inflationRate * 100),
    inflationPct: Number((st.inflationRate * 100).toFixed(3)),
    priceIndex: Number(st.priceIndex.toFixed(2)),
    rewardMultiplier: st.rewardMultiplier,
    taxRatePct: Number((st.taxRate * 100).toFixed(2)),
    bankInterestRatePct: Number((st.bankInterestRate * 100).toFixed(3)),
  };
}

// Injeksi/penarikan darurat (QE / quantitative tightening) — dipakai AI ekonom.
function injectMoney(guildId, amount, note = 'QE (Quantitative Easing)') {
  const amt = Math.round(Number(amount) || 0);
  const st = econ.getState(guildId);
  econ.updateState(guildId, { totalMinted: st.totalMinted + Math.max(0, amt), treasury: Math.max(0, st.treasury - Math.max(0, amt)) });
  econ.recordTransaction(guildId, { type: 'qe', amount: amt, note });
  // QE positif: sebarkan ke semua pemegang dompet secara merata (helicopter money).
  if (amt > 0) {
    const holders = require('../database/db').db.prepare('SELECT userId FROM economy WHERE guildId = ?').all(guildId);
    if (holders.length) {
      const each = Math.floor(amt / holders.length);
      let distributed = 0;
      for (const h of holders) {
        updateBalance(guildId, h.userId, each);
        distributed += each;
      }
      econ.recordTransaction(guildId, { type: 'reward', amount: distributed, note: `Distribusi ${note}` });
    }
  }
  return { amount: amt };
}

module.exports = {
  PHASES, PHASE_LABEL,
  computePolicy, nextPhase, healthScore, rankScore, inflationLabel,
  creditPlayer, debitPlayer, tick, summary, shopPrice, injectMoney,
  printMoney, burnMoney, setRates, playMinigame,
  getState: (guildId) => econ.getState(guildId),
  getPriceHistory: (guildId, limit) => econ.getPriceHistory(guildId, limit),
  getTransactions: (guildId, limit) => econ.getTransactions(guildId, limit),
  getAiLog: (guildId, limit) => econ.getAiLog(guildId, limit),
};

// ============================================================================
// BANK SENTRAL — kontrol langsung ala otoritas moneter (owner/admin).
// ============================================================================

// Cetak uang (QE): distribusikan KZC baru merata ke semua pemegang dompet.
function printMoney(guildId, amount, note = 'Cetak uang oleh bank sentral') {
  const amt = Math.round(Number(amount) || 0);
  if (amt <= 0) return { amount: 0, distributed: 0 };
  const holders = db.prepare('SELECT userId FROM economy WHERE guildId = ?').all(guildId);
  const each = holders.length ? Math.floor(amt / holders.length) : 0;
  let distributed = 0;
  for (const h of holders) {
    updateBalance(guildId, h.userId, each);
    distributed += each;
  }
  econ.recordTransaction(guildId, { type: 'qe', amount: distributed, note });
  const st = econ.getState(guildId);
  econ.updateState(guildId, { totalMinted: st.totalMinted + distributed, moneySupply: econ.computeMoneySupply(guildId) });
  return { amount: amt, distributed };
}

// Bakar uang (QT): kurangi uang beredar secara proporsional dari semua pemegang.
function burnMoney(guildId, amount, note = 'Bakar uang oleh bank sentral (QT)') {
  const amt = Math.round(Number(amount) || 0);
  if (amt <= 0) return { amount: 0, burned: 0 };
  const total = econ.computeMoneySupply(guildId);
  if (total <= 0) return { amount: amt, burned: 0 };
  const holders = db.prepare('SELECT userId, balance, bank FROM economy WHERE guildId = ?').all(guildId);
  let burned = 0;
  for (const h of holders) {
    const own = h.balance + h.bank;
    if (own <= 0) continue;
    const cut = Math.min(own, Math.floor(own * amt / total));
    if (cut <= 0) continue;
    const fromBalance = Math.min(cut, h.balance);
    if (fromBalance > 0) updateBalance(guildId, h.userId, -fromBalance);
    const fromBank = cut - fromBalance;
    if (fromBank > 0) updateBank(guildId, h.userId, -fromBank);
    burned += cut;
  }
  econ.recordTransaction(guildId, { type: 'qe', amount: -burned, note });
  const st = econ.getState(guildId);
  econ.updateState(guildId, { totalBurned: st.totalBurned + burned, moneySupply: econ.computeMoneySupply(guildId) });
  return { amount: amt, burned };
}

// Set tuas kebijakan moneter secara manual (override AI).
function setRates(guildId, { rewardMultiplier, taxRate, bankInterestRate }) {
  const st = econ.getState(guildId);
  const next = {
    rewardMultiplier: rewardMultiplier != null ? Math.min(3, Math.max(0.1, Number(rewardMultiplier))) : st.rewardMultiplier,
    taxRate: taxRate != null ? Math.min(0.9, Math.max(0, Number(taxRate))) : st.taxRate,
    bankInterestRate: bankInterestRate != null ? Math.min(0.2, Math.max(0, Number(bankInterestRate))) : st.bankInterestRate,
  };
  econ.updateState(guildId, next);
  econ.addAiLog(guildId, {
    decision: `Bank sentral menyesuaikan kebijakan: reward ${next.rewardMultiplier}x, pajak ${(next.taxRate * 100).toFixed(1)}%, bunga ${(next.bankInterestRate * 100).toFixed(2)}%.`,
    policyJson: next, reasoning: 'manual (bank sentral)',
  });
  return next;
}

// ============================================================================
// MINIGAME ZERO-SUM — uang berpindah, total tetap (kecuali bank cetak/bakar).
// Entry fee masuk treasury, hadiah dibayar dari treasury.
// ============================================================================
function playMinigame(guildId, userId, bet, won = false) {
  bet = Math.max(1, Math.round(Number(bet) || 0));
  const eco = getEconomy(guildId, userId);
  if (eco.balance < bet) return { ok: false, error: `Kizco tidak cukup (punya ${eco.balance}).` };
  const st = econ.getState(guildId);
  updateBalance(guildId, userId, -bet); // bayar entry
  let payout = 0;
  if (won) {
    payout = Math.min(bet, st.treasury); // hadiah dari treasury (dibatasi saldo treasury)
    updateBalance(guildId, userId, bet + payout); // balikin entry + hadiah
    econ.updateState(guildId, { treasury: st.treasury - payout });
  } else {
    econ.updateState(guildId, { treasury: st.treasury + bet });
  }
  econ.recordTransaction(guildId, { type: 'minigame', actorId: userId, amount: won ? payout : -bet, note: won ? 'Menang minigame' : 'Kalah minigame' });
  return { ok: true, won, bet, payout, net: won ? payout : -bet };
}
