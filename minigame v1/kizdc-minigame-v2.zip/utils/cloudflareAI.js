// Helper untuk panggil Cloudflare Workers AI. Butuh CLOUDFLARE_ACCOUNT_ID dan
// CLOUDFLARE_API_TOKEN diisi di .env. Token dibuat di dashboard Cloudflare dengan
// permission "Workers AI - Read/Edit". Lihat README bagian AI untuk panduan lengkap.
const CF_API_BASE = 'https://api.cloudflare.com/client/v4/accounts';

const TEXT_MODEL = '@cf/meta/llama-3.1-8b-instruct';
const IMAGE_MODEL = '@cf/stabilityai/stable-diffusion-xl-base-1.0';

function getCredentials() {
  const accountId = process.env.CLOUDFLARE_ACCOUNT_ID;
  const apiToken = process.env.CLOUDFLARE_API_TOKEN;
  if (!accountId || !apiToken) {
    throw new Error('CLOUDFLARE_ACCOUNT_ID atau CLOUDFLARE_API_TOKEN belum diisi di .env. Lihat README bagian AI.');
  }
  return { accountId, apiToken };
}

async function generateText(messages) {
  const { accountId, apiToken } = getCredentials();
  const res = await fetch(`${CF_API_BASE}/${accountId}/ai/run/${TEXT_MODEL}`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ messages }),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => '');
    throw new Error(`Cloudflare AI merespons status ${res.status}: ${errText.slice(0, 200)}`);
  }

  const data = await res.json();
  if (!data.success || !data.result?.response) {
    throw new Error(`Cloudflare AI gagal memproses: ${JSON.stringify(data.errors || 'response kosong')}`);
  }
  return data.result.response;
}

async function generateImage(prompt) {
  const { accountId, apiToken } = getCredentials();
  const res = await fetch(`${CF_API_BASE}/${accountId}/ai/run/${IMAGE_MODEL}`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ prompt }),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => '');
    throw new Error(`Cloudflare AI merespons status ${res.status}: ${errText.slice(0, 200)}`);
  }

  const contentType = res.headers.get('content-type') || '';
  if (contentType.includes('application/json')) {
    const data = await res.json();
    throw new Error(`Cloudflare AI gagal membuat gambar: ${JSON.stringify(data.errors || data)}`);
  }

  const arrayBuffer = await res.arrayBuffer();
  return Buffer.from(arrayBuffer);
}

module.exports = { generateText, generateImage, TEXT_MODEL, IMAGE_MODEL };
