const { sendLog } = require('../utils/serverLog');
const { getAiChannel, deleteAiChannel } = require('../database/db');
const config = require('../config.json');

module.exports = {
  name: 'channelDelete',
  async execute(channel) {
    if (!channel.guild) return;

    // Kalau yang dihapus adalah channel AI privat (dihapus manual lewat Discord, bukan lewat
    // tombol "Hapus Channel Ini"), bersihkan baris DB-nya juga supaya tidak jadi data orphan.
    if (getAiChannel(channel.id)) deleteAiChannel(channel.id);

    sendLog(channel.guild, {
      title: 'Channel Dihapus',
      color: config.errorColor,
      fields: [
        { name: 'Nama', value: `${channel.name}`, inline: true },
        { name: 'Tipe', value: `${channel.type}`, inline: true },
      ],
      footer: `Channel ID: ${channel.id}`,
    });
  },
};
