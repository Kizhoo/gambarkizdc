const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('nickname')
    .setDescription('Ubah nickname seorang member')
    .addUserOption(o => o.setName('target').setDescription('Member yang akan diubah nickname-nya').setRequired(true))
    .addStringOption(o => o.setName('nama').setDescription('Nickname baru (kosongkan untuk reset ke nama asli)').setMaxLength(32))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageNicknames),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const target = interaction.options.getMember('target');
    const newName = interaction.options.getString('nama');

    if (!target) return interaction.reply({ embeds: [errorEmbed(t(lang, 'mod.not_found'))], ephemeral: true });

    if (!target.manageable) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'mod.cant_nickname'))], ephemeral: true });
    }

    try {
      await target.setNickname(newName || null);
      const message = newName
        ? t(lang, 'mod.nick_ok', { user: target.user.tag, name: newName })
        : t(lang, 'mod.nick_reset', { user: target.user.tag });
      return interaction.reply({ embeds: [successEmbed(message)] });
    } catch (err) {
      console.error('[nickname] Gagal ubah nickname:', err.message);
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'mod.nick_fail'))], ephemeral: true });
    }
  },
};
