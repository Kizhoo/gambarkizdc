const { SlashCommandBuilder } = require('discord.js');
const { getValidPlayer, safePlayerAction } = require('../../utils/musicGuard');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder().setName('autoplay').setDescription('Nyalakan/matikan autoplay lagu terkait saat antrian habis'),
  async execute(interaction, client) {
    const lang = guildLang(interaction);
    const player = await getValidPlayer(interaction, client);
    if (!player) return;

    if (typeof player.setAutoplay !== 'function') {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'music.autoplay_unavailable'))], ephemeral: true });
    }

    const newState = !player.data?.get('autoplay');
    return safePlayerAction(interaction, () => player.setAutoplay(newState, interaction.client.user), { embeds: [successEmbed(t(lang, 'music.autoplay_set', { s: newState ? t(lang, 'music.on') : t(lang, 'music.off') }))] });
  },
};
