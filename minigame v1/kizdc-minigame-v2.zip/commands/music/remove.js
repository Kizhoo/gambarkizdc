const { SlashCommandBuilder } = require('discord.js');
const { getValidPlayer } = require('../../utils/musicGuard');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('remove')
    .setDescription('Hapus lagu tertentu dari antrian berdasarkan nomor urut')
    .addIntegerOption(o => o.setName('nomor').setDescription('Nomor lagu di antrian (lihat lewat /queue)').setRequired(true).setMinValue(1)),
  async execute(interaction, client) {
    const lang = guildLang(interaction);
    const player = await getValidPlayer(interaction, client);
    if (!player) return;

    const position = interaction.options.getInteger('nomor');
    const index = position - 1;

    if (index < 0 || index >= player.queue.length) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'music.invalid_pos', { n: player.queue.length }))], ephemeral: true });
    }

    const removed = player.queue[index];
    player.queue.splice(index, 1);

    return interaction.reply({ embeds: [successEmbed(t(lang, 'music.removed', { t: removed.title }))] });
  },
};
