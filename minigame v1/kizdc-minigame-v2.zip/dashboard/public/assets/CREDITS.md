# KREDIT ASET — KizhooBot Web (pasca-RPG, era Minigame KizDefense)

Semua aset gratis dan legal dipakai. Sumber per kategori:

## Minigame KizDefense — `minigame/`
- **Free Idle Turret Defense Asset Kit** (CraftPix bundle 206389) — lisensi
  CraftPix Free License: https://craftpix.net/file-licenses/
  (diunduh dari halaman resmi CraftPix; boleh dipakai untuk proyek komersial
  dan non-komersial, dilarang redistribusi aset mentahnya).
  Isi: 20 turret (dipakai 8 tier), monster kumbang darat (8 warna), monster
  terbang (3 warna), bos hibrida (4 warna), 2 set ledakan, muzzle flash,
  3 proyektil, 4 latar, base slot, dan paket UI (tombol/bar/popup).
  Aset di-downscale dan dioptimasi ulang untuk web lewat pipeline build
  (`scripts/build_minigame_assets.py`) — hanya hasil olahan yang dipakai.

## Ikon item pasar — `icons/`
- Ikon item (w_sword, m_ember, c_ring, dst.) — digambar ulang untuk proyek ini,
  dipakai halaman market sebagai ikon barang (dengan fallback prosedural
  canvas via `item-icons.js` bila PNG tidak ada).

## Font — `fonts/`
- **Silkscreen** (400 & 700) oleh Jason Kottke — SIL Open Font License 1.1.
  https://www.kreativ.fonts.net/silkscreen (Google Fonts).
  Dipakai untuk angka HUD dan judul halaman minigame.
- **Press Start 2P** oleh CodeMan38 — SIL Open Font License 1.1.
  (disimpan untuk kebutuhan tampilan retro; saat ini tidak dipakai halaman aktif).
