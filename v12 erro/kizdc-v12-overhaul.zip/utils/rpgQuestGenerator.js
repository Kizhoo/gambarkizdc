// ============================================================================
// GENERATOR QUEST OTOMATIS (AI) — utk /rpg quest board
// ----------------------------------------------------------------------------
// Dipanggil berkala dari events/ready.js (lihat checkRpgAutoQuest). AI diminta
// merancang N quest baru dalam format JSON KETAT, hasilnya divalidasi field-per-
// field sebelum disimpan lewat rdb.createQuest(source: 'ai') — quest yang lolos
// validasi minimal saja yang masuk DB, sisanya dibuang diam-diam + logged.
//
// PENTING soal VARIASI (kenapa dulu quest-nya "itu-itu aja" - goblin/naga/hutan
// terus): sebelumnya AI dibiarkan BEBAS ngarang monster/lokasi/alasan quest dari
// nol tiap generate. Model bahasa (apalagi yang ringan/"flash") secara statistik
// cenderung balik ke ide paling umum/klise kalau tidak dikasih batasan konkret -
// itu bukan soal "kurang diminta variasi", tapi soal tidak ada apa pun yang
// MEMAKSA hasilnya beda. Solusinya BUKAN nyuruh AI lebih kreatif (sudah dicoba,
// hasilnya tetap konvergen), tapi: kita yang RANDOM PILIH kombinasi konkret
// (monster x lokasi x alasan/hook x nuansa bahaya) dari QUEST_ELEMENTS di bawah
// SEBELUM manggil AI, lalu AI cuma tugas nulis flavor text buat kombinasi PERSIS
// itu. Variasinya jadi DIJAMIN secara struktur (>100 kombinasi berbeda), AI
// tinggal nulis kalimatnya - jauh lebih tahan banting daripada gantung ke
// "kreativitas" model semata.
// ============================================================================
const { generateText } = require('./aiProvider');
const settings = require('./settings');
const D = require('./rpgData');

const SUPPORTED_OBJECTIVES = {
  monstersKilled: { label: 'kalahkan monster biasa', targetRange: [3, 15] },
  bossesDefeated: { label: 'kalahkan boss', targetRange: [1, 3] },
};

// Rank minimal biar quest "kalahkan boss" boleh muncul sama sekali. SEBELUM ini boss quest bisa
// disodorkan ke minRank berapa pun (termasuk G/F - rank paling awal), jadi pemain baru yang cuma
// punya papan quest berisi "kalahkan boss" (kayak disuruh ngelawan naga padahal baru mulai) tidak
// punya pilihan lain yang lebih gampang. Sekarang boss quest cuma boleh muncul kalau minRank quest
// itu sendiri >= C (sekitar sepertiga jalan naik rank) - di bawah itu, dipaksa jadi monster biasa.
const MIN_RANK_FOR_BOSS_QUEST = 'C';

// ---------------------------------------------------------------------------
// BANK ELEMEN QUEST - dikombinasikan acak. 22 monster x 20 lokasi x 16 hook x
// 8 nuansa = 56.320 kombinasi mungkin, jauh di atas "100+" yang diminta.
// ---------------------------------------------------------------------------
const MONSTERS = [
  'goblin', 'sekumpulan goblin', 'orc', 'kobold', 'slime raksasa', 'serigala liar', 'kawanan serigala',
  'bandit', 'perompak jalanan', 'hantu gentayangan', 'kerangka hidup', 'laba-laba raksasa', 'harpy',
  'troll jembatan', 'penyihir jahat', 'kultus terlarang', 'griffin liar', 'basilisk muda', 'mimic',
  'gargoyle hidup', 'siren danau', 'golem batu', 'naga muda', 'naga api', 'hydra rawa', 'lich pemula',
  'chimera', 'manticore', 'raja tikus got', 'iblis kecil', 'zombie', 'kawanan zombie', 'vampir muda',
  'wyvern', 'elemental api', 'elemental es', 'ogre', 'minotaur', 'banshee', 'werewolf',
];
const LOCATIONS = [
  'hutan di pinggir desa', 'hutan berkabut', 'gua gelap di bukit', 'reruntuhan kuil kuno', 'rawa beracun',
  'lereng gunung bersalju', 'tambang bawah tanah yang ditinggalkan', 'danau terpencil', 'padang rumput luas',
  'jembatan tua yang retak', 'jalan pegunungan berbahaya', 'dermaga pelabuhan', 'kastil tua yang runtuh',
  'menara penyihir terbengkalai', 'ladang gandum di luar desa', 'gurun pasir', 'katakomba bawah tanah',
  'air terjun tersembunyi', 'pasar malam yang sepi', 'perbatasan hutan terlarang', 'goa kristal',
];
const HOOKS = [
  'kepala desa yang cemas melapor', 'pedagang kehilangan barang dagangannya', 'penjaga gerbang minta bantuan',
  'seorang anak kecil ketakutan bercerita', 'pemburu berpengalaman menemukan jejak aneh', 'tetua guild mendapat laporan',
  'petani melapor ternaknya hilang', 'musafir yang lewat memperingatkan bahaya', 'biarawati kuil minta pertolongan',
  'nelayan setempat resah', 'penambang melarikan diri ketakutan', 'surat misterius tergeletak di papan quest',
  'pasukan penjaga kewalahan', 'seorang mantan petualang minta bantuan mencari rekannya yang hilang',
  'suara aneh terdengar tiap malam', 'karavan dagang diserang di tengah jalan',
];
const DANGER_FLAVORS = [
  'sudah mengganggu warga selama beberapa hari', 'baru saja muncul dan bikin geger',
  'diduga sudah lama bersarang di sana', 'semakin berani mendekati pemukiman',
  'meninggalkan jejak kehancuran ke mana pun ia pergi', 'membuat jalur dagang jadi tidak aman',
  'jadi buah bibir di seluruh desa', 'menyerang siapa pun yang lewat tanpa alasan jelas',
];

function pickRandom(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

// Bangun N "seed" kombinasi UNIK (tidak ada monster+lokasi yang sama persis dalam 1 batch,
// biar dalam 1 papan quest yang sama juga tidak kelihatan mirip-mirip).
function buildSeeds(count) {
  const seeds = [];
  const usedCombos = new Set();
  let guard = 0;
  while (seeds.length < count && guard < count * 30) {
    guard++;
    const monster = pickRandom(MONSTERS);
    const location = pickRandom(LOCATIONS);
    const comboKey = `${monster}|${location}`;
    if (usedCombos.has(comboKey)) continue;
    usedCombos.add(comboKey);
    seeds.push({ monster, location, hook: pickRandom(HOOKS), flavor: pickRandom(DANGER_FLAVORS) });
  }
  return seeds;
}

function safeJsonArray(text) {
  if (typeof text !== 'string') return null;
  let t = text.trim();
  // Buang pagar markdown kalau model tetap bungkus ```json ... ``` walau sudah diminta jangan.
  t = t.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/```\s*$/i, '').trim();
  const start = t.indexOf('['); const end = t.lastIndexOf(']');
  if (start === -1 || end === -1 || end < start) return null;
  try { const parsed = JSON.parse(t.slice(start, end + 1)); return Array.isArray(parsed) ? parsed : null; }
  catch { return null; }
}

function clampInt(v, min, max, fallback) {
  const n = Math.round(Number(v));
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, n));
}

// Validasi + normalisasi SATU quest mentah dari AI. Return null kalau tidak layak dipakai
// sama sekali (field wajib hilang/rusak) alih-alih setengah-setengah mengarang nilai penting.
function normalizeQuest(raw, guildId, monsterHint) {
  if (!raw || typeof raw !== 'object') return null;
  const title = String(raw.title || '').trim().slice(0, 80);
  const description = String(raw.description || '').trim().slice(0, 300);
  if (!title || !description) return null;

  let objectiveType = SUPPORTED_OBJECTIVES[raw.objectiveType] ? raw.objectiveType : null;
  if (!objectiveType) return null;

  const minRank = D.RANK_INDEX[raw.minRank] != null ? raw.minRank : 'G';

  // Turunkan paksa ke monstersKilled kalau quest ini ditujukan buat rank rendah - jangan sampai
  // pemain baru cuma disodorkan quest "kalahkan boss" sebagai satu-satunya pilihan.
  if (objectiveType === 'bossesDefeated' && D.RANK_INDEX[minRank] < D.RANK_INDEX[MIN_RANK_FOR_BOSS_QUEST]) {
    objectiveType = 'monstersKilled';
  }

  const [tMin, tMax] = SUPPORTED_OBJECTIVES[objectiveType].targetRange;
  const objectiveTarget = clampInt(raw.objectiveTarget, tMin, tMax, tMin);
  const type = raw.type === 'weekly' ? 'weekly' : 'daily';

  // Skala reward wajar berdasarkan target, bukan percaya mentah-mentah angka dari AI (biar
  // tidak ada quest yang ke-generate reward-nya kebablasan/nol karena model salah hitung).
  const baseXp = objectiveType === 'bossesDefeated' ? 300 : 40;
  const baseGold = objectiveType === 'bossesDefeated' ? 150 : 20;
  const rewardXp = clampInt(raw.rewardXp, objectiveTarget * baseXp * 0.5, objectiveTarget * baseXp * 2, objectiveTarget * baseXp);
  const rewardGold = clampInt(raw.rewardGold, objectiveTarget * baseGold * 0.5, objectiveTarget * baseGold * 2, objectiveTarget * baseGold);
  const rewardRep = clampInt(raw.rewardRep, 1, 25, objectiveType === 'bossesDefeated' ? 10 : 3);

  const expiresAt = Date.now() + (type === 'weekly' ? 7 : 2) * 86400000;

  return {
    // Quest bersifat GLOBAL: gunakan sentinel guildId 'global' supaya quest yang sama muncul
    // di SEMUA server (bukan per-server). Lihat README bagian quest global.
    guildId: 'global', title, description, type, objectiveType, objectiveTarget,
    rewardXp, rewardGold, rewardRep, minRank, source: 'ai', createdBy: null, expiresAt,
    monsterHint: monsterHint || null,
  };
}

async function generateQuestBatch(guildId, count = 3) {
  const seeds = buildSeeds(count);
  const objectiveList = Object.entries(SUPPORTED_OBJECTIVES).map(([k, v]) => `"${k}" (${v.label}, target wajar ${v.targetRange[0]}-${v.targetRange[1]})`).join(', ');
  const rankKeys = D.RANKS.map(r => r.key).join(', ');
  const seedList = seeds.map((s, i) => `${i + 1}. Musuh: "${s.monster}" | Lokasi: "${s.location}" | Yang melapor: "${s.hook}" | Nuansa: "${s.flavor}"`).join('\n');

  const messages = [
    {
      role: 'system',
      content: `Kamu perancang quest untuk guild petualang di game RPG Discord bernama Kizhoo Adventure. ` +
        `Tugasmu membuat ${count} quest baru dalam Bahasa Indonesia bernuansa fantasi ringan & seru, MASING-MASING WAJIB dibangun dari kombinasi elemen yang SUDAH DITENTUKAN di bawah - jangan diganti dengan idemu sendiri, cuma dikembangkan jadi cerita singkat yang mengalir natural (title + description), boleh dikreasikan gaya bahasanya asal elemen intinya tetap dipakai:\n\n` +
        `${seedList}\n\n` +
        `Balas HANYA dengan JSON array mentah (urut sesuai nomor di atas), TANPA markdown, TANPA penjelasan, ` +
        `TANPA teks lain apa pun sebelum/sesudahnya - respons kamu harus langsung bisa di-parse JSON.parse().\n\n` +
        `Setiap elemen array WAJIB punya field persis ini:\n` +
        `- title: string pendek (maks 8 kata), harus menyebut/menyiratkan musuh & lokasi dari kombinasi yang diberikan\n` +
        `- description: 1-2 kalimat flavor text yang merangkai musuh + lokasi + yang melapor + nuansa dari kombinasinya jadi cerita pendek yang masuk akal\n` +
        `- type: "daily" atau "weekly"\n` +
        `- objectiveType: HARUS SALAH SATU dari: ${objectiveList} (jangan buat tipe lain, itu tidak akan berfungsi)\n` +
        `- objectiveTarget: integer sesuai rentang wajar tipe objective-nya\n` +
        `- rewardXp, rewardGold: integer masuk akal sesuai besar target\n` +
        `- rewardRep: integer 1-25\n` +
        `- minRank: salah satu dari [${rankKeys}] (rank minimal buat ambil quest ini)\n\n` +
        `ATURAN DIFFICULTY (WAJIB, jangan dilanggar):\n` +
        `- objectiveType "bossesDefeated" HANYA BOLEH dipakai kalau minRank kamu isi ${MIN_RANK_FOR_BOSS_QUEST} atau lebih tinggi, DAN kombinasi musuhnya memang terdengar seperti boss (mis. naga, hydra, lich, chimera, manticore) - kalau musuhnya monster biasa (goblin, serigala, bandit, dll), pakai "monstersKilled" walau nuansanya berbahaya.\n` +
        `- Pemain baru (minRank G/F/E) TIDAK BOLEH disodori quest kalahkan boss - buat mereka objectiveType "monstersKilled" saja dengan target kecil (3-6).\n` +
        `- Buat SEBARAN minRank yang variatif di ${count} quest ini (jangan semuanya minRank sama), supaya ada quest gampang buat pemain baru dan quest lebih menantang buat pemain rank tinggi.`,
    },
    { role: 'user', content: `Buatkan ${count} quest baru sekarang, sesuai urutan kombinasi yang sudah diberikan.` },
  ];

  const questModel = settings.get('ai.questModel', null);
  const raw = await generateText(messages, questModel ? { model: questModel } : {});
  const arr = safeJsonArray(raw);
  if (!arr) throw new Error('AI tidak mengembalikan JSON array yang valid untuk quest.');

  const quests = arr.map((q, i) => normalizeQuest(q, guildId, seeds[i]?.monster)).filter(Boolean);
  if (!quests.length) throw new Error('Tidak ada quest hasil AI yang lolos validasi.');
  return quests;
}

module.exports = { generateQuestBatch, SUPPORTED_OBJECTIVES, MONSTERS, LOCATIONS, HOOKS, DANGER_FLAVORS };
