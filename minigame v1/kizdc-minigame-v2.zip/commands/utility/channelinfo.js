const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  subcommandOf: true,
  data: new SlashCommandBuilder()
    .setName('channelinfo')
    .setDescription('Lihat informasi channel ini atau channel lain')
    .addChannelOption(o => o.setName('channel').setDescription('Channel yang ingin dilihat')),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const channel = interaction.options.getChannel('channel') || interaction.channel;
    const embed = baseEmbed()
      .setTitle(t(lang, 'channel.title', { name: channel.name }))
      .addFields(
        { name: 'ID', value: channel.id, inline: true },
        { name: t(lang, 'info.type'), value: `${channel.type}`, inline: true },
        { name: t(lang, 'info.categories'), value: channel.parent ? channel.parent.name : t(lang, 'info.none'), inline: true },
        { name: t(lang, 'info.created'), value: `<t:${Math.floor(channel.createdTimestamp / 1000)}:R>`, inline: false },
      );
    return interaction.reply({ embeds: [embed] });
  },
};
