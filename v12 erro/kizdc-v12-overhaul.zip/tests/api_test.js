// Test integrasi: mountRpg + attachRealtime pada Express + http server sungguhan.
// Memverifikasi: login gate, me, class, dungeon kill/chest/floor, craft, skill,
// stat, leaderboard, achievements, friends, chat — end-to-end tanpa Discord.
process.env.KIZHOO_DB_PATH = '/tmp/kiz_api_test.sqlite';
require('fs').rmSync('/tmp/kiz_api_test.sqlite', { force: true });
const express = require('express');
const http = require('http');
const rpgDb = require('../database/rpgDb');
const { mountRpg } = require('../utils/rpgServer');
const { attachRealtime } = require('../utils/rpgRealtime');

const app = express();
app.use(express.json());
const sessions = {};
const auth = (req, res, next) => {
  const sid = String(req.headers.cookie || '').replace(/.*kz_sid=([^;]*).*/, '$1');
  if (sessions[sid]) { req.session = sessions[sid]; return next(); }
  return res.status(401).json({ error: 'belum login' });
};
const resolveUserId = (req) => (req.session && req.session.userId) || null;
const client = { guilds: { cache: new Map() }, users: { cache: new Map(), fetch: async () => null } };
client.guilds.cache.set('g1', { id: 'g1' });
mountRpg(app, { auth, resolveUserId, client });

const server = http.createServer(app);
attachRealtime(server, { client });
server.listen(0, async () => {
  const port = server.address().port;
  const base = 'http://127.0.0.1:' + port;
  let pass = 0, fail = 0;
  const ok = (c, m) => { if (c) { pass++; console.log('  OK', m); } else { fail++; console.log('  FAIL', m); } };
  const sid = 'testsid123';
  sessions[sid] = { userId: '777', username: 'tester', avatar: null, guilds: [{ id: 'g1', name: 'G' }] };
  rpgDb.saveSession(sid, sessions[sid]);
  const H = { 'Content-Type': 'application/json', Cookie: 'kz_sid=' + sid };
  const POST = (p, b) => fetch(base + p, { method: 'POST', headers: H, body: JSON.stringify(b || {}) }).then(r => r.json());
  const GET = (p) => fetch(base + p, { headers: H }).then(r => r.json());

  // 1. Gate login /rpg (tanpa cookie -> redirect).
  const gate = await fetch(base + '/rpg', { redirect: 'manual' });
  ok(gate.status === 302 && String(gate.headers.get('location')).includes('/auth/login'), '/rpg redirect ke login tanpa sesi');

  // 2. Gate login /rpg (dengan cookie -> 200 + config tersuntik).
  const page = await fetch(base + '/rpg', { headers: { Cookie: 'kz_sid=' + sid } });
  const html = await page.text();
  ok(page.status === 200 && html.includes('"server":true') && html.includes('"userId":"777"'), '/rpg menyuntik RPG_CONFIG user');

  // 3. me (belum ada karakter).
  let r = await GET('/api/rpg/me');
  ok(r.char === null, '/me char null di awal');

  // 4. pilih class archer.
  r = await POST('/api/rpg/class', { classKey: 'archer' });
  ok(r.ok && r.char.classKey === 'archer', 'pilih class archer');
  r = await GET('/api/rpg/me');
  ok(r.char.classKey === 'archer' && r.char.friendId && r.char.friendId.startsWith('KZ-'), 'me: archer + friendId ' + r.char.friendId);
  ok(r.char.gold === 0 && Array.isArray(r.char.skills), 'me: fields lengkap');

  // 5. dungeon kill (monster valid utk lantai).
  r = await POST('/api/rpg/dungeon/kill', { monsterId: 'slime', floor: 2 });
  ok(r.ok && r.rewards.xp > 0, 'dungeon kill slime: xp=' + (r.rewards && r.rewards.xp));

  // 6. dungeon kill monster tidak valid (dragon di lantai 2).
  r = await POST('/api/rpg/dungeon/kill', { monsterId: 'dragon', floor: 2 });
  ok(r.error && /tidak cocok/i.test(r.error), 'dungeon kill dragon@lantai2 ditolak');

  // 7. chest roll.
  r = await POST('/api/rpg/dungeon/chest', { floor: 3, tier: 'gold' });
  ok(r.ok && r.loot && r.loot.gold > 0 && r.loot.tier, 'chest: gold=' + r.loot.gold + ' tier=' + r.loot.tier);
  const goldBefore = (await GET('/api/rpg/me')).char.gold;
  ok(goldBefore > 0, 'gold dari chest masuk wallet: ' + goldBefore);

  // 8. floor completion (tanpa hadiah — hanya progres).
  r = await POST('/api/rpg/dungeon/floor', { dungeonId: 'x', floor: 1 });
  ok(r.ok, 'floor complete ok');
  const char1 = rpgDb.getCharacter('777');
  ok(char1.floorsCleared === 1, 'counter floorsCleared naik');

  // 9. kasih bahan lalu craft.
  rpgDb.addItem('777', 'm_wolf_pelt', 3);
  rpgDb.addItem('777', 'm_bat_wing', 2);
  r = await POST('/api/rpg/craft', { out: 'w_hunt_longbow' });
  ok(r.ok && r.item && r.item.id === 'w_hunt_longbow', 'craft longbow OK');
  ok(rpgDb.getItemQty('777', 'w_hunt_longbow') === 1, 'item hasil craft masuk inventori');

  // 10. craft tanpa bahan.
  r = await POST('/api/rpg/craft', { out: 'w_omega' });
  ok(r.error && /bahan kurang/i.test(r.error), 'craft tanpa bahan ditolak');

  // 11. skill unlock (perlu skill point).
  rpgDb.updateCharacter('777', { skillPoints: 5 });
  r = await POST('/api/rpg/skill', { skillId: 'ar_aim' });
  ok(r.ok && r.newLevel === 1, 'unlock skill ar_aim');

  // 12. stat allocation.
  rpgDb.updateCharacter('777', { statPoints: 3 });
  r = await POST('/api/rpg/stat', { stat: 'mp', points: 2 });
  ok(r.ok && r.added === 12, 'alokasi stat mp +12');

  // 13. equip.
  r = await POST('/api/rpg/item/equip', { itemId: 'w_hunt_longbow' });
  ok(r.ok, 'equip longbow');
  ok(rpgDb.getCharacter('777').equipWeapon === 'w_hunt_longbow', 'equipWeapon tersimpan');

  // 14. leaderboard (user kedua biar ada saingan).
  rpgDb.createCharacter('888', 'mage');
  rpgDb.updateCharacter('888', { level: 30, gameName: 'Rival' });
  r = await GET('/api/rpg/leaderboard');
  ok(r.list.length >= 2 && r.list[0].name === 'Rival' && r.list.some(x => x.isMe), 'leaderboard: nama asli + penanda saya');

  // 15. achievements.
  r = await GET('/api/rpg/achievements');
  ok(r.list.length >= 40 && r.newlyUnlocked.length > 0, 'achievements: ' + r.list.length + ' definisi, baru terbuka: ' + r.newlyUnlocked.length);
  const firstBlood = r.list.find(a => a.id === 'first_blood');
  ok(firstBlood && firstBlood.unlocked, 'first_blood otomatis terbuka');
  r = await POST('/api/rpg/achievements/claim', { achId: 'first_blood' });
  ok(r.ok && r.reward && r.reward.gold === 50, 'claim first_blood +50 gold');
  r = await POST('/api/rpg/achievements/claim', { achId: 'first_blood' });
  ok(r.error, 'claim ganda ditolak');

  // 16. friends.
  rpgDb.createCharacter('999', 'warrior');
  rpgDb.updateCharacter('999', { gameName: 'TemanSatu' });
  rpgDb.ensureFriendId('999');
  r = await POST('/api/rpg/friends/add', { query: 'TemanSatu' });
  ok(r.ok && r.status === 'pending', 'kirim permintaan teman');
  // dari sisi 999: terima.
  sessions['sid999'] = { userId: '999', username: 'u999', avatar: null, guilds: [] };
  rpgDb.saveSession('sid999', sessions['sid999']);
  const H999 = { 'Content-Type': 'application/json', Cookie: 'kz_sid=sid999' };
  const r2 = await fetch(base + '/api/rpg/friends/accept', { method: 'POST', headers: H999, body: JSON.stringify({ userId: '777' }) }).then(x => x.json());
  ok(r2.ok, 'terima permintaan');
  r = await GET('/api/rpg/friends');
  ok(r.friends.length === 1 && r.friends[0].name === 'TemanSatu', 'daftar teman: 1');

  // 17. chat history (global) via WS.
  const WebSocket = require('ws');
  await new Promise((resolve) => {
    const ws = new WebSocket('ws://127.0.0.1:' + port + '/ws', { headers: { Cookie: 'kz_sid=' + sid } });
    let opened = false;
    let done = false;
    let timer = null;
    ws.on('open', () => { opened = true; ws.send(JSON.stringify({ t: 'chat.global', message: 'halo dunia dari test' })); });
    ws.on('message', (raw) => {
      const m = JSON.parse(raw.toString());
      if (m.t === 'chat.global' && m.message === 'halo dunia dari test') {
        done = true; clearTimeout(timer);
        ok(opened && m.name === 'tester', 'WS chat global: pesan diterima balik (nama=' + m.name + ')');
        ws.close(); resolve();
      }
    });
    ws.on('error', () => { if (!done) { done = true; clearTimeout(timer); ok(false, 'WS koneksi error'); resolve(); } });
    timer = setTimeout(() => { if (!done) { done = true; ok(false, 'WS timeout'); try { ws.close(); } catch (_) {} resolve(); } }, 4000);
  });
  r = await GET('/api/rpg/chat/global');
  ok(r.messages.length >= 1 && r.messages[0].message.includes('halo dunia'), 'chat global tersimpan di DB');

  // 17b. POST chat global (fallback REST saat WS diblokir) + relay ke klien WS.
  await new Promise(async (resolve) => {
    const ws = new WebSocket('ws://127.0.0.1:' + port + '/ws', { headers: { Cookie: 'kz_sid=' + sid } });
    let done = false, timer = null;
    ws.on('open', async () => {
      const p = await POST('/api/rpg/chat/global', { message: 'pesan fallback rest' });
      ok(p.ok === true && p.message === 'pesan fallback rest' && p.name === 'tester', 'POST /chat/global: ok + nama + isi');
      ok(p.id && p.at, 'POST /chat/global: id + timestamp dikembalikan');
    });
    ws.on('message', (raw) => {
      const m = JSON.parse(raw.toString());
      if (m.t === 'chat.global' && m.message === 'pesan fallback rest') {
        done = true; clearTimeout(timer);
        ok(true, 'POST /chat/global tersiarkan ke klien WS via relay');
        ws.close(); resolve();
      }
    });
    ws.on('error', () => { if (!done) { done = true; clearTimeout(timer); ok(false, 'WS relay error'); resolve(); } });
    timer = setTimeout(() => { if (!done) { done = true; ok(false, 'relay POST chat ke WS timeout'); try { ws.close(); } catch (_) {} resolve(); } }, 4000);
  });
  r = await GET('/api/rpg/chat/global');
  ok(r.messages.some((m) => m.message === 'pesan fallback rest'), 'chat REST tersimpan di DB & terbaca di history');

  // 17c. POST chat DM (fallback REST) — hanya sesama teman.
  const sidB = 'testsidB';
  sessions[sidB] = { userId: '999', username: 'temansatu', avatar: null, guilds: [{ id: 'g1', name: 'G' }] };
  rpgDb.saveSession(sidB, sessions[sidB]);
  const HB = { 'Content-Type': 'application/json', Cookie: 'kz_sid=' + sidB };
  const pDm = await fetch(base + '/api/rpg/chat/dm', { method: 'POST', headers: HB, body: JSON.stringify({ to: '777', message: 'dm via rest' }) }).then((x) => x.json());
  ok(pDm.ok === true && pDm.message === 'dm via rest', 'POST /chat/dm ke teman: ok');
  const sidR = 'testsidRival';
  sessions[sidR] = { userId: '888', username: 'rival', avatar: null, guilds: [{ id: 'g1', name: 'G' }] };
  rpgDb.saveSession(sidR, sessions[sidR]);
  const HR = { 'Content-Type': 'application/json', Cookie: 'kz_sid=' + sidR };
  const pDmBad = await fetch(base + '/api/rpg/chat/dm', { method: 'POST', headers: HR, body: JSON.stringify({ to: '777', message: 'bukan teman' }) }).then((x) => x.json());
  ok(pDmBad.error, 'POST /chat/dm ke non-teman: ditolak');
  const pEmpty = await POST('/api/rpg/chat/global', { message: '   ' });
  ok(pEmpty.error, 'POST /chat/global kosong: ditolak');
  r = await GET('/api/rpg/chat/dm?with=999');
  ok(r.messages.some((m) => m.message === 'dm via rest'), 'chat DM REST tersimpan & terbaca di history');

  // 18. WS auth tanpa cookie ditolak.
  await new Promise((resolve) => {
    const ws = new WebSocket('ws://127.0.0.1:' + port + '/ws');
    ws.on('close', (code) => { ok(code === 1008, 'WS tanpa sesi ditolak (code=' + code + ')'); resolve(); });
    ws.on('error', () => {});
    setTimeout(resolve, 2500);
  });

  // 19. SISTEM PET: grant, xp, activate, whistle, snack.
  {
    const g = rpgDb.grantPet('777', 'ember');
    ok(g.ok && !g.duplicate, 'grantPet ember (baru)');
    const g2 = rpgDb.grantPet('777', 'ember');
    ok(g2.ok && g2.duplicate, 'grantPet ember kedua = duplikat');
    const xp = rpgDb.addPetXp('777', 'ember', 500);
    ok(xp.ok && xp.level > 1, 'pet xp naik level (' + xp.level + ', +' + xp.leveled + ')');
    let r = await POST('/api/rpg/pet/activate', { petId: 'ember' });
    ok(r.ok && r.activePetId === 'ember', 'aktifkan pet ember');
    r = await POST('/api/rpg/pet/activate', { petId: 'nyx' });
    ok(!r.ok, 'aktifkan pet yang belum dimiliki ditolak');
    r = await GET('/api/rpg/pets');
    const ember = (r.pets || []).find((p) => p.id === 'ember');
    const nyx = (r.pets || []).find((p) => p.id === 'nyx');
    ok(r.pets && r.pets.length === 15 && ember && ember.owned && ember.active, 'koleksi pet: 15 jenis (mythic masuk), ember aktif');
    ok(nyx && !nyx.owned, 'nyx belum dimiliki (terkunci)');
    // Beri seruling + camilan, lalu pakai.
    rpgDb.addItem('777', 'm_whistle_cracked', 1);
    rpgDb.addItem('777', 'm_snack', 3);
    const before = Object.keys({ ...rpgDb.getPets('777').reduce((o, p) => (o[p.petId] = 1, o), {}) }).length;
    r = await POST('/api/rpg/item/use', { itemId: 'm_whistle_cracked' });
    ok(r.ok && r.exchanged && r.exchanged.gems >= 70, 'seruling ditukar permata gacha: +' + (r.exchanged && r.exchanged.gems));
    r = await POST('/api/rpg/item/use', { itemId: 'm_snack' });
    ok(r.ok && r.pet && r.pet.level >= 1, 'camilan memberi XP pet aktif');
    const afterPets = rpgDb.getPets('777');
    ok(afterPets.length >= before, 'koleksi pet bertambah / tetap (duplikat dikompensasi)');
    // Pet passive muncul di /me.
    r = await GET('/api/rpg/me');
    ok(r.char && r.char.pet && r.char.pet.id, 'me: pet aktif terlihat (' + (r.char.pet && r.char.pet.id) + ')');
    ok(Array.isArray(r.char.pets) && r.char.pets.length === afterPets.length, 'me: koleksi pet terkirim');
    function PETS_OK(id) { return ['ember','bolt','leafy','pebble','aqua'].includes(id); }
  }

  // 20. Peti TIDAK lagi mengeluarkan pet (gacha satu-satunya sumber) — beri shard+permata.
  {
    let gotShards = false, gotGems = false, gotPet = false, tries = 0;
    // Satu pembukaan DETERMINISTIK: Math.random dipaksa 0 (selalu lolos ambang
    // peluang permata) — menghilangkan flakiness peluang 16% per peti.
    const origRandom = Math.random;
    Math.random = () => 0;
    let forced = await POST('/api/rpg/dungeon/chest', { floor: 30, tier: 'gold' });
    Math.random = origRandom;
    if (forced.loot && forced.loot.shards) gotShards = true;
    if (forced.loot && forced.loot.gems) gotGems = true;
    if (forced.loot && forced.loot.pet) gotPet = true;
    tries++;
    for (let i = 0; i < 8; i++) {
      const r = await POST('/api/rpg/dungeon/chest', { floor: 30, tier: 'gold' });
      if (r.loot && r.loot.shards) gotShards = true;
      if (r.loot && r.loot.gems) gotGems = true;
      if (r.loot && r.loot.pet) gotPet = true;
      tries++;
    }
    ok(gotShards && !gotPet, 'peti beri pecahan bintang & TIDAK beri pet (' + tries + 'x)');
    ok(gotGems, 'peti kadang beri permata gacha');
  }

  // 20b. GACHA: tarik, pity, duplikat->shard, mythic pool.
  {
    rpgDb.addGems('777', 10000);
    let r = await POST('/api/rpg/gacha/pull', { count: 10 });
    ok(r.ok && r.pulls && r.pulls.length === 10, 'gacha 10x menghasilkan 10 tarikan');
    const rarOk = r.pulls.every((p) => ['common','uncommon','rare','epic','legendary','mythic'].includes(p.rarity));
    ok(rarOk, 'semua hasil gacha punya rarity valid');
    let dupes = 0;
    for (let i = 0; i < 6; i++) { r = await POST('/api/rpg/gacha/pull', { count: 10 }); for (const p of r.pulls) if (p.duplicate) dupes++; }
    ok(dupes > 0, 'duplikat gacha berubah pecahan (' + dupes + ' duplikat)');
    r = await GET('/api/rpg/gacha');
    ok(r.ok && r.gems >= 0 && r.config && r.config.rates.mythic === 0.008, 'info gacha: saldo + rates (mythic 0.8%)');
  }

  // 20c. EVOLUSI: level pet -> evolve -> stage 2.
  {
    const pets = rpgDb.getPets('777');
    const pet = pets[0];
    for (let i = 0; i < 40; i++) rpgDb.addPetXp('777', pet.petId, 9999);
    const ev = require('../utils/rpgData').PET_EVOLUTION[pet.petId];
    rpgDb.addPetShards('777', ev.shards);
    rpgDb.addGold('777', 'g1', ev.gold + 5000);
    const r = await POST('/api/rpg/pet/evolve', { petId: pet.petId });
    ok(r.ok && r.pet && r.pet.stage === 2, 'evolusi pet ' + pet.petId + ' -> stage 2 (' + (r.error || 'ok') + ')');
    const r2 = await POST('/api/rpg/pet/evolve', { petId: pet.petId });
    ok(r2.error, 'evolusi kedua ditolak');
  }

  // 20d. MENARA: naik berurutan + reward.
  {
    let r = await POST('/api/rpg/tower/clear', { floor: 1 });
    ok(r.ok && r.rewards && r.rewards.gems > 0, 'tower lantai 1: +' + (r.rewards && r.rewards.gems) + ' permata');
    r = await POST('/api/rpg/tower/clear', { floor: 5 });
    ok(r.error, 'tower lompat lantai ditolak');
    r = await POST('/api/rpg/tower/clear', { floor: 2 });
    ok(r.ok, 'tower lantai 2 berurutan diterima');
    r = await GET('/api/rpg/tower');
    ok(r.ok && r.best === 2, 'rekor menara tersimpan (2)');
  }

  // 20e. WORLD BOSS: status + serang.
  {
    let r = await GET('/api/rpg/worldboss');
    ok(r.ok && r.boss && r.boss.maxHp > 0, 'world boss mingguan aktif: ' + (r.boss && r.boss.name));
    r = await POST('/api/rpg/worldboss/attack', { damage: 999999999 });
    ok(r.ok && r.applied > 0 && r.applied < 999999999, 'serangan dijepit wajar: ' + r.applied);
    r = await GET('/api/rpg/worldboss');
    ok(r.my && r.my.damage > 0, 'kontribusi tercatat: ' + r.my.damage);
  }

  // 20f. RUMAH LELANG: pasang -> beli (user lain) -> batal.
  {
    rpgDb.addItem('777', 'p_heal_s', 3);
    let r = await POST('/api/rpg/auction/list', { itemId: 'p_heal_s', qty: 1, price: 120 });
    ok(r.ok && r.auction, 'lelang dipasang');
    if (!rpgDb.getCharacter('888')) rpgDb.createCharacter('888', 'mage');
    rpgDb.addGold('888', 'g1', 5000);
    const bH = { 'Content-Type': 'application/json', Cookie: 'kz_sid=buyersid' };
    sessions['buyersid'] = { userId: '888', username: 'buyer', avatar: null, guilds: [{ id: 'g1', name: 'G' }] };
    const BPOST = (p2, b2) => fetch(base + p2, { method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: 'kz_sid=buyersid' }, body: JSON.stringify(b2 || {}) }).then((x) => x.json());
    const BGET = (p2) => fetch(base + p2, { headers: bH }).then((x) => x.json());
    r = await BPOST('/api/rpg/auction/buy', { id: r.auction.id });
    ok(r.ok, 'lelang dibeli user lain');
    rpgDb.addItem('888', 'p_mana', 2);
    r = await BPOST('/api/rpg/auction/list', { itemId: 'p_mana', qty: 1, price: 90 });
    r = await BPOST('/api/rpg/auction/cancel', { id: r.auction.id });
    ok(r.ok, 'lelang dibatalkan pemiliknya');
  }

  // 20g. HADIAH antar teman.
  {
    rpgDb.addFriend('777', '888');
    let r = await POST('/api/rpg/gift/send', { toUserId: '888', kind: 'gold', amount: 250, message: 'nih' });
    ok(r.ok, 'hadiah gold terkirim');
    r = await fetch(base + '/api/rpg/gift/inbox', { headers: { Cookie: 'kz_sid=buyersid' } }).then((x) => x.json());
    ok(r.ok && r.gifts && r.gifts.length >= 1, 'inbox hadiah terlihat');
    r = await fetch(base + '/api/rpg/gift/claim', { method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: 'kz_sid=buyersid' }, body: JSON.stringify({ id: r.gifts[0].id }) }).then((x) => x.json());
    ok(r.ok, 'hadiah diklaim');
  }

  // 20h. PRESTIGE ditolak di level rendah.
  {
    const r = await POST('/api/rpg/prestige', { });
    ok(r.error, 'prestige ditolak di bawah level 50');
  }

  // 20i. PEDAGANG: beli ramuan.
  {
    rpgDb.addGold('777', 'g1', 5000);
    const r = await POST('/api/rpg/merchant/buy', { itemId: 'p_heal_s' });
    ok(r.ok && r.item, 'pedagang jual ramuan (' + (r.error || r.item.name) + ')');
    const r2 = await POST('/api/rpg/merchant/buy', { itemId: 'w_sword' });
    ok(r2.error, 'pedagang tolak item non-ramuan');
  }

  console.log('\\n==== HASIL API: ' + pass + ' lulus, ' + fail + ' gagal ====');
  // Exit BERSIH: tanpa process.exit() — kombinasi process.exit + finalizer
  // better-sqlite3 memicu crash native (Statement::~Statement assertion) di
  // Node 24. Set exitCode lalu biarkan proses keluar natural setelah DB ditutup.
  process.exitCode = fail ? 1 : 0;
  try { server.close(); } catch (_) {}
  try { server.closeAllConnections && server.closeAllConnections(); } catch (_) {}
  try { rpgDb.close(); } catch (_) {}
});
