const { SlashCommandBuilder } = require('discord.js');
const { setBirthday, removeBirthday, getUpcomingBirthdays } = require('../../database/db');
const { successEmbed, errorEmbed, baseEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('birthday')
    .setDescription('Kelola tanggal ulang tahun kamu')
    .addSubcommand(sub => sub.setName('set').setDescription('Atur tanggal ulang tahun kamu supaya dirayakan bot')
      .addIntegerOption(o => o.setName('tanggal').setDescription('Tanggal (1-31)').setRequired(true).setMinValue(1).setMaxValue(31))
      .addIntegerOption(o => o.setName('bulan').setDescription('Bulan (1-12)').setRequired(true).setMinValue(1).setMaxValue(12)))
    .addSubcommand(sub => sub.setName('remove').setDescription('Hapus data ulang tahun kamu'))
    .addSubcommand(sub => sub.setName('list').setDescription('Lihat daftar ulang tahun member di server ini')),

  async execute(interaction) {
    const lang = guildLang(interaction);
    const sub = interaction.options.getSubcommand();
    const monthName = (n) => t(lang, 'month.' + n);

    if (sub === 'set') {
      const day = interaction.options.getInteger('tanggal');
      const month = interaction.options.getInteger('bulan');
      const daysInMonth = new Date(2024, month, 0).getDate();
      if (day > daysInMonth) return interaction.reply({ embeds: [errorEmbed(t(lang, 'bday.invalid', { m: monthName(month) }))], ephemeral: true });

      setBirthday(interaction.guild.id, interaction.user.id, day, month);
      return interaction.reply({ embeds: [successEmbed(t(lang, 'bday.set', { d: day, m: monthName(month) }))], ephemeral: true });
    }

    if (sub === 'remove') {
      const removed = removeBirthday(interaction.guild.id, interaction.user.id);
      if (!removed) return interaction.reply({ embeds: [errorEmbed(t(lang, 'bday.not_set'))], ephemeral: true });
      return interaction.reply({ embeds: [successEmbed(t(lang, 'bday.removed'))], ephemeral: true });
    }

    if (sub === 'list') {
      const all = getUpcomingBirthdays(interaction.guild.id);
      if (all.length === 0) return interaction.reply({ embeds: [baseEmbed().setDescription(t(lang, 'bday.empty'))] });

      const now = new Date();
      const currentMonth = now.getMonth() + 1;
      const currentDay = now.getDate();
      const sorted = [...all].sort((a, b) => {
        const diffA = ((a.month - currentMonth + 12) % 12) * 31 + (a.day - currentDay);
        const diffB = ((b.month - currentMonth + 12) % 12) * 31 + (b.day - currentDay);
        return diffA - diffB;
      });

      const description = sorted.slice(0, 15).map(b => `**${b.day} ${monthName(b.month)}** — <@${b.userId}>`).join('\n');
      return interaction.reply({ embeds: [baseEmbed().setTitle(t(lang, 'bday.title')).setDescription(description)] });
    }
  },
};
