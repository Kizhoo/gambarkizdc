const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { safeDefer } = require('../../utils/interactionHelpers');
const { fetchJson } = require('../../utils/publicApi');
const settings = require('../../utils/settings');
const { t, guildLang } = require('../../utils/i18n');

const SFW_SOURCES = [
  { name: 'NekosAPI', url: () => `https://api.nekosapi.com/v4/images/random?rating=safe&limit=1&t=${Date.now()}`, extract: d => d?.[0] },
  { name: 'nekos.best', url: () => 'https://nekos.best/api/v2/waifu', extract: d => ({ url: d.results?.[0]?.url, tags: ['waifu'] }) },
  { name: 'nekos.life', url: () => 'https://nekos.life/api/v2/img/waifu', extract: d => ({ url: d.url, tags: ['waifu'] }) },
];

const EXPLICIT_TAGS = new Set(['pussy', 'penis', 'sex', 'exposed_anus', 'exposed_girl_breasts', 'exposed_boy_breasts']);

async function fetchExplicit() {
  let last;
  for (let attempt = 0; attempt < 5; attempt++) {
    const data = await fetchJson(`https://api.nekosapi.com/v4/images/random?rating=explicit&limit=1&t=${Date.now()}-${attempt}`, { timeout: 15000 });
    const image = data?.[0];
    last = image;
    if (image?.url && image.rating === 'explicit' && image.tags?.some(tag => EXPLICIT_TAGS.has(tag))) return image;
  }
  if (last?.url && last.rating === 'explicit') return last;
  throw new Error('penyedia tidak mengembalikan gambar explicit yang tervalidasi');
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('waifu')
    .setDescription('Gambar anime acak dengan mode SFW atau explicit NSFW')
    .addStringOption(o => o.setName('mode').setDescription('Default mengikuti pengaturan NSFW bot')
      .addChoices(
        { name: 'Otomatis (ikuti config)', value: 'auto' },
        { name: 'SFW', value: 'sfw' },
        { name: 'NSFW explicit', value: 'nsfw' },
      )),

  cooldown: 5,
  async execute(interaction) {
    const lang = guildLang(interaction);
    const selected = interaction.options.getString('mode') || 'auto';
    const globallyEnabled = settings.get('isNsfw', false);
    const wantNsfw = selected === 'nsfw' || (selected === 'auto' && globallyEnabled);

    if (wantNsfw && !globallyEnabled) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'waifu.nsfw_off'))], ephemeral: true });
    }
    if (wantNsfw && interaction.channel?.nsfw !== true) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'waifu.channel_nsfw'))], ephemeral: true });
    }
    if (!(await safeDefer(interaction))) return;

    try {
      if (wantNsfw) {
        const image = await fetchExplicit();
        const tags = image.tags?.filter(tag => EXPLICIT_TAGS.has(tag)).slice(0, 4).join(', ') || 'explicit';
        return interaction.editReply({ embeds: [baseEmbed()
          .setTitle('🔞 Waifu Explicit NSFW')
          .setDescription(`Rating API: **explicit** • Tag: ${tags}`)
          .setImage(image.url)
          .setFooter({ text: `${t(lang, 'waifu.source', { name: 'NekosAPI v4' })} • ${t(lang, 'waifu.age_restricted')}` })] });
      }

      let lastError;
      for (const source of SFW_SOURCES) {
        try {
          const image = source.extract(await fetchJson(source.url(), { timeout: 12000 }));
          if (!image?.url) throw new Error('URL gambar kosong');
          return interaction.editReply({ embeds: [baseEmbed().setTitle('🌸 Waifu SFW').setImage(image.url).setFooter({ text: `${t(lang, 'waifu.source', { name: source.name })} • SFW` })] });
        } catch (error) {
          lastError = error;
          console.warn(`[waifu] ${source.name}: ${error.message}`);
        }
      }
      throw lastError || new Error('semua penyedia SFW gagal');
    } catch (error) {
      console.error('[waifu]', error);
      return interaction.editReply({ embeds: [errorEmbed(t(lang, 'waifu.load_fail', { err: error.message }))] }).catch(() => {});
    }
  },
};
