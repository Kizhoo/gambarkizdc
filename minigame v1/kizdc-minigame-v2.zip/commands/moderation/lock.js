const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('lock')
    .setDescription('Kunci/buka channel ini')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addSubcommand(sub => sub.setName('on').setDescription('Kunci channel ini (member tidak bisa kirim pesan)'))
    .addSubcommand(sub => sub.setName('off').setDescription('Buka kunci channel ini')),

  async execute(interaction) {
    const lang = guildLang(interaction);
    const sub = interaction.options.getSubcommand();

    if (sub === 'on') {
      await interaction.channel.permissionOverwrites.edit(interaction.guild.roles.everyone, { SendMessages: false });
      return interaction.reply({ embeds: [successEmbed(t(lang, 'mod.locked'))] });
    }

    if (sub === 'off') {
      await interaction.channel.permissionOverwrites.edit(interaction.guild.roles.everyone, { SendMessages: null });
      return interaction.reply({ embeds: [successEmbed(t(lang, 'mod.unlocked'))] });
    }
  },
};
