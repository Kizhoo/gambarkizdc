// ============================================================================
// KIZHOO ADVENTURE — REALTIME SERVER (WebSocket)
// ----------------------------------------------------------------------------
// Dipasang ke HTTP server dashboard: attachRealtime(server, { client }).
// Menangani: presence (siapa online), chat global, chat pribadi antar teman,
// lobby multiplayer (maks 4 orang, karakter terlihat bergerak), dan relay
// party raid (host authoritative — klien kirim aksi, host broadcast state).
//
// Protokol JSON: { t: 'tipe', ...data }. Autentikasi via cookie kz_sid
// (sama dengan dashboard — session persist di SQLite).
// ============================================================================
const { WebSocketServer } = require('ws');
const rpgDb = require('../database/rpgDb');
const Sec = require('./security');

const LOBBY_MAX = 4;
const CHAT_RATE = { max: 10, windowMs: 10 * 1000 };
// Batas keamanan WebSocket: pesan terlalu besar / banjir -> putus.
const MSG_MAX_BYTES = 8 * 1024;
const MSG_MAX_PER_10S = 240; // mencakup sync posisi lobby (tiap ~100ms)

function attachRealtime(server, { client } = {}) {
  const wss = new WebSocketServer({ server, path: '/ws' });

  // userId -> Set<socket>; dipakai untuk presence & pengiriman langsung.
  const sockets = new Map();
  // Set userId online — dibaca rpgServer.js (friends online) lewat global.
  const online = new Set();
  global.__rpgOnline = online;

  // Lobby in-memory: code -> { code, name, leaderId, members:Set }
  const lobbies = new Map();
  // v10: snapshot lobby dibaca endpoint REST rpgServer (mode hemat tanpa WS).
  global.__rpgLobbies = lobbies;
  const codeGen = () => [...Array(5)].map(() => 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[Math.floor(Math.random() * 32)]).join('');

  const chatBuckets = new Map(); // userId -> [timestamps]

  function send(ws, obj) { try { if (ws.readyState === 1) ws.send(JSON.stringify(obj)); } catch (_) {} }
  function sendToUser(userId, obj) {
    const set = sockets.get(userId);
    if (!set) return;
    for (const ws of set) send(ws, obj);
  }
  function broadcast(obj, exceptUserId = null) {
    for (const [uid, set] of sockets) {
      if (exceptUserId && uid === exceptUserId) continue;
      for (const ws of set) send(ws, obj);
    }
  }
  function broadcastLobby(code, obj) {
    const lob = lobbies.get(code);
    if (!lob) return;
    for (const uid of lob.members) sendToUser(uid, obj);
  }
  function lobbyInfo(lob) {
    return { code: lob.code, name: lob.name, count: lob.members.size, max: LOBBY_MAX };
  }
  function broadcastLobbyList() {
    broadcast({ t: 'lobby.list', lobbies: [...lobbies.values()].map(lobbyInfo) });
  }

  // Relay untuk rpgServer.js: pesan chat yang dikirim lewat POST REST
  // (fallback saat WebSocket diblokir proxy hosting) tetap disiarkan ke
  // semua klien WS — user realtime & user "mode hemat" saling melihat.
  global.__rpgChatRelay = {
    broadcast: (obj) => broadcast(obj),
    toUser: (userId, obj) => sendToUser(userId, obj),
  };

  function parseSid(req) {
    try {
      const cookies = String(req.headers.cookie || '');
      const m = /kz_sid=([^;]+)/.exec(cookies);
      return m ? decodeURIComponent(m[1]) : null;
    } catch (_) { return null; }
  }

  // Sanitasi teks user: buang karakter kontrol & zero-width (anti abuse/spoof).
  function cleanText(s, max) {
    return String(s || '').replace(/[\u0000-\u0008\u000B-\u001F\u007F\u200B-\u200F\u2028\u2029\uFEFF]/g, '').trim().slice(0, max);
  }

  function peerState(ws) {
    const c = rpgDb.getCharacter(ws.userId);
    return {
      userId: ws.userId,
      name: (c && c.gameName) || ws.username || 'Petualang',
      classKey: c ? c.className : null,
      level: c ? c.level : 1,
      petId: c ? (c.activePetId || null) : null,
      x: ws.lobbyX != null ? ws.lobbyX : 0,
      y: ws.lobbyY != null ? ws.lobbyY : 0,
      flip: !!ws.lobbyFlip,
      anim: ws.lobbyAnim || 'idle',
      ready: !!ws.lobbyReady,
    };
  }
  function pushLobbyPeers(code) {
    const lob = lobbies.get(code);
    if (!lob) return;
    const peers = [];
    for (const uid of lob.members) {
      const set = sockets.get(uid);
      if (set) for (const ws of set) { peers.push(peerState(ws)); break; }
    }
    broadcastLobby(code, { t: 'lobby.peers', ...lobbyInfo(lob), peers });
  }

  wss.on('connection', (ws, req) => {
    // ANTI cross-site WebSocket hijacking: Origin domain asing langsung ditolak.
    if (!Sec.wsOriginOk(req)) { ws.close(4003, 'Forbidden'); return; }
    const sid = parseSid(req);
    const session = sid ? rpgDb.getSession(sid) : null;
    if (!session || !session.userId) { send(ws, { t: 'error', message: 'Sesi tidak valid — login ulang.' }); ws.close(1008, 'Sesi tidak valid'); return; }

    ws.userId = String(session.userId);
    ws.username = session.username || null;
    ws.isAlive = true;
    ws.lobbyCode = null;
    ws.msgBucket = []; // rate-limit per-socket (banjir pesan)

    if (!sockets.has(ws.userId)) sockets.set(ws.userId, new Set());
    sockets.get(ws.userId).add(ws);
    const firstConn = online.size === 0 || !online.has(ws.userId);
    online.add(ws.userId);

    send(ws, { t: 'hello.ok', userId: ws.userId, name: ws.username });
    if (firstConn) broadcast({ t: 'presence', online: [...online] }, ws.userId);
    broadcastLobbyList();

    ws.on('pong', () => { ws.isAlive = true; });
    ws.on('close', () => {
      const set = sockets.get(ws.userId);
      if (set) { set.delete(ws); if (!set.size) sockets.delete(ws.userId); }
      if (!sockets.has(ws.userId)) {
        online.delete(ws.userId);
        broadcast({ t: 'presence', online: [...online] });
        if (ws.lobbyCode && lobbies.has(ws.lobbyCode)) leaveLobby(ws);
      }
    });
    ws.on('message', (raw) => {
      // Guard ukuran + banjir — koneksi nakal diputus tanpa membebani server.
      try {
        const size = raw && raw.length != null ? raw.length : String(raw).length;
        if (size > MSG_MAX_BYTES) { ws.close(4009, 'Payload terlalu besar'); return; }
        const nowTs = Date.now();
        ws.msgBucket = ws.msgBucket.filter((t) => nowTs - t < 10 * 1000);
        if (ws.msgBucket.length >= MSG_MAX_PER_10S) { ws.close(4008, 'Banjir pesan'); return; }
        ws.msgBucket.push(nowTs);
      } catch (_) { ws.close(1011, 'Kesalahan'); return; }
      let msg = null;
      try { msg = JSON.parse(String(raw)); } catch (_) { return; }
      if (!msg || typeof msg !== 'object' || Array.isArray(msg)) return;
      if (typeof msg.t !== 'string' || msg.t.length > 24) return;
      try { handle(ws, msg); } catch (e) { send(ws, { t: 'error', message: 'Aksi gagal diproses.' }); }
    });
  });

  function leaveLobby(ws) {
    const code = ws.lobbyCode;
    if (!code) return;
    const lob = lobbies.get(code);
    ws.lobbyCode = null; ws.lobbyReady = false;
    if (!lob) return;
    lob.members.delete(ws.userId);
    if (!lob.members.size) { lobbies.delete(code); }
    else {
      // Leader keluar -> bubarkan lobby (sederhana & jelas).
      if (lob.leaderId === ws.userId) {
        for (const uid of [...lob.members]) {
          const set = sockets.get(uid);
          if (set) for (const s of set) { s.lobbyCode = null; send(s, { t: 'lobby.closed', reason: 'leader' }); }
        }
        lobbies.delete(code);
      } else {
        broadcastLobby(code, { t: 'lobby.left', userId: ws.userId, ...lobbyInfo(lob) });
        pushLobbyPeers(code);
      }
    }
    broadcastLobbyList();
  }

  function handle(ws, msg) {
    switch (msg.t) {
      // ---------------- CHAT GLOBAL ----------------
      case 'chat.global': {
        const text = cleanText(msg.message, 300);
        if (!text) return;
        const nowTs = Date.now();
        const arr = (chatBuckets.get(ws.userId) || []).filter((t) => nowTs - t < CHAT_RATE.windowMs);
        if (arr.length >= CHAT_RATE.max) { send(ws, { t: 'chat.reject', reason: 'Terlalu cepat — tarik napas dulu.' }); return; }
        arr.push(nowTs); chatBuckets.set(ws.userId, arr);
        const row = rpgDb.addChatMessage({ channel: 'global', fromUserId: ws.userId, message: text });
        const c = rpgDb.getCharacter(ws.userId);
        broadcast({ t: 'chat.global', id: row.id, from: ws.userId, name: (c && c.gameName) || ws.username || 'Petualang', message: text, at: row.createdAt, classKey: c ? c.className : null });
        break;
      }
      // ---------------- CHAT PRIBADI (teman) ----------------
      case 'chat.dm': {
        const to = String(msg.to || '').replace(/\D/g, '').slice(0, 20);
        const text = cleanText(msg.message, 300);
        if (!to || !text || to === ws.userId) return;
        // Hanya teman yang boleh saling DM.
        const isFriend = rpgDb.getFriends(ws.userId).some((f) => f.friendUserId === to);
        if (!isFriend) { send(ws, { t: 'chat.reject', reason: 'Hanya bisa chat dengan teman.' }); return; }
        const row = rpgDb.addChatMessage({ channel: 'dm', fromUserId: ws.userId, toUserId: to, message: text });
        const c = rpgDb.getCharacter(ws.userId);
        const payload = { t: 'chat.dm', id: row.id, from: ws.userId, to, name: (c && c.gameName) || ws.username || 'Petualang', message: text, at: row.createdAt };
        sendToUser(to, payload);
        sendToUser(ws.userId, payload); // echo ke pengirim (multi-tab sinkron)
        break;
      }
      // ---------------- LOBBY ----------------
      case 'lobby.create': {
        if (ws.lobbyCode) leaveLobby(ws);
        let code = codeGen(), guard = 0;
        while (lobbies.has(code) && guard++ < 30) code = codeGen();
        const name = cleanText(msg.name, 24) || ('Party ' + code);
        const lob = { code, name, leaderId: ws.userId, members: new Set([ws.userId]) };
        lobbies.set(code, lob);
        ws.lobbyCode = code; ws.lobbyReady = false;
        send(ws, { t: 'lobby.joined', ...lobbyInfo(lob), leader: true, code });
        pushLobbyPeers(code);
        broadcastLobbyList();
        break;
      }
      case 'lobby.join': {
        if (ws.lobbyCode) leaveLobby(ws);
        const code = String(msg.code || '').toUpperCase().trim();
        const lob = lobbies.get(code);
        if (!lob) { send(ws, { t: 'lobby.error', message: 'Lobby tidak ditemukan atau sudah bubar.' }); return; }
        if (lob.members.size >= LOBBY_MAX) { send(ws, { t: 'lobby.error', message: 'Lobby penuh (maksimal 4 orang).' }); return; }
        lob.members.add(ws.userId);
        ws.lobbyCode = code; ws.lobbyReady = false;
        send(ws, { t: 'lobby.joined', ...lobbyInfo(lob), leader: false, code });
        const c = rpgDb.getCharacter(ws.userId);
        broadcastLobby(code, { t: 'lobby.chat', from: 'system', name: '', message: ((c && c.gameName) || ws.username || 'Petualang') + ' masuk lobby.' });
        pushLobbyPeers(code);
        broadcastLobbyList();
        break;
      }
      case 'lobby.leave': leaveLobby(ws); break;
      // Refresh daftar lobby: tombol Refresh / recovery sambungan meminta
      // daftar terkini (dulu client kirim 'hello' yang TIDAK pernah dijawab
      // -> tombol Refresh gagal senyap).
      case 'lobby.list': send(ws, { t: 'lobby.list', lobbies: [...lobbies.values()].map(lobbyInfo) }); break;
      case 'lobby.state': {
        if (!ws.lobbyCode) return;
        if (typeof msg.x === 'number') ws.lobbyX = msg.x;
        if (typeof msg.y === 'number') ws.lobbyY = msg.y;
        if (typeof msg.flip === 'boolean') ws.lobbyFlip = msg.flip;
        if (typeof msg.anim === 'string') ws.lobbyAnim = msg.anim.slice(0, 12);
        pushLobbyPeers(ws.lobbyCode);
        break;
      }
      case 'lobby.ready': {
        if (!ws.lobbyCode) return;
        ws.lobbyReady = !!msg.ready;
        pushLobbyPeers(ws.lobbyCode);
        break;
      }
      case 'lobby.chat': {
        if (!ws.lobbyCode) return;
        const text = String(msg.message || '').trim().slice(0, 300);
        if (!text) return;
        const c = rpgDb.getCharacter(ws.userId);
        broadcastLobby(ws.lobbyCode, { t: 'lobby.chat', from: ws.userId, name: (c && c.gameName) || ws.username || 'Petualang', message: text });
        break;
      }
      case 'lobby.start': {
        const lob = ws.lobbyCode && lobbies.get(ws.lobbyCode);
        if (!lob || lob.leaderId !== ws.userId) { send(ws, { t: 'lobby.error', message: 'Hanya pemilik lobby yang bisa mulai.' }); return; }
        // Semua anggota harus ready.
        const notReady = [];
        for (const uid of lob.members) {
          const set = sockets.get(uid);
          const memberWs = set ? [...set][0] : null;
          if (uid !== lob.leaderId && !(memberWs && memberWs.lobbyReady)) notReady.push(uid);
        }
        if (notReady.length) { send(ws, { t: 'lobby.error', message: 'Ada anggota yang belum siap.' }); return; }
        const seed = Math.floor(Math.random() * 1e9);
        broadcastLobby(lob.code, { t: 'lobby.start', code: lob.code, seed, leader: lob.leaderId });
        break;
      }
      // ---------------- PARTY RAID (relay host-authoritative) ----------------
      case 'party.action': {
        // Teruskan aksi anggota ke host (pembuat state).
        const lob = ws.lobbyCode && lobbies.get(ws.lobbyCode);
        if (!lob) return;
        sendToUser(lob.leaderId, { t: 'party.action', from: ws.userId, action: msg.action, arg: msg.arg || null });
        break;
      }
      case 'party.state': {
        const lob = ws.lobbyCode && lobbies.get(ws.lobbyCode);
        if (!lob || lob.leaderId !== ws.userId) return;
        broadcastLobby(lob.code, { t: 'party.state', state: msg.state }, null);
        // Hitung counter party raid sekali per raid start.
        if (msg.raidEnd) {
          for (const uid of lob.members) rpgDb.incCharacter(uid, 'partyRaids', 1);
        }
        break;
      }
      default: break;
    }
  }

  // Heartbeat: bersihkan koneksi mati tiap 30 detik.
  const interval = setInterval(() => {
    for (const ws of wss.clients) {
      if (!ws.isAlive) { try { ws.terminate(); } catch (_) {} continue; }
      ws.isAlive = false;
      try { ws.ping(); } catch (_) {}
    }
  }, 30 * 1000);
  if (interval.unref) interval.unref(); // tidak menahan proses keluar saat natural exit
  wss.on('close', () => clearInterval(interval));

  return wss;
}

module.exports = { attachRealtime };
