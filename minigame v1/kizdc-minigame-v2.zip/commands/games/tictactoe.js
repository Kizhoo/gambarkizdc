const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, EmbedBuilder } = require('discord.js');
const { errorEmbed } = require('../../utils/embeds');
const config = require('../../config.json');
const { pickTimeControl, collectorOptionsFor } = require('../../utils/gameTimeControl');
const { pickDifficulty } = require('../../utils/gameDifficulty');
const { t, guildLang } = require('../../utils/i18n');

const WIN_LINES = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8],
  [0, 3, 6], [1, 4, 7], [2, 5, 8],
  [0, 4, 8], [2, 4, 6],
];

function winnerOf(board) {
  for (const [a, b, c] of WIN_LINES) {
    if (board[a] && board[a] === board[b] && board[a] === board[c]) return board[a];
  }
  return board.every(cell => cell) ? 'draw' : null;
}

// Minimax sempurna (ruang state cuma 9 sel, murah dihitung, <1ms) - AI TIDAK PERNAH kalah,
// paling banter seri kalau lawannya main optimal juga. Sengaja bukan heuristik win/block/center
// biasa (sudah dites: itu masih bisa kalah ~1% lawan gerakan acak karena miss kasus fork ganda).
function winnerScore(board, aiSymbol, humanSymbol, depth) {
  const w = winnerOf(board);
  if (w === aiSymbol) return 10 - depth;
  if (w === humanSymbol) return depth - 10;
  if (w === 'draw') return 0;
  return null;
}
function minimax(board, aiSymbol, humanSymbol, isAiTurn, depth) {
  const terminal = winnerScore(board, aiSymbol, humanSymbol, depth);
  if (terminal !== null) return { score: terminal };
  const empty = board.map((v, i) => (v ? null : i)).filter(v => v !== null);
  let best = null;
  for (const i of empty) {
    const b = [...board]; b[i] = isAiTurn ? aiSymbol : humanSymbol;
    const res = minimax(b, aiSymbol, humanSymbol, !isAiTurn, depth + 1);
    if (best === null || (isAiTurn ? res.score > best.score : res.score < best.score)) best = { score: res.score, move: i };
  }
  return best;
}
function pickAiMove(board, aiSymbol, humanSymbol) {
  if (board.every(c => !c)) return 4; // papan kosong: buka tengah (optimal, hemat komputasi)
  return minimax(board, aiSymbol, humanSymbol, true, 0).move;
}

// Difficulty: minimax di atas sudah SEMPURNA (itu jadi basis "extreme"/tidak pernah kalah).
// Buat tingkat di bawahnya, kita simulasikan AI yang "kurang jago" lewat blunder rate - peluang
// dia malah ambil gerakan ACAK dari semua kotak kosong alih-alih gerakan optimal minimax.
const BLUNDER_RATE = { easy: 0.85, medium: 0.5, hard: 0.15, extreme: 0 };
function pickAiMoveWithDifficulty(board, aiSymbol, humanSymbol, difficulty = 'hard') {
  const rate = BLUNDER_RATE[difficulty] ?? BLUNDER_RATE.hard;
  if (rate > 0 && Math.random() < rate) {
    const empty = board.map((v, i) => (v ? null : i)).filter(v => v !== null);
    return empty[Math.floor(Math.random() * empty.length)];
  }
  return pickAiMove(board, aiSymbol, humanSymbol);
}

module.exports = {
  subcommandOf: 'games',
  data: new SlashCommandBuilder()
    .setName('tictactoe')
    .setDescription('Main Tic-Tac-Toe (X/O) — lawan member lain atau lawan AI')
    .addUserOption(o => o.setName('lawan').setDescription('Member yang mau diajak main (kosongkan buat lawan AI)')),

  async execute(interaction) {
    const lang = guildLang(interaction);
    const opponent = interaction.options.getUser('lawan');
    const vsAi = !opponent;

    if (!vsAi) {
      if (opponent.bot) return interaction.reply({ embeds: [errorEmbed(t(lang, 'game.cant_bot'))], ephemeral: true });
      if (opponent.id === interaction.user.id) return interaction.reply({ embeds: [errorEmbed(t(lang, 'game.cant_self'))], ephemeral: true });
    }

    // ----- Pilih batas waktu per giliran dulu (20d/30d/1-10m/tanpa batas) -----
    const timeControl = await pickTimeControl(interaction, { gameTitle: 'Tic-Tac-Toe', prefix: 'ttt', vsAi, opponentTag: vsAi ? null : `${opponent}` });
    if (timeControl.componentInteraction) await timeControl.componentInteraction.deferUpdate().catch(() => {});
    let challengeMsg = timeControl.message;

    // ----- Vs AI: pilih difficulty lawan (easy/medium/hard/extreme) -----
    let difficulty = { key: 'hard', label: 'Hard' };
    if (vsAi) {
      difficulty = await pickDifficulty(challengeMsg, interaction.user.id, { gameTitle: 'Tic-Tac-Toe', prefix: 'ttt' });
      if (difficulty.componentInteraction) await difficulty.componentInteraction.deferUpdate().catch(() => {});
      challengeMsg = difficulty.message;
    }

    if (!vsAi) {
      // ----- Konfirmasi lawan dulu sebelum papan dimulai (PvP saja, AI tidak perlu konfirmasi) -----
      const challengeRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('ttt_accept').setLabel(t(lang, 'game.accept')).setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('ttt_decline').setLabel(t(lang, 'game.decline')).setStyle(ButtonStyle.Danger),
      );
      challengeMsg = await challengeMsg.edit({
        embeds: [new EmbedBuilder().setColor(config.embedColor).setTitle(t(lang, 'ttt.title'))
          .setDescription(t(lang, 'game.challenge', { p: `${interaction.user}`, o: `${opponent}`, game: 'Tic-Tac-Toe', tc: timeControl.label }))],
        components: [challengeRow],
      });
      const decision = await challengeMsg.awaitMessageComponent({ componentType: ComponentType.Button, time: 60000 }).catch(() => null);
      if (!decision || decision.customId === 'ttt_decline') {
        const text = !decision ? t(lang, 'game.challenge_timeout') : t(lang, 'game.challenge_declined', { o: `${opponent}` });
        return challengeMsg.edit({ embeds: [errorEmbed(text)], components: [] }).catch(() => {});
      }
      if (decision.user.id !== opponent.id) {
        return decision.reply({ content: t(lang, 'game.only_challenged'), ephemeral: true });
      }
      await decision.deferUpdate();
    }

    const AI_PLAYER = { id: 'AI', username: 'AI', toString: () => '🤖 AI' };
    const players = { X: interaction.user, O: vsAi ? AI_PLAYER : opponent };
    const board = Array(9).fill(null);
    let turn = 'X';
    let finished = false;

    const buildButtons = () => {
      const rows = [];
      for (let r = 0; r < 3; r++) {
        const row = new ActionRowBuilder();
        for (let c = 0; c < 3; c++) {
          const i = r * 3 + c;
          const cell = board[i];
          row.addComponents(
            new ButtonBuilder()
              .setCustomId(`ttt_${i}`)
              .setLabel(cell || '\u200b')
              .setStyle(cell === 'X' ? ButtonStyle.Danger : cell === 'O' ? ButtonStyle.Primary : ButtonStyle.Secondary)
              .setDisabled(!!cell || finished)
          );
        }
        rows.push(row);
      }
      return rows;
    };

    const buildEmbed = (statusText) => new EmbedBuilder()
      .setColor(config.embedColor)
      .setTitle('Tic-Tac-Toe' + (vsAi ? ' (vs AI)' : ''))
      .setFooter({ text: t(lang, 'game.time_per_turn', { t: timeControl.label }) + (vsAi ? ` • ${t(lang, 'game.difficulty', { d: difficulty.label })}` : '') })
      .setDescription(`${players.X} (X) vs ${players.O} (O)\n\n${statusText}`);

    const initialPayload = { embeds: [buildEmbed(t(lang, 'game.your_turn', { p: `${players[turn]} (${turn})` }))], components: buildButtons() };
    const message = await challengeMsg.edit(initialPayload);

    const collector = message.createMessageComponentCollector(collectorOptionsFor(timeControl.ms));

    // Terapkan satu langkah (index sudah divalidasi kosong), cek menang, ganti giliran. Return
    // payload buat di-render - dipakai baik buat langkah manusia maupun langkah AI.
    const applyMove = (index) => {
      board[index] = turn;
      const winner = winnerOf(board);
      if (winner) {
        finished = true;
        collector.stop();
        const resultText = winner === 'draw' ? t(lang, 'game.draw') : t(lang, 'game.win', { p: `${players[winner]} (${winner})` });
        return { embeds: [buildEmbed(resultText)], components: buildButtons() };
      }
      turn = turn === 'X' ? 'O' : 'X';
      return { embeds: [buildEmbed(t(lang, 'game.your_turn', { p: `${players[turn]} (${turn})` }))], components: buildButtons() };
    };

    collector.on('collect', async i => {
      const currentPlayer = players[turn];
      if (vsAi && turn === 'O') return i.reply({ content: t(lang, 'game.ai_turn'), ephemeral: true });
      if (i.user.id !== currentPlayer.id) {
        return i.reply({ content: t(lang, 'game.not_your_turn'), ephemeral: true });
      }

      const index = parseInt(i.customId.split('_')[1]);
      if (board[index]) return i.reply({ content: t(lang, 'game.cell_taken'), ephemeral: true });

      const payload = applyMove(index);
      await i.update(payload);

      // Giliran AI langsung jalan (delay dikit biar kerasa "mikir", bukan instan aneh).
      if (vsAi && !finished && turn === 'O') {
        setTimeout(async () => {
          if (finished) return;
          const aiIndex = pickAiMoveWithDifficulty(board, 'O', 'X', difficulty.key);
          const aiPayload = applyMove(aiIndex);
          await message.edit(aiPayload).catch(() => {});
        }, 650);
      }
    });

    collector.on('end', (collected, reason) => {
      if (!finished && (reason === 'time' || reason === 'idle')) {
        message.edit({ embeds: [buildEmbed(t(lang, 'game.timeout', { p: `${players[turn]}` }))], components: [] }).catch(() => {});
      }
    });
  },
};
