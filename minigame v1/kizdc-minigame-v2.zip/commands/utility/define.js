const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { safeDefer } = require('../../utils/interactionHelpers');
const { fetchExternal } = require('../../utils/httpClient');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  subcommandOf: true,
  data: new SlashCommandBuilder()
    .setName('define')
    .setDescription('Cari arti kata dalam Bahasa Inggris')
    .addStringOption(o => o.setName('kata').setDescription('Kata yang ingin dicari artinya').setRequired(true)),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const word = interaction.options.getString('kata');
    if (!(await safeDefer(interaction))) return;

    try {
      const res = await fetchExternal(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word)}`);
      if (!res.ok) {
        return interaction.editReply({ embeds: [errorEmbed(t(lang, 'define.not_found', { w: word }))] });
      }
      const data = await res.json();
      const entry = data[0];

      const embed = baseEmbed().setTitle(entry.word);
      if (entry.phonetic) embed.setDescription(`*${entry.phonetic}*`);

      for (const meaning of entry.meanings.slice(0, 3)) {
        const defs = meaning.definitions.slice(0, 2).map((d, i) => `${i + 1}. ${d.definition}`).join('\n');
        embed.addFields({ name: meaning.partOfSpeech, value: defs });
      }

      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      console.error('[define] Gagal ambil arti kata:', err.message);
      return interaction.editReply({ embeds: [errorEmbed(t(lang, 'define.fail'))] }).catch(() => {});
    }
  },
};
