// Cache in-memory sederhana untuk fitur snipe. Tidak perlu persistent karena
// snipe secara konvensi cuma nyimpen 1 pesan terakhir per channel dan hilang saat bot restart.
const deletedCache = new Map(); // channelId -> { content, author, timestamp, attachments }
const editedCache = new Map(); // channelId -> { oldContent, newContent, author, timestamp }

function cacheDeleted(channelId, data) {
  deletedCache.set(channelId, data);
}

function getDeleted(channelId) {
  return deletedCache.get(channelId);
}

function cacheEdited(channelId, data) {
  editedCache.set(channelId, data);
}

function getEdited(channelId) {
  return editedCache.get(channelId);
}

module.exports = { cacheDeleted, getDeleted, cacheEdited, getEdited };
