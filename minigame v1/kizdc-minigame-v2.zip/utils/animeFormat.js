const { baseEmbed } = require('./embeds');

const SEASON_LABEL_ID = { WINTER: 'Winter', SPRING: 'Spring', SUMMER: 'Summer', FALL: 'Fall' };
const STATUS_LABEL_ID = {
  RELEASING: 'Sedang Tayang',
  FINISHED: 'Tamat',
  NOT_YET_RELEASED: 'Belum Rilis',
  CANCELLED: 'Dibatalkan',
  HIATUS: 'Hiatus',
};

function streamingLinksText(links) {
  if (!links || !links.length) return null;
  return links.map(l => `[${l.site}](${l.url})`).join(' • ');
}

// Format ringkas satu baris per anime - dipakai di embed yang isinya banyak anime sekaligus
// (jadwal hari ini, daftar musim ini), jadi harus tetap kompak walau infonya lebih lengkap.
function animeLine(a) {
  const parts = [`**[${a.title}](${a.url})**`];
  if (a.episodes) parts.push(`${a.episodes} eps`);
  if (a.score) parts.push(`⭐ ${a.score}`);
  const meta = parts.length > 1 ? ` — ${parts.slice(1).join(' • ')}` : '';
  const genreLine = a.genres.length ? `\n${a.genres.slice(0, 3).join(', ')}` : '';
  const broadcastLine = a.broadcast ? `\n📅 ${a.broadcast}` : '';
  const streamText = streamingLinksText(a.streamingLinks);
  const streamLine = streamText ? `\n▸ Tonton di ${streamText}` : '';
  return `${parts[0]}${meta}${genreLine}${broadcastLine}${streamLine}`;
}

function todayScheduleEmbed({ anime }, { maxItems = 10 } = {}) {
  const embed = baseEmbed().setTitle('📺 Episode Tayang 24 Jam ke Depan');
  if (!anime.length) {
    embed.setDescription('Tidak ada episode terjadwal tayang dalam 24 jam ke depan menurut data AniList.');
    return embed;
  }
  const shown = anime.slice(0, maxItems);
  embed.setDescription(shown.map(animeLine).join('\n\n'));
  if (shown[0]?.image) embed.setThumbnail(shown[0].image);
  const overflowNote = anime.length > maxItems ? `Menampilkan ${maxItems} dari ${anime.length} episode • ` : '';
  embed.setFooter({ text: `${overflowNote}Waktu ditampilkan dalam WIB • Data: AniList` });
  return embed;
}

function seasonEmbed({ season, seasonYear, anime, hasNextPage }, { maxItems = 10, page = 1 } = {}) {
  const seasonLabel = season ? `${SEASON_LABEL_ID[season] || season} ${seasonYear}` : '';
  const embed = baseEmbed().setTitle(`🗓️ Anime Musim Ini${seasonLabel ? ` (${seasonLabel})` : ''}${page > 1 ? ` — Halaman ${page}` : ''}`);
  if (!anime.length) {
    embed.setDescription('Belum ada data anime musim ini dari AniList.');
    return embed;
  }
  const shown = anime.slice(0, maxItems);
  embed.setDescription(shown.map(animeLine).join('\n\n'));
  if (shown[0]?.image) embed.setThumbnail(shown[0].image);
  embed.setFooter({ text: `${hasNextPage ? 'Masih ada halaman berikutnya • ' : ''}Data: AniList` });
  return embed;
}

function searchResultEmbed(query, results) {
  if (!results.length) {
    return baseEmbed().setTitle(`Hasil pencarian: ${query}`).setDescription('Tidak ketemu anime dengan judul itu di AniList.');
  }
  const top = results[0];
  const embed = baseEmbed()
    .setTitle(top.title)
    .setURL(top.url)
    .setDescription(top.synopsis ? (top.synopsis.length > 500 ? `${top.synopsis.slice(0, 500)}...` : top.synopsis) : 'Sinopsis tidak tersedia.')
    .addFields(
      { name: 'Episode', value: String(top.episodes ?? '?'), inline: true },
      { name: 'Skor', value: top.score ? `⭐ ${top.score}/10` : '-', inline: true },
      { name: 'Status', value: STATUS_LABEL_ID[top.status] || top.status || '-', inline: true },
    );
  if (top.genres.length) embed.addFields({ name: 'Genre', value: top.genres.join(', '), inline: false });
  const streamText = streamingLinksText(top.streamingLinks);
  if (streamText) embed.addFields({ name: '🎬 Tonton di', value: streamText, inline: false });
  if (top.color) embed.setColor(top.color);
  if (top.image) embed.setThumbnail(top.image);
  if (top.bannerImage) embed.setImage(top.bannerImage);
  if (results.length > 1) {
    embed.addFields({ name: 'Hasil lain', value: results.slice(1, 5).map(r => `[${r.title}](${r.url})`).join('\n') });
  }
  embed.setFooter({ text: 'Data: AniList' });
  return embed;
}

// Kartu penuh buat SATU anime - dipakai buat notifikasi auto-alert episode baru. Ini yang
// paling sering dilihat user jadi dibikin selengkap & serapi mungkin: banner besar, skor,
// genre, status, dan link nonton resmi (kalau ada datanya di AniList).
function animeEpisodeAlertEmbed(item) {
  const isPremiere = item.episode === 1;
  const embed = baseEmbed()
    .setAuthor({ name: isPremiere ? '✨ Anime Baru Mulai Tayang' : '🔔 Episode Baru Tayang' })
    .setTitle(item.title)
    .setURL(item.url);

  if (item.broadcast) embed.setDescription(`📅 ${item.broadcast}`);
  if (item.color) embed.setColor(item.color);
  if (item.image) embed.setThumbnail(item.image);
  if (item.bannerImage) embed.setImage(item.bannerImage);

  const fields = [];
  if (item.episodes) fields.push({ name: 'Total Episode', value: String(item.episodes), inline: true });
  if (item.score) fields.push({ name: 'Skor', value: `⭐ ${item.score}/10`, inline: true });
  if (item.status) fields.push({ name: 'Status', value: STATUS_LABEL_ID[item.status] || item.status, inline: true });
  if (item.genres.length) fields.push({ name: 'Genre', value: item.genres.slice(0, 5).join(', '), inline: false });
  const streamText = streamingLinksText(item.streamingLinks);
  if (streamText) {
    // PENTING: link ini menuju HALAMAN SERIAL di platform (bukan halaman episode ini).
    // Episode yang baru tayang sering belum langsung tersedia karena jeda lisensi/rilis
    // regional (kadang beberapa jam sampai beberapa hari). Kasih catatan jujur biar user
    // tidak bingung kenapa episode terbaru belum ada di sana.
    fields.push({ name: '🎬 Tonton di', value: streamText, inline: false });
    fields.push({
      name: '⏳ Soal ketersediaan episode',
      value: isPremiere
        ? 'Link menuju halaman serial resmi. Episode perdana bisa butuh beberapa saat untuk muncul karena jeda rilis regional.'
        : 'Link menuju halaman serial resmi — **episode terbaru mungkin belum langsung tersedia** di platform ini karena jeda lisensi/rilis per wilayah. Kalau belum ada, coba lagi beberapa jam kemudian.',
      inline: false,
    });
  } else {
    fields.push({ name: '🎬 Tonton di', value: 'Belum ada link streaming resmi terdaftar di AniList untuk judul ini.', inline: false });
  }
  embed.addFields(fields);

  embed.setFooter({ text: 'Waktu tayang = jadwal siaran negara asal • Data: AniList' });
  return embed;
}

module.exports = { todayScheduleEmbed, seasonEmbed, searchResultEmbed, animeEpisodeAlertEmbed };
