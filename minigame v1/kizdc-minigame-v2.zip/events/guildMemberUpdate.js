const { AuditLogEvent } = require('discord.js');
const { sendLog } = require('../utils/serverLog');
const settings = require('../config.json');

module.exports = {
  name: 'guildMemberUpdate',
  async execute(oldMember, newMember) {
    const guild = newMember.guild;

    // Perubahan nickname
    if (oldMember.nickname !== newMember.nickname) {
      sendLog(guild, {
        title: 'Nickname Diubah',
        color: settings.warnColor,
        author: { name: newMember.user.tag, iconURL: newMember.user.displayAvatarURL() },
        fields: [
          { name: 'Sebelum', value: oldMember.nickname || '*(tidak ada)*', inline: true },
          { name: 'Sesudah', value: newMember.nickname || '*(tidak ada)*', inline: true },
        ],
        footer: `User ID: ${newMember.id}`,
      });
    }

    // Perubahan timeout
    const oldTo = oldMember.communicationDisabledUntilTimestamp;
    const newTo = newMember.communicationDisabledUntilTimestamp;
    if (oldTo !== newTo) {
      if (newTo && newTo > Date.now()) {
        sendLog(guild, {
          title: 'Member Di-timeout',
          color: settings.errorColor,
          author: { name: newMember.user.tag, iconURL: newMember.user.displayAvatarURL() },
          fields: [{ name: 'Sampai', value: `<t:${Math.floor(newTo / 1000)}:F>` }],
          footer: `User ID: ${newMember.id}`,
        });
      } else {
        sendLog(guild, {
          title: 'Timeout Member Dicabut',
          color: settings.successColor,
          author: { name: newMember.user.tag, iconURL: newMember.user.displayAvatarURL() },
          footer: `User ID: ${newMember.id}`,
        });
      }
    }

    // Perubahan role
    const oldRoles = new Set(oldMember.roles.cache.keys());
    const newRoles = new Set(newMember.roles.cache.keys());
    const added = [...newRoles].filter(r => !oldRoles.has(r));
    const removed = [...oldRoles].filter(r => !newRoles.has(r));
    if (added.length || removed.length) {
      const fields = [];
      if (added.length) fields.push({ name: 'Role ditambah', value: added.map(r => `<@&${r}>`).join(', ').slice(0, 1024) });
      if (removed.length) fields.push({ name: 'Role dicabut', value: removed.map(r => `<@&${r}>`).join(', ').slice(0, 1024) });
      sendLog(guild, {
        title: 'Role Member Diubah',
        color: settings.embedColor,
        author: { name: newMember.user.tag, iconURL: newMember.user.displayAvatarURL() },
        fields,
        footer: `User ID: ${newMember.id}`,
      });
    }
  },
};
