// ============================================================================
// /minigame — HUB MINIGAME KIZHOOBOT (KizDefense + game berikutnya)
// ----------------------------------------------------------------------------
// Kartu pengumuman + tombol langsung ke hub minigame di browser. KizDefense
// (merge turret defense) adalah game pertama di hub; game baru tinggal
// ditambahkan ke halaman /minigame.
// Tombol-tombol era-RPG lama di pesan lama di-handle di interactionCreate.js
// dengan arahan ke hub ini juga.
// ============================================================================
const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { baseEmbed } = require('../../utils/embeds');
const { dashboardUrl } = require('../../utils/botIntro');

function hubUrl() {
  return `${dashboardUrl().replace(/\/+$/, '')}/minigame`;
}
function gameUrl() {
  return `${dashboardUrl().replace(/\/+$/, '')}/kizdefense`;
}

function hubCard() {
  return baseEmbed()
    .setTitle('Minigame — Hub Game KizhooBot')
    .setDescription(
      'Pusat game web KizhooBot. Game pertama: **KizDefense** — merge turret defense dengan hadiah **Kizco asli**. Game berikutnya menyusul di hub yang sama.'
    )
    .addFields(
      { name: 'KizDefense: Gabung Menara', value: 'Beli menara, gabungkan dua yang setingkat jadi tier lebih tinggi (T1 sampai T20), susun barisan bunker, dan tahan gelombang monster.', inline: false },
      { name: 'Gelombang & Bab', value: '10 gelombang per bab dengan bos di gelombang 5 dan 10. Tema medan berganti tiap bab: salju, gurun, angkasa, lava.', inline: false },
      { name: 'Seru & Cepat', value: 'Mode amuk (fever), kombo gabung, bonus menara gratis, auto-merge, kecepatan 2x, dan peti hadiah tiap selesai bab.', inline: false },
      { name: 'Idle & Hadiah', value: 'Penghasilan offline maks 8 jam, papan peringkat, dan klaim Kizco (25 per gelombang, minimal 10 gelombang).', inline: false },
    )
    .setFooter({ text: 'Login pakai akun Discord-mu. Bisa dimainkan di HP maupun PC.' });
}

function playRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setLabel('Hub Minigame')
      .setStyle(ButtonStyle.Link)
      .setURL(hubUrl()),
    new ButtonBuilder()
      .setLabel('Langsung KizDefense')
      .setStyle(ButtonStyle.Link)
      .setURL(gameUrl()),
  );
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('minigame')
    .setDescription('Buka hub minigame — mainkan KizDefense (merge turret defense) dengan hadiah Kizco'),
  cooldown: 2,

  async execute(interaction) {
    return interaction.reply({ embeds: [hubCard()], components: [playRow()] });
  },

  // Tombol minigame lama pada pesan (mg:*) — arahkan kembali ke web.
  async handleButton(interaction) {
    const embed = baseEmbed()
      .setTitle('Minigame — KizDefense')
      .setDescription('Buka hub minigame lewat tombol di bawah — progresmu tersimpan otomatis.');
    return interaction.reply({ embeds: [embed], components: [playRow()], ephemeral: true });
  },
};
