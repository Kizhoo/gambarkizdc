// ============================================================================
// MATA UANG — tembaga/perak/gold
// ----------------------------------------------------------------------------
// 1 gold = 100 perak = 10.000 tembaga. Nilai yang DISIMPAN di database TETAP
// satu angka gold-equivalent seperti sebelumnya (tidak ada migrasi skala unit,
// nol risiko ke harga/reward yang sudah ada) - modul ini CUMA lapisan tampilan:
// pecah satu angka jadi kombinasi koin gold/perak/tembaga yang enak dilihat.
// ============================================================================
const SILVER_PER_GOLD = 100;
const COPPER_PER_SILVER = 100;
const COPPER_PER_GOLD = SILVER_PER_GOLD * COPPER_PER_SILVER; // 10.000

// amountGold: boleh desimal (mis. hasil bagi) - dibulatkan ke tembaga terdekat sebelum dipecah.
function breakdown(amountGold) {
  const totalCopper = Math.round(amountGold * COPPER_PER_GOLD);
  const gold = Math.floor(totalCopper / COPPER_PER_GOLD);
  const silver = Math.floor((totalCopper % COPPER_PER_GOLD) / COPPER_PER_SILVER);
  const copper = totalCopper % COPPER_PER_SILVER;
  return { gold, silver, copper, totalCopper };
}

// Format ringkas buat teks embed, mis. "12g 34p 5t" - skip bagian yang 0 kecuali semuanya 0.
function formatShort(amountGold) {
  const { gold, silver, copper } = breakdown(amountGold);
  const parts = [];
  if (gold) parts.push(`${gold.toLocaleString('id-ID')}g`);
  if (silver) parts.push(`${silver}p`);
  if (copper || !parts.length) parts.push(`${copper}t`);
  return parts.join(' ');
}

module.exports = { SILVER_PER_GOLD, COPPER_PER_SILVER, COPPER_PER_GOLD, breakdown, formatShort };
