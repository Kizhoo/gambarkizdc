const { SlashCommandBuilder } = require('discord.js');
const { getShopItems } = require('../../database/db');
const { baseEmbed } = require('../../utils/embeds');
const kizco = require('../../utils/kizco');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder().setName('shop').setDescription('Lihat daftar item di toko server'),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const items = getShopItems(interaction.guild.id);

    if (items.length === 0) {
      return interaction.reply({ embeds: [baseEmbed().setDescription(t(lang, 'shop.empty'))] });
    }

    const description = items.map(item =>
      `**${item.name}** — ${kizco.format(item.price)}\nID: \`${item.itemId}\`${item.description ? `\n${item.description}` : ''}`
    ).join('\n\n');

    return interaction.reply({ embeds: [baseEmbed().setTitle(t(lang, 'shop.title')).setDescription(description)] });
  },
};
