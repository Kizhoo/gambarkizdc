const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('8ball')
    .setDescription('Tanya bola ajaib 8ball')
    .addStringOption(o => o.setName('pertanyaan').setDescription('Pertanyaan kamu').setRequired(true)),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const question = interaction.options.getString('pertanyaan');
    const answer = t(lang, '8ball.a' + (Math.floor(Math.random() * 11) + 1));
    const embed = baseEmbed()
      .setTitle('Magic 8-Ball')
      .addFields(
        { name: t(lang, 'fun.question'), value: question },
        { name: t(lang, 'fun.answer'), value: answer },
      );
    return interaction.reply({ embeds: [embed] });
  },
};
