// ============================================================================
// PRICE ALERT — notifikasi saat harga item melewati ambang yang ditentukan.
// ----------------------------------------------------------------------------
// Dipanggil dari mesin matching (orderbook) setiap ada transaksi. Alert aktif
// yang terpicu akan dinonaktifkan lalu dikirim ke pemiliknya lewat:
//   1) WebSocket (dashboard/trading web) — push 'alert'
//   2) DM Discord (kalau client tersedia & user bisa di-fetch)
// ============================================================================
const econ = require('../database/economyDb');
const kizco = require('./kizco');

let client = null;
function setClient(c) { client = c; }

async function checkAndNotify(guildId, itemId, price) {
  const active = econ.listActiveAlerts(guildId, itemId);
  if (!active.length) return [];
  const triggered = [];
  for (const a of active) {
    const hit = (a.direction === 'above' && price >= a.price) || (a.direction === 'below' && price <= a.price);
    if (hit) { econ.deactivateAlert(a.id); triggered.push(a); }
  }
  for (const a of triggered) {
    if (client && typeof client.broadcastDashboard === 'function') {
      client.broadcastDashboard('alert', { guildId, userId: a.userId, itemId, direction: a.direction, targetPrice: a.price, currentPrice: price });
    }
    if (client) {
      try {
        const u = await client.users.fetch(a.userId).catch(() => null);
        if (u) await u.send(`🔔 **Alert Harga Kizco**\n\`${itemId}\` sekarang **${kizco.format(price)}** (terpicu: ${a.direction} **${kizco.format(a.price)}**).`).catch(() => {});
      } catch {}
    }
  }
  return triggered;
}

module.exports = { setClient, checkAndNotify };
