const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { safeDefer } = require('../../utils/interactionHelpers');
const { fetchExternal } = require('../../utils/httpClient');
const { t, guildLang } = require('../../utils/i18n');

// Banyak sumber dicoba berurutan. Karena IP hosting bisa di-blacklist sebagian
// layanan (403) atau tidak bisa resolve DNS (ENOTFOUND), makin banyak & beragam
// sumber makin besar peluang salah satunya berhasil. Urutan = prioritas.
const SOURCES = [
  { name: 'otakugifs', url: (s) => `https://api.otakugifs.xyz/gif?reaction=${s}`, extract: (d) => d.url },
  { name: 'nekos.life', url: (s) => `https://nekos.life/api/v2/img/${s}`, extract: (d) => d.url },
  { name: 'purrbot', url: (s) => `https://purrbot.site/api/img/sfw/${s}/gif`, extract: (d) => d.link },
  { name: 'nekos.best', url: (s) => `https://nekos.best/api/v2/${s}`, extract: (d) => d.results?.[0]?.url },
  { name: 'waifu.pics', url: (s) => `https://api.waifu.pics/sfw/${s}`, extract: (d) => d.url },
];

// Nama subcommand -> nama reaction di tiap provider (kadang beda).
const REACTION_MAP = {
  hug: { otakugifs: 'hug', 'nekos.life': 'hug', purrbot: 'hug', 'nekos.best': 'hug', 'waifu.pics': 'hug' },
  slap: { otakugifs: 'slap', 'nekos.life': 'slap', purrbot: 'slap', 'nekos.best': 'slap', 'waifu.pics': 'slap' },
  kiss: { otakugifs: 'kiss', 'nekos.life': 'kiss', purrbot: 'kiss', 'nekos.best': 'kiss', 'waifu.pics': 'kiss' },
  pat: { otakugifs: 'pat', 'nekos.life': 'pat', purrbot: 'pat', 'nekos.best': 'pat', 'waifu.pics': 'pat' },
  cuddle: { otakugifs: 'cuddle', 'nekos.life': 'cuddle', purrbot: 'cuddle', 'nekos.best': 'cuddle', 'waifu.pics': 'cuddle' },
};

async function fetchGifWithFallback(sub) {
  let lastError;
  for (const source of SOURCES) {
    const reaction = REACTION_MAP[sub]?.[source.name];
    if (!reaction) continue;
    try {
      const res = await fetchExternal(source.url(reaction));
      if (!res.ok) throw new Error(`${source.name} status ${res.status}`);
      const data = await res.json();
      const gifUrl = source.extract(data);
      if (!gifUrl) throw new Error(`${source.name} tidak mengembalikan URL`);
      return { gifUrl, source: source.name };
    } catch (err) {
      lastError = err;
      console.warn(`[action] ${source.name} gagal (${sub}): ${err.cause?.code || err.message}, coba sumber berikutnya...`);
    }
  }
  throw lastError || new Error('Semua sumber gagal');
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('action')
    .setDescription('Interaksi seru pakai GIF anime')
    .addSubcommand(sub => sub.setName('hug').setDescription('Peluk seseorang')
      .addUserOption(o => o.setName('target').setDescription('Target').setRequired(true)))
    .addSubcommand(sub => sub.setName('slap').setDescription('Tampar seseorang')
      .addUserOption(o => o.setName('target').setDescription('Target').setRequired(true)))
    .addSubcommand(sub => sub.setName('kiss').setDescription('Cium seseorang')
      .addUserOption(o => o.setName('target').setDescription('Target').setRequired(true)))
    .addSubcommand(sub => sub.setName('pat').setDescription('Elus kepala seseorang')
      .addUserOption(o => o.setName('target').setDescription('Target').setRequired(true)))
    .addSubcommand(sub => sub.setName('cuddle').setDescription('Peluk manja seseorang')
      .addUserOption(o => o.setName('target').setDescription('Target').setRequired(true))),

  async execute(interaction) {
    const lang = guildLang(interaction);
    const sub = interaction.options.getSubcommand();
    const target = interaction.options.getUser('target');
    if (!(await safeDefer(interaction))) return;

    const VERB = { hug: t(lang, 'act.hug'), slap: t(lang, 'act.slap'), kiss: t(lang, 'act.kiss'), pat: t(lang, 'act.pat'), cuddle: t(lang, 'act.cuddle') };

    try {
      const { gifUrl, source } = await fetchGifWithFallback(sub);
      const embed = baseEmbed()
        .setDescription(`${interaction.user} ${VERB[sub]} ${target}`)
        .setImage(gifUrl)
        .setFooter({ text: `Powered by ${source}` });
      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      const reason = err.cause?.code || err.message || 'unknown error';
      console.error(`[action] Semua sumber GIF gagal (${sub}): ${reason}`);
      await interaction.editReply({ embeds: [errorEmbed(t(lang, 'act.gif_fail', { err: reason }))] }).catch(() => {});
    }
  },
};
