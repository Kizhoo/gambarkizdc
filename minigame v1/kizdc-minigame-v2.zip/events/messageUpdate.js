const { EmbedBuilder } = require('discord.js');
const { getGuildConfig } = require('../database/db');
const { cacheEdited } = require('../utils/snipeCache');
const config = require('../config.json');

module.exports = {
  name: 'messageUpdate',
  async execute(oldMessage, newMessage) {
    if (!newMessage.guild || !newMessage.author || newMessage.author.bot) return;
    if (oldMessage.content === newMessage.content) return; // hanya embed/reaction update, skip

    cacheEdited(newMessage.channel.id, {
      oldContent: oldMessage.content || '*(kosong)*',
      newContent: newMessage.content || '*(kosong)*',
      author: newMessage.author,
      timestamp: Date.now(),
    });

    const cfg = getGuildConfig(newMessage.guild.id);
    if (cfg.modLogEnabled && cfg.logChannel) {
      const logChannel = newMessage.guild.channels.cache.get(cfg.logChannel);
      if (logChannel) {
        const embed = new EmbedBuilder()
          .setColor(config.warnColor)
          .setAuthor({ name: newMessage.author.tag, iconURL: newMessage.author.displayAvatarURL() })
          .setTitle('Pesan Diedit')
          .addFields(
            { name: 'Sebelum', value: (oldMessage.content || '*(kosong)*').slice(0, 1000) },
            { name: 'Sesudah', value: (newMessage.content || '*(kosong)*').slice(0, 1000) },
            { name: 'Channel', value: `${newMessage.channel}`, inline: true },
          )
          .setFooter({ text: `User ID: ${newMessage.author.id}`})
          .setTimestamp();
        logChannel.send({ embeds: [embed] }).catch(() => {});
      }
    }
  },
};
