const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { homeView } = require('../../utils/panelHandler');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('panel')
    .setDescription('Buka panel manajemen bot (setting/AI/backup/user/server) berbasis tombol')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const view = homeView();
    return interaction.reply({ ...view, ephemeral: true });
  },
};
