// ============================================================================
// KARTU "SEDANG MEMUTAR" — v9 (CANVAS = album art + judul + progress bar)
// ----------------------------------------------------------------------------
// Emoji dikurangi: field/teks pakai kata biasa, emoji hanya untuk kontrol yang
// memang butuh ikon (play/pause/skip/stop) agar gampang dikenali di mobile.
// ============================================================================

const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, AttachmentBuilder } = require('discord.js');
const { createCanvas } = require('@napi-rs/canvas');
const { roundedRect, fitText, clippedText, drawImageCover, drawBlurredCover, downloadImage } = require('./canvasUtils');
const { formatDuration, sourceLabel } = require('./musicFormat');
const emojis = require('./emojis');
const config = require('../config.json');

const LIVE_UPDATE_INTERVAL_MS = 4000; // 4 detik — aman dari rate limit Discord

// === INTERPOLASI POSISI (real-time) ===
function computeDisplayPosition(player, track) {
  if (track.isStream) return 0;
  const raw = Math.max(0, player.position || 0);
  if (player.paused) {
    player.data?.set('positionSample', { raw, display: raw, at: Date.now() });
    return raw;
  }
  const now = Date.now();
  const sample = player.data?.get('positionSample');
  const display = (sample && sample.raw === raw) ? sample.display + (now - sample.at) : raw;
  const clamped = Math.min(track.length || display, Math.max(0, display));
  player.data?.set('positionSample', { raw, display: clamped, at: now });
  return clamped;
}

// === THUMBNAIL CACHE PER PLAYER ===
async function getCachedThumbnail(player, track) {
  const url = track.thumbnail;
  if (!url) return null;
  const cache = player.data?.get('npThumbCache');
  if (cache && cache.url === url) return cache.img;
  try {
    const img = await downloadImage(url);
    player.data?.set('npThumbCache', { url, img });
    return img;
  } catch { return null; }
}

function drawDefaultBackdrop(ctx, w, h, accent) {
  const gradient = ctx.createLinearGradient(0, 0, w, h);
  gradient.addColorStop(0, '#0B0F1A');
  gradient.addColorStop(1, '#151B2C');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, w, h);
  ctx.globalAlpha = 0.15;
  ctx.fillStyle = accent;
  ctx.beginPath(); ctx.arc(w - 60, -20, 200, 0, Math.PI * 2); ctx.fill();
  ctx.globalAlpha = 1;
}

// ============================================================================
// CANVAS KARTU PLAYER (album art + judul + progress bar) — horizontal
// ============================================================================
const CARD_W = 960;
const CARD_H = 220;
const ART_X = 26;
const ART_Y = 26;
const ART_SIZE = 168;
const CONTENT_X = ART_X + ART_SIZE + 26;
const CONTENT_W = CARD_W - CONTENT_X - 26;
const PROGRESS_Y = CARD_H - 26 - 34;
const PROGRESS_H = 12;

async function renderNowPlayingCanvas(player, track) {
  const paused = !!player.paused;
  const isLive = !!track.isStream;
  const accent = isLive ? '#ED4245' : (paused ? '#F5C244' : config.successColor || '#57F287');

  const canvas = createCanvas(CARD_W, CARD_H);
  const ctx = canvas.getContext('2d');
  const thumb = await getCachedThumbnail(player, track);

  if (thumb) {
    drawBlurredCover(ctx, thumb, 0, 0, CARD_W, CARD_H, 26);
    const overlay = ctx.createLinearGradient(CARD_W, 0, 0, 0);
    overlay.addColorStop(0, 'rgba(6,9,16,0.9)');
    overlay.addColorStop(0.45, 'rgba(6,9,16,0.78)');
    overlay.addColorStop(1, 'rgba(6,9,16,0.55)');
    ctx.fillStyle = overlay;
    ctx.fillRect(0, 0, CARD_W, CARD_H);
  } else {
    drawDefaultBackdrop(ctx, CARD_W, CARD_H, accent);
  }

  ctx.fillStyle = accent;
  roundedRect(ctx, 0, 0, 6, CARD_H, 3);
  ctx.fill();

  // album art
  if (thumb) {
    ctx.save();
    roundedRect(ctx, ART_X, ART_Y, ART_SIZE, ART_SIZE, 16);
    ctx.clip();
    drawImageCover(ctx, thumb, ART_X, ART_Y, ART_SIZE, ART_SIZE);
    ctx.restore();
  } else {
    ctx.fillStyle = '#1E293B';
    roundedRect(ctx, ART_X, ART_Y, ART_SIZE, ART_SIZE, 16); ctx.fill();
    ctx.fillStyle = accent;
    ctx.font = '700 60px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('♪', ART_X + ART_SIZE / 2, ART_Y + ART_SIZE / 2 + 20);
    ctx.textAlign = 'left';
  }
  ctx.strokeStyle = 'rgba(255,255,255,0.22)';
  ctx.lineWidth = 2;
  roundedRect(ctx, ART_X, ART_Y, ART_SIZE, ART_SIZE, 16);
  ctx.stroke();

  // kicker status
  const kicker = isLive ? 'SIARAN LANGSUNG' : (paused ? 'DIJEDA' : 'SEDANG MEMUTAR');
  ctx.font = '800 19px sans-serif';
  ctx.fillStyle = accent;
  ctx.fillText(kicker, CONTENT_X, 66);

  // judul
  const title = track.title || 'Tidak diketahui';
  const titleSize = fitText(ctx, title, CONTENT_W, 32, 800, 18);
  ctx.font = `800 ${titleSize}px sans-serif`;
  ctx.fillStyle = '#F8FAFC';
  ctx.fillText(clippedText(ctx, title, CONTENT_W), CONTENT_X, 102);

  // artist
  ctx.font = '500 19px sans-serif';
  ctx.fillStyle = '#CBD5E1';
  ctx.fillText(clippedText(ctx, `Oleh: ${track.author || 'Tidak diketahui'}`, CONTENT_W), CONTENT_X, 130);

  // progress bar
  const barX = CONTENT_X;
  const barW = CONTENT_W;
  const barY = PROGRESS_Y;

  if (isLive) {
    roundedRect(ctx, barX, barY, barW, PROGRESS_H, PROGRESS_H / 2);
    ctx.fillStyle = 'rgba(237,66,69,0.25)';
    ctx.fill();
    ctx.strokeStyle = '#ED4245';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.fillStyle = '#F8FAFC';
    ctx.font = '700 18px sans-serif';
    ctx.fillText('LIVE — durasi tidak terbatas', barX, barY + PROGRESS_H + 30);
  } else {
    const position = computeDisplayPosition(player, track);
    const progress = track.length > 0 ? Math.min(1, Math.max(0, position / track.length)) : 0;

    roundedRect(ctx, barX, barY, barW, PROGRESS_H, PROGRESS_H / 2);
    ctx.fillStyle = 'rgba(255,255,255,0.14)';
    ctx.fill();

    const fillW = Math.max(PROGRESS_H, barW * progress);
    ctx.save();
    ctx.shadowColor = accent;
    ctx.shadowBlur = 8;
    const grad = ctx.createLinearGradient(barX, 0, barX + barW, 0);
    grad.addColorStop(0, accent);
    grad.addColorStop(1, `${accent}CC`);
    roundedRect(ctx, barX, barY, fillW, PROGRESS_H, PROGRESS_H / 2);
    ctx.fillStyle = grad;
    ctx.fill();
    ctx.restore();

    const knobX = barX + Math.min(barW - PROGRESS_H / 2, Math.max(PROGRESS_H / 2, barW * progress));
    ctx.beginPath();
    ctx.arc(knobX, barY + PROGRESS_H / 2, PROGRESS_H * 0.85, 0, Math.PI * 2);
    ctx.fillStyle = '#FFFFFF';
    ctx.fill();
    ctx.strokeStyle = accent;
    ctx.lineWidth = 2.5;
    ctx.stroke();

    ctx.fillStyle = '#E2E8F0';
    ctx.font = '600 18px sans-serif';
    ctx.fillText(formatDuration(position), barX, barY + PROGRESS_H + 30);
    ctx.textAlign = 'right';
    ctx.fillText(formatDuration(track.length), barX + barW, barY + PROGRESS_H + 30);
    ctx.textAlign = 'left';
  }

  return canvas.toBuffer('image/png');
}

// ============================================================================
// PAYLOAD: Embed info + Canvas player + Tombol
// ============================================================================
async function buildNowPlayingPayload(player, track) {
  const paused = !!player.paused;
  const isLive = !!track.isStream;
  const accent = isLive ? '#ED4245' : (paused ? '#F5C244' : config.successColor || '#57F287');

  const loopLabels = { none: 'Mati', track: 'Lagu Ini', queue: 'Semua Antrian' };

  const buffer = await renderNowPlayingCanvas(player, track);
  const attachment = new AttachmentBuilder(buffer, { name: 'nowplaying.png' });

  const embed = new EmbedBuilder()
    .setColor(accent)
    .setTitle(isLive ? 'MUSIC — Siaran Langsung' : (paused ? 'MUSIC — Dijeda' : 'MUSIC — Sedang Memutar'))
    .setDescription(`**[${track.title || 'Tidak diketahui'}](${track.uri})**`)
    .setURL(track.uri || null)
    .setImage('attachment://nowplaying.png')
    .addFields(
      { name: emojis.field('artist', 'Artist'), value: track.author || 'Tidak diketahui', inline: true },
      { name: emojis.field('duration', 'Durasi'), value: isLive ? 'Live' : formatDuration(track.length), inline: true },
      { name: emojis.field('source', 'Sumber'), value: sourceLabel(track.sourceName), inline: true },
      { name: emojis.field('requester', 'Request by'), value: `${track.requester?.tag || track.requester || 'Tidak diketahui'}`, inline: true },
      { name: emojis.field('volume', 'Volume'), value: `${player.volume}%`, inline: true },
      { name: emojis.field('loop', 'Loop'), value: loopLabels[player.loop] || 'Mati', inline: true },
    )
    .setFooter({ text: `${emojis.get('queueCount')} ${player.queue.length} lagu di antrian  •  ${config.footer}` })
    .setTimestamp();

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('music_pause').setEmoji(emojis.get(paused ? 'play' : 'pause')).setLabel(paused ? 'Main' : 'Jeda').setStyle(paused ? ButtonStyle.Success : ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('music_skip').setEmoji(emojis.get('skip')).setLabel('Skip').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('music_stop').setEmoji(emojis.get('stop')).setLabel('Stop').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('music_volup').setEmoji(emojis.get('volup')).setLabel('Vol+').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('music_voldown').setEmoji(emojis.get('voldown')).setLabel('Vol-').setStyle(ButtonStyle.Danger),
  );

  const loopEmoji = player.loop === 'track' ? emojis.get('loopOne') : player.loop === 'queue' ? emojis.get('loop') : emojis.get('pause');
  const loopLabel = player.loop === 'track' ? '1 Lagu' : player.loop === 'queue' ? 'Antrian' : 'Mati';
  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('music_loop').setEmoji(loopEmoji).setLabel(`Loop: ${loopLabel}`).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('music_shuffle').setEmoji(emojis.get('shuffle')).setLabel('Acak').setStyle(ButtonStyle.Secondary).setDisabled(player.queue.length < 3),
    new ButtonBuilder().setCustomId('music_queue').setEmoji(emojis.get('queue')).setLabel(`Antrian (${player.queue.length})`).setStyle(ButtonStyle.Secondary),
  );

  return { embeds: [embed], files: [attachment], components: [row1, row2] };
}

// ============================================================================
// AUTO-REFRESH REAL-TIME
// ============================================================================
function startLiveUpdate(player, message, track) {
  stopLiveUpdate(player);
  const interval = setInterval(async () => {
    if (player.destroyed || player.queue.current !== track) { stopLiveUpdate(player); return; }
    try { await message.edit(await buildNowPlayingPayload(player, track)); } catch { stopLiveUpdate(player); }
  }, LIVE_UPDATE_INTERVAL_MS);
  player.data?.set('nowPlayingMessage', message);
  player.data?.set('nowPlayingInterval', interval);
}

function stopLiveUpdate(player) {
  const interval = player.data?.get('nowPlayingInterval');
  if (interval) clearInterval(interval);
  player.data?.delete?.('nowPlayingInterval');
}

function clearIdleTimeout(player) {
  const t = player.data?.get('idleDisconnectTimeout');
  if (t) clearTimeout(t);
  player.data?.delete?.('idleDisconnectTimeout');
}

function getTrackedMessage(player) {
  return player.data?.get('nowPlayingMessage') || null;
}

module.exports = {
  buildNowPlayingPayload,
  renderNowPlayingCanvas,
  computeDisplayPosition,
  startLiveUpdate,
  stopLiveUpdate,
  clearIdleTimeout,
  getTrackedMessage,
  LIVE_UPDATE_INTERVAL_MS,
};
