// Uji end-to-end sistem RPG memakai DB sqlite sementara.
process.env.KIZHOO_DB_PATH = '/tmp/kizhoo_rpg_test.sqlite';
require('fs').rmSync(process.env.KIZHOO_DB_PATH, { force: true });

const rdb = require('../database/rpgDb');
const engine = require('../utils/rpgEngine');
const D = require('../utils/rpgData');
const luna = require('../utils/lunaAgent');

const U = 'user_A', U2 = 'user_B', G = 'guild_1';
let pass = 0, fail = 0;
const ok = (cond, msg) => { if (cond) { pass++; console.log('  ✓', msg); } else { fail++; console.log('  ✗ FAIL:', msg); } };

console.log('1) Buat karakter');
let c = rdb.createCharacter(U, 'warrior');
rdb.updateCharacter(U, { skillPoints: 1 });
ok(c && c.className === 'warrior' && c.rankKey === 'G', 'karakter Warrior rank G dibuat');

console.log('2) Level up via XP');
const before = rdb.getCharacter(U).level;
const res = engine.addExp(U, 5000); // cukup untuk beberapa level
c = rdb.getCharacter(U);
ok(c.level > before, `naik dari Lv${before} ke Lv${c.level}`);
ok(c.skillPoints >= 1 && c.statPoints >= 3, `dapat skill point (${c.skillPoints}) & stat point (${c.statPoints})`);

console.log('3) Alokasi stat');
const statRes = engine.allocateStat(U, 'atk', 2);
ok(statRes.ok && statRes.added === 4, `+${statRes.added} ATK (2 point)`);

console.log('4) Buka skill (prereq & gating)');
const bad = engine.unlockOrUpgradeSkill(U, 'w_berserk'); // butuh level 25 & prereq
ok(!bad.ok, `skill tinggi ditolak: "${bad.error}"`);
const good = engine.unlockOrUpgradeSkill(U, 'w_slash');
ok(good.ok && good.action === 'unlock', `buka Power Slash: ${good.ok}`);
const stats = engine.computeStats(rdb.getCharacter(U));
ok(stats.atk > 0 && stats.hp > 0, `stat efektif dihitung: ATK ${stats.atk}, HP ${stats.hp}`);

console.log('5) Promosi rank (harus MANUAL)');
rdb.updateCharacter(U, { level: 10, questsCompleted: 10 });
let promo = engine.checkPromotion(rdb.getCharacter(U));
ok(promo.eligible, `layak naik ke ${promo.next.key}`);
const rr = rdb.createRankRequest(U, G, 'G', 'F', 'test');
ok(rr.request && rr.request.status === 'pending', 'pengajuan promosi dibuat (pending, TIDAK auto)');
ok(rdb.getCharacter(U).rankKey === 'G', 'rank BELUM berubah sebelum ACC (benar, tidak otomatis)');
const dup = rdb.createRankRequest(U, G, 'G', 'F', 'test2');
ok(dup.existing, 'tidak bisa buat pengajuan ganda');
engine.applyPromotion(U, 'F');
rdb.resolveRankRequest(rr.request.id, 'approved', 'staff_1');
ok(rdb.getCharacter(U).rankKey === 'F', 'setelah ACC staff, rank jadi F');

console.log('6) Reputasi');
const repRes = engine.addReputation(U, 600);
ok(repRes.ok && repRes.tier.name === 'Disukai', `reputasi 600 -> tier ${repRes.tier.name}`);

console.log('7) Party (buat, gabung, list, keluar)');
const p = rdb.createParty(G, U, 'Naga Merah');
ok(p.partyId && p.members.length === 1, `party dibuat id#${p.partyId}`);
rdb.createCharacter(U2, 'healer');
rdb.joinParty(p.partyId, U2);
ok(rdb.getParty(p.partyId).members.length === 2, 'user B gabung, anggota jadi 2');
ok(rdb.listOpenParties(G).length === 1, 'party muncul di daftar terbuka');
const left = rdb.leaveParty(U2);
ok(!left.disbanded && rdb.getParty(p.partyId).members.length === 1, 'user B keluar, party tetap ada');
const leftLeader = rdb.leaveParty(U);
ok(leftLeader.disbanded, 'leader keluar -> party bubar');

console.log('8) Quest board + accept');
const q = rdb.createQuest({ guildId: G, title: 'Basmi 10 Slime', description: 'Kalahkan 10 slime', objectiveType: 'kill', objectiveTarget: 10, rewardXp: 300, rewardGold: 100, rewardRep: 50, minRank: 'G' });
ok(q.questId, `quest dibuat id#${q.questId}`);
ok(rdb.listActiveQuests(G).length === 1, 'quest muncul di papan');
rdb.acceptQuest(U, q.questId);
ok(rdb.getUserActiveQuests(U).length === 1, 'quest diterima & masuk daftar aktif');

console.log('9) Luna tools (baca DB + aksi) tanpa panggil model');
const ctx = { userId: U, guildId: G, guild: { name: 'Test Server', memberCount: 42 } };
const status = luna.TOOLS.get_status.run(ctx);
ok(status.registered && status.class === 'warrior', `Luna get_status: Lv${status.level} rank ${status.rank}`);
const lq = luna.TOOLS.list_quests.run(ctx);
ok(lq.count === 1, `Luna list_quests: ${lq.count} quest`);
const cp = luna.TOOLS.create_party.run(ctx, { name: 'Party Luna' });
ok(cp.ok, `Luna create_party: ${cp.ok}`);
ok(rdb.getPartyOfUser(U).name === 'Party Luna', 'party buatan Luna tersimpan di DB');
const reqPromo = luna.TOOLS.request_promotion.run(ctx, { reason: 'via luna' });
ok(reqPromo.ok !== undefined, `Luna request_promotion dieksekusi (ok=${reqPromo.ok})`);

console.log('10) Leaderboard');
const lb = rdb.getLeaderboard(5);
ok(lb.length >= 2, `leaderboard: ${lb.length} petualang`);

console.log(`\n==== HASIL: ${pass} lulus, ${fail} gagal ====`);
process.exit(fail ? 1 : 0);
