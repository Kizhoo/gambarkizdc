// ============================================================================
// PANEL MANAJEMEN BERBASIS TOMBOL
// ----------------------------------------------------------------------------
// Satu pintu untuk mengubah SEMUA setting (config.json) + manajemen server & user
// langsung dari Discord, hot-update tanpa restart.
//
// Skema customId : "pnl:<view>:<action>:<arg>"
// Skema modal    : "pnlmodal:<section>:<kind>:<arg>"
//   view   = home | settings | ai | backup | users | server | anime | crypto
// ============================================================================
const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
  StringSelectMenuBuilder, ChannelSelectMenuBuilder, ChannelType,
  ModalBuilder, TextInputBuilder, TextInputStyle, PermissionFlagsBits,
} = require('discord.js');
const settings = require('./settings');
const { isOwner } = require('./ownerCheck');
const { baseEmbed, successEmbed, errorEmbed } = require('./embeds');
const {
  getGuildConfig, updateGuildConfig, listUsers, countUsers, getUser,
  setUserBanned, setUserField, deleteUser, resetEconomyForGuild,
  getAnimeConfig, updateAnimeConfig, getCryptoConfig, updateCryptoConfig,
} = require('../database/db');
const rpgEngine = require('./rpgEngine');

const state = (v) => (v ? 'Aktif' : 'Nonaktif');
const cid = (view, action = 'open', arg = '') => `pnl:${view}:${action}:${arg}`;
// Cache sementara buat tombol "pilih node hasil pencarian" - kunci = ID pesan ephemeral yang
// nampilin tombolnya, isi = daftar node yang ditemukan pas itu. Dibersihkan otomatis 10 menit
// (lihat setTimeout di handler 'discover') biar tidak numpuk terus di memori.
const discoveryCache = new Map();

// Acknowledge yang tahan latensi tinggi (abaikan 10062 "Unknown interaction").
async function safeUpdate(interaction, payload) {
  try { await interaction.update(payload); }
  catch (e) { if (e?.code !== 10062) throw e; }
}

// ---------------- NAV ----------------
function navRow(active) {
  const btn = (view, label) => new ButtonBuilder()
    .setCustomId(cid(view)).setLabel(label)
    .setStyle(active === view ? ButtonStyle.Primary : ButtonStyle.Secondary)
    .setDisabled(active === view);
  return new ActionRowBuilder().addComponents(
    btn('settings', 'Umum'),
    btn('ai', 'AI'),
    btn('backup', 'Backup & Node'),
    btn('users', 'User'),
    btn('server', 'Server'),
  );
}

// ---------------- HOME ----------------
function homeView() {
  const embed = baseEmbed()
    .setTitle('Panel Manajemen KizhooBot')
    .setDescription('Kelola seluruh setting & data bot dari sini. Perubahan langsung aktif tanpa restart dan tersimpan otomatis di config.json.\n\nPilih kategori di bawah.')
    .addFields(
      { name: 'Umum', value: 'NSFW, registrasi, ekonomi, XP, tampilan', inline: false },
      { name: 'AI', value: 'Model, model premium, panjang history', inline: false },
      { name: 'Backup & Node', value: 'Auto-backup, emergency, node musik', inline: false },
      { name: 'User', value: 'Data registrasi: edit, reset, ban, hapus', inline: false },
      { name: 'Server', value: 'Welcome, automod, log, channel', inline: false },
      { name: 'Notifikasi Owner', value: 'Notif registrasi baru & bot ditambahkan ke server', inline: false },
    );
  const notifBtn = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(cid('notif')).setLabel('Notifikasi Owner').setStyle(ButtonStyle.Secondary).setEmoji('🔔'),
  );
  return { embeds: [embed], components: [navRow('home'), notifBtn] };
}

// ---------------- SETTINGS (UMUM) ----------------
function settingsView() {
  const embed = baseEmbed()
    .setTitle('Setting Umum')
    .addFields(
      { name: 'Konten NSFW', value: state(settings.get('isNsfw')), inline: true },
      { name: 'Registrasi wajib', value: state(settings.get('registration.enabled')), inline: true },
      { name: 'Kunci semua command', value: state(settings.get('registration.gateAllCommands')), inline: true },
      { name: 'Umur minimal', value: `${settings.get('registration.minAge', 13)} tahun`, inline: true },
      { name: 'XP per pesan', value: `${settings.get('xpPerMessage.min')} - ${settings.get('xpPerMessage.max')}`, inline: true },
      { name: 'Daily', value: `${settings.get('dailyAmount')}`, inline: true },
      { name: 'Work', value: `${settings.get('workMin')} - ${settings.get('workMax')}`, inline: true },
      { name: 'Peluang rob', value: `${Math.round(settings.get('robSuccessRate', 0.4) * 100)}%`, inline: true },
      { name: 'Nama bot', value: `${settings.get('botName')}`, inline: true },
    );
  const toggles = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(cid('settings', 'toggle', 'isNsfw')).setLabel(`NSFW: ${state(settings.get('isNsfw'))}`).setStyle(settings.get('isNsfw') ? ButtonStyle.Danger : ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(cid('settings', 'toggle', 'registration.enabled')).setLabel(`Registrasi: ${state(settings.get('registration.enabled'))}`).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(cid('settings', 'toggle', 'registration.gateAllCommands')).setLabel(`Kunci command: ${state(settings.get('registration.gateAllCommands'))}`).setStyle(ButtonStyle.Secondary),
  );
  const edits = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(cid('settings', 'edit', 'numbers')).setLabel('Edit angka (XP/ekonomi/umur)').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(cid('settings', 'edit', 'texts')).setLabel('Edit tampilan (nama/footer/warna)').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(cid('games')).setLabel('Setting Game »').setStyle(ButtonStyle.Secondary),
  );
  return { embeds: [embed], components: [navRow('settings'), toggles, edits] };
}

// ---------------- AI ----------------
function aiView() {
  const ai = settings.get('ai', {});
  const attachmentsOn = ai.attachments?.enabled !== false;
  const embed = baseEmbed()
    .setTitle('Setting AI')
    .addFields(
      { name: 'Model aktif', value: `\`${ai.model}\``, inline: false },
      { name: 'Mode premium', value: state(ai.premiumEnabled), inline: true },
      { name: 'Model premium', value: `\`${ai.premiumModel}\``, inline: true },
      { name: 'Panjang history', value: `${ai.maxHistory} pesan`, inline: true },
      { name: 'Lampiran file (termasuk zip)', value: state(attachmentsOn), inline: true },
      { name: 'Batas ukuran file', value: `${ai.attachments?.maxFileSizeMB ?? 8} MB`, inline: true },
      { name: 'Cooldown chat', value: `${ai.cooldownSeconds ?? 6} detik`, inline: true },
    )
    .setFooter({ text: 'Model premium tetap pakai Cloudflare (mis. gpt-oss, llama-70b). Butuh CLOUDFLARE_ACCOUNT_ID/API_TOKEN di .env.' });

  const list = (ai.models?.cloudflare || []).slice(0, 25);
  const modelSelect = new StringSelectMenuBuilder()
    .setCustomId(cid('ai', 'set', 'model'))
    .setPlaceholder('Pilih model AI aktif')
    .addOptions(list.length ? list.map(m => ({ label: m.replace('@cf/', '').slice(0, 100), value: m.slice(0, 100), default: m === ai.model })) : [{ label: 'kosong', value: 'none' }]);

  const premSelect = new StringSelectMenuBuilder()
    .setCustomId(cid('ai', 'set', 'premiummodel'))
    .setPlaceholder('Pilih model premium')
    .addOptions(list.length ? list.map(m => ({ label: m.replace('@cf/', '').slice(0, 100), value: m.slice(0, 100), default: m === ai.premiumModel })) : [{ label: 'kosong', value: 'none' }]);

  const btns = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(cid('ai', 'toggle', 'ai.premiumEnabled')).setLabel(`Mode Premium: ${state(ai.premiumEnabled)}`).setStyle(ai.premiumEnabled ? ButtonStyle.Success : ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(cid('ai', 'edit', 'maxhistory')).setLabel('Edit panjang history').setStyle(ButtonStyle.Primary),
  );
  const btns2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(cid('ai', 'toggle', 'ai.attachments.enabled')).setLabel(`Lampiran File: ${state(attachmentsOn)}`).setStyle(attachmentsOn ? ButtonStyle.Success : ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(cid('ai', 'edit', 'cooldown')).setLabel('Edit cooldown chat').setStyle(ButtonStyle.Primary),
  );
  return { embeds: [embed], components: [navRow('ai'), new ActionRowBuilder().addComponents(modelSelect), new ActionRowBuilder().addComponents(premSelect), btns, btns2] };
}

// ---------------- BACKUP / NODE ----------------
function backupView() {
  const b = settings.get('backup', {});
  const nodes = settings.get('music.nodes', []);
  const embed = baseEmbed()
    .setTitle('Backup & Node Musik')
    .addFields(
      { name: 'Auto backup', value: state(b.enabled), inline: true },
      { name: 'Interval', value: `${b.intervalHours} jam`, inline: true },
      { name: 'Kirim ke DM owner', value: state(b.sendToOwnerDM), inline: true },
      { name: 'Emergency backup', value: state(b.emergencyOnShutdown), inline: true },
      { name: 'Auto-discover node', value: state(settings.get('music.autoDiscoverNodes')), inline: true },
      { name: 'Jumlah node', value: `${nodes.length}`, inline: true },
    );
  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(cid('backup', 'toggle', 'backup.enabled')).setLabel(`Auto backup: ${state(b.enabled)}`).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(cid('backup', 'toggle', 'backup.emergencyOnShutdown')).setLabel(`Emergency: ${state(b.emergencyOnShutdown)}`).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(cid('backup', 'toggle', 'music.autoDiscoverNodes')).setLabel(`Auto-discover: ${state(settings.get('music.autoDiscoverNodes'))}`).setStyle(ButtonStyle.Secondary),
  );
  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(cid('backup', 'edit', 'interval')).setLabel('Edit interval').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(cid('backup', 'run', 'backupnow')).setLabel('Backup sekarang').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(cid('backup', 'run', 'healnodes')).setLabel('Perbaiki node').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(cid('music')).setLabel('Kelola Node Musik »').setStyle(ButtonStyle.Primary),
  );
  return { embeds: [embed], components: [navRow('backup'), row1, row2] };
}

// ---------------- MUSIK (owner-only, node Lavalink) ----------------
function musicView() {
  const { getNodes, getPreferredNode } = require('./nodeManager');
  const nodes = getNodes();
  const preferred = getPreferredNode();
  const embed = baseEmbed()
    .setTitle('Kelola Node Musik (Lavalink)')
    .setDescription(nodes.length
      ? nodes.map(n => `${n.name === preferred ? '⭐ ' : ''}**${n.name}** — \`${n.url}\`${n.secure ? ' 🔒' : ''}${n.name === preferred ? ' *(dipakai)*' : ''}`).join('\n')
      : 'Belum ada node musik terdaftar. Pakai tombol "Cari Node Online" atau `/node add` buat nambah.')
    .setFooter({ text: `${nodes.length} node terdaftar • Node aktif: ${preferred || '(otomatis)'} • Auto-discover: ${state(settings.get('music.autoDiscoverNodes'))} • Pilih node di dropdown buat lihat detail` });

  const select = new StringSelectMenuBuilder()
    .setCustomId(cid('music', 'select'))
    .setPlaceholder(nodes.length ? 'Pilih node buat lihat detail / hapus' : 'Belum ada node')
    .addOptions(nodes.length ? nodes.slice(0, 25).map(n => ({ label: n.name, value: n.name, description: n.url.slice(0, 100) })) : [{ label: '(kosong)', value: 'none' }]);

  const buttons = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(cid('music', 'discover')).setLabel('Cari Node Online').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(cid('music', 'heal')).setLabel('Auto-Perbaiki').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(cid('backup')).setLabel('« Kembali').setStyle(ButtonStyle.Secondary),
  );
  return { embeds: [embed], components: [new ActionRowBuilder().addComponents(select), buttons] };
}

// ---------------- GAME (owner-only, timer & difficulty default) ----------------
function gamesView() {
  const { DIFFICULTIES } = require('./gameDifficulty');
  const currentDiff = settings.get('games.defaultAiDifficulty', 'hard');
  const questModel = settings.get('ai.questModel', '@cf/zai-org/glm-5.2');
  const modelList = (settings.get('ai.models.cloudflare', []) || []).slice(0, 25);
  const embed = baseEmbed()
    .setTitle('Setting Game')
    .setDescription('Durasi di sini jadi default buat SEMUA game tebak-tebakan (tebak gambar, tebak anime, tebak pokemon, tebak bendera, tebak ibukota, benar/salah, dll - satu mesin yang sama). Catur/Tic-Tac-Toe/Connect Four/Suit punya pemilihan waktu sendiri tiap mulai game (20 Detik s/d 10 Menit, atau Tanpa Batas Waktu), jadi tidak perlu diatur di sini.\n\nModel AI penulis quest **dipisah** dari model chat Luna biasa - biar bisa pakai model yang lebih kuat/kreatif khusus buat quest tanpa mempengaruhi kecepatan/biaya chat harian.')
    .addFields(
      { name: 'Durasi Tebak-Tebakan', value: `${settings.get('games.quizDurationSeconds', 45)} detik`, inline: true },
      { name: 'Durasi Tebak Kata Acak', value: `${settings.get('games.wordScrambleSeconds', 30)} detik`, inline: true },
      { name: 'Durasi per Soal Trivia', value: `${settings.get('games.triviaSecondsPerQuestion', 15)} detik`, inline: true },
      { name: 'Default Difficulty AI (Catur/TTT/C4/Suit)', value: DIFFICULTIES.find(d => d.key === currentDiff)?.label || 'Hard', inline: true },
      { name: 'Model AI Penulis Quest', value: `\`${questModel}\``, inline: true },
    );
  const editRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(cid('games', 'edit', 'durations')).setLabel('Edit Durasi Game').setStyle(ButtonStyle.Primary),
  );
  const diffRow = new ActionRowBuilder().addComponents(
    ...DIFFICULTIES.map(d => new ButtonBuilder()
      .setCustomId(cid('games', 'setdiff', d.key))
      .setLabel(d.key === currentDiff ? `✓ ${d.label}` : d.label)
      .setStyle(d.key === currentDiff ? ButtonStyle.Success : ButtonStyle.Secondary)),
  );
  const questModelSelect = new StringSelectMenuBuilder()
    .setCustomId(cid('games', 'setquestmodel'))
    .setPlaceholder('Pilih model AI penulis quest')
    .addOptions(modelList.length ? modelList.map(m => ({ label: m.replace('@cf/', '').slice(0, 100), value: m.slice(0, 100), default: m === questModel })) : [{ label: 'kosong', value: 'none' }]);
  const backRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(cid('settings')).setLabel('« Kembali').setStyle(ButtonStyle.Secondary),
  );
  return { embeds: [embed], components: [editRow, diffRow, new ActionRowBuilder().addComponents(questModelSelect), backRow] };
}


const USERS_PER_PAGE = 10;
function usersView(page = 0) {
  const total = countUsers();
  const maxPage = Math.max(0, Math.ceil(total / USERS_PER_PAGE) - 1);
  page = Math.min(Math.max(0, page), maxPage);
  const users = listUsers(USERS_PER_PAGE, page * USERS_PER_PAGE);

  const embed = baseEmbed()
    .setTitle('Manajemen User Terdaftar')
    .setDescription(users.length
      ? users.map((u, i) => `**${page * USERS_PER_PAGE + i + 1}. ${u.username}** — ${u.age} th ${u.banned ? '(diblokir)' : ''}\n<@${u.userId}> • \`${u.userId}\``).join('\n\n')
      : 'Belum ada user terdaftar.')
    .setFooter({ text: `Total ${total} user • Halaman ${page + 1} dari ${maxPage + 1}` });

  const rows = [navRow('users')];
  if (users.length) {
    rows.push(new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId(cid('users', 'pick'))
        .setPlaceholder('Pilih user untuk dikelola')
        .addOptions(users.map(u => ({ label: `${u.username} (${u.age} th)`.slice(0, 100), description: u.userId, value: u.userId }))),
    ));
  }
  // customId prev & next SELALU unik (arg diberi prefix arah) supaya tidak duplikat saat 1 halaman.
  rows.push(new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(cid('users', 'page', `p${Math.max(0, page - 1)}`)).setLabel('Sebelumnya').setStyle(ButtonStyle.Secondary).setDisabled(page <= 0),
    new ButtonBuilder().setCustomId(cid('users', 'page', `n${Math.min(maxPage, page + 1)}`)).setLabel('Berikutnya').setStyle(ButtonStyle.Secondary).setDisabled(page >= maxPage),
  ));
  return { embeds: [embed], components: rows };
}

function userManageView(userId) {
  const u = getUser(userId);
  if (!u) return usersView(0);
  const embed = baseEmbed()
    .setTitle(`Kelola User: ${u.username}`)
    .addFields(
      { name: 'User', value: `<@${u.userId}>`, inline: true },
      { name: 'ID', value: `\`${u.userId}\``, inline: true },
      { name: 'Umur', value: `${u.age} tahun`, inline: true },
      { name: 'Status', value: u.banned ? 'Diblokir' : 'Aktif', inline: true },
      { name: 'Terdaftar', value: `<t:${Math.floor(u.registeredAt / 1000)}:R>`, inline: true },
      { name: 'Catatan', value: u.notes || '-', inline: false },
    );
  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(cid('users', 'editage', u.userId)).setLabel('Edit umur').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(cid('users', 'editname', u.userId)).setLabel('Edit username').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(cid('users', 'note', u.userId)).setLabel('Catatan').setStyle(ButtonStyle.Primary),
  );
  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(cid('users', 'reseteco', u.userId)).setLabel('Reset ekonomi').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(cid('users', 'resetlvl', u.userId)).setLabel('Reset level').setStyle(ButtonStyle.Secondary),
  );
  const row3 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(cid('users', u.banned ? 'unban' : 'ban', u.userId)).setLabel(u.banned ? 'Buka blokir' : 'Blokir').setStyle(u.banned ? ButtonStyle.Success : ButtonStyle.Danger),
    new ButtonBuilder().setCustomId(cid('users', 'del', u.userId)).setLabel('Hapus data').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId(cid('users')).setLabel('Kembali').setStyle(ButtonStyle.Secondary),
  );
  return { embeds: [embed], components: [row1, row2, row3] };
}

// ---------------- SERVER (per-guild) ----------------
function serverView(interaction) {
  const cfg = getGuildConfig(interaction.guild.id);
  const ch = (id) => (id ? `<#${id}>` : 'belum diatur');
  const embed = baseEmbed()
    .setTitle(`Setting Server: ${interaction.guild.name}`)
    .addFields(
      { name: 'Welcome', value: state(cfg.welcomeEnabled), inline: true },
      { name: 'Goodbye', value: state(cfg.goodbyeEnabled), inline: true },
      { name: 'Automod', value: state(cfg.automodEnabled), inline: true },
      { name: 'Anti-link', value: state(cfg.antiLinkEnabled), inline: true },
      { name: 'Anti-spam', value: state(cfg.antiSpamEnabled), inline: true },
      { name: 'Anti-raid', value: state(cfg.antiraidEnabled), inline: true },
      { name: 'Mod log', value: state(cfg.modLogEnabled), inline: true },
      { name: 'Channel welcome', value: ch(cfg.welcomeChannel), inline: true },
      { name: 'Gaya welcome', value: cfg.welcomeStyle === 'card' ? 'Gaya 2 (Kartu Gambar)' : 'Gaya 1 (Embed)', inline: true },
      { name: 'Channel log', value: ch(cfg.logChannel), inline: true },
      { name: 'Channel voice log', value: ch(cfg.voiceLogChannel), inline: true },
      { name: 'Channel level up', value: ch(cfg.levelUpChannel), inline: true },
      { name: 'Channel suggestion', value: ch(cfg.suggestChannelId), inline: true },
      { name: 'Channel update anime', value: ch(getAnimeConfig(interaction.guild.id).channelId), inline: true },
      { name: 'Channel sinyal crypto', value: ch(getCryptoConfig(interaction.guild.id).channelId), inline: true },
    );
  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(cid('server', 'toggle', 'welcomeEnabled')).setLabel(`Welcome: ${state(cfg.welcomeEnabled)}`).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(cid('server', 'toggle', 'goodbyeEnabled')).setLabel(`Goodbye: ${state(cfg.goodbyeEnabled)}`).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(cid('server', 'toggle', 'automodEnabled')).setLabel(`Automod: ${state(cfg.automodEnabled)}`).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(cid('anime')).setLabel('Setting Anime »').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(cid('crypto')).setLabel('Setting Crypto »').setStyle(ButtonStyle.Primary),
  );
  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(cid('server', 'toggle', 'antiLinkEnabled')).setLabel(`Anti-link: ${state(cfg.antiLinkEnabled)}`).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(cid('server', 'toggle', 'antiSpamEnabled')).setLabel(`Anti-spam: ${state(cfg.antiSpamEnabled)}`).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(cid('server', 'toggle', 'antiraidEnabled')).setLabel(`Anti-raid: ${state(cfg.antiraidEnabled)}`).setStyle(ButtonStyle.Secondary),
  );
  const chSelect = new ChannelSelectMenuBuilder()
    .setCustomId(cid('server', 'setch'))
    .setPlaceholder('Set channel (pilih dulu jenisnya di bawah)')
    .addChannelTypes(ChannelType.GuildText);
  const chTarget = new StringSelectMenuBuilder()
    .setCustomId(cid('server', 'chtarget'))
    .setPlaceholder('Pilih channel yang mau diatur')
    .addOptions(
      { label: 'Welcome', value: 'welcomeChannel' },
      { label: 'Goodbye', value: 'goodbyeChannel' },
      { label: 'Log server', value: 'logChannel' },
      { label: 'Voice log', value: 'voiceLogChannel' },
      { label: 'Level up', value: 'levelUpChannel' },
      { label: 'Suggestion', value: 'suggestChannelId' },
    );
  return { embeds: [embed], components: [navRow('server'), row1, row2, new ActionRowBuilder().addComponents(chTarget), new ActionRowBuilder().addComponents(chSelect)] };
}

// ---------------- ANIME (per-guild, channel sendiri) ----------------
function animeView(interaction) {
  const cfg = getAnimeConfig(interaction.guild.id);
  const embed = baseEmbed()
    .setTitle(`Setting Update Anime: ${interaction.guild.name}`)
    .setDescription('Auto-post jadwal anime tayang hari ini & alert tiap episode baru dari anime musim ini, langsung ke channel ini.')
    .addFields(
      { name: 'Channel tujuan', value: cfg.channelId ? `<#${cfg.channelId}>` : 'belum diatur', inline: true },
      { name: 'Digest harian', value: state(cfg.dailyDigestEnabled), inline: true },
      { name: 'Alert episode baru', value: state(cfg.newSeasonAlertEnabled), inline: true },
    )
    .setFooter({ text: 'Data: AniList. Digest harian sekali per hari; alert episode baru dicek berkala & kirim satu pesan per episode - bisa cukup ramai di jam-jam ramai tayang.' });

  const toggles = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(cid('anime', 'toggle', 'dailyDigestEnabled')).setLabel(`Digest Harian: ${state(cfg.dailyDigestEnabled)}`).setStyle(cfg.dailyDigestEnabled ? ButtonStyle.Success : ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(cid('anime', 'toggle', 'newSeasonAlertEnabled')).setLabel(`Alert Episode Baru: ${state(cfg.newSeasonAlertEnabled)}`).setStyle(cfg.newSeasonAlertEnabled ? ButtonStyle.Success : ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(cid('server')).setLabel('« Kembali').setStyle(ButtonStyle.Secondary),
  );
  const chSelect = new ChannelSelectMenuBuilder()
    .setCustomId(cid('anime', 'setch'))
    .setPlaceholder('Pilih channel tujuan update anime')
    .addChannelTypes(ChannelType.GuildText);
  return { embeds: [embed], components: [toggles, new ActionRowBuilder().addComponents(chSelect)] };
}

// ---------------- CRYPTO (per-guild, channel sendiri) ----------------
function cryptoView(interaction) {
  const cfg = getCryptoConfig(interaction.guild.id);
  const watchlist = (cfg.watchlist || '').split(',').map(s => s.trim()).filter(Boolean);
  const embed = baseEmbed()
    .setTitle(`Setting Sinyal Crypto: ${interaction.guild.name}`)
    .setDescription('Auto-post notifikasi saat kondisi indikator teknikal (RSI/EMA) berubah untuk koin di watchlist, langsung ke channel ini.')
    .addFields(
      { name: 'Channel tujuan', value: cfg.channelId ? `<#${cfg.channelId}>` : 'belum diatur', inline: true },
      { name: 'Auto-sinyal', value: state(cfg.signalEnabled), inline: true },
      { name: 'Watchlist', value: watchlist.length ? watchlist.join(', ') : '(kosong)', inline: false },
    )
    .setFooter({ text: 'Data: Binance (publik). Notifikasi indikator, bukan saran beli/jual.' });

  const toggles = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(cid('crypto', 'toggle', 'signalEnabled')).setLabel(`Auto-sinyal: ${state(cfg.signalEnabled)}`).setStyle(cfg.signalEnabled ? ButtonStyle.Success : ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(cid('crypto', 'edit', 'watchlist')).setLabel('Edit watchlist').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(cid('server')).setLabel('« Kembali').setStyle(ButtonStyle.Secondary),
  );
  const chSelect = new ChannelSelectMenuBuilder()
    .setCustomId(cid('crypto', 'setch'))
    .setPlaceholder('Pilih channel tujuan sinyal crypto')
    .addChannelTypes(ChannelType.GuildText);
  return { embeds: [embed], components: [toggles, new ActionRowBuilder().addComponents(chSelect)] };
}

// ---------------- NOTIFIKASI OWNER (owner-only) ----------------
function notifView() {
  const cfg = settings.get('ownerNotifications', {});
  const embed = baseEmbed()
    .setTitle('Notifikasi Owner')
    .setDescription('Notifikasi dikirim ke channel di bawah (server owner) saat ada aktivitas penting.')
    .addFields(
      { name: 'Status', value: state(cfg.enabled !== false), inline: true },
      { name: 'Channel', value: cfg.channelId ? `<#${cfg.channelId}>` : 'belum diatur', inline: true },
      { name: 'Notif registrasi baru', value: state(cfg.notifyRegister !== false), inline: true },
      { name: 'Notif bot ditambahkan', value: state(cfg.notifyGuildJoin !== false), inline: true },
    );
  const toggles = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(cid('notif', 'toggle', 'ownerNotifications.enabled')).setLabel(`Aktif: ${state(cfg.enabled !== false)}`).setStyle(cfg.enabled !== false ? ButtonStyle.Success : ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(cid('notif', 'toggle', 'ownerNotifications.notifyRegister')).setLabel(`Registrasi: ${state(cfg.notifyRegister !== false)}`).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(cid('notif', 'toggle', 'ownerNotifications.notifyGuildJoin')).setLabel(`Server baru: ${state(cfg.notifyGuildJoin !== false)}`).setStyle(ButtonStyle.Secondary),
  );
  const chSelect = new ChannelSelectMenuBuilder()
    .setCustomId(cid('notif', 'setch'))
    .setPlaceholder('Pilih channel notifikasi owner')
    .addChannelTypes(ChannelType.GuildText);
  const back = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(cid('home')).setLabel('« Kembali').setStyle(ButtonStyle.Secondary),
  );
  return { embeds: [embed], components: [toggles, new ActionRowBuilder().addComponents(chSelect), back] };
}

function renderView(view, interaction, arg) {
  switch (view) {
    case 'settings': return settingsView();
    case 'ai': return aiView();
    case 'backup': return backupView();
    case 'music': return musicView();
    case 'games': return gamesView();
    case 'users': return usersView(parseInt(String(arg).replace(/\D/g, ''), 10) || 0);
    case 'server': return serverView(interaction);
    case 'anime': return animeView(interaction);
    case 'crypto': return cryptoView(interaction);
    case 'notif': return notifView();
    default: return homeView();
  }
}

// ---------------- MODAL BUILDERS ----------------
function numberModal() {
  const row = (id, label, val) => new ActionRowBuilder().addComponents(
    new TextInputBuilder().setCustomId(id).setLabel(label).setStyle(TextInputStyle.Short).setValue(String(val)).setRequired(true));
  return new ModalBuilder().setCustomId('pnlmodal:settings:numbers').setTitle('Edit Angka').addComponents(
    row('minAge', 'Umur minimal registrasi', settings.get('registration.minAge', 13)),
    row('daily', 'Jumlah daily', settings.get('dailyAmount', 500)),
    row('xpmin', 'XP minimal per pesan', settings.get('xpPerMessage.min', 15)),
    row('xpmax', 'XP maksimal per pesan', settings.get('xpPerMessage.max', 25)),
    row('robrate', 'Peluang rob (0-100)', Math.round(settings.get('robSuccessRate', 0.4) * 100)),
  );
}
function textModal() {
  const row = (id, label, val) => new ActionRowBuilder().addComponents(
    new TextInputBuilder().setCustomId(id).setLabel(label).setStyle(TextInputStyle.Short).setValue(String(val || '')).setRequired(false));
  return new ModalBuilder().setCustomId('pnlmodal:settings:texts').setTitle('Edit Tampilan').addComponents(
    row('botName', 'Nama bot', settings.get('botName')),
    row('footer', 'Teks footer embed', settings.get('footer')),
    row('embedColor', 'Warna embed (hex, mis. #2b2d31)', settings.get('embedColor')),
  );
}

// ---------------- ROUTER ----------------
async function handlePanel(interaction, client) {
  const [, view, action, arg] = interaction.customId.split(':');

  const globalViews = ['settings', 'ai', 'backup', 'users', 'home', 'music', 'games', 'notif'];
  if (globalViews.includes(view) && !isOwner(interaction.user.id)) {
    return interaction.reply({ embeds: [errorEmbed('Bagian panel ini khusus owner bot.')], ephemeral: true });
  }
  if (['server', 'anime', 'crypto'].includes(view) && !interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
    return interaction.reply({ embeds: [errorEmbed('Butuh izin Manage Server untuk bagian ini.')], ephemeral: true });
  }

  // Navigasi
  if (action === 'open' || action === 'page') return safeUpdate(interaction, renderView(view, interaction, arg));

  // Toggle boolean
  if (action === 'toggle') {
    if (view === 'server') {
      const cfg = getGuildConfig(interaction.guild.id);
      updateGuildConfig(interaction.guild.id, { [arg]: cfg[arg] ? 0 : 1 });
    } else if (view === 'anime') {
      const cfg = getAnimeConfig(interaction.guild.id);
      updateAnimeConfig(interaction.guild.id, { [arg]: cfg[arg] ? 0 : 1 });
    } else if (view === 'crypto') {
      const cfg = getCryptoConfig(interaction.guild.id);
      updateCryptoConfig(interaction.guild.id, { [arg]: cfg[arg] ? 0 : 1 });
    } else {
      settings.toggle(arg);
    }
    return safeUpdate(interaction, renderView(view, interaction, arg));
  }

  // ----- Modals (harus di-ack sebelum kerja lain) -----
  if (view === 'settings' && action === 'edit' && arg === 'numbers') return interaction.showModal(numberModal());
  if (view === 'settings' && action === 'edit' && arg === 'texts') return interaction.showModal(textModal());
  if (view === 'ai' && action === 'edit' && arg === 'maxhistory') {
    const m = new ModalBuilder().setCustomId('pnlmodal:ai:maxhistory').setTitle('Panjang History AI').addComponents(
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('val').setLabel('Jumlah pesan history (2-30)').setStyle(TextInputStyle.Short).setValue(String(settings.get('ai.maxHistory', 12))).setRequired(true)));
    return interaction.showModal(m);
  }
  if (view === 'ai' && action === 'edit' && arg === 'cooldown') {
    const m = new ModalBuilder().setCustomId('pnlmodal:ai:cooldown').setTitle('Cooldown Chat AI').addComponents(
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('val').setLabel('Jeda antar chat/imagine per user (detik)').setStyle(TextInputStyle.Short).setValue(String(settings.get('ai.cooldownSeconds', 6))).setRequired(true)));
    return interaction.showModal(m);
  }
  if (view === 'backup' && action === 'edit' && arg === 'interval') {
    const m = new ModalBuilder().setCustomId('pnlmodal:backup:interval').setTitle('Interval Auto-Backup').addComponents(
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('val').setLabel('Interval dalam jam (min 1)').setStyle(TextInputStyle.Short).setValue(String(settings.get('backup.intervalHours', 12))).setRequired(true)));
    return interaction.showModal(m);
  }
  if (view === 'crypto' && action === 'edit' && arg === 'watchlist') {
    const cfg = getCryptoConfig(interaction.guild.id);
    const m = new ModalBuilder().setCustomId('pnlmodal:crypto:watchlist').setTitle('Watchlist Crypto').addComponents(
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('val').setLabel('Simbol dipisah koma, mis. BTC,ETH,SOL').setStyle(TextInputStyle.Short).setValue(cfg.watchlist || 'BTCUSDT,ETHUSDT').setRequired(true)));
    return interaction.showModal(m);
  }
  if (view === 'games' && action === 'edit' && arg === 'durations') {
    const m = new ModalBuilder().setCustomId('pnlmodal:games:durations').setTitle('Edit Durasi Game').addComponents(
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('quiz').setLabel('Tebak-tebakan (detik)').setStyle(TextInputStyle.Short).setValue(String(settings.get('games.quizDurationSeconds', 45))).setRequired(true)),
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('scramble').setLabel('Tebak Kata Acak (detik)').setStyle(TextInputStyle.Short).setValue(String(settings.get('games.wordScrambleSeconds', 30))).setRequired(true)),
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('trivia').setLabel('Trivia per soal (detik)').setStyle(TextInputStyle.Short).setValue(String(settings.get('games.triviaSecondsPerQuestion', 15))).setRequired(true)),
    );
    return interaction.showModal(m);
  }
  if (view === 'games' && action === 'setdiff') {
    settings.set('games.defaultAiDifficulty', arg);
    return safeUpdate(interaction, gamesView());
  }
  if (view === 'users' && (action === 'editage' || action === 'editname' || action === 'note')) {
    const u = getUser(arg);
    if (!u) return safeUpdate(interaction, usersView(0));
    let m;
    if (action === 'editage') m = new ModalBuilder().setCustomId(`pnlmodal:users:age:${arg}`).setTitle('Edit Umur').addComponents(
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('val').setLabel('Umur baru').setStyle(TextInputStyle.Short).setValue(String(u.age)).setRequired(true)));
    if (action === 'editname') m = new ModalBuilder().setCustomId(`pnlmodal:users:name:${arg}`).setTitle('Edit Username').addComponents(
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('val').setLabel('Username baru').setStyle(TextInputStyle.Short).setValue(u.username).setRequired(true)));
    if (action === 'note') m = new ModalBuilder().setCustomId(`pnlmodal:users:note:${arg}`).setTitle('Catatan Admin').addComponents(
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('val').setLabel('Catatan').setStyle(TextInputStyle.Paragraph).setValue(u.notes || '').setRequired(false)));
    return interaction.showModal(m);
  }

  // ----- AI model select -----
  if (view === 'ai' && action === 'set') {
    if (arg === 'model') settings.set('ai.model', interaction.values[0]);
    if (arg === 'premiummodel') settings.set('ai.premiumModel', interaction.values[0]);
    return safeUpdate(interaction, aiView());
  }

  // ----- Quest-writer model select -----
  if (view === 'games' && action === 'setquestmodel') {
    settings.set('ai.questModel', interaction.values[0]);
    return safeUpdate(interaction, gamesView());
  }

  // ----- Server channel setter -----
  if (view === 'server' && action === 'chtarget') {
    // simpan target sementara di footer embed? lebih aman: pakai customId dinamis pada ChannelSelect
    const target = interaction.values[0];
    const v = serverView(interaction);
    // ganti channel select agar membawa target di customId
    const chSelect = new ChannelSelectMenuBuilder()
      .setCustomId(cid('server', 'setch', target))
      .setPlaceholder(`Pilih channel untuk: ${target}`)
      .addChannelTypes(ChannelType.GuildText);
    v.components[v.components.length - 1] = new ActionRowBuilder().addComponents(chSelect);
    return safeUpdate(interaction, v);
  }
  if (view === 'server' && action === 'setch') {
    if (!arg) return interaction.reply({ embeds: [errorEmbed('Pilih dulu channel yang mau diatur dari menu di atasnya.')], ephemeral: true });
    updateGuildConfig(interaction.guild.id, { [arg]: interaction.values[0] });
    return safeUpdate(interaction, serverView(interaction));
  }
  if (view === 'anime' && action === 'setch') {
    updateAnimeConfig(interaction.guild.id, { channelId: interaction.values[0] });
    return safeUpdate(interaction, animeView(interaction));
  }
  if (view === 'crypto' && action === 'setch') {
    updateCryptoConfig(interaction.guild.id, { channelId: interaction.values[0] });
    return safeUpdate(interaction, cryptoView(interaction));
  }
  if (view === 'notif' && action === 'setch') {
    settings.set('ownerNotifications.channelId', interaction.values[0]);
    settings.set('ownerNotifications.enabled', true); // otomatis aktifkan begitu channel di-set
    return safeUpdate(interaction, notifView());
  }
  if (view === 'music' && action === 'select') {
    if (interaction.values[0] === 'none') return interaction.reply({ embeds: [errorEmbed('Belum ada node buat dipilih.')], ephemeral: true });
    const { getNodes, getPreferredNode } = require('./nodeManager');
    const node = getNodes().find(n => n.name === interaction.values[0]);
    if (!node) return interaction.reply({ embeds: [errorEmbed('Node tidak ditemukan (mungkin baru saja dihapus).')], ephemeral: true });
    const isActive = getPreferredNode() === node.name;
    const embed = baseEmbed().setTitle(`Node: ${node.name}${isActive ? ' ⭐' : ''}`).addFields(
      { name: 'URL', value: `\`${node.url}\``, inline: true },
      { name: 'SSL', value: node.secure ? 'Ya' : 'Tidak', inline: true },
      { name: 'Status', value: isActive ? 'Node aktif/prioritas saat ini' : 'Bukan node prioritas (dipilih otomatis)', inline: true },
    );
    const confirmRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(cid('music', 'use', node.name)).setLabel(isActive ? 'Sudah Dipakai ✓' : 'Pakai Node Ini').setStyle(ButtonStyle.Success).setDisabled(isActive),
      new ButtonBuilder().setCustomId(cid('music', 'remove', node.name)).setLabel(`Hapus Node "${node.name}"`).setStyle(ButtonStyle.Danger),
    );
    return interaction.reply({ embeds: [embed], components: [confirmRow], ephemeral: true });
  }

  // ----- Users select & actions -----
  if (view === 'users' && action === 'pick') return safeUpdate(interaction, userManageView(interaction.values[0]));
  if (view === 'users' && (action === 'ban' || action === 'unban')) { setUserBanned(arg, action === 'ban'); return safeUpdate(interaction, userManageView(arg)); }
  if (view === 'users' && action === 'del') { deleteUser(arg); return safeUpdate(interaction, usersView(0)); }
  if (view === 'users' && action === 'reseteco') { resetEconomyForGuild(interaction.guild.id, arg); return safeUpdate(interaction, userManageView(arg)); }
  if (view === 'users' && action === 'resetlvl') { rpgEngine.setLevel(arg, 0, interaction.guild.id); return safeUpdate(interaction, userManageView(arg)); }

  // ----- Backup actions -----
  if (view === 'backup' && action === 'run') {
    await interaction.deferReply({ ephemeral: true }).catch(() => {});
    if (arg === 'backupnow') {
      try { const { sendBackupToOwner } = require('./backup'); await sendBackupToOwner(client, 'panel manual'); return interaction.editReply({ embeds: [successEmbed('Backup terkirim ke DM owner.')] }).catch(() => {}); }
      catch (e) { return interaction.editReply({ embeds: [errorEmbed('Backup gagal: ' + e.message)] }).catch(() => {}); }
    }
    if (arg === 'healnodes') {
      const { autoDiscoverAndConnect } = require('./nodeManager');
      const r = await autoDiscoverAndConnect(client, 8);
      return interaction.editReply({ embeds: [r.connected ? successEmbed(`Tersambung ke node ${r.connected.name}.`) : errorEmbed(`Belum berhasil (mencoba ${r.tried} node). Coba lagi nanti.`)] }).catch(() => {});
    }
  }

  // ----- Music node actions -----
  if (view === 'music' && action === 'discover') {
    await interaction.deferReply({ ephemeral: true });
    const { discoverOnlineNodes } = require('./nodeManager');
    const { source, nodes } = await discoverOnlineNodes(12);
    if (!nodes.length) return interaction.editReply({ embeds: [errorEmbed('Tidak ada node online yang ditemukan dari sumber discovery saat ini.')] });
    // Maks 10 (2 baris tombol @5) biar muat di 1 pesan - node komunitas SIFATNYA volatile (bisa
    // mati kapan aja), jadi owner yang milih sendiri mana yang mau dicoba, bukan bot nebak 1.
    const shortlist = nodes.slice(0, 10);
    const embed = baseEmbed()
      .setTitle('Node Online Ditemukan')
      .setDescription(shortlist.map((n, i) => `**${i + 1}. ${n.name}** — \`${n.url}\`${n.secure ? ' 🔒' : ''}`).join('\n'))
      .setFooter({ text: `Sumber: ${source} • Klik tombol buat langsung sambungkan & simpan node itu (node komunitas bisa aja mati sewaktu-waktu)` });
    const rows = [];
    for (let i = 0; i < shortlist.length; i += 5) {
      const row = new ActionRowBuilder();
      shortlist.slice(i, i + 5).forEach((n, j) => {
        const idx = i + j;
        row.addComponents(new ButtonBuilder().setCustomId(cid('music', 'pickdiscovered', String(idx))).setLabel(`${idx + 1}. ${n.name}`.slice(0, 80)).setStyle(ButtonStyle.Secondary));
      });
      rows.push(row);
    }
    const sent = await interaction.editReply({ embeds: [embed], components: rows });
    discoveryCache.set(sent.id, shortlist);
    setTimeout(() => discoveryCache.delete(sent.id), 10 * 60 * 1000); // buang cache lama biar gak numpuk di memori
    return;
  }
  if (view === 'music' && action === 'pickdiscovered') {
    await interaction.deferUpdate().catch(() => {});
    const list = discoveryCache.get(interaction.message.id);
    const node = list?.[Number(arg)];
    if (!node) return interaction.followUp({ embeds: [errorEmbed('Daftar ini sudah kadaluarsa (>10 menit), klik "Cari Node Online" lagi buat cari yang baru.')], ephemeral: true });
    const { nodeExists, connectAndSave } = require('./nodeManager');
    if (nodeExists(node.name)) return interaction.followUp({ embeds: [errorEmbed(`Node "${node.name}" sudah ada di daftarmu.`)], ephemeral: true });
    const ok = await connectAndSave(client, node);
    return interaction.followUp({
      embeds: [ok ? successEmbed(`Tersambung & disimpan: **${node.name}** (\`${node.url}\`).`) : errorEmbed(`Gagal konek ke **${node.name}** (mungkin baru saja mati/tidak stabil). Coba node lain dari daftar di atas.`)],
      ephemeral: true,
    });
  }
  if (view === 'music' && action === 'heal') {
    await interaction.deferReply({ ephemeral: true });
    const { autoDiscoverAndConnect } = require('./nodeManager');
    const r = await autoDiscoverAndConnect(client, 8);
    return interaction.editReply({ embeds: [r.connected ? successEmbed(`Tersambung ke node ${r.connected.name} (\`${r.connected.url}\`). Disimpan ke config.`) : errorEmbed(`Belum berhasil (mencoba ${r.tried} node). Coba lagi nanti.`)] }).catch(() => {});
  }
  if (view === 'music' && action === 'use') {
    try {
      const { usePreferredNode } = require('./nodeManager');
      await interaction.deferUpdate().catch(() => {});
      const { node, connected } = await usePreferredNode(client, arg);
      const followUp = connected
        ? successEmbed(`Node **${node.name}** sekarang jadi node aktif/prioritas. Koneksi voice baru bakal coba pakai node ini duluan.`)
        : errorEmbed(`Node **${node.name}** dijadikan prioritas, tapi belum berhasil konek (mungkin sedang down). Bakal dipakai begitu dia hidup lagi.`);
      await interaction.followUp({ embeds: [followUp], ephemeral: true }).catch(() => {});
      return interaction.editReply(musicView()).catch(() => {});
    } catch (e) {
      return interaction.followUp({ embeds: [errorEmbed(`Gagal: ${e.message}`)], ephemeral: true }).catch(() => {});
    }
  }
  if (view === 'music' && action === 'remove') {
    try {
      const { removeNode } = require('./nodeManager');
      removeNode(client, arg);
      return interaction.update(musicView());
    } catch (e) {
      return interaction.reply({ embeds: [errorEmbed(`Gagal hapus node: ${e.message}`)], ephemeral: true });
    }
  }
}

// ---------------- MODAL SUBMIT ----------------
async function handlePanelModal(interaction) {
  const [, section, kind, arg] = interaction.customId.split(':');
  const guildScoped = section === 'anime' || section === 'crypto';
  if (guildScoped) {
    if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
      return interaction.reply({ embeds: [errorEmbed('Butuh izin Manage Server untuk bagian ini.')], ephemeral: true }).catch(() => {});
    }
  } else if (!isOwner(interaction.user.id)) {
    return interaction.reply({ embeds: [errorEmbed('Khusus owner.')], ephemeral: true }).catch(() => {});
  }
  const field = (id) => interaction.fields.getTextInputValue(id);
  const intOf = (id, def) => { const v = parseInt(field(id), 10); return Number.isFinite(v) ? v : def; };

  try {
    if (section === 'settings' && kind === 'numbers') {
      settings.setMany({
        'registration.minAge': Math.max(1, intOf('minAge', 13)),
        dailyAmount: Math.max(0, intOf('daily', 500)),
        'xpPerMessage.min': Math.max(1, intOf('xpmin', 15)),
        'xpPerMessage.max': Math.max(1, intOf('xpmax', 25)),
        robSuccessRate: Math.min(1, Math.max(0, intOf('robrate', 40) / 100)),
      });
      return interaction.reply({ embeds: [successEmbed('Angka diperbarui dan tersimpan ke config.json.')], ephemeral: true });
    }
    if (section === 'settings' && kind === 'texts') {
      const color = field('embedColor').trim();
      settings.setMany({
        botName: field('botName').trim() || settings.get('botName'),
        footer: field('footer').trim(),
        embedColor: /^#?[0-9a-fA-F]{6}$/.test(color) ? (color.startsWith('#') ? color : '#' + color) : settings.get('embedColor'),
      });
      return interaction.reply({ embeds: [successEmbed('Tampilan diperbarui.')], ephemeral: true });
    }
    if (section === 'ai' && kind === 'maxhistory') {
      settings.set('ai.maxHistory', Math.min(30, Math.max(2, intOf('val', 12))));
      return interaction.reply({ embeds: [successEmbed('Panjang history AI diperbarui.')], ephemeral: true });
    }
    if (section === 'ai' && kind === 'cooldown') {
      settings.set('ai.cooldownSeconds', Math.min(120, Math.max(0, intOf('val', 6))));
      return interaction.reply({ embeds: [successEmbed('Cooldown chat AI diperbarui.')], ephemeral: true });
    }
    if (section === 'backup' && kind === 'interval') {
      settings.set('backup.intervalHours', Math.max(1, intOf('val', 12)));
      return interaction.reply({ embeds: [successEmbed('Interval backup diperbarui (berlaku pada siklus berikutnya).')], ephemeral: true });
    }
    if (section === 'games' && kind === 'durations') {
      settings.setMany({
        'games.quizDurationSeconds': Math.min(300, Math.max(5, intOf('quiz', 45))),
        'games.wordScrambleSeconds': Math.min(300, Math.max(5, intOf('scramble', 30))),
        'games.triviaSecondsPerQuestion': Math.min(120, Math.max(5, intOf('trivia', 15))),
      });
      return interaction.reply({ embeds: [successEmbed('Durasi game diperbarui dan langsung berlaku (tanpa restart).')], ephemeral: true });
    }
    if (section === 'crypto' && kind === 'watchlist') {
      const { normalizeSymbol } = require('./cryptoApi');
      const maxItems = settings.get('crypto.maxWatchlistPerGuild', 10);
      const raw = field('val').split(',').map(s => s.trim()).filter(Boolean);
      const normalized = [...new Set(raw.map(normalizeSymbol).filter(Boolean))].slice(0, maxItems);
      if (!normalized.length) return interaction.reply({ embeds: [errorEmbed('Watchlist tidak boleh kosong. Contoh: BTC,ETH,SOL')], ephemeral: true });
      updateCryptoConfig(interaction.guild.id, { watchlist: normalized.join(',') });
      return interaction.reply({ embeds: [successEmbed(`Watchlist diperbarui: ${normalized.join(', ')}${raw.length > maxItems ? ` (dipotong maks ${maxItems} simbol)` : ''}`)], ephemeral: true });
    }
    if (section === 'users' && kind === 'age') { setUserField(arg, 'age', Math.max(1, intOf('val', 13))); return interaction.reply({ embeds: [successEmbed('Umur user diperbarui.')], ephemeral: true }); }
    if (section === 'users' && kind === 'name') { setUserField(arg, 'username', field('val').slice(0, 40)); return interaction.reply({ embeds: [successEmbed('Username user diperbarui.')], ephemeral: true }); }
    if (section === 'users' && kind === 'note') { setUserField(arg, 'notes', field('val').slice(0, 500)); return interaction.reply({ embeds: [successEmbed('Catatan user disimpan.')], ephemeral: true }); }
  } catch (e) {
    if (e?.code === 10062) return; // interaction expired, abaikan
    return interaction.reply({ embeds: [errorEmbed('Gagal menyimpan: ' + e.message)], ephemeral: true }).catch(() => {});
  }
}

module.exports = { homeView, handlePanel, handlePanelModal, renderView };
