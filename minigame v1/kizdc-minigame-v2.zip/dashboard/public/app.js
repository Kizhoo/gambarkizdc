// ============================================================================
// KizhooBot Dashboard — frontend logic (vanilla JS)
// ============================================================================
const $ = (id) => document.getElementById(id);
let TOKEN = '';
let ws = null;
let guilds = [];

function authHeaders() { return { 'Authorization': `Bearer ${TOKEN}`, 'Content-Type': 'application/json' }; }
function escapeHtml(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function fmtNum(n) { return (Math.round(Number(n) || 0)).toLocaleString('id-ID'); }
function fmtKzc(n) { return fmtNum(n) + ' KZC'; }
function fmtPct(n) { const v = Number(n) || 0; return (v > 0 ? '+' : '') + v.toFixed(3) + '%'; }
function mountIcon(parent, id, category, size) {
  if (!parent || !window.ItemIcons) return;
  const c = document.createElement('canvas');
  window.ItemIcons.draw(c, id, category, size);
  parent.appendChild(c);
  return c;
}

// ---------- LOGIN ----------
$('btnLogin').addEventListener('click', async () => {
  const token = $('token').value.trim();
  const res = await fetch('/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token }) });
  if (res.ok) {
    TOKEN = token;
    showApp();
  } else {
    $('loginError').textContent = 'Token salah';
  }
});

// ---------- TABS ----------
const TITLES = { home: 'Home', music: 'Musik', chat: 'Chat as Bot', tts: 'Text-to-Speech', dengerin: 'Dengerin VC', monitor: 'Monitor', server: 'Server Config', leaderboard: 'Ranking', economy: 'Ekonomi Kizco', catalog: 'Katalog Item', giveaways: 'Giveaway', moderation: 'Moderasi', users: 'Manajemen User', settings: 'Settings' };
document.querySelectorAll('.nav-item').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach((b) => b.classList.remove('active'));
    document.querySelectorAll('.pane').forEach((p) => p.classList.remove('active'));
    btn.classList.add('active');
    const t = btn.dataset.tab;
    $('tab-' + t).classList.add('active');
    $('pageTitle').textContent = TITLES[t] || t;
    if (t === 'home') loadStats();
    if (t === 'music') loadMusic();
    if (t === 'server') loadGuildConfig();
    if (t === 'leaderboard') loadLeaderboard();
    if (t === 'economy') loadEconomy();
    if (t === 'catalog') loadCatalog();
    if (t === 'giveaways') loadGiveaways();
    if (t === 'moderation') loadModeration();
    if (t === 'users') loadUsers();
    if (t === 'settings') { loadGlobalSettings(); loadAnalytics(); }
  });
});

// ---------- POPULATE GUILDS ----------
function fillGuilds() {
  const selects = ['chatGuild', 'ttsGuild', 'listenGuild', 'monGuild', 'cfgGuild', 'musicGuild', 'lbGuild', 'modGuild', 'econGuild', 'catalogGuild', 'userGuild'];
  selects.forEach((id) => {
    const sel = $(id);
    if (!sel) return;
    sel.innerHTML = '<option value="">Pilih server...</option>' + guilds.map((g) => `<option value="${g.id}">${escapeHtml(g.name)}</option>`).join('');
  });
}

function fillChannels(guildSelId, channelSelId, type) {
  const guild = guilds.find((g) => g.id === $(guildSelId).value);
  const sel = $(channelSelId);
  sel.innerHTML = '<option value="">Pilih channel...</option>';
  if (!guild) return;
  const list = type === 'text' ? guild.channels : guild.voiceChannels;
  sel.innerHTML += list.map((c) => `<option value="${c.id}"># ${escapeHtml(c.name)}</option>`).join('');
}

$('chatGuild').addEventListener('change', () => fillChannels('chatGuild', 'chatChannel', 'text'));
$('ttsGuild').addEventListener('change', () => fillChannels('ttsGuild', 'ttsChannel', 'voice'));
$('listenGuild').addEventListener('change', () => fillChannels('listenGuild', 'listenChannel', 'voice'));
$('monGuild').addEventListener('change', () => { /* filter monitor oleh guild */ });

const VOICES = ['Brian', 'Amy', 'Emma', 'Geraint', 'Russell', 'Nicole', 'Joey', 'Matthew', 'Joanna'];
$('ttsVoice').innerHTML = VOICES.map((v) => `<option>${v}</option>`).join('');

// ---------- API HELPERS ----------
async function loadGuilds() {
  const res = await fetch('/api/guilds', { headers: authHeaders() });
  guilds = await res.json();
  fillGuilds();
}

// ---------- SEND CHAT ----------
$('btnSend').addEventListener('click', async () => {
  const channelId = $('chatChannel').value;
  const text = $('chatText').value;
  if (!channelId || !text.trim()) return setStatus('chatStatus', 'Pilih channel & isi pesan dulu', 'err');
  const res = await fetch('/api/send', { method: 'POST', headers: authHeaders(), body: JSON.stringify({ channelId, text }) });
  const data = await res.json();
  if (res.ok) { setStatus('chatStatus', 'Terkirim', 'ok'); $('chatText').value = ''; }
  else setStatus('chatStatus', 'Gagal: ' + data.error, 'err');
});

// ---------- TTS ----------
$('btnTts').addEventListener('click', async () => {
  const guildId = $('ttsGuild').value;
  const voiceChannelId = $('ttsChannel').value;
  const text = $('ttsText').value;
  if (!guildId || !voiceChannelId || !text.trim()) return setStatus('ttsStatus', 'Pilih server, voice channel & isi teks', 'err');
  setStatus('ttsStatus', 'Memproses TTS...', '');
  const res = await fetch('/api/tts', { method: 'POST', headers: authHeaders(), body: JSON.stringify({ guildId, voiceChannelId, text }) });
  const data = await res.json();
  if (res.ok) setStatus('ttsStatus', 'Berhasil bicara di voice', 'ok');
  else setStatus('ttsStatus', 'Gagal: ' + data.error, 'err');
});

function setStatus(id, text, cls) {
  const el = $(id);
  el.textContent = text;
  el.className = 'status ' + (cls || '');
}

// ---------- DENGERIN (audio streaming VC) ----------
let listening = false;
let audioCtx = null;
let scriptNode = null;
let pcmQueue = [];
let pcmReadIdx = 0;

function ensureAudio() {
  if (audioCtx) return;
  audioCtx = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 48000 });
  scriptNode = audioCtx.createScriptProcessor(4096, 2, 2);
  scriptNode.onaudioprocess = (e) => {
    const outL = e.outputBuffer.getChannelData(0);
    const outR = e.outputBuffer.getChannelData(1);
    for (let i = 0; i < outL.length; i++) {
      outL[i] = pcmQueue[pcmReadIdx] || 0; pcmReadIdx++;
      outR[i] = pcmQueue[pcmReadIdx] || 0; pcmReadIdx++;
    }
    if (pcmReadIdx > 48000 * 8) { pcmQueue.splice(0, pcmReadIdx); pcmReadIdx = 0; }
  };
  scriptNode.connect(audioCtx.destination);
}

function onPcm(arrayBuffer) {
  const int16 = new Int16Array(arrayBuffer);
  let peak = 0;
  for (let i = 0; i < int16.length; i++) {
    const v = int16[i] / 32768;
    pcmQueue.push(v);
    if (Math.abs(v) > peak) peak = Math.abs(v);
  }
  const fill = $('listenPeak');
  if (fill) fill.style.width = Math.min(100, peak * 150) + '%';
}

$('btnListen').addEventListener('click', async () => {
  const guildId = $('listenGuild').value;
  const channelId = $('listenChannel').value;

  if (listening) {
    await fetch('/api/listen/stop', { method: 'POST', headers: authHeaders(), body: JSON.stringify({ guildId }) });
    listening = false;
    $('btnListen').textContent = 'Start Listening';
    $('btnListen').className = 'btn danger';
    $('listenLive').classList.add('hidden');
    setStatus('listenStatus', 'Berhenti.', '');
    return;
  }

  if (!guildId || !channelId) return setStatus('listenStatus', 'Pilih server & voice channel dulu', 'err');
  ensureAudio();
  await audioCtx.resume().catch(() => {});
  setStatus('listenStatus', 'Menghubungkan...', '');
  const res = await fetch('/api/listen/start', { method: 'POST', headers: authHeaders(), body: JSON.stringify({ guildId, voiceChannelId: channelId }) });
  const data = await res.json();
  if (res.ok) {
    listening = true;
    $('btnListen').textContent = 'Stop Listening';
    $('btnListen').className = 'btn success';
    $('listenLive').classList.remove('hidden');
    setStatus('listenStatus', 'Mendengarkan...', 'ok');
  } else {
    setStatus('listenStatus', 'Gagal: ' + data.error, 'err');
  }
});

// ---------- WEBSOCKET (monitoring) ----------
function connectWs() {
  const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
  ws = new WebSocket(`${proto}//${location.host}/?token=${TOKEN}`);
  ws.binaryType = 'arraybuffer';
  ws.onopen = () => {
    const dot = $('connDot'), txt = $('connText');
    if (dot) dot.className = 'conn-dot on';
    if (txt) txt.textContent = 'Connected';
  };
  ws.onmessage = (e) => {
    if (typeof e.data === 'string') {
      const { type, data } = JSON.parse(e.data);
      if (type === 'hello') { guilds = data.guilds; fillGuilds(); }
      if (type === 'message') appendMessage(data);
      if (type === 'voice') appendVoice(data);
      if (type === 'economy') onEconomyPush(data);
    } else {
      onPcm(e.data);
    }
  };
  ws.onclose = () => {
    const dot = $('connDot'), txt = $('connText');
    if (dot) dot.className = 'conn-dot';
    if (txt) txt.textContent = 'Reconnecting...';
    if (TOKEN) setTimeout(connectWs, 3000);
  };
}

function appendMessage(m) {
  const feed = $('msgFeed');
  if ($('monGuild').value && m.guildId !== $('monGuild').value) return;
  const div = document.createElement('div');
  div.className = 'msg';
  const stickers = m.stickers?.length ? m.stickers.map(() => `<span class="tag">stiker</span>`).join('') : '';
  const comp = m.components ? `<span class="tag">tombol</span>` : '';
  const attach = m.attachments?.map((a) => {
    if (a.type?.startsWith('image/')) return `<span class="attach"><img src="${a.url}" alt="${escapeHtml(a.name)}" /></span>`;
    return `<span class="attach">${escapeHtml(a.name)}</span>`;
  }).join('') || '';
  const embed = m.embeds?.length ? `<span class="tag">embed</span>` : '';
  div.innerHTML = `
    <div class="head"><img src="${m.authorAvatar}" /><span class="name">${escapeHtml(m.author)}</span><span class="ch">#${escapeHtml(m.channelName)}</span>${stickers}${comp}${embed}</div>
    ${m.content ? `<div class="body">${escapeHtml(m.content)}</div>` : ''}
    ${attach}`;
  feed.prepend(div);
  while (feed.children.length > 100) feed.removeChild(feed.lastChild);
}

function appendVoice(v) {
  const feed = $('voiceFeed');
  const div = document.createElement('div');
  div.className = 'voice';
  const action = v.channelId ? `masuk <b>${escapeHtml(v.channelName)}</b>` : `keluar voice`;
  div.innerHTML = `<span class="dot ${v.speaking ? 'speaking' : ''}"></span><b>${escapeHtml(v.username)}</b> ${action}`;
  feed.prepend(div);
  while (feed.children.length > 100) feed.removeChild(feed.lastChild);
}

// ---------- SERVER CONFIG ----------
const GUILD_BOOL_FIELDS = [
  ['welcomeEnabled', 'Welcome'],
  ['goodbyeEnabled', 'Goodbye'],
  ['automodEnabled', 'Automod'],
  ['antiLinkEnabled', 'Anti-link'],
  ['antiSpamEnabled', 'Anti-spam'],
  ['antiraidEnabled', 'Anti-raid'],
  ['modLogEnabled', 'Mod log'],
];
let guildCfgCache = {};

function cfgRow(label, inner) {
  const div = document.createElement('div');
  div.className = 'cfg-row';
  div.innerHTML = `<label>${label}</label>${inner}`;
  return div;
}

async function loadGuildConfig() {
  const guildId = $('cfgGuild').value;
  if (!guildId) return;
  const res = await fetch(`/api/guild/${guildId}`, { headers: authHeaders() });
  guildCfgCache = await res.json();
  const form = $('guildCfgForm');
  form.innerHTML = '';
  GUILD_BOOL_FIELDS.forEach(([key, label]) => {
    form.appendChild(cfgRow(label, `<input type="checkbox" data-key="${key}" ${guildCfgCache[key] ? 'checked' : ''} />`));
  });
  const styleOpts = [['embed', 'Embed'], ['card', 'Kartu Gambar']].map(([v, l]) => `<option value="${v}" ${(guildCfgCache.welcomeStyle || 'embed') === v ? 'selected' : ''}>${l}</option>`).join('');
  form.appendChild(cfgRow('Gaya welcome', `<select data-key="welcomeStyle">${styleOpts}</select>`));
  form.appendChild(cfgRow('Warna border (hex)', `<input type="text" data-key="welcomeColor" value="${escapeHtml(guildCfgCache.welcomeColor || 'green')}" />`));
}

$('cfgGuild').addEventListener('change', loadGuildConfig);
$('btnSaveGuild').addEventListener('click', async () => {
  const guildId = $('cfgGuild').value;
  if (!guildId) return;
  const changes = {};
  document.querySelectorAll('#guildCfgForm [data-key]').forEach((el) => {
    const key = el.dataset.key;
    changes[key] = el.type === 'checkbox' ? (el.checked ? 1 : 0) : el.value;
  });
  const res = await fetch(`/api/guild/${guildId}`, { method: 'POST', headers: authHeaders(), body: JSON.stringify(changes) });
  setStatus('guildCfgStatus', res.ok ? 'Tersimpan' : 'Gagal', res.ok ? 'ok' : 'err');
});

// ---------- MANAJEMEN USER ----------
let usersCache = [];
$('btnRefreshUsers').addEventListener('click', loadUsers);
$('userSearch').addEventListener('input', debounce(loadUsers, 300));
$('userGuild').addEventListener('change', loadUsers);

function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }

async function loadUsers() {
  const q = ($('userSearch').value || '').trim();
  const gid = $('userGuild').value;
  const params = new URLSearchParams();
  if (gid) params.set('guildId', gid);
  if (q) params.set('q', q);
  const res = await fetch('/api/users?' + params.toString(), { headers: authHeaders() });
  usersCache = await res.json();
  renderUsers();
}

function renderUsers() {
  const box = $('usersList');
  const gid = $('userGuild').value;
  const hasBal = !!gid;
  if (!usersCache.length) { box.innerHTML = '<div class="empty">Tidak ada user terdaftar.</div>'; return; }
  box.innerHTML = `<table>
    <thead><tr><th>User</th><th>ID</th><th>Umur</th><th>Status</th>${hasBal ? '<th>Dompet</th><th>Bank</th>' : ''}<th>Aksi</th></tr></thead>
    <tbody>` + usersCache.map(u => `
      <tr data-id="${u.userId}">
        <td>${escapeHtml(u.username)}</td>
        <td class="num muted">${u.userId}</td>
        <td>${u.age ?? '-'}</td>
        <td>${u.banned ? '<span class="tag banned">Blokir</span>' : '<span class="tag ok">Aktif</span>'}</td>
        ${hasBal ? `<td class="num">${fmtNum(u.balance)}</td><td class="num">${fmtNum(u.bank)}</td>` : ''}
        <td>
          <button class="btn mini-btn" data-act="ban">${u.banned ? 'Buka' : 'Blokir'}</button>
          <button class="btn mini-btn" data-act="edit">Edit</button>
          ${hasBal ? '<button class="btn mini-btn" data-act="saldo">Saldo</button>' : ''}
          <button class="btn danger mini-btn" data-act="delete">Hapus</button>
        </td>
      </tr>`).join('') + `</tbody></table>`;
  box.querySelectorAll('[data-act]').forEach((btn) => btn.addEventListener('click', () => handleUserAction(btn)));
}

function handleUserAction(btn) {
  const userId = btn.closest('tr').dataset.id;
  const user = usersCache.find(u => u.userId === userId);
  const act = btn.dataset.act;
  if (act === 'ban') {
    const banned = user.banned ? false : true;
    fetch(`/api/users/${userId}/ban`, { method: 'POST', headers: authHeaders(), body: JSON.stringify({ banned }) }).then(loadUsers);
  } else if (act === 'delete') {
    if (!confirm('Hapus user ' + userId + '?')) return;
    fetch(`/api/users/${userId}`, { method: 'DELETE', headers: authHeaders() }).then(loadUsers);
  } else if (act === 'edit') {
    showUserEdit(user);
  } else if (act === 'saldo') {
    showUserBalance(user);
  }
}

function showUserEdit(user) {
  const box = $('usersList');
  const form = document.createElement('div');
  form.className = 'inline-edit';
  form.innerHTML = `
    <span class="small muted">Edit ${escapeHtml(user.username)}:</span>
    <input id="edUsername" value="${escapeHtml(user.username)}" placeholder="Username" />
    <input id="edAge" type="number" value="${user.age ?? ''}" placeholder="Umur" />
    <button id="edSave" class="btn primary mini-btn">Simpan</button>
    <button id="edCancel" class="btn mini-btn">Batal</button>`;
  box.prepend(form);
  $('edSave').onclick = async () => {
    await fetch(`/api/users/${user.userId}/edit`, { method: 'POST', headers: authHeaders(), body: JSON.stringify({ username: $('edUsername').value, age: Number($('edAge').value) || 0 }) });
    loadUsers();
  };
  $('edCancel').onclick = () => loadUsers();
}

function showUserBalance(user) {
  const gid = $('userGuild').value;
  const box = $('usersList');
  const form = document.createElement('div');
  form.className = 'inline-edit';
  form.innerHTML = `
    <span class="small muted">Saldo ${escapeHtml(user.username)}:</span>
    <input id="balAmt" type="number" placeholder="Jumlah" />
    <button data-bact="setBalance" class="btn mini-btn">Set Dompet</button>
    <button data-bact="addBalance" class="btn mini-btn">Tambah</button>
    <button data-bact="setBank" class="btn mini-btn">Set Bank</button>
    <button data-bact="reset" class="btn danger mini-btn">Reset</button>
    <button id="balCancel" class="btn mini-btn">Batal</button>`;
  box.prepend(form);
  form.querySelectorAll('[data-bact]').forEach((b) => b.onclick = async () => {
    const amount = Number($('balAmt').value) || 0;
    await fetch(`/api/users/${user.userId}/economy`, { method: 'POST', headers: authHeaders(), body: JSON.stringify({ guildId: gid, action: b.dataset.bact, amount }) });
    loadUsers();
  });
  $('balCancel').onclick = () => loadUsers();
}

// ---------- SETTINGS (global) ----------
const GLOBAL_FIELDS = [
  ['botName', 'Nama bot', 'text'],
  ['footer', 'Footer embed', 'text'],
  ['embedColor', 'Warna embed', 'text'],
  ['successColor', 'Warna sukses', 'text'],
  ['errorColor', 'Warna error', 'text'],
  ['warnColor', 'Warna warning', 'text'],
  ['dailyAmount', 'Daily', 'number'],
  ['workMin', 'Work min', 'number'],
  ['workMax', 'Work max', 'number'],
  ['robSuccessRate', 'Peluang rob (0-1)', 'number'],
];

async function loadGlobalSettings() {
  const res = await fetch('/api/settings', { headers: authHeaders() });
  const cfg = await res.json();
  const form = $('globalCfgForm');
  form.innerHTML = '';
  GLOBAL_FIELDS.forEach(([key, label, type]) => {
    form.appendChild(cfgRow(label, `<input type="${type}" data-key="${key}" value="${escapeHtml(cfg[key] ?? '')}" step="0.01" />`));
  });
  form.appendChild(cfgRow('NSFW', `<input type="checkbox" data-key="isNsfw" ${cfg.isNsfw ? 'checked' : ''} />`));
}

$('btnSaveGlobal').addEventListener('click', async () => {
  const changes = {};
  document.querySelectorAll('#globalCfgForm [data-key]').forEach((el) => {
    const key = el.dataset.key;
    if (el.type === 'checkbox') changes[key] = el.checked;
    else if (el.type === 'number') changes[key] = Number(el.value);
    else changes[key] = el.value;
  });
  const res = await fetch('/api/settings', { method: 'POST', headers: authHeaders(), body: JSON.stringify(changes) });
  setStatus('globalCfgStatus', res.ok ? 'Tersimpan' : 'Gagal', res.ok ? 'ok' : 'err');
});

// ---------- ANALITIK ----------
async function loadAnalytics() {
  const res = await fetch('/api/analytics', { headers: authHeaders() });
  const data = await res.json();
  const box = $('analyticsBox');
  if (box) {
    if (!data.commandCounts || !data.commandCounts.length) {
      box.innerHTML = 'Belum ada command yang dipakai sejak bot restart.';
      return;
    }
    box.innerHTML = `Total command: <b>${data.totalExecuted}</b><br>` + data.commandCounts.slice(0, 10).map(([name, count]) => `${escapeHtml(name)}: <b>${count}</b>`).join(' &middot; ');
  }
}

// ---------- MUSIK ----------
let musicGuildId = '';
async function loadMusic() {
  const gid = $('musicGuild').value;
  if (!gid) return;
  musicGuildId = gid;
  const res = await fetch(`/api/music/${gid}`, { headers: authHeaders() });
  const m = await res.json();
  const info = $('musicInfo');
  if (!m.playing) { info.textContent = 'Tidak ada musik yang diputar.'; $('musicQueue').innerHTML = ''; return; }
  const state = m.paused ? 'Dijeda' : 'Sedang Memutar';
  info.innerHTML = `<b>${state}</b> &mdash; <b>${escapeHtml(m.title)}</b> oleh ${escapeHtml(m.author || '-')}<br><span class="muted">Volume ${m.volume}% &middot; Loop ${m.loop} &middot; Antrian ${m.queueLength}</span>`;
  $('musicVol').value = m.volume;
  $('musicQueue').innerHTML = m.queue.length ? m.queue.map((q, i) => `<div class="msg"><div class="body">${i + 1}. <b>${escapeHtml(q.title)}</b> &mdash; ${escapeHtml(q.author || '-')}</div></div>`).join('') : '<div class="small muted">Antrian kosong.</div>';
}
$('musicGuild').addEventListener('change', loadMusic);
document.querySelectorAll('[data-ma]').forEach((btn) => {
  btn.addEventListener('click', async () => {
    if (!musicGuildId) return;
    const action = btn.dataset.ma;
    const value = action === 'volume' ? $('musicVol').value : undefined;
    await fetch(`/api/music/${musicGuildId}/action`, { method: 'POST', headers: authHeaders(), body: JSON.stringify({ action, value }) });
    loadMusic();
  });
});

// ---------- LEADERBOARD ----------
async function loadLeaderboard() {
  const gid = $('lbGuild').value;
  if (!gid) return;
  const res = await fetch(`/api/leaderboard/${gid}`, { headers: authHeaders() });
  const d = await res.json();
  $('lbEco').innerHTML = d.economy.length ? d.economy.map((e) => `<div class="msg"><div class="body"><b>#${e.rank}</b> ${e.userId} &mdash; ${fmtKzc(e.balance)} (bank ${fmtNum(e.bank)})</div></div>`).join('') : '<div class="small muted">Belum ada data.</div>';
  $('lbLevel').innerHTML = d.level.length ? d.level.map((l) => `<div class="msg"><div class="body"><b>#${l.rank}</b> ${l.userId} &mdash; Level ${l.level} (${l.xp} XP)</div></div>`).join('') : '<div class="small muted">Belum ada data.</div>';
}
$('lbGuild').addEventListener('change', loadLeaderboard);

// ---------- EKONOMI KIZCO ----------
let econChart = null;
let itemChart = null;

function renderEconSummary(s) {
  if (!s) return;
  if (s.priceIndex != null) $('ecPrice').textContent = s.priceIndex;
  if (s.inflationPct != null) $('ecInflation').textContent = s.inflationLabel ? `${s.inflationLabel} ${fmtPct(s.inflationPct)}` : fmtPct(s.inflationPct);
  if (s.moneySupply != null) $('ecMoney').textContent = fmtKzc(s.moneySupply);
  if (s.phaseLabel) $('ecPhase').textContent = s.phaseLabel;
  if (s.health != null) $('ecHealth').textContent = s.health + '/100';
}

function onEconomyPush(data) {
  if (!data || !data.guildId || data.guildId !== $('econGuild').value) return;
  renderEconSummary(data.summary);
}

function drawEconChart(hist) {
  const canvas = $('econChart');
  if (typeof Chart === 'undefined' || !hist || hist.length < 2) return;
  const labels = hist.map(p => { const d = new Date(p.timestamp); return `${d.getHours()}:${String(d.getMinutes()).padStart(2, '0')}`; });
  if (econChart) econChart.destroy();
  econChart = new Chart(canvas, {
    type: 'line',
    data: {
      labels,
      datasets: [
        { label: 'Indeks Harga', data: hist.map(p => p.priceIndex), borderColor: '#4f8cff', backgroundColor: 'rgba(79,140,255,0.15)', fill: true, tension: 0.3, yAxisID: 'y' },
        { label: 'Uang Beredar', data: hist.map(p => p.moneySupply), borderColor: '#ffc14d', backgroundColor: 'rgba(255,193,77,0.1)', fill: false, tension: 0.3, yAxisID: 'y1' },
      ],
    },
    options: {
      responsive: true,
      plugins: { legend: { labels: { color: '#e6e9ef' } } },
      scales: {
        x: { ticks: { color: '#8a93a6' }, grid: { color: 'rgba(255,255,255,0.05)' } },
        y: { position: 'left', ticks: { color: '#4f8cff' }, grid: { color: 'rgba(255,255,255,0.05)' } },
        y1: { position: 'right', ticks: { color: '#ffc14d' }, grid: { drawOnChartArea: false } },
      },
    },
  });
}

async function loadEconomy() {
  const gid = $('econGuild').value;
  if (!gid) return;
  try {
    const s = await (await fetch(`/api/economy/${gid}`, { headers: authHeaders() })).json();
    renderEconSummary(s);
    const hist = await (await fetch(`/api/economy/${gid}/history`, { headers: authHeaders() })).json();
    drawEconChart(hist);
    const txs = await (await fetch(`/api/economy/${gid}/transactions`, { headers: authHeaders() })).json();
    $('econTx').innerHTML = txs.length ? txs.map(t => {
      const sign = t.amount >= 0 ? '+' : '';
      return `<div class="msg"><div class="body"><b>${sign}${fmtKzc(t.amount)}</b> <span class="muted">(${t.type})</span>${t.actorId ? ` &middot; ${t.actorId}` : ''}</div></div>`;
    }).join('') : '<div class="small muted">Belum ada transaksi.</div>';
    const rep = await (await fetch(`/api/economy/${gid}/report`, { headers: authHeaders() })).json();
    $('econReport').innerHTML = rep.length ? rep.slice(0, 8).map(r => `<div class="msg"><div class="body">${escapeHtml(r.decision)}<br><span class="muted"><t:${Math.floor(r.timestamp / 1000)}:R></span></div></div>`).join('') : '<div class="small muted">Belum ada laporan AI.</div>';
    loadEconItems();
  } catch (e) {
    console.error('loadEconomy error:', e);
  }
}
$('econGuild').addEventListener('change', loadEconomy);

async function loadEconItems() {
  const gid = $('econGuild').value;
  if (!gid) return;
  try {
    const items = await (await fetch(`/api/economy/${gid}/items`, { headers: authHeaders() })).json();
    $('econItem').innerHTML = '<option value="">Pilih item...</option>' + items.map(i => `<option value="${i.id}">${escapeHtml(i.name)}</option>`).join('');
  } catch (e) { console.error('loadEconItems error:', e); }
}
$('econItem').addEventListener('change', async () => {
  const gid = $('econGuild').value;
  const id = $('econItem').value;
  if (!gid || !id) return;
  try {
    const hist = await (await fetch(`/api/economy/${gid}/item/${id}`, { headers: authHeaders() })).json();
    drawItemChart(hist);
  } catch (e) { console.error('item chart error:', e); }
});
function drawItemChart(hist) {
  const canvas = $('itemChart');
  if (typeof Chart === 'undefined' || !hist || hist.length < 2) return;
  const labels = hist.map(p => { const d = new Date(p.t); return `${d.getHours()}:${String(d.getMinutes()).padStart(2, '0')}`; });
  if (itemChart) itemChart.destroy();
  itemChart = new Chart(canvas, {
    type: 'line',
    data: { labels, datasets: [{ label: 'Harga', data: hist.map(p => p.price), borderColor: '#34d399', backgroundColor: 'rgba(52,211,153,0.15)', fill: true, tension: 0.3 }] },
    options: {
      responsive: true,
      plugins: { legend: { labels: { color: '#e6e9ef' } } },
      scales: { x: { ticks: { color: '#8a93a6' }, grid: { color: 'rgba(255,255,255,0.05)' } }, y: { ticks: { color: '#34d399' }, grid: { color: 'rgba(255,255,255,0.05)' } } },
    },
  });
}

// ---------- GIVEAWAYS ----------
async function loadGiveaways() {
  const res = await fetch('/api/giveaways', { headers: authHeaders() });
  const list = await res.json();
  $('giveawayList').innerHTML = list.length ? list.map((g) => `<div class="msg"><div class="body"><b>${escapeHtml(g.prize)}</b> &middot; ${g.winnerCount} pemenang &middot; berakhir <t:${Math.floor(g.endTime / 1000)}:R></div></div>`).join('') : '<div class="small muted">Tidak ada giveaway aktif.</div>';
}

// ---------- MODERASI ----------
async function loadModeration() {
  const gid = $('modGuild').value;
  if (!gid) return;
  const res = await fetch(`/api/warnings/${gid}`, { headers: authHeaders() });
  const list = await res.json();
  $('warningList').innerHTML = list.length ? list.map((w) => `<div class="msg"><div class="body"><b>${w.userId}</b> &mdash; ${escapeHtml(w.reason || 'tanpa alasan')}<br><span class="muted">oleh ${w.moderatorId} &middot; <t:${Math.floor(w.timestamp / 1000)}:R></span></div></div>`).join('') : '<div class="small muted">Tidak ada warning.</div>';
}
$('modGuild').addEventListener('change', loadModeration);

// ---------- INIT ----------
function showApp() {
  $('login').classList.add('hidden');
  $('app').classList.remove('hidden');
  loadGuilds();
  connectWs();
  loadStats();
}

// ---------- STATS ----------
function formatUptime(sec) {
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60);
  return h > 0 ? `${h}j ${m}m` : `${m}m`;
}
async function loadStats() {
  try {
    const res = await fetch('/api/stats', { headers: authHeaders() });
    const s = await res.json();
    $('stGuilds').textContent = s.guilds ?? 0;
    $('stMembers').textContent = s.totalMembers ?? 0;
    $('stRegistered').textContent = s.registeredUsers ?? 0;
    $('stCommands').textContent = s.commands ?? 0;
    $('stPing').textContent = (s.ping ?? 0) + 'ms';
    $('stUptime').textContent = formatUptime(s.uptimeSeconds || 0);
  } catch {}
  try {
    const res2 = await fetch('/api/analytics', { headers: authHeaders() });
    const a = await res2.json();
    const box = $('homeAnalytics');
    if (!a.commandCounts || !a.commandCounts.length) { box.textContent = 'Belum ada command dipakai sejak restart.'; }
    else box.innerHTML = a.commandCounts.slice(0, 8).map(([n, c]) => `<b>${escapeHtml(n)}</b>: ${c}`).join(' &middot; ');
  } catch {}
}

$('btnLogout').addEventListener('click', () => {
  window.location.href = '/auth/logout';
});

// cek session OAuth2 dulu, fallback token
fetch('/api/me').then((r) => {
  if (r.ok) return showApp();
  if (TOKEN) showApp();
}).catch(() => { if (TOKEN) showApp(); });

// ---------- KATALOG ITEM ----------
async function loadCatalog() {
  const gid = $('catalogGuild').value;
  if (!gid) return;
  const res = await fetch(`/api/economy/${gid}/catalog`, { headers: authHeaders() });
  const list = await res.json();
  const box = $('catalogList');
  box.innerHTML = list.map(it => `
    <div class="msg cat-row">
      <div class="body"><span class="cat-ic" data-ic="${it.id}" data-cat="${it.category}"></span> <b>${escapeHtml(it.name)}</b> <span class="muted">\`${it.id}\` &middot; ${it.category} &middot; base ${fmtNum(it.basePrice)}</span>
        ${it.aiGenerated ? '<span class="tag">AI</span>' : ''} ${it.active ? '<span class="tag ok">aktif</span>' : '<span class="tag banned">nonaktif</span>'}
        <button class="btn mini-btn" data-toggle="${it.id}" style="float:right">${it.active ? 'Nonaktifkan' : 'Aktifkan'}</button>
      </div>
    </div>`).join('');
  box.querySelectorAll('.cat-ic').forEach(el => mountIcon(el, el.dataset.ic, el.dataset.cat, 28));
  box.querySelectorAll('[data-toggle]').forEach(b => b.addEventListener('click', async () => {
    await fetch(`/api/economy/${gid}/catalog/${b.dataset.toggle}/toggle`, { method: 'POST', headers: authHeaders() });
    loadCatalog();
  }));
}
$('catalogGuild').addEventListener('change', loadCatalog);

// ---------- BANK SENTRAL ----------
function bankAction(action, extra = {}) {
  const gid = $('econGuild').value;
  if (!gid) return setStatus('bankStatus', 'Pilih server dulu', 'err');
  return fetch(`/api/economy/${gid}/bank`, { method: 'POST', headers: authHeaders(), body: JSON.stringify({ action, ...extra }) })
    .then(async r => { const d = await r.json(); if (r.ok) { setStatus('bankStatus', 'Tersimpan', 'ok'); loadEconomy(); } else setStatus('bankStatus', d.error, 'err'); });
}
$('btnBankPrint').addEventListener('click', () => bankAction('print', { amount: Number($('bankPrintAmt').value) || 0 }));
$('btnBankBurn').addEventListener('click', () => bankAction('burn', { amount: Number($('bankBurnAmt').value) || 0 }));
$('btnBankRate').addEventListener('click', () => bankAction('rate', { jenis: $('bankRateType').value, nilai: Number($('bankRateVal').value) || 0 }));
