// ============================================================================
// BATTLE ENGINE TURN-BASED (PvE) — "Kizhoo Adventure" Tahap 3
// ----------------------------------------------------------------------------
// State battle disimpan in-memory per user (sesi interaktif via tombol). Combat
// giliran-giliran: Serang / Skill / Bertahan / Kabur. Skill diambil dari skill
// tree class yang sudah dibuka. Menang -> XP+gold+counter (via engine/rdb).
//
// startBattle(userId, guildId, monsterId?) -> state
// getBattle(userId) / endBattle(userId)
// playerAction(userId, action, payload) -> { state, events }
// Semua angka murni logika; render pixel-art di rpgCard.renderBattleScene.
// ============================================================================
const D = require('./rpgData');
const rdb = require('../database/rpgDb');
const engine = require('./rpgEngine');
const items = require('./rpgItems');
const { monsterSprite } = require('./rpgSprites');
const { getBattleBackgrounds } = require('./rpgCard');
const { t, guildLang } = require('./i18n');

// Bahasa aktif untuk sebuah sesi battle (default id).
function stateLang(state) { return guildLang({ id: state.guildId }); }

const sessions = new Map(); // userId -> state

function rand(min, max) { return Math.random() * (max - min) + min; }

function activeSkillsFor(char) {
  const owned = rdb.getSkills(char.userId);
  const list = [];
  for (const s of owned) {
    const def = D.skillById(char.className, s.skillId);
    if (def && def.type === 'active') list.push({ id: def.id, name: def.name, emoji: def.emoji, level: s.level, effect: def.effect, mp: def.effect.mp || 0 });
  }
  return list;
}

function buildPlayer(char) {
  const stats = engine.computeStats(char);
  const cls = D.CLASSES[char.className];
  // NEW: efek gabungan seluruh equipment (senjata+zirah+aksesoris) — lihat rpgItems.equipEffects.
  const eff = items.equipEffects(char);
  return {
    userId: char.userId, name: null, classKey: char.className, rankKey: char.rankKey, level: char.level,
    hp: stats.hp, hpMax: stats.hp, mp: stats.mp, mpMax: stats.mp,
    atk: stats.atk, def: stats.def, spd: stats.spd, crit: stats.crit, healPct: stats.healPct || 0,
    actives: activeSkillsFor(char),
    // Efek item: shield aktif di awal battle, revive 1x per battle, dst.
    eff,
    shield: eff.shield ? Math.round(stats.hp * eff.shield) : 0,
    reviveUsed: false,
    regenHp: 0, regenMp: 0,
    buffTurns: 0, buffPct: 0, evasionTurns: 0, evasionPct: 0, defending: false,
    // Dibawa buat renderBattleScene gambar karakter HASIL KUSTOMISASI, bukan sprite hero polos.
    customization: {
      hairStyle: char.hairStyle || 'short', hairColor: char.hairColor || '#1f2937',
      expression: char.expression || 'netral', outfitColor: char.outfitColor || (cls && cls.color),
      pantsColor: char.pantsColor || '#472a19', shoesColor: char.shoesColor || '#0b0b12',
    },
  };
}

function pickMonster(char, monsterId) {
  if (monsterId) return D.monsterById(monsterId) || D.MONSTERS[0];
  const pool = D.monstersForLevel(char.level).filter(m => m.tier === 'normal' || m.tier === 'elite');
  return pool[Math.floor(Math.random() * pool.length)] || D.MONSTERS[0];
}

function buildEnemy(mob) {
  const sp = monsterSprite(mob.id);
  return {
    id: mob.id, name: mob.name, tier: mob.tier, level: mob.level, emoji: mob.emoji,
    spriteKey: sp.key, tint: sp.tint || null,
    hp: mob.hp, hpMax: mob.hp, atk: mob.atk, def: mob.def, spd: Math.round(mob.level * 0.6 + 5),
    xp: mob.xp, gold: mob.gold, dot: 0, dotTurns: 0,
    // NEW: status debuff pada musuh (racun item/pelemah/lumpuh) + tanda pemburu (mark)
    weakenMul: 1, weakenTurns: 0, paralyzeTurns: 0, markAmp: 0, markTurns: 0,
  };
}

function startBattle(userId, guildId, monsterId) {
  const lang = guildLang({ id: guildId });
  const char = rdb.getCharacter(userId);
  if (!char) return { error: t(lang, 'rpgb.no_char') };
  if (sessions.has(userId)) return { error: t(lang, 'rpgb.in_battle') };
  const mob = pickMonster(char, monsterId);
  const player = buildPlayer(char);
  const enemy = buildEnemy(mob);
  const bgs = getBattleBackgrounds();
  const state = {
    userId, guildId, lang, player, enemy, round: 1, over: false, result: null,
    log: [t(lang, 'rpgb.encounter', { name: enemy.name, level: enemy.level })],
    turn: player.spd >= enemy.spd ? 'player' : 'enemy',
    // BUGFIX: background dipilih SEKALI di awal battle dan disimpan di state, bukan diacak
    // ulang tiap render. Sebelumnya battleMessage() manggil renderBattleScene(state) tanpa
    // { bg }, jadi tiap tombol Serang/Bertahan/Skill dipencet -> background acak baru lagi,
    // keliatan seperti "kedip"/ganti-ganti terus.
    bg: bgs[Math.floor(Math.random() * bgs.length)],
  };
  sessions.set(userId, state);
  // Kalau enemy lebih cepat, dia jalan duluan.
  if (state.turn === 'enemy') enemyTurn(state);
  return { state };
}
function getBattle(userId) { return sessions.get(userId) || null; }
function endBattle(userId) { sessions.delete(userId); }

function computeDamage(atk, def, critPct, buffPct = 0) {
  let base = atk * (1 + buffPct) * rand(0.9, 1.12);
  const crit = Math.random() * 100 < critPct;
  if (crit) base *= 1.6;
  return { dmg: Math.max(1, Math.round(base - def * 0.5)), crit };
}

// Terapkan damage ke player (memperhitungkan shield, defending, evasion + dodge item).
function damagePlayer(state, raw) {
  const p = state.player;
  const eff = p.eff || {};
  // NEW: dodge permanen dari item (jubah bayangan dsb.) + evasion buff ramuan.
  const dodgePct = (eff.dodge || 0) * 100 + (p.evasionTurns > 0 ? p.evasionPct : 0);
  if (dodgePct > 0 && Math.random() * 100 < dodgePct) { state.log.push(t(stateLang(state), 'rpgb.dodge')); return 0; }
  let dmg = raw;
  if (p.defending) dmg = Math.round(dmg * 0.5);
  if (p.shield > 0) {
    const absorbed = Math.min(p.shield, dmg);
    p.shield -= absorbed; dmg -= absorbed;
    if (absorbed > 0) state.log.push(t(stateLang(state), 'rpgb.shield_absorb', { dmg: absorbed }));
  }
  p.hp = Math.max(0, p.hp - dmg);
  return dmg;
}

function enemyTurn(state) {
  const lang = stateLang(state);
  const e = state.enemy, p = state.player;
  // NEW: musuh lumpuh (racun paralyze) — melewatkan giliran.
  if (e.paralyzeTurns > 0) {
    e.paralyzeTurns--;
    state.log.push(`${e.name} lumpuh dan melewatkan giliran!`);
    state.round++;
    state.turn = 'player';
    return;
  }
  // Tick DoT pada enemy (racun) di awal giliran musuh.
  if (e.dotTurns > 0) { e.hp = Math.max(0, e.hp - e.dot); state.log.push(t(lang, 'rpgb.poison', { name: e.name, dmg: e.dot })); e.dotTurns--; if (e.hp <= 0) { winBattle(state); return; } }
  if (state.over) return;
  const heavy = (e.tier === 'boss' || e.tier === 'worldboss') && Math.random() < 0.3;
  const { dmg, crit } = computeDamage(e.atk * (heavy ? 1.6 : 1) * (e.weakenMul || 1), p.def, 5);
  const dealt = damagePlayer(state, dmg);
  state.log.push(`${heavy ? t(lang, 'rpgb.heavy') : ''}${t(lang, 'rpgb.enemy_attack', { name: e.name, crt: crit ? t(lang, 'rpgb.crit') : '', dmg: dealt })}`);
  // NEW: THORNS — pantulkan sebagian damage ke musuh (zirah duri & decrer).
  const thorns = (p.eff && p.eff.thorns) || 0;
  if (thorns > 0 && dealt > 0 && !state.over) {
    const ref = Math.max(1, Math.round(dealt * thorns));
    e.hp = Math.max(0, e.hp - ref);
    state.log.push(`Duri zirah memantulkan ${ref} damage ke ${e.name}!`);
    if (e.hp <= 0) { winBattle(state); return; }
  }
  // Reset defending setelah menahan satu serangan.
  p.defending = false;
  if (p.hp <= 0) {
    // NEW: REVIVE (zirah phoenix / jam pasir waktu) — 1x per battle.
    const rev = (p.eff && p.eff.revive) || 0;
    if (rev > 0 && !p.reviveUsed) {
      p.reviveUsed = true;
      p.hp = Math.max(1, Math.round(p.hpMax * rev));
      state.log.push(`Kau bangkit kembali dengan ${p.hp} HP! (efek item 1×)`);
    } else { loseBattle(state); return; }
  }
  // Tick regen item (HP & MP) tiap ronde + peluruhan durasinya.
  if (p.regenHp > 0) { p.hp = Math.min(p.hpMax, p.hp + p.regenHp); if (--p._regenHpTurns <= 0) p.regenHp = 0; }
  if ((p.eff && p.eff.regen) > 0 && p.hp < p.hpMax) p.hp = Math.min(p.hpMax, p.hp + p.eff.regen);
  if ((p.eff && p.eff.manaRegen) > 0 && p.mp < p.mpMax) p.mp = Math.min(p.mpMax, p.mp + p.eff.manaRegen);
  if (p.regenMp > 0) { p.mp = Math.min(p.mpMax, p.mp + p.regenMp); if (--p._regenMpTurns <= 0) p.regenMp = 0; }
  // Kurangi durasi buff/evasion tiap ronde penuh.
  if (p.buffTurns > 0) { p.buffTurns--; if (p.buffTurns === 0) { p.buffPct = 0; state.log.push(t(lang, 'rpgb.buff_off')); } }
  if (p.evasionTurns > 0) { p.evasionTurns--; if (p.evasionTurns === 0) p.evasionPct = 0; }
  if (e.weakenTurns > 0) { e.weakenTurns--; if (e.weakenTurns === 0) e.weakenMul = 1; }
  if (e.markTurns > 0) e.markTurns--;
  state.round++;
  state.turn = 'player';
}

function winBattle(state) {
  const lang = stateLang(state);
  state.over = true; state.result = 'win';
  const e = state.enemy;
  const p = state.player;
  const lvRes = engine.addExp(state.userId, e.xp, state.guildId);
  // NEW: goldFind — emas lebih banyak dari item (koin keberuntungan, mahkota raja).
  const gold = Math.round(e.gold * (1 + ((p.eff && p.eff.goldFind) || 0)));
  rdb.addGold(state.userId, state.guildId, gold);
  rdb.incCharacter(state.userId, 'monstersKilled', 1);
  rdb.incCharacter(state.userId, 'wins', 1);
  const isBoss = e.tier === 'boss' || e.tier === 'worldboss';
  if (e.tier === 'boss') rdb.incCharacter(state.userId, 'bossesDefeated', 1);
  if (e.tier === 'worldboss') { rdb.incCharacter(state.userId, 'bossesDefeated', 1); rdb.incCharacter(state.userId, 'worldQuests', 1); }
  // Majukan quest yang objektifnya cocok (monstersKilled selalu, bossesDefeated kalau ini boss)
  // dan langsung kasih reward-nya kalau target tercapai.
  const completedQuests = rdb.advanceQuestProgress(state.userId, 'monstersKilled', 1);
  if (isBoss) completedQuests.push(...rdb.advanceQuestProgress(state.userId, 'bossesDefeated', 1));
  for (const q of completedQuests) {
    if (q.rewardXp) engine.addExp(state.userId, q.rewardXp, state.guildId);
    if (q.rewardGold) rdb.addGold(state.userId, state.guildId, q.rewardGold);
    if (q.rewardRep) rdb.incCharacter(state.userId, 'reputation', q.rewardRep);
  }
  state.rewards = { xp: e.xp, gold, levelUp: lvRes.leveledUp ? lvRes : null, completedQuests };
  state.log.push(t(lang, 'rpgb.win', { name: e.name, xp: e.xp, gold }));
  for (const q of completedQuests) state.log.push(t(lang, 'rpgb.quest_done', { title: q.title, xp: q.rewardXp, gold: q.rewardGold, rep: q.rewardRep }));
}
function loseBattle(state) {
  const lang = stateLang(state);
  state.over = true; state.result = 'lose';
  rdb.incCharacter(state.userId, 'losses', 1);
  state.log.push(t(lang, 'rpgb.lose', { name: state.enemy.name }));
}

// Aksi pemain. action: 'attack' | 'skill' | 'defend' | 'flee'. payload.skillId utk skill.
function playerAction(userId, action, payload = {}) {
  const state = sessions.get(userId);
  if (!state) return { error: 'Tidak ada battle aktif.' };
  const lang = stateLang(state);
  if (state.over) return { state };
  if (state.turn !== 'player') return { error: t(lang, 'rpgb.not_turn') };
  const p = state.player, e = state.enemy;
  state.log = state.log.slice(-3); // jaga log ringkas

  if (action === 'attack') {
    const eff = p.eff || {};
    const { dmg, crit } = computeDamage(p.atk, e.def, p.crit, p.buffPct);
    let final = dmg;
    const parts = [];
    // NEW: EXECUTE — damage ×1.8 vs musuh sekarat (pedang naga, kitab meteor, dll.).
    if (eff.execute && e.hp / e.hpMax < eff.execute) { final = Math.round(final * 1.8); parts.push('☠️ EKSEKUSI!'); }
    e.hp = Math.max(0, e.hp - final);
    state.log.push(t(lang, 'rpgb.attack', { crt: crit ? t(lang, 'rpgb.crit') : '', dmg: final }) + (parts.length ? ' ' + parts.join(' ') : ''));
    // NEW: LIFESTEAL — menyerap HP dari damage.
    if (eff.lifesteal && final > 0 && p.hp < p.hpMax) {
      const heal = Math.max(1, Math.round(final * eff.lifesteal));
      p.hp = Math.min(p.hpMax, p.hp + heal);
      state.log.push(`🩸 Menyerap ${heal} HP dari musuh.`);
    }
    // NEW: POISON senjata — meracuni musuh tiap serangan.
    if (eff.poison && e.hp > 0) {
      const dot = Math.max(1, Math.round(p.atk * eff.poison));
      e.dot = Math.max(e.dot, dot); e.dotTurns = Math.max(e.dotTurns, 3);
      state.log.push(`🧪 ${e.name} teracuni (-${dot} HP/giliran).`);
    }
    // NEW: CLEAVE — peluang sabetan kedua (sweep).
    if (eff.cleave && e.hp > 0 && Math.random() < eff.cleave) {
      const extra = Math.max(1, Math.round(final * 0.5));
      e.hp = Math.max(0, e.hp - extra);
      state.log.push(`🌀 Sabetan menyapu! ${extra} damage tambahan.`);
    }
  } else if (action === 'defend') {
    p.defending = true;
    const regen = Math.round(p.mpMax * 0.15);
    p.mp = Math.min(p.mpMax, p.mp + regen);
    state.log.push(t(lang, 'rpgb.defend', { mp: regen }));
  } else if (action === 'flee') {
    const chance = Math.min(0.85, 0.4 + (p.spd - e.spd) * 0.03);
    if (Math.random() < chance) { state.log.push(t(lang, 'rpgb.flee_ok')); state.over = true; state.result = 'flee'; return { state }; }
    state.log.push(t(lang, 'rpgb.flee_fail'));
  } else if (action === 'skill') {
    const sk = p.actives.find(s => s.id === payload.skillId);
    if (!sk) return { error: t(lang, 'rpgb.skill_unknown') };
    if (p.mp < sk.mp) return { error: t(lang, 'rpgb.mp_low', { name: sk.name, mp: sk.mp }) };
    p.mp -= sk.mp;
    const ef = sk.effect;
    let msg = `${sk.name}: `;
    const parts = [];
    if (ef.dmg) {
      let mult = ef.dmg + (sk.level - 1) * 0.1;
      const hits = ef.hits || 1;
      let total = 0, anyCrit = false;
      for (let h = 0; h < hits; h++) {
        // pierce: sebagian DEF musuh diabaikan; mark: damage di-amplifikasi bila musuh bertanda.
        const defEff = ef.pierce ? e.def * (1 - ef.pierce) : e.def;
        const amp = e.markTurns > 0 ? (1 + (e.markAmp || 0)) : 1;
        const { dmg, crit } = computeDamage(p.atk * mult * amp, defEff, p.crit + (ef.critBonus ? ef.critBonus * 100 : 0), p.buffPct);
        let final = dmg;
        if (ef.execute && e.hp / e.hpMax < ef.execute) { final = Math.round(final * 2.2); if (h === 0) parts.push(t(lang, 'rpgb.execute')); }
        e.hp = Math.max(0, e.hp - final);
        total += final; if (crit) anyCrit = true;
        if (e.hp <= 0) break;
      }
      parts.push(`${total} damage${anyCrit ? t(lang, 'rpgb.crit') : ''}`);
    }
    if (ef.dot) { e.dot = Math.round(p.atk * ef.dot); e.dotTurns = ef.turns || 3; parts.push(t(lang, 'rpgb.dot', { dmg: e.dot })); }
    if (ef.heal || ef.healAoe) {
      // Regeneration (heal diri) & Bloom of Life (heal tim — di battle solo berlaku ke diri sendiri).
      const base = ef.heal || ef.healAoe;
      const heal = Math.round(p.atk * (base + (sk.level - 1) * 0.1) * (1 + p.healPct));
      p.hp = Math.min(p.hpMax, p.hp + heal);
      parts.push(t(lang, 'rpgb.heal', { hp: heal }));
    }
    if (ef.shield) { const sh = Math.round(p.hpMax * (ef.shield + (sk.level - 1) * 0.03)); p.shield += sh; parts.push(t(lang, 'rpgb.shield', { sh })); }
    if (ef.atkBuff) { p.buffPct = ef.atkBuff; p.buffTurns = (ef.turns || 3) + 1; parts.push(t(lang, 'rpgb.atk_buff', { pct: Math.round(ef.atkBuff * 100), turns: ef.turns })); }
    if (ef.evasion) { p.evasionPct = ef.evasion * 100; p.evasionTurns = (ef.turns || 2) + 1; parts.push(t(lang, 'rpgb.evade', { pct: Math.round(ef.evasion * 100) })); }
    if (ef.mark) { e.markAmp = ef.mark; e.markTurns = (ef.turns || 3) + 1; parts.push(`${e.name} bertanda (+${Math.round(ef.mark * 100)}% damage diterima)`); }
    state.log.push(msg + parts.join(', '));
  } else if (action === 'potion') {
    // Pakai ramuan/consumable dari inventory. Sebelumnya tidak ada action ini, jadi ramuan
    // yang sudah dibeli tidak pernah bisa dipakai saat bertarung.
    const it = items.getItem(payload.itemId);
    if (!it || (it.category !== 'potion' && it.category !== 'material') || (it.type !== 'consumable' && it.type !== 'material')) return { error: t(lang, 'rpgb.potion_unknown') };
    if (rdb.getItemQty(userId, it.id) < 1) return { error: t(lang, 'rpgb.potion_none', { name: it.name }) };
    rdb.removeItem(userId, it.id, 1);
    const ef = it.effect || {};
    const parts = [];
    // Boost penyembuhan dari item healer (healBoost).
    const hb = 1 + ((p.eff && p.eff.healBoost) || 0);
    if (ef.heal) { const h = Math.min(p.hpMax, p.hp + Math.round(ef.heal * hb)); parts.push(`+${h - p.hp} HP`); p.hp = h; }
    if (ef.mana) { const m = Math.min(p.mpMax, p.mp + ef.mana); parts.push(`+${m - p.mp} MP`); p.mp = m; }
    if (ef.healPct) { const h = Math.min(p.hpMax, p.hp + Math.round(p.hpMax * ef.healPct * hb)); parts.push(`+${h - p.hp} HP`); p.hp = h; }
    if (ef.manaPct) { const m = Math.min(p.mpMax, p.mp + Math.round(p.mpMax * ef.manaPct)); parts.push(`+${m - p.mp} MP`); p.mp = m; }
    // NEW: semua kind ramuan kini benar-benar berefek di battle.
    if (ef.kind === 'elixir') { parts.push('HP & MP penuh'); p.hp = p.hpMax; p.mp = p.mpMax; }
    if (ef.kind === 'strength' || ef.kind === 'berserk') { p.buffPct = Math.max(p.buffPct, ef.val); p.buffTurns = (ef.turns || 2) + 1; parts.push(`ATK +${Math.round(ef.val * 100)}% (${ef.turns} giliran)`); }
    if (ef.kind === 'swift') { p.evasionPct = Math.max(p.evasionPct, ef.val * 100); p.evasionTurns = (ef.turns || 3) + 1; parts.push(`Hindar +${Math.round(ef.val * 100)}% (${ef.turns} giliran)`); }
    if (ef.kind === 'regen') { p.regenHp = Math.max(p.regenHp, ef.val); p._regenHpTurns = (ef.turns || 4) + 1; parts.push(`Regen ${ef.val} HP/giliran`); }
    if (ef.kind === 'manaRegen') { p.regenMp = Math.max(p.regenMp, ef.val); p._regenMpTurns = (ef.turns || 4) + 1; parts.push(`Regen ${ef.val} MP/giliran`); }
    if (ef.kind === 'shield') { const sh = Math.round(p.hpMax * ef.val); p.shield += sh; parts.push(`Perisai +${sh}`); }
    if (ef.kind === 'poison' || ef.kind === 'venom') { e.dot = Math.max(e.dot, ef.val); e.dotTurns = Math.max(e.dotTurns, ef.turns || 3); parts.push(`${e.name} teracuni (-${ef.val}/giliran)`); }
    if (ef.kind === 'weaken') { e.weakenMul = 1 - ef.val; e.weakenTurns = (ef.turns || 3) + 1; parts.push(`ATK ${e.name} -${Math.round(ef.val * 100)}%`); }
    if (ef.kind === 'paralyze') { e.paralyzeTurns = Math.max(e.paralyzeTurns, ef.turns || ef.val || 2); parts.push(`${e.name} lumpuh ${e.paralyzeTurns} giliran`); }
    state.log.push(t(lang, 'rpgb.potion_use', { name: it.name, effect: parts.join(', ') || 'OK' }));
  } else {
    return { error: t(lang, 'rpgb.action_unknown') };
  }

  if (e.hp <= 0) { winBattle(state); return { state }; }
  // Giliran musuh.
  state.turn = 'enemy';
  enemyTurn(state);
  return { state };
}

module.exports = { startBattle, getBattle, endBattle, playerAction, activeSkillsFor };
