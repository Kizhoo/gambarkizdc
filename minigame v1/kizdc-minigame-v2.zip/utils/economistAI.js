// ============================================================================
// AI EKONOM (ECONOMIST) — "bank sentral" yang mengawasi ekonomi Kizco
// ----------------------------------------------------------------------------
// Peran ganda:
//   1) NARASI: tiap siklus menulis "laporan pasar" (market report) yang bisa
//      dipahami manusia — apa yang terjadi, kenapa, dan kebijakan apa diambil.
//   2) KEBIJAKAN: mengevaluasi inflasi/deflasi dan MENYESUAIKAN 3 tuas moneter
//      (rewardMultiplier, taxRate, bankInterestRate) bila model deterministik
//      kurang pas, plus memutuskan QE (injeksi) / QT (pengetatan) bila ekstrem.
//
// PENTING: AI TIDAK PERNAH jadi satu-satunya sumber kebenaran. Aturan dasar
// sudah dihitung deterministik di economyEngine.computePolicy(). AI cuma bisa
// menyempurnakan + menjelaskan — dan kalau provider AI mati/tidak dikonfigurasi,
// sistem tetap jalan 100% dengan aturan tersebut (fallback template).
// ============================================================================
const { generateText } = require('./aiProvider');
const econ = require('../database/economyDb');
const engine = require('./economyEngine');
const kizco = require('./kizco');
const settings = require('./settings');

// Ekstrak blok JSON pertama dari respons model (toleran thd teks sampah).
function extractJson(text) {
  const s = String(text || '');
  const start = s.indexOf('{');
  const end = s.lastIndexOf('}');
  if (start === -1 || end <= start) return null;
  try { return JSON.parse(s.slice(start, end + 1)); } catch (_) { return null; }
}

function buildPrompt(summary, tick) {
  const m = tick.metrics;
  return `Kamu adalah ekonom (gubernur bank sentral) untuk ekonomi game bernama Kizco di satu server Discord.

Kondisi ekonomi saat ini (data makro, SATUAN Kizco/KZC):
- Indeks harga: ${summary.priceIndex} (100 = baseline)
- Inflasi per siklus: ${summary.inflationPct}% (target ${(settings.get('economy.targetInflationPerCycle', 0.004) * 100).toFixed(2)}%)
- Uang beredar (M): ${kizco.format(summary.moneySupply)}
- Pertumbuhan uang: ${(m.moneyGrowth * 100).toFixed(2)}%
- Pertumbuhan aktivitas riil: ${(m.activityGrowth * 100).toFixed(2)}%
- Fase bisnis: ${summary.phaseLabel}
- Kebijakan saat ini: rewardMultiplier=${summary.rewardMultiplier}, pajak=${summary.taxRatePct}%, bunga bank=${summary.bankInterestRatePct}%

Analisis situasi lalu balas HANYA satu blok JSON (tanpa teks lain) dengan struktur:
{
  "narrative": "2-3 kalimat bahasa Indonesia menjelaskan kondisi & keputusan (jangan terlalu panjang)",
  "adjustPolicy": false,
  "rewardMultiplier": 1.0,
  "taxRate": 0.05,
  "bankInterestRate": 0.02,
  "qeAmount": 0
}

Aturan:
- Kalau inflasi jauh di atas target: naikkan taxRate, turunkan rewardMultiplier (jangan berlebihan, max ±50% dari nilai saat ini).
- Kalau deflasi (inflasi negatif): turunkan taxRate, naikkan rewardMultiplier; kalau parah (M turun drastis), set qeAmount positif (maks 5% dari M).
- Kalau kondisi sehat: adjustPolicy=false, qeAmount=0.
- Semua angka pecahan desimal, jangan pakai koma sebagai pemisah ribuan.`;
}

// Narasi fallback deterministik kalau AI tidak tersedia / gagal.
function fallbackNarrative(summary) {
  const infl = summary.inflationPct;
  if (infl > 2) return `Inflasi tinggi (${infl}%) karena uang beredar tumbuh lebih cepat daripada aktivitas riil. Kebijakan diperketat: pajak dinaikkan dan reward diturunkan untuk menyerap kelebihan likuiditas.`;
  if (infl > 0.4) return `Inflasi moderat (${infl}%) masih terkendali, sedikit di atas target. Bank sentral memantau dan menyesuaikan tuas moneter secara bertahap.`;
  if (infl < -1) return `Terjadi deflasi (${infl}%) — level harga turun. Kebijakan dilonggarkan: pajak diturunkan dan reward dinaikkan agar uang kembali mengalir.`;
  if (infl < 0) return `Deflasi ringan (${infl}%). Harga sedikit turun; kebijakan cenderung akomodatif untuk mendorong aktivitas.`;
  return `Ekonomi sehat, inflasi ${infl}% mendekati target. Kebijakan netral.`;
}

async function runEconomist(guildId, tickResult) {
  const summary = engine.summary(guildId);
  const st = econ.getState(guildId);
  return _runEconomist(guildId, tickResult, summary, st);
}

// Analisis on-demand (dipanggil tombol "Laporan" biar selalu segar).
async function runNow(guildId) {
  const summary = engine.summary(guildId);
  const st = econ.getState(guildId);
  const tick = {
    metrics: { moneyGrowth: 0, activityGrowth: 0, inflationRate: summary.inflationRate },
    policy: { rewardMultiplier: summary.rewardMultiplier, taxRate: summary.taxRate, bankInterestRate: summary.bankInterestRate },
  };
  return _runEconomist(guildId, tick, summary, st);
}

async function _runEconomist(guildId, tickResult, summary, st) {
  let decision, policy = null;
  const aiEnabled = !!process.env.CLOUDFLARE_ACCOUNT_ID && !!process.env.CLOUDFLARE_API_TOKEN;

  if (aiEnabled) {
    try {
      const raw = await generateText([{ role: 'user', content: buildPrompt(summary, tickResult) }], {});
      const parsed = extractJson(raw);
      if (parsed) {
        const base = tickResult.policy;
        // Batasi deviasi AI dari kebijakan deterministik (defense: AI tidak boleh ekstrem).
        const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, Number(v)));
        const rewardMultiplier = clamp(parsed.rewardMultiplier ?? base.rewardMultiplier, 0.4, 2.2);
        const taxRate = clamp(parsed.taxRate ?? base.taxRate, 0, 0.5);
        const bankInterestRate = clamp(parsed.bankInterestRate ?? base.bankInterestRate, 0, 0.1);
        const qeAmount = clamp(parsed.qeAmount ?? 0, 0, Math.round(st.moneySupply * 0.05));

        policy = { rewardMultiplier, taxRate, bankInterestRate, qeAmount };

        // Terapkan kebijakan AI (override deterministik).
        econ.updateState(guildId, { rewardMultiplier, taxRate, bankInterestRate });
        if (qeAmount > 0) engine.injectMoney(guildId, qeAmount, 'QE oleh AI Ekonom (respon deflasi)');

        decision = String(parsed.narrative || '').slice(0, 500) || fallbackNarrative(summary);
        econ.addAiLog(guildId, { decision, policyJson: policy, reasoning: 'AI ekonom (provider aktif)' });
        return { summary: engine.summary(guildId), decision, policy, source: 'ai' };
      }
    } catch (e) {
      console.warn('[economistAI] Gagal generate narasi AI, pakai fallback:', e.message);
    }
  }

  // Fallback deterministik.
  decision = fallbackNarrative(summary);
  policy = { rewardMultiplier: st.rewardMultiplier, taxRate: st.taxRate, bankInterestRate: st.bankInterestRate, qeAmount: 0 };
  econ.addAiLog(guildId, { decision, policyJson: policy, reasoning: 'Aturan deterministik (AI tidak tersedia)' });
  return { summary, decision, policy, source: 'rule' };
}

module.exports = { runEconomist, runNow, fallbackNarrative };
