// ============================================================================
// ITEM GENERATOR v3 — BUKAN GENERATOR LAGI, TAPI PEMBERSIH KATALOG.
// ----------------------------------------------------------------------------
// Dulu file ini men-generate ratusan item acak (material/artifact/collectible/
// cosmetic/food) ke tabel econ_items sehingga market penuh 600+ item tanpa
// efek & tanpa ikon yang jelas. Katalog sekarang DIRAPIKAN: hanya 90 item RPG
// resmi (utils/rpgItems.js) yang aktif di market.
//
// purgeGeneratedItems() dipanggil tiap startup (idempotent):
//   - MENONAKTIFKAN semua econ_items yang TIDAK ada di katalog resmi
//     (item generator lama + sisa item AI) → langsung hilang dari market/shop.
//   - Item tidak dihapus dari DB supaya riwayat transaksi & listing lama tetap
//     bisa dibaca (getItem tetap menemukannya), hanya tidak dijual lagi.
// ============================================================================
const econ = require('../database/economyDb');
const rpgItems = require('./rpgItems');

function purgeGeneratedItems() {
  const official = new Set(Object.keys(rpgItems.ITEMS));
  const all = econ.listItems({ activeOnly: false });
  let purged = 0;
  for (const it of all) {
    if (official.has(it.id)) {
      // Pastikan item resmi selalu aktif (idempotent).
      if (!it.active) econ.setItemActive(it.id, true);
      continue;
    }
    if (it.active) { econ.setItemActive(it.id, false); purged++; }
  }
  return { purged };
}

// Kompatibilitas: fungsi lama masih diekspor tapi kini menjadi pembersih.
function generateItems() { return []; }
function seedGeneratedItems() { return purgeGeneratedItems(); }
// Migrasi nama lama tidak diperlukan lagi (tidak ada item generator baru).
function fixReversedNames() {}

module.exports = { generateItems, seedGeneratedItems, purgeGeneratedItems, fixReversedNames };
