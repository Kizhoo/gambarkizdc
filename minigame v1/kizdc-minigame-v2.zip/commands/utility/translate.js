const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { safeDefer } = require('../../utils/interactionHelpers');
const { fetchExternal } = require('../../utils/httpClient');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  subcommandOf: true,
  data: new SlashCommandBuilder()
    .setName('translate')
    .setDescription('Terjemahkan teks ke bahasa lain')
    .addStringOption(o => o.setName('teks').setDescription('Teks yang ingin diterjemahkan').setRequired(true))
    .addStringOption(o => o.setName('ke').setDescription('Kode bahasa tujuan, contoh: en, id, ja, ko').setRequired(true))
    .addStringOption(o => o.setName('dari').setDescription('Kode bahasa asal (default: auto-detect)')),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const text = interaction.options.getString('teks');
    const target = interaction.options.getString('ke');
    const source = interaction.options.getString('dari') || 'auto';

    if (!(await safeDefer(interaction))) return;

    try {
      const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${source}|${target}`;
      const res = await fetchExternal(url);
      if (!res.ok) throw new Error(`mymemory.translated.net merespons status ${res.status}`);
      const data = await res.json();

      if (!data.responseData || data.responseStatus !== 200) {
        return interaction.editReply({ embeds: [errorEmbed(t(lang, 'util.translate_fail'))] });
      }

      const embed = baseEmbed()
        .setTitle(t(lang, 'translate.title'))
        .addFields(
          { name: t(lang, 'translate.original', { s: source }), value: text.slice(0, 1000) },
          { name: t(lang, 'translate.translated', { t: target }), value: data.responseData.translatedText.slice(0, 1000) },
        );

      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      console.error('[translate] Gagal menerjemahkan:', err.message);
      return interaction.editReply({ embeds: [errorEmbed(t(lang, 'translate.fail'))] }).catch(() => {});
    }
  },
};
