// ============================================================================
// KARTU PERKENALAN BOT — dikirim sekali saat bot baru ditambahkan ke server.
// ----------------------------------------------------------------------------
// Terinspirasi konsep kartu onboarding bot lain (aksen + header + ringkasan fitur
// + tombol CTA), tapi desain & copywriting-nya original untuk KizhooBot. Semua
// teks di sini sudah TERLOKALISASI (utils/i18n) mengikuti bahasa server, dan ada
// menu pilih bahasa supaya admin bisa ganti bahasa langsung dari kartu ini.
// ============================================================================
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, StringSelectMenuBuilder, ButtonStyle, PermissionsBitField } = require('discord.js');
const settings = require('./settings');
const { getGuildConfig, updateGuildConfig } = require('../database/db');
const { errorEmbed } = require('./embeds');
const { LANGUAGES, LANG_BY_CODE, t, langName } = require('./i18n');

// Warna aksen (kiri border embed) — pakai warna brand bot dari config, fallback biru.
function accentColor() {
  return settings.get('embedColor', '#3b82f6');
}

// URL dashboard publik. Diambil dari DASHBOARD_REDIRECT_URL (buang path /auth/callback)
// supaya otomatis ikut kalau domain diubah, fallback ke domain resmi.
function dashboardUrl() {
  const redirect = String(process.env.DASHBOARD_REDIRECT_URL || '').trim();
  if (redirect) return redirect.replace(/\/auth\/callback\/?$/, '');
  return process.env.DASHBOARD_PUBLIC_URL || 'https://bot.kizhoo.my.id';
}

// Link invite bot dengan permission paling wajar (least privilege).
function inviteUrl(client) {
  const permissions = new PermissionsBitField([
    'ViewChannel', 'SendMessages', 'EmbedLinks', 'AttachFiles', 'ReadMessageHistory',
    'ManageMessages', 'ManageChannels', 'ManageRoles', 'KickMembers', 'BanMembers', 'ModerateMembers',
    'Connect', 'Speak',
  ]);
  return `https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=${permissions.bitfield}&scope=bot%20applications.commands`;
}

// Link support server (opsional) — diambil dari config bila admin mengisinya.
function supportUrl() {
  return settings.get('supportServerInvite', '') || settings.get('supportServer', '') || '';
}

// Bahasa aktif untuk sebuah server (default Indonesia).
function guildLanguage(guild) {
  const cfg = guild ? getGuildConfig(guild.id) : null;
  return (cfg && cfg.language) || 'id';
}

/**
 * Bangun kartu perkenalan bot (embed + tombol link + pilih bahasa).
 * @param {import('discord.js').Client} client
 * @param {import('discord.js').Guild} [guild] — server tujuan (buat personalisasi & bahasa)
 * @returns {{ embeds: EmbedBuilder[], components: ActionRowBuilder[] }}
 */
function buildBotIntro(client, guild) {
  const bot = client.user;
  const lang = guildLanguage(guild);
  const serverName = guild?.name || '';
  const guildCount = client.guilds.cache.size;
  const commandCount = client.commands?.size || 0;

  const features = ['f1', 'f2', 'f3', 'f4', 'f5', 'f6', 'f7'].map((k) => `• ${t(lang, 'intro.' + k)}`).join('\n');

  const embed = new EmbedBuilder()
    .setColor(accentColor())
    .setAuthor({ name: bot.username, iconURL: bot.displayAvatarURL({ size: 128 }) })
    .setTitle(t(lang, 'intro.title'))
    .setThumbnail(bot.displayAvatarURL({ size: 256 }))
    .setDescription(t(lang, 'intro.desc', { server: serverName }))
    .addFields(
      { name: t(lang, 'intro.quickstart_title'), value: t(lang, 'intro.quickstart'), inline: false },
      { name: t(lang, 'intro.features_title'), value: features, inline: false },
    )
    .setFooter({ text: t(lang, 'intro.footer', { servers: guildCount, commands: commandCount }) })
    .setTimestamp();

  const buttons = [
    new ButtonBuilder().setLabel(t(lang, 'btn.dashboard')).setStyle(ButtonStyle.Link).setURL(dashboardUrl()),
    new ButtonBuilder().setLabel(t(lang, 'btn.invite')).setStyle(ButtonStyle.Link).setURL(inviteUrl(client)),
  ];
  const support = supportUrl();
  if (support) {
    buttons.push(new ButtonBuilder().setLabel(t(lang, 'btn.support')).setStyle(ButtonStyle.Link).setURL(support));
  }

  // Menu pilih bahasa server.
  const langRow = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('lang:select')
      .setPlaceholder(t(lang, 'lang.label'))
      .addOptions(LANGUAGES.map((l) => ({ label: l.native, value: l.code, emoji: l.flag, default: l.code === lang }))),
  );

  return { embeds: [embed], components: [new ActionRowBuilder().addComponents(buttons), langRow] };
}

// Handler menu pilih bahasa: simpan ke config server lalu render ulang kartu.
async function handleLanguageSelect(interaction, client) {
  const code = interaction.values?.[0];
  if (!LANG_BY_CODE[code]) return interaction.update({}).catch(() => {});
  if (!interaction.member.permissions?.has('ManageGuild')) {
    return interaction.reply({ embeds: [errorEmbed('Kamu butuh izin Manage Server untuk mengganti bahasa.')], ephemeral: true });
  }
  updateGuildConfig(interaction.guild.id, { language: code });
  const payload = buildBotIntro(client, interaction.guild);
  return interaction.update(payload);
}

module.exports = { buildBotIntro, handleLanguageSelect, dashboardUrl, inviteUrl, guildLanguage, langName };
