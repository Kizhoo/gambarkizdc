// ============================================================================
// COMMAND /util — gabungan SEMUA command utility jadi SATU command
// ----------------------------------------------------------------------------
// Setiap command utility (avatar, banner, ping, define, translate, dll) jadi
// subcommand. Command yang punya subcommand sendiri (explore, emoji) jadi
// SUBCOMMAND GROUP. Dispatch di execute() memanggil handler aslinya.
//
// Command utility asli DITANDAI `subcommandOf: true` (tidak ke-load sebagai
// command terpisah oleh index.js), jadi cuma /util yang terdaftar.
// ============================================================================
const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { errorEmbed } = require('../../utils/embeds');

// === Handler per subcommand (file asli tetap dipakai untuk logika execute) ===
const handlers = {
  avatar: require('./avatar'),
  banner: require('./banner'),
  calculator: require('./calculator'),
  channelinfo: require('./channelinfo'),
  color: require('./color'),
  define: require('./define'),
  editsnipe: require('./editsnipe'),
  imagesearch: require('./imagesearch'),
  ping: require('./ping'),
  poll: require('./poll'),
  qrcode: require('./qrcode'),
  register: require('./register'),
  remindme: require('./remindme'),
  roleinfo: require('./roleinfo'),
  serverinfo: require('./serverinfo'),
  snipe: require('./snipe'),
  translate: require('./translate'),
  urlshorten: require('./urlshorten'),
  userinfo: require('./userinfo'),
  voicemonitor: require('./voicemonitor'),
  explore: require('./explore'),
  emoji: require('./emoji'),
};

// === Helper buat option string ===
const str = (name, desc, required = false) => (o) => {
  const b = o.setName(name).setDescription(desc);
  if (required) b.setRequired(true);
  return b;
};

// === Data: 20 subcommand + 2 subcommand group ===
const data = new SlashCommandBuilder()
  .setName('util')
  .setDescription('Kumpulan command utility bot (info, tools, pencarian, dll)')

  // ---------- INFO ----------
  .addSubcommand(s => s.setName('ping').setDescription('Cek latency bot'))
  .addSubcommand(s => s.setName('avatar').setDescription('Lihat avatar user dalam ukuran penuh')
    .addUserOption(str('target', 'User yang ingin dilihat avatarnya')))
  .addSubcommand(s => s.setName('banner').setDescription('Lihat banner profil user')
    .addUserOption(str('target', 'User yang ingin dilihat bannernya')))
  .addSubcommand(s => s.setName('userinfo').setDescription('Lihat informasi seorang user')
    .addUserOption(str('target', 'User yang ingin dilihat')))
  .addSubcommand(s => s.setName('serverinfo').setDescription('Lihat informasi server ini'))
  .addSubcommand(s => s.setName('channelinfo').setDescription('Lihat informasi channel ini atau channel lain')
    .addChannelOption(str('channel', 'Channel yang ingin dilihat')))
  .addSubcommand(s => s.setName('roleinfo').setDescription('Lihat informasi sebuah role')
    .addRoleOption(o => o.setName('role').setDescription('Role yang ingin dilihat').setRequired(true)))
  .addSubcommand(s => s.setName('snipe').setDescription('Lihat pesan terakhir yang dihapus di channel ini'))
  .addSubcommand(s => s.setName('editsnipe').setDescription('Lihat pesan terakhir yang diedit di channel ini'))

  // ---------- TOOLS ----------
  .addSubcommand(s => s.setName('calculator').setDescription('Hitung ekspresi matematika')
    .addStringOption(str('ekspresi', 'Contoh: (2+3)*4, 10/3, 2^10', true)))
  .addSubcommand(s => s.setName('color').setDescription('Lihat preview warna dari kode hex')
    .addStringOption(str('hex', 'Kode warna hex, contoh: ff5733 atau #ff5733', true)))
  .addSubcommand(s => s.setName('define').setDescription('Cari arti kata dalam Bahasa Inggris')
    .addStringOption(str('kata', 'Kata yang ingin dicari artinya', true)))
  .addSubcommand(s => s.setName('translate').setDescription('Terjemahkan teks ke bahasa lain')
    .addStringOption(str('teks', 'Teks yang ingin diterjemahkan', true))
    .addStringOption(str('ke', 'Kode bahasa tujuan, contoh: en, id, ja, ko', true))
    .addStringOption(str('dari', 'Kode bahasa asal (default: auto-detect)')))
  .addSubcommand(s => s.setName('qrcode').setDescription('Buat QR code dari teks atau link')
    .addStringOption(str('teks', 'Teks atau URL yang ingin dijadikan QR code', true)))
  .addSubcommand(s => s.setName('urlshorten').setDescription('Perpendek link/URL panjang')
    .addStringOption(str('url', 'URL yang ingin diperpendek', true)))
  .addSubcommand(s => s.setName('imagesearch').setDescription('Cari gambar/wallpaper berkualitas tinggi berdasarkan kata kunci')
    .addStringOption(str('kata_kunci', 'Kata kunci pencarian gambar', true)))
  .addSubcommand(s => s.setName('poll').setDescription('Buat polling sederhana')
    .addStringOption(str('pertanyaan', 'Pertanyaan polling', true))
    .addStringOption(str('opsi', 'Pisahkan dengan | contoh: A|B|C (kosongkan untuk polling Ya/Tidak)')))
  .addSubcommand(s => s.setName('remindme').setDescription('Ingatkan aku tentang sesuatu nanti')
    .addStringOption(str('waktu', 'Contoh: 10m, 2h, 1d, 30s', true))
    .addStringOption(str('pesan', 'Isi pengingat', true)))
  .addSubcommand(s => s.setName('register').setDescription('Buka panel registrasi interaktif KizhooBot'))
  .addSubcommand(s => s.setName('voicemonitor').setDescription('Dashboard monitoring voice channel real-time'))

  // ---------- SUBCOMMAND GROUP: explore (20 pencarian/media API) ----------
  .addSubcommandGroup(g => {
    g.setName('explore').setDescription('20 fitur pencarian dan media berbasis public API');
    const q = (name, desc) => (s) => s.setName(name).setDescription(desc).addStringOption(o => o.setName('query').setDescription('Kata pencarian').setRequired(true));
    g.addSubcommand(q('pokemon', 'Cari informasi Pokémon'));
    g.addSubcommand(q('anime', 'Cari anime melalui Jikan API'));
    g.addSubcommand(q('manga', 'Cari manga melalui Jikan API'));
    g.addSubcommand(q('character', 'Cari karakter anime'));
    g.addSubcommand(q('country', 'Cari profil lengkap negara'));
    g.addSubcommand(q('weather', 'Cek cuaca kota secara real-time'));
    g.addSubcommand(q('github', 'Lihat profil publik GitHub'));
    g.addSubcommand(q('npm', 'Cari detail package npm'));
    g.addSubcommand(q('dictionary', 'Kamus bahasa Inggris'));
    g.addSubcommand(q('crypto', 'Cek harga aset kripto'));
    g.addSubcommand(s => s.setName('joke').setDescription('Ambil joke acak dari API'));
    g.addSubcommand(s => s.setName('quote').setDescription('Ambil quote inspiratif acak'));
    g.addSubcommand(s => s.setName('fact').setDescription('Ambil fakta unik acak'));
    g.addSubcommand(s => s.setName('dog').setDescription('Foto anjing acak'));
    g.addSubcommand(s => s.setName('cat').setDescription('Foto kucing acak'));
    g.addSubcommand(s => s.setName('fox').setDescription('Foto rubah acak'));
    g.addSubcommand(s => s.setName('duck').setDescription('Foto bebek acak'));
    g.addSubcommand(s => s.setName('meme').setDescription('Meme komunitas acak'));
    g.addSubcommand(s => s.setName('space').setDescription('Berita antariksa terbaru'));
    g.addSubcommand(s => s.setName('activity').setDescription('Rekomendasi aktivitas saat bosan'));
    return g;
  })

  // ---------- SUBCOMMAND GROUP: emoji (import & kelola emoji bot) ----------
  .addSubcommandGroup(g => {
    g.setName('emoji').setDescription('[Owner] Import & kelola emoji animasi bot');
    g.addSubcommand(s => s.setName('import').setDescription('Import banyak emoji dari emoji.gg')
      .addStringOption(o => o.setName('kata').setDescription('Kata kunci (mis. cat, pepe, anime)').setRequired(true))
      .addIntegerOption(o => o.setName('jumlah').setDescription('Jumlah maksimal (1-30, default 10)').setMinValue(1).setMaxValue(30)));
    g.addSubcommand(s => s.setName('url').setDescription('Import 1 emoji dari URL langsung')
      .addStringOption(o => o.setName('url').setDescription('URL gambar emoji').setRequired(true))
      .addStringOption(o => o.setName('nama').setDescription('Nama emoji (2-32 huruf/angka)').setRequired(true)));
    g.addSubcommand(s => s.setName('list').setDescription('Lihat semua emoji yang sudah di-import'));
    return g;
  });

module.exports = {
  data,
  async execute(interaction, client) {
    const group = interaction.options.getSubcommandGroup(false);
    const sub = interaction.options.getSubcommand(false);
    const key = group || sub;
    const handler = handlers[key];
    if (!handler) {
      return interaction.reply({ embeds: [errorEmbed('Subcommand tidak dikenal.')], ephemeral: true });
    }
    // delegasikan ke handler asli (execute-nya tetap jalan, getSubcommand tetap akurat)
    return handler.execute(interaction, client);
  },
};
