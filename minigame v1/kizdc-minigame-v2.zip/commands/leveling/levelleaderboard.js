const { SlashCommandBuilder } = require('discord.js');
const { getLevelLeaderboard } = require('../../database/db');
const { baseEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder().setName('levelleaderboard').setDescription('Lihat 10 orang dengan level tertinggi'),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const top = getLevelLeaderboard(interaction.guild.id, 10);

    if (top.length === 0) {
      return interaction.reply({ embeds: [baseEmbed().setDescription(t(lang, 'lb.level_empty'))] });
    }

    const medals = ['', '', ''];
    const description = top.map((row, i) => {
      const prefix = medals[i] || `#${i + 1}`;
      return `${prefix} <@${row.userId}> — Level **${row.level}** (${row.xp} XP)`;
    }).join('\n');

    return interaction.reply({ embeds: [baseEmbed().setTitle(t(lang, 'lb.level_title')).setDescription(description)] });
  },
};
