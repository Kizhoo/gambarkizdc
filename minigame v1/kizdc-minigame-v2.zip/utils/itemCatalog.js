// ============================================================================
// ITEM CATALOG — katalog resmi barang pasar (data murni, tanpa logika game).
// ----------------------------------------------------------------------------
// Dulu hidup di utils/rpgItems.js (era RPG). Pasca-penghapusan RPG, katalog
// barang yang dijual /market & web tetap dipertahankan DI SINI supaya pasar,
// trading, dan lelang tidak berubah. Field stats/effect hanya data tampilan.
// ============================================================================
'use strict';

const ITEMS = {
  "w_rusty": {
    "id": "w_rusty",
    "name": "Pedang Karatan",
    "category": "weapon",
    "type": "equip",
    "wtype": "sword",
    "atype": null,
    "class": "warrior",
    "tier": "common",
    "price": 80,
    "emoji": "",
    "stats": {
      "atk": 3
    },
    "effect": {
      "kind": "cleave",
      "pct": 0.08
    },
    "desc": "Pedang tua, tapi masih bisa dipakai."
  },
  "w_steel": {
    "id": "w_steel",
    "name": "Pedang Baja",
    "category": "weapon",
    "type": "equip",
    "wtype": "sword",
    "atype": null,
    "class": "warrior",
    "tier": "uncommon",
    "price": 250,
    "emoji": "",
    "stats": {
      "atk": 7
    },
    "effect": {
      "kind": "critDmg",
      "pct": 0.15
    },
    "desc": "Ditempa dari baja berkualitas — sisi tajamnya menkatkan critical."
  },
  "w_iron_axe": {
    "id": "w_iron_axe",
    "name": "Kapak Besi",
    "category": "weapon",
    "type": "equip",
    "wtype": "axe",
    "atype": null,
    "class": "warrior",
    "tier": "uncommon",
    "price": 280,
    "emoji": "",
    "stats": {
      "atk": 9
    },
    "effect": {
      "kind": "execute",
      "pct": 0.12
    },
    "desc": "Kapak berat yang mudah menjatuhkan musuh lemah."
  },
  "w_elven": {
    "id": "w_elven",
    "name": "Pedang Elf",
    "category": "weapon",
    "type": "equip",
    "wtype": "sword",
    "atype": null,
    "class": "warrior",
    "tier": "rare",
    "price": 600,
    "emoji": "",
    "stats": {
      "atk": 13,
      "spd": 2
    },
    "effect": {
      "kind": "lifesteal",
      "pct": 0.06
    },
    "desc": "Ringan dan tajam, buatan pengrajin elf — sedikit menyerap nyawa."
  },
  "w_warhammer": {
    "id": "w_warhammer",
    "name": "Palu Perang",
    "category": "weapon",
    "type": "equip",
    "wtype": "hammer",
    "atype": null,
    "class": "warrior",
    "tier": "rare",
    "price": 650,
    "emoji": "",
    "stats": {
      "atk": 14,
      "def": 2
    },
    "effect": {
      "kind": "cleave",
      "pct": 0.3
    },
    "desc": "Ayunan palunya menyapu musuh di sekitar."
  },
  "w_knight_spear": {
    "id": "w_knight_spear",
    "name": "Tombak Ksatria",
    "category": "weapon",
    "type": "equip",
    "wtype": "spear",
    "atype": null,
    "class": "warrior",
    "tier": "epic",
    "price": 1400,
    "emoji": "",
    "stats": {
      "atk": 20,
      "spd": 4
    },
    "effect": {
      "kind": "cleave",
      "pct": 0.35
    },
    "desc": "Jangkauan jauh — tebasan menyapu beberapa musuh sekaligus."
  },
  "w_dragon": {
    "id": "w_dragon",
    "name": "Pedang Taring Naga",
    "category": "weapon",
    "type": "equip",
    "wtype": "sword",
    "atype": null,
    "class": "warrior",
    "tier": "epic",
    "price": 1500,
    "emoji": "",
    "stats": {
      "atk": 22
    },
    "effect": {
      "kind": "lifesteal",
      "pct": 0.15
    },
    "desc": "Ditempa dari taring naga asli. Menghisap nyawa musuh."
  },
  "w_omega": {
    "id": "w_omega",
    "name": "Pedang Legenda Ω",
    "category": "weapon",
    "type": "equip",
    "wtype": "sword",
    "atype": null,
    "class": "warrior",
    "tier": "mythic",
    "price": 4000,
    "emoji": "",
    "stats": {
      "atk": 35,
      "crit": 5
    },
    "effect": {
      "kind": "cleave",
      "pct": 0.5
    },
    "desc": "Senjata para legenda. Tebasannya menyapu seluruh medan."
  },
  "w_wood_staff": {
    "id": "w_wood_staff",
    "name": "Tongkat Kayu",
    "category": "weapon",
    "type": "equip",
    "wtype": "staff",
    "atype": null,
    "class": "mage",
    "tier": "common",
    "price": 80,
    "emoji": "",
    "stats": {
      "atk": 4
    },
    "effect": {
      "kind": "manaRegen",
      "val": 3
    },
    "desc": "Tongkat sederhana yang mengalirkan mana perlahan."
  },
  "w_flame_wand": {
    "id": "w_flame_wand",
    "name": "Tongkat Api",
    "category": "weapon",
    "type": "equip",
    "wtype": "wand",
    "atype": null,
    "class": "mage",
    "tier": "uncommon",
    "price": 260,
    "emoji": "",
    "stats": {
      "atk": 8
    },
    "effect": {
      "kind": "poison",
      "dot": 0.1,
      "turns": 2
    },
    "desc": "Ujungnya menyala — serangan membakar musuh (damage per giliran)."
  },
  "w_arcane_orb": {
    "id": "w_arcane_orb",
    "name": "Bola Arcanum",
    "category": "weapon",
    "type": "equip",
    "wtype": "orb",
    "atype": null,
    "class": "mage",
    "tier": "rare",
    "price": 620,
    "emoji": "",
    "stats": {
      "atk": 13,
      "crit": 3
    },
    "effect": {
      "kind": "critDmg",
      "pct": 0.3
    },
    "desc": "Kristal arcanum yang memusatkan energi ke satu titik lemah."
  },
  "w_void_orb": {
    "id": "w_void_orb",
    "name": "Bola Kehampaan",
    "category": "weapon",
    "type": "equip",
    "wtype": "orb",
    "atype": null,
    "class": "mage",
    "tier": "rare",
    "price": 640,
    "emoji": "",
    "stats": {
      "atk": 12,
      "spd": 2
    },
    "effect": {
      "kind": "manaRegen",
      "val": 8
    },
    "desc": "Menyerap energi kehampaan — MP pulih jauh lebih cepat."
  },
  "w_frost_staff": {
    "id": "w_frost_staff",
    "name": "Tongkat Es",
    "category": "weapon",
    "type": "equip",
    "wtype": "staff",
    "atype": null,
    "class": "mage",
    "tier": "epic",
    "price": 1450,
    "emoji": "",
    "stats": {
      "atk": 20,
      "spd": 3
    },
    "effect": {
      "kind": "manaRegen",
      "val": 6
    },
    "desc": "Dingin membekukan — memulihkan MP tiap giliran."
  },
  "w_meteor_tome": {
    "id": "w_meteor_tome",
    "name": "Kitab Meteor",
    "category": "weapon",
    "type": "equip",
    "wtype": "tome",
    "atype": null,
    "class": "mage",
    "tier": "epic",
    "price": 1550,
    "emoji": "",
    "stats": {
      "atk": 23
    },
    "effect": {
      "kind": "execute",
      "pct": 0.25
    },
    "desc": "Kitab kuno. Siram musuh yang nyaris tumbang."
  },
  "w_archstaff": {
    "id": "w_archstaff",
    "name": "Tongkat Archmage",
    "category": "weapon",
    "type": "equip",
    "wtype": "staff",
    "atype": null,
    "class": "mage",
    "tier": "mythic",
    "price": 4100,
    "emoji": "",
    "stats": {
      "atk": 36,
      "crit": 8
    },
    "effect": {
      "kind": "manaRegen",
      "val": 12
    },
    "desc": "Tongkat sang Archmage. Energi sihir mengalir tanpa henti."
  },
  "w_rusty_dagger": {
    "id": "w_rusty_dagger",
    "name": "Belati Karatan",
    "category": "weapon",
    "type": "equip",
    "wtype": "dagger",
    "atype": null,
    "class": "assassin",
    "tier": "common",
    "price": 80,
    "emoji": "",
    "stats": {
      "atk": 3,
      "spd": 2
    },
    "effect": {
      "kind": "poison",
      "dot": 0.06,
      "turns": 2
    },
    "desc": "Belati kecil berkarat — sisa racunnya masih menusuk."
  },
  "w_sharp_katana": {
    "id": "w_sharp_katana",
    "name": "Katana Tajam",
    "category": "weapon",
    "type": "equip",
    "wtype": "katana",
    "atype": null,
    "class": "assassin",
    "tier": "uncommon",
    "price": 270,
    "emoji": "",
    "stats": {
      "atk": 7,
      "spd": 2
    },
    "effect": {
      "kind": "critDmg",
      "pct": 0.2
    },
    "desc": "Bilah ramping setajam silet — critical terasa lebih sakit."
  },
  "w_venom_claw": {
    "id": "w_venom_claw",
    "name": "Cakar Beracun",
    "category": "weapon",
    "type": "equip",
    "wtype": "claw",
    "atype": null,
    "class": "assassin",
    "tier": "rare",
    "price": 640,
    "emoji": "",
    "stats": {
      "atk": 12,
      "crit": 3
    },
    "effect": {
      "kind": "poison",
      "dot": 0.15,
      "turns": 3
    },
    "desc": "Cakar berlapis racun — meracuni lawan tiap serangan."
  },
  "w_twin_fang": {
    "id": "w_twin_fang",
    "name": "Belati Taring Kembar",
    "category": "weapon",
    "type": "equip",
    "wtype": "dagger",
    "atype": null,
    "class": "assassin",
    "tier": "rare",
    "price": 660,
    "emoji": "",
    "stats": {
      "atk": 11,
      "spd": 4
    },
    "effect": {
      "kind": "cleave",
      "pct": 0.25
    },
    "desc": "Sepasang belati viper — tebasan ganda menyapu ke depan."
  },
  "w_shadow_bow": {
    "id": "w_shadow_bow",
    "name": "Busur Bayangan",
    "category": "weapon",
    "type": "equip",
    "wtype": "bow",
    "atype": null,
    "class": "assassin",
    "tier": "epic",
    "price": 1450,
    "emoji": "",
    "stats": {
      "atk": 20,
      "crit": 6
    },
    "effect": {
      "kind": "critDmg",
      "pct": 0.25
    },
    "desc": "Panah bayangan yang selalu menemukan titik lemah."
  },
  "w_night_katana": {
    "id": "w_night_katana",
    "name": "Katana Malam",
    "category": "weapon",
    "type": "equip",
    "wtype": "katana",
    "atype": null,
    "class": "assassin",
    "tier": "epic",
    "price": 1500,
    "emoji": "",
    "stats": {
      "atk": 21,
      "spd": 5
    },
    "effect": {
      "kind": "execute",
      "pct": 0.2
    },
    "desc": "Ditempa di bawah bulan — mematikan bagi musuh sekarat."
  },
  "w_phantom": {
    "id": "w_phantom",
    "name": "Belati Phantom",
    "category": "weapon",
    "type": "equip",
    "wtype": "dagger",
    "atype": null,
    "class": "assassin",
    "tier": "mythic",
    "price": 4000,
    "emoji": "",
    "stats": {
      "atk": 33,
      "crit": 12,
      "spd": 8
    },
    "effect": {
      "kind": "execute",
      "pct": 0.3
    },
    "desc": "Belati yang menembus bayangan dan jantung sekaligus."
  },
  "w_short_bow": {
    "id": "w_short_bow",
    "name": "Busur Pemburu",
    "category": "weapon",
    "type": "equip",
    "wtype": "bow",
    "atype": null,
    "class": "archer",
    "tier": "common",
    "price": 80,
    "emoji": "",
    "stats": {
      "atk": 4
    },
    "effect": {
      "kind": "critDmg",
      "pct": 0.1
    },
    "desc": "Busur kayu lurus. Berat tarikannya jujur, panahnya juga."
  },
  "w_hunt_longbow": {
    "id": "w_hunt_longbow",
    "name": "Longbow Pemburu",
    "category": "weapon",
    "type": "equip",
    "wtype": "bow",
    "atype": null,
    "class": "archer",
    "tier": "uncommon",
    "price": 260,
    "emoji": "",
    "stats": {
      "atk": 8,
      "spd": 2
    },
    "effect": {
      "kind": "critDmg",
      "pct": 0.15
    },
    "desc": "Lengkung tinggi warisan pemburu tua — bidikan sedikit lebih tajam."
  },
  "w_recurve_bow": {
    "id": "w_recurve_bow",
    "name": "Busur Recurve",
    "category": "weapon",
    "type": "equip",
    "wtype": "bow",
    "atype": null,
    "class": "archer",
    "tier": "rare",
    "price": 620,
    "emoji": "",
    "stats": {
      "atk": 13,
      "crit": 3
    },
    "effect": {
      "kind": "critDmg",
      "pct": 0.25
    },
    "desc": "Ujungnya melengkung dua arah. Tenang menembus angin."
  },
  "w_bone_bow": {
    "id": "w_bone_bow",
    "name": "Busur Tulang",
    "category": "weapon",
    "type": "equip",
    "wtype": "bow",
    "atype": null,
    "class": "archer",
    "tier": "rare",
    "price": 640,
    "emoji": "",
    "stats": {
      "atk": 12,
      "spd": 4
    },
    "effect": {
      "kind": "poison",
      "dot": 0.08,
      "turns": 3
    },
    "desc": "Dirangkai dari tulang makhluk gua. Lukanya suka bernanah."
  },
  "w_elven_bow": {
    "id": "w_elven_bow",
    "name": "Busur Elf",
    "category": "weapon",
    "type": "equip",
    "wtype": "bow",
    "atype": null,
    "class": "archer",
    "tier": "epic",
    "price": 1400,
    "emoji": "",
    "stats": {
      "atk": 20,
      "crit": 5
    },
    "effect": {
      "kind": "critDmg",
      "pct": 0.3
    },
    "desc": "Kayu elf yang selalu ingat ke mana panah harus pergi."
  },
  "w_windseeker": {
    "id": "w_windseeker",
    "name": "Windseeker",
    "category": "weapon",
    "type": "equip",
    "wtype": "bow",
    "atype": null,
    "class": "archer",
    "tier": "mythic",
    "price": 4000,
    "emoji": "",
    "stats": {
      "atk": 34,
      "crit": 10,
      "spd": 6
    },
    "effect": {
      "kind": "critDmg",
      "pct": 0.4
    },
    "desc": "Busur legendaris yang menembak sebelum kamu sempat berpikir."
  },
  "a_leather": {
    "id": "a_leather",
    "name": "Baju Kulit",
    "category": "armor",
    "type": "equip",
    "wtype": null,
    "atype": "light",
    "class": null,
    "tier": "common",
    "price": 80,
    "emoji": "",
    "stats": {
      "def": 3
    },
    "effect": {
      "kind": "regen",
      "val": 1
    },
    "desc": "Perlindungan dasar yang memulihkan luka perlahan."
  },
  "a_padded_vest": {
    "id": "a_padded_vest",
    "name": "Rompi Empuk",
    "category": "armor",
    "type": "equip",
    "wtype": null,
    "atype": "light",
    "class": null,
    "tier": "common",
    "price": 85,
    "emoji": "",
    "stats": {
      "def": 2,
      "hp": 10
    },
    "effect": {
      "kind": "thorns",
      "pct": 0.05
    },
    "desc": "Rompi tebal yang memantulkan sedikit pukulan."
  },
  "a_chain": {
    "id": "a_chain",
    "name": "Baju Rantai",
    "category": "armor",
    "type": "equip",
    "wtype": null,
    "atype": "mail",
    "class": null,
    "tier": "uncommon",
    "price": 250,
    "emoji": "",
    "stats": {
      "def": 7
    },
    "effect": {
      "kind": "thorns",
      "pct": 0.08
    },
    "desc": "Anyaman rantai yang memantulkan serangan."
  },
  "a_ranger_coat": {
    "id": "a_ranger_coat",
    "name": "Jaket Ranger",
    "category": "armor",
    "type": "equip",
    "wtype": null,
    "atype": "coat",
    "class": null,
    "tier": "uncommon",
    "price": 260,
    "emoji": "",
    "stats": {
      "def": 5,
      "spd": 3
    },
    "effect": {
      "kind": "dodge",
      "pct": 0.06
    },
    "desc": "Jaket pelari rimba — serangan musuh kadang meleset."
  },
  "a_guardian": {
    "id": "a_guardian",
    "name": "Zirah Penjaga",
    "category": "armor",
    "type": "equip",
    "wtype": null,
    "atype": "plate",
    "class": null,
    "tier": "rare",
    "price": 620,
    "emoji": "",
    "stats": {
      "def": 12,
      "hp": 20
    },
    "effect": {
      "kind": "shield",
      "pct": 0.12
    },
    "desc": "Zirah penjaga yang memberi perisai di awal bertempur."
  },
  "a_plate": {
    "id": "a_plate",
    "name": "Baju Pelat",
    "category": "armor",
    "type": "equip",
    "wtype": null,
    "atype": "plate",
    "class": null,
    "tier": "rare",
    "price": 600,
    "emoji": "",
    "stats": {
      "def": 13
    },
    "effect": {
      "kind": "thorns",
      "pct": 0.15
    },
    "desc": "Pelat baja tebal — musuh yang menyerang ikut terluka."
  },
  "a_mithril_mail": {
    "id": "a_mithril_mail",
    "name": "Zirah Mithril",
    "category": "armor",
    "type": "equip",
    "wtype": null,
    "atype": "mail",
    "class": null,
    "tier": "rare",
    "price": 640,
    "emoji": "",
    "stats": {
      "def": 11,
      "spd": 2,
      "mp": 10
    },
    "effect": {
      "kind": "manaRegen",
      "val": 4
    },
    "desc": "Ringan berkilau — mana mengalir lebih lancar."
  },
  "a_dragon": {
    "id": "a_dragon",
    "name": "Zirah Sisik Naga",
    "category": "armor",
    "type": "equip",
    "wtype": null,
    "atype": "scale",
    "class": null,
    "tier": "epic",
    "price": 1500,
    "emoji": "",
    "stats": {
      "def": 22
    },
    "effect": {
      "kind": "thorns",
      "pct": 0.25
    },
    "desc": "Sisik naga memantulkan seperempat damage ke penyerang."
  },
  "a_titan_aegis": {
    "id": "a_titan_aegis",
    "name": "Aegis Titan",
    "category": "armor",
    "type": "equip",
    "wtype": null,
    "atype": "aegis",
    "class": null,
    "tier": "epic",
    "price": 1450,
    "emoji": "",
    "stats": {
      "def": 18,
      "hp": 40
    },
    "effect": {
      "kind": "shield",
      "pct": 0.2
    },
    "desc": "Perisai raksasa para titan — pelindung awal yang tebal."
  },
  "a_frost_bulwark": {
    "id": "a_frost_bulwark",
    "name": "Benteng Beku",
    "category": "armor",
    "type": "equip",
    "wtype": null,
    "atype": "bulwark",
    "class": null,
    "tier": "epic",
    "price": 1500,
    "emoji": "",
    "stats": {
      "def": 20,
      "mp": 15
    },
    "effect": {
      "kind": "regen",
      "val": 5
    },
    "desc": "Kegelapan es yang terus memulihkan tubuhnya."
  },
  "a_omega": {
    "id": "a_omega",
    "name": "Zirah Suci Ω",
    "category": "armor",
    "type": "equip",
    "wtype": null,
    "atype": "aegis",
    "class": null,
    "tier": "mythic",
    "price": 4000,
    "emoji": "",
    "stats": {
      "def": 35,
      "spd": 5
    },
    "effect": {
      "kind": "shield",
      "pct": 0.25
    },
    "desc": "Diberkati guild tertinggi. Memberi perisai saat bertempur."
  },
  "a_void_shroud": {
    "id": "a_void_shroud",
    "name": "Selubung Kehampaan",
    "category": "armor",
    "type": "equip",
    "wtype": null,
    "atype": "shroud",
    "class": null,
    "tier": "mythic",
    "price": 4200,
    "emoji": "",
    "stats": {
      "def": 26,
      "spd": 6
    },
    "effect": {
      "kind": "dodge",
      "pct": 0.12
    },
    "desc": "Tubuhmu setengah ada di dimensi lain — serangan menembus kosong."
  },
  "a_phoenix_mail": {
    "id": "a_phoenix_mail",
    "name": "Zirah Phoenix",
    "category": "armor",
    "type": "equip",
    "wtype": null,
    "atype": "scale",
    "class": null,
    "tier": "mythic",
    "price": 4400,
    "emoji": "",
    "stats": {
      "def": 30,
      "hp": 50
    },
    "effect": {
      "kind": "revive",
      "pct": 0.3
    },
    "desc": "Seperti phoenix: bangkit sekali dari kematian dengan 30% HP."
  },
  "c_lucky_coin": {
    "id": "c_lucky_coin",
    "name": "Koin Keberuntungan",
    "category": "accessory",
    "type": "equip",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "common",
    "price": 120,
    "emoji": "",
    "stats": {
      "spd": 1
    },
    "effect": {
      "kind": "goldFind",
      "pct": 0.1
    },
    "desc": "Koin kuno yang selalu menarik emas ke arahmu."
  },
  "c_swift": {
    "id": "c_swift",
    "name": "Cincin Gesit",
    "category": "accessory",
    "type": "equip",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "uncommon",
    "price": 100,
    "emoji": "",
    "stats": {
      "spd": 3
    },
    "effect": {
      "kind": "dodge",
      "pct": 0.04
    },
    "desc": "Gerakanmu lebih ringan — sedikit peluang menghindar."
  },
  "c_crit": {
    "id": "c_crit",
    "name": "Anting Kritis",
    "category": "accessory",
    "type": "equip",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "uncommon",
    "price": 100,
    "emoji": "",
    "stats": {
      "crit": 3
    },
    "effect": {
      "kind": "critDmg",
      "pct": 0.15
    },
    "desc": "Menajamkan insting — critical lebih berdarah."
  },
  "c_mana_ring": {
    "id": "c_mana_ring",
    "name": "Cincin Mana",
    "category": "accessory",
    "type": "equip",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "uncommon",
    "price": 180,
    "emoji": "",
    "stats": {
      "mp": 15
    },
    "effect": {
      "kind": "manaRegen",
      "val": 3
    },
    "desc": "Cincin safir yang meneteskan mana perlahan."
  },
  "c_cloak": {
    "id": "c_cloak",
    "name": "Jubah Bayangan",
    "category": "accessory",
    "type": "equip",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "rare",
    "price": 400,
    "emoji": "",
    "stats": {
      "spd": 6,
      "crit": 2
    },
    "effect": {
      "kind": "dodge",
      "pct": 0.08
    },
    "desc": "Menyatu dengan bayangan — serangan meleset lebih sering."
  },
  "c_vital": {
    "id": "c_vital",
    "name": "Gelang Vitalitas",
    "category": "accessory",
    "type": "equip",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "rare",
    "price": 420,
    "emoji": "",
    "stats": {
      "hp": 40
    },
    "effect": {
      "kind": "regen",
      "val": 2
    },
    "desc": "Menguatkan daya tahan tubuh dan memulihkannya."
  },
  "c_blood_pendant": {
    "id": "c_blood_pendant",
    "name": "Liontin Darah",
    "category": "accessory",
    "type": "equip",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "rare",
    "price": 450,
    "emoji": "",
    "stats": {
      "atk": 6
    },
    "effect": {
      "kind": "lifesteal",
      "pct": 0.08
    },
    "desc": "Berdenyut seperti jantung — menyerap nyawa musuh."
  },
  "c_thorn_bracer": {
    "id": "c_thorn_bracer",
    "name": "Deker Duri",
    "category": "accessory",
    "type": "equip",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "rare",
    "price": 440,
    "emoji": "",
    "stats": {
      "def": 4
    },
    "effect": {
      "kind": "thorns",
      "pct": 0.12
    },
    "desc": "Duri hitam yang melukai siapa pun yang menyerangmu."
  },
  "c_crown": {
    "id": "c_crown",
    "name": "Mahkota Raja",
    "category": "accessory",
    "type": "equip",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "epic",
    "price": 1200,
    "emoji": "",
    "stats": {
      "spd": 10,
      "crit": 5
    },
    "effect": {
      "kind": "goldFind",
      "pct": 0.15
    },
    "desc": "Harta karun para raja — emas mengalir lebih deras."
  },
  "c_storm_charm": {
    "id": "c_storm_charm",
    "name": "Jimat Badai",
    "category": "accessory",
    "type": "equip",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "epic",
    "price": 1250,
    "emoji": "",
    "stats": {
      "crit": 8
    },
    "effect": {
      "kind": "critDmg",
      "pct": 0.4
    },
    "desc": "Listrik badai meledak di setiap critical."
  },
  "c_guardian_angel": {
    "id": "c_guardian_angel",
    "name": "Pelindung Malaikat",
    "category": "accessory",
    "type": "equip",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "epic",
    "price": 1300,
    "emoji": "",
    "stats": {
      "def": 6,
      "hp": 30
    },
    "effect": {
      "kind": "shield",
      "pct": 0.15
    },
    "desc": "Sayap halus membentuk perisai cahaya di awal bertempur."
  },
  "c_phoenix": {
    "id": "c_phoenix",
    "name": "Kalung Phoenix",
    "category": "accessory",
    "type": "equip",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "mythic",
    "price": 4000,
    "emoji": "",
    "stats": {
      "hp": 50,
      "crit": 8
    },
    "effect": {
      "kind": "lifesteal",
      "pct": 0.12
    },
    "desc": "Abu phoenix — menghidupkan kembali semangatmu."
  },
  "c_time_hourglass": {
    "id": "c_time_hourglass",
    "name": "Jam Pasir Waktu",
    "category": "accessory",
    "type": "equip",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "mythic",
    "price": 4200,
    "emoji": "",
    "stats": {
      "spd": 8
    },
    "effect": {
      "kind": "revive",
      "pct": 0.25
    },
    "desc": "Mengulang sekejap waktu — bangkit sekali dengan 25% HP."
  },
  "p_heal_s": {
    "id": "p_heal_s",
    "name": "Ramuan Kecil",
    "category": "potion",
    "type": "consumable",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "common",
    "price": 20,
    "emoji": "",
    "stats": null,
    "effect": {
      "kind": "heal",
      "val": 40
    },
    "desc": "Pulihkan 40 HP."
  },
  "p_heal_m": {
    "id": "p_heal_m",
    "name": "Ramuan Sedang",
    "category": "potion",
    "type": "consumable",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "uncommon",
    "price": 50,
    "emoji": "",
    "stats": null,
    "effect": {
      "kind": "heal",
      "val": 100
    },
    "desc": "Pulihkan 100 HP."
  },
  "p_heal_l": {
    "id": "p_heal_l",
    "name": "Ramuan Besar",
    "category": "potion",
    "type": "consumable",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "rare",
    "price": 120,
    "emoji": "",
    "stats": null,
    "effect": {
      "kind": "heal",
      "val": 250
    },
    "desc": "Pulihkan 250 HP."
  },
  "p_mana": {
    "id": "p_mana",
    "name": "Ramuan Mana",
    "category": "potion",
    "type": "consumable",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "uncommon",
    "price": 40,
    "emoji": "",
    "stats": null,
    "effect": {
      "kind": "mana",
      "val": 50
    },
    "desc": "Pulihkan 50 MP."
  },
  "p_mana_l": {
    "id": "p_mana_l",
    "name": "Ramuan Mana Besar",
    "category": "potion",
    "type": "consumable",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "rare",
    "price": 95,
    "emoji": "",
    "stats": null,
    "effect": {
      "kind": "mana",
      "val": 120
    },
    "desc": "Pulihkan 120 MP."
  },
  "p_strength": {
    "id": "p_strength",
    "name": "Ramuan Kekuatan",
    "category": "potion",
    "type": "consumable",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "rare",
    "price": 90,
    "emoji": "",
    "stats": null,
    "effect": {
      "kind": "strength",
      "val": 0.35,
      "turns": 3
    },
    "desc": "ATK +35% selama 3 giliran."
  },
  "p_berserk": {
    "id": "p_berserk",
    "name": "Ramuan Amuk",
    "category": "potion",
    "type": "consumable",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "epic",
    "price": 140,
    "emoji": "",
    "stats": null,
    "effect": {
      "kind": "berserk",
      "val": 0.6,
      "turns": 2
    },
    "desc": "ATK +60% selama 2 giliran — amukan total."
  },
  "p_swift": {
    "id": "p_swift",
    "name": "Ramuan Kilat",
    "category": "potion",
    "type": "consumable",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "rare",
    "price": 85,
    "emoji": "",
    "stats": null,
    "effect": {
      "kind": "swift",
      "val": 0.25,
      "turns": 3
    },
    "desc": "Peluang menghindar +25% selama 3 giliran."
  },
  "p_regen": {
    "id": "p_regen",
    "name": "Ramuan Regenerasi",
    "category": "potion",
    "type": "consumable",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "rare",
    "price": 80,
    "emoji": "",
    "stats": null,
    "effect": {
      "kind": "regen",
      "val": 25,
      "turns": 4
    },
    "desc": "Regen +25 HP/giliran selama 4 giliran."
  },
  "p_manareg": {
    "id": "p_manareg",
    "name": "Ramuan Fokus",
    "category": "potion",
    "type": "consumable",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "rare",
    "price": 70,
    "emoji": "",
    "stats": null,
    "effect": {
      "kind": "manaRegen",
      "val": 15,
      "turns": 4
    },
    "desc": "Regen +15 MP/giliran selama 4 giliran."
  },
  "p_guard": {
    "id": "p_guard",
    "name": "Ramuan Pelindung",
    "category": "potion",
    "type": "consumable",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "epic",
    "price": 130,
    "emoji": "",
    "stats": null,
    "effect": {
      "kind": "shield",
      "val": 0.3
    },
    "desc": "Perisai 30% HP maks seketika."
  },
  "p_poison": {
    "id": "p_poison",
    "name": "Racun Mematikan",
    "category": "potion",
    "type": "consumable",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "epic",
    "price": 110,
    "emoji": "",
    "stats": null,
    "effect": {
      "kind": "poison",
      "val": 30,
      "turns": 3
    },
    "desc": "Racuni musuh: -30 HP/giliran selama 3 giliran."
  },
  "p_venom": {
    "id": "p_venom",
    "name": "Racun Viper",
    "category": "potion",
    "type": "consumable",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "epic",
    "price": 160,
    "emoji": "",
    "stats": null,
    "effect": {
      "kind": "venom",
      "val": 55,
      "turns": 3
    },
    "desc": "Racun super: -55 HP/giliran selama 3 giliran."
  },
  "p_weaken": {
    "id": "p_weaken",
    "name": "Racun Pelemah",
    "category": "potion",
    "type": "consumable",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "uncommon",
    "price": 85,
    "emoji": "",
    "stats": null,
    "effect": {
      "kind": "weaken",
      "val": 0.4,
      "turns": 3
    },
    "desc": "Melemahkan ATK musuh -40% selama 3 giliran."
  },
  "p_paralyze": {
    "id": "p_paralyze",
    "name": "Racun Lumpuh",
    "category": "potion",
    "type": "consumable",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "epic",
    "price": 180,
    "emoji": "",
    "stats": null,
    "effect": {
      "kind": "paralyze",
      "val": 1,
      "turns": 2
    },
    "desc": "Lumpuhkan musuh — ia melewatkan 2 giliran."
  },
  "p_elixir": {
    "id": "p_elixir",
    "name": "Elixir",
    "category": "potion",
    "type": "consumable",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "epic",
    "price": 300,
    "emoji": "",
    "stats": null,
    "effect": {
      "kind": "elixir"
    },
    "desc": "Pulihkan HP & MP sepenuhnya."
  },
  "m_slime_jelly": {
    "id": "m_slime_jelly",
    "name": "Jeli Slime",
    "category": "material",
    "type": "material",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "common",
    "price": 12,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Gumpalan jeli lengket. Dimakan: pulihkan 15 HP."
  },
  "m_rat_tail": {
    "id": "m_rat_tail",
    "name": "Ekor Tikus",
    "category": "material",
    "type": "material",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "common",
    "price": 10,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Ekor kering tikus kerangka. Dimakan: pulihkan 10 MP."
  },
  "m_bat_wing": {
    "id": "m_bat_wing",
    "name": "Sayap Kelelawar",
    "category": "material",
    "type": "material",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "common",
    "price": 12,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Sayap tipis jurang. Konsumsi: hindar +10% (2 giliran)."
  },
  "m_goblin_ear": {
    "id": "m_goblin_ear",
    "name": "Telinga Goblin",
    "category": "material",
    "type": "material",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "common",
    "price": 15,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Telinga runcing goblin. Dimakan: pulihkan 20 HP."
  },
  "m_bone": {
    "id": "m_bone",
    "name": "Tulang",
    "category": "material",
    "type": "material",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "common",
    "price": 10,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Tulang kerangka hidup. Digerus: ATK +10% (2 giliran)."
  },
  "m_wolf_pelt": {
    "id": "m_wolf_pelt",
    "name": "Bulu Serigala",
    "category": "material",
    "type": "material",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "uncommon",
    "price": 22,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Bulu tebal serigala. Dililitkan: perisai 10% HP maks."
  },
  "m_venom_sac": {
    "id": "m_venom_sac",
    "name": "Kantong Racun",
    "category": "material",
    "type": "material",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "uncommon",
    "price": 26,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Kantong racun laba-laba. Konsumsi: racun 12/giliran (2 giliran)."
  },
  "m_imp_ember": {
    "id": "m_imp_ember",
    "name": "Bara Iblis Kecil",
    "category": "material",
    "type": "material",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "uncommon",
    "price": 24,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Bara yang masih menyala. Konsumsi: ATK +15% (2 giliran)."
  },
  "m_hyena_fang": {
    "id": "m_hyena_fang",
    "name": "Taring Hyena",
    "category": "material",
    "type": "material",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "uncommon",
    "price": 22,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Taring tajam hyena gurun. Dimakan: pulihkan 25 HP."
  },
  "m_vulture_feather": {
    "id": "m_vulture_feather",
    "name": "Bulu Nasar",
    "category": "material",
    "type": "material",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "uncommon",
    "price": 22,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Bulu burung nasar. Konsumsi: hindar +12% (2 giliran)."
  },
  "m_turtle_shell": {
    "id": "m_turtle_shell",
    "name": "Tempurung Kura",
    "category": "material",
    "type": "material",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "rare",
    "price": 40,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Tempurung kura raksasa. Dipakai: perisai 15% HP maks."
  },
  "m_gargoyle_shard": {
    "id": "m_gargoyle_shard",
    "name": "Pecahan Gargoyle",
    "category": "material",
    "type": "material",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "rare",
    "price": 42,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Pecahan batu gargoyle. Digerus: ATK +12% (3 giliran)."
  },
  "m_mummy_bandage": {
    "id": "m_mummy_bandage",
    "name": "Perban Mumi",
    "category": "material",
    "type": "material",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "rare",
    "price": 40,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Perban kuno. Dililitkan: regen 15 HP/giliran (3 giliran)."
  },
  "m_orc_tusk": {
    "id": "m_orc_tusk",
    "name": "Taring Orc",
    "category": "material",
    "type": "material",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "rare",
    "price": 45,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Taring besar orc. Digerus: ATK +20% (2 giliran)."
  },
  "m_golem_core": {
    "id": "m_golem_core",
    "name": "Inti Golem",
    "category": "material",
    "type": "material",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "rare",
    "price": 50,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Inti batu berenergi. Dipakai: perisai 20% HP maks."
  },
  "m_wraith_ecto": {
    "id": "m_wraith_ecto",
    "name": "Ektoplasma",
    "category": "material",
    "type": "material",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "epic",
    "price": 70,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Arwah yang membeku. Konsumsi: pulihkan 60 MP."
  },
  "m_yeti_fur": {
    "id": "m_yeti_fur",
    "name": "Bulu Yeti",
    "category": "material",
    "type": "material",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "epic",
    "price": 80,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Bulu tebal yeti salju. Dipakai: regen 20 HP/giliran (3 giliran)."
  },
  "m_minotaur_horn": {
    "id": "m_minotaur_horn",
    "name": "Tanduk Minotaur",
    "category": "material",
    "type": "material",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "epic",
    "price": 95,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Tanduk sang minotaur. Digerus: ATK +40% (2 giliran)."
  },
  "m_dragon_scale": {
    "id": "m_dragon_scale",
    "name": "Sisik Naga",
    "category": "material",
    "type": "material",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "epic",
    "price": 110,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Sisik naga purba. Dipakai: perisai 25% HP maks."
  },
  "m_demon_heart": {
    "id": "m_demon_heart",
    "name": "Jantung Iblis",
    "category": "material",
    "type": "material",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "mythic",
    "price": 220,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Masih berdetak. Dikonsumsi: pulihkan HP & MP penuh."
  },
  "m_whistle_cracked": {
    "id": "m_whistle_cracked",
    "name": "Seruling Retak",
    "category": "material",
    "type": "use",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "uncommon",
    "price": 350,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Suaranya serak. Ditukar jadi 70 permata gacha + pecahan bintang."
  },
  "m_whistle_silver": {
    "id": "m_whistle_silver",
    "name": "Seruling Perak",
    "category": "material",
    "type": "use",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "rare",
    "price": 900,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Nada peraknya menembus jauh. Ditukar jadi 170 permata gacha + pecahan."
  },
  "m_whistle_gold": {
    "id": "m_whistle_gold",
    "name": "Seruling Emas",
    "category": "material",
    "type": "use",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "epic",
    "price": 2200,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Gema keemasan. Ditukar jadi 260 permata gacha + pecahan bintang."
  },
  "m_whistle_mythic": {
    "id": "m_whistle_mythic",
    "name": "Seruling Mistik",
    "category": "material",
    "type": "use",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "mythic",
    "price": 5000,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Pusaka purba. Ditukar jadi 550 permata gacha + banyak pecahan bintang."
  },
  "m_snack": {
    "id": "m_snack",
    "name": "Camilan Pet",
    "category": "material",
    "type": "use",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "common",
    "price": 60,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Biskuit ikan kering. Pet aktif +50 XP."
  },
  "m_snack_l": {
    "id": "m_snack_l",
    "name": "Hidangan Pet",
    "category": "material",
    "type": "use",
    "wtype": null,
    "atype": null,
    "class": null,
    "tier": "rare",
    "price": 200,
    "emoji": "",
    "stats": null,
    "effect": null,
    "desc": "Sajian lengkap berbahan langka. Pet aktif +150 XP."
  }
};

function getItem(id) { return ITEMS[id] || null; }

module.exports = { ITEMS, getItem };
