// ============================================================================
// DATA LAYER SISTEM RPG "KIZHOO ADVENTURE"
// ----------------------------------------------------------------------------
// Memakai koneksi better-sqlite3 yang SAMA dari database/db.js (satu file DB,
// jadi ikut ke-backup otomatis). Semua tabel RPG diprefix `rpg_`.
//
// Berisi: karakter, skill yang dibuka, party + member, quest + progress,
// dan permintaan promosi rank (MANUAL, butuh approval staff/owner).
// ============================================================================
const { db, getEconomy, updateBalance } = require('./db');

db.exec(`
CREATE TABLE IF NOT EXISTS rpg_characters (
  userId TEXT PRIMARY KEY,
  className TEXT NOT NULL,
  level INTEGER NOT NULL DEFAULT 1,
  xp INTEGER NOT NULL DEFAULT 0,
  rankKey TEXT NOT NULL DEFAULT 'G',
  statPoints INTEGER NOT NULL DEFAULT 0,
  skillPoints INTEGER NOT NULL DEFAULT 0,
  reputation INTEGER NOT NULL DEFAULT 0,
  hpBonus INTEGER NOT NULL DEFAULT 0,
  atkBonus INTEGER NOT NULL DEFAULT 0,
  defBonus INTEGER NOT NULL DEFAULT 0,
  spdBonus INTEGER NOT NULL DEFAULT 0,
  questsCompleted INTEGER NOT NULL DEFAULT 0,
  monstersKilled INTEGER NOT NULL DEFAULT 0,
  dungeonsCleared INTEGER NOT NULL DEFAULT 0,
  bossesDefeated INTEGER NOT NULL DEFAULT 0,
  worldQuests INTEGER NOT NULL DEFAULT 0,
  partyLed INTEGER NOT NULL DEFAULT 0,
  wins INTEGER NOT NULL DEFAULT 0,
  losses INTEGER NOT NULL DEFAULT 0,
  gold INTEGER NOT NULL DEFAULT 0,
  appearance TEXT DEFAULT '{}',
  titleText TEXT DEFAULT NULL,
  createdAt INTEGER NOT NULL,
  updatedAt INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS rpg_skills (
  userId TEXT NOT NULL,
  skillId TEXT NOT NULL,
  level INTEGER NOT NULL DEFAULT 1,
  PRIMARY KEY (userId, skillId)
);
CREATE TABLE IF NOT EXISTS rpg_parties (
  partyId INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT NOT NULL,
  leaderId TEXT NOT NULL,
  name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  maxSize INTEGER NOT NULL DEFAULT 4,
  createdAt INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS rpg_party_members (
  partyId INTEGER NOT NULL,
  userId TEXT NOT NULL,
  joinedAt INTEGER NOT NULL,
  PRIMARY KEY (partyId, userId)
);
CREATE TABLE IF NOT EXISTS rpg_party_category (
  guildId TEXT PRIMARY KEY,
  categoryId TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS rpg_quest_config (
  guildId TEXT PRIMARY KEY,
  channelId TEXT,
  autoGenerateEnabled INTEGER DEFAULT 0,
  lastGeneratedAt INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS rpg_quests (
  questId INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'daily',
  objectiveType TEXT NOT NULL,
  objectiveTarget INTEGER NOT NULL DEFAULT 1,
  rewardXp INTEGER NOT NULL DEFAULT 0,
  rewardGold INTEGER NOT NULL DEFAULT 0,
  rewardRep INTEGER NOT NULL DEFAULT 0,
  minRank TEXT DEFAULT 'G',
  source TEXT DEFAULT 'system',
  createdBy TEXT DEFAULT NULL,
  createdAt INTEGER NOT NULL,
  expiresAt INTEGER DEFAULT NULL,
  monsterHint TEXT DEFAULT NULL,
  active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS rpg_quest_progress (
  userId TEXT NOT NULL,
  questId INTEGER NOT NULL,
  progress INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active',
  acceptedAt INTEGER NOT NULL,
  PRIMARY KEY (userId, questId)
);
CREATE TABLE IF NOT EXISTS rpg_rank_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  userId TEXT NOT NULL,
  guildId TEXT NOT NULL,
  fromRank TEXT NOT NULL,
  toRank TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  reason TEXT DEFAULT NULL,
  reviewedBy TEXT DEFAULT NULL,
  createdAt INTEGER NOT NULL,
  reviewedAt INTEGER DEFAULT NULL
);
CREATE TABLE IF NOT EXISTS rpg_inventory (
  userId TEXT NOT NULL,
  itemId TEXT NOT NULL,
  qty INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (userId, itemId)
);
CREATE TABLE IF NOT EXISTS rpg_pets (
  userId TEXT NOT NULL,
  petId TEXT NOT NULL,
  level INTEGER NOT NULL DEFAULT 1,
  xp INTEGER NOT NULL DEFAULT 0,
  obtainedAt INTEGER NOT NULL,
  PRIMARY KEY (userId, petId)
);
`);

// Kolom pet aktif di karakter (satu pet menemani pada satu waktu).
(function ensurePetColumn() {
  const cols = db.prepare('PRAGMA table_info(rpg_characters)').all().map(c => c.name);
  if (!cols.includes('activePetId')) db.exec(`ALTER TABLE rpg_characters ADD COLUMN activePetId TEXT DEFAULT NULL`);
})();

// Kolom slot equipment (senjata/zirah/aksesoris) - dipisah dari inventory karena cuma boleh
// satu item terpasang per slot.
(function ensureEquipColumns() {
  const cols = db.prepare('PRAGMA table_info(rpg_characters)').all().map(c => c.name);
  const add = (col) => { if (!cols.includes(col)) db.exec(`ALTER TABLE rpg_characters ADD COLUMN ${col} TEXT DEFAULT NULL`); };
  add('equipWeapon'); add('equipArmor'); add('equipAccessory');
})();

// Auto-migrasi kolom baru buat DB lama yang sudah punya tabel rpg_parties dari versi sebelum
// fitur channel per-party ini ada (pola sama seperti ensureColumn di database/db.js).
(function ensurePartyChannelColumn() {
  const cols = db.prepare('PRAGMA table_info(rpg_parties)').all().map(c => c.name);
  if (!cols.includes('channelId')) db.exec('ALTER TABLE rpg_parties ADD COLUMN channelId TEXT');
})();

// Kolom kustomisasi karakter (rambut/ekspresi/baju/celana/sepatu) - dipakai di canvas
// (utils/rpgSprites.js drawCustomHero) buat /rpg customize dan render PvP nanti.
(function ensureCustomizationColumns() {
  const cols = db.prepare('PRAGMA table_info(rpg_characters)').all().map(c => c.name);
  const add = (col, def) => { if (!cols.includes(col)) db.exec(`ALTER TABLE rpg_characters ADD COLUMN ${col} TEXT DEFAULT '${def}'`); };
  add('hairStyle', 'short'); add('hairColor', '#1f2937'); add('expression', 'netral');
  add('outfitColor', ''); add('pantsColor', '#472a19'); add('shoesColor', '#0b0b12');
})();

// MIGRASI HEALER -> ARCHER (sekali jalan, idempoten):// class healer lama diubah jadi archer, senjata healer di inventory & slot equip
// dikonversi ke senjata archer lewat tabel alias (nilai stat setara).
(function ensureArcherMigration() {
  const rpgItems = require('../utils/rpgItems');
  db.prepare("UPDATE rpg_characters SET className = 'archer' WHERE className = 'healer'").run();
  const HEALER_TO_ARCHER = {
    w_wood_scepter: 'w_short_bow', w_holy_tome: 'w_hunt_longbow', w_moon_chalice: 'w_recurve_bow',
    w_blessed_relic: 'w_bone_bow', w_divine_staff: 'w_elven_bow', w_seraph: 'w_windseeker',
  };
  // Konversi slot equipment (kolom equipWeapon).
  const rows = db.prepare("SELECT userId, equipWeapon FROM rpg_characters WHERE equipWeapon IS NOT NULL").all();
  for (const r of rows) {
    const mapped = HEALER_TO_ARCHER[r.equipWeapon] || (rpgItems.getItem(r.equipWeapon) ? r.equipWeapon : null);
    // getItem me-resolve alias lama juga; kalau item tak dikenal, lepas (NULL) biar tidak nyangkut.
    const target = mapped && rpgItems.ITEMS[mapped] ? mapped : null;
    if (target !== r.equipWeapon) db.prepare('UPDATE rpg_characters SET equipWeapon = ? WHERE userId = ?').run(target, r.userId);
  }
  // Konversi isi inventory baris per baris (gabungkan qty bila menumpuk).
  const inv = db.prepare("SELECT userId, itemId, qty FROM rpg_inventory").all();
  for (const row of inv) {
    const it = rpgItems.getItem(row.itemId);
    const canonical = it ? it.id : null;
    if (!canonical) { db.prepare('DELETE FROM rpg_inventory WHERE userId = ? AND itemId = ?').run(row.userId, row.itemId); continue; }
    if (canonical !== row.itemId) {
      db.prepare('DELETE FROM rpg_inventory WHERE userId = ? AND itemId = ?').run(row.userId, row.itemId);
      addItem(row.userId, canonical, row.qty);
    }
  }
})();

// Kolom ALOKASI STAT tambahan (mp & crit) + IDENTITAS PEMAIN (nama panggung, friend ID,
// title dari achievement) + COUNTER BARU untuk sistem achievement & progresi web.
(function ensureWebRpgColumns() {
  const cols = db.prepare('PRAGMA table_info(rpg_characters)').all().map(c => c.name);
  const addInt = (col, def) => { if (!cols.includes(col)) db.exec(`ALTER TABLE rpg_characters ADD COLUMN ${col} INTEGER DEFAULT ${def}`); };
  const addText = (col, def) => { if (!cols.includes(col)) db.exec(`ALTER TABLE rpg_characters ADD COLUMN ${col} TEXT DEFAULT '${def}'`); };
  addInt('mpBonus', 0); addInt('critBonus', 0);
  addText('gameName', ''); addText('friendId', ''); addText('title', '');
  addInt('floorsCleared', 0); addInt('chestsOpened', 0); addInt('mimicsKilled', 0);
  addInt('itemsCrafted', 0); addInt('chatSent', 0); addInt('partyRaids', 0); addInt('potionsUsed', 0);
  // friendId unik per pemain — dibuat malas (saat pertama kali dibutuhkan).
})();

// Tabel web-era (achievement, friends, chat, sesi dashboard) TIDAK dibuat di
// sini lagi — dikelola penuh oleh blok SELF-HEAL di bawah, supaya skema lama/
// asing dari deploy campur versi dinormalkan DULU sebelum CREATE INDEX berjalan
// (index menuntut kolom tertentu; kalau tabel lama beda skema, exec di sini
// langsung meledak "no such column" sebelum sempat sembuh).

// ---- SELF-HEAL SKEMA (anti "no such column" pasca deploy campur versi) ----
// Kasus nyata: hosting sempat menjalankan rpgDb.js versi lama/asing yang membuat
// tabel chat dengan skema beda (mis. kode lama menuntut kolom `scope` yang tidak
// pernah ada di DB). Daripada query meledak 500 di setiap request, skema
// dinormalkan saat boot:
//  - kolom pelengkap yang hilang -> ALTER TABLE (data dipertahankan).
//  - kolom INTI yang hilang -> tabel di-reset. Achievement bisa dibuka ulang,
//    teman bisa ditambah ulang, riwayat chat & sesi login memang sementara.
//    Progres game (karakter, inventory, pet, quest) TIDAK tersentuh sama sekali.
(function healVolatileTables() {
  const heal = (table, core, addable) => {
    const exists = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name = ?").get(table);
    if (!exists) return; // belum ada -> CREATE TABLE IF NOT EXISTS di bawah sudah cukup.
    const cols = db.prepare(`PRAGMA table_info(${table})`).all().map(c => c.name);
    const missingCore = core.filter(c => !cols.includes(c));
    if (missingCore.length) {
      db.exec(`DROP TABLE ${table}`);
      console.log(`[rpgDb] Skema ${table} tidak kompatibel (kolom inti hilang: ${missingCore.join(', ')}) -> tabel di-reset.`);
      return;
    }
    for (const c of Object.keys(addable)) {
      if (!cols.includes(c)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${c} ${addable[c]}`);
    }
  };
  // 1) Periksa tabel yang SUDAH ada dulu (perbaiki/drop bila tidak kompatibel)...
  heal('rpg_chat_messages', ['id','channel','fromUserId','message','createdAt'], { toUserId: 'TEXT' });
  heal('dashboard_sessions', ['sid','payload','createdAt','expiresAt'], {});
  heal('rpg_achievements', ['userId','achId'], { unlockedAt: 'INTEGER NOT NULL DEFAULT 0', claimed: 'INTEGER NOT NULL DEFAULT 0' });
  heal('rpg_friends', ['userId','friendUserId'], { status: "TEXT NOT NULL DEFAULT 'accepted'", createdAt: 'INTEGER NOT NULL DEFAULT 0' });
  // 2) ...baru (re)buat skema final — mengisi kembali tabel yang barusan di-drop.
  db.exec(`CREATE TABLE IF NOT EXISTS rpg_achievements (
    userId TEXT NOT NULL,
    achId TEXT NOT NULL,
    unlockedAt INTEGER NOT NULL,
    claimed INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (userId, achId)
  );`);
  db.exec(`CREATE TABLE IF NOT EXISTS rpg_friends (
    userId TEXT NOT NULL,
    friendUserId TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'accepted',
    createdAt INTEGER NOT NULL,
    PRIMARY KEY (userId, friendUserId)
  );`);
  db.exec(`CREATE TABLE IF NOT EXISTS rpg_chat_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel TEXT NOT NULL,
    fromUserId TEXT NOT NULL,
    toUserId TEXT,
    message TEXT NOT NULL,
    createdAt INTEGER NOT NULL
  );`);
  db.exec(`CREATE INDEX IF NOT EXISTS idx_chat_channel_time ON rpg_chat_messages (channel, createdAt);`);
  db.exec(`CREATE INDEX IF NOT EXISTS idx_chat_dm_pair ON rpg_chat_messages (fromUserId, toUserId, createdAt);`);
  db.exec(`CREATE TABLE IF NOT EXISTS dashboard_sessions (
    sid TEXT PRIMARY KEY,
    payload TEXT NOT NULL,
    createdAt INTEGER NOT NULL,
    expiresAt INTEGER NOT NULL
  );`);
})();

// Mata uang tembaga/perak digabung sebagai kolom BARU (aditif, TIDAK mengubah/rescale kolom
// `gold` yang sudah ada sama sekali - nol risiko ke saldo yang sudah tersimpan). 100 tembaga =
// 1 perak, 100 perak = 1 gold (lihat utils/currency.js) - dipakai buat reward kecil/receh yang
// nambah rasa "koin fisik" tanpa ganggu harga/reward gold yang sudah dibalance sebelumnya.
// `goldMigratedAt` nandain kapan gold RPG user ini sudah dipindah ke saldo /economy per-server
// (unifikasi "gold RPG & balance biasa jadi satu") - dijalankan SEKALI per user (bukan per
// server) pas dia pertama kali sentuh fitur gold RPG lagi setelah update ini, biar tidak ada
// nilai yang duplikat/hilang karena karakter RPG bersifat global sedangkan saldo economy per-server.
(function ensureCoinColumns() {
  const cols = db.prepare('PRAGMA table_info(rpg_characters)').all().map(c => c.name);
  const add = (col, def) => { if (!cols.includes(col)) db.exec(`ALTER TABLE rpg_characters ADD COLUMN ${col} INTEGER DEFAULT ${def}`); };
  add('silver', 0); add('copper', 0); add('goldMigratedAt', 0);
})();

// Nama musuh "mentah" (mis. "griffin liar", "lich pemula") yang jadi SEED konkret quest ini pas
// digenerate (lihat utils/rpgQuestGenerator.js) - disimpan APA ADANYA biar kartu quest bisa milih
// ikon sprite yang beneran cocok sama musuhnya, bukan nebak-nebak dari teks flavor bebas yang
// ditulis AI (yang belum tentu literal menyebut nama monsternya).
(function ensureQuestMonsterHintColumn() {
  const cols = db.prepare('PRAGMA table_info(rpg_quests)').all().map(c => c.name);
  if (!cols.includes('monsterHint')) db.exec('ALTER TABLE rpg_quests ADD COLUMN monsterHint TEXT DEFAULT NULL');
})();

const now = () => Date.now();

// ---------------- CHARACTER ----------------
function getCharacter(userId) {
  return db.prepare('SELECT * FROM rpg_characters WHERE userId = ?').get(userId) || null;
}
function createCharacter(userId, className) {
  const t = now();
  db.prepare(`INSERT INTO rpg_characters (userId, className, createdAt, updatedAt)
              VALUES (?, ?, ?, ?)`).run(userId, className, t, t);
  return getCharacter(userId);
}
function updateCharacter(userId, fields) {
  const keys = Object.keys(fields);
  if (!keys.length) return getCharacter(userId);
  const setClause = keys.map(k => `${k} = @${k}`).join(', ');
  db.prepare(`UPDATE rpg_characters SET ${setClause}, updatedAt = @updatedAt WHERE userId = @userId`)
    .run({ ...fields, userId, updatedAt: now() });
  return getCharacter(userId);
}
// Naikkan sebuah counter secara aman (mis. questsCompleted, monstersKilled).
function incCharacter(userId, field, amount = 1) {
  const allowed = ['questsCompleted','monstersKilled','dungeonsCleared','bossesDefeated','worldQuests','partyLed','wins','losses','gold','reputation',
    'floorsCleared','chestsOpened','mimicsKilled','itemsCrafted','chatSent','partyRaids','potionsUsed',
    'mythicPetsOwned','worldBossHits','towerRuns','gachaPulled','evolutions','giftsClaimed','prestiges','secretRoomsFound','altarsUsed','merchantsMet'];
  if (!allowed.includes(field)) throw new Error(`Field counter tidak diizinkan: ${field}`);
  db.prepare(`UPDATE rpg_characters SET ${field} = ${field} + ?, updatedAt = ? WHERE userId = ?`).run(amount, now(), userId);
  return getCharacter(userId);
}
// Hapus karakter TOTAL beserta semua data terkait (skill, inventory, progress quest, dan
// keanggotaan party - kalau dia leader party, party itu ikut dibubarkan). Dipakai admin reset
// SAJA (destruktif & permanen) - bukan buat alur normal manapun.
function deleteCharacterCascade(userId) {
  const party = getPartyOfUser(userId);
  if (party) leaveParty(userId); // otomatis bubarkan kalau dia leader (lihat leaveParty)
  db.prepare('DELETE FROM rpg_skills WHERE userId = ?').run(userId);
  db.prepare('DELETE FROM rpg_inventory WHERE userId = ?').run(userId);
  db.prepare('DELETE FROM rpg_quest_progress WHERE userId = ?').run(userId);
  db.prepare('DELETE FROM rpg_characters WHERE userId = ?').run(userId);
}
function getLeaderboard(limit = 10, orderBy = 'level') {
  const col = ['level','reputation','wins','gold'].includes(orderBy) ? orderBy : 'level';
  return db.prepare(`SELECT * FROM rpg_characters ORDER BY ${col} DESC, xp DESC LIMIT ?`).all(limit);
}
// Karakter RPG itu GLOBAL (bukan per-server), jadi ini balikin SEMUA userId yang punya karakter
// di seluruh server tempat bot ini terpasang. Dipakai buat aksi massal (mis. "tambah gold semua
// user disini") - pemanggilnya WAJIB filter lagi ke member yang beneran ada di guild yang dimaksud,
// karena "punya karakter" tidak berarti "member di server ini".
function getAllCharacterUserIds() {
  return db.prepare('SELECT userId FROM rpg_characters').all().map(r => r.userId);
}

// ---------------- WALLET (gold RPG disatukan ke saldo /economy per-server) ----------------
// Karakter RPG bersifat GLOBAL (satu karakter dipakai di semua server bot ini terpasang),
// tapi saldo /economy itu PER-SERVER. Supaya nggak ada nilai yang duplikat/hilang saat
// disatukan, migrasi gold lama dijalankan SEKALI SAJA per user (bukan per server) - begitu
// user itu pertama kali menyentuh fitur gold RPG lagi di SERVER MANA PUN setelah update ini,
// gold lama-nya (kalau masih ada & belum pernah dipindah) ditambahkan ke saldo /economy di
// server itu, lalu kolom gold lama di-nolkan dan ditandai `goldMigratedAt` biar tidak
// kejadian lagi di server lain manapun.
function ensureGoldMigrated(userId, guildId) {
  const char = getCharacter(userId);
  if (!char.goldMigratedAt && char.gold > 0) {
    updateBalance(guildId, userId, char.gold);
    db.prepare('UPDATE rpg_characters SET gold = 0, goldMigratedAt = ? WHERE userId = ?').run(now(), userId);
  } else if (!char.goldMigratedAt) {
    db.prepare('UPDATE rpg_characters SET goldMigratedAt = ? WHERE userId = ?').run(now(), userId);
  }
}
// Dompet gabungan: gold (dari saldo /economy server ini, sudah satu sumber kebenaran) +
// perak/tembaga (recehan flavor RPG, kolom baru, terpisah dari gold - lihat ensureCoinColumns).
function getWallet(userId, guildId) {
  ensureGoldMigrated(userId, guildId);
  const char = getCharacter(userId);
  const econ = getEconomy(guildId, userId);
  return { gold: econ.balance, silver: char.silver, copper: char.copper };
}
// Tambah/kurangi gold (lewat saldo /economy) - dipakai gantiin incCharacter(...,'gold',...) yang lama.
function addGold(userId, guildId, amount) {
  ensureGoldMigrated(userId, guildId);
  return updateBalance(guildId, userId, amount);
}
// Tambah perak/tembaga (recehan flavor) - independen dari gold, boleh negatif buat dikurangi.
function addCoins(userId, { silver = 0, copper = 0 } = {}) {
  db.prepare('UPDATE rpg_characters SET silver = MAX(0, silver + ?), copper = MAX(0, copper + ?), updatedAt = ? WHERE userId = ?')
    .run(silver, copper, now(), userId);
  return getCharacter(userId);
}

// ---------------- INVENTORY & EQUIPMENT ----------------
function getInventory(userId) {
  return db.prepare('SELECT * FROM rpg_inventory WHERE userId = ? AND qty > 0 ORDER BY itemId').all(userId);
}
function getItemQty(userId, itemId) {
  return db.prepare('SELECT qty FROM rpg_inventory WHERE userId = ? AND itemId = ?').get(userId, itemId)?.qty || 0;
}
function addItem(userId, itemId, qty = 1) {
  db.prepare(`
    INSERT INTO rpg_inventory (userId, itemId, qty) VALUES (?, ?, ?)
    ON CONFLICT(userId, itemId) DO UPDATE SET qty = qty + excluded.qty
  `).run(userId, itemId, qty);
}
// Return false (tanpa mengubah apa pun) kalau qty di tangan kurang dari yang mau dikurangi -
// dicek DULU sebelum UPDATE, biar tidak pernah kejadian qty jadi negatif.
function removeItem(userId, itemId, qty = 1) {
  const have = getItemQty(userId, itemId);
  if (have < qty) return false;
  db.prepare('UPDATE rpg_inventory SET qty = qty - ? WHERE userId = ? AND itemId = ?').run(qty, userId, itemId);
  return true;
}
// Pasang item ke slot (equipWeapon/equipArmor/equipAccessory). Item lama di slot itu (kalau
// ada) otomatis balik ke inventory - jadi tidak pernah ada item yang hilang begitu saja.
function equipItem(userId, itemId, slotColumn) {
  if (!['equipWeapon', 'equipArmor', 'equipAccessory'].includes(slotColumn)) throw new Error(`Slot tidak valid: ${slotColumn}`);
  const char = getCharacter(userId);
  if (!char) return { ok: false, error: 'Karakter belum dibuat.' };
  // Senjata terikat kelas: heal cuma bisa pakai senjata healer, dst.
  if (slotColumn === 'equipWeapon') {
    const rpgItems = require('../utils/rpgItems');
    const it = rpgItems.getItem(itemId);
    if (it && it.category === 'weapon' && it.class && it.class !== char.className) {
      return { ok: false, error: `Senjata ini hanya untuk ${it.class}.` };
    }
  }
  if (!removeItem(userId, itemId, 1)) return { ok: false, error: 'Item tidak ada di inventorymu.' };
  const previous = char[slotColumn];
  if (previous) addItem(userId, previous, 1);
  db.prepare(`UPDATE rpg_characters SET ${slotColumn} = ?, updatedAt = ? WHERE userId = ?`).run(itemId, now(), userId);
  return { ok: true, previous, character: getCharacter(userId) };
}
function unequipItem(userId, slotColumn) {
  if (!['equipWeapon', 'equipArmor', 'equipAccessory'].includes(slotColumn)) throw new Error(`Slot tidak valid: ${slotColumn}`);
  const char = getCharacter(userId);
  const current = char[slotColumn];
  if (!current) return { ok: false, error: 'Slot itu lagi kosong.' };
  addItem(userId, current, 1);
  db.prepare(`UPDATE rpg_characters SET ${slotColumn} = NULL, updatedAt = ? WHERE userId = ?`).run(now(), userId);
  return { ok: true, item: current, character: getCharacter(userId) };
}

// ---------------- SKILLS ----------------
function getSkills(userId) {
  return db.prepare('SELECT * FROM rpg_skills WHERE userId = ?').all(userId);
}
function getSkillLevel(userId, skillId) {
  return db.prepare('SELECT level FROM rpg_skills WHERE userId = ? AND skillId = ?').get(userId, skillId)?.level || 0;
}
function setSkillLevel(userId, skillId, level) {
  db.prepare(`INSERT INTO rpg_skills (userId, skillId, level) VALUES (?, ?, ?)
              ON CONFLICT(userId, skillId) DO UPDATE SET level = excluded.level`).run(userId, skillId, level);
}
function resetSkills(userId) {
  db.prepare('DELETE FROM rpg_skills WHERE userId = ?').run(userId);
}

// ---------------- PARTY ----------------
function createParty(guildId, leaderId, name, maxSize = 4) {
  const info = db.prepare('INSERT INTO rpg_parties (guildId, leaderId, name, createdAt, maxSize) VALUES (?, ?, ?, ?, ?)')
    .run(guildId, leaderId, name, now(), maxSize);
  const partyId = info.lastInsertRowid;
  db.prepare('INSERT INTO rpg_party_members (partyId, userId, joinedAt) VALUES (?, ?, ?)').run(partyId, leaderId, now());
  return getParty(partyId);
}
function getParty(partyId) {
  const party = db.prepare('SELECT * FROM rpg_parties WHERE partyId = ?').get(partyId);
  if (!party) return null;
  party.members = db.prepare('SELECT userId, joinedAt FROM rpg_party_members WHERE partyId = ? ORDER BY joinedAt').all(partyId);
  return party;
}
function getPartyOfUser(userId) {
  const row = db.prepare('SELECT partyId FROM rpg_party_members WHERE userId = ?').get(userId);
  return row ? getParty(row.partyId) : null;
}
function listOpenParties(guildId) {
  const rows = db.prepare("SELECT * FROM rpg_parties WHERE guildId = ? AND status = 'open' ORDER BY createdAt DESC").all(guildId);
  return rows.map(p => getParty(p.partyId));
}
function joinParty(partyId, userId) {
  db.prepare('INSERT OR IGNORE INTO rpg_party_members (partyId, userId, joinedAt) VALUES (?, ?, ?)').run(partyId, userId, now());
  return getParty(partyId);
}
function leaveParty(userId) {
  const party = getPartyOfUser(userId);
  if (!party) return null;
  db.prepare('DELETE FROM rpg_party_members WHERE partyId = ? AND userId = ?').run(party.partyId, userId);
  // Kalau leader keluar: bubarkan party (atau bisa dikembangkan: pindah kepemimpinan).
  if (party.leaderId === userId) {
    db.prepare('DELETE FROM rpg_party_members WHERE partyId = ?').run(party.partyId);
    db.prepare('DELETE FROM rpg_parties WHERE partyId = ?').run(party.partyId);
    return { disbanded: true, party };
  }
  return { disbanded: false, party: getParty(party.partyId) };
}
function setPartyStatus(partyId, status) {
  db.prepare('UPDATE rpg_parties SET status = ? WHERE partyId = ?').run(status, partyId);
  return getParty(partyId);
}
function setPartyChannel(partyId, channelId) {
  db.prepare('UPDATE rpg_parties SET channelId = ? WHERE partyId = ?').run(channelId, partyId);
  return getParty(partyId);
}
function getPartyCategoryId(guildId) {
  return db.prepare('SELECT categoryId FROM rpg_party_category WHERE guildId = ?').get(guildId)?.categoryId || null;
}
function setPartyCategoryId(guildId, categoryId) {
  db.prepare(`
    INSERT INTO rpg_party_category (guildId, categoryId) VALUES (?, ?)
    ON CONFLICT(guildId) DO UPDATE SET categoryId = excluded.categoryId
  `).run(guildId, categoryId);
}

// ---------------- QUESTS ----------------
function createQuest(q) {
  const info = db.prepare(`INSERT INTO rpg_quests
    (guildId, title, description, type, objectiveType, objectiveTarget, rewardXp, rewardGold, rewardRep, minRank, source, createdBy, createdAt, expiresAt, monsterHint)
    VALUES (@guildId, @title, @description, @type, @objectiveType, @objectiveTarget, @rewardXp, @rewardGold, @rewardRep, @minRank, @source, @createdBy, @createdAt, @expiresAt, @monsterHint)`)
    .run({
      guildId: q.guildId, title: q.title, description: q.description, type: q.type || 'daily',
      objectiveType: q.objectiveType, objectiveTarget: q.objectiveTarget || 1,
      rewardXp: q.rewardXp || 0, rewardGold: q.rewardGold || 0, rewardRep: q.rewardRep || 0,
      minRank: q.minRank || 'G', source: q.source || 'system', createdBy: q.createdBy || null,
      createdAt: now(), expiresAt: q.expiresAt || null, monsterHint: q.monsterHint || null,
    });
  return getQuest(info.lastInsertRowid);
}
function getQuest(questId) {
  return db.prepare('SELECT * FROM rpg_quests WHERE questId = ?').get(questId) || null;
}
// Cek kelayakan quest buat diterima yang BENERAN live, bukan cuma nengok kolom `active` (yang
// SEBELUMNYA cuma ke-update kalau ada yang buka /rpg quest board - jadi tombol "Terima" di pesan
// LAMA bisa aja masih keliatan bisa diklik & LOLOS walau expiresAt-nya sudah lewat, karena
// `active`-nya belum sempat di-set 0 sama siapa pun). Dipakai SATU tempat ini di semua jalur
// terima quest (tombol, /rpg quest accept, tool Luna) biar konsisten & tidak ada yang kelewat.
function isQuestOpen(q) {
  if (!q || !q.active) return false;
  if (q.expiresAt && q.expiresAt <= Date.now()) return false;
  return true;
}

// ---------------- LACAK PESAN PAPAN QUEST (biar bisa di-edit otomatis pas kadaluarsa) ----------------
// "Papan quest ilang otomatis kalau waktunya habis" - Discord tidak punya cara bikin pesan
// "kadaluarsa sendiri", jadi kita catat pesan mana nampilin quest mana pas di-post, lalu job
// berkala di events/ready.js ngecek dan EDIT pesannya (ganti gambar+hapus tombol) begitu SEMUA
// quest yang ditampilkan di situ sudah lewat expiresAt-nya.
db.exec(`
CREATE TABLE IF NOT EXISTS rpg_quest_posts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT NOT NULL,
  channelId TEXT NOT NULL,
  messageId TEXT NOT NULL,
  questIds TEXT NOT NULL,
  maxExpiresAt INTEGER,
  cleaned INTEGER NOT NULL DEFAULT 0,
  createdAt INTEGER NOT NULL
);
`);
function recordQuestPost(guildId, channelId, messageId, quests) {
  const expiries = quests.map(q => q.expiresAt).filter(Boolean);
  if (!expiries.length) return; // tidak ada expiresAt sama sekali (harusnya tidak pernah kejadian) - jangan dilacak, biar aman dibiarkan apa adanya
  const maxExpiresAt = Math.max(...expiries);
  db.prepare('INSERT INTO rpg_quest_posts (guildId, channelId, messageId, questIds, maxExpiresAt, cleaned, createdAt) VALUES (?, ?, ?, ?, ?, 0, ?)')
    .run(guildId, channelId, messageId, JSON.stringify(quests.map(q => q.questId)), maxExpiresAt, now());
}
function getDueQuestPosts(limit = 25) {
  return db.prepare('SELECT * FROM rpg_quest_posts WHERE cleaned = 0 AND maxExpiresAt IS NOT NULL AND maxExpiresAt <= ? ORDER BY maxExpiresAt ASC LIMIT ?').all(now(), limit);
}
function markQuestPostCleaned(id) {
  db.prepare('UPDATE rpg_quest_posts SET cleaned = 1 WHERE id = ?').run(id);
}
function listActiveQuests(guildId, limit = 25) {
  const t = now();
  return db.prepare('SELECT * FROM rpg_quests WHERE guildId = ? AND active = 1 AND (expiresAt IS NULL OR expiresAt > ?) ORDER BY createdAt DESC LIMIT ?')
    .all(guildId, t, limit);
}
function deactivateExpiredQuests() {
  db.prepare('UPDATE rpg_quests SET active = 0 WHERE expiresAt IS NOT NULL AND expiresAt <= ?').run(now());
}
function acceptQuest(userId, questId) {
  db.prepare('INSERT OR IGNORE INTO rpg_quest_progress (userId, questId, acceptedAt) VALUES (?, ?, ?)').run(userId, questId, now());
  return getQuestProgress(userId, questId);
}
function getQuestProgress(userId, questId) {
  return db.prepare('SELECT * FROM rpg_quest_progress WHERE userId = ? AND questId = ?').get(userId, questId) || null;
}
function getUserActiveQuests(userId) {
  return db.prepare(`SELECT qp.*, q.title, q.objectiveType, q.objectiveTarget, q.rewardXp, q.rewardGold, q.rewardRep
                     FROM rpg_quest_progress qp JOIN rpg_quests q ON q.questId = qp.questId
                     WHERE qp.userId = ? AND qp.status = 'active'`).all(userId);
}
function updateQuestProgress(userId, questId, progress, status) {
  db.prepare('UPDATE rpg_quest_progress SET progress = ?, status = ? WHERE userId = ? AND questId = ?')
    .run(progress, status, userId, questId);
  return getQuestProgress(userId, questId);
}
// Majukan progress SEMUA quest aktif user yang objectiveType-nya cocok (mis. 'monstersKilled').
// Cuma urusan data (update angka + tandai selesai) - pemberian reward (XP/gold/rep) sengaja
// diserahkan ke pemanggil (rpg.js/rpgBattle.js) yang sudah punya akses ke rpgEngine, biar
// modul ini tidak perlu require rpgEngine.js balik (rpgEngine.js sudah require modul ini).
function advanceQuestProgress(userId, objectiveType, amount = 1) {
  const rows = getUserActiveQuests(userId).filter(q => q.objectiveType === objectiveType);
  const completed = [];
  for (const q of rows) {
    const newProgress = Math.min(q.objectiveTarget, q.progress + amount);
    const done = newProgress >= q.objectiveTarget;
    updateQuestProgress(userId, q.questId, newProgress, done ? 'completed' : 'active');
    if (done) completed.push(q);
  }
  return completed;
}

// ---------------- PETS ----------------
// Koleksi pet milik user (satu baris per jenis pet) + pet yang sedang aktif.
function getPets(userId) {
  return db.prepare('SELECT * FROM rpg_pets WHERE userId = ? ORDER BY obtainedAt').all(userId);
}
function getPet(userId, petId) {
  return db.prepare('SELECT * FROM rpg_pets WHERE userId = ? AND petId = ?').get(userId, petId) || null;
}
// Beri pet ke user. Kalau sudah punya -> return { duplicate: true } TANPA mengubah
// apa pun (pemanggil yang menentukan kompensasinya, mis. dikonversi jadi camilan).
function grantPet(userId, petId) {
  const existing = getPet(userId, petId);
  if (existing) return { ok: true, duplicate: true, pet: existing };
  db.prepare('INSERT INTO rpg_pets (userId, petId, level, xp, obtainedAt) VALUES (?, ?, 1, 0, ?)').run(userId, petId, now());
  // Pet pertama langsung diaktifkan otomatis biar langsung terlihat menemani.
  const char = getCharacter(userId);
  if (char && !char.activePetId) db.prepare('UPDATE rpg_characters SET activePetId = ?, updatedAt = ? WHERE userId = ?').run(petId, now(), userId);
  return { ok: true, duplicate: false, pet: getPet(userId, petId) };
}
function setActivePet(userId, petId) {
  const owned = getPet(userId, petId);
  if (!owned) return { ok: false, error: 'Kamu belum memiliki pet itu.' };
  db.prepare('UPDATE rpg_characters SET activePetId = ?, updatedAt = ? WHERE userId = ?').run(petId, now(), userId);
  return { ok: true };
}
function getActivePet(userId) {
  const char = getCharacter(userId);
  if (!char || !char.activePetId) return null;
  return getPet(userId, char.activePetId);
}
// Tambah XP pet (level up otomatis sampai cap). Return info level baru + sisa xp.
function addPetXp(userId, petId, amount) {
  const D = require('../utils/rpgData');
  const pet = getPet(userId, petId);
  if (!pet) return { ok: false, error: 'Pet tidak ditemukan.' };
  let { level, xp } = pet;
  if (level >= D.PET_LEVEL_CAP) return { ok: true, level, xp, capped: true };
  xp += Math.max(0, Math.floor(amount));
  let leveled = 0;
  while (level < D.PET_LEVEL_CAP && xp >= D.petXpForLevel(level)) {
    xp -= D.petXpForLevel(level);
    level += 1;
    leveled += 1;
  }
  if (level >= D.PET_LEVEL_CAP) xp = 0;
  db.prepare('UPDATE rpg_pets SET level = ?, xp = ? WHERE userId = ? AND petId = ?').run(level, xp, userId, petId);
  return { ok: true, level, xp, leveled };
}

// ---------------- RANK REQUESTS (promosi MANUAL) ----------------
// ---------------- QUEST CONFIG (buat auto-generate quest via AI) ----------------
function getQuestConfig(guildId) {
  let row = db.prepare('SELECT * FROM rpg_quest_config WHERE guildId = ?').get(guildId);
  if (!row) {
    db.prepare('INSERT INTO rpg_quest_config (guildId) VALUES (?)').run(guildId);
    row = db.prepare('SELECT * FROM rpg_quest_config WHERE guildId = ?').get(guildId);
  }
  return row;
}
function updateQuestConfig(guildId, fields) {
  getQuestConfig(guildId);
  const keys = Object.keys(fields);
  if (!keys.length) return;
  const setClause = keys.map(k => `${k} = @${k}`).join(', ');
  db.prepare(`UPDATE rpg_quest_config SET ${setClause} WHERE guildId = @guildId`).run({ guildId, ...fields });
}
function getQuestConfigsWithAutoGen() {
  return db.prepare('SELECT * FROM rpg_quest_config WHERE channelId IS NOT NULL AND autoGenerateEnabled = 1').all();
}

function createRankRequest(userId, guildId, fromRank, toRank, reason) {
  // Jangan buat duplikat pending.
  const existing = db.prepare("SELECT * FROM rpg_rank_requests WHERE userId = ? AND status = 'pending'").get(userId);
  if (existing) return { existing, request: existing };
  const info = db.prepare(`INSERT INTO rpg_rank_requests (userId, guildId, fromRank, toRank, reason, createdAt)
                           VALUES (?, ?, ?, ?, ?, ?)`).run(userId, guildId, fromRank, toRank, reason || null, now());
  return { existing: null, request: db.prepare('SELECT * FROM rpg_rank_requests WHERE id = ?').get(info.lastInsertRowid) };
}
function getRankRequest(id) {
  return db.prepare('SELECT * FROM rpg_rank_requests WHERE id = ?').get(id) || null;
}
function listPendingRankRequests(guildId) {
  return db.prepare("SELECT * FROM rpg_rank_requests WHERE guildId = ? AND status = 'pending' ORDER BY createdAt").all(guildId);
}
function resolveRankRequest(id, status, reviewedBy) {
  db.prepare('UPDATE rpg_rank_requests SET status = ?, reviewedBy = ?, reviewedAt = ? WHERE id = ?')
    .run(status, reviewedBy, now(), id);
  return getRankRequest(id);
}

// ---------------- ACHIEVEMENT ----------------
// Daftar achievement yang sudah terbuka (tanpa progress — progress dihitung di rpgServer
// dari counter karakter, biar selalu sinkron dengan data terbaru).
function getAchievements(userId) {
  return db.prepare('SELECT * FROM rpg_achievements WHERE userId = ?').all(userId);
}
function unlockAchievement(userId, achId) {
  db.prepare('INSERT OR IGNORE INTO rpg_achievements (userId, achId, unlockedAt, claimed) VALUES (?, ?, ?, 0)')
    .run(userId, achId, now());
}
function claimAchievement(userId, achId) {
  db.prepare('UPDATE rpg_achievements SET claimed = 1 WHERE userId = ? AND achId = ?').run(userId, achId);
}

// ---------------- TEMAN ----------------
// Model: dua baris simetris (A->B dan B->A) untuk pertemanan yang diterima.
// Permintaan tertimbun sebagai baris status 'pending' SATU ARAH (pemohon -> target).
function addFriend(userId, friendUserId) {
  const t = now();
  db.prepare(`INSERT INTO rpg_friends (userId, friendUserId, status, createdAt) VALUES (?, ?, 'accepted', ?)
              ON CONFLICT(userId, friendUserId) DO UPDATE SET status = 'accepted'`)
    .run(userId, friendUserId, t);
  db.prepare(`INSERT INTO rpg_friends (userId, friendUserId, status, createdAt) VALUES (?, ?, 'accepted', ?)
              ON CONFLICT(userId, friendUserId) DO UPDATE SET status = 'accepted'`)
    .run(friendUserId, userId, t);
}
function requestFriend(fromUserId, toUserId) {
  db.prepare(`INSERT INTO rpg_friends (userId, friendUserId, status, createdAt) VALUES (?, ?, 'pending', ?)
              ON CONFLICT(userId, friendUserId) DO UPDATE SET status = 'pending'`)
    .run(fromUserId, toUserId, now());
}
function removeFriend(userId, friendUserId) {
  db.prepare('DELETE FROM rpg_friends WHERE (userId = ? AND friendUserId = ?) OR (userId = ? AND friendUserId = ?)')
    .run(userId, friendUserId, friendUserId, userId);
}
function getFriends(userId) {
  return db.prepare("SELECT * FROM rpg_friends WHERE userId = ? AND status = 'accepted'").all(userId);
}
function getPendingRequests(userId) {
  return db.prepare("SELECT * FROM rpg_friends WHERE friendUserId = ? AND status = 'pending'").all(userId);
}
// Cari pemain berdasarkan nama panggung / friendId / userId (untuk tambah teman).
function searchPlayers(query, limit = 10) {
  const q = String(query || '').trim();
  if (!q) return [];
  const like = `%${q}%`;
  return db.prepare(`
    SELECT userId, gameName, friendId, className, level, rankKey, title FROM rpg_characters
    WHERE userId LIKE ? OR (gameName != '' AND gameName LIKE ?) OR (friendId != '' AND friendId LIKE ?)
    LIMIT ?`).all(like, like, like, limit);
}

// ---------------- CHAT ----------------
function addChatMessage({ channel, fromUserId, toUserId = null, message }) {
  const info = db.prepare('INSERT INTO rpg_chat_messages (channel, fromUserId, toUserId, message, createdAt) VALUES (?, ?, ?, ?, ?)')
    .run(channel, fromUserId, toUserId, String(message).slice(0, 300), now());
  return { id: info.lastInsertRowid, channel, fromUserId, toUserId, message: String(message).slice(0, 300), createdAt: now() };
}
function getChatHistory(channel, { limit = 40, before = null } = {}) {
  if (before) {
    return db.prepare('SELECT * FROM rpg_chat_messages WHERE channel = ? AND id < ? ORDER BY id DESC LIMIT ?')
      .all(channel, before, limit).reverse();
  }
  return db.prepare('SELECT * FROM rpg_chat_messages WHERE channel = ? ORDER BY id DESC LIMIT ?')
    .all(channel, limit).reverse();
}
function getDmHistory(userA, userB, { limit = 60 } = {}) {
  return db.prepare(`SELECT * FROM rpg_chat_messages WHERE channel = 'dm'
    AND ((fromUserId = ? AND toUserId = ?) OR (fromUserId = ? AND toUserId = ?))
    ORDER BY id DESC LIMIT ?`).all(userA, userB, userB, userA, limit).reverse();
}

// ---------------- SESSION DASHBOARD (persist, tahan restart) ----------------
function saveSession(sid, payload, maxAgeMs = 30 * 24 * 3600 * 1000) {
  const t = now();
  db.prepare(`INSERT INTO dashboard_sessions (sid, payload, createdAt, expiresAt) VALUES (?, ?, ?, ?)
              ON CONFLICT(sid) DO UPDATE SET payload = excluded.payload, expiresAt = excluded.expiresAt`)
    .run(sid, JSON.stringify(payload), t, t + maxAgeMs);
}
function getSession(sid) {
  const row = db.prepare('SELECT * FROM dashboard_sessions WHERE sid = ? AND expiresAt > ?').get(sid, now());
  if (!row) return null;
  try { return JSON.parse(row.payload); } catch (_) { return null; }
}
function deleteSession(sid) {
  db.prepare('DELETE FROM dashboard_sessions WHERE sid = ?').run(sid);
}
function cleanExpiredSessions() {
  db.prepare('DELETE FROM dashboard_sessions WHERE expiresAt <= ?').run(now());
}

// ---------------- FRIEND ID (kode undangan unik) ----------------
function ensureFriendId(userId) {
  const char = getCharacter(userId);
  if (!char) return null;
  if (char.friendId) return char.friendId;
  const code = () => 'KZ-' + [...Array(4)].map(() => 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[Math.floor(Math.random() * 32)]).join('');
  let fid = code();
  let guard = 0;
  while (db.prepare('SELECT 1 FROM rpg_characters WHERE friendId = ?').get(fid) && guard++ < 20) fid = code();
  updateCharacter(userId, { friendId: fid });
  return fid;
}

// ---------------- MIGRASI SISTEM BARU (gacha / evolusi / mode spesial) ----------------
(function ensureV3Columns() {
  const cols = db.prepare('PRAGMA table_info(rpg_characters)').all().map(c => c.name);
  const add = (col, def) => { if (!cols.includes(col)) db.exec(`ALTER TABLE rpg_characters ADD COLUMN ${col} ${def}`); };
  // Mata uang gacha & pecahan evolusi.
  add('gems', 'INTEGER NOT NULL DEFAULT 0');
  add('petShards', 'INTEGER NOT NULL DEFAULT 0');
  // Counter gacha + pity (tarikan sejak last epic+/legendary+/mythic).
  add('gachaPulled', 'INTEGER NOT NULL DEFAULT 0');
  add('pitySinceEpic', 'INTEGER NOT NULL DEFAULT 0');
  add('pitySinceLegendary', 'INTEGER NOT NULL DEFAULT 0');
  add('pitySinceMythic', 'INTEGER NOT NULL DEFAULT 0');
  // Counter achievement & progression mode baru.
  add('petsEvolved', 'INTEGER NOT NULL DEFAULT 0');
  add('mythicPetsOwned', 'INTEGER NOT NULL DEFAULT 0');
  add('towerBest', 'INTEGER NOT NULL DEFAULT 0');
  add('worldbossHits', 'INTEGER NOT NULL DEFAULT 0');
  add('bestCombo', 'INTEGER NOT NULL DEFAULT 0');
  add('prestigeLevel', 'INTEGER NOT NULL DEFAULT 0');
  add('giftsSent', 'INTEGER NOT NULL DEFAULT 0');
  add('auctionsListed', 'INTEGER NOT NULL DEFAULT 0');
  add('auctionsWon', 'INTEGER NOT NULL DEFAULT 0');
  // Gelar yang sedang dipakai (dari daftar gelar achievement/prestige).
  add('equippedTitle', "TEXT DEFAULT NULL");
  // Pangkat evolusi pet (1 = anak-anak, 2 = evolusi).
  const pcols = db.prepare('PRAGMA table_info(rpg_pets)').all().map(c => c.name);
  if (!pcols.includes('stage')) db.exec(`ALTER TABLE rpg_pets ADD COLUMN stage INTEGER NOT NULL DEFAULT 1`);
  if (!pcols.includes('evolvedAt')) db.exec(`ALTER TABLE rpg_pets ADD COLUMN evolvedAt INTEGER DEFAULT NULL`);
})();

(function ensureV3Tables() {
  db.exec(`
  CREATE TABLE IF NOT EXISTS rpg_worldboss (
    weekKey TEXT PRIMARY KEY,
    bossId TEXT NOT NULL,
    hp INTEGER NOT NULL,
    maxHp INTEGER NOT NULL,
    defeatedAt INTEGER DEFAULT NULL,
    createdAt INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS rpg_worldboss_damage (
    weekKey TEXT NOT NULL,
    userId TEXT NOT NULL,
    damage INTEGER NOT NULL DEFAULT 0,
    hits INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (weekKey, userId)
  );
  CREATE TABLE IF NOT EXISTS rpg_auctions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sellerId TEXT NOT NULL,
    itemId TEXT NOT NULL,
    qty INTEGER NOT NULL DEFAULT 1,
    price INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    buyerId TEXT DEFAULT NULL,
    createdAt INTEGER NOT NULL,
    closedAt INTEGER DEFAULT NULL
  );
  CREATE TABLE IF NOT EXISTS rpg_gifts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fromUserId TEXT NOT NULL,
    toUserId TEXT NOT NULL,
    kind TEXT NOT NULL,
    itemId TEXT DEFAULT NULL,
    qty INTEGER NOT NULL DEFAULT 0,
    gold INTEGER NOT NULL DEFAULT 0,
    gems INTEGER NOT NULL DEFAULT 0,
    message TEXT DEFAULT NULL,
    claimed INTEGER NOT NULL DEFAULT 0,
    createdAt INTEGER NOT NULL
  );
  `);
})();

// ---------------- GEM & SHARD ----------------
function addGems(userId, amount) {
  const n = Math.max(0, Math.floor(amount));
  if (n) db.prepare('UPDATE rpg_characters SET gems = gems + ?, updatedAt = ? WHERE userId = ?').run(n, now(), userId);
  return getCharacter(userId).gems;
}
function spendGems(userId, amount) {
  const char = getCharacter(userId);
  const n = Math.floor(amount);
  if (!char || char.gems < n) return { ok: false, error: 'Permata tidak cukup.' };
  db.prepare('UPDATE rpg_characters SET gems = gems - ?, updatedAt = ? WHERE userId = ?').run(n, now(), userId);
  return { ok: true, gems: char.gems - n };
}
function addPetShards(userId, amount) {
  const n = Math.floor(amount);
  if (n) db.prepare('UPDATE rpg_characters SET petShards = petShards + ?, updatedAt = ? WHERE userId = ?').run(n, now(), userId);
  return getCharacter(userId).petShards;
}
function spendPetShards(userId, amount) {
  const char = getCharacter(userId);
  const n = Math.floor(amount);
  if (!char || char.petShards < n) return { ok: false, error: 'Pecahan bintang tidak cukup.' };
  db.prepare('UPDATE rpg_characters SET petShards = petShards - ?, updatedAt = ? WHERE userId = ?').run(n, now(), userId);
  return { ok: true, petShards: char.petShards - n };
}

// ---------------- EVOLUSI PET ----------------
// Naikkan pet ke stage 2 (validasi syarat level/shard/gold dilakukan rpgServer
// yang punya akses rpgData.PET_EVOLUTION + dompet guild).
function evolvePetToStage2(userId, petId) {
  const pet = getPet(userId, petId);
  if (!pet) return { ok: false, error: 'Pet tidak ditemukan.' };
  if (pet.stage >= 2) return { ok: false, error: 'Pet ini sudah berevolusi.' };
  db.prepare('UPDATE rpg_pets SET stage = 2, evolvedAt = ? WHERE userId = ? AND petId = ?').run(now(), userId, petId);
  db.prepare('UPDATE rpg_characters SET petsEvolved = petsEvolved + 1, updatedAt = ? WHERE userId = ?').run(now(), userId);
  return { ok: true, pet: getPet(userId, petId) };
}

// ---------------- TOWER (menara tanpa ujung) ----------------
function recordTowerFloor(userId, floor) {
  const char = getCharacter(userId);
  if (!char) return { ok: false };
  if (floor > char.towerBest) {
    db.prepare('UPDATE rpg_characters SET towerBest = ?, updatedAt = ? WHERE userId = ?').run(floor, now(), userId);
    return { ok: true, newBest: true };
  }
  return { ok: true, newBest: false };
}

// ---------------- WORLD BOSS MINGGUAN ----------------
function weekKeyNow() {
  const d = new Date();
  const jan = new Date(d.getFullYear(), 0, 1);
  const week = Math.ceil((((d - jan) / 86400000) + jan.getDay() + 1) / 7);
  return d.getFullYear() + '-W' + String(week).padStart(2, '0');
}
function getWorldBoss(weekKey) {
  let row = db.prepare('SELECT * FROM rpg_worldboss WHERE weekKey = ?').get(weekKey);
  if (!row) {
    const D = require('../utils/rpgData');
    const boss = D.worldBossForWeek(weekKey);
    db.prepare('INSERT INTO rpg_worldboss (weekKey, bossId, hp, maxHp, createdAt) VALUES (?, ?, ?, ?, ?)')
      .run(weekKey, boss.id, boss.hp, boss.hp, now());
    row = db.prepare('SELECT * FROM rpg_worldboss WHERE weekKey = ?').get(weekKey);
  }
  return row;
}
function damageWorldBoss(weekKey, userId, damage) {
  const row = getWorldBoss(weekKey);
  const dmg = Math.max(1, Math.min(Math.floor(damage), row.hp));
  db.prepare('UPDATE rpg_worldboss SET hp = hp - ?, defeatedAt = CASE WHEN hp - ? <= 0 THEN ? ELSE defeatedAt END WHERE weekKey = ?')
    .run(dmg, dmg, now(), weekKey);
  db.prepare(`INSERT INTO rpg_worldboss_damage (weekKey, userId, damage, hits) VALUES (?, ?, ?, 1)
              ON CONFLICT(weekKey, userId) DO UPDATE SET damage = damage + excluded.damage, hits = hits + 1`)
    .run(weekKey, userId, dmg);
  db.prepare('UPDATE rpg_characters SET worldbossHits = worldbossHits + 1, updatedAt = ? WHERE userId = ?').run(now(), userId);
  return { applied: dmg, boss: getWorldBoss(weekKey) };
}
function getWorldBossLeaderboard(weekKey, limit = 20) {
  return db.prepare(`SELECT wd.userId, wd.damage, wd.hits, c.gameName, c.className, c.level, c.title
                     FROM rpg_worldboss_damage wd LEFT JOIN rpg_characters c ON c.userId = wd.userId
                     WHERE wd.weekKey = ? ORDER BY wd.damage DESC LIMIT ?`).all(weekKey, limit);
}

// ---------------- RUMAH LELANG (antarpemain) ----------------
function createAuction(sellerId, itemId, qty, price) {
  const info = db.prepare("INSERT INTO rpg_auctions (sellerId, itemId, qty, price, status, createdAt) VALUES (?, ?, ?, ?, 'active', ?)")
    .run(sellerId, itemId, qty, price, now());
  db.prepare('UPDATE rpg_characters SET auctionsListed = auctionsListed + 1, updatedAt = ? WHERE userId = ?').run(now(), sellerId);
  return db.prepare('SELECT * FROM rpg_auctions WHERE id = ?').get(info.lastInsertRowid);
}
function getAuction(id) { return db.prepare('SELECT * FROM rpg_auctions WHERE id = ?').get(id) || null; }
function listAuctions({ limit = 40, sellerId = null } = {}) {
  if (sellerId) return db.prepare("SELECT * FROM rpg_auctions WHERE sellerId = ? AND status = 'active' ORDER BY createdAt DESC LIMIT ?").all(sellerId, limit);
  return db.prepare("SELECT * FROM rpg_auctions WHERE status = 'active' ORDER BY createdAt DESC LIMIT ?").all(limit);
}
function buyAuction(id, buyerId) {
  const a = getAuction(id);
  if (!a || a.status !== 'active') return { ok: false, error: 'Lelang sudah ditutup.' };
  if (a.sellerId === buyerId) return { ok: false, error: 'Tidak bisa membeli lelang sendiri.' };
  db.prepare("UPDATE rpg_auctions SET status = 'sold', buyerId = ?, closedAt = ? WHERE id = ? AND status = 'active'").run(buyerId, now(), id);
  db.prepare('UPDATE rpg_characters SET auctionsWon = auctionsWon + 1, updatedAt = ? WHERE userId = ?').run(now(), buyerId);
  return { ok: true, auction: getAuction(id) };
}
function cancelAuction(id, sellerId) {
  const a = getAuction(id);
  if (!a || a.sellerId !== sellerId) return { ok: false, error: 'Bukan lelangmu.' };
  if (a.status !== 'active') return { ok: false, error: 'Lelang sudah berakhir.' };
  db.prepare("UPDATE rpg_auctions SET status = 'cancelled', closedAt = ? WHERE id = ?").run(now(), id);
  return { ok: true };
}

// ---------------- HADIAH (gift antar-teman) ----------------
function createGift({ fromUserId, toUserId, kind, itemId = null, qty = 0, gold = 0, gems = 0, message = null }) {
  const info = db.prepare(`INSERT INTO rpg_gifts (fromUserId, toUserId, kind, itemId, qty, gold, gems, message, claimed, createdAt)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?)`)
    .run(fromUserId, toUserId, kind, itemId, qty, gold, gems, message ? String(message).slice(0, 120) : null, now());
  db.prepare('UPDATE rpg_characters SET giftsSent = giftsSent + 1, updatedAt = ? WHERE userId = ?').run(now(), fromUserId);
  return db.prepare('SELECT * FROM rpg_gifts WHERE id = ?').get(info.lastInsertRowid);
}
function getGift(id) { return db.prepare('SELECT * FROM rpg_gifts WHERE id = ?').get(id) || null; }
function getGiftInbox(userId, limit = 30) {
  return db.prepare('SELECT * FROM rpg_gifts WHERE toUserId = ? ORDER BY createdAt DESC LIMIT ?').all(userId, limit);
}
function claimGift(id, userId) {
  const g = getGift(id);
  if (!g || g.toUserId !== userId) return { ok: false, error: 'Hadiah tidak ditemukan.' };
  if (g.claimed) return { ok: false, error: 'Hadiah sudah diambil.' };
  db.prepare('UPDATE rpg_gifts SET claimed = 1 WHERE id = ?').run(id);
  return { ok: true, gift: getGift(id) };
}


// ---------------- KEAMANAN: audit log (rpg_security_log) ----------------
db.exec(`
CREATE TABLE IF NOT EXISTS rpg_security_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts INTEGER NOT NULL,
  ip TEXT NOT NULL,
  kind TEXT NOT NULL,
  path TEXT,
  detail TEXT
)`);
function logSecurity(ip, kind, path, detail) {
  try {
    db.prepare('INSERT INTO rpg_security_log (ts, ip, kind, path, detail) VALUES (?, ?, ?, ?, ?)')
      .run(now(), String(ip || '').slice(0, 64), String(kind || '').slice(0, 32), String(path || '').slice(0, 180), String(detail || '').slice(0, 240));
  } catch (_) {}
}
function getSecurityStats() {
  const since = now() - 24 * 3600 * 1000;
  const byKind = db.prepare('SELECT kind, COUNT(*) AS n, COUNT(DISTINCT ip) AS ips FROM rpg_security_log WHERE ts >= ? GROUP BY kind ORDER BY n DESC').all(since);
  const recent = db.prepare('SELECT ts, ip, kind, path, detail FROM rpg_security_log WHERE ts >= ? ORDER BY id DESC LIMIT 60').all(since);
  return { since, byKind, recent };
}
// Pangkas log lama (maks 5.000 baris) — dieksekusi oleh janitor security,
// BUKAN setInterval di sini (interval saat process.exit memicu crash native
// better-sqlite3 di Node 24: Statement::~Statement setelah env teardown).
function trimSecurityLog() {
  try { db.prepare('DELETE FROM rpg_security_log WHERE id <= (SELECT COALESCE(MAX(id),0) - 5000 FROM rpg_security_log)').run(); } catch (_) {}
}


// Tutup koneksi DB bersama (dipakai test suite untuk exit bersih tanpa crash
// finalizer better-sqlite3 di Node 24 — JANGAN dipanggil saat bot masih jalan).
function close() { try { db.close(); } catch (_) {} }

module.exports = {
  getCharacter, createCharacter, updateCharacter, incCharacter, getLeaderboard, getAllCharacterUserIds, deleteCharacterCascade,
  getWallet, addGold, addCoins, ensureGoldMigrated,
  getSkills, getSkillLevel, setSkillLevel, resetSkills,
  getInventory, getItemQty, addItem, removeItem, equipItem, unequipItem,
  createParty, getParty, getPartyOfUser, listOpenParties, joinParty, leaveParty, setPartyStatus,
  setPartyChannel, getPartyCategoryId, setPartyCategoryId,
  createQuest, getQuest, isQuestOpen, listActiveQuests, deactivateExpiredQuests, acceptQuest, getQuestProgress,
  recordQuestPost, getDueQuestPosts, markQuestPostCleaned,
  getUserActiveQuests, updateQuestProgress, advanceQuestProgress,
  getPets, getPet, grantPet, setActivePet, getActivePet, addPetXp, evolvePetToStage2,
  getQuestConfig, updateQuestConfig, getQuestConfigsWithAutoGen,
  createRankRequest, getRankRequest, listPendingRankRequests, resolveRankRequest,
  getAchievements, unlockAchievement, claimAchievement,
  addFriend, requestFriend, removeFriend, getFriends, getPendingRequests, searchPlayers,
  addChatMessage, getChatHistory, getDmHistory,
  saveSession, getSession, deleteSession, cleanExpiredSessions, ensureFriendId,
  addGems, spendGems, addPetShards, spendPetShards,
  recordTowerFloor, weekKeyNow, getWorldBoss, damageWorldBoss, getWorldBossLeaderboard,
  createAuction, getAuction, listAuctions, buyAuction, cancelAuction,
  createGift, getGift, getGiftInbox, claimGift,
  logSecurity, getSecurityStats, trimSecurityLog, close,
};
