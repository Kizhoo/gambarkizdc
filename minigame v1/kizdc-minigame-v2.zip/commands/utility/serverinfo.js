const { SlashCommandBuilder, ChannelType } = require('discord.js');
const { baseEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  subcommandOf: true,
  data: new SlashCommandBuilder().setName('serverinfo').setDescription('Lihat informasi server ini'),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const guild = interaction.guild;
    const textChannels = guild.channels.cache.filter(c => c.type === ChannelType.GuildText).size;
    const voiceChannels = guild.channels.cache.filter(c => c.type === ChannelType.GuildVoice).size;
    const owner = await guild.fetchOwner();

    const embed = baseEmbed()
      .setTitle(guild.name)
      .setThumbnail(guild.iconURL({ dynamic: true, size: 256 }))
      .addFields(
        { name: t(lang, 'info.owner'), value: `${owner.user.tag}`, inline: true },
        { name: t(lang, 'info.members'), value: `${guild.memberCount}`, inline: true },
        { name: t(lang, 'info.created'), value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:R>`, inline: true },
        { name: 'Text Channel', value: `${textChannels}`, inline: true },
        { name: 'Voice Channel', value: `${voiceChannels}`, inline: true },
        { name: t(lang, 'info.roles'), value: `${guild.roles.cache.size}`, inline: true },
        { name: 'Boost Level', value: `${guild.premiumTier}`, inline: true },
        { name: 'Boost Count', value: `${guild.premiumSubscriptionCount || 0}`, inline: true },
        { name: 'Verification Level', value: `${guild.verificationLevel}`, inline: true },
      );

    return interaction.reply({ embeds: [embed] });
  },
};
