const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, EmbedBuilder } = require('discord.js');
const { errorEmbed } = require('../../utils/embeds');
const config = require('../../config.json');
const { pickTimeControl, collectorOptionsFor } = require('../../utils/gameTimeControl');
const { pickDifficulty } = require('../../utils/gameDifficulty');
const { t, guildLang } = require('../../utils/i18n');

const ROWS = 6;
const COLS = 7;
const EMPTY = '\u26aa';
const RED = '\ud83d\udd34';
const YELLOW = '\ud83d\udfe1';

function dropPieceOnCopy(board, col, piece) {
  const b = board.map(r => [...r]);
  for (let r = ROWS - 1; r >= 0; r--) if (!b[r][col]) { b[r][col] = piece; return b; }
  return null;
}
function validCols(board) { const out = []; for (let c = 0; c < COLS; c++) if (!board[0][c]) out.push(c); return out; }
function checkWinnerOn(board, piece) {
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      if (board[r][c] !== piece) continue;
      if (c + 3 < COLS && board[r][c + 1] === piece && board[r][c + 2] === piece && board[r][c + 3] === piece) return true;
      if (r + 3 < ROWS && board[r + 1][c] === piece && board[r + 2][c] === piece && board[r + 3][c] === piece) return true;
      if (r + 3 < ROWS && c + 3 < COLS && board[r + 1][c + 1] === piece && board[r + 2][c + 2] === piece && board[r + 3][c + 3] === piece) return true;
      if (r - 3 >= 0 && c + 3 < COLS && board[r - 1][c + 1] === piece && board[r - 2][c + 2] === piece && board[r - 3][c + 3] === piece) return true;
    }
  }
  return false;
}
function boardFull(board) { return board[0].every(cell => cell !== null); }

// AI pakai minimax + alpha-beta pruning, depth 6 (sudah dites: rata-rata ~15ms/langkah, terburuk
// ~90ms dari papan kosong - jauh di bawah batas waktu interaksi Discord). Heuristik evaluasi
// standar Connect Four: skor tiap "jendela" 4-sel + bobot ekstra kolom tengah.
function evalWindow(window, aiP, huP) {
  const aiCount = window.filter(x => x === aiP).length;
  const huCount = window.filter(x => x === huP).length;
  const empty = window.filter(x => !x).length;
  if (aiCount === 4) return 100000;
  if (huCount === 4) return -100000;
  let score = 0;
  if (aiCount === 3 && empty === 1) score += 50;
  else if (aiCount === 2 && empty === 2) score += 10;
  if (huCount === 3 && empty === 1) score -= 60;
  else if (huCount === 2 && empty === 2) score -= 8;
  return score;
}
function evaluate(board, aiP, huP) {
  let score = 0;
  score += board.map(r => r[3]).filter(x => x === aiP).length * 6;
  for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS - 3; c++) score += evalWindow([board[r][c], board[r][c + 1], board[r][c + 2], board[r][c + 3]], aiP, huP);
  for (let c = 0; c < COLS; c++) for (let r = 0; r < ROWS - 3; r++) score += evalWindow([board[r][c], board[r + 1][c], board[r + 2][c], board[r + 3][c]], aiP, huP);
  for (let r = 0; r < ROWS - 3; r++) for (let c = 0; c < COLS - 3; c++) score += evalWindow([board[r][c], board[r + 1][c + 1], board[r + 2][c + 2], board[r + 3][c + 3]], aiP, huP);
  for (let r = 3; r < ROWS; r++) for (let c = 0; c < COLS - 3; c++) score += evalWindow([board[r][c], board[r - 1][c + 1], board[r - 2][c + 2], board[r - 3][c + 3]], aiP, huP);
  return score;
}
function minimaxC4(board, depth, alpha, beta, maximizing, aiP, huP) {
  const cols = validCols(board).sort((a, b) => Math.abs(a - 3) - Math.abs(b - 3));
  if (checkWinnerOn(board, aiP)) return { score: 10000000 - depth * 1000 };
  if (checkWinnerOn(board, huP)) return { score: -10000000 + depth * 1000 };
  if (!cols.length) return { score: 0 };
  if (depth === 0) return { score: evaluate(board, aiP, huP) };

  if (maximizing) {
    let best = { score: -Infinity, col: cols[0] };
    for (const c of cols) {
      const res = minimaxC4(dropPieceOnCopy(board, c, aiP), depth - 1, alpha, beta, false, aiP, huP);
      if (res.score > best.score) best = { score: res.score, col: c };
      alpha = Math.max(alpha, best.score);
      if (alpha >= beta) break;
    }
    return best;
  }
  let best = { score: Infinity, col: cols[0] };
  for (const c of cols) {
    const res = minimaxC4(dropPieceOnCopy(board, c, huP), depth - 1, alpha, beta, true, aiP, huP);
    if (res.score < best.score) best = { score: res.score, col: c };
    beta = Math.min(beta, best.score);
    if (alpha >= beta) break;
  }
  return best;
}
// Difficulty: "hard" = perilaku lama (depth 6, terverifikasi ~15ms rata2/langkah). Tingkat lain
// nurunin depth pencarian (makin dangkal makin gampang dikalahkan) + nambah peluang blunder
// (ambil kolom acak) buat easy/medium biar kerasa jelas bedanya, bukan cuma "agak kurang jago".
const DEPTH_BY_DIFFICULTY = { easy: 1, medium: 3, hard: 6, extreme: 8 };
const BLUNDER_RATE = { easy: 0.35, medium: 0.12, hard: 0, extreme: 0 };
function pickAiMove(board, aiP, huP, difficulty = 'hard') {
  const rate = BLUNDER_RATE[difficulty] ?? 0;
  if (rate > 0 && Math.random() < rate) {
    const cols = validCols(board);
    return cols[Math.floor(Math.random() * cols.length)];
  }
  const depth = DEPTH_BY_DIFFICULTY[difficulty] ?? DEPTH_BY_DIFFICULTY.hard;
  return minimaxC4(board, depth, -Infinity, Infinity, true, aiP, huP).col;
}

module.exports = {
  subcommandOf: 'games',
  data: new SlashCommandBuilder()
    .setName('connectfour')
    .setDescription('Main Connect Four — lawan member lain atau lawan AI')
    .addUserOption(o => o.setName('lawan').setDescription('Member yang mau diajak main (kosongkan buat lawan AI)')),

  async execute(interaction) {
    const lang = guildLang(interaction);
    const opponent = interaction.options.getUser('lawan');
    const vsAi = !opponent;

    if (!vsAi) {
      if (opponent.bot) return interaction.reply({ embeds: [errorEmbed(t(lang, 'game.cant_bot'))], ephemeral: true });
      if (opponent.id === interaction.user.id) return interaction.reply({ embeds: [errorEmbed(t(lang, 'game.cant_self'))], ephemeral: true });
    }

    // ----- Pilih batas waktu per giliran dulu (20d/30d/1-10m/tanpa batas) -----
    const timeControl = await pickTimeControl(interaction, { gameTitle: 'Connect Four', prefix: 'c4', vsAi, opponentTag: vsAi ? null : `${opponent}` });
    if (timeControl.componentInteraction) await timeControl.componentInteraction.deferUpdate().catch(() => {});
    let challengeMsg = timeControl.message;

    // ----- Vs AI: pilih difficulty lawan (easy/medium/hard/extreme) -----
    let difficulty = { key: 'hard', label: 'Hard' };
    if (vsAi) {
      difficulty = await pickDifficulty(challengeMsg, interaction.user.id, { gameTitle: 'Connect Four', prefix: 'c4' });
      if (difficulty.componentInteraction) await difficulty.componentInteraction.deferUpdate().catch(() => {});
      challengeMsg = difficulty.message;
    }

    if (!vsAi) {
      const challengeRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('c4_accept').setLabel(t(lang, 'game.accept')).setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('c4_decline').setLabel(t(lang, 'game.decline')).setStyle(ButtonStyle.Danger),
      );
      challengeMsg = await challengeMsg.edit({
        embeds: [new EmbedBuilder().setColor(config.embedColor).setTitle(t(lang, 'c4.title'))
          .setDescription(t(lang, 'game.challenge', { p: `${interaction.user}`, o: `${opponent}`, game: 'Connect Four', tc: timeControl.label }))],
        components: [challengeRow],
      });
      const decision = await challengeMsg.awaitMessageComponent({ componentType: ComponentType.Button, time: 60000 }).catch(() => null);
      if (!decision || decision.customId === 'c4_decline') {
        const text = !decision ? t(lang, 'game.challenge_timeout') : t(lang, 'game.challenge_declined', { o: `${opponent}` });
        return challengeMsg.edit({ embeds: [errorEmbed(text)], components: [] }).catch(() => {});
      }
      if (decision.user.id !== opponent.id) {
        return decision.reply({ content: t(lang, 'game.only_challenged'), ephemeral: true });
      }
      await decision.deferUpdate();
    }

    const AI_PLAYER = { id: 'AI', username: 'AI', toString: () => '🤖 AI' };
    const players = { R: interaction.user, Y: vsAi ? AI_PLAYER : opponent };
    const board = Array.from({ length: ROWS }, () => Array(COLS).fill(null));
    let turn = 'R';
    let finished = false;

    const renderBoard = () => board.map(row =>
      row.map(cell => (cell === 'R' ? RED : cell === 'Y' ? YELLOW : EMPTY)).join('')
    ).join('\n');

    const dropPiece = (col, piece) => {
      for (let r = ROWS - 1; r >= 0; r--) {
        if (!board[r][col]) { board[r][col] = piece; return true; }
      }
      return false;
    };

    const buildButtons = () => {
      const rowsUI = [];
      for (let group = 0; group < 2; group++) {
        const row = new ActionRowBuilder();
        const startCol = group * 4;
        const endCol = Math.min(startCol + 4, COLS);
        for (let c = startCol; c < endCol; c++) {
          const colFull = board[0][c] !== null;
          row.addComponents(
            new ButtonBuilder().setCustomId(`c4_${c}`).setLabel(`${c + 1}`).setStyle(ButtonStyle.Secondary).setDisabled(colFull || finished)
          );
        }
        if (row.components.length > 0) rowsUI.push(row);
      }
      return rowsUI;
    };

    const buildEmbed = (statusText) => new EmbedBuilder()
      .setColor(config.embedColor)
      .setTitle('Connect Four' + (vsAi ? ' (vs AI)' : ''))
      .setFooter({ text: t(lang, 'game.time_per_turn', { t: timeControl.label }) + (vsAi ? ` • ${t(lang, 'game.difficulty', { d: difficulty.label })}` : '') })
      .setDescription(t(lang, 'c4.players', { r: players.R, y: players.Y }) + `\n\n${renderBoard()}\n\n${statusText}`);

    const initialPayload = { embeds: [buildEmbed(t(lang, 'game.your_turn', { p: `${players[turn]}` }))], components: buildButtons() };
    const message = await challengeMsg.edit(initialPayload);

    const collector = message.createMessageComponentCollector(collectorOptionsFor(timeControl.ms));

    // Jatuhkan satu keping (kolom sudah divalidasi tidak penuh), cek menang/seri, ganti giliran.
    // Dipakai baik buat langkah manusia maupun langkah AI.
    const applyDrop = (col) => {
      dropPiece(col, turn);
      if (checkWinnerOn(board, turn)) {
        finished = true; collector.stop();
        return { embeds: [buildEmbed(t(lang, 'game.win', { p: `${players[turn]}` }))], components: [] };
      }
      if (boardFull(board)) {
        finished = true; collector.stop();
        return { embeds: [buildEmbed(t(lang, 'game.draw') + ' ' + t(lang, 'c4.board_full'))], components: [] };
      }
      turn = turn === 'R' ? 'Y' : 'R';
      return { embeds: [buildEmbed(t(lang, 'game.your_turn', { p: `${players[turn]}` }))], components: buildButtons() };
    };

    collector.on('collect', async i => {
      const currentPlayer = players[turn];
      if (vsAi && turn === 'Y') return i.reply({ content: t(lang, 'game.ai_turn'), ephemeral: true });
      if (i.user.id !== currentPlayer.id) {
        return i.reply({ content: t(lang, 'game.not_your_turn'), ephemeral: true });
      }

      const col = parseInt(i.customId.split('_')[1]);
      if (board[0][col]) return i.reply({ content: t(lang, 'game.col_full'), ephemeral: true });

      const payload = applyDrop(col);
      await i.update(payload);

      if (vsAi && !finished && turn === 'Y') {
        setTimeout(async () => {
          if (finished) return;
          const aiCol = pickAiMove(board, 'Y', 'R', difficulty.key);
          const aiPayload = applyDrop(aiCol);
          await message.edit(aiPayload).catch(() => {});
        }, 650);
      }
    });

    collector.on('end', (collected, reason) => {
      if (!finished && (reason === 'time' || reason === 'idle')) {
        message.edit({ embeds: [buildEmbed(t(lang, 'game.timeout', { p: `${players[turn]}` }))], components: [] }).catch(() => {});
      }
    });
  },
};
