const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, EmbedBuilder } = require('discord.js');
const { errorEmbed } = require('../../utils/embeds');
const { safeDefer } = require('../../utils/interactionHelpers');
const { fetchExternal } = require('../../utils/httpClient');
const config = require('../../config.json');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  subcommandOf: true,
  data: new SlashCommandBuilder()
    .setName('imagesearch')
    .setDescription('Cari gambar/wallpaper berkualitas tinggi berdasarkan kata kunci')
    .addStringOption(o => o.setName('kata_kunci').setDescription('Kata kunci pencarian gambar').setRequired(true)),

  async execute(interaction) {
    const lang = guildLang(interaction);
    const query = interaction.options.getString('kata_kunci');
    if (!(await safeDefer(interaction))) return;

    let results;
    try {
      const url = `https://wallhaven.cc/api/v1/search?q=${encodeURIComponent(query)}&purity=100&categories=111&sorting=relevance`;
      const res = await fetchExternal(url);
      if (!res.ok) throw new Error(`wallhaven.cc merespons status ${res.status}`);
      const data = await res.json();
      results = data.data;
    } catch (err) {
      console.error('[imagesearch] Gagal cari gambar:', err.message);
      return interaction.editReply({ embeds: [errorEmbed(t(lang, 'imgsearch.fail'))] });
    }

    if (!results || results.length === 0) {
      return interaction.editReply({ embeds: [errorEmbed(t(lang, 'imgsearch.no_result', { q: query }))] });
    }

    let index = 0;

    const buildEmbed = () => {
      const item = results[index];
      return new EmbedBuilder()
        .setColor(config.embedColor)
        .setTitle(t(lang, 'imgsearch.title', { q: query }))
        .setURL(item.url)
        .setImage(item.path)
        .setFooter({ text: t(lang, 'imgsearch.footer', { i: index + 1, n: results.length, r: item.resolution }) });
    };

    const buildRow = () => new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('img_prev').setLabel(t(lang, 'imgsearch.prev')).setStyle(ButtonStyle.Secondary).setDisabled(index === 0),
      new ButtonBuilder().setCustomId('img_next').setLabel(t(lang, 'imgsearch.next')).setStyle(ButtonStyle.Secondary).setDisabled(index === results.length - 1),
    );

    const message = await interaction.editReply({ embeds: [buildEmbed()], components: [buildRow()] });

    const collector = message.createMessageComponentCollector({ componentType: ComponentType.Button, time: 180000 });

    collector.on('collect', async i => {
      if (i.user.id !== interaction.user.id) {
        return i.reply({ content: t(lang, 'imgsearch.not_yours'), ephemeral: true });
      }

      if (i.customId === 'img_next' && index < results.length - 1) index++;
      if (i.customId === 'img_prev' && index > 0) index--;

      await i.update({ embeds: [buildEmbed()], components: [buildRow()] });
    });

    collector.on('end', () => {
      interaction.editReply({ components: [] }).catch(() => {});
    });
  },
};
