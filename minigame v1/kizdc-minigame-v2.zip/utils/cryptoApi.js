// ============================================================================
// CRYPTO API - client buat Binance public REST API (data pasar, tanpa API key
// karena semua endpoint di sini cuma baca data publik, bukan trading) plus
// kalkulasi indikator teknikal dasar (RSI, EMA) buat fitur /crypto signal.
//
// PENTING soal "sinyal": ini pembacaan indikator teknikal otomatis, BUKAN saran
// finansial. Selalu tampilkan disclaimer di command & auto-post-nya.
// ============================================================================
const { fetchJson } = require('./publicApi');
const settings = require('./settings');

const TICKER_CACHE_TTL_MS = 20 * 1000;
const KLINES_CACHE_TTL_MS = 60 * 1000;

function baseUrl() {
  return settings.get('crypto.baseUrl', 'https://api.binance.com').replace(/\/$/, '');
}

// Daftar quote asset umum di Binance, dicek berurutan (stablecoin duluan) supaya "BTCUSDT"
// tidak salah kedeteksi cocok sama suffix "BTC" duluan.
const KNOWN_QUOTES = ['USDT', 'FDUSD', 'BUSD', 'USDC', 'BTC', 'ETH', 'BNB', 'TRY', 'EUR', 'USD'];

function normalizeSymbol(input) {
  const raw = String(input || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (!raw) return null;
  for (const quote of KNOWN_QUOTES) {
    // panjang harus lebih besar dari suffix-nya sendiri, supaya "BTC" polos tidak
    // dikira sudah punya quote asset "BTC" (yang sebenarnya cuma nama basenya doang).
    if (raw.length > quote.length && raw.endsWith(quote)) return raw;
  }
  return `${raw}USDT`; // nama koin polos (BTC, ETH, dst) - default dipasangkan ke USDT
}

async function getTicker24h(symbol) {
  const url = `${baseUrl()}/api/v3/ticker/24hr?symbol=${encodeURIComponent(symbol)}`;
  try {
    return await fetchJson(url, { ttl: TICKER_CACHE_TTL_MS });
  } catch (err) {
    if (err.message?.includes('400')) throw new Error(`Simbol \`${symbol}\` tidak ditemukan di Binance. Contoh yang valid: BTCUSDT, ETHUSDT.`);
    throw err;
  }
}

async function getKlines(symbol, interval, limit) {
  const url = `${baseUrl()}/api/v3/klines?symbol=${encodeURIComponent(symbol)}&interval=${interval}&limit=${limit}`;
  try {
    const raw = await fetchJson(url, { ttl: KLINES_CACHE_TTL_MS });
    return raw.map(k => ({
      openTime: k[0],
      open: parseFloat(k[1]),
      high: parseFloat(k[2]),
      low: parseFloat(k[3]),
      close: parseFloat(k[4]),
      volume: parseFloat(k[5]),
      closeTime: k[6],
    }));
  } catch (err) {
    if (err.message?.includes('400')) throw new Error(`Simbol \`${symbol}\` tidak ditemukan di Binance. Contoh yang valid: BTCUSDT, ETHUSDT.`);
    throw err;
  }
}

// ---------------- Indikator teknikal ----------------

// EMA (Exponential Moving Average). Nilai awal diseed pakai SMA dari `period` candle
// pertama (standar praktik) supaya deret EMA-nya lebih stabil/akurat, bukan cuma
// mulai dari harga pertama.
function emaSeries(closes, period) {
  if (closes.length < period) return [];
  const k = 2 / (period + 1);
  const sma = closes.slice(0, period).reduce((a, b) => a + b, 0) / period;
  const out = [sma];
  for (let i = period; i < closes.length; i++) {
    out.push(closes[i] * k + out[out.length - 1] * (1 - k));
  }
  return out; // out[out.length-1] = EMA terbaru
}

// RSI (Relative Strength Index) pakai Wilder's smoothing, standar 14-periode.
function rsi(closes, period = 14) {
  if (closes.length <= period) return null;
  let gainSum = 0, lossSum = 0;
  for (let i = 1; i <= period; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff >= 0) gainSum += diff; else lossSum -= diff;
  }
  let avgGain = gainSum / period;
  let avgLoss = lossSum / period;
  for (let i = period + 1; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1];
    const gain = diff > 0 ? diff : 0;
    const loss = diff < 0 ? -diff : 0;
    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;
  }
  if (avgGain === 0 && avgLoss === 0) return 50; // harga benar-benar flat
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - 100 / (1 + rs);
}

/**
 * Hitung ringkasan indikator dari array candle (hasil getKlines, urut lama->baru)
 * dan klasifikasikan jadi "state" ringkas buat dedup notifikasi (lihat crypto_signal_state).
 */
function computeIndicators(candles, options = {}) {
  const rsiPeriod = options.rsiPeriod ?? settings.get('crypto.rsiPeriod', 14);
  const emaFastPeriod = options.emaFast ?? settings.get('crypto.emaFast', 20);
  const emaSlowPeriod = options.emaSlow ?? settings.get('crypto.emaSlow', 50);
  const overbought = options.rsiOverbought ?? settings.get('crypto.rsiOverbought', 70);
  const oversold = options.rsiOversold ?? settings.get('crypto.rsiOversold', 30);

  const closes = candles.map(c => c.close);
  const rsiValue = rsi(closes, rsiPeriod);
  const emaFastSeries = emaSeries(closes, emaFastPeriod);
  const emaSlowSeries = emaSeries(closes, emaSlowPeriod);
  const emaFastValue = emaFastSeries.length ? emaFastSeries[emaFastSeries.length - 1] : null;
  const emaSlowValue = emaSlowSeries.length ? emaSlowSeries[emaSlowSeries.length - 1] : null;

  let rsiZone = 'neutral';
  if (rsiValue != null) {
    if (rsiValue >= overbought) rsiZone = 'overbought';
    else if (rsiValue <= oversold) rsiZone = 'oversold';
  }

  let emaTrend = 'unknown';
  if (emaFastValue != null && emaSlowValue != null) {
    emaTrend = emaFastValue >= emaSlowValue ? 'bullish' : 'bearish';
  }

  const lastPrice = closes[closes.length - 1];
  const priceChangePctVsFirst = ((lastPrice - closes[0]) / closes[0]) * 100;

  return {
    lastPrice,
    rsi: rsiValue != null ? Number(rsiValue.toFixed(2)) : null,
    rsiZone,
    rsiPeriod,
    emaFast: emaFastValue != null ? Number(emaFastValue.toFixed(8)) : null,
    emaSlow: emaSlowValue != null ? Number(emaSlowValue.toFixed(8)) : null,
    emaFastPeriod,
    emaSlowPeriod,
    emaTrend,
    priceChangePctVsFirst: Number(priceChangePctVsFirst.toFixed(2)),
    state: `${rsiZone}|${emaTrend}`,
  };
}

// Format harga adaptif: koin murah (misal SHIB) butuh lebih banyak desimal daripada BTC.
function formatPrice(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return '-';
  if (n >= 1000) return n.toLocaleString('en-US', { maximumFractionDigits: 2 });
  if (n >= 1) return n.toLocaleString('en-US', { maximumFractionDigits: 4 });
  if (n >= 0.01) return n.toFixed(6);
  return n.toFixed(8);
}

module.exports = {
  normalizeSymbol, getTicker24h, getKlines, computeIndicators, formatPrice, rsi, emaSeries,
};
