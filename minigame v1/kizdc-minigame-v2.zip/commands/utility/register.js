const {
  SlashCommandBuilder, ModalBuilder, TextInputBuilder, TextInputStyle,
  ActionRowBuilder, ButtonBuilder, ButtonStyle, AttachmentBuilder,
} = require('discord.js');
const { registerUser, getUser, deleteUser, setUserProfile } = require('../../database/db');
const { baseEmbed, successEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');
const settings = require('../../utils/settings');

function panelComponents(user, lang) {
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('reg:start').setLabel(t(lang, user ? 'reg.btn.update' : 'reg.btn.start')).setEmoji('📝').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('reg:card').setLabel(t(lang, 'reg.btn.card')).setEmoji('🖼️').setStyle(ButtonStyle.Success).setDisabled(!user),
    new ButtonBuilder().setCustomId('reg:info').setLabel(t(lang, 'reg.btn.info')).setEmoji('👤').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('reg:delete').setLabel(t(lang, 'reg.btn.delete')).setEmoji('🗑️').setStyle(ButtonStyle.Danger).setDisabled(!user),
  )];
}

function registrationPanel(user, lang) {
  const minAge = settings.get('registration.minAge', 13);
  const embed = baseEmbed()
    .setColor(user ? '#22C55E' : '#5865F2')
    .setTitle(t(lang, user ? 'reg.title.active' : 'reg.title.welcome'))
    .setDescription(user
      ? t(lang, 'reg.desc.active')
      : t(lang, 'reg.desc.welcome', { min: minAge }))
    .addFields(
      { name: t(lang, 'reg.field.privacy'), value: t(lang, 'reg.val.privacy'), inline: true },
      { name: t(lang, 'reg.field.fast'), value: t(lang, 'reg.val.fast'), inline: true },
      { name: t(lang, 'reg.field.integrated'), value: t(lang, 'reg.val.integrated'), inline: true },
    )
    .setFooter({ text: user ? t(lang, 'reg.footer.registered', { date: new Date(user.registeredAt).toLocaleDateString('id-ID') }) : t(lang, 'reg.footer.start') });
  return { embeds: [embed], components: panelComponents(user, lang), ephemeral: true };
}

function showRegistrationModal(interaction) {
  const lang = guildLang(interaction);
  const current = getUser(interaction.user.id);
  const modal = new ModalBuilder().setCustomId('reg:modal').setTitle(t(lang, current ? 'reg.modal.title.update' : 'reg.modal.title'));
  const username = new TextInputBuilder()
    .setCustomId('username').setLabel(t(lang, 'reg.label.username')).setStyle(TextInputStyle.Short)
    .setPlaceholder(t(lang, 'reg.ph.username')).setRequired(true).setMinLength(2).setMaxLength(40)
    .setValue(current?.username?.slice(0, 40) || interaction.user.globalName?.slice(0, 40) || interaction.user.username.slice(0, 40));
  const age = new TextInputBuilder()
    .setCustomId('age').setLabel(t(lang, 'reg.label.age')).setStyle(TextInputStyle.Short)
    .setPlaceholder(t(lang, 'reg.ph.age')).setRequired(true).setMinLength(1).setMaxLength(3);
  if (current?.age) age.setValue(String(current.age));
  const bio = new TextInputBuilder()
    .setCustomId('bio').setLabel(t(lang, 'reg.label.bio')).setStyle(TextInputStyle.Paragraph)
    .setPlaceholder(t(lang, 'reg.ph.bio')).setRequired(false).setMaxLength(160);
  modal.addComponents(
    new ActionRowBuilder().addComponents(username),
    new ActionRowBuilder().addComponents(age),
    new ActionRowBuilder().addComponents(bio),
  );
  return interaction.showModal(modal);
}

async function handleButton(interaction) {
  const lang = guildLang(interaction);
  if (interaction.customId === 'reg:start') return showRegistrationModal(interaction);
  if (interaction.customId === 'reg:card') {
    const user = getUser(interaction.user.id);
    if (!user) return interaction.reply({ embeds: [errorEmbed(t(lang, 'reg.err.not_registered'))], ephemeral: true });
    // Render kartu profil canvas yang sama seperti `/profile card`, langsung dari panel register.
    await interaction.deferReply({ ephemeral: true }).catch(() => {});
    try {
      const { collectData } = require('../social/profile');
      const { renderProfileCard } = require('../../utils/profileCard');
      const data = await collectData(interaction, interaction.user);
      if (!data.member) return interaction.editReply({ embeds: [errorEmbed(t(lang, 'reg.err.member_missing'))] });
      const image = await renderProfileCard(data);
      const file = new AttachmentBuilder(image, { name: `profile-${interaction.user.id}.png` });
      return interaction.editReply({ files: [file] });
    } catch (error) {
      console.error('[register card]', error);
      return interaction.editReply({ embeds: [errorEmbed(t(lang, 'reg.err.card_fail', { err: error.message }))] });
    }
  }
  if (interaction.customId === 'reg:info') {
    const user = getUser(interaction.user.id);
    if (!user) return interaction.reply({ embeds: [errorEmbed(t(lang, 'reg.err.not_registered'))], ephemeral: true });
    return interaction.reply({ embeds: [baseEmbed()
      .setColor(user.banned ? '#EF4444' : '#22C55E')
      .setTitle(t(lang, 'reg.info.title'))
      .setThumbnail(interaction.user.displayAvatarURL({ size: 256 }))
      .addFields(
        { name: t(lang, 'reg.field.name'), value: user.username, inline: true },
        { name: t(lang, 'reg.field.age'), value: t(lang, 'reg.age_years', { age: user.age }), inline: true },
        { name: t(lang, 'reg.field.status'), value: user.banned ? t(lang, 'reg.status.banned') : t(lang, 'reg.status.active'), inline: true },
        { name: t(lang, 'reg.field.registered'), value: `<t:${Math.floor(user.registeredAt / 1000)}:F>`, inline: false },
      )], ephemeral: true });
  }
  if (interaction.customId === 'reg:delete') {
    if (!getUser(interaction.user.id)) return interaction.reply({ embeds: [errorEmbed(t(lang, 'reg.err.no_data'))], ephemeral: true });
    return interaction.reply({
      embeds: [baseEmbed().setColor('#EF4444').setTitle(t(lang, 'reg.confirm.title')).setDescription(t(lang, 'reg.confirm.desc'))],
      components: [new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('reg:confirm-delete').setLabel(t(lang, 'reg.btn.yes_delete')).setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId('reg:cancel-delete').setLabel(t(lang, 'reg.btn.cancel')).setStyle(ButtonStyle.Secondary),
      )], ephemeral: true,
    });
  }
  if (interaction.customId === 'reg:confirm-delete') {
    deleteUser(interaction.user.id);
    return interaction.update({ embeds: [successEmbed(t(lang, 'reg.deleted'))], components: [] });
  }
  if (interaction.customId === 'reg:cancel-delete') {
    return interaction.update({ embeds: [successEmbed(t(lang, 'reg.cancelled'))], components: [] });
  }
}

async function handleModal(interaction) {
  const lang = guildLang(interaction);
  const username = interaction.fields.getTextInputValue('username').trim();
  const ageRaw = interaction.fields.getTextInputValue('age').trim();
  const bio = interaction.fields.getTextInputValue('bio').trim();
  const age = Number(ageRaw);
  const minAge = settings.get('registration.minAge', 13);
  if (!username || username.length < 2) return interaction.reply({ embeds: [errorEmbed(t(lang, 'reg.err.name_short'))], ephemeral: true });
  if (!/^\d{1,3}$/.test(ageRaw) || !Number.isInteger(age) || age < minAge || age > 120) {
    return interaction.reply({ embeds: [errorEmbed(t(lang, 'reg.err.age', { min: minAge }))], ephemeral: true });
  }
  const existed = Boolean(getUser(interaction.user.id));
  const saved = registerUser(interaction.user.id, username.slice(0, 40), age);
  if (bio) setUserProfile(interaction.user.id, { bio });

  // Notifikasi pendaftaran baru ke server owner (lihat utils/ownerNotifications.js)
  const { sendRegisterNotification } = require('../../utils/ownerNotifications');
  sendRegisterNotification(interaction.client, { user: interaction.user, guild: interaction.guild, age }).catch(() => {});

  return interaction.reply({
    embeds: [baseEmbed().setColor('#22C55E').setTitle(t(lang, existed ? 'reg.updated_title' : 'reg.success_title'))
      .setThumbnail(interaction.user.displayAvatarURL({ size: 256 }))
      .setDescription(t(lang, 'reg.success_desc', { name: saved.username }))
      .addFields(
        { name: t(lang, 'reg.field.name'), value: saved.username, inline: true },
        { name: t(lang, 'reg.field.age'), value: t(lang, 'reg.age_years', { age: saved.age }), inline: true },
        { name: t(lang, 'reg.next'), value: t(lang, 'reg.next_val'), inline: false },
      )],
    components: [new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('reg:info').setLabel(t(lang, 'reg.btn.view')).setEmoji('👤').setStyle(ButtonStyle.Success),
    )], ephemeral: true,
  });
}

module.exports = {
  subcommandOf: true,
  data: new SlashCommandBuilder().setName('register').setDescription('Buka panel registrasi interaktif KizhooBot'),
  cooldown: 2,
  async execute(interaction) {
    return interaction.reply(registrationPanel(getUser(interaction.user.id), guildLang(interaction)));
  },
  handleButton,
  handleModal,
  registrationPanel,
};
