const { baseEmbed, successEmbed, errorEmbed } = require('./embeds');
const { normalizeAnswer } = require('./publicApi');
const { updateBalance } = require('../database/db');
const settings = require('./settings');

const activeChannels = new Set();

async function startQuiz(interaction, quiz) {
  const channelId = interaction.channelId;
  if (activeChannels.has(channelId)) {
    return interaction.reply({ embeds: [errorEmbed('Masih ada game tebak-tebakan aktif di channel ini. Selesaikan dulu sebelum memulai game baru.')], ephemeral: true });
  }

  const answers = [quiz.answer, ...(quiz.aliases || [])].map(normalizeAnswer).filter(Boolean);
  if (!answers.length) throw new Error('API tidak mengembalikan jawaban game');
  // Default durasi diambil dari panel (Setting > Game), bukan angka mati - jadi SEMUA game yang
  // pakai mesin ini (tebak gambar, tebak anime, tebak pokemon, tebak bendera, tebak ibukota, dst)
  // ikut berubah begitu owner ubah "Durasi Tebak-Tebakan" di panel, tanpa perlu restart.
  const durationMs = quiz.durationMs || settings.get('games.quizDurationSeconds', 45) * 1000;
  const reward = Number.isFinite(quiz.reward) ? quiz.reward : 75;
  const embed = baseEmbed()
    .setTitle(quiz.title || 'Game Tebak-tebakan')
    .setDescription(`${quiz.prompt || 'Ketik jawabanmu langsung di chat.'}\n\n⏱️ Waktu **${Math.round(durationMs / 1000)} detik** • 🪙 Hadiah **${reward} cash**`)
    .setFooter({ text: `Sumber: ${quiz.source || 'Public API'} • Semua member boleh menjawab` });
  if (quiz.image) embed.setImage(quiz.image);
  if (quiz.thumbnail) embed.setThumbnail(quiz.thumbnail);

  await interaction.reply({ embeds: [embed] });
  activeChannels.add(channelId);
  const collector = interaction.channel.createMessageCollector({
    filter: message => !message.author.bot,
    time: durationMs,
  });

  let solved = false;
  const hintTimer = setTimeout(() => {
    const fallbackHint = `${answers[0].split(' ').length} kata • ${answers[0].replace(/\s/g, '').length} huruf`;
    interaction.channel.send({ embeds: [baseEmbed().setTitle('💡 Petunjuk').setDescription(quiz.hint || fallbackHint)] }).catch(() => {});
  }, Math.min(20000, Math.floor(durationMs / 2)));

  collector.on('collect', message => {
    const value = normalizeAnswer(message.content);
    if (!answers.includes(value)) return;
    solved = true;
    clearTimeout(hintTimer);
    collector.stop('solved');
    if (interaction.guildId && reward > 0) updateBalance(interaction.guildId, message.author.id, reward);
    message.reply({ embeds: [successEmbed(`Jawaban **benar**, ${message.author}!\nJawaban: **${quiz.answer}**${reward > 0 ? `\nHadiah: **${reward} cash**` : ''}`)] }).catch(() => {});
  });

  collector.on('end', () => {
    clearTimeout(hintTimer);
    activeChannels.delete(channelId);
    if (!solved) interaction.channel.send({ embeds: [baseEmbed().setTitle('⏰ Waktu habis').setDescription(`Jawaban yang benar: **${quiz.answer}**`)] }).catch(() => {});
  });
}

module.exports = { startQuiz, activeChannels };
