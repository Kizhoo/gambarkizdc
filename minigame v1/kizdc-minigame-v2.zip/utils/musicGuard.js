const { errorEmbed } = require('./embeds');

/**
 * Validasi: ada player aktif & user ada di voice channel yang sama dengan bot.
 * Return player kalau valid, atau null (dan sudah reply error) kalau tidak valid.
 */
async function getValidPlayer(interaction, client) {
  const player = client.kazagumo.players.get(interaction.guild.id);
  if (!player) {
    await interaction.reply({ embeds: [errorEmbed('Tidak ada musik yang sedang diputar.')], ephemeral: true });
    return null;
  }

  const voiceChannel = interaction.member.voice.channel;
  if (!voiceChannel || voiceChannel.id !== player.voiceId) {
    await interaction.reply({ embeds: [errorEmbed('Kamu harus ada di voice channel yang sama dengan bot.')], ephemeral: true });
    return null;
  }

  return player;
}

// Banyak method player (skip/pause/resume/seek/stop/dst) DIAM-DIAM mengirim request ke node
// Lavalink di baliknya (lihat Player.sendServerUpdate) - kalau node yang lagi dipakai player itu
// mati/timeout, method itu REJECT. Sebelumnya tidak ada satu pun command yang menangkap ini
// (tidak di-await, tidak ada .catch()), jadi errornya cuma nyangkut sebagai unhandled rejection
// di console server - user di Discord tidak dapat penjelasan apa pun, cuma diem aja gak kejadian
// apa-apa. Semua command musik yang MENGUBAH state player sekarang wajib lewat helper ini.
async function safePlayerAction(interaction, actionFn, successPayload) {
  try {
    await actionFn();
    return interaction.reply(successPayload);
  } catch (err) {
    console.error(`[Music] Aksi player gagal di guild ${interaction.guild.id}:`, err.message);
    const cause = (err?.cause?.message || err?.cause?.code || '').toLowerCase();
    const rawMsg = (err.message || '').toLowerCase();
    let msg;
    if (rawMsg.includes('youtube extraction failed') || rawMsg.includes('piped instances')) {
      msg = 'Node musik ini gagal ambil audio dari YouTube (server Lavalink-nya yang perlu dibenerin, bukan bot). Coba lagu dari Spotify/SoundCloud dulu.';
    } else if (cause.includes('timeout') || cause.includes('econnrefused') || cause.includes('enotfound') || rawMsg.includes('fetch failed')) {
      msg = 'Node musik (Lavalink) yang lagi dipakai tidak bisa dihubungi (mati/timeout). Coba lagi sebentar lagi, atau owner bisa cek Panel → Backup & Node.';
    } else {
      msg = `Gagal menjalankan aksi ini: ${err.message?.slice(0, 200) || 'error tidak diketahui'}`;
    }
    return interaction.reply({ embeds: [errorEmbed(msg)], ephemeral: true }).catch(() => {});
  }
}

module.exports = { getValidPlayer, safePlayerAction };
