const { EmbedBuilder } = require('discord.js');
const { getGuildConfig } = require('../database/db');
const config = require('../config.json');

module.exports = {
  name: 'guildBanAdd',
  async execute(ban) {
    const cfg = getGuildConfig(ban.guild.id);
    if (!cfg.modLogEnabled || !cfg.logChannel) return;

    const logChannel = ban.guild.channels.cache.get(cfg.logChannel);
    if (!logChannel) return;

    let reason = 'Tidak diketahui';
    try {
      const fetchedBan = await ban.guild.bans.fetch(ban.user.id);
      reason = fetchedBan.reason || 'Tidak ada alasan';
    } catch {}

    const embed = new EmbedBuilder()
      .setColor(config.errorColor)
      .setAuthor({ name: ban.user.tag, iconURL: ban.user.displayAvatarURL() })
      .setTitle('Member Diban')
      .addFields({ name: 'Alasan', value: reason })
      .setFooter({ text: `User ID: ${ban.user.id}`})
      .setTimestamp();
    logChannel.send({ embeds: [embed] }).catch(() => {});
  },
};
