const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  subcommandOf: true,
  data: new SlashCommandBuilder().setName('ping').setDescription('Cek latency bot'),
  async execute(interaction, client) {
    const lang = guildLang(interaction);
    const sent = await interaction.reply({ content: t(lang, 'ping.calc'), fetchReply: true });
    const roundtrip = sent.createdTimestamp - interaction.createdTimestamp;
    const embed = baseEmbed()
      .setTitle('Pong!')
      .addFields(
        { name: t(lang, 'ping.roundtrip'), value: `${roundtrip}ms`, inline: true },
        { name: t(lang, 'ping.api'), value: `${Math.round(client.ws.ping)}ms`, inline: true },
      );
    return interaction.editReply({ content: null, embeds: [embed] });
  },
};
