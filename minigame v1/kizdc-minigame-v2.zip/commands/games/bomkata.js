// ============================================================================
// BOM KATA — party game multiplayer (gaya "Bomb Party"), BUKAN Wordle
// ----------------------------------------------------------------------------
// Lobi terbuka (siapa aja di channel bisa Gabung), lalu gantian: tiap giliran
// dikasih potongan huruf (mis. "AN"), pemain WAJIB ketik kata (langsung di
// chat, bukan tombol) yang mengandung potongan itu sebelum waktu habis. Salah
// format/keulang/telat = kehilangan 1 nyawa. Waktu makin nyempit tiap
// beberapa giliran biar makin seru. Terakhir yang masih hidup = menang.
//
// SENGAJA TIDAK pakai kamus Bahasa Indonesia bawaan buat validasi kata: kamus
// yang tidak lengkap malah bakal nolak kata BENERAN dan bikin frustrasi (bug
// UX yang lebih parah daripada tidak ada validasi sama sekali). Sebagai
// gantinya dipakai validasi struktural (huruf semua, panjang cukup, memang
// mengandung potongan huruf yang diminta, belum pernah dipakai) + tombol
// "Tantang" yang bisa dipencet SIAPA PUN pemain lain yang masih hidup kalau
// merasa itu bukan kata asli - jadi kualitas dijaga rame-rame (khas game
// party), bukan divonis sepihak oleh bot yang bisa aja salah.
// ============================================================================
const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const { baseEmbed, errorEmbed, successEmbed } = require('../../utils/embeds');
const config = require('../../config.json');
const { updateBalance } = require('../../database/db');
const { t, guildLang } = require('../../utils/i18n');

const START_LIVES = 2;
const START_TIME_SECONDS = 18;
const MIN_TIME_SECONDS = 8;
const SHRINK_EVERY_N_TURNS = 4; // tiap 4 giliran sukses, waktu berkurang 1 detik
const CHALLENGE_WINDOW_MS = 7000;
const MAX_PLAYERS = 12;
const MAX_TOTAL_TURNS = 500; // jaring pengaman, harusnya tidak pernah kena di permainan wajar
const WINNER_REWARD = 250;
const RUNNERUP_REWARD = 60;

// Potongan huruf yang dipakai SENGAJA dipilih yang umum banget muncul di kata Bahasa Indonesia
// (kebanyakan suku kata konsonan+vokal & imbuhan umum) - biar hampir selalu ada kata yang cocok,
// gak bikin pemain macet gara-gara potongan hurufnya kelewat langka.
const PROMPTS = [
  'an','ar','in','it','is','ir','ik','il','im','ka','ta','ra','ma','na','sa','ba','da','ga','la','pa',
  'ca','ha','ja','wa','ya','ke','se','te','pe','me','be','de','ge','le','ne','re','we','ko','so','to',
  'po','mo','no','ro','lo','bo','do','go','ku','tu','su','pu','mu','nu','lu','bu','du','gu','ru','ng',
  'ny','ah','ai','au','ing','kan','nya','ber','ter','pen','per','tar','gan','man','tan','lan','san',
];

function pickPrompt() { return PROMPTS[Math.floor(Math.random() * PROMPTS.length)]; }
function computeTimeLimit(totalTurns) {
  return Math.max(MIN_TIME_SECONDS, START_TIME_SECONDS - Math.floor(totalTurns / SHRINK_EVERY_N_TURNS));
}
function isStructurallyValid(word, prompt, usedWords, lang = 'id') {
  const w = word.trim().toLowerCase();
  if (!/^[a-z]+$/.test(w)) return { ok: false, reason: t(lang, 'bk.invalid_letters') };
  if (w.length < 3) return { ok: false, reason: t(lang, 'bk.too_short') };
  if (!w.includes(prompt)) return { ok: false, reason: t(lang, 'bk.missing_piece', { p: prompt.toUpperCase() }) };
  if (usedWords.has(w)) return { ok: false, reason: t(lang, 'bk.used_word') };
  return { ok: true, word: w };
}
function livesDisplay(p) { return '❤️'.repeat(Math.max(0, p.lives)) + '🖤'.repeat(START_LIVES - Math.max(0, p.lives)); }

module.exports = {
  subcommandOf: 'games',
  data: new SlashCommandBuilder()
    .setName('bomkata')
    .setDescription('Bom Kata - party game multiplayer: gantian cari kata sebelum bomnya meledak!'),

  async execute(interaction) {
    const lang = guildLang(interaction);
    // ---------------- LOBI ----------------
    const players = new Map(); // userId -> { user, lives }
    players.set(interaction.user.id, { user: interaction.user, lives: START_LIVES });

    const lobbyRow = (locked = false) => new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('bk_join').setLabel(t(lang, 'bk.join')).setStyle(ButtonStyle.Success).setDisabled(locked || players.size >= MAX_PLAYERS),
      new ButtonBuilder().setCustomId('bk_start').setLabel(t(lang, 'bk.start')).setStyle(ButtonStyle.Primary).setDisabled(locked || players.size < 2),
      new ButtonBuilder().setCustomId('bk_cancel').setLabel(t(lang, 'bk.cancel')).setStyle(ButtonStyle.Danger).setDisabled(locked),
    );
    const lobbyEmbed = () => baseEmbed()
      .setTitle(t(lang, 'bk.lobby_title'))
      .setDescription(t(lang, 'bk.lobby_desc', { max: MAX_PLAYERS, host: `${interaction.user}`, n: players.size, list: [...players.values()].map(p => `• ${p.user}`).join('\n') }))
      .setFooter({ text: t(lang, 'bk.lobby_footer') });

    const lobbyMsg = await interaction.reply({ embeds: [lobbyEmbed()], components: [lobbyRow()], fetchReply: true });
    const lobbyCollector = lobbyMsg.createMessageComponentCollector({ componentType: ComponentType.Button, time: 120000 });
    let started = false, cancelled = false;

    await new Promise((resolve) => {
      lobbyCollector.on('collect', async (i) => {
        if (i.customId === 'bk_join') {
          if (players.has(i.user.id)) return i.reply({ content: t(lang, 'bk.joined'), ephemeral: true }).catch(() => {});
          if (i.user.bot) return i.reply({ content: t(lang, 'bk.bot'), ephemeral: true }).catch(() => {});
          if (players.size >= MAX_PLAYERS) return i.reply({ content: t(lang, 'bk.full'), ephemeral: true }).catch(() => {});
          players.set(i.user.id, { user: i.user, lives: START_LIVES });
          await i.update({ embeds: [lobbyEmbed()], components: [lobbyRow()] }).catch(() => {});
          return;
        }
        if (i.customId === 'bk_start') {
          if (i.user.id !== interaction.user.id) return i.reply({ content: t(lang, 'bk.only_host_start'), ephemeral: true }).catch(() => {});
          if (players.size < 2) return i.reply({ content: t(lang, 'bk.min_players'), ephemeral: true }).catch(() => {});
          started = true;
          await i.update({ embeds: [lobbyEmbed()], components: [lobbyRow(true)] }).catch(() => {});
          lobbyCollector.stop('start');
          return;
        }
        if (i.customId === 'bk_cancel') {
          if (i.user.id !== interaction.user.id) return i.reply({ content: t(lang, 'bk.only_host_cancel'), ephemeral: true }).catch(() => {});
          cancelled = true;
          await i.update({ embeds: [errorEmbed(t(lang, 'bk.cancelled'))], components: [] }).catch(() => {});
          lobbyCollector.stop('cancel');
          return;
        }
      });
      lobbyCollector.on('end', (collected, reason) => {
        if (reason !== 'start' && reason !== 'cancel') {
          lobbyMsg.edit({ embeds: [errorEmbed(t(lang, 'bk.closed'))], components: [] }).catch(() => {});
        }
        resolve();
      });
    });

    if (!started || cancelled) return;

    // ---------------- GAME ----------------
    const order = [...players.keys()].sort(() => Math.random() - 0.5);
    const usedWords = new Set();
    let currentIdx = 0;
    let totalTurns = 0;
    const channel = lobbyMsg.channel;

    const aliveIds = () => order.filter(id => players.get(id).lives > 0);
    const scoreboard = () => order.map(id => {
      const p = players.get(id);
      return `${p.lives > 0 ? '' : '💀 '}${p.user.username}: ${livesDisplay(p)}`;
    }).join(' | ');

    function advanceToNextAlive() {
      const alive = aliveIds();
      if (!alive.length) return null;
      let tries = 0;
      do {
        currentIdx = (currentIdx + 1) % order.length;
        tries++;
      } while (players.get(order[currentIdx]).lives <= 0 && tries <= order.length);
      return order[currentIdx];
    }
    // Pastikan pemain pertama yang jalan memang hidup (selalu true di awal, tapi dijaga juga).
    while (players.get(order[currentIdx]).lives <= 0) currentIdx = (currentIdx + 1) % order.length;

    await channel.send({ embeds: [baseEmbed().setTitle(t(lang, 'bk.started')).setDescription(t(lang, 'bk.started_desc', { lives: START_LIVES, scoreboard: scoreboard() }))] }).catch(() => {});

    while (aliveIds().length > 1 && totalTurns < MAX_TOTAL_TURNS) {
      const currentId = order[currentIdx];
      const current = players.get(currentId);
      const prompt = pickPrompt();
      const timeLimit = computeTimeLimit(totalTurns);

      await channel.send({
        embeds: [baseEmbed().setColor(config.embedColor).setTitle(t(lang, 'bk.turn_title', { name: current.user.username }))
          .setDescription(t(lang, 'bk.turn_desc', { user: `${current.user}`, prompt: prompt.toUpperCase(), time: timeLimit }))],
      }).catch(() => null);

      const collected = await channel.awaitMessages({
        filter: (m) => m.author.id === currentId && !m.author.bot,
        max: 1, time: timeLimit * 1000, errors: [],
      }).catch(() => null);

      const answerMsg = collected?.first();
      const check = answerMsg ? isStructurallyValid(answerMsg.content, prompt, usedWords, lang) : { ok: false, reason: t(lang, 'bk.timeout') };

      if (!check.ok) {
        current.lives--;
        await channel.send({ embeds: [errorEmbed(t(lang, 'bk.lost_life', { name: current.user.username, reason: check.reason }))] }).catch(() => {});
      } else {
        usedWords.add(check.word);
        // Jendela Tantang - siapa pun pemain lain yang MASIH HIDUP bisa gugat kalau kata ini
        // dirasa bukan kata asli. Klik pertama dari pemain valid langsung memutuskan.
        const challengeRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('bk_challenge').setLabel(t(lang, 'bk.challenge_btn')).setStyle(ButtonStyle.Secondary),
        );
        const acceptMsg = await channel.send({
          embeds: [successEmbed(t(lang, 'bk.answer', { u: current.user.username, word: check.word, sec: Math.round(CHALLENGE_WINDOW_MS / 1000) }))],
          components: [challengeRow],
        }).catch(() => null);

        let challenged = false;
        if (acceptMsg) {
          const otherAliveIds = new Set(aliveIds().filter(id => id !== currentId));
          const challengeCollector = acceptMsg.createMessageComponentCollector({ componentType: ComponentType.Button, time: CHALLENGE_WINDOW_MS });
          await new Promise((res) => {
            challengeCollector.on('collect', async (i) => {
              if (!otherAliveIds.has(i.user.id)) return i.reply({ content: t(lang, 'bk.challenger_only'), ephemeral: true }).catch(() => {});
              challenged = true;
              await i.update({ embeds: [errorEmbed(t(lang, 'bk.challenge', { u: players.get(i.user.id).user.username, word: check.word }))], components: [] }).catch(() => {});
              challengeCollector.stop('challenged');
            });
            challengeCollector.on('end', () => res());
          });
          if (!challenged) await acceptMsg.edit({ components: [] }).catch(() => {});
        }

        if (challenged) {
          usedWords.delete(check.word); // dibatalkan, biar bisa dipakai ulang orang lain nanti
          current.lives--;
          await channel.send({ embeds: [errorEmbed(t(lang, 'bk.lose_life', { u: current.user.username }))] }).catch(() => {});
        }
      }

      totalTurns++;
      if (current.lives <= 0) {
        await channel.send({ embeds: [errorEmbed(t(lang, 'bk.eliminated', { name: current.user.username }))] }).catch(() => {});
      }
      if (aliveIds().length <= 1) break;
      advanceToNextAlive();
    }

    const winnerId = aliveIds()[0];
    const winner = winnerId ? players.get(winnerId) : null;
    if (winner && interaction.guildId) {
      updateBalance(interaction.guildId, winnerId, WINNER_REWARD);
      for (const id of order) {
        if (id !== winnerId) updateBalance(interaction.guildId, id, RUNNERUP_REWARD);
      }
    }
    await channel.send({
      embeds: [baseEmbed().setColor(config.successColor).setTitle(t(lang, 'bk.winner_title'))
        .setDescription(winner
          ? t(lang, 'bk.winner_desc', { winner: `${winner.user}`, reward: WINNER_REWARD, runner: RUNNERUP_REWARD })
          : t(lang, 'bk.no_winner'))],
    }).catch(() => {});
  },
};
