const { ActivityType, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getActiveGiveaways, endGiveaway } = require('../database/db');
const { finishGiveaway } = require('../utils/giveawayUtil');
const { getDueReminders, deleteReminder, getBirthdaysToday, markBirthdayAnnounced, getGuildConfig } = require('../database/db');
const {
  getAnimeConfigsWithAnyFeature, updateAnimeConfig, filterUnseenEpisodes, markEpisodesSeen,
  getCryptoConfigsWithSignalEnabled, getCryptoSignalState, setCryptoSignalState,
} = require('../database/db');
const { getTodaySchedule, getUpcomingEpisodes } = require('../utils/animeApi');
const { todayScheduleEmbed, animeEpisodeAlertEmbed } = require('../utils/animeFormat');
const { getKlines, computeIndicators } = require('../utils/cryptoApi');
const { autoSignalAlertEmbed, signalBaselineEmbed } = require('../utils/cryptoFormat');
const { warnEmbed } = require('../utils/embeds');
const { checkAndHeal } = require('../utils/nodeHealthMonitor');
const { startAutoBackup, registerEmergencyBackup } = require('../utils/backup');
const { recoverSessions: recoverWerewolfSessions } = require('../utils/werewolfGame');
const rdb = require('../database/rpgDb');
const { generateQuestBatch } = require('../utils/rpgQuestGenerator');
const { dashboardUrl } = require('../utils/botIntro');
const settings = require('../utils/settings');
const { initPoTokenScheduler } = require('../utils/poTokenScheduler');
const { initEmojiImporter } = require('../utils/emojiImporter');
const config = require('../config.json');
const economyEngine = require('../utils/economyEngine');
const economist = require('../utils/economistAI');
const shopManager = require('../utils/shopManager');
const kizco = require('../utils/kizco');
const econDb = require('../database/economyDb');
const priceAlerts = require('../utils/priceAlerts');
const marketEngine = require('../utils/marketEngine');

const MONTHS = [
  'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
  'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember',
];

module.exports = {
  name: 'clientReady',
  once: true,
  async execute(client) {
    console.log(`[KizhooBot] Login sebagai ${client.user.tag}!`);
    priceAlerts.setClient(client);
    client.user.setPresence({
      activities: [{ name: `${client.commands.size} command | /help`, type: ActivityType.Watching }],
      status: 'online',
    });

    // Pulihkan timer dan channel Werewolf yang masih aktif setelah restart.
    await recoverWerewolfSessions(client);

    // Cek giveaway yang sudah harus berakhir tiap 15 detik
    setInterval(async () => {
      const active = getActiveGiveaways();
      const now = Date.now();
      for (const g of active) {
        if (g.endTime <= now) {
          await finishGiveaway(client, g);
        }
      }
    }, 15000);

    // Cek reminder tiap 20 detik
    setInterval(async () => {
      const due = getDueReminders(Date.now());
      for (const r of due) {
        try {
          const channel = await client.channels.fetch(r.channelId).catch(() => null);
          if (channel) {
            await channel.send(`<@${r.userId}> Pengingat: **${r.message}**`);
          }
        } catch (e) {
          console.error('Gagal kirim reminder: ', e);
        } finally {
          deleteReminder(r.id);
        }
      }
    }, 20000);

    // Cek ulang tahun tiap 1 jam (aman dari duplikasi lewat lastAnnouncedYear)
    const checkBirthdays = async () => {
      const now = new Date();
      const day = now.getDate();
      const month = now.getMonth() + 1;
      const year = now.getFullYear();
      const todayBirthdays = getBirthdaysToday(day, month);

      for (const b of todayBirthdays) {
        if (b.lastAnnouncedYear === year) continue; // sudah diumumkan tahun ini

        const guild = client.guilds.cache.get(b.guildId);
        if (!guild) continue;

        const cfg = getGuildConfig(b.guildId);
        const channelId = cfg.welcomeChannel || cfg.logChannel;
        const channel = channelId ? guild.channels.cache.get(channelId) : null;

        if (channel) {
          const embed = new EmbedBuilder()
            .setColor(config.successColor)
            .setTitle('Happy Birthday!')
            .setDescription(`Selamat ulang tahun <@${b.userId}>! Semoga hari kamu menyenangkan!`)
            .setTimestamp();
          channel.send({ content: `<@${b.userId}>`, embeds: [embed] }).catch(() => {});
        }

        markBirthdayAnnounced(b.guildId, b.userId, year);
      }
    };

    checkBirthdays();
    setInterval(checkBirthdays, 3600000);

    // Cek kesehatan node Lavalink: sekali di awal (kasih waktu node utama konek dulu),
    // lalu tiap 5 menit. Kalau semua node mati, otomatis coba kandidat cadangan
    // dan lapor ke owner lewat DM (lihat utils/nodeHealthMonitor.js).
    setTimeout(() => checkAndHeal(client), 20000);
    setInterval(() => checkAndHeal(client), 300000);

    // ===== AUTO-UPDATE ANIME =====
    // BUGFIX notif anime kekirim 2x: checkAnimeEpisodeAlerts baru menandai episode "sudah
    // diumumkan" SETELAH semua channel selesai dikirimi (lihat markEpisodesSeen di bawah). Kalau
    // siklus sebelumnya belum selesai (network AniList lambat, dll) pas siklus berikutnya sudah
    // due, DUA eksekusi bisa jalan bersamaan dan sama-sama nemu episode yang sama "belum
    // diumumkan" -> episode itu terkirim dua kali. Guard sederhana ini mencegah SEMUA fungsi
    // cek berkala di bawah jalan tumpang-tindih dengan dirinya sendiri.
    const runningChecks = new Set();
    function guardOverlap(key, fn) {
      return async () => {
        if (runningChecks.has(key)) { console.warn(`[${key}] Siklus sebelumnya masih jalan, siklus ini dilewati.`); return; }
        runningChecks.add(key);
        try { await fn(); } finally { runningChecks.delete(key); }
      };
    }

    // Digest jadwal tayang hari ini: dicek tiap `anime.checkIntervalMinutes`, tapi cuma benar-benar
    // kirim sekali per hari per server (begitu jam server cocok `anime.digestHour` DAN belum
    // dikirim hari ini - dedup lewat lastDigestDate). Jadwal cuma di-fetch SEKALI per siklus lalu
    // dibagi ke semua server yang due, bukan fetch per-server, biar hemat request ke AniList.
    const checkAnimeDailyDigest = guardOverlap('animeDailyDigest', async () => {
      const configs = getAnimeConfigsWithAnyFeature().filter(c => c.dailyDigestEnabled && c.channelId);
      if (!configs.length) return;
      if (new Date().getHours() !== settings.get('anime.digestHour', 8)) return;

      const todayKey = new Date().toISOString().slice(0, 10); // kunci dedup harian, tidak perlu sama persis dgn "hari ini" versi lokal - yang penting stabil & ganti sekali/hari
      const due = configs.filter(c => c.lastDigestDate !== todayKey);
      if (!due.length) return;

      let scheduleResult;
      try {
        scheduleResult = await getTodaySchedule({ limit: settings.get('anime.maxItemsPerDigest', 10) });
      } catch (e) {
        console.error('[anime digest] Gagal ambil jadwal:', e.message);
        return;
      }
      const embed = todayScheduleEmbed(scheduleResult, { maxItems: settings.get('anime.maxItemsPerDigest', 10) });

      for (const cfg of due) {
        try {
          const channel = await client.channels.fetch(cfg.channelId).catch(() => null);
          if (channel) await channel.send({ embeds: [embed] });
          updateAnimeConfig(cfg.guildId, { lastDigestDate: todayKey });
        } catch (e) {
          console.error(`[anime digest] Gagal kirim ke guild ${cfg.guildId}:`, e.message);
        }
      }
    });

    // Alert episode baru tayang (SEMUA episode dari anime musim ini, bukan cuma episode 1):
    // beda dengan digest (rekap harian gabungan sekali sehari), ini ngecek jendela waktu SEMPIT
    // tiap siklus dan kirim SATU PESAN PER EPISODE, persis pas jamnya mulai tayang. Dedup GLOBAL
    // per (malId, episode) lewat tabel anime_episode_seen, jadi episode yang sama tidak pernah
    // diumumkan dobel walau jendela cek berikutnya tumpang tindih.
    // CATATAN: karena ini semua episode (bukan cuma anime baru), volumenya jauh lebih banyak
    // daripada versi sebelumnya - di hari/jam ramai tayang bisa banyak pesan sekaligus. Dibatasi
    // `anime.maxEpisodeAlertsPerCheck` per siklus biar tidak membanjiri channel kalau kebetulan
    // banyak anime tayang barengan.
    const checkAnimeEpisodeAlerts = guardOverlap('animeEpisodeAlerts', async () => {
      const configs = getAnimeConfigsWithAnyFeature().filter(c => c.newSeasonAlertEnabled && c.channelId);
      if (!configs.length) return;

      const checkIntervalMinutes = settings.get('anime.checkIntervalMinutes', 20);
      let episodes;
      try {
        // Jendela dilebihkan sedikit dari interval cek (+10 menit) biar tidak ada episode yang
        // kelewat kalau siklus cek meleset/telat sedikit dari jadwal.
        episodes = await getUpcomingEpisodes({ windowMinutes: checkIntervalMinutes + 10 });
      } catch (e) {
        console.error('[anime episode] Gagal ambil jadwal episode:', e.message);
        return;
      }

      const unseen = filterUnseenEpisodes(episodes);
      if (!unseen.length) return;

      const maxAlerts = settings.get('anime.maxEpisodeAlertsPerCheck', 15);
      const toAnnounce = unseen.slice(0, maxAlerts);
      const overflow = unseen.length - toAnnounce.length;

      for (const item of toAnnounce) {
        const embed = animeEpisodeAlertEmbed(item);
        for (const cfg of configs) {
          try {
            const channel = await client.channels.fetch(cfg.channelId).catch(() => null);
            if (channel) await channel.send({ embeds: [embed] });
          } catch (e) {
            console.error(`[anime episode] Gagal kirim ke guild ${cfg.guildId}:`, e.message);
          }
        }
      }
      if (overflow > 0) {
        const note = { embeds: [warnEmbed(`+${overflow} episode lain juga baru tayang di jendela cek ini. Biar tidak membanjiri channel, sisanya akan **diumumkan bertahap di pengecekan berikutnya** (tiap ${checkIntervalMinutes} menit) — tidak ada yang dilewati.`)] };
        for (const cfg of configs) {
          const channel = await client.channels.fetch(cfg.channelId).catch(() => null);
          if (channel) await channel.send(note).catch(() => {});
        }
      }
      // FIX BUG NOTIF ANIME: HANYA tandai episode yang benar-benar SUDAH diumumkan (toAnnounce).
      // Sebelumnya semua `unseen` ditandai seen termasuk yang kena limit overflow -> episode
      // overflow (mis. episode 4, 5, dst yang lewat batas 15/siklus) ditandai "sudah dilihat"
      // padahal cuma dapat catatan "+N lainnya", tidak pernah dapat embed sendiri, lalu HILANG
      // selamanya. Dengan hanya menandai `toAnnounce`, episode overflow tetap "unseen" dan akan
      // diumumkan satu-satu di siklus-siklus berikutnya sampai habis.
      markEpisodesSeen(toAnnounce);
    });

    setTimeout(checkAnimeDailyDigest, 15000);
    setInterval(checkAnimeDailyDigest, settings.get('anime.checkIntervalMinutes', 20) * 60000);
    setTimeout(checkAnimeEpisodeAlerts, 25000);
    setInterval(checkAnimeEpisodeAlerts, settings.get('anime.checkIntervalMinutes', 20) * 60000);

    // ===== SINYAL CRYPTO =====
    // Cuma kirim notifikasi kalau kondisi indikator BERUBAH dibanding pengecekan sebelumnya
    // (dedup lewat tabel crypto_signal_state) - jadi tidak spam tiap siklus. Pengecekan pertama
    // kali per (server, simbol) cuma menyimpan baseline, belum langsung kirim alert.
    const checkCryptoSignals = guardOverlap('cryptoSignals', async () => {
      const configs = getCryptoConfigsWithSignalEnabled();
      if (!configs.length) return;
      const interval = settings.get('crypto.interval', '1h');
      const limit = settings.get('crypto.klineLimit', 100);

      for (const cfg of configs) {
        const symbols = (cfg.watchlist || '').split(',').map(s => s.trim()).filter(Boolean);
        if (!symbols.length) continue;
        const channel = await client.channels.fetch(cfg.channelId).catch(() => null);
        if (!channel) continue;

        for (const symbol of symbols) {
          try {
            const candles = await getKlines(symbol, interval, limit);
            if (candles.length < 20) continue;
            const indicators = computeIndicators(candles);
            const prior = getCryptoSignalState(cfg.guildId, symbol);
            if (!prior) {
              // Baseline pertama kali - kirim SEKALI biar user tau fiturnya beneran jalan,
              // bukan nunggu sampai ada perubahan kondisi (yang bisa berjam-jam/berhari-hari
              // kalau pasarnya lagi anteng).
              await channel.send({ embeds: [signalBaselineEmbed(symbol, indicators, interval)] }).catch(() => {});
              setCryptoSignalState(cfg.guildId, symbol, indicators.state);
              continue;
            }
            if (prior.lastState !== indicators.state) {
              await channel.send({ embeds: [autoSignalAlertEmbed(symbol, indicators, interval, prior.lastState)] }).catch(() => {});
              setCryptoSignalState(cfg.guildId, symbol, indicators.state);
            }
          } catch (e) {
            console.error(`[crypto signal] Gagal cek ${symbol} untuk guild ${cfg.guildId}:`, e.message);
          }
        }
      }
    });

    setTimeout(checkCryptoSignals, 35000);
    setInterval(checkCryptoSignals, settings.get('crypto.checkIntervalMinutes', 30) * 60000);

    // ===== MESIN EKONOMI KIZCO (makroekonomi ala dunia nyata) =====
    // Tiap siklus: hitung M & Y, inflasi/deflasi, fase bisnis, kebijakan moneter,
    // bunga bank, pajak, lalu AI Ekonom menulis laporan & AI Manajer Toko menyetok
    // barang sesuai permintaan. Push snapshot ke dashboard secara real-time.
    function economyNotifyEmbed(guildId, { phaseChange = false } = {}) {
      const s = economyEngine.summary(guildId);
      const logs = economyEngine.getAiLog(guildId, 1);
      const latest = logs[0];
      return new EmbedBuilder()
        .setColor(config.embedColor)
        .setTitle(phaseChange ? `🔄 Perubahan Fase Ekonomi: ${s.phaseLabel}` : '📊 Laporan Ekonomi Kizco')
        .setDescription(latest?.decision || `Indeks harga ${s.priceIndex}, inflasi ${kizco.pct(s.inflationPct)}.`)
        .addFields(
          { name: 'Indeks Harga', value: `${s.priceIndex}`, inline: true },
          { name: 'Inflasi', value: `${kizco.pct(s.inflationPct)}`, inline: true },
          { name: 'Uang Beredar', value: kizco.format(s.moneySupply), inline: true },
          { name: 'Fase', value: s.phaseLabel, inline: true },
          { name: 'Pajak', value: `${s.taxRatePct}%`, inline: true },
          { name: 'Bunga Bank', value: `${s.bankInterestRatePct}%`, inline: true },
        )
        .setFooter({ text: `${config.footer} • siklus #${s.cycle} • /economy untuk panel lengkap` });
    }

    async function maybeNotifyEconomy(client, guildId, tick) {
      const cfg = getGuildConfig(guildId);
      if (!cfg.econNotifyEnabled || !cfg.econChannelId) return;
      const every = settings.get('economy.notifyEveryCycles', 6);
      const lastPoint = econDb.getLastPricePoint(guildId);
      const phaseChange = !!(lastPoint && lastPoint.phase && lastPoint.phase !== tick.state.phase);
      const duePeriodic = tick.state.cycle % Math.max(1, every) === 0;
      if (!phaseChange && !duePeriodic) return;
      try {
        const channel = await client.channels.fetch(cfg.econChannelId).catch(() => null);
        if (channel) await channel.send({ embeds: [economyNotifyEmbed(guildId, { phaseChange })] });
      } catch (e) {
        console.error(`[economy notify] Gagal kirim ke guild ${guildId}:`, e.message);
      }
    }

    const checkEconomy = guardOverlap('economyTick', async () => {
      if (!settings.get('economy.enabled', true)) return;
      const economistEvery = settings.get('economy.economistEveryCycles', 1);
      const shopEvery = settings.get('economy.shopManagerEveryCycles', 1);
      for (const guild of client.guilds.cache.values()) {
        try {
          const tick = economyEngine.tick(guild.id);
          if (tick.state.cycle % Math.max(1, economistEvery) === 0) {
            await economist.runEconomist(guild.id, tick);
          }
          if (tick.state.cycle % Math.max(1, shopEvery) === 0) {
            await shopManager.runShopManagerWithAi(guild.id);
          }
          await maybeNotifyEconomy(client, guild.id, tick);
          if (typeof client.broadcastDashboard === 'function') {
            client.broadcastDashboard('economy', { guildId: guild.id, summary: economyEngine.summary(guild.id) });
          }
        } catch (e) {
          console.error(`[economy] Gagal tick guild ${guild.id}:`, e.message);
        }
      }
    });
    setTimeout(checkEconomy, 60000);
    setInterval(checkEconomy, settings.get('economy.cycleMinutes', 60) * 60000);

    // ===== MARKET ENGINE (harga instrumen KZC, candle OHLCV, realtime) =====
    // Satu engine untuk SEMUA user/guild (bukan simulator per koneksi). Tiap ~5 detik
    // semua instrumen di-step (candle berjalan diperbarui; saat menit berganti, candle
    // ditutup & di-roll-up ke timeframe lebih tinggi). Broadcast ringan ke WebSocket.
    const checkMarket = () => {
      for (const guild of client.guilds.cache.values()) {
        try {
          marketEngine.stepGuild(guild.id);
          marketEngine.maybePrune(guild.id);
          if (typeof client.broadcastDashboard === 'function') {
            client.broadcastDashboard('market', { guildId: guild.id });
          }
        } catch (e) {
          console.error(`[KZC][Market] Gagal step guild ${guild.id}:`, e.message);
        }
      }
    };
    setInterval(checkMarket, Math.max(1, settings.get('economy.marketTickSeconds', 1)) * 1000);

    // ===== QUEST OTOMATIS (AI) — quest untuk WEB GAME =====
    // Tiap server yang mengaktifkan auto-generate, dicek apakah sudah waktunya
    // bikin batch quest baru (interval per rpgQuest.intervalHours, default 12 jam,
    // dedup lewat lastGeneratedAt). Quest baru dibaca LANGSUNG oleh papan quest
    // web game (DB yang sama) dan diumumkan singkat ke channel quest dengan
    // tombol link ke web — semua aksi menerima/menyelesaikan quest terjadi di web.
    const checkRpgAutoQuest = guardOverlap('rpgAutoQuest', async () => {
      // Cleanup dijalankan SELALU (bukan cuma buat guild yang auto-generate) - dua hal: (1) tandai
      // quest yang sudah lewat expiresAt jadi tidak aktif di DB, (2) edit pesan pengumuman quest
      // yang quest-nya sudah semuanya kadaluarsa jadi notice singkat + tombol ke web.
      rdb.deactivateExpiredQuests();
      for (const post of rdb.getDueQuestPosts()) {
        try {
          const channel = await client.channels.fetch(post.channelId).catch(() => null);
          if (!channel) { rdb.markQuestPostCleaned(post.id); continue; }
          const msg = await channel.messages.fetch(post.messageId).catch(() => null);
          if (msg) {
            const oldEmbed = msg.embeds[0];
            const embed = new EmbedBuilder().setColor(config.errorColor || '#ED4245')
              .setTitle((oldEmbed?.title || 'Papan Quest') + ' — Kadaluarsa')
              .setDescription('Semua quest di pengumuman ini sudah lewat batas waktu. Cek papan quest terbaru langsung di web game.');
            await msg.edit({ embeds: [embed], components: [], files: [] }).catch(() => {});
          }
        } catch (e) {
          console.error('[rpg auto-quest cleanup] gagal edit pesan kadaluarsa:', e.message);
        }
        rdb.markQuestPostCleaned(post.id);
      }

      const configs = rdb.getQuestConfigsWithAutoGen();
      if (!configs.length) return;
      const intervalMs = settings.get('rpgQuest.intervalHours', 12) * 3600000;
      const count = settings.get('rpgQuest.countPerCycle', 3);
      const due = configs.filter(c => Date.now() - (c.lastGeneratedAt || 0) >= intervalMs);
      if (!due.length) return;

      // Quest GLOBAL: generate SATU batch, lalu posting ke semua channel quest yang aktif.
      let created = [];
      try {
        const quests = await generateQuestBatch('global', count);
        created = quests.map(q => rdb.createQuest(q));
      } catch (e) {
        console.error('[rpg auto-quest] Gagal generate quest global:', e.message);
      }

      for (const cfg of due) {
        try {
          const channel = await client.channels.fetch(cfg.channelId).catch(() => null);
          if (!channel) { rdb.updateQuestConfig(cfg.guildId, { lastGeneratedAt: Date.now() }); continue; }
          if (!created.length) { rdb.updateQuestConfig(cfg.guildId, { lastGeneratedAt: Date.now() }); continue; }
          rdb.updateQuestConfig(cfg.guildId, { lastGeneratedAt: Date.now() });
          // Pengumuman ringkas: judul quest + reward + tombol link ke web game.
          // TIDAK ada tombol accept Discord lagi — menerima quest dilakukan di web.
          const gameBtn = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setLabel('Buka Papan Quest').setStyle(ButtonStyle.Link)
              .setURL(`${dashboardUrl().replace(/\/+$/, '')}/rpg`),
          );
          const embed = new EmbedBuilder()
            .setColor(config.successColor)
            .setTitle('Quest Baru di Papan Guild!')
            .setDescription(created.map(q => `**${q.title}** _(${q.type})_\n${q.description}\n+${q.rewardXp} XP • +${q.rewardGold} KZC • +${q.rewardRep} rep • min rank ${q.minRank}`).join('\n\n'))
            .setFooter({ text: 'Dibuat otomatis oleh AI • Terima & kejar quest-nya langsung di web game' });
          const sent = await channel.send({ embeds: [embed], components: [gameBtn] }).catch(() => null);
          if (sent) rdb.recordQuestPost(cfg.guildId, channel.id, sent.id, created);
        } catch (e) {
          console.error(`[rpg auto-quest] Gagal generate untuk guild ${cfg.guildId}:`, e.message);
          // Tetap update lastGeneratedAt biar guild yang error terus (mis. provider AI lagi down)
          // tidak nyoba ulang tiap siklus cek (bisa tiap beberapa menit) dan membanjiri log/API.
          rdb.updateQuestConfig(cfg.guildId, { lastGeneratedAt: Date.now() });
        }
      }
    });

    setTimeout(checkRpgAutoQuest, 45000);
    setInterval(checkRpgAutoQuest, settings.get('rpgQuest.checkIntervalMinutes', 60) * 60000);

    // ===== SISTEM BACKUP =====
    // Auto-backup terjadwal + emergency backup saat proses mau dimatikan (SIGTERM/SIGINT).
    registerEmergencyBackup(client);
    startAutoBackup(client);

    // ===== AUTO-REFRESH PO TOKEN LAVALINK =====
    // Menggantikan workflow GitHub Actions terpisah (potokenlava) yang sering timeout karena IP
    // runner Azure gampang diblokir YouTube. Jalan langsung di sini pakai IP server bot ini
    // sendiri. Nonaktif otomatis kalau LAVALINK_URL/LAVALINK_PASSWORD belum diisi di .env.
    initPoTokenScheduler(client);

    // ===== AUTO-IMPORT EMOJI PREMIUM (emoji.gg + URL langsung) =====
    initEmojiImporter(client);
  },
};
