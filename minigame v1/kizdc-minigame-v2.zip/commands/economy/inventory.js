const { SlashCommandBuilder } = require('discord.js');
const { getInventory } = require('../../database/db');
const { baseEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('inventory')
    .setDescription('Lihat isi inventory kamu')
    .addUserOption(o => o.setName('target').setDescription('User yang ingin dilihat inventorynya')),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const target = interaction.options.getUser('target') || interaction.user;
    const items = getInventory(interaction.guild.id, target.id);

    if (items.length === 0) {
      return interaction.reply({ embeds: [baseEmbed().setDescription(t(lang, 'inv.empty', { user: target.username }))] });
    }

    const description = items.map(i => `**${i.name}** x${i.quantity}${i.description ? `\n${i.description}` : ''}`).join('\n\n');
    return interaction.reply({ embeds: [baseEmbed().setTitle(t(lang, 'inv.title', { user: target.username })).setDescription(description)] });
  },
};
