const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  subcommandOf: true,
  data: new SlashCommandBuilder()
    .setName('qrcode')
    .setDescription('Buat QR code dari teks atau link')
    .addStringOption(o => o.setName('teks').setDescription('Teks atau URL yang ingin dijadikan QR code').setRequired(true)),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const text = interaction.options.getString('teks');
    const url = `https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=${encodeURIComponent(text)}`;

    const embed = baseEmbed()
      .setTitle('QR Code')
      .setDescription(t(lang, 'qrcode.desc', { t: text.slice(0, 100) }))
      .setImage(url);

    return interaction.reply({ embeds: [embed] });
  },
};
