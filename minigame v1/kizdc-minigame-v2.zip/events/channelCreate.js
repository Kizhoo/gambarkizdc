const { sendLog } = require('../utils/serverLog');
const config = require('../config.json');

module.exports = {
  name: 'channelCreate',
  async execute(channel) {
    if (!channel.guild) return;
    sendLog(channel.guild, {
      title: 'Channel Dibuat',
      color: config.successColor,
      fields: [
        { name: 'Nama', value: `${channel} (${channel.name})`, inline: true },
        { name: 'Tipe', value: `${channel.type}`, inline: true },
      ],
      footer: `Channel ID: ${channel.id}`,
    });
  },
};
