# HOSTING — Panduan Deploy di MonkeyBytes Hosting (Monkey Network)

Dokumen ini merangkum peraturan resmi MonkeyBytes Hosting (dibaca dari
`https://monkey-network.xyz/` — Terms of Service, FAQ, dan Security Guide)
dan cara project ini mematuhinya. Tujuannya: **tidak mengulang insiden ban
otomatis** yang terjadi sebelumnya.

> Sumber: `/legal/terms.html`, `/faq.html`, `/guides/discord-bot-security-best-practices.html`
> Terakhir dicek: 25 September 2026.

---

## 1. Ringkasan Peraturan (yang relevan ke project ini)

### Yang DIIZINKAN
- Hosting Discord bot untuk penggunaan pribadi, komunitas, atau edukasi.
- **Backend service yang benar-benar dibutuhkan bot** — dashboard web RPG
  termasuk kategori ini: game-nya adalah fitur inti bot, memakai database
  SQLite yang sama, dan login-nya via Discord OAuth bot.
- Belajar & eksperimen kode, project open-source / pribadi.
- SQLite langsung jalan (hanya file di folder bot) — cocok dengan project ini.

### Yang DILARANG (poin kritis)
| Larangan | Status project ini |
|----------|--------------------|
| Malware, spam, raid, otomasi abusif | Aman — bukan kasus |
| **Kode ter-obfuscate** (scanner ToS: `OBFUSCATED_CODE`) | **SUDAH DIPERBAIKI** — build sekarang pakai terser (minifikasi standar). `javascript-obfuscator` sudah di-uninstall total. |
| **Proxy / VPN / tunneling**, proses yang meneruskan traffic pihak ketiga lewat infrastruktur mereka | **WAJIB `ENABLE_TUNNEL=false` (atau kosong)** — fitur tunnel Cloudflare di project ini hanya untuk hosting lain / dev lokal. JANGAN AKTIFKAN di MonkeyBytes. |
| Cryptomining / resource abuse | Aman |
| Reselling hosting | Aman |
| Game server (Minecraft dsb.) yang tak berhubungan dengan bot Discord | Aman — RPG web-nya adalah fitur bot, bukan game server standalone |
| Melanggar ToS Discord | Aman |

### Limit resource (free plan)
- 2 GB RAM, 2 GB SSD, 300% CPU, 1 database, 1 alokasi jaringan, maks 4 server.
- Uptime 24/7, auto-restart saat crash, tanpa sleep timer.
- **Konfirmasi server tiap 14 hari** lewat lifecycle system di dashboard
  panel — kalau tidak, server ditandai inactive dan bisa direclaim.
  Ingatkan dirimu sendiri (mis. reminder Discord tiap 10 hari).

---

## 2. Checklist Deploy (MonkeyBytes)

1. **Login panel** → buat server Node.js.
2. **Set environment variable DI PANEL** (bukan di file `.env` yang ke-upload):
   - `DISCORD_TOKEN`, `CLIENT_ID` (wajib)
   - `DASHBOARD_TOKEN`, `DASHBOARD_REDIRECT_URL`, `OWNER_ID`
   - `ALLOWED_DOMAINS` = domain resmi publik dashboard-mu
   - `ENABLE_TUNNEL` = **kosongkan / false** (ToS: dilarang)
   - Kalau di hosting masih ada file `.env` LAMA dari setup sebelumnya: BUKA dan
     HAPUS baris `ENABLE_TUNNEL=true` — sisa konfigurasi lama membuat proses
     tunnel cloudflared jalan tiap boot = pelanggaran ToS = suspend. Sejak v6
     package `cloudflared` sudah dihapus dari dependencies dan tunnel otomatis
     ditolak di lingkungan panel, tapi tetap bersihkan `.env`-nya.
3. **STOP server dulu di panel** (tombol Stop, bukan restart). File yang
   ditimpa saat proses Node masih berjalan bisa gagal timpa/gagal muat — ini
   penyebab utama kondisi "file campur versi" (backend lama + frontend baru).
4. **Nyalakan maintenance mode**, lalu **HAPUS semua file kode lama** di
   `/home/container/` **KECUALI `database/kizhoobot.sqlite`** (dan `.env` kalau
   ada). File DB itu = seluruh progres game pemain (karakter, inventory, pet,
   quest) — JANGAN ikut dihapus. Skema tabel web (chat/sesi/teman/achievement)
   sudah punya *self-heal* otomatis saat boot, jadi DB lama tetap aman dipakai.
5. **Upload via SFTP** (host/port/username/password dari panel, port biasanya
   2022) ke `/home/container/`:
   - Upload SEMUA file project **KECUALI `node_modules/` dan `.git/`**
     (JANGAN upload node_modules — install lewat console).
   - Pastikan `package.json` ter-upload dan entry file `index.js` ada.
   - Setelah upload, cek di file manager: file `database/rpgDb.js` dan
     `utils/rpgServer.js` HARUS hasil upload baru (tanggal modifikasi hari ini).
     Kalau tanggalnya lama, upload ulang file itu — backend lama adalah sumber
     error `no such column: scope` / chat & lobby mati.
6. **Install dependensi lewat console panel** (bukan upload):
   ```
   npm install --omit=dev
   ```
   (`--omit=dev` supaya devDependencies seperti terser tidak ikut — lebih
   hemat storage 2 GB).
7. **Set start command** di panel: `npm start` (entry: `node index.js`).
8. **Satu alokasi jaringan** → arahkan ke port yang dipakai dashboard
   (default `DASHBOARD_PORT`, cek `.env` / panel). Alokasi inilah yang
   membuat web RPG bisa diakses publik.
9. **START server dari panel**, matikan maintenance mode → bot start.
10. **VERIFIKASI PASCA-DEPLOY (wajib, 1 menit)** — mencegah "game tiba-tiba
    jelek diam-diam" karena file campur versi / upload terpotong:
   - Buka `https://domain-mu/api/rpg/asset-integrity`
     → harus `"ok": true`. Kalau `ok: false`, daftar `missing` menunjukkan
     file/folder mana yang tidak lengkap — upload ulang.
   - Buka `https://domain-mu/api/rpg/build-info`
     → catat `build`-nya; harus `2026.09.26-3`, sama dengan yang terlihat di
     footer lobby game, dan tidak muncul banner merah "file campur versi" saat
     game dibuka.
   - Deploy Guard aktif otomatis di sisi game: halaman membandingkan versi
     engine vs halaman vs server; aset yang gagal dimuat >= 3 muncul banner
     peringatan. Browser cache dibypass lewat `?v=<build>` di semua aset.
11. **Cek log console** — pastikan tidak ada error, lalu tes `/rpg` di Discord
    dan buka web-nya.
12. Set **reminder 14 hari** untuk konfirmasi lifecycle.

### Troubleshooting cepat

| Gejala | Arti & solusi |
|--------|---------------|
| `SqliteError: no such column: ...` (mis. `scope`) di log | Backend di hosting BUKAN versi terbaru — `database/rpgDb.js` / `utils/rpgServer.js` masih versi lama/asing. Solusi: stop server, hapus file kode (PERTAHANKAN `database/kizhoobot.sqlite`), upload ulang zip terbaru, start. Versi terbaru tidak pernah memakai kolom `scope`. |
| Chat / lobby multiplayer mati total | Biasanya efek backend campur versi (endpoint baru tidak ada / error 500). Setelah deploy bersih, chat punya dua jalur (WS + fallback REST). |
| Layar "Terjadi Error" `Cannot read properties of null (reading 'slice')` | Sudah diperbaiki di build `2026.09.26-3` (karakter baru: daftar dungeon selalu diinisialisasi). Kalau masih muncul, hard-refresh browser (Ctrl+Shift+R) supaya `rpg.min.js` baru termuat. |
| Ikon item terlihat berantakan/noise | Build `2026.09.26-3` memfilter ikon PNG (LINEAR) & sprite pixel (NEAREST) secara terpisah. Kalau masih terlihat noise, pastikan folder `assets/icons/` ter-upload lengkap (cek `/api/rpg/asset-integrity`). |
| Saldo KZC di web beda dengan `/balance` di Discord | KZC RPG disimpan PER-SERVER. Gunakan chip "Dompet: ..." di kiri-atas lobby untuk memilih server dompet yang sama dengan server tempat `/balance` dijalankan. |
| `[rpgDb] Skema ... di-reset` muncul di log boot | NORMAL — self-heal menormalkan tabel web (chat/sesi/teman/achievement) dari skema lama. Progres game tidak tersentuh. |
| Server ter-suspend: "This server is currently suspended" | Pesan dari panel hosting (proses dihentikan di level infrastruktur), bukan bug kode. Lihat seksi "Jika server ter-suspend" di bawah. |

### Catatan WebSocket (chat & multiplayer)
- Chat dunia & chat teman punya **fallback REST**: kalau proxy hosting tidak
  meneruskan WebSocket, pesan tetap terkirim (mode hemat, daftar memuat ulang
  tiap 5 detik) dan status "realtime terputus" terlihat jelas di UI.
- Lobby multiplayer & party raid butuh WebSocket penuh. Kalau chip status di
  scene multiplayer menulis "realtime terputus — server/hosting tidak
  meneruskan koneksi realtime", aktifkan dukungan WebSocket di proxy/alokasi
  jaringan panel (opsi "WebSocket" pada alokasi, kalau tersedia).

### Jika server ter-suspend (pesan "This server is currently suspended")

Pesan itu murni dari panel hosting — artinya pihak hosting menghentikan server
di level infrastruktur, bukan crash dari kode game. Urutan penanganan:

1. Cek email + notifikasi di panel untuk alasan resmi suspend.
2. Appeal / tanya staff: `monkeybyteshosting@gmail.com` atau Discord community
   (section 5). Poin appeal: server hanya menjalankan Discord bot + dashboard
   web RPG milik sendiri (Node.js + SQLite), TANPA tunneling (`ENABLE_TUNNEL`
   kosong; package tunnel dihapus total sejak v6), TANPA kode ter-obfuscate
   (minifikasi terser standar industri).
3. Cek pemicu paling umum dari sisi kita (urut kemungkinan):
   - `.env` lama di hosting masih berisi `ENABLE_TUNNEL=true` — proses
     cloudflared pernah jalan tiap boot padahal ToS melarang tunneling.
     Bersihkan baris itu.
   - Disk quota 2 GB penuh (folder `backups/` menumpuk arsip). Sejak v6 arsip
     dirotasi otomatis (maks 3) dan emergency backup dibatasi 1x per 6 jam.
   - Konfirmasi lifecycle 14 hari terlewat — konfirmasi ulang di dashboard
     panel; biasanya server langsung menyala lagi setelah dikonfirmasi.
4. Setelah di-unsuspend: ulangi checklist deploy section 2 mulai langkah 3
   (stop server dulu, hapus file lama KECUALI `database/kizhoobot.sqlite`,
   upload zip terbaru).

---

## 3. Kenapa dulu kena ban, dan jaminan sekarang

**Insiden**: akun ter-ban otomatis oleh scanner ToS (rule `OBFUSCATED_CODE`,
5 strike) karena `rpg.min.js` dulunya dibangun dengan package
`javascript-obfuscator` — outputnya (string ter-encode, nama variabel acak,
self-defending) identik pola malware di mata scanner.

**Perbaikan permanen** (commit `04c8830`):
- `javascript-obfuscator` di-**uninstall** dari project; build script tidak
  lagi memanggilnya.
- `rpg.min.js` dibangun dengan **terser** — minifikasi standar industri
  (dipakai jQuery/React/dll), struktur & string tetap terbaca scanner.
- Proteksi anti-clone TIDAK bergantung obfuscation: domain-lock server +
  security-lock client + security gate game tetap aktif penuh (lihat
  `SECURITY.md`).

**Jaminan ke depan**: `npm run build:client` hanya menghasilkan minifikasi
terser yang bisa diaudit penuh. Tidak ada lagi proses build yang menghasilkan
pola obfuscation.

---

## 4. Catatan fitur yang berkaitan hosting

| Fitur | Pengaturan aman |
|-------|-----------------|
| Tunnel Cloudflare (`utils/tunnel.js`) | **OFF di MonkeyBytes** (ToS larang tunneling). Hanya untuk dev lokal / hosting lain yang mengizinkan. Default memang OFF — hanya jalan kalau `ENABLE_TUNNEL=true`. |
| Gzip compression | ON — hemat bandwidth, tidak ada larangan |
| Rate limiting / WAF / honeypot | ON — justru menaikkan reputasi bot (menghentikan penyalahgunaan) |
| Backup SQLite otomatis | ON — sejak v6 arsip dirotasi otomatis (maks 3) + emergency backup dibatasi 1x/6 jam (anti disk penuh) |
| `rpg_security_log` | Auto-trim 5000 baris — tidak akan membengkakkan storage |

---

## 5. Kontak MonkeyBytes

- Email: `monkeybyteshosting@gmail.com`
- Discord community: `http://gb.monkey-network.xyz:4039`
- Appeal ban: hubungi staff langsung (draf appeal tersedia di
  `download/APPEAL-hosting-ban.md` pada workspace pembuatan project ini).
