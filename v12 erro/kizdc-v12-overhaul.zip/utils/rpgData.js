// ============================================================================
// DATA STATIS SISTEM RPG "KIZHOO ADVENTURE"
// ----------------------------------------------------------------------------
// Semua angka DISESUAIKAN dengan skala bot (level cap 100).
//
// Berisi: kurva XP, RANK (G..Omega), CLASS (4: Warrior/Mage/Assassin/Archer)
// + stat dasar & growth, SKILL TREE per class (10 skill, 4 tier, ala game AAA),
// definisi ACHIEVEMENT, tier reputasi, dan daftar monster untuk battle engine.
// File ini murni data + fungsi kalkulasi kecil, tidak menyentuh DB/Discord.
//
// CATATAN HEALER -> ARCHER: class Healer diganti Archer penuh. Mage kini punya
// skill penyembuhan diri (Regeneration) dan tim (Bloom of Life), jadi peran
// support tetap ada tanpa class terpisah.
// ============================================================================

// ---------- KURVA XP (level karakter RPG, terpisah dari XP chat) ----------
const LEVEL_CAP = 100;
function xpForLevel(level) {
  if (level >= LEVEL_CAP) return Infinity;
  return Math.floor(50 * level * level + 150 * level + 50);
}
// Total XP kumulatif untuk MENCAPAI sebuah level (dari level 1).
function totalXpForLevel(level) {
  let sum = 0;
  for (let l = 1; l < level; l++) sum += xpForLevel(l);
  return sum;
}
// Skill point yang didapat tiap naik 1 level (kelipatan 5 dapat bonus).
function skillPointsForLevelUp(newLevel) {
  return 1 + (newLevel % 5 === 0 ? 1 : 0);
}
// Stat point (untuk alokasi manual) tiap naik level.
function statPointsForLevelUp() { return 3; }

// ---------- RANK (G paling bawah .. Omega paling atas) ----------
const RANKS = [
  { key: 'G',   name: 'Novice',      color: '#9CA3AF', promo: 'grind',    req: { level: 1 } },
  { key: 'F',   name: 'Apprentice',  color: '#A3A3A3', promo: 'grind',    req: { level: 5,  quests: 5 } },
  { key: 'E',   name: 'Iron',        color: '#78716C', promo: 'grind',    req: { level: 12, quests: 15, monsters: 50 } },
  { key: 'D',   name: 'Bronze',      color: '#B45309', promo: 'grind',    req: { level: 20, quests: 30, dungeons: 1 } },
  { key: 'C',   name: 'Silver',      color: '#CBD5E1', promo: 'grind',    req: { level: 30, quests: 50, reputation: 500 } },
  { key: 'B',   name: 'Gold',        color: '#EAB308', promo: 'grind',    req: { level: 42, dungeons: 3, partyLed: 5 } },
  { key: 'A',   name: 'Platinum',    color: '#22D3EE', promo: 'grind',    req: { level: 55, bosses: 1, reputation: 1500 } },
  { key: 'S',   name: 'Diamond',     color: '#38BDF8', promo: 'grind',    req: { level: 70, worldQuests: 1, reputation: 3000 } },
  { key: 'SS',  name: 'Mythril',     color: '#6366F1', promo: 'grind',    req: { level: 85, dungeons: 10, bosses: 3 } },
  { key: 'SSS', name: 'Adamantite',  color: '#A855F7', promo: 'grind',    req: { level: 100, bosses: 5, reputation: 6000 } },
  { key: 'EX',  name: 'Divine',      color: '#F59E0B', promo: 'prestige', req: { note: 'Hanya dari prestasi luar biasa / event khusus. Tidak bisa digrind.' } },
  { key: 'Ω',   name: 'Celestial',   color: '#EF4444', promo: 'legendary', req: { note: 'Hanya 1 orang per era. Diberikan owner/sistem dunia.' } },
];
const RANK_INDEX = Object.fromEntries(RANKS.map((r, i) => [r.key, i]));
function getRank(key) { return RANKS[RANK_INDEX[key]] || RANKS[0]; }
function nextRank(key) { const i = RANK_INDEX[key]; return i != null && i < RANKS.length - 1 ? RANKS[i + 1] : null; }
function rankAtLeastMet(character, req) {
  const missing = [];
  const map = {
    level: ['level', 'Level'],
    quests: ['questsCompleted', 'Quest selesai'],
    monsters: ['monstersKilled', 'Monster dikalahkan'],
    dungeons: ['dungeonsCleared', 'Dungeon selesai'],
    bosses: ['bossesDefeated', 'Boss dikalahkan'],
    worldQuests: ['worldQuests', 'World Quest'],
    reputation: ['reputation', 'Reputasi'],
    partyLed: ['partyLed', 'Memimpin party'],
  };
  for (const [k, v] of Object.entries(req)) {
    if (k === 'note') continue;
    const [field, label] = map[k] || [k, k];
    const have = character[field] || 0;
    if (have < v) missing.push({ label, have, need: v });
  }
  return missing;
}

// ---------- CLASS (4) — Healer digantikan Archer ----------
// baseStats pada level 1; growth = tambahan per level.
const CLASSES = {
  warrior: {
    key: 'warrior', name: 'Warrior', role: 'Tank / DPS Fisik', color: '#DC2626',
    description: 'Prajurit garis depan. HP dan pertahanan tebal, jago bertahan sambil memukul keras.',
    base:   { hp: 140, mp: 30, atk: 18, def: 16, spd: 8,  crit: 5 },
    growth: { hp: 16,  mp: 3,  atk: 3.2, def: 2.8, spd: 0.6, crit: 0.2 },
  },
  mage: {
    key: 'mage', name: 'Mage', role: 'Burst Sihir / AoE / Penyembuh', color: '#7C3AED',
    description: 'Penyihir serba bisa. Ledakan sihir besar, serangan area, sampai menyembuhkan diri dan tim.',
    base:   { hp: 90,  mp: 90, atk: 22, def: 8,  spd: 10, crit: 8 },
    growth: { hp: 9,   mp: 9,  atk: 4.0, def: 1.2, spd: 0.8, crit: 0.35 },
  },
  assassin: {
    key: 'assassin', name: 'Assassin', role: 'Crit / Evasion / DoT', color: '#059669',
    description: 'Pembunuh gesit. Critical dan kecepatan tinggi, menghindar dan meracuni lawan.',
    base:   { hp: 105, mp: 50, atk: 20, def: 10, spd: 16, crit: 15 },
    growth: { hp: 11,  mp: 5,  atk: 3.6, def: 1.6, spd: 1.4, crit: 0.6 },
  },
  archer: {
    key: 'archer', name: 'Archer', role: 'DPS Jarak Jauh / Crit', color: '#65A30D',
    description: 'Pemanah berhati dingin. Menghujani musuh dari jauh dengan panah presisi dan racun.',
    base:   { hp: 100, mp: 55, atk: 21, def: 9, spd: 14, crit: 12 },
    growth: { hp: 10,  mp: 5,  atk: 3.7, def: 1.3, spd: 1.1, crit: 0.5 },
  },
};
const CLASS_KEYS = Object.keys(CLASSES);

function baseStatsForLevel(classKey, level) {
  const c = CLASSES[classKey] || CLASSES.warrior;
  const s = {};
  for (const stat of Object.keys(c.base)) {
    s[stat] = Math.round((c.base[stat] + c.growth[stat] * (level - 1)) * 10) / 10;
  }
  return s;
}

// ---------- SKILL TREE per class (10 skill, 4 tier — ala game AAA) ----------
// tier     = baris pohon (gating visual & urutan buka).
// reqLevel = level karakter minimal.
// requires = skill prasyarat (harus sudah dibuka minimal level 1).
// type     = 'active' (dipakai di battle) / 'passive' (bonus pasif).
// maxLevel = bisa di-upgrade; cost = skill point per level upgrade.
// effect   = parameter untuk battle engine (bot & web memakai skema sama):
//   dmg, aoe, hits (multi-hit), critBonus, execute, dot, turns, heal, healAoe,
//   shield, atkBuff, slow, evasion, absorbMp, reviveHp, mark (amp damage),
//   pierce (abaikan sebagian DEF), defPct, atkPct, spdPct, critPct, hpPct,
//   healPct, evaPct, mpRegen, firstStrike.
// fx       = deskriptor visual untuk web (bot mengabaikannya).
const SKILL_TREES = {
  warrior: [
    { id: 'w_slash',   name: 'Power Slash',    type: 'active',  tier: 1, reqLevel: 1,  maxLevel: 5, cost: 1, requires: [],
      effect: { dmg: 1.4, mp: 8 }, fx: { kind: 'slash', color: '#f97316' },
      desc: 'Tebasan kuat 140% ATK. Naik +12% per level.' },
    { id: 'w_guard',   name: 'Iron Guard',     type: 'passive', tier: 1, reqLevel: 1,  maxLevel: 5, cost: 1, requires: [],
      effect: { defPct: 0.06 }, fx: { kind: 'passive', color: '#94a3b8' },
      desc: 'DEF pasif +6% per level.' },
    { id: 'w_taunt',   name: 'Taunt',          type: 'active',  tier: 2, reqLevel: 8,  maxLevel: 3, cost: 1, requires: ['w_guard'],
      effect: { shield: 0.1, turns: 2, mp: 10 }, fx: { kind: 'shield', color: '#fbbf24' },
      desc: 'Menghina musuh lalu berdiri kokoh: perisai 10% HP maks.' },
    { id: 'w_cleave',  name: 'Cleave',         type: 'active',  tier: 2, reqLevel: 12, maxLevel: 5, cost: 1, requires: ['w_slash'],
      effect: { dmg: 1.1, aoe: true, mp: 14 }, fx: { kind: 'cleave', color: '#f97316' },
      desc: 'Sabetan luas: 110% ATK ke semua musuh.' },
    { id: 'w_tough',   name: 'Toughness',      type: 'passive', tier: 2, reqLevel: 10, maxLevel: 5, cost: 1, requires: ['w_guard'],
      effect: { hpPct: 0.05 }, fx: { kind: 'passive', color: '#ef4444' },
      desc: 'HP maks pasif +5% per level.' },
    { id: 'w_whirl',   name: 'Whirlwind',      type: 'active',  tier: 3, reqLevel: 20, maxLevel: 5, cost: 2, requires: ['w_cleave'],
      effect: { dmg: 1.5, aoe: true, mp: 22 }, fx: { kind: 'spin', color: '#fdba74' },
      desc: 'Berputar seperti badai: 150% ATK ke semua musuh.' },
    { id: 'w_berserk', name: 'Berserker Rage', type: 'active',  tier: 3, reqLevel: 25, maxLevel: 3, cost: 2, requires: ['w_cleave', 'w_taunt'],
      effect: { atkBuff: 0.3, turns: 3, mp: 25 }, fx: { kind: 'rage', color: '#dc2626' },
      desc: 'Amukan membara: ATK +30% selama 3 giliran.' },
    { id: 'w_warlord', name: 'Warlord Cry',    type: 'active',  tier: 4, reqLevel: 35, maxLevel: 3, cost: 2, requires: ['w_whirl'],
      effect: { atkBuff: 0.2, shield: 0.15, turns: 3, mp: 30 }, fx: { kind: 'banner', color: '#f59e0b' },
      desc: 'Sorakan perang: ATK +20% dan perisai 15% HP untuk satu giliran penuh.' },
    { id: 'w_last',    name: 'Last Stand',     type: 'passive', tier: 4, reqLevel: 40, maxLevel: 1, cost: 3, requires: ['w_berserk'],
      effect: { reviveHp: 0.25 }, fx: { kind: 'passive', color: '#fbbf12' },
      desc: 'Sekali per battle: bertahan di 1 HP lalu pulih 25% HP.' },
    { id: 'w_colossus',name: 'Colossus',       type: 'passive', tier: 4, reqLevel: 45, maxLevel: 3, cost: 3, requires: ['w_warlord'],
      effect: { defPct: 0.1, thorns: 0.08 }, fx: { kind: 'passive', color: '#a16207' },
      desc: 'Tubuh raksasa: DEF +10% dan memantulkan 8% damage per level.' },
  ],
  mage: [
    { id: 'm_fire',    name: 'Fireball',       type: 'active',  tier: 1, reqLevel: 1,  maxLevel: 5, cost: 1, requires: [],
      effect: { dmg: 1.6, mp: 12 }, fx: { kind: 'fireball', color: '#f97316' },
      desc: 'Bola api 160% ATK sihir ke satu musuh.' },
    { id: 'm_focus',   name: 'Arcane Focus',   type: 'passive', tier: 1, reqLevel: 1,  maxLevel: 5, cost: 1, requires: [],
      effect: { atkPct: 0.06 }, fx: { kind: 'passive', color: '#a78bfa' },
      desc: 'ATK sihir pasif +6% per level.' },
    { id: 'm_regen',   name: 'Regeneration',   type: 'active',  tier: 2, reqLevel: 8,  maxLevel: 5, cost: 1, requires: ['m_focus'],
      effect: { heal: 1.3, mp: 10 }, fx: { kind: 'heal', color: '#4ade80' },
      desc: 'Menjahit luka dengan sihir: pulihkan 130% ATK sebagai HP diri.' },
    { id: 'm_frost',   name: 'Frost Nova',     type: 'active',  tier: 2, reqLevel: 10, maxLevel: 5, cost: 1, requires: ['m_fire'],
      effect: { dmg: 1.1, aoe: true, slow: true, mp: 20 }, fx: { kind: 'frost', color: '#7dd3fc' },
      desc: 'Ledakan es: 110% ATK ke semua musuh + memperlambat.' },
    { id: 'm_shield',  name: 'Mana Shield',    type: 'active',  tier: 3, reqLevel: 12, maxLevel: 3, cost: 1, requires: ['m_focus'],
      effect: { absorbMp: true, mp: 18 }, fx: { kind: 'manashield', color: '#60a5fa' },
      desc: 'Selubung mana menyerap damage memakai MP.' },
    { id: 'm_bloom',   name: 'Bloom of Life',  type: 'active',  tier: 3, reqLevel: 18, maxLevel: 5, cost: 2, requires: ['m_regen'],
      effect: { healAoe: 0.9, turns: 3, mp: 24 }, fx: { kind: 'bloom', color: '#34d399' },
      desc: 'Sekuntum cahaya hidup: pulihkan 90% ATK untuk diri dan seluruh tim, plus regen 3 giliran.' },
    { id: 'm_meteor',  name: 'Meteor',         type: 'active',  tier: 3, reqLevel: 28, maxLevel: 3, cost: 2, requires: ['m_frost'],
      effect: { dmg: 2.6, aoe: true, mp: 40 }, fx: { kind: 'meteor', color: '#fb923c' },
      desc: 'Meteor jatuh: 260% ATK ke semua musuh.' },
    { id: 'm_timeflow',name: 'Time Flow',      type: 'passive', tier: 4, reqLevel: 40, maxLevel: 3, cost: 3, requires: ['m_bloom'],
      effect: { healPct: 0.08, spdPct: 0.04 }, fx: { kind: 'passive', color: '#c084fc' },
      desc: 'Waktu mengalir lambat: efek penyembuhan +8% dan SPD +4% per level.' },
    { id: 'm_arch',    name: 'Archmage',       type: 'passive', tier: 4, reqLevel: 45, maxLevel: 1, cost: 3, requires: ['m_meteor', 'm_shield'],
      effect: { critPct: 0.15, mpRegen: 10 }, fx: { kind: 'passive', color: '#8b5cf6' },
      desc: 'Puncak ilmu sihir: crit +15% dan regen 10 MP tiap giliran.' },
    { id: 'm_void',    name: 'Void Cascade',   type: 'active',  tier: 4, reqLevel: 50, maxLevel: 3, cost: 3, requires: ['m_meteor'],
      effect: { dmg: 2.0, aoe: true, hits: 2, mp: 55 }, fx: { kind: 'void', color: '#a855f7' },
      desc: 'Robekan kehampaan beruntun: dua gelombang 200% ATK ke semua musuh.' },
  ],
  assassin: [
    { id: 'a_strike',  name: 'Shadow Strike',  type: 'active',  tier: 1, reqLevel: 1,  maxLevel: 5, cost: 1, requires: [],
      effect: { dmg: 1.5, critBonus: 0.1, mp: 10 }, fx: { kind: 'dash', color: '#34d399' },
      desc: 'Tikaman bayangan 150% ATK dengan crit +10%.' },
    { id: 'a_agi',     name: 'Agility',        type: 'passive', tier: 1, reqLevel: 1,  maxLevel: 5, cost: 1, requires: [],
      effect: { spdPct: 0.06, evaPct: 0.03 }, fx: { kind: 'passive', color: '#6ee7b7' },
      desc: 'SPD +6% dan peluang hindar +3% per level.' },
    { id: 'a_poison',  name: 'Poison Blade',   type: 'active',  tier: 2, reqLevel: 10, maxLevel: 5, cost: 1, requires: ['a_strike'],
      effect: { dmg: 0.8, dot: 0.15, turns: 3, mp: 14 }, fx: { kind: 'poison', color: '#a3e635' },
      desc: 'Bilah berlumpur racun: 80% ATK + racun 15% ATK per giliran.' },
    { id: 'a_smoke',   name: 'Smoke Bomb',     type: 'active',  tier: 2, reqLevel: 14, maxLevel: 3, cost: 1, requires: ['a_agi'],
      effect: { evasion: 0.5, turns: 2, mp: 16 }, fx: { kind: 'smoke', color: '#94a3b8' },
      desc: 'Bom asap: peluang hindar 50% selama 2 giliran.' },
    { id: 'a_flurry',  name: 'Blade Flurry',   type: 'active',  tier: 3, reqLevel: 20, maxLevel: 5, cost: 2, requires: ['a_poison'],
      effect: { dmg: 0.65, hits: 3, mp: 18 }, fx: { kind: 'flurry', color: '#5eead4' },
      desc: 'Tarian bilah: 3 serangan beruntun masing-masing 65% ATK.' },
    { id: 'a_assass',  name: 'Assassinate',    type: 'active',  tier: 3, reqLevel: 30, maxLevel: 3, cost: 2, requires: ['a_poison'],
      effect: { dmg: 3.0, execute: 0.2, mp: 35 }, fx: { kind: 'execute', color: '#f43f5e' },
      desc: 'Eksekusi mematikan: 300% ATK, diperkuat vs musuh sekarat.' },
    { id: 'a_phantom', name: 'Phantom Step',    type: 'passive', tier: 4, reqLevel: 40, maxLevel: 3, cost: 3, requires: ['a_smoke'],
      effect: { evaPct: 0.04, spdPct: 0.05 }, fx: { kind: 'passive', color: '#22d3ee' },
      desc: 'Melangkah tanpa jejak: hindar +4% dan SPD +5% per level.' },
    { id: 'a_venomlord',name: 'Venom Lord',    type: 'passive', tier: 4, reqLevel: 42, maxLevel: 3, cost: 3, requires: ['a_flurry'],
      effect: { atkPct: 0.05, evaPct: 0.03 }, fx: { kind: 'passive', color: '#84cc16' },
      desc: 'Racun mengalir di nadi: ATK +5% dan hindar +3% per level.' },
    { id: 'a_shadow',  name: 'Shadow Master',  type: 'passive', tier: 4, reqLevel: 45, maxLevel: 1, cost: 3, requires: ['a_assass', 'a_smoke'],
      effect: { critPct: 0.2, firstStrike: true }, fx: { kind: 'passive', color: '#10b981' },
      desc: 'Satu dengan bayangan: crit +20% dan selalu bergerak duluan.' },
    { id: 'a_thousand',name: 'Thousand Cuts',  type: 'active',  tier: 4, reqLevel: 50, maxLevel: 3, cost: 3, requires: ['a_assass'],
      effect: { dmg: 0.5, hits: 6, critBonus: 0.1, mp: 42 }, fx: { kind: 'flurry', color: '#f472b6' },
      desc: 'Seribu sayatan: 6 tebasan kilat 50% ATK dengan crit +10%.' },
  ],
  archer: [
    { id: 'ar_aim',    name: 'Power Shot',     type: 'active',  tier: 1, reqLevel: 1,  maxLevel: 5, cost: 1, requires: [],
      effect: { dmg: 1.5, mp: 8 }, fx: { kind: 'arrow', color: '#fbbf24' },
      desc: 'Tarikan penuh: panah 150% ATK.' },
    { id: 'ar_eye',    name: 'Hawkeye',        type: 'passive', tier: 1, reqLevel: 1,  maxLevel: 5, cost: 1, requires: [],
      effect: { critPct: 0.02 }, fx: { kind: 'passive', color: '#fde047' },
      desc: 'Mata terlatih: crit +2% per level.' },
    { id: 'ar_pierce', name: 'Piercing Arrow', type: 'active',  tier: 2, reqLevel: 10, maxLevel: 5, cost: 1, requires: ['ar_aim'],
      effect: { dmg: 1.3, pierce: 0.5, mp: 12 }, fx: { kind: 'arrow', color: '#f59e0b' },
      desc: 'Panah berujung baja: 130% ATK yang menembus 50% pertahanan musuh.' },
    { id: 'ar_quick',  name: 'Rapid Shot',     type: 'active',  tier: 2, reqLevel: 14, maxLevel: 5, cost: 1, requires: ['ar_eye'],
      effect: { dmg: 0.55, hits: 3, mp: 16 }, fx: { kind: 'arrow', color: '#a3e635' },
      desc: 'Tiga panah beruntun, masing-masing 55% ATK.' },
    { id: 'ar_toxic',  name: 'Toxic Arrow',    type: 'active',  tier: 3, reqLevel: 18, maxLevel: 5, cost: 1, requires: ['ar_pierce'],
      effect: { dmg: 0.9, dot: 0.18, turns: 3, mp: 15 }, fx: { kind: 'poison', color: '#84cc16' },
      desc: 'Ujung panah dilumuri racun: 90% ATK + racun 18% ATK per giliran.' },
    { id: 'ar_multi',  name: 'Arrow Rain',     type: 'active',  tier: 3, reqLevel: 22, maxLevel: 5, cost: 2, requires: ['ar_quick'],
      effect: { dmg: 1.0, aoe: true, mp: 20 }, fx: { kind: 'arrowrain', color: '#facc15' },
      desc: 'Hujan panah: 100% ATK ke semua musuh.' },
    { id: 'ar_mark',   name: 'Hunter Mark',    type: 'active',  tier: 4, reqLevel: 30, maxLevel: 3, cost: 2, requires: ['ar_toxic'],
      effect: { mark: 0.25, turns: 3, mp: 18 }, fx: { kind: 'mark', color: '#f43f5e' },
      desc: 'Tanda pemburu: musuh bertanda menerima +25% damage selama 3 giliran.' },
    { id: 'ar_wind',   name: 'Windwalker',     type: 'passive', tier: 4, reqLevel: 45, maxLevel: 1, cost: 3, requires: ['ar_multi', 'ar_mark'],
      effect: { spdPct: 0.15, critPct: 0.1, firstStrike: true }, fx: { kind: 'passive', color: '#38bdf8' },
      desc: 'Satu dengan angin: SPD +15%, crit +10%, dan selalu menembak duluan.' },
    { id: 'ar_snipe',  name: 'Sniper Shot',    type: 'active',  tier: 4, reqLevel: 40, maxLevel: 3, cost: 3, requires: ['ar_mark'],
      effect: { dmg: 2.6, critBonus: 0.25, pierce: 0.3, mp: 30 }, fx: { kind: 'snipe', color: '#f87171' },
      desc: 'Bidikan jitu dari kegelapan: 260% ATK, crit +25%, menembus 30% DEF.' },
    { id: 'ar_legend', name: 'Arrow of Legend',type: 'active',  tier: 4, reqLevel: 50, maxLevel: 3, cost: 3, requires: ['ar_snipe'],
      effect: { dmg: 3.2, aoe: true, execute: 0.25, mp: 48 }, fx: { kind: 'arrowrain', color: '#fde047' },
      desc: 'Panah legendaris: 320% ATK ke semua musuh, mengerikan vs yang sekarat.' },
  ],
};
function skillById(classKey, skillId) {
  return (SKILL_TREES[classKey] || []).find(s => s.id === skillId) || null;
}

// ---------- REPUTASI (kepercayaan NPC/kerajaan/guild) ----------
const REPUTATION_TIERS = [
  { min: -Infinity, key: 'hostile',  name: 'Dimusuhi',     color: '#7F1D1D' },
  { min: -200,      key: 'disliked', name: 'Tidak Disukai',color: '#B91C1C' },
  { min: 0,         key: 'neutral',  name: 'Netral',       color: '#6B7280' },
  { min: 500,       key: 'liked',    name: 'Disukai',      color: '#16A34A' },
  { min: 1500,      key: 'honored',  name: 'Dihormati',    color: '#0EA5E9' },
  { min: 3000,      key: 'revered',  name: 'Disegani',     color: '#8B5CF6' },
  { min: 6000,      key: 'exalted',  name: 'Diagungkan',   color: '#F59E0B' },
];
function reputationTier(rep) {
  let t = REPUTATION_TIERS[0];
  for (const tier of REPUTATION_TIERS) if (rep >= tier.min) t = tier;
  return t;
}

// ---------- MONSTER (dipakai battle engine) ----------
// tier: normal / elite / boss / worldboss.
const MONSTERS = [
  { id: 'slime',     name: 'Slime',            tier: 'normal', level: 3,  hp: 90,   atk: 12, def: 6,  xp: 60,   gold: 25,  drops: ['m_slime_jelly'] },
  { id: 'goblin',    name: 'Goblin Scout',     tier: 'normal', level: 6,  hp: 150,  atk: 20, def: 10, xp: 110,  gold: 45,  drops: ['m_goblin_ear'] },
  { id: 'wolf',      name: 'Dire Wolf',        tier: 'normal', level: 10, hp: 240,  atk: 30, def: 14, xp: 180,  gold: 70,  drops: ['m_wolf_pelt'] },
  { id: 'orc',       name: 'Orc Warrior',      tier: 'elite',  level: 16, hp: 480,  atk: 44, def: 22, xp: 340,  gold: 140, drops: ['m_orc_tusk'] },
  { id: 'golem',     name: 'Stone Golem',      tier: 'elite',  level: 24, hp: 900,  atk: 55, def: 40, xp: 620,  gold: 260, drops: ['m_golem_core'] },
  { id: 'wraith',    name: 'Shadow Wraith',    tier: 'elite',  level: 32, hp: 1200, atk: 78, def: 30, xp: 940,  gold: 380, drops: ['m_wraith_ecto'] },
  { id: 'minotaur',  name: 'Minotaur Boss',    tier: 'boss',   level: 40, hp: 3200, atk: 105,def: 55, xp: 2200, gold: 900, drops: ['m_minotaur_horn'] },
  { id: 'dragon',    name: 'Ancient Dragon',   tier: 'boss',   level: 60, hp: 7000, atk: 160,def: 80, xp: 5200, gold: 2400,drops: ['m_dragon_scale'] },
  { id: 'demonlord', name: 'Demon Lord',       tier: 'worldboss', level: 80, hp: 20000, atk: 240, def: 120, xp: 14000, gold: 8000, drops: ['m_demon_heart'] },
];
function monsterById(id) { return MONSTERS.find(m => m.id === id) || null; }
function monstersForLevel(level) {
  return MONSTERS.filter(m => m.level <= level + 3);
}

// ---------- PETS (sahabat kecil yang menemani petualangan) ----------
// Rarity menentukan: base stat pasif, kekuatan skill, dan FX visual di web
// (common polos, uncommon aura lembut, rare glow + trail, epic partikel,
// legendary aura khusus + percik). Semua angka di sini SERVER-side dan
// salinannya ada di rpg.js untuk render.
const PET_LEVEL_CAP = 20;
function petXpForLevel(level) {
  if (level >= PET_LEVEL_CAP) return Infinity;
  return Math.floor(60 * Math.pow(level, 1.55) + 40 * level);
}
// Bonus pasif pet aktif = base + (level-1) * growth, dibulatkan.
function petPassiveAt(pet, level) {
  const out = {};
  for (const [k, v] of Object.entries(pet.passive || {})) {
    out[k] = Math.round(v.base + (level - 1) * v.growth);
  }
  return out;
}
// Kekuatan skill pet naik seiring level (skala 1.0 -> 1.95 di level cap).
function petSkillScale(level) { return 1 + (level - 1) * 0.05; }

const PETS = [
  // -- COMMON --
  { id: 'ember',   name: 'Ember',   species: 'Kitten Api',   element: 'fire',  rarity: 'common', role: 'dps',
    lore: 'Anak kucing lahir dari bara ritual kuno. Ekornya tak pernah padam, bahkan saat tidur di taskamu.',
    passive: { atk: { base: 4,  growth: 1.2 } },
    skill: { name: 'Percikan Bara', type: 'fire',  target: 'enemy', cd: 3, power: 1.15, effect: 'burn',  effectDesc: 'membakar musuh (damage tambahan 2 giliran)' } },
  { id: 'bolt',    name: 'Bolt',    species: 'Anjing Petir', element: 'bolt',  rarity: 'common', role: 'dps',
    lore: 'Anak anjing berbalut listrik statis. Menggigil kalau diajak main, haruskah kamu memeluknya?',
    passive: { spd: { base: 4,  growth: 1.0 } },
    skill: { name: 'Kilat Tack',  type: 'bolt',  target: 'enemy', cd: 3, power: 1.2,  effect: 'stun10', effectDesc: '10% peluang membuat musuh bingung 1 giliran' } },
  { id: 'leafy',   name: 'Leafy',  species: 'Rubah Daun',   element: 'nature',rarity: 'common', role: 'support',
    lore: 'Rubah kecil hutan yang tanduk pucuknya tumbuh makin rimbun setiap musim semi.',
    passive: { def: { base: 3,  growth: 0.9 } },
    skill: { name: 'Peloah Daun', type: 'nature',target: 'ally',  cd: 4, power: 0.9,  effect: 'hot',   effectDesc: 'menyembuhkanmu sedikit tiap giliran (3 giliran)' } },
  { id: 'pebble',  name: 'Pebble', species: 'Kura-kura Batu',element: 'earth',rarity: 'common', role: 'tank',
    lore: 'Kura-kura dengan cangkang berlumut. Lambat berjalan, tapi selalu tiba di tujuan.',
    passive: { def: { base: 6,  growth: 1.4 }, hp: { base: 20, growth: 6 } },
    skill: { name: 'Cangkang Besi', type: 'earth',target: 'ally', cd: 4, power: 1.6, effect: 'shield', effectDesc: 'perisai yang menyerap damage (sekuat pertahanan pet)' } },
  { id: 'aqua',    name: 'Aqua',   species: 'Slime Air',    element: 'water', rarity: 'common', role: 'dps',
    lore: 'Gumpalan air yang ikut pulang setelah hujan badai. Gemas, tapi jangan dipeluk terlalu keras.',
    passive: { hp: { base: 15, growth: 5 }, mp: { base: 8,  growth: 2.5 } },
    skill: { name: 'Percikan',    type: 'water', target: 'enemy', cd: 3, power: 1.1,  effect: 'slow',  effectDesc: 'melemahkan serangan musuh (-15% atk)' } },
  // -- UNCOMMON --
  { id: 'zephyr',  name: 'Zephyr', species: 'Burung Hantu Angin', element: 'wind', rarity: 'uncommon', role: 'support',
    lore: 'Burung hantu kecil penjaga menara angin. Sayapnya bersuara seperti peluit kalau terbang malam.',
    passive: { spd: { base: 6,  growth: 1.3 }, mp: { base: 10, growth: 3 } },
    skill: { name: 'Hembusan Angin', type: 'wind', target: 'enemies', cd: 4, power: 0.7, effect: 'atkdown', effectDesc: 'menyerang semua musuh dan menurunkan attack mereka' } },
  { id: 'frost',   name: 'Frost',  species: 'Rubah Es',     element: 'ice',   rarity: 'uncommon', role: 'dps',
    lore: 'Rubah pucat dari puncak bersalju. Jejak kakinya membeku menjadi bunga es.',
    passive: { atk: { base: 6,  growth: 1.5 } },
    skill: { name: 'Gigitan Beku', type: 'ice',  target: 'enemy', cd: 4, power: 1.3,  effect: 'freeze', effectDesc: 'membekukan musuh 1 giliran' } },
  { id: 'toxic',   name: 'Toxic',  species: 'Katak Beracun',element: 'poison',rarity: 'uncommon', role: 'dps',
    lore: 'Katak kecil berwarna mencolok dari rawa terlarang. Warnanya adalah peringatan, katanya.',
    passive: { atk: { base: 5,  growth: 1.4 }, hp: { base: 10, growth: 4 } },
    skill: { name: 'Ludah Beracun', type: 'poison', target: 'enemy', cd: 3, power: 1.0, effect: 'poison', effectDesc: 'meracuni musuh (damage tiap giliran, 3 giliran)' } },
  // -- RARE --
  { id: 'shadow',  name: 'Shadow', species: 'Kelelawar Bayang', element: 'dark', rarity: 'rare', role: 'dps',
    lore: 'Kelelawar dari celah bayangan gua tua. Mata ungunya berpendar di kegelapan total.',
    passive: { atk: { base: 8,  growth: 1.8 }, crit: { base: 3, growth: 0.8 } },
    skill: { name: 'Cengkeraman Bayang', type: 'dark', target: 'enemy', cd: 4, power: 1.45, effect: 'lifesteal', effectDesc: 'menyerap 50% damage sebagai HP untukmu' } },
  { id: 'terra',   name: 'Terra',  species: 'Golem Kecil',  element: 'earth', rarity: 'rare', role: 'tank',
    lore: 'Pecahan golem yang belajar berjalan sendiri. Matanya menyala hijau kalau senang.',
    passive: { def: { base: 10, growth: 2.2 }, hp: { base: 40, growth: 9 } },
    skill: { name: 'Gempa Kecil', type: 'earth', target: 'enemies', cd: 5, power: 0.95, effect: 'defup', effectDesc: 'mengguncang semua musuh dan menguatkan pertahananmu' } },
  // -- EPIC --
  { id: 'lumen',   name: 'Lumen',  species: 'Rubah Cahaya', element: 'light', rarity: 'epic', role: 'hybrid',
    lore: 'Rubah keemasan yang muncul di kuil terbengkalai. Konon membawa keberuntungan bagi yang jujur.',
    passive: { atk: { base: 9,  growth: 2.0 }, hp: { base: 25, growth: 7 }, mp: { base: 15, growth: 4 } },
    skill: { name: 'Sinar Keemasan', type: 'light', target: 'enemy', cd: 4, power: 1.5, effect: 'radiant', effectDesc: 'melukai musuh dan menyembuhkanmu sebagian' } },
  // -- LEGENDARY --
  { id: 'nyx',     name: 'Nyx',    species: 'Anakan Naga Bayang', element: 'darkfire', rarity: 'legendary', role: 'dps',
    lore: 'Anakan naga dari sarang gunung berapi yang mati. Napasnya masih menyimpan bara kegelapan.',
    passive: { atk: { base: 14, growth: 2.6 }, crit: { base: 5, growth: 1.1 } },
    skill: { name: 'Napas Bayang', type: 'darkfire', target: 'enemies', cd: 5, power: 1.7, effect: 'burn', effectDesc: 'napas gelap yang membakar semua musuh' } },
  { id: 'celeste', name: 'Celeste', species: 'Unicorn Kecil', element: 'holy', rarity: 'legendary', role: 'support',
    lore: 'Unicorn muda yang turun mengikuti bintang jatuh. Tanduknya berpendar lembut menenangkan hati.',
    passive: { def: { base: 10, growth: 2.0 }, hp: { base: 50, growth: 11 }, mp: { base: 20, growth: 5 } },
    skill: { name: 'Berkat Cahaya', type: 'holy', target: 'ally', cd: 6, power: 2.2, effect: 'blessing', effectDesc: 'penyembuhan besar + membersihkan racun dan bakar' } },
  // -- MYTHIC (hanya dari gacha, peluang sangat kecil) --
  { id: 'solara',   name: 'Solara',   species: 'Anakan Phoenix Matahari', element: 'solar', rarity: 'mythic', role: 'dps',
    lore: 'Menetas dari inti matahari yang jatuh. Bulu baranya menyala seakan fajar tersembunyi di tubuh kecilnya.',
    passive: { atk: { base: 18, growth: 3.2 }, crit: { base: 6, growth: 1.3 }, spd: { base: 6, growth: 1.2 } },
    skill: { name: 'Nyala Fajar', type: 'solar', target: 'enemies', cd: 5, power: 1.9, effect: 'burn', effectDesc: 'sinar fajar membakar semua musuh (2 giliran)' } },
  { id: 'nocturne', name: 'Nocturne', species: 'Anakan Panther Void', element: 'void', rarity: 'mythic', role: 'dps',
    lore: 'Bayangan berbentuk anak panther, lahir dari retakan antar-bintang. Bulunya berkelip seperti langit malam.',
    passive: { atk: { base: 16, growth: 3.0 }, crit: { base: 8, growth: 1.5 }, eva: { base: 4, growth: 1.0 } },
    skill: { name: 'Cakar Bintang Jatuh', type: 'void', target: 'enemy', cd: 4, power: 2.1, effect: 'voidlash', effectDesc: 'tebasan void dengan crit +25% dan menyerap HP' } },
];
const PET_BY_ID = Object.fromEntries(PETS.map(p => [p.id, p]));
// Pet pool per rarity untuk roll gacha (server).
const PET_BY_RARITY = {
  common:    ['ember', 'bolt', 'leafy', 'pebble', 'aqua'],
  uncommon:  ['zephyr', 'frost', 'toxic'],
  rare:      ['shadow', 'terra'],
  epic:      ['lumen'],
  legendary: ['nyx', 'celeste'],
  mythic:    ['solara', 'nocturne'],
};

// ---------- EVOLUSI PET ----------
// Stage 1 = bentuk anak-anak (default). Stage 2 = bentuk evolusi: tubuh, sprite,
// dan skill berubah; stat pasif dikali multiplier. Syarat: level 10 + pecahan
// (shard) sesuai rarity + biaya gold. Shard didapat dari duplikat gacha & peti.
const PET_EVOLUTION = {
  ember:   { name: 'Pyrelisk',    species: 'Kucing Api Penjaga',   reqLevel: 10, shards: 20,  gold: 1500,  mult: 1.8,
             skill: { name: 'Bara Sang Raja', type: 'fire', target: 'enemies', cd: 4, power: 1.8, effect: 'burn', effectDesc: 'surai menyala membakar semua musuh (2 giliran)' } },
  bolt:    { name: 'Stormfang',   species: 'Anjing Badai',         reqLevel: 10, shards: 20,  gold: 1500,  mult: 1.8,
             skill: { name: 'Taring Guntur', type: 'bolt', target: 'enemy', cd: 3, power: 1.9, effect: 'stun25', effectDesc: '25% peluang melumpuhkan musuh 1 giliran' } },
  leafy:   { name: 'Verdantis',   species: 'Rubah Roh Bunga',      reqLevel: 10, shards: 20,  gold: 1500,  mult: 1.8,
             skill: { name: 'Panggilan Musim Semi', type: 'nature', target: 'ally', cd: 3, power: 1.6, effect: 'hot', effectDesc: 'menyembuhkan tiap giliran (3 giliran)' } },
  pebble:  { name: 'Bastion',     species: 'Kura-kura Purba',      reqLevel: 10, shards: 20,  gold: 1500,  mult: 1.8,
             skill: { name: 'Tembok Kuno', type: 'earth', target: 'ally', cd: 3, power: 2.2, effect: 'shield', effectDesc: 'perisai besar dari inti kristal purba' } },
  aqua:    { name: 'Tidecaller',  species: 'Roh Air Arus',          reqLevel: 10, shards: 20,  gold: 1500,  mult: 1.8,
             skill: { name: 'Ombak Besar', type: 'water', target: 'enemies', cd: 4, power: 1.4, effect: 'slow', effectDesc: 'gelombang melemahkan semua musuh (-20% atk)' } },
  zephyr:  { name: 'Skysovereign',species: 'Burung Hantu Angkasa', reqLevel: 10, shards: 40,  gold: 3500,  mult: 1.8,
             skill: { name: 'Badai Sayap', type: 'wind', target: 'enemies', cd: 4, power: 1.2, effect: 'atkdown', effectDesc: 'putaran sayap menekan semua musuh' } },
  frost:   { name: 'Glacira',     species: 'Rubah Kristal Es',     reqLevel: 10, shards: 40,  gold: 3500,  mult: 1.8,
             skill: { name: 'Taring Gletser', type: 'ice', target: 'enemy', cd: 4, power: 1.8, effect: 'freeze', effectDesc: 'membekukan musuh 1 giliran + dingin menusuk' } },
  toxic:   { name: 'Venomarch',   species: 'Katak Raja Beracun',   reqLevel: 10, shards: 40,  gold: 3500,  mult: 1.8,
             skill: { name: 'Hujan Racun', type: 'poison', target: 'enemies', cd: 4, power: 1.3, effect: 'poison', effectDesc: 'meracuni semua musuh (3 giliran)' } },
  shadow:  { name: 'Duskmaw',     species: 'Kelelawar Jurang',     reqLevel: 10, shards: 80,  gold: 7000,  mult: 1.85,
             skill: { name: 'Sansai Bayang', type: 'dark', target: 'enemy', cd: 3, power: 2.0, effect: 'lifesteal', effectDesc: 'menyerap 60% damage sebagai HP' } },
  terra:   { name: 'Monolith',    species: 'Golem Kuno',           reqLevel: 10, shards: 80,  gold: 7000,  mult: 1.85,
             skill: { name: 'Gempa Purba', type: 'earth', target: 'enemies', cd: 4, power: 1.5, effect: 'defup', effectDesc: 'gempa ke semua musuh + pertahanan tim naik' } },
  lumen:   { name: 'Radiance',    species: 'Rubah Sembilan Cahaya',reqLevel: 10, shards: 160, gold: 14000, mult: 1.9,
             skill: { name: 'Fajar Sembilan Ekor', type: 'light', target: 'enemy', cd: 3, power: 2.2, effect: 'radiant', effectDesc: 'tebasan cahaya: damage besar + heal diri' } },
  nyx:     { name: 'Umbraxis',   species: 'Naga Bayang Dewasa',    reqLevel: 10, shards: 240, gold: 22000, mult: 1.95,
             skill: { name: 'Napas Kehampaan', type: 'darkfire', target: 'enemies', cd: 4, power: 2.3, effect: 'burn', effectDesc: 'napas gelap membakar semua musuh (3 giliran)' } },
  celeste: { name: 'Seraphion',  species: 'Unicorn Bersayap',      reqLevel: 10, shards: 240, gold: 22000, mult: 1.95,
             skill: { name: 'Cahaya Serafim', type: 'holy', target: 'ally', cd: 4, power: 3.0, effect: 'blessing', effectDesc: 'penyembuhan masif + bersihkan semua debuff' } },
  solara:  { name: 'Solaris',    species: 'Phoenix Matahari',     reqLevel: 10, shards: 400, gold: 40000, mult: 2.0,
             skill: { name: 'Supernova', type: 'solar', target: 'enemies', cd: 4, power: 2.6, effect: 'burn', effectDesc: 'ledakan matahari ke semua musuh (3 giliran)' } },
  nocturne:{ name: 'Eclipseon',  species: 'Panther Gerhana',      reqLevel: 10, shards: 400, gold: 40000, mult: 2.0,
             skill: { name: 'Gerhana Total', type: 'void', target: 'enemy', cd: 3, power: 3.2, effect: 'voidlash', effectDesc: 'tebasan gerhana: crit +35% & serap HP' } },
};

// ---------- GACHA PET (satu-satunya cara mendapat pet) ----------
// Mata uang: Permata (gems) — didapat dari dungeon, tower, world boss,
// achievement, tukar seruling lama, dan beli dengan gold (kurs jelek).
/* ---------- v11: SKILL KEDUA per pet + ULTIMATE evolusi terakhir (mirror klien) ---------- */
const PET_SKILL2 = {
  ember:   { name: 'Cakar Membara',     target: 'enemy',   cd: 3, power: 1.35, effect: 'burn',    effectDesc: 'tiga goresan api yang meninggalkan bara' },
  bolt:    { name: 'Lolongan Voltase',  target: 'enemies', cd: 4, power: 0.8,  effect: 'atkdown', effectDesc: 'ultrasonic statis membuat semua musuh goyah' },
  leafy:   { name: 'Tanduk Musim Semi', target: 'ally',    cd: 4, power: 1.2,  effect: 'shield',  effectDesc: 'daun hidup membentuk pelindung rimbun' },
  pebble:  { name: 'Gulingan Batu',     target: 'enemy',   cd: 3, power: 1.4,  effect: 'stun10',  effectDesc: 'mengguling menabrak kaki musuh' },
  aqua:    { name: 'Genangan Licin',    target: 'enemies', cd: 4, power: 0.9,  effect: 'slow',    effectDesc: 'air menjalar membuat musuh tergelincir' },
  zephyr:  { name: 'Terjaga Malam',     target: 'ally',    cd: 4, power: 1.0,  effect: 'hot',     effectDesc: 'pantauan si burung hantu menenangkanmu (3 giliran)' },
  frost:   { name: 'Napas Salju',       target: 'enemies', cd: 4, power: 0.9,  effect: 'slow',    effectDesc: 'kabut dingin memperlambat barisan musuh' },
  toxic:   { name: 'Kabut Racun',       target: 'enemies', cd: 4, power: 0.85, effect: 'poison',  effectDesc: 'kantung kulit menyemprot kabut beracun' },
  shadow:  { name: 'Pekat Menyelubungi',target: 'enemies', cd: 4, power: 0.8,  effect: 'atkdown', effectDesc: 'sayap malam meredupkan semangat musuh' },
  terra:   { name: 'Kulit Granit',      target: 'ally',    cd: 4, power: 1.2,  effect: 'shield',  effectDesc: 'lapisan batu hidup menutupi tubuhmu' },
  lumen:   { name: 'Berkat Cahaya',     target: 'ally',    cd: 4, power: 1.1,  effect: 'hot',     effectDesc: 'kilau ekor menyembuhkan luka perlahan' },
  nyx:     { name: 'Sayap Kegelapan',   target: 'enemies', cd: 4, power: 1.0,  effect: 'atkdown', effectDesc: 'bayangan sayap menekan semua musuh' },
  celeste: { name: 'Air Mancur Cahaya', target: 'ally',    cd: 4, power: 1.4,  effect: 'blessing',effectDesc: 'terusan cahaya suci membasuh debuff' },
  solara:  { name: 'Sayat Surya',       target: 'enemies', cd: 4, power: 1.2,  effect: 'burn',    effectDesc: 'hujan bulu matahari membakar area' },
  nocturne:{ name: 'Bayang Menindih',   target: 'enemies', cd: 4, power: 1.0,  effect: 'atkdown', effectDesc: 'bayangan panther menghimpit lawan' },
};
const PET_ULTIMATE = {
  ember:   { name: 'MAHKOTA BARA RAJA',   target: 'enemies', power: 2.6, effect: 'burn',     effectDesc: 'surai raja api meledak membakar seluruh medan (3 giliran)' },
  bolt:    { name: 'TARING BADAI',        target: 'enemy',   power: 3.0, effect: 'stun25',   effectDesc: 'petir bertubi-tubi dari taring badai' },
  leafy:   { name: 'TAMAN ABADI',         target: 'ally',    power: 2.6, effect: 'blessing', effectDesc: 'musim semi dipanggil: heal besar + regen' },
  pebble:  { name: 'BENTENG PURBA',       target: 'ally',    power: 3.2, effect: 'shield',   effectDesc: 'dinding kristal purba tak tertembus' },
  aqua:    { name: 'GELOMBANG PASANG',    target: 'enemies', power: 2.2, effect: 'slow',     effectDesc: 'ombak besar menenggelamkan semua musuh' },
  zephyr:  { name: 'MATA BADAI',          target: 'enemies', power: 2.0, effect: 'atkdown',  effectDesc: 'pusaran angin antah-berantah menghancurkan formasi' },
  frost:   { name: 'NOL ABSOLUT',         target: 'enemies', power: 2.4, effect: 'freeze',   effectDesc: 'dingin absolut membekukan waktu musuh' },
  toxic:   { name: 'RAWA MAUT',           target: 'enemies', power: 2.3, effect: 'poison',   effectDesc: 'murka raja katak meracuni segalanya (3 giliran)' },
  shadow:  { name: 'LAYANG JURANG',       target: 'enemy',   power: 3.0, effect: 'lifesteal',effectDesc: 'menyerap nyawa langsung dari kegelapan' },
  terra:   { name: 'GEMPA PURBA',         target: 'enemies', power: 2.2, effect: 'stun25',   effectDesc: 'monolit bangkit dan mengguncang bumi' },
  lumen:   { name: 'SEMBILAN FAJAR',      target: 'enemies', power: 2.8, effect: 'radiant',  effectDesc: 'sembilan ekor menyala menjadi fajar yang menampar' },
  nyx:     { name: 'GERHANA NAPAS',       target: 'enemies', power: 3.0, effect: 'burn',     effectDesc: 'napas kehampaan memadamkan semua cahaya' },
  celeste: { name: 'SERAFIM TURUN',       target: 'ally',    power: 3.4, effect: 'blessing', effectDesc: 'cahaya surga menyembuhkan dan menyucikan' },
  solara:  { name: 'SUPERNOVA MATAHARI',  target: 'enemies', power: 3.2, effect: 'burn',     effectDesc: 'reinkarnasi matahari meledak di medan perang' },
  nocturne:{ name: 'GERHANA TOTAL',       target: 'enemy',   power: 3.6, effect: 'voidlash', effectDesc: 'satu tebasan menelan cahaya dunia' },
};
(function () {
  const PETS_BY_ID = {}; PETS.forEach((p) => { PETS_BY_ID[p.id] = p; });
  Object.entries(PET_SKILL2).forEach(([id, s2]) => { if (PETS_BY_ID[id]) PETS_BY_ID[id].skills = [PETS_BY_ID[id].skill, s2].filter(Boolean); });
  Object.entries(PET_ULTIMATE).forEach(([id, ult]) => { if (PET_EVOLUTION[id]) PET_EVOLUTION[id].ultimate = ult; });
})();

const GACHA = {
  cost: 100,               // permata per tarikan
  cost10: 900,             // 10 tarikan + 1 bonus
  rates: { common: 0.4200, uncommon: 0.2700, rare: 0.1700, epic: 0.0850, legendary: 0.0470, mythic: 0.0080 },
  pityEpicAt: 20,          // dijamin epic+ jika 20 tarikan tanpa epic+
  pityLegendaryAt: 60,     // dijamin legendary+ jika 60 tarikan tanpa legendary+
  pityMythicAt: 150,       // dijamin mythic jika 150 tarikan tanpa mythic
  shardFromDupe: { common: 6, uncommon: 12, rare: 25, epic: 50, legendary: 100, mythic: 200 },
  goldToGems: { rate: 1000, gems: 60 }, // 1000 gold -> 60 permata
};

// ---------- WORLD BOSS MINGGUAN ----------
// Satu boss per minggu (rotasi), HP bersama seluruh pemain, reward kontribusi.
const WORLD_BOSSES = [
  { id: 'demonlord', name: 'Demon Lord Abaddon',  hp: 3000000, atk: 240, def: 120, level: 80, sprite: 'demonlord', element: 'dark' },
  { id: 'yeti',      name: 'Raja Yeti Glacial',   hp: 2600000, atk: 200, def: 140, level: 75, sprite: 'yeti', element: 'ice' },
  { id: 'dragon',    name: 'Ancient Dragon Vharox', hp: 3400000, atk: 260, def: 110, level: 85, sprite: 'dragon', element: 'fire' },
];
function worldBossForWeek(weekKey) {
  let h = 0;
  for (let i = 0; i < weekKey.length; i++) h = (h * 31 + weekKey.charCodeAt(i)) >>> 0;
  return WORLD_BOSSES[h % WORLD_BOSSES.length];
}

// ---------- ACHIEVEMENT ----------
// Kondisi bertipe 'counter' (field di rpg_characters >= target) atau 'special'
// (dicek rpgServer.js dengan data tambahan: inventory, skill, teman, dsb.).
// reward: { gold, xp, rep, title } — title opsional, terbuka untuk profil.
// icon: nama ikon vektor di web (lihat drawIcon di rpg.js).
const ACHIEVEMENTS = [
  // -- Pertempuran --
  { id: 'first_blood',   name: 'Darah Pertama',       cat: 'battle',  icon: 'sword',   desc: 'Kalahkan monster pertamamu.',              cond: { type: 'counter', stat: 'monstersKilled', target: 1 },    reward: { gold: 50, xp: 20 } },
  { id: 'slayer_50',     name: 'Pembasmi',            cat: 'battle',  icon: 'sword',   desc: 'Kalahkan 50 monster.',                    cond: { type: 'counter', stat: 'monstersKilled', target: 50 },   reward: { gold: 300, xp: 150, title: 'Pembasmi' } },
  { id: 'slayer_250',    name: 'Pemburu Kejam',       cat: 'battle',  icon: 'sword',   desc: 'Kalahkan 250 monster.',                   cond: { type: 'counter', stat: 'monstersKilled', target: 250 },  reward: { gold: 1200, xp: 600, title: 'Pemburu Kejam' } },
  { id: 'slayer_1000',   name: 'Mimpi Buruk Monster', cat: 'battle',  icon: 'skull',   desc: 'Kalahkan 1.000 monster.',                 cond: { type: 'counter', stat: 'monstersKilled', target: 1000 }, reward: { gold: 6000, xp: 3000, title: 'Mimpi Buruk' } },
  { id: 'win_1',         name: 'Kemenangan Pertama',  cat: 'battle',  icon: 'trophy',  desc: 'Menangkan battle pertamamu.',             cond: { type: 'counter', stat: 'wins', target: 1 },    reward: { gold: 40, xp: 20 } },
  { id: 'win_100',       name: 'Sang Juara',          cat: 'battle',  icon: 'trophy',  desc: 'Menangkan 100 battle.',                   cond: { type: 'counter', stat: 'wins', target: 100 },  reward: { gold: 1500, xp: 800, title: 'Sang Juara' } },
  { id: 'win_500',       name: 'Tak Terkalahkan',     cat: 'battle',  icon: 'trophy',  desc: 'Menangkan 500 battle.',                   cond: { type: 'counter', stat: 'wins', target: 500 },  reward: { gold: 8000, xp: 4000, title: 'Tak Terkalahkan' } },
  { id: 'boss_1',        name: 'Pembunuh Boss',       cat: 'battle',  icon: 'skull',   desc: 'Kalahkan boss pertamamu.',                cond: { type: 'counter', stat: 'bossesDefeated', target: 1 },  reward: { gold: 400, xp: 250 } },
  { id: 'boss_10',       name: 'Penakluk Raksasa',    cat: 'battle',  icon: 'skull',   desc: 'Kalahkan 10 boss.',                       cond: { type: 'counter', stat: 'bossesDefeated', target: 10 }, reward: { gold: 2500, xp: 1500, title: 'Penakluk Raksasa' } },

  // -- Dungeon --
  { id: 'floor_10',      name: 'Penjelajah Muda',     cat: 'dungeon', icon: 'compass', desc: 'Selesaikan 10 lantai dungeon.',           cond: { type: 'counter', stat: 'floorsCleared', target: 10 },  reward: { gold: 250, xp: 150 } },
  { id: 'floor_100',     name: 'Kaki Tangan Kuat',    cat: 'dungeon', icon: 'compass', desc: 'Selesaikan 100 lantai dungeon.',          cond: { type: 'counter', stat: 'floorsCleared', target: 100 }, reward: { gold: 2000, xp: 1200, title: 'Penjelajah Sejati' } },
  { id: 'dungeon_1',     name: 'Rumah Baru',          cat: 'dungeon', icon: 'door',    desc: 'Taklukkan satu dungeon penuh.',           cond: { type: 'counter', stat: 'dungeonsCleared', target: 1 },  reward: { gold: 500, xp: 300 } },
  { id: 'dungeon_10',    name: 'Kunci Segala Pintu',  cat: 'dungeon', icon: 'door',    desc: 'Taklukkan 10 dungeon penuh.',             cond: { type: 'counter', stat: 'dungeonsCleared', target: 10 }, reward: { gold: 3000, xp: 2000, title: 'Pembuka Jalan' } },
  { id: 'chest_25',      name: 'Tangan Panas',        cat: 'dungeon', icon: 'chest',   desc: 'Buka 25 peti harta.',                     cond: { type: 'counter', stat: 'chestsOpened', target: 25 },   reward: { gold: 350, xp: 150 } },
  { id: 'chest_150',     name: 'Pemburu Harta',       cat: 'dungeon', icon: 'chest',   desc: 'Buka 150 peti harta.',                    cond: { type: 'counter', stat: 'chestsOpened', target: 150 },  reward: { gold: 2500, xp: 1200, title: 'Pemburu Harta' } },
  { id: 'mimic_1',       name: 'Ada Apa dengan Peti Itu', cat: 'dungeon', icon: 'chest', desc: 'Kalahkan mimic penyamar pertamamu.',  cond: { type: 'counter', stat: 'mimicsKilled', target: 1 },   reward: { gold: 200, xp: 150 } },
  { id: 'mimic_15',      name: 'Pembongkar Mimik',    cat: 'dungeon', icon: 'chest',   desc: 'Kalahkan 15 mimic.',                      cond: { type: 'counter', stat: 'mimicsKilled', target: 15 },  reward: { gold: 1800, xp: 1000, title: 'Pembongkar Mimik' } },

  // -- Kerajinan --
  { id: 'craft_1',       name: 'Pukulan Pertama',     cat: 'craft',   icon: 'hammer',  desc: 'Tempa item pertamamu di pandai besi.',    cond: { type: 'counter', stat: 'itemsCrafted', target: 1 },   reward: { gold: 60, xp: 30 } },
  { id: 'craft_25',      name: 'Ahli Tempa',          cat: 'craft',   icon: 'hammer',  desc: 'Tempa 25 item.',                          cond: { type: 'counter', stat: 'itemsCrafted', target: 25 },  reward: { gold: 1500, xp: 800, title: 'Ahli Tempa' } },
  { id: 'craft_100',     name: 'Master Pandai Besi',  cat: 'craft',   icon: 'hammer',  desc: 'Tempa 100 item.',                         cond: { type: 'counter', stat: 'itemsCrafted', target: 100 }, reward: { gold: 6000, xp: 3500, title: 'Master Tempa' } },

  // -- Sosial --
  { id: 'friend_1',      name: 'Tak Sendirian',       cat: 'social',  icon: 'friends', desc: 'Punya satu teman.',                       cond: { type: 'special', key: 'friends' , target: 1 },        reward: { gold: 100, xp: 50 } },
  { id: 'friend_10',     name: 'Populer',             cat: 'social',  icon: 'friends', desc: 'Punya 10 teman.',                         cond: { type: 'special', key: 'friends', target: 10 },        reward: { gold: 1200, xp: 600, title: 'Populer' } },
  { id: 'chat_50',       name: 'Cerewet',             cat: 'social',  icon: 'chat',    desc: 'Kirim 50 pesan chat.',                    cond: { type: 'counter', stat: 'chatSent', target: 50 },     reward: { gold: 150, xp: 80 } },
  { id: 'party_1',       name: 'Pembaris',            cat: 'social',  icon: 'party',   desc: 'Main bareng di party raid.',               cond: { type: 'counter', stat: 'partyRaids', target: 1 },    reward: { gold: 300, xp: 200 } },
  { id: 'party_25',      name: 'Satu Tim',            cat: 'social',  icon: 'party',   desc: 'Main 25 party raid.',                     cond: { type: 'counter', stat: 'partyRaids', target: 25 },   reward: { gold: 2500, xp: 1500, title: 'Satu Tim' } },

  // -- Koleksi --
  { id: 'pet_1',        name: 'Sahabat Baru',        cat: 'pet',      icon: 'paw',     desc: 'Dapatkan pet pertamamu.',                  cond: { type: 'special', key: 'petsOwned', target: 1 },        reward: { gold: 150, xp: 100 } },
  { id: 'pet_3',        name: 'Rumah Penuh',         cat: 'pet',      icon: 'paw',     desc: 'Kumpulkan 3 pet berbeda.',                 cond: { type: 'special', key: 'petsOwned', target: 3 },        reward: { gold: 800, xp: 400 } },
  { id: 'pet_6',        name: 'Penjinak Handal',     cat: 'pet',      icon: 'paw',     desc: 'Kumpulkan 6 pet berbeda.',                 cond: { type: 'special', key: 'petsOwned', target: 6 },        reward: { gold: 2500, xp: 1200, title: 'Penjinak' } },
  { id: 'pet_all',      name: 'Taman Miniatur',      cat: 'pet',      icon: 'paw',     desc: 'Kumpulkan semua jenis pet (15).',          cond: { type: 'special', key: 'petsOwned', target: 15 },       reward: { gold: 15000, xp: 6000, title: 'Sahabat Segala Makhluk' } },
  { id: 'pet_lvl10',    name: 'Ikatan Kuat',         cat: 'pet',      icon: 'paw',     desc: 'Naikkan satu pet ke level 10.',            cond: { type: 'special', key: 'petMaxLevel', target: 10 },      reward: { gold: 1200, xp: 600 } },
  { id: 'pet_lvl20',    name: 'Duo Tak Terpisahkan', cat: 'pet',      icon: 'paw',     desc: 'Naikkan satu pet ke level maksimal (20).', cond: { type: 'special', key: 'petMaxLevel', target: 20 },      reward: { gold: 8000, xp: 4000, title: 'Duo Sejati' } },
  { id: 'pet_evolve_1', name: 'Metamorfosis',       cat: 'pet',      icon: 'paw',     desc: 'Evolusikan satu pet ke bentuk sejatinya.',   cond: { type: 'counter', stat: 'petsEvolved', target: 1 },     reward: { gold: 1000, xp: 500, gems: 50 } },
  { id: 'pet_evolve_5', name: 'Pelatih Sejati',     cat: 'pet',      icon: 'paw',     desc: 'Evolusikan 5 pet berbeda.',                cond: { type: 'counter', stat: 'petsEvolved', target: 5 },     reward: { gold: 6000, xp: 3000, title: 'Pelatih Sejati' } },
  { id: 'pet_mythic',   name: 'Legenda Terpilih',   cat: 'pet',      icon: 'star',    desc: 'Dapatkan satu pet MYTHIC dari gacha.',      cond: { type: 'counter', stat: 'mythicPetsOwned', target: 1 },  reward: { gold: 20000, xp: 10000, title: 'Yang Terpilih Cahaya' } },
  { id: 'gacha_10',     name: 'Pemutar Pertama',    cat: 'pet',      icon: 'star',    desc: 'Tarik gacha 10 kali.',                     cond: { type: 'counter', stat: 'gachaPulled', target: 10 },    reward: { gold: 500, xp: 200 } },
  { id: 'gacha_100',    name: 'Salah Saudara',      cat: 'pet',      icon: 'star',    desc: 'Tarik gacha 100 kali.',                    cond: { type: 'counter', stat: 'gachaPulled', target: 100 },   reward: { gold: 5000, xp: 2500, title: 'Tangan Keberuntungan' } },
  { id: 'rare_item',     name: 'Sedikit Langka',      cat: 'collect', icon: 'star',    desc: 'Punya item ber-rarity Langka.',           cond: { type: 'special', key: 'tierItem', target: 'rare' },    reward: { gold: 200, xp: 100 } },
  { id: 'epic_item',     name: 'Kebanggaan Tas',     cat: 'collect', icon: 'star',    desc: 'Punya item ber-rarity Epik.',             cond: { type: 'special', key: 'tierItem', target: 'epic' },    reward: { gold: 800, xp: 400 } },
  { id: 'mythic_item',   name: 'Barang Mistik',      cat: 'collect', icon: 'star',    desc: 'Punya item ber-rarity Mistik.',           cond: { type: 'special', key: 'tierItem', target: 'mythic' },  reward: { gold: 3000, xp: 1500, title: 'Kolektor Mistik' } },
  { id: 'mat_10',        name: 'Penimbun Bahan',      cat: 'collect', icon: 'bag',     desc: 'Punya 10 jenis material sekaligus.',      cond: { type: 'special', key: 'matKinds', target: 10 },        reward: { gold: 400, xp: 200 } },
  { id: 'rich_10k',      name: 'Kantong Tebal',       cat: 'collect', icon: 'coin',    desc: 'Punya 10.000 KZC sekaligus.',             cond: { type: 'special', key: 'gold', target: 10000 },        reward: { gold: 500, xp: 200 } },
  { id: 'rich_100k',     name: 'Kaya Raya',           cat: 'collect', icon: 'coin',    desc: 'Punya 100.000 KZC sekaligus.',            cond: { type: 'special', key: 'gold', target: 100000 },      reward: { gold: 5000, xp: 2000, title: 'Kaya Raya' } },
  { id: 'potion_25',     name: 'Perbekalan Perang',   cat: 'collect', icon: 'potion',  desc: 'Minum 25 ramuan.',                        cond: { type: 'counter', stat: 'potionsUsed', target: 25 },  reward: { gold: 200, xp: 100 } },

  // -- Progresi --
  { id: 'level_10',      name: 'Bukan Pemula Lagi',   cat: 'progress',icon: 'star',    desc: 'Capai level 10.',                         cond: { type: 'counter', stat: 'level', target: 10 },       reward: { gold: 200, xp: 100 } },
  { id: 'level_25',      name: 'Nama Mulai Dikenal',  cat: 'progress',icon: 'star',    desc: 'Capai level 25.',                         cond: { type: 'counter', stat: 'level', target: 25 },       reward: { gold: 1000, xp: 500 } },
  { id: 'level_50',      name: 'Veteran',             cat: 'progress',icon: 'star',    desc: 'Capai level 50.',                         cond: { type: 'counter', stat: 'level', target: 50 },       reward: { gold: 4000, xp: 2000, title: 'Veteran' } },
  { id: 'level_100',     name: 'Puncak Kekuatan',     cat: 'progress',icon: 'crown',   desc: 'Capai level 100.',                        cond: { type: 'counter', stat: 'level', target: 100 },      reward: { gold: 20000, xp: 0, title: 'Sang Legenda' } },
  { id: 'quest_1',       name: 'Tangan Kurang Gatal', cat: 'progress',icon: 'scroll',  desc: 'Selesaikan quest pertamamu.',             cond: { type: 'counter', stat: 'questsCompleted', target: 1 }, reward: { gold: 60, xp: 40 } },
  { id: 'quest_25',      name: 'Andalan Guild',       cat: 'progress',icon: 'scroll',  desc: 'Selesaikan 25 quest.',                    cond: { type: 'counter', stat: 'questsCompleted', target: 25 }, reward: { gold: 900, xp: 500 } },
  { id: 'quest_100',     name: 'Wajah Papan Quest',   cat: 'progress',icon: 'scroll',  desc: 'Selesaikan 100 quest.',                   cond: { type: 'counter', stat: 'questsCompleted', target: 100 }, reward: { gold: 3500, xp: 1800, title: 'Andalan Guild' } },
  { id: 'skill_max_1',   name: 'Fokus Satu Hal',      cat: 'progress',icon: 'skill',   desc: 'Naikkan satu skill ke level maksimal.',   cond: { type: 'special', key: 'maxedSkills', target: 1 },     reward: { gold: 300, xp: 150 } },
  { id: 'skill_max_5',   name: 'Ahli Serba Bisa',     cat: 'progress',icon: 'skill',   desc: 'Naikkan 5 skill ke level maksimal.',      cond: { type: 'special', key: 'maxedSkills', target: 5 },     reward: { gold: 2000, xp: 1000 } },
  { id: 'rank_d',        name: 'Lencana Perunggu',    cat: 'progress',icon: 'medal',   desc: 'Capai rank D (Bronze).',                  cond: { type: 'special', key: 'rankAtLeast', target: 'D' },  reward: { gold: 500, xp: 300 } },
  { id: 'rank_b',        name: 'Lencana Emas',        cat: 'progress',icon: 'medal',   desc: 'Capai rank B (Gold).',                    cond: { type: 'special', key: 'rankAtLeast', target: 'B' },  reward: { gold: 2000, xp: 1200 } },
  { id: 'rank_s',        name: 'Lencana Diamond',     cat: 'progress',icon: 'medal',   desc: 'Capai rank S (Diamond).',                 cond: { type: 'special', key: 'rankAtLeast', target: 'S' },  reward: { gold: 5000, xp: 3000, title: 'Diamond' } },

  // -- Mode Spesial (tower / world boss / combo / prestige / sosial baru) --
  { id: 'tower_5',       name: 'Pendaki Awal',        cat: 'mode',     icon: 'compass', desc: 'Capai lantai 5 Menara Tanpa Ujung.',       cond: { type: 'counter', stat: 'towerBest', target: 5 },      reward: { gold: 400, xp: 300, gems: 30 } },
  { id: 'tower_25',      name: 'Penakluk Menara',     cat: 'mode',     icon: 'compass', desc: 'Capai lantai 25 Menara Tanpa Ujung.',      cond: { type: 'counter', stat: 'towerBest', target: 25 },     reward: { gold: 4000, xp: 2500, gems: 100, title: 'Penakluk Menara' } },
  { id: 'tower_50',      name: 'Puncak Tak Terlihat', cat: 'mode',     icon: 'crown',   desc: 'Capai lantai 50 Menara Tanpa Ujung.',      cond: { type: 'counter', stat: 'towerBest', target: 50 },     reward: { gold: 20000, xp: 12000, gems: 300, title: 'Yang Mendaki Tak Berujung' } },
  { id: 'wb_hit_1',      name: 'Menyengat Raksasa',   cat: 'mode',     icon: 'skull',   desc: 'Serang world boss mingguan pertamamu.',    cond: { type: 'counter', stat: 'worldbossHits', target: 1 },    reward: { gold: 300, xp: 200, gems: 20 } },
  { id: 'wb_hit_50',     name: 'Duri di Tumit Raksasa', cat: 'mode',   icon: 'skull',   desc: 'Serang world boss 50 kali.',               cond: { type: 'counter', stat: 'worldbossHits', target: 50 },   reward: { gold: 4000, xp: 2500, gems: 80, title: 'Duri Raksasa' } },
  { id: 'combo_10',      name: 'Aliran Pedang',       cat: 'mode',     icon: 'sword',   desc: 'Capai combo 10 tanpa jeda.',               cond: { type: 'counter', stat: 'bestCombo', target: 10 },      reward: { gold: 350, xp: 200 } },
  { id: 'combo_30',      name: 'Badai Tanpa Henti',   cat: 'mode',     icon: 'sword',   desc: 'Capai combo 30 tanpa jeda.',               cond: { type: 'counter', stat: 'bestCombo', target: 30 },      reward: { gold: 2500, xp: 1500, gems: 60, title: 'Badai Berjalan' } },
  { id: 'prestige_1',    name: 'Lahir Kembali',       cat: 'mode',     icon: 'star',    desc: 'Lakukan prestige pertamamu.',             cond: { type: 'counter', stat: 'prestigeLevel', target: 1 },   reward: { gold: 0, xp: 0, gems: 200, title: 'Yang Terlahir Kembali' } },
  { id: 'prestige_3',    name: 'Siklus Abadi',        cat: 'mode',     icon: 'star',    desc: 'Prestige 3 kali.',                         cond: { type: 'counter', stat: 'prestigeLevel', target: 3 },   reward: { gold: 0, xp: 0, gems: 600, title: 'Penjelajah Siklus' } },
  { id: 'gift_1',        name: 'Tangan Terbuka',      cat: 'mode',     icon: 'friends', desc: 'Kirim hadiah ke teman.',                   cond: { type: 'counter', stat: 'giftsSent', target: 1 },        reward: { gold: 200, xp: 100 } },
  { id: 'gift_10',       name: 'Santa Kecil',         cat: 'mode',     icon: 'friends', desc: 'Kirim 10 hadiah.',                         cond: { type: 'counter', stat: 'giftsSent', target: 10 },       reward: { gold: 2000, xp: 1000, gems: 50, title: 'Santa Kecil' } },
  { id: 'auction_1',     name: 'Membuka Stan',        cat: 'mode',     icon: 'coin',    desc: 'Jual satu item di rumah lelang.',          cond: { type: 'counter', stat: 'auctionsListed', target: 1 },  reward: { gold: 300, xp: 150 } },
  { id: 'auction_win',   name: 'Pembeli Cepat',       cat: 'mode',     icon: 'coin',    desc: 'Menangkan 10 lelang.',                     cond: { type: 'counter', stat: 'auctionsWon', target: 10 },    reward: { gold: 1500, xp: 800, title: 'Tangan Aneh' } },
];
const ACH_BY_ID = Object.fromEntries(ACHIEVEMENTS.map(a => [a.id, a]));
const ACH_CATEGORIES = [
  { key: 'battle',   name: 'Pertempuran' },
  { key: 'dungeon',  name: 'Dungeon' },
  { key: 'craft',    name: 'Kerajinan' },
  { key: 'pet',      name: 'Pet' },
  { key: 'social',   name: 'Sosial' },
  { key: 'collect',  name: 'Koleksi' },
  { key: 'progress', name: 'Progresi' },
  { key: 'mode',     name: 'Mode Spesial' },
];

module.exports = {
  LEVEL_CAP, xpForLevel, totalXpForLevel, skillPointsForLevelUp, statPointsForLevelUp,
  RANKS, RANK_INDEX, getRank, nextRank, rankAtLeastMet,
  CLASSES, CLASS_KEYS, baseStatsForLevel,
  SKILL_TREES, skillById,
  REPUTATION_TIERS, reputationTier,
  MONSTERS, monsterById, monstersForLevel,
  PETS, PET_BY_ID, PET_BY_RARITY, PET_LEVEL_CAP, petXpForLevel, petPassiveAt, petSkillScale,
  PET_EVOLUTION, PET_SKILL2, PET_ULTIMATE, GACHA, WORLD_BOSSES, worldBossForWeek,
  ACHIEVEMENTS, ACH_BY_ID, ACH_CATEGORIES,
};
