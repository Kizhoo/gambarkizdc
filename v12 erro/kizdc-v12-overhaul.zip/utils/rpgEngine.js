// ============================================================================
// ENGINE SISTEM RPG "KIZHOO ADVENTURE"
// ----------------------------------------------------------------------------
// Logika permainan murni (tanpa Discord): naik level & XP, hitung stat efektif
// (base class + bonus alokasi + skill pasif), cek kelayakan promosi rank,
// buka/upgrade skill dengan validasi (skill point, prasyarat, level, maxLevel),
// dan perubahan reputasi.
// ============================================================================
const D = require('./rpgData');
const rdb = require('../database/rpgDb');
const items = require('./rpgItems');
const { syncLevel } = require('../database/db');
const { t } = require('./i18n');

// ---------- XP & LEVEL ----------
// Tambah XP ke karakter. Menangani multi-level-up sekaligus. Return ringkasan.
// Karakter otomatis dibuat (default Warrior) kalau belum ada, supaya level chat
// dan level RPG pakai SATU level yang sama. Kalau guildId diberikan, tabel leveling
// per-guild ikut disinkronkan ke level RPG ini.
function addExp(userId, amount, guildId) {
  let char = rdb.getCharacter(userId);
  if (!char) char = rdb.createCharacter(userId, 'warrior');
  if (char.level >= D.LEVEL_CAP) return { leveledUp: false, levelsGained: 0, char, fromLevel: char.level, toLevel: char.level, xpIntoLevel: char.xp, xpForNext: D.xpForLevel(char.level) };

  let xp = char.xp + Math.max(0, Math.floor(amount));
  let level = char.level;
  let skillPointsGained = 0;
  let statPointsGained = 0;

  while (level < D.LEVEL_CAP && xp >= D.xpForLevel(level)) {
    xp -= D.xpForLevel(level);
    level += 1;
    skillPointsGained += D.skillPointsForLevelUp(level);
    statPointsGained += D.statPointsForLevelUp();
  }
  const levelsGained = level - char.level;
  const updated = rdb.updateCharacter(userId, {
    xp, level,
    skillPoints: char.skillPoints + skillPointsGained,
    statPoints: char.statPoints + statPointsGained,
  });
  // Sinkronkan level per-guild supaya /rank & leaderboard menampilkan level yang sama.
  if (guildId) { try { syncLevel(guildId, userId, level, xp); } catch (_) {} }
  return {
    leveledUp: levelsGained > 0, levelsGained,
    skillPointsGained, statPointsGained,
    fromLevel: char.level, toLevel: level,
    xpIntoLevel: xp, xpForNext: D.xpForLevel(level),
    char: updated,
  };
}

// ---------- LEVEL TERUNIFIKASI (baca & set) ----------
// Sumber kebenaran SATU-SATUNYA untuk level & XP adalah karakter RPG global.
// Fungsi ini dipakai /rank, /profile, dashboard, dan semua jalur baca level
// supaya tidak ada lagi "level ganda" (tabel leveling per-guild hanyalah mirror).
function getLevel(userId) {
  const char = rdb.getCharacter(userId);
  if (!char) return { level: 1, xp: 0, needed: D.xpForLevel(1) };
  return { level: char.level, xp: char.xp, needed: D.xpForLevel(char.level) };
}

// Set level TERUNIFIKASI (update karakter RPG + sinkronkan mirror per-guild).
function setLevel(userId, level, guildId) {
  let char = rdb.getCharacter(userId);
  if (!char) char = rdb.createCharacter(userId, 'warrior');
  level = Math.max(0, Math.min(D.LEVEL_CAP, Math.floor(Number(level) || 0)));
  const updated = rdb.updateCharacter(userId, { level, xp: 0 });
  if (guildId) { try { syncLevel(guildId, userId, level, 0); } catch (_) {} }
  return { level: updated.level };
}

// ---------- STAT EFEKTIF ----------
// base class utk level + bonus alokasi manual + bonus pasif dari skill.
function computeStats(char, skills = null) {
  skills = skills || rdb.getSkills(char.userId);
  const base = D.baseStatsForLevel(char.className, char.level);
  const stats = {
    hp: base.hp + (char.hpBonus || 0),
    mp: base.mp + (char.mpBonus || 0),
    atk: base.atk + (char.atkBonus || 0),
    def: base.def + (char.defBonus || 0),
    spd: base.spd + (char.spdBonus || 0),
    crit: base.crit + (char.critBonus || 0),
  };
  // Terapkan skill pasif.
  for (const s of skills) {
    const def = D.skillById(char.className, s.skillId);
    if (!def || def.type !== 'passive') continue;
    const e = def.effect || {};
    const lvl = s.level || 1;
    if (e.defPct)  stats.def  *= (1 + e.defPct * lvl);
    if (e.atkPct)  stats.atk  *= (1 + e.atkPct * lvl);
    if (e.spdPct)  stats.spd  *= (1 + e.spdPct * lvl);
    if (e.hpPct)   stats.hp  *= (1 + e.hpPct * lvl);
    if (e.critPct) stats.crit += e.critPct * 100 * lvl;
    if (e.healPct) stats.healPct = (stats.healPct || 0) + e.healPct * lvl;
    if (e.evaPct)  stats.evasion = (stats.evasion || 0) + e.evaPct * lvl * 100;
    if (e.thorns)  stats.thorns = (stats.thorns || 0) + e.thorns * lvl;
  }
  // PRESTIGE: bonus permanen +10% stat dasar per tingkat reinkarnasi.
  const prestigeMult = 1 + 0.1 * (char.prestigeLevel || 0);
  if (prestigeMult > 1) for (const k of ['hp', 'mp', 'atk', 'def', 'spd']) stats[k] *= prestigeMult;
  // Bonus dari equipment (senjata/zirah/aksesoris) - flat, diterapkan SETELAH persentase skill
  // pasif biar item selalu kasih tambahan penuh sesuai nilai di katalog, tidak ikut digandakan
  // oleh persentase skill.
  for (const slot of ['equipWeapon', 'equipArmor', 'equipAccessory']) {
    const item = char[slot] && items.getItem(char[slot]);
    if (!item || !item.stats) continue;
    for (const [k, v] of Object.entries(item.stats)) if (stats[k] != null) stats[k] += v;
  }
  for (const k of ['hp','mp','atk','def','spd','crit']) stats[k] = Math.round(stats[k]);
  return stats;
}

// ---------- SKILL: buka / upgrade ----------
function unlockOrUpgradeSkill(userId, skillId, lang = 'id') {
  const char = rdb.getCharacter(userId);
  if (!char) return { ok: false, error: t(lang, 'rpge.no_char') };
  const def = D.skillById(char.className, skillId);
  if (!def) return { ok: false, error: t(lang, 'rpge.skill_not_found') };

  const currentLevel = rdb.getSkillLevel(userId, skillId);
  if (currentLevel >= def.maxLevel) return { ok: false, error: t(lang, 'rpge.skill_max', { name: def.name, max: def.maxLevel }) };
  if (char.level < def.reqLevel) return { ok: false, error: t(lang, 'rpge.skill_level', { lvl: def.reqLevel, cur: char.level }) };

  for (const req of def.requires || []) {
    if (rdb.getSkillLevel(userId, req) < 1) {
      const reqDef = D.skillById(char.className, req);
      return { ok: false, error: t(lang, 'rpge.skill_require', { name: reqDef ? reqDef.name : req }) };
    }
  }
  if (char.skillPoints < def.cost) return { ok: false, error: t(lang, 'rpge.skill_points', { cost: def.cost, have: char.skillPoints }) };

  rdb.setSkillLevel(userId, skillId, currentLevel + 1);
  const updated = rdb.updateCharacter(userId, { skillPoints: char.skillPoints - def.cost });
  return { ok: true, skill: def, newLevel: currentLevel + 1, remainingPoints: updated.skillPoints, action: currentLevel === 0 ? 'unlock' : 'upgrade' };
}

// Reset skill tree (kembalikan semua skill point). Berguna utk respec.
function respecSkills(userId, lang = 'id') {
  const char = rdb.getCharacter(userId);
  if (!char) return { ok: false, error: t(lang, 'rpge.no_char_short') };
  const skills = rdb.getSkills(userId);
  let refunded = 0;
  for (const s of skills) {
    const def = D.skillById(char.className, s.skillId);
    if (def) refunded += def.cost * s.level;
  }
  rdb.resetSkills(userId);
  const updated = rdb.updateCharacter(userId, { skillPoints: char.skillPoints + refunded });
  return { ok: true, refunded, skillPoints: updated.skillPoints };
}

// ---------- STAT POINT: alokasi manual ----------
const STAT_MAP = { hp: 'hpBonus', mp: 'mpBonus', atk: 'atkBonus', def: 'defBonus', spd: 'spdBonus', crit: 'critBonus' };
const STAT_STEP = { hp: 10, mp: 6, atk: 2, def: 2, spd: 1, crit: 1 };
function allocateStat(userId, stat, points = 1, lang = 'id') {
  const char = rdb.getCharacter(userId);
  if (!char) return { ok: false, error: t(lang, 'rpge.no_char_short') };
  const field = STAT_MAP[stat];
  if (!field) return { ok: false, error: t(lang, 'rpge.stat_invalid') };
  points = Math.max(1, Math.floor(points));
  if (char.statPoints < points) return { ok: false, error: t(lang, 'rpge.stat_points', { have: char.statPoints }) };
  const updated = rdb.updateCharacter(userId, {
    [field]: (char[field] || 0) + STAT_STEP[stat] * points,
    statPoints: char.statPoints - points,
  });
  return { ok: true, stat, added: STAT_STEP[stat] * points, statPoints: updated.statPoints, char: updated };
}

// ---------- RANK: kelayakan promosi ----------
function checkPromotion(char, lang = 'id') {
  const current = D.getRank(char.rankKey);
  const next = D.nextRank(char.rankKey);
  if (!next) return { eligible: false, next: null, reason: t(lang, 'rpg.rank_highest') };
  if (next.promo === 'prestige') {
    return { eligible: false, next, prestige: true, reason: t(lang, 'rpg.rank_special', { rank: next.key, name: next.name }) };
  }
  if (next.promo === 'legendary') {
    return { eligible: false, next, legendary: true, reason: t(lang, 'rpg.rank_legendary', { rank: next.key, name: next.name }) };
  }
  const missing = D.rankAtLeastMet(char, next.req);
  return { eligible: missing.length === 0, next, current, missing };
}

// Terapkan promosi (dipanggil SETELAH approval manual). Tidak mengecek ulang syarat
// supaya staff/owner bisa meng-override kalau perlu — validasi dilakukan di command.
function applyPromotion(userId, toRankKey, lang = 'id') {
  const char = rdb.getCharacter(userId);
  if (!char) return { ok: false, error: t(lang, 'rpge.no_char_short') };
  const rank = D.getRank(toRankKey);
  if (!rank) return { ok: false, error: t(lang, 'rpge.rank_invalid') };
  const updated = rdb.updateCharacter(userId, { rankKey: toRankKey });
  return { ok: true, char: updated, rank };
}

// ---------- REPUTASI ----------
function addReputation(userId, amount) {
  const char = rdb.getCharacter(userId);
  if (!char) return { ok: false, error: 'Karakter belum dibuat.' };
  const before = D.reputationTier(char.reputation);
  const updated = rdb.updateCharacter(userId, { reputation: char.reputation + Math.floor(amount) });
  const after = D.reputationTier(updated.reputation);
  return { ok: true, reputation: updated.reputation, changedTier: before.key !== after.key, tier: after, char: updated };
}

// ---------- GANTI CLASS ----------
// Refund skill point (reset skill tree) + stat point (reset alokasi manual),
// lalu ganti class karakter. Berguna karena karakter auto-dibuat sebagai Warrior
// saat pertama chat — pemain bisa ganti class sesuai keinginan tanpa buat karakter baru.
function changeClass(userId, classKey, lang = 'id') {
  if (!D.CLASSES[classKey]) return { ok: false, error: t(lang, 'rpg.class_invalid') };
  let char = rdb.getCharacter(userId);
  if (!char) return { ok: false, error: t(lang, 'rpge.no_char_short') };
  const skillRes = respecSkills(userId, lang);
  char = rdb.getCharacter(userId); // baca ulang setelah skill point di-refund
  const spentStats =
    Math.floor((char.hpBonus || 0) / STAT_STEP.hp) +
    Math.floor((char.mpBonus || 0) / STAT_STEP.mp) +
    Math.floor((char.atkBonus || 0) / STAT_STEP.atk) +
    Math.floor((char.defBonus || 0) / STAT_STEP.def) +
    Math.floor((char.spdBonus || 0) / STAT_STEP.spd) +
    Math.floor((char.critBonus || 0) / STAT_STEP.crit);
  const updated = rdb.updateCharacter(userId, {
    className: classKey,
    hpBonus: 0, mpBonus: 0, atkBonus: 0, defBonus: 0, spdBonus: 0, critBonus: 0,
    statPoints: char.statPoints + spentStats,
  });
  return { ok: true, char: updated, class: D.CLASSES[classKey], skillRefund: skillRes.refunded || 0, statRefund: spentStats };
}

module.exports = {
  addExp, getLevel, setLevel, computeStats, unlockOrUpgradeSkill, respecSkills,
  allocateStat, STAT_STEP, changeClass,
  checkPromotion, applyPromotion, addReputation,
};
