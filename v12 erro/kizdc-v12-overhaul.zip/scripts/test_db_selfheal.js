// Tes self-heal skema: simulasi DB hosting user yang punya tabel chat versi
// asing/lama (mirip kasus "no such column: scope" — skema beda total), lalu
// pastikan rpgDb.js menormalkannya dan fungsi chat jalan tanpa error.
const fs = require('fs');
const path = require('path');
const os = require('os');
const Database = require('better-sqlite3');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'kz-heal-'));
const dbPath = path.join(tmp, 'legacy.sqlite');
process.env.KIZHOO_DB_PATH = dbPath;

// 1) Buat DB "warisan" seperti di hosting: tabel rpg_characters + rpg_chat_messages
//    versi ASING (kolom scope/sender//body — TIDAK punya kolom kita).
const raw = new Database(dbPath);
raw.exec(`
  CREATE TABLE rpg_characters (
    userId TEXT PRIMARY KEY, className TEXT NOT NULL, level INTEGER NOT NULL DEFAULT 1,
    xp INTEGER NOT NULL DEFAULT 0, rankKey TEXT NOT NULL DEFAULT 'G',
    statPoints INTEGER NOT NULL DEFAULT 0, skillPoints INTEGER NOT NULL DEFAULT 0,
    reputation INTEGER NOT NULL DEFAULT 0, hpBonus INTEGER NOT NULL DEFAULT 0,
    atkBonus INTEGER NOT NULL DEFAULT 0, defBonus INTEGER NOT NULL DEFAULT 0,
    spdBonus INTEGER NOT NULL DEFAULT 0, questsCompleted INTEGER NOT NULL DEFAULT 0,
    monstersKilled INTEGER NOT NULL DEFAULT 0, dungeonsCleared INTEGER NOT NULL DEFAULT 0,
    bossesDefeated INTEGER NOT NULL DEFAULT 0, worldQuests INTEGER NOT NULL DEFAULT 0,
    partyLed INTEGER NOT NULL DEFAULT 0, wins INTEGER NOT NULL DEFAULT 0,
    losses INTEGER NOT NULL DEFAULT 0, gold INTEGER NOT NULL DEFAULT 0,
    appearance TEXT DEFAULT '{}', titleText TEXT DEFAULT NULL,
    createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL
  );
  CREATE TABLE rpg_chat_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scope TEXT NOT NULL,
    sender TEXT NOT NULL,
    body TEXT NOT NULL,
    ts INTEGER NOT NULL
  );
  CREATE TABLE dashboard_sessions_legacy_junk (x INTEGER);
`);
raw.prepare(`INSERT INTO rpg_characters (userId, className, createdAt, updatedAt) VALUES ('u1','mage',1,1)`).run();
raw.prepare(`INSERT INTO rpg_chat_messages (scope, sender, body, ts) VALUES ('global','u1','pesan lama',1)`).run();
raw.close();

// 2) Muat rpgDb — harus self-heal tanpa lempar error.
const rpgDb = require('../database/rpgDb.js');

// 3) Verifikasi (lewat koneksi RAW terpisah — rpgDb tidak mengekspor objek db).
const verify = new Database(dbPath);
const cols = verify.prepare('PRAGMA table_info(rpg_chat_messages)').all().map(c => c.name);
const need = ['id', 'channel', 'fromUserId', 'toUserId', 'message', 'createdAt'];
const missing = need.filter(c => !cols.includes(c));
if (missing.length) { console.error('GAGAL: kolom hilang setelah heal:', missing); process.exit(1); }

const added = rpgDb.addChatMessage({ channel: 'global', fromUserId: 'u1', message: 'halo dunia' });
const hist = rpgDb.getChatHistory('global');
if (!hist.some(m => m.message === 'halo dunia')) { console.error('GAGAL: pesan baru tidak terbaca', hist); process.exit(1); }
verify.close();

const sess = rpgDb.saveSession('sid-tes', { username: 'tes' });
const got = rpgDb.getSession('sid-tes');
if (!got || got.username !== 'tes') { console.error('GAGAL: sesi tidak tersimpan/terbaca'); process.exit(1); }

// Karakter lama tetap utuh (progres game tidak tersentuh).
const ch = rpgDb.getCharacter('u1');
if (!ch || ch.className !== 'mage') { console.error('GAGAL: karakter lama hilang'); process.exit(1); }

// 4) Kasus kedua: tabel dengan SEMUA kolom inti kecuali toUserId -> harus ALTER (data dipertahankan).
const dbPath2 = path.join(tmp, 'partial.sqlite');
process.env.KIZHOO_DB_PATH = dbPath2;
delete require.cache[require.resolve('../database/rpgDb.js')];
delete require.cache[require.resolve('../database/db.js')];
const raw2 = new Database(dbPath2);
raw2.exec(`CREATE TABLE rpg_chat_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT, channel TEXT NOT NULL, fromUserId TEXT NOT NULL,
  message TEXT NOT NULL, createdAt INTEGER NOT NULL);`);
raw2.prepare(`INSERT INTO rpg_chat_messages (channel, fromUserId, message, createdAt) VALUES ('global','u9','pesan lama',7)`).run();
raw2.close();
const rpgDb2 = require('../database/rpgDb.js');
const keep = rpgDb2.getChatHistory('global');
if (!keep.some(m => m.message === 'pesan lama')) { console.error('GAGAL: data seharusnya dipertahankan lewat ALTER'); process.exit(1); }
rpgDb2.addChatMessage({ channel: 'dm', fromUserId: 'u9', toUserId: 'u8', message: 'dm tes' });
const dm2 = rpgDb2.getDmHistory('u9', 'u8');
if (!dm2.some(m => m.message === 'dm tes')) { console.error('GAGAL: DM tidak jalan pasca ALTER'); process.exit(1); }

// 5) Kasus ketiga: friends & achievements versi asing + tabel chat penuh kolom asing.
const dbPath3 = path.join(tmp, 'foreign-fa.sqlite');
process.env.KIZHOO_DB_PATH = dbPath3;
delete require.cache[require.resolve('../database/rpgDb.js')];
delete require.cache[require.resolve('../database/db.js')];
const raw3 = new Database(dbPath3);
raw3.exec(`
  CREATE TABLE rpg_friends (uid TEXT, fid TEXT, since INTEGER);
  CREATE TABLE rpg_achievements (player TEXT, badge TEXT, ts INTEGER);
  CREATE TABLE rpg_chat_messages (id INTEGER PRIMARY KEY AUTOINCREMENT, scope TEXT, sender TEXT, body TEXT, ts INTEGER);
`);
raw3.close();
const rpgDb3 = require('../database/rpgDb.js');
// Friends & achievements harus terbentuk ulang dengan skema benar (fungsi jalan).
rpgDb3.addFriend ? rpgDb3.addFriend('u1', 'u2') : null;
const fr = rpgDb3.getFriends('u1');
rpgDb3.addChatMessage({ channel: 'global', fromUserId: 'u1', message: 'pasca reset' });
if (!rpgDb3.getChatHistory('global').some(m => m.message === 'pasca reset')) {
  console.error('GAGAL: chat tidak jalan pasca reset tabel asing'); process.exit(1);
}
try {
  rpgDb3.unlockAchievement("u1", "first_kill");
} catch (e) { console.error('GAGAL: achievement pasca reset:', e.message); process.exit(1); }

console.log('SELF-HEAL TEST: SEMUA LULUS (skema asing di-reset, skema parsial di-ALTER, progres karakter utuh, friends/achievements pulih)');
