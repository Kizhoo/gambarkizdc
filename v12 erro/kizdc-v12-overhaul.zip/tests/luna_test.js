// ============================================================================
// LUNA TOOL TEST — verifikasi tool Luna sinkron dengan web game
// ----------------------------------------------------------------------------
// Fokus: tool baru hasil penyelarasan web (accept_quest HARUS menulis ke
// appearance.activeQuests yang dibaca web, bukan tabel lama), tool pet/gacha/
// worldboss/tower/friends, dan tool lama yang dihapus benar-benar hilang.
// ============================================================================
process.env.KIZHOO_DB_PATH = '/tmp/kiz_luna_test.sqlite';
require('fs').rmSync('/tmp/kiz_luna_test.sqlite', { force: true });

const rdb = require('../database/rpgDb');
const { TOOLS, toolCatalog } = require('../utils/lunaAgent');
const D = require('../utils/rpgData');

let pass = 0, fail = 0;
function ok(cond, name) {
  if (cond) { pass++; console.log(`  OK ${name}`); }
  else { fail++; console.log(`  GAGAL ${name}`); }
}

const U = '424242', G = 'g1';
const ctx = { userId: U, guildId: G, guild: null, member: null, client: null, channelId: 'c1' };

// ---- Seed: karakter + quest aktif + pet + wallet ----
rdb.createCharacter(U, 'archer');
rdb.updateCharacter(U, { appearance: JSON.stringify({ choseClass: 1 }) });
rdb.updateCharacter(U, { gems: 500, petShards: 30, towerBest: 7 });
rdb.addGold(U, G, 1000);
const quest = rdb.createQuest({
  title: 'Uji Coba Luna', description: 'Membasmi slime di padang uji', type: 'hunt',
  objectiveType: 'monstersKilled', objectiveTarget: 3, rewardXp: 50, rewardGold: 20, rewardRep: 1,
  minRank: 'G', guildId: 'global', expiresAt: Date.now() + 86400000,
});
rdb.grantPet(U, 'ember');
rdb.addPetXp(U, 'ember', 40);

console.log('== Tool yang dihapus benar-benar hilang ==');
for (const gone of ['hunt', 'create_character', 'create_party', 'join_party', 'leave_party', 'list_parties', 'use_item']) {
  ok(!TOOLS[gone], `tool "${gone}" sudah tidak ada`);
}

console.log('== Tool baru terdaftar ==');
for (const added of ['pet_collection', 'pet_activate', 'gacha_info', 'worldboss_info', 'tower_info', 'auction_info', 'friends_list', 'web_game_link']) {
  ok(!!TOOLS[added], `tool "${added}" terdaftar`);
}
ok(!toolCatalog({ userId: '999' }).includes('admin_action'), 'admin_action tersembunyi dari katalog user biasa');
ok(toolCatalog({ userId: String(process.env.OWNER_ID || '0') }).length > 0, 'katalog owner tetap ter-generate');

console.log('== get_status: field web-game lengkap ==');
const st = TOOLS.get_status.run(ctx);
ok(st.registered === true, 'karakter terdaftar');
ok(st.class === 'archer' && typeof st.level === 'number', 'class & level terbaca');
ok(st.gems === 500 && st.petShards === 30, 'gems & petShards terbaca');
ok(st.towerBest === 7, 'towerBest terbaca');
ok(st.activePet && st.activePet.name === 'Ember', 'pet aktif terbaca');
ok(!('party' in st), 'field party (sistem lama) sudah tidak ada');

console.log('== accept_quest: SINKRON WEB (appearance.activeQuests) ==');
const acc = TOOLS.accept_quest.run(ctx, { questId: quest.questId });
ok(acc.ok === true, `quest diterima (${acc.accepted || acc.error})`);
const char = rdb.getCharacter(U);
const app = JSON.parse(char.appearance || '{}');
ok(Array.isArray(app.activeQuests) && app.activeQuests.includes(quest.questId), 'quest masuk appearance.activeQuests (dibaca web)');
const accAgain = TOOLS.accept_quest.run(ctx, { questId: quest.questId });
ok(accAgain.ok === false && /sudah kamu ambil/i.test(accAgain.error || ''), 'double-accept ditolak');
const qp = TOOLS.quest_progress.run(ctx, {});
ok(qp.ok === true && qp.activeQuests.some(q => q.id === quest.questId), 'quest_progress membaca quest yang baru diambil');

console.log('== Tool pet ==');
const pc = TOOLS.pet_collection.run(ctx);
ok(pc.ownedCount === 1 && pc.pets.find(p => p.id === 'ember')?.owned === true, 'koleksi pet akurat');
ok(pc.pets.find(p => p.id === 'nyx')?.owned === false, 'pet belum dimiliki terdeteksi');
const pa = TOOLS.pet_activate.run(ctx, { petId: 'nyx' });
ok(pa.ok === false, 'aktifkan pet yang belum dimiliki ditolak');
const pa2 = TOOLS.pet_activate.run(ctx, { petId: 'ember' });
ok(pa2.ok !== false && rdb.getActivePet(U)?.petId === 'ember', 'aktifkan pet milik sendiri sukses');

console.log('== Tool gacha / worldboss / tower / lelang / teman ==');
const gi = TOOLS.gacha_info.run(ctx);
ok(gi.gems === 500 && gi.pity && gi.pity.mythicGuaranteedAt === D.GACHA.pityMythicAt, 'gacha_info + pity akurat');
const wb = TOOLS.worldboss_info.run(ctx);
ok(wb.maxHp > 0 && Array.isArray(wb.leaderboard), `worldboss aktif: ${wb.boss} (HP ${wb.hp}/${wb.maxHp})`);
const ti = TOOLS.tower_info.run(ctx);
ok(ti.bestFloor === 7, 'tower_info akurat');
const ai = TOOLS.auction_info.run(ctx);
ok(ai.ok !== false && Array.isArray(ai.auctions), 'auction_info jalan (kosong boleh)');
const fl = TOOLS.friends_list.run(ctx);
ok(fl.ok !== false && fl.count === 0, 'friends_list jalan (kosong)');
const wl = TOOLS.web_game_link.run(ctx);
ok(typeof wl.url === 'string' && wl.url.endsWith('/rpg'), 'web_game_link mengembalikan URL /rpg');

console.log('== quest kadaluarsa ditolak ==');
rdb.createQuest({ title: 'Quest Basi', description: 'x', type: 'hunt', objectiveType: 'monstersKilled', objectiveTarget: 1, rewardXp: 1, rewardGold: 1, rewardRep: 0, minRank: 'G', guildId: 'global', expiresAt: Date.now() - 1000 });
const all = rdb.listActiveQuests('global', 20).filter(q => q.title === 'Quest Basi');
if (all.length) {
  const accBad = TOOLS.accept_quest.run(ctx, { questId: all[0].questId });
  ok(accBad.ok === false, 'quest kadaluarsa ditolak');
} else {
  ok(true, 'quest kadaluarsa sudah otomatis dinonaktifkan oleh DB');
}

rdb.close();
console.log(`\n==== HASIL LUNA: ${pass} lulus, ${fail} gagal ====`);
process.exitCode = fail ? 1 : 0;
