const { SlashCommandBuilder } = require('discord.js');
const { evaluate } = require('../../utils/mathParser');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  subcommandOf: true,
  data: new SlashCommandBuilder()
    .setName('calculator')
    .setDescription('Hitung ekspresi matematika')
    .addStringOption(o => o.setName('ekspresi').setDescription('Contoh: (2+3)*4, 10/3, 2^10').setRequired(true)),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const expression = interaction.options.getString('ekspresi');

    try {
      const result = evaluate(expression);
      const embed = baseEmbed()
        .setTitle(t(lang, 'calc.title'))
        .addFields(
          { name: t(lang, 'info.expression'), value: `\`${expression}\`` },
          { name: t(lang, 'fun.result'), value: `\`${result}\`` },
        );
      return interaction.reply({ embeds: [embed] });
    } catch (err) {
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'calc.fail', { err: err.message }))], ephemeral: true });
    }
  },
};
