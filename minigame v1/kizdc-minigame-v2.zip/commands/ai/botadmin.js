const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const { isOwner } = require('../../utils/ownerCheck');
const { generateText } = require('../../utils/aiProvider');
const { healthyNodeCount, checkAndHeal, CANDIDATE_NODES } = require('../../utils/nodeHealthMonitor');
const { baseEmbed, errorEmbed, successEmbed } = require('../../utils/embeds');
const { safeDefer } = require('../../utils/interactionHelpers');
const admin = require('../../utils/adminActions');
const settings = require('../../utils/settings');
const config = require('../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('botadmin')
    .setDescription('[Owner Only] Monitoring, diagnostik, dan admin user/ekonomi')
    .addSubcommand(sub => sub.setName('status').setDescription('Lihat status kesehatan bot secara keseluruhan'))
    .addSubcommand(sub => sub.setName('nodes').setDescription('Cek dan coba perbaiki node musik secara manual sekarang'))
    .addSubcommand(sub => sub.setName('explain').setDescription('Minta AI jelaskan sebuah pesan error/log')
      .addStringOption(o => o.setName('teks').setDescription('Paste pesan error atau log yang mau dijelaskan').setRequired(true)))
    .addSubcommand(sub => sub.setName('addgold').setDescription('Tambah/kurangi gold user (angka negatif = kurangi)')
      .addUserOption(o => o.setName('user').setDescription('Target').setRequired(true))
      .addIntegerOption(o => o.setName('jumlah').setDescription('Jumlah gold (boleh negatif)').setRequired(true)))
    .addSubcommand(sub => sub.setName('setgold').setDescription('Set gold user ke angka tertentu')
      .addUserOption(o => o.setName('user').setDescription('Target').setRequired(true))
      .addIntegerOption(o => o.setName('jumlah').setDescription('Gold baru').setRequired(true)))
    .addSubcommand(sub => sub.setName('setlevel').setDescription('Set level user (level terunifikasi)')
      .addUserOption(o => o.setName('user').setDescription('Target').setRequired(true))
      .addIntegerOption(o => o.setName('level').setDescription('Level baru').setRequired(true).setMinValue(1)))
    .addSubcommand(sub => sub.setName('giveitem').setDescription('Kasih item pasar langsung ke tas user')
      .addUserOption(o => o.setName('user').setDescription('Target').setRequired(true))
      .addStringOption(o => o.setName('item_id').setDescription('ID item (lihat /market)').setRequired(true))
      .addIntegerOption(o => o.setName('jumlah').setDescription('Jumlah (default 1)').setMinValue(1)))
    .addSubcommand(sub => sub.setName('removeitem').setDescription('Cabut item dari tas user')
      .addUserOption(o => o.setName('user').setDescription('Target').setRequired(true))
      .addStringOption(o => o.setName('item_id').setDescription('ID item').setRequired(true))
      .addIntegerOption(o => o.setName('jumlah').setDescription('Jumlah (default 1)').setMinValue(1)))
    .addSubcommand(sub => sub.setName('addxp').setDescription('Kasih XP user langsung (otomatis naik level kalau cukup)')
      .addUserOption(o => o.setName('user').setDescription('Target').setRequired(true))
      .addIntegerOption(o => o.setName('jumlah').setDescription('Jumlah XP').setRequired(true).setMinValue(1)))
    .addSubcommand(sub => sub.setName('setmodel').setDescription('Ganti model AI yang dipakai Luna & AI chat (langsung aktif, tanpa restart)')
      .addStringOption(o => {
        o.setName('model').setDescription('Model baru').setRequired(true);
        const choices = (config.ai?.models?.cloudflare || []).slice(0, 25).map(m => ({ name: m.replace('@cf/', ''), value: m }));
        if (choices.length) o.addChoices(...choices);
        return o;
      }))
    .addSubcommand(sub => sub.setName('viewuser').setDescription('Lihat detail lengkap user (level, saldo, minigame)')
      .addUserOption(o => o.setName('user').setDescription('Target').setRequired(true))),

  async execute(interaction, client) {
    if (!isOwner(interaction.user.id)) {
      return interaction.reply({ embeds: [errorEmbed('Command ini cuma bisa dipakai owner bot.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'addgold' || sub === 'setgold') {
      const target = interaction.options.getUser('user');
      const amount = interaction.options.getInteger('jumlah');
      const res = sub === 'addgold'
        ? admin.adminAddGold(target.id, interaction.guild.id, amount)
        : admin.adminSetGold(target.id, interaction.guild.id, amount);
      if (!res.ok) return interaction.reply({ embeds: [errorEmbed(res.error)], ephemeral: true });
      return interaction.reply({ embeds: [successEmbed(`✅ Saldo ${target} sekarang **${res.newBalance.toLocaleString('id-ID')} gold** (server ini).`)], ephemeral: true });
    }
    if (sub === 'setlevel') {
      const target = interaction.options.getUser('user');
      const res = admin.adminSetLevel(target.id, interaction.options.getInteger('level'), interaction.guild.id);
      if (!res.ok) return interaction.reply({ embeds: [errorEmbed(res.error)], ephemeral: true });
      return interaction.reply({ embeds: [successEmbed(`✅ Level ${target} di-set ke **${res.level}**.`)], ephemeral: true });
    }
    if (sub === 'giveitem') {
      const target = interaction.options.getUser('user');
      const res = admin.adminGiveItem(target.id, interaction.options.getString('item_id'), interaction.options.getInteger('jumlah') || 1);
      if (!res.ok) return interaction.reply({ embeds: [errorEmbed(res.error)], ephemeral: true });
      return interaction.reply({ embeds: [successEmbed(`✅ ${target} dapat **${res.item} x${res.qty}**.`)], ephemeral: true });
    }
    if (sub === 'removeitem') {
      const target = interaction.options.getUser('user');
      const res = admin.adminRemoveItem(target.id, interaction.options.getString('item_id'), interaction.options.getInteger('jumlah') || 1);
      if (!res.ok) return interaction.reply({ embeds: [errorEmbed(res.error)], ephemeral: true });
      return interaction.reply({ embeds: [successEmbed(`✅ **${res.item} x${res.qty}** dicabut dari tas ${target}.`)], ephemeral: true });
    }
    if (sub === 'addxp') {
      const target = interaction.options.getUser('user');
      const res = admin.adminAddXp(target.id, interaction.options.getInteger('jumlah'), interaction.guild.id);
      if (!res.ok) return interaction.reply({ embeds: [errorEmbed(res.error)], ephemeral: true });
      // Kirim notifikasi level-up ke channel (tidak cuma pesan ephemeral) supaya konsisten
      // dengan sistem leveling: naik level selalu ada notifikasi, baik dari RPG maupun XP manual.
      if (res.leveledUp) {
        const embed = new EmbedBuilder()
          .setColor(config.successColor)
          .setAuthor({ name: target.username, iconURL: target.displayAvatarURL() })
          .setTitle('Naik Level')
          .setDescription(`Selamat ${target}, kamu sekarang **Level ${res.toLevel}**! (${res.xpIntoLevel}/${res.xpForNext} XP)`)
          .setFooter({ text: config.footer })
          .setTimestamp();
        interaction.channel.send({ embeds: [embed] }).catch(() => {});
      }
      return interaction.reply({ embeds: [successEmbed(`✅ XP diberikan.${res.leveledUp ? ` ${target} naik ke **Level ${res.toLevel}**!` : ` Level ${target} sekarang: **${res.level}**.`}`)], ephemeral: true });
    }
    if (sub === 'setmodel') {
      const model = interaction.options.getString('model');
      settings.set('ai.model', model);
      return interaction.reply({ embeds: [successEmbed(`✅ Model AI diganti ke **${model}**. Langsung aktif buat Luna & AI chat, tanpa perlu restart bot.`)], ephemeral: true });
    }
    if (sub === 'viewuser') {
      const target = interaction.options.getUser('user');
      const res = admin.adminViewUser(target.id, interaction.guild.id);
      if (!res.ok) return interaction.reply({ embeds: [errorEmbed(res.error)], ephemeral: true });
      const mg = res.minigame;
      const embed = baseEmbed().setTitle(`Detail User — ${target.username}`)
        .setDescription([
          `Level ${res.level} (XP ${res.xp.toLocaleString('id-ID')})`,
          `Saldo: ${res.balance.toLocaleString('id-ID')} KZC • Bank: ${res.bank.toLocaleString('id-ID')} KZC`,
          `Jenis item di tas: ${res.inventoryCount}`,
          mg ? `Minigame: gelombang ${mg.wave} • rekor ${mg.bestWave} • ${mg.totalKills.toLocaleString('id-ID')} kill` : 'Minigame: belum pernah main',
        ].join('\n'));
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === 'status') {
      const memUsage = process.memoryUsage();
      const nodeCount = healthyNodeCount();

      const embed = baseEmbed()
        .setTitle('Status Bot')
        .addFields(
          { name: 'Uptime', value: `<t:${Math.floor((Date.now() - client.uptime) / 1000)}:R>`, inline: true },
          { name: 'Server', value: `${client.guilds.cache.size}`, inline: true },
          { name: 'Ping Gateway', value: `${Math.round(client.ws.ping)}ms`, inline: true },
          { name: 'RAM Digunakan', value: `${(memUsage.heapUsed / 1024 / 1024).toFixed(2)} MB`, inline: true },
          { name: 'Node Musik Sehat', value: `${nodeCount}`, inline: true },
          { name: 'Command Termuat', value: `${client.commands.size}`, inline: true },
        )
        .setColor(nodeCount > 0 ? config.successColor : config.errorColor);

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === 'nodes') {
      if (!(await safeDefer(interaction, { ephemeral: true }))) return;

      const before = healthyNodeCount();
      await checkAndHeal(client);
      const after = healthyNodeCount();

      const connectedNames = [...client.kazagumo.shoukaku.nodes.entries()]
        .map(([name]) => name)
        .join(', ') || 'Tidak ada';

      const embed = baseEmbed()
        .setTitle('Cek Node Musik Manual')
        .setDescription(
          `Node sehat sebelum cek: **${before}**\nNode sehat sesudah cek: **${after}**\nNode terdaftar saat ini: ${connectedNames}\n\nKandidat cadangan tersedia: ${CANDIDATE_NODES.map(n => n.name).join(', ')}`
        );
      return interaction.editReply({ embeds: [embed] });
    }

    if (sub === 'explain') {
      const text = interaction.options.getString('teks');
      if (!(await safeDefer(interaction, { ephemeral: true }))) return;

      try {
        const messages = [
          {
            role: 'system',
            content: 'Kamu adalah asisten debugging untuk bot Discord Node.js. Jelaskan pesan error/log berikut dalam Bahasa Indonesia yang mudah dipahami: apa penyebabnya, dan saran perbaikan singkat. Maksimal 5 kalimat, jangan bertele-tele, dan jangan pakai emoji.',
          },
          { role: 'user', content: text },
        ];
        const explanation = await generateText(messages);

        const isNodeIssue = /voice_connect_failed|lavalink|node.*(down|mati|offline|error)/i.test(text);

        const embed = baseEmbed()
          .setTitle('Penjelasan Error (AI)')
          .addFields(
            { name: 'Input', value: text.slice(0, 500) },
            { name: 'Penjelasan', value: explanation.slice(0, 1000) },
          );

        if (isNodeIssue) {
          const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('botadmin_fix_nodes').setLabel('Cek & Perbaiki Node Musik').setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId('botadmin_cancel').setLabel('Batal').setStyle(ButtonStyle.Secondary),
          );
          embed.setFooter({ text: 'Terdeteksi kemungkinan masalah node musik. Ada aksi perbaikan otomatis yang tersedia.' });
          const message = await interaction.editReply({ embeds: [embed], components: [row] });

          const collector = message.createMessageComponentCollector({ componentType: ComponentType.Button, time: 60000, max: 1 });
          collector.on('collect', async i => {
            if (i.customId === 'botadmin_fix_nodes') {
              await i.update({ embeds: [embed], components: [], content: 'Menjalankan pengecekan node...' });
              await checkAndHeal(client);
              await interaction.followUp({ embeds: [successEmbed(`Selesai. Node sehat sekarang: ${healthyNodeCount()}.`)], ephemeral: true });
            } else {
              await i.update({ components: [], content: 'Dibatalkan.' });
            }
          });
          return;
        }

        embed.setFooter({ text: 'Tidak ada aksi perbaikan otomatis untuk jenis error ini. Perbaikan kode tetap perlu dilakukan manual.' });
        return interaction.editReply({ embeds: [embed] });
      } catch (err) {
        console.error('[botadmin explain] Gagal:', err.message);
        return interaction.editReply({ embeds: [errorEmbed(`Gagal minta penjelasan dari AI: ${err.message}`)] }).catch(() => {});
      }
    }
  },
};
