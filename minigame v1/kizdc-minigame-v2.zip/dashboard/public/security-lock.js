/* ============================================================================
 * KIZHOO ADVENTURE — SECURITY LOCK (client-side anti-clone)
 * ----------------------------------------------------------------------------
 * Dimuat PERTAMA sebelum semua script game. Tugasnya:
 *   1. Verifikasi halaman ini benar-benar berjalan di domain resmi
 *      (daftar domain disuntik server lewat /security-lock.js atau diambil
 *      dari /api/security/manifest).
 *   2. Blokir skenario kloningan umum: file:// hasil "save as", domain asing,
 *      di-iframe situs lain.
 *   3. Menyediakan window.__kzSecGate() — game client menolak boot kalau gate ini
 *      tidak ada / mengembalikan false. Menghapus file ini = game mati.
 *   4. Melindungi aset ringan: context-menu di canvas + drag gambar.
 *
 * Situs resmi lolos otomatis: localhost, IP LAN pribadi, *.trycloudflare.com
 * (tunnel bawaan bot), *.space-z.ai, plus domain yang didaftarkan owner di
 * ALLOWED_DOMAINS / DASHBOARD_REDIRECT_URL.
 * ========================================================================== */
(function () {
  'use strict';

  window.__KZ_SEC_CFG = null; // disuntik oleh server (dashboard/server.js)

  var DEFAULT_ALLOW = [
    'localhost', '127.0.0.1', '::1',
    '*.trycloudflare.com', '*.space-z.ai', '*.localhost',
    '*.local', '*.lan', '*.internal'
  ];

  function hostOk(host) {
    if (!host) return false;
    host = String(host).toLowerCase().split(':')[0];
    // IP privat / LAN: pemilik sah membuka dari perangkat lain di jaringan sendiri.
    if (/^10\.\d+\.\d+\.\d+$/.test(host)) return true;
    if (/^192\.168\.\d+\.\d+$/.test(host)) return true;
    if (/^172\.(1[6-9]|2\d|3[01])\.\d+\.\d+$/.test(host)) return true;
    if (/^\[?[0-9a-f:]+\]?$/.test(host) && /^(::1|f[ec][0-9a-f]|fe80)/i.test(host)) return true;
    var list = (cfg && cfg.domains && cfg.domains.length) ? cfg.domains.concat(DEFAULT_ALLOW) : DEFAULT_ALLOW;
    for (var i = 0; i < list.length; i++) {
      var p = String(list[i]).toLowerCase();
      if (p.charAt(0) === '*') { if (host.slice(-(p.length - 1)) === p.slice(1)) return true; }
      else if (host === p) return true;
    }
    return false;
  }

  var cfg = window.__KZ_SEC_CFG || null; // manifest domain (disuntik server saat serve)
  var verdict = null;     // null=belum divalidasi, true=resmi, false=kloningan

  function decide() {
    if (verdict !== null) return verdict;
    var loc = window.location;
    // file:// = hasil "Save Page As" / situs bajakan offline -> blokir.
    if (loc.protocol === 'file:' || loc.protocol === 'about:') { verdict = false; return false; }
    verdict = hostOk(loc.hostname);
    return verdict;
  }

  // ---- Overlay anti-pirasi (dipasang HANYA saat terdeteksi kloningan) ----
  function overlay() {
    var official = (cfg && cfg.official) || '';
    var d = document;
    function paint() {
      var o = d.getElementById('kz-antipiracy');
      if (!o) {
        d.body && (d.body.innerHTML = '');
        o = d.createElement('div');
        o.id = 'kz-antipiracy';
        o.setAttribute('style', [
          'position:fixed', 'inset:0', 'z-index:2147483647',
          'display:flex', 'flex-direction:column', 'align-items:center', 'justify-content:center',
          'gap:18px', 'padding:32px', 'text-align:center',
          'background:radial-gradient(circle at 50% 35%, #2a1215 0%, #0a0f1c 70%)',
          'color:#f8fafc',
          'font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace'
        ].join(';'));
        o.innerHTML =
          '<div style="font-size:clamp(18px,4vw,30px);letter-spacing:3px;color:#fca5a5;font-weight:700">' +
          'SITUS TIDAK RESMI</div>' +
          '<div style="max-width:520px;line-height:1.7;font-size:14px;color:#cbd5e1">' +
          'Halaman ini adalah salinan tidak resmi dari <b>Kizhoo Adventure</b>.' +
          '<br>Data akun kamu TIDAK aman di situs ini (pencuri bisa membaca login Discord-mu).' +
          '<br>Main hanya di alamat resmi yang diterbitkan pemilik game.</div>' +
          (official
            ? '<a href="' + official.replace(/"/g, '&quot;') + '" style="display:inline-block;padding:12px 26px;' +
              'background:linear-gradient(180deg,#fde68a,#f2c230);color:#1a1207;border-radius:10px;' +
              'font-weight:700;text-decoration:none;font-size:15px">Buka Situs Resmi</a>'
            : '') +
          '<div style="font-size:11px;color:#64748b">Kizhoo Adventure - dilindungi sistem keamanan anti-kloning</div>';
        (d.body || d.documentElement).appendChild(o);
      }
    }
    paint();
    // Re-assert: kalau script kloner menghapus overlay, pasang lagi.
    setInterval(paint, 2000);
  }

  // ---- Frame-busting: jangan biarkan situs lain mengandung game ini ----
  function bustFrames() {
    try { if (window.top !== window.self) window.top.location = window.self.location; } catch (_) {}
  }

  // ---- Gate untuk game client (dibundel bersama halaman game) ----
  window.__kzSecGate = function () {
    if (decide()) return true;
    bustFrames();
    overlay();
    return false;
  };

  // ---- Eksekusi awal ----
  if (decide()) {
    bustFrames(); // domain resmi tidak mungkin di-iframe (header server), just in case
    // Pelindung aset ringan (tidak mengganggu player).
    document.addEventListener('contextmenu', function (e) {
      var t = e.target;
      if (t && (t.tagName === 'CANVAS' || (t.tagName === 'IMG' && t.closest && t.closest('#game')))) e.preventDefault();
    }, true);
    document.addEventListener('dragstart', function (e) {
      var t = e.target;
      if (t && t.tagName === 'IMG') e.preventDefault();
    }, true);
    try {
      console.log('%cKizhoo Adventure %c- domain resmi terverifikasi',
        'color:#f2c230;font-weight:bold', 'color:#8b96ab');
    } catch (_) {}
  } else {
    // Blok secepat mungkin, lalu isi manifest untuk tahu alamat resmi.
    bustFrames();
    overlay();
    fetch('/api/security/manifest', { credentials: 'omit' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (m) { if (m && m.official) { cfg = m; overlay(); } })
      .catch(function () {});
    // Blokir navigasi keluar scripts lain tidak bisa; cukup pastikan gate false.
  }

  // ---- Ambil manifest (kalau belum disuntik server) untuk verifikasi ulang ----
  if (!cfg) {
    fetch('/api/security/manifest', { credentials: 'omit' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (m) {
        if (!m) return;
        cfg = m;
        // Verifikasi ulang: kalau setelah tahu daftar domain ternyata host ini
        // tidak terdaftar (mis. kloner men-redirect API), matikan gate.
        if (verdict === true && !hostOk(window.location.hostname)) {
          verdict = false;
          window.__kzSecGate = function () { overlay(); return false; };
          overlay();
        }
      })
      .catch(function () {});
  }
})();
