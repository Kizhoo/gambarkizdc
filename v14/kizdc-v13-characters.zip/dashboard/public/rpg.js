/* ============================================================================
 * KIZHOO ADVENTURE — RPG Web (Phaser 3) — v2 "Archer Update"
 * ----------------------------------------------------------------------------
 * Game RPG 2D bergaya Terraria: lobby, pemilihan class, kustomisasi karakter,
 * mode Quest (battle turn-based), mode Dungeon (platformer multi-lantai dengan
 * peti rarity & mimic), pandai besi, skill tree, achievement, teman + lobby
 * multiplayer, chat global/teman/lobby, leaderboard, dan profil.
 *
 * Prinsip desain:
 *   - TANPA EMOJI — semua ikon ASET PNG pixel (assets/icons + ui/icons, di-tint).
 *   - Server-authoritative: mode server memvalidasi semua reward di backend.
 *   - Mode demo (tanpa server bot) tetap jalan penuh lewat localStorage.
 *
 * Data layer: mode "demo" menyimpan progres di localStorage. Bila di-host lewat
 * dashboard bot (window.RPG_CONFIG.server = true), semua data lewat API
 * /api/rpg/* — lihat utils/rpgServer.js. Struktur file ini:
 *   1. Config & util           6. Scene: Boot/Login/Lobby/Class/QuestBoard
 *   2. Data game               7. Scene: QuestBattle (animasi skill)
 *   3. Data layer & realtime   8. Scene: DungeonSelect/Dungeon (platformer)
 *   4. Tekstur & ikon vektor   9. Scene: Inventory/SkillTree/Forge
 *   5. UI helper & background 10. Scene: Board/Profile/Ach/Friends/Lobby/Party
 *                             11. Konfig game + error handler
 * ============================================================================
 */

'use strict';

// ============================ SECURITY GATE =================================
// Game hanya boleh jalan di domain resmi. Dua sumber verifikasi:
//   1. security-lock.js (window.__kzSecGate) — dimuat paling awal di rpg.html.
//   2. window.__KZ_SEC_BAKE — daftar domain resmi yang disuntik LANGSUNG oleh
//      server bot asli saat serve /rpg (kloner statis tidak punya suntikan ini).
// Kalau kloner menghapus security-lock.js maupun memalsukan gate, sumber kedua
// tetap menahan. Jangan mengubah bagian ini.
(function () {
  var ok = false;
  try { ok = typeof window.__kzSecGate === 'function' && window.__kzSecGate() !== false; } catch (_) {}
  if (!ok) {
    var bake = window.__KZ_SEC_BAKE;
    if (bake && bake.domains) {
      var h = String(window.location.hostname || '').toLowerCase();
      for (var i = 0; i < bake.domains.length; i++) {
        var p = String(bake.domains[i]).toLowerCase();
        if (p.charAt(0) === '*' ? h.slice(-(p.length - 1)) === p.slice(1) : h === p) { ok = true; break; }
      }
    }
  }
  if (!ok) {
    try {
      var el = document.getElementById('game');
      if (el) el.innerHTML = '';
    } catch (_) {}
    throw new Error('KIZHOO ADVENTURE hanya bisa dimainkan di domain resmi.');
  }
})();
window.__kzRpgLoaded = true; // penanda utk fallback loader di rpg.html

// ============================ BUILD STAMP ===================================
// Identitas versi build game. WAJIB identik dengan:
//   - <meta name="kz-build"> di rpg.html
//   - GAME_BUILD di utils/rpgServer.js  (endpoint /api/rpg/build-info)
// Dipakai Deploy Guard: mendeteksi file campur antar versi (rpg.html baru +
// rpg.js lama dsb.) sehingga TIDAK ADA lagi "game tiba-tiba jelek diam-diam"
// akibat sisa file lama di hosting. Versi lama (sebelum stamp ini ada) tidak
// punya window.KZ_BUILD -> langsung terdeteksi oleh rpg.html.
const KZ_BUILD = '2026.09.28-1';
window.KZ_BUILD = KZ_BUILD;

// ============================ SPLASH GUARD v13 ==============================
// Kasus lapangan (screenshot user "v12 erro"): splash "MEMUAT DUNIA..."
// menutupi game yang SEBENARNYA sudah jalan di belakangnya (transisi CSS
// opacity mentok di perangkat lemot / tab di-background lama / jalur scene
// yang tidak menyembunyikan splash). Perbaikan sistemik:
//   1. kzSplashHide: class hidden + display:none terkatrol (kompositor tidak
//      bisa membekukannya) — dipanggil dari EVERY scene create (withSceneFX).
//   2. kzSplashShow: membatalkan keduanya (dipakai showFatal / pemulihan FBO).
//   3. Watchdog DOM di rpg.html memaksa menutup bila game hidup tapi splash
//      masih tampak, dan menawarkan muat ulang bila macet total.
window.kzSplashHide = function () {
  try {
    window.__kzSplashDone = true; // watchdog muat berhenti menunggu
    var b = document.getElementById('boot');
    if (!b || b.classList.contains('hidden')) return;
    b.classList.add('hidden');
    setTimeout(function () { try { if (b.classList.contains('hidden')) b.style.display = 'none'; } catch (_) {} }, 650);
  } catch (_) {}
};
window.kzSplashShow = function () {
  try {
    var b = document.getElementById('boot');
    if (!b) return;
    b.style.display = ''; // kembali ke display:flex dari CSS
    b.classList.remove('hidden');
  } catch (_) {}
};

// ============================ DEPLOY GUARD ==================================
// Banner diagnostik NON-Phaser (DOM, tampil di atas canvas di scene mana pun).
// Tujuan: masalah deploy (aset hilang / file campur versi / server-client
// beda build) HARUS terlihat jelas — bukan "game jadi jelek misterius".
window.showDeployBanner = function (title, detail, kind) {
  try {
    if (document.getElementById('kzDeployBanner')) return;
    var b = document.createElement('div');
    b.id = 'kzDeployBanner';
    b.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:99999;pointer-events:auto;'
      + 'font:12px/1.55 ui-sans-serif,system-ui,Segoe UI,Roboto,sans-serif;'
      + 'background:' + (kind === 'warn' ? '#7c2d12' : '#991b1b') + ';color:#fecaca;'
      + 'border-bottom:3px solid ' + (kind === 'warn' ? '#f59e0b' : '#ef4444') + ';'
      + 'padding:10px 14px;display:flex;gap:12px;align-items:center;justify-content:center;flex-wrap:wrap;';
    var t = document.createElement('div');
    t.style.cssText = 'max-width:860px;text-align:center';
    t.innerHTML = '<b style="color:#fde68a">' + String(title).replace(/[<>&]/g, '') + '</b><br>'
      + String(detail).replace(/[<>&]/g, '');
    var btn = document.createElement('button');
    btn.textContent = 'Muat Ulang';
    btn.style.cssText = 'padding:8px 16px;font:700 12px ui-monospace,monospace;color:#fde68a;background:#1f2937;border:2px solid #f59e0b;cursor:pointer';
    btn.onclick = function () { location.reload(); };
    var x = document.createElement('button');
    x.textContent = 'Tutup';
    x.style.cssText = 'padding:8px 12px;font:700 12px ui-monospace,monospace;color:#cbd5e1;background:#111827;border:2px solid #475569;cursor:pointer';
    x.onclick = function () { b.remove(); };
    b.appendChild(t); b.appendChild(btn); b.appendChild(x);
    (document.body || document.documentElement).appendChild(b);
    console.error('[DEPLOY GUARD]', title, detail);
  } catch (_) {}
};

/* ============================================================================
 * 1. KONFIGURASI RUNTIME + UTIL
 * ========================================================================== */
const CFG = window.RPG_CONFIG || { server: false, userId: null, guildId: null, apiBase: '' };

const R = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
const RF = (a, b) => a + Math.random() * (b - a);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const fmt = (n) => (Math.round(Number(n) || 0)).toLocaleString('id-ID');
const dist2 = (x1, y1, x2, y2) => (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2);
const hex = (n) => '#' + Number(n >>> 0).toString(16).padStart(6, '0');
// Font stack tanpa emoji: teks murni + angka.
// F_HEAD  : judul besar (pixel chunky ala konsol retro).
// F_PIX   : label/HUD/tombol/angka (pixel ringkas — terbaca sampai ukuran kecil).
// F_UI    : deskripsi & kalimat panjang (sans bersih — kenyamanan baca).
const F_HEAD = "'Press Start 2P', ui-monospace, monospace";
const F_PIX = "'Silkscreen', 'Press Start 2P', ui-monospace, monospace";
const F_UI = 'system-ui, "Segoe UI", Roboto, sans-serif';
// Palet UI terpusat — satu sumber kebenaran agar seluruh 23 scene seragam.
const PAL = {
  ink: 0x0a0f1c, ink2: 0x0b1220, panel: 0x101828, panelHi: 0x1b2740,
  line: 0x2a3650, gold: 0xf2c230, goldHi: 0xfde68a, goldDk: 0xb45309,
  text: '#f8fafc', muted: '#8b96ab', green: 0x16a34a, red: 0xdc2626,
};

/* ============================================================================
 * 2. DATA GAME (class, skill tree, monster, item, dungeon — cermin rpgWorld.js)
 * ========================================================================== */
/* ---------- v12 §5: DEPTH TOKENS — satu sumber kebenaran z-order ----------
 * Urut: latar -> unit -> FX -> HUD -> panel -> toast. Nilai = angka lama yang
 * sudah terbukti benar (migrasi tanpa regresi); kode baru WAJIB pakai token
 * agar layering tidak pernah lagi saling menimpa acak. */
const DEPTH = {
  FAR_BG: -100, BG: 0, TERRAIN: 20, DECO: 40, SHADOW: 48,
  UNIT_BACK: 55, UNIT: 60, UNIT_FRONT: 70, BARS: 75,
  FX_BACK: 79, FX: 80, FX_MID: 85, FX_FRONT: 88, FX_SCREEN: 880,
  HUD: 900, VIGNETTE: 899, CONTROLS: 1000, PROMPT: 1502,
  PANEL: 2000, SUBPANEL: 2100, CINEMA: 2950, TOAST: 4000,
};
// v12 §6: finisher khas class — dibuka meter ULTIMATE penuh (sinematik).
const HERO_ULTS = {
  warrior: { name: 'GERGAJI COLOSSUS', fx: 'spin', power: 2.6, color: '#f97316' },
  mage:    { name: 'SUPERNOVA ARKANA', fx: 'meteor', power: 2.8, color: '#a78bfa' },
  archer:  { name: 'HUJAN BINTANG', fx: 'arrowrain', power: 2.5, color: '#fde047' },
  assassin:{ name: 'SERIBU BAYANG', fx: 'flurry', power: 2.7, color: '#c084fc' },
};
/* v12 §5: hit-stop — bekuan 1-3 frame saat impact keras (game feel). */
function battleHitStop(scene, ms = 70) {
  if (!scene) return;
  try {
    if ((scene.__hitStopUntil || 0) > scene.time.now) return;
    scene.__hitStopUntil = scene.time.now + ms + 40;
    scene.time.paused = true;
    scene.tweens.pauseAll();
    setTimeout(() => { try { scene.time.paused = false; scene.tweens.resumeAll(); } catch (_) {} }, ms);
  } catch (_) {}
}
/* v12 §5: cinematic ultimate — slow-motion singkat + vignette + judul + zoom,
 * lalu snap kembali ke kecepatan normal. Dipakai finisher hero & pet. */
function cinematicUltimate(scene, opts = {}) {
  return new Promise((res) => {
    let done = false;
    const finish = () => { if (!done) { done = true; res(); } };
    try {
      const W = scene.scale.width, H = scene.scale.height;
      const col = toColorInt(opts.color, 0xf59e0b);
      const veil = scene.add.rectangle(W / 2, H / 2, W, H, 0x000000, 0.42).setScrollFactor(0).setDepth(DEPTH.CINEMA);
      const ring = scene.add.image(W / 2, H / 2, scene.textures.exists('fx_tex_ring') ? 'fx_tex_ring' : 'fx_tex_flash').setTint(col).setBlendMode(Phaser.BlendModes.ADD).setScrollFactor(0).setDepth(DEPTH.CINEMA + 1).setScale(0.2).setAlpha(0.8);
      const title = scene.add.text(W / 2, H * 0.30, opts.name || 'ULTIMATE', { fontFamily: F_HEAD, fontSize: '20px', color: hex(col), stroke: '#0b0b12', strokeThickness: 6 }).setOrigin(0.5).setScrollFactor(0).setDepth(DEPTH.CINEMA + 2).setScale(0.3);
      scene.tweens.add({ targets: title, scale: 1, duration: 260, ease: 'Back.easeOut' });
      scene.tweens.add({ targets: ring, scale: Math.max(W, H) / 200, alpha: 0, duration: 700, ease: 'Quad.easeOut' });
      scene.time.timeScale = 0.22;
      scene.tweens.timeScale = 0.3;
      try { scene.cameras.main.zoomTo(1.045, 240, 'Sine.easeOut'); } catch (_) {}
      setTimeout(() => {
        try {
          scene.time.timeScale = 1; scene.tweens.timeScale = 1;
          try { scene.cameras.main.zoomTo(1, 180, 'Sine.easeInOut'); } catch (_) {}
          scene.tweens.add({ targets: [veil, title], alpha: 0, duration: 240, onComplete: () => { veil.destroy(); title.destroy(); } });
        } catch (_) {}
        finish();
      }, opts.dur || 900);
      setTimeout(finish, (opts.dur || 900) + 600); // pengaman: tidak pernah menggantung
    } catch (e) { finish(); }
  });
}
const CLASSES = {
  warrior: {
    key: 'warrior', name: 'Warrior', color: 0xDC2626, role: 'Tank / DPS Fisik',
    desc: 'Prajurit garis depan. HP dan pertahanan tebal, jago bertahan sambil memukul keras.',
    base: { hp: 140, mp: 30, atk: 18, def: 16, spd: 8, crit: 5 },
    growth: { hp: 16, mp: 3, atk: 3.2, def: 2.8, spd: 0.6, crit: 0.2 },
  },
  mage: {
    key: 'mage', name: 'Mage', color: 0x7C3AED, role: 'Burst Sihir / AoE / Penyembuh',
    desc: 'Penyihir serba bisa. Ledakan sihir besar, serangan area, sampai menyembuhkan diri dan tim.',
    base: { hp: 90, mp: 90, atk: 22, def: 8, spd: 10, crit: 8 },
    growth: { hp: 9, mp: 9, atk: 4.0, def: 1.2, spd: 0.8, crit: 0.35 },
  },
  assassin: {
    key: 'assassin', name: 'Assassin', color: 0x059669, role: 'Crit / Evasion / DoT',
    desc: 'Pembunuh gesit. Critical dan kecepatan tinggi, menghindar dan meracuni lawan.',
    base: { hp: 105, mp: 50, atk: 20, def: 10, spd: 16, crit: 15 },
    growth: { hp: 11, mp: 5, atk: 3.6, def: 1.6, spd: 1.4, crit: 0.6 },
  },
  archer: {
    key: 'archer', name: 'Archer', color: 0x65A30D, role: 'DPS Jarak Jauh / Crit',
    desc: 'Pemanah berhati dingin. Menghujani musuh dari jauh dengan panah presisi dan racun.',
    base: { hp: 100, mp: 55, atk: 21, def: 9, spd: 14, crit: 12 },
    growth: { hp: 10, mp: 5, atk: 3.7, def: 1.3, spd: 1.1, crit: 0.5 },
  },
};
const CLASS_KEYS = Object.keys(CLASSES);
// v12: elemen serangan dasar per class (petunjuk strategi sejak giliran 1).
const CLASS_ELEM = { warrior: 'fire', mage: 'void', assassin: 'dark', archer: 'wind' };

// Tier item (rarity) — urutan menentukan bobot drop.
const TIERS = {
  common:    { name: 'Umum',       color: 0x9CA3AF },
  uncommon:  { name: 'Lumayan',    color: 0x4ADE80 },
  rare:      { name: 'Langka',     color: 0x38BDF8 },
  epic:      { name: 'Epik',       color: 0xA855F7 },
  legendary: { name: 'Legendaris', color: 0xFACC15 },
  mythic:    { name: 'Mistik',     color: 0xFF4D8F },
};
const TIER_ORDER = ['common', 'uncommon', 'rare', 'epic', 'legendary', 'mythic'];
const tierIndex = (t) => Math.max(0, TIER_ORDER.indexOf(t));
const tierInfo = (t) => TIERS[t] || TIERS.common;

const MONSTERS = [
  { id: 'slime',    name: 'Slime',           tier: 'normal', level: 3,  hp: 90,   atk: 12, def: 6,  xp: 60,  gold: 25,  color: 0x4ade80, element: 'water' },
  { id: 'goblin',   name: 'Goblin Scout',    tier: 'normal', level: 6,  hp: 150,  atk: 20, def: 10, xp: 110, gold: 45,  color: 0x86efac, element: 'nature' },
  { id: 'wolf',     name: 'Dire Wolf',       tier: 'normal', level: 10, hp: 240,  atk: 30, def: 14, xp: 180, gold: 70,  color: 0x94a3b8, element: 'nature' },
  { id: 'skeleton', name: 'Kerangka Hidup',  tier: 'normal', level: 12, hp: 280,  atk: 34, def: 16, xp: 220, gold: 85,  color: 0xe5e7eb, element: 'dark' },
  { id: 'orc',      name: 'Orc Warrior',     tier: 'elite',  level: 16, hp: 480,  atk: 44, def: 22, xp: 340, gold: 140, color: 0x65a30d, element: 'nature' },
  { id: 'golem',    name: 'Stone Golem',     tier: 'elite',  level: 24, hp: 900,  atk: 55, def: 40, xp: 620, gold: 260, color: 0x78716c, element: 'earth' },
  { id: 'wraith',   name: 'Shadow Wraith',   tier: 'elite',  level: 32, hp: 1200, atk: 78, def: 30, xp: 940, gold: 380, color: 0x7c3aed, element: 'dark' },
  { id: 'minotaur', name: 'Minotaur Boss',   tier: 'boss',   level: 40, hp: 3200, atk: 105,def: 55, xp: 2200,gold: 900, color: 0xb45309, element: 'fire' },
  { id: 'dragon',   name: 'Ancient Dragon',  tier: 'boss',   level: 60, hp: 7000, atk: 160,def: 80, xp: 5200,gold: 2400,color: 0xdc2626, element: 'fire' },
  { id: 'demonlord',name: 'Demon Lord',      tier: 'worldboss', level: 80, hp: 20000, atk: 240, def: 120, xp: 14000, gold: 8000, color: 0x7f1d1d, element: 'void' },
  { id: 'rat',      name: 'Skeletal Rat',    tier: 'normal', level: 4,  hp: 100,  atk: 15, def: 7,  xp: 75,  gold: 30,  color: 0xa8a29e, element: 'dark' },
  { id: 'bat',      name: 'Abyss Bat',       tier: 'normal', level: 5,  hp: 120,  atk: 18, def: 8,  xp: 95,  gold: 38,  color: 0x818cf8, element: 'dark' },
  { id: 'spider',   name: 'Giant Spider',    tier: 'normal', level: 7,  hp: 170,  atk: 24, def: 12, xp: 140, gold: 55,  color: 0x475569, element: 'poison' },
  { id: 'snake',    name: 'Raja Ular',       tier: 'normal', level: 8,  hp: 190,  atk: 25, def: 12, xp: 150, gold: 58,  color: 0x65a30d, element: 'poison' },
  { id: 'imp',      name: 'Fire Imp',        tier: 'normal', level: 9,  hp: 210,  atk: 27, def: 13, xp: 160, gold: 62,  color: 0xf97316, element: 'fire' },
  { id: 'turtle',   name: 'Giant Turtle',    tier: 'elite',  level: 14, hp: 420,  atk: 30, def: 28, xp: 300, gold: 120, color: 0x14b8a6, element: 'water' },
  { id: 'gargoyle', name: 'Abyss Gargoyle',  tier: 'elite',  level: 18, hp: 540,  atk: 48, def: 30, xp: 380, gold: 160, color: 0x64748b, element: 'dark' },
  { id: 'yeti',     name: 'Frost Yeti',      tier: 'boss',   level: 45, hp: 4200, atk: 120,def: 60, xp: 2600,gold: 1100,color: 0x93c5fd, element: 'ice' },
  { id: 'hyena',    name: 'Hyena Gurun',     tier: 'normal', level: 9,  hp: 205,  atk: 26, def: 12, xp: 155, gold: 60,  color: 0xd4a373, element: 'nature' },
  { id: 'scorpion', name: 'Kalajengking',    tier: 'normal', level: 11, hp: 235,  atk: 30, def: 16, xp: 185, gold: 72,  color: 0xb45309, element: 'poison' },
  { id: 'vulture',  name: 'Burung Nasar',    tier: 'normal', level: 13, hp: 260,  atk: 34, def: 14, xp: 215, gold: 82,  color: 0x78350f, element: 'wind' },
  { id: 'mummy',    name: 'Mumi Purba',      tier: 'elite',  level: 20, hp: 560,  atk: 50, def: 26, xp: 400, gold: 170, color: 0xcbb271, element: 'dark' },
  { id: 'deceased', name: 'Mayat Hidup',     tier: 'elite',  level: 26, hp: 820,  atk: 60, def: 32, xp: 640, gold: 270, color: 0x6b7280, element: 'dark' },
];
const monsterById = (id) => MONSTERS.find((m) => m.id === id) || MONSTERS[0];
const MONSTER_DROPS = {
  slime: [{ id: 'm_slime_jelly', rate: 0.7 }], goblin: [{ id: 'm_goblin_ear', rate: 0.6 }],
  wolf: [{ id: 'm_wolf_pelt', rate: 0.6 }], skeleton: [{ id: 'm_bone', rate: 0.7 }],
  orc: [{ id: 'm_orc_tusk', rate: 0.5 }], golem: [{ id: 'm_golem_core', rate: 0.4 }],
  wraith: [{ id: 'm_wraith_ecto', rate: 0.4 }], minotaur: [{ id: 'm_minotaur_horn', rate: 0.5 }],
  dragon: [{ id: 'm_dragon_scale', rate: 0.6 }], demonlord: [{ id: 'm_demon_heart', rate: 0.7 }],
  rat: [{ id: 'm_rat_tail', rate: 0.6 }], bat: [{ id: 'm_bat_wing', rate: 0.6 }],
  spider: [{ id: 'm_venom_sac', rate: 0.5 }], snake: [{ id: 'm_venom_sac', rate: 0.5 }],
  imp: [{ id: 'm_imp_ember', rate: 0.5 }], turtle: [{ id: 'm_turtle_shell', rate: 0.5 }],
  gargoyle: [{ id: 'm_gargoyle_shard', rate: 0.5 }], yeti: [{ id: 'm_yeti_fur', rate: 0.6 }],
  hyena: [{ id: 'm_hyena_fang', rate: 0.5 }], scorpion: [{ id: 'm_venom_sac', rate: 0.5 }],
  vulture: [{ id: 'm_vulture_feather', rate: 0.5 }], mummy: [{ id: 'm_mummy_bandage', rate: 0.5 }],
  deceased: [{ id: 'm_bone', rate: 0.5 }],
};

// ---------- SKILL TREE (cermin utils/rpgData.js — server memvalidasi sama) ----------
const SKILL_TREES = {
  warrior: [
    { id: 'w_slash', name: 'Power Slash', type: 'active', tier: 1, reqLevel: 1, maxLevel: 5, cost: 1, requires: [], effect: { dmg: 1.4, mp: 8 }, fx: { kind: 'slash', color: '#f97316', elem: 'fire' }, desc: 'Tebasan kuat 140% ATK. Naik +12% per level.' },
    { id: 'w_guard', name: 'Iron Guard', type: 'passive', tier: 1, reqLevel: 1, maxLevel: 5, cost: 1, requires: [], effect: { defPct: 0.06 }, fx: { kind: 'passive', color: '#94a3b8' }, desc: 'DEF pasif +6% per level.' },
    { id: 'w_taunt', name: 'Taunt', type: 'active', tier: 2, reqLevel: 8, maxLevel: 3, cost: 1, requires: ['w_guard'], effect: { shield: 0.1, turns: 2, mp: 10 }, fx: { kind: 'shield', color: '#fbbf24' }, desc: 'Menghina musuh lalu berdiri kokoh: perisai 10% HP maks.' },
    { id: 'w_cleave', name: 'Cleave', type: 'active', tier: 2, reqLevel: 12, maxLevel: 5, cost: 1, requires: ['w_slash'], effect: { dmg: 1.1, aoe: true, mp: 14 }, fx: { kind: 'cleave', color: '#f97316', elem: 'fire' }, desc: 'Sabetan luas: 110% ATK ke semua musuh.' },
    { id: 'w_tough', name: 'Toughness', type: 'passive', tier: 2, reqLevel: 10, maxLevel: 5, cost: 1, requires: ['w_guard'], effect: { hpPct: 0.05 }, fx: { kind: 'passive', color: '#ef4444' }, desc: 'HP maks pasif +5% per level.' },
    { id: 'w_whirl', name: 'Whirlwind', type: 'active', tier: 3, reqLevel: 20, maxLevel: 5, cost: 2, requires: ['w_cleave'], effect: { dmg: 1.5, aoe: true, mp: 22 }, fx: { kind: 'spin', color: '#fdba74', elem: 'fire' }, desc: 'Berputar seperti badai: 150% ATK ke semua musuh.' },
    { id: 'w_berserk', name: 'Berserker Rage', type: 'active', tier: 3, reqLevel: 25, maxLevel: 3, cost: 2, requires: ['w_cleave', 'w_taunt'], effect: { atkBuff: 0.3, turns: 3, mp: 25 }, fx: { kind: 'rage', color: '#dc2626', elem: 'fire' }, desc: 'Amukan membara: ATK +30% selama 3 giliran.' },
    { id: 'w_warlord', name: 'Warlord Cry', type: 'active', tier: 4, reqLevel: 35, maxLevel: 3, cost: 2, requires: ['w_whirl'], effect: { atkBuff: 0.2, shield: 0.15, turns: 3, mp: 30 }, fx: { kind: 'banner', color: '#f59e0b', elem: 'solar' }, desc: 'Sorakan perang: ATK +20% dan perisai 15% HP untuk satu giliran penuh.' },
    { id: 'w_last', name: 'Last Stand', type: 'passive', tier: 4, reqLevel: 40, maxLevel: 1, cost: 3, requires: ['w_berserk'], effect: { reviveHp: 0.25 }, fx: { kind: 'passive', color: '#fbbf12' }, desc: 'Sekali per battle: bertahan di 1 HP lalu pulih 25% HP.' },
    { id: 'w_colossus', name: 'Colossus', type: 'passive', tier: 4, reqLevel: 45, maxLevel: 3, cost: 3, requires: ['w_warlord'], effect: { defPct: 0.1, thorns: 0.08 }, fx: { kind: 'passive', color: '#a16207' }, desc: 'Tubuh raksasa: DEF +10% dan memantulkan 8% damage per level.' },
  ],
  mage: [
    { id: 'm_fire', name: 'Fireball', type: 'active', tier: 1, reqLevel: 1, maxLevel: 5, cost: 1, requires: [], effect: { dmg: 1.6, mp: 12 }, fx: { kind: 'fireball', color: '#f97316', elem: 'fire' }, desc: 'Bola api 160% ATK sihir ke satu musuh.' },
    { id: 'm_focus', name: 'Arcane Focus', type: 'passive', tier: 1, reqLevel: 1, maxLevel: 5, cost: 1, requires: [], effect: { atkPct: 0.06 }, fx: { kind: 'passive', color: '#a78bfa' }, desc: 'ATK sihir pasif +6% per level.' },
    { id: 'm_regen', name: 'Regeneration', type: 'active', tier: 2, reqLevel: 8, maxLevel: 5, cost: 1, requires: ['m_focus'], effect: { heal: 1.3, mp: 10 }, fx: { kind: 'heal', color: '#4ade80', elem: 'light' }, desc: 'Menjahit luka dengan sihir: pulihkan 130% ATK sebagai HP diri.' },
    { id: 'm_frost', name: 'Frost Nova', type: 'active', tier: 2, reqLevel: 10, maxLevel: 5, cost: 1, requires: ['m_fire'], effect: { dmg: 1.1, aoe: true, slow: true, mp: 20 }, fx: { kind: 'frost', color: '#7dd3fc', elem: 'ice' }, desc: 'Ledakan es: 110% ATK ke semua musuh + memperlambat.' },
    { id: 'm_shield', name: 'Mana Shield', type: 'active', tier: 3, reqLevel: 12, maxLevel: 3, cost: 1, requires: ['m_focus'], effect: { absorbMp: true, mp: 18 }, fx: { kind: 'manashield', color: '#60a5fa', elem: 'void' }, desc: 'Selubung mana menyerap damage memakai MP.' },
    { id: 'm_bloom', name: 'Bloom of Life', type: 'active', tier: 3, reqLevel: 18, maxLevel: 5, cost: 2, requires: ['m_regen'], effect: { healAoe: 0.9, turns: 3, mp: 24 }, fx: { kind: 'bloom', color: '#34d399', elem: 'nature' }, desc: 'Sekuntum cahaya hidup: pulihkan 90% ATK untuk diri dan seluruh tim, plus regen 3 giliran.' },
    { id: 'm_meteor', name: 'Meteor', type: 'active', tier: 3, reqLevel: 28, maxLevel: 3, cost: 2, requires: ['m_frost'], effect: { dmg: 2.6, aoe: true, mp: 40 }, fx: { kind: 'meteor', color: '#fb923c', elem: 'fire' }, desc: 'Meteor jatuh: 260% ATK ke semua musuh.' },
    { id: 'm_timeflow', name: 'Time Flow', type: 'passive', tier: 4, reqLevel: 40, maxLevel: 3, cost: 3, requires: ['m_bloom'], effect: { healPct: 0.08, spdPct: 0.04 }, fx: { kind: 'passive', color: '#c084fc' }, desc: 'Waktu mengalir lambat: efek penyembuhan +8% dan SPD +4% per level.' },
    { id: 'm_arch', name: 'Archmage', type: 'passive', tier: 4, reqLevel: 45, maxLevel: 1, cost: 3, requires: ['m_meteor', 'm_shield'], effect: { critPct: 0.15, mpRegen: 10 }, fx: { kind: 'passive', color: '#8b5cf6' }, desc: 'Puncak ilmu sihir: crit +15% dan regen 10 MP tiap giliran.' },
    { id: 'm_void', name: 'Void Cascade', type: 'active', tier: 4, reqLevel: 50, maxLevel: 3, cost: 3, requires: ['m_meteor'], effect: { dmg: 2.0, aoe: true, hits: 2, mp: 55 }, fx: { kind: 'void', color: '#a855f7', elem: 'void' }, desc: 'Robekan kehampaan beruntun: dua gelombang 200% ATK ke semua musuh.' },
  ],
  assassin: [
    { id: 'a_strike', name: 'Shadow Strike', type: 'active', tier: 1, reqLevel: 1, maxLevel: 5, cost: 1, requires: [], effect: { dmg: 1.5, critBonus: 0.1, mp: 10 }, fx: { kind: 'dash', color: '#34d399', elem: 'dark' }, desc: 'Tikaman bayangan 150% ATK dengan crit +10%.' },
    { id: 'a_agi', name: 'Agility', type: 'passive', tier: 1, reqLevel: 1, maxLevel: 5, cost: 1, requires: [], effect: { spdPct: 0.06, evaPct: 0.03 }, fx: { kind: 'passive', color: '#6ee7b7' }, desc: 'SPD +6% dan peluang hindar +3% per level.' },
    { id: 'a_poison', name: 'Poison Blade', type: 'active', tier: 2, reqLevel: 10, maxLevel: 5, cost: 1, requires: ['a_strike'], effect: { dmg: 0.8, dot: 0.15, turns: 3, mp: 14 }, fx: { kind: 'poison', color: '#a3e635', elem: 'poison' }, desc: 'Bilah berlumpur racun: 80% ATK + racun 15% ATK per giliran.' },
    { id: 'a_smoke', name: 'Smoke Bomb', type: 'active', tier: 2, reqLevel: 14, maxLevel: 3, cost: 1, requires: ['a_agi'], effect: { evasion: 0.5, turns: 2, mp: 16 }, fx: { kind: 'smoke', color: '#94a3b8', elem: 'dark' }, desc: 'Bom asap: peluang hindar 50% selama 2 giliran.' },
    { id: 'a_flurry', name: 'Blade Flurry', type: 'active', tier: 3, reqLevel: 20, maxLevel: 5, cost: 2, requires: ['a_poison'], effect: { dmg: 0.65, hits: 3, mp: 18 }, fx: { kind: 'flurry', color: '#5eead4', elem: 'dark' }, desc: 'Tarian bilah: 3 serangan beruntun masing-masing 65% ATK.' },
    { id: 'a_assass', name: 'Assassinate', type: 'active', tier: 3, reqLevel: 30, maxLevel: 3, cost: 2, requires: ['a_poison'], effect: { dmg: 3.0, execute: 0.2, mp: 35 }, fx: { kind: 'execute', color: '#f43f5e', elem: 'dark' }, desc: 'Eksekusi mematikan: 300% ATK, diperkuat vs musuh sekarat.' },
    { id: 'a_phantom', name: 'Phantom Step', type: 'passive', tier: 4, reqLevel: 40, maxLevel: 3, cost: 3, requires: ['a_smoke'], effect: { evaPct: 0.04, spdPct: 0.05 }, fx: { kind: 'passive', color: '#22d3ee' }, desc: 'Melangkah tanpa jejak: hindar +4% dan SPD +5% per level.' },
    { id: 'a_venomlord', name: 'Venom Lord', type: 'passive', tier: 4, reqLevel: 42, maxLevel: 3, cost: 3, requires: ['a_flurry'], effect: { atkPct: 0.05, evaPct: 0.03 }, fx: { kind: 'passive', color: '#84cc16' }, desc: 'Racun mengalir di nadi: ATK +5% dan hindar +3% per level.' },
    { id: 'a_shadow', name: 'Shadow Master', type: 'passive', tier: 4, reqLevel: 45, maxLevel: 1, cost: 3, requires: ['a_assass', 'a_smoke'], effect: { critPct: 0.2, firstStrike: true }, fx: { kind: 'passive', color: '#10b981' }, desc: 'Satu dengan bayangan: crit +20% dan selalu bergerak duluan.' },
    { id: 'a_thousand', name: 'Thousand Cuts', type: 'active', tier: 4, reqLevel: 50, maxLevel: 3, cost: 3, requires: ['a_assass'], effect: { dmg: 0.5, hits: 6, critBonus: 0.1, mp: 42 }, fx: { kind: 'flurry', color: '#f472b6', elem: 'dark' }, desc: 'Seribu sayatan: 6 tebasan kilat 50% ATK dengan crit +10%.' },
  ],
  archer: [
    { id: 'ar_aim', name: 'Power Shot', type: 'active', tier: 1, reqLevel: 1, maxLevel: 5, cost: 1, requires: [], effect: { dmg: 1.5, mp: 8 }, fx: { kind: 'arrow', color: '#fbbf24', elem: 'wind' }, desc: 'Tarikan penuh: panah 150% ATK.' },
    { id: 'ar_eye', name: 'Hawkeye', type: 'passive', tier: 1, reqLevel: 1, maxLevel: 5, cost: 1, requires: [], effect: { critPct: 0.02 }, fx: { kind: 'passive', color: '#fde047' }, desc: 'Mata terlatih: crit +2% per level.' },
    { id: 'ar_pierce', name: 'Piercing Arrow', type: 'active', tier: 2, reqLevel: 10, maxLevel: 5, cost: 1, requires: ['ar_aim'], effect: { dmg: 1.3, pierce: 0.5, mp: 12 }, fx: { kind: 'arrow', color: '#f59e0b', elem: 'wind' }, desc: 'Panah berujung baja: 130% ATK yang menembus 50% pertahanan musuh.' },
    { id: 'ar_quick', name: 'Rapid Shot', type: 'active', tier: 2, reqLevel: 14, maxLevel: 5, cost: 1, requires: ['ar_eye'], effect: { dmg: 0.55, hits: 3, mp: 16 }, fx: { kind: 'arrow', color: '#a3e635', elem: 'wind' }, desc: 'Tiga panah beruntun, masing-masing 55% ATK.' },
    { id: 'ar_toxic', name: 'Toxic Arrow', type: 'active', tier: 3, reqLevel: 18, maxLevel: 5, cost: 1, requires: ['ar_pierce'], effect: { dmg: 0.9, dot: 0.18, turns: 3, mp: 15 }, fx: { kind: 'poison', color: '#84cc16', elem: 'poison' }, desc: 'Ujung panah dilumuri racun: 90% ATK + racun 18% ATK per giliran.' },
    { id: 'ar_multi', name: 'Arrow Rain', type: 'active', tier: 3, reqLevel: 22, maxLevel: 5, cost: 2, requires: ['ar_quick'], effect: { dmg: 1.0, aoe: true, mp: 20 }, fx: { kind: 'arrowrain', color: '#facc15', elem: 'wind' }, desc: 'Hujan panah: 100% ATK ke semua musuh.' },
    { id: 'ar_mark', name: 'Hunter Mark', type: 'active', tier: 4, reqLevel: 30, maxLevel: 3, cost: 2, requires: ['ar_toxic'], effect: { mark: 0.25, turns: 3, mp: 18 }, fx: { kind: 'mark', color: '#f43f5e' }, desc: 'Tanda pemburu: musuh bertanda menerima +25% damage selama 3 giliran.' },
    { id: 'ar_wind', name: 'Windwalker', type: 'passive', tier: 4, reqLevel: 45, maxLevel: 1, cost: 3, requires: ['ar_multi', 'ar_mark'], effect: { spdPct: 0.15, critPct: 0.1, firstStrike: true }, fx: { kind: 'passive', color: '#38bdf8' }, desc: 'Satu dengan angin: SPD +15%, crit +10%, dan selalu menembak duluan.' },
    { id: 'ar_snipe', name: 'Sniper Shot', type: 'active', tier: 4, reqLevel: 40, maxLevel: 3, cost: 3, requires: ['ar_mark'], effect: { dmg: 2.6, critBonus: 0.25, pierce: 0.3, mp: 30 }, fx: { kind: 'snipe', color: '#f87171', elem: 'wind' }, desc: 'Bidikan jitu dari kegelapan: 260% ATK, crit +25%, menembus 30% DEF.' },
    { id: 'ar_legend', name: 'Arrow of Legend', type: 'active', tier: 4, reqLevel: 50, maxLevel: 3, cost: 3, requires: ['ar_snipe'], effect: { dmg: 3.2, aoe: true, execute: 0.25, mp: 48 }, fx: { kind: 'arrowrain', color: '#fde047', elem: 'holy' }, desc: 'Panah legendaris: 320% ATK ke semua musuh, mengerikan vs yang sekarat.' },
  ],
};
function skillById(classKey, skillId) { return (SKILL_TREES[classKey] || []).find((s) => s.id === skillId) || null; }
// Skill level pemain (diisi dari server / localStorage saat load).
const SkillState = {
  levels: {},
  set(list) { this.levels = {}; for (const s of list || []) this.levels[s.id] = s.level; },
  get(id) { return this.levels[id] || 0; },
};

/* ============ SISTEM PET (klien) — katalog cermin utils/rpgData.js ============ */
const PET_LEVEL_CAP = 20;
const PETS = {
  ember:   { id: 'ember',   name: 'Ember',   species: 'Kitten Api',          element: 'fire',  rarity: 'common',    movement: 'ground', attackType: 'magic', role: 'dps',     color: '#fb923c',
             passive: { atk: { base: 4, growth: 1.2 } },
             skill: { name: 'Percikan Bara',       target: 'enemy', cd: 3, power: 1.15, effect: 'burn',       effectDesc: 'membakar musuh (damage tambahan 2 giliran)' },
             lore: 'Anak kucing lahir dari bara ritual kuno. Ekornya tak pernah padam, bahkan saat tidur di taskamu.' },
  bolt:    { id: 'bolt',    name: 'Bolt',    species: 'Anjing Petir',        element: 'bolt',  rarity: 'common',    movement: 'ground', attackType: 'melee', role: 'dps',     color: '#fde047',
             passive: { spd: { base: 4, growth: 1.0 } },
             skill: { name: 'Kilat Tack',          target: 'enemy', cd: 3, power: 1.2,  effect: 'stun10',     effectDesc: '10% peluang membuat musuh bingung 1 giliran' },
             lore: 'Anak anjing berbalut listrik statis. Menggigil kalau diajak main, haruskah kamu memeluknya?' },
  leafy:   { id: 'leafy',   name: 'Leafy',   species: 'Rubah Daun',          element: 'nature',rarity: 'common',    movement: 'ground', attackType: 'support', role: 'support', color: '#4ade80',
             passive: { def: { base: 3, growth: 0.9 } },
             skill: { name: 'Peloah Daun',         target: 'ally',  cd: 4, power: 0.9,  effect: 'hot',        effectDesc: 'menyembuhkanmu sedikit tiap giliran (3 giliran)' },
             lore: 'Rubah kecil hutan yang tanduk pucuknya tumbuh makin rimbun setiap musim semi.' },
  pebble:  { id: 'pebble',  name: 'Pebble',  species: 'Kura-kura Batu',      element: 'earth', rarity: 'common',    movement: 'ground', attackType: 'melee', role: 'tank',    color: '#a8a29e',
             passive: { def: { base: 6, growth: 1.4 }, hp: { base: 20, growth: 6 } },
             skill: { name: 'Cangkang Besi',       target: 'ally',  cd: 4, power: 1.6,  effect: 'shield',     effectDesc: 'perisai yang menyerap damage (sekuat pertahanan pet)' },
             lore: 'Kura-kura dengan cangkang berlumut. Lambat berjalan, tapi selalu tiba di tujuan.' },
  aqua:    { id: 'aqua',    name: 'Aqua',   species: 'Slime Air',            element: 'water', rarity: 'common',    movement: 'aquatic', attackType: 'magic', role: 'dps',     color: '#38bdf8',
             passive: { hp: { base: 15, growth: 5 }, mp: { base: 8, growth: 2.5 } },
             skill: { name: 'Percikan',            target: 'enemy', cd: 3, power: 1.1,  effect: 'slow',       effectDesc: 'melemahkan serangan musuh (-15% atk)' },
             lore: 'Gumpalan air yang ikut pulang setelah hujan badai. Gemas, tapi jangan dipeluk terlalu keras.' },
  zephyr:  { id: 'zephyr',  name: 'Zephyr',  species: 'Burung Hantu Angin',  element: 'wind', rarity: 'uncommon',  movement: 'flying', attackType: 'support', role: 'support', color: '#7dd3fc',
             passive: { spd: { base: 6, growth: 1.3 }, mp: { base: 10, growth: 3 } },
             skill: { name: 'Hembusan Angin',      target: 'enemies', cd: 4, power: 0.7, effect: 'atkdown',  effectDesc: 'menyerang semua musuh dan menurunkan attack mereka' },
             lore: 'Burung hantu kecil penjaga menara angin. Sayapnya bersuara seperti peluit kalau terbang malam.' },
  frost:   { id: 'frost',   name: 'Frost',   species: 'Rubah Es',            element: 'ice',   rarity: 'uncommon',  movement: 'ground', attackType: 'magic', role: 'dps',     color: '#bae6fd',
             passive: { atk: { base: 6, growth: 1.5 } },
             skill: { name: 'Gigitan Beku',        target: 'enemy', cd: 4, power: 1.3,  effect: 'freeze',     effectDesc: 'membekukan musuh 1 giliran' },
             lore: 'Rubah pucat dari puncak bersalju. Jejak kakinya membeku menjadi bunga es.' },
  toxic:   { id: 'toxic',   name: 'Toxic',   species: 'Katak Beracun',       element: 'poison',rarity: 'uncommon',  movement: 'ground', attackType: 'ranged', role: 'dps',     color: '#a3e635',
             passive: { atk: { base: 5, growth: 1.4 }, hp: { base: 10, growth: 4 } },
             skill: { name: 'Ludah Beracun',       target: 'enemy', cd: 3, power: 1.0,  effect: 'poison',     effectDesc: 'meracuni musuh (damage tiap giliran, 3 giliran)' },
             lore: 'Katak kecil berwarna mencolok dari rawa terlarang. Warnanya adalah peringatan, katanya.' },
  shadow:  { id: 'shadow',  name: 'Shadow',  species: 'Kelelawar Bayang',    element: 'dark',  rarity: 'rare',      movement: 'flying', attackType: 'melee', role: 'dps',     color: '#a78bfa',
             passive: { atk: { base: 8, growth: 1.8 }, crit: { base: 3, growth: 0.8 } },
             skill: { name: 'Cengkeraman Bayang',  target: 'enemy', cd: 4, power: 1.45, effect: 'lifesteal',  effectDesc: 'menyerap 50% damage sebagai HP untukmu' },
             lore: 'Kelelawar dari celah bayangan gua tua. Mata ungunya berpendar di kegelapan total.' },
  terra:   { id: 'terra',   name: 'Terra',   species: 'Golem Kecil',         element: 'earth', rarity: 'rare',      movement: 'ground', attackType: 'melee', role: 'tank',    color: '#78716c',
             passive: { def: { base: 10, growth: 2.2 }, hp: { base: 40, growth: 9 } },
             skill: { name: 'Gempa Kecil',         target: 'enemies', cd: 5, power: 0.95, effect: 'defup',    effectDesc: 'mengguncang semua musuh dan menguatkan pertahananmu' },
             lore: 'Pecahan golem yang belajar berjalan sendiri. Matanya menyala hijau kalau senang.' },
  lumen:   { id: 'lumen',   name: 'Lumen',   species: 'Rubah Cahaya',        element: 'light', rarity: 'epic',      movement: 'ground', attackType: 'magic', role: 'hybrid',  color: '#fde68a',
             passive: { atk: { base: 9, growth: 2.0 }, hp: { base: 25, growth: 7 }, mp: { base: 15, growth: 4 } },
             skill: { name: 'Sinar Keemasan',      target: 'enemy', cd: 4, power: 1.5,  effect: 'radiant',    effectDesc: 'melukai musuh dan menyembuhkanmu sebagian' },
             lore: 'Rubah keemasan yang muncul di kuil terbengkalai. Konon membawa keberuntungan bagi yang jujur.' },
  nyx:     { id: 'nyx',     name: 'Nyx',     species: 'Anakan Naga Bayang',  element: 'darkfire', rarity: 'legendary', movement: 'flying', attackType: 'magic', role: 'dps',  color: '#c084fc',
             passive: { atk: { base: 14, growth: 2.6 }, crit: { base: 5, growth: 1.1 } },
             skill: { name: 'Napas Bayang',        target: 'enemies', cd: 5, power: 1.7, effect: 'burn',      effectDesc: 'napas gelap yang membakar semua musuh' },
             lore: 'Anakan naga dari sarang gunung berapi yang mati. Napasnya masih menyimpan bara kegelapan.' },
  celeste: { id: 'celeste', name: 'Celeste', species: 'Unicorn Kecil',       element: 'holy',  rarity: 'legendary', movement: 'ground', attackType: 'support', role: 'support', color: '#f9a8d4',
             passive: { def: { base: 10, growth: 2.0 }, hp: { base: 50, growth: 11 }, mp: { base: 20, growth: 5 } },
             skill: { name: 'Berkat Cahaya',       target: 'ally',  cd: 6, power: 2.2,  effect: 'blessing',   effectDesc: 'penyembuhan besar + membersihkan racun dan bakar' },
             lore: 'Unicorn muda yang turun mengikuti bintang jatuh. Tanduknya berpendar lembut menenangkan hati.' },
  solara:  { id: 'solara',  name: 'Solara',  species: 'Anakan Phoenix Matahari', element: 'solar', rarity: 'mythic',    movement: 'flying', attackType: 'magic', role: 'dps',     color: '#fbbf24',
             passive: { atk: { base: 18, growth: 3.2 }, crit: { base: 6, growth: 1.3 }, spd: { base: 6, growth: 1.2 } },
             skill: { name: 'Nyala Fajar',         target: 'enemies', cd: 5, power: 1.9, effect: 'burn',       effectDesc: 'sinar fajar membakar semua musuh (2 giliran)' },
             lore: 'Menetas dari inti matahari yang jatuh. Bulu baranya menyala seakan fajar tersembunyi di tubuh kecilnya.' },
  nocturne:{ id: 'nocturne', name: 'Nocturne', species: 'Anakan Panther Void',   element: 'void',  rarity: 'mythic',    movement: 'burrow', attackType: 'melee', role: 'dps',     color: '#a78bfa',
             passive: { atk: { base: 16, growth: 3.0 }, crit: { base: 8, growth: 1.5 }, eva: { base: 4, growth: 1.0 } },
             skill: { name: 'Cakar Bintang Jatuh', target: 'enemy',  cd: 4, power: 2.1,  effect: 'voidlash',   effectDesc: 'tebasan void dengan crit +25% dan menyerap HP' },
             lore: 'Bayangan berbentuk anak panther, lahir dari retakan antar-bintang. Bulunya berkelip seperti langit malam.' },
};
const PET_ORDER = ['ember', 'bolt', 'leafy', 'pebble', 'aqua', 'zephyr', 'frost', 'toxic', 'shadow', 'terra', 'lumen', 'nyx', 'celeste', 'solara', 'nocturne'];
const PET_BY_RARITY = { common: ['ember','bolt','leafy','pebble','aqua'], uncommon: ['zephyr','frost','toxic'], rare: ['shadow','terra'], epic: ['lumen'], legendary: ['nyx','celeste'], mythic: ['solara','nocturne'] };

/* ---------- EVOLUSI PET (cermin utils/rpgData.js) ----------
 * Stage 1 = bentuk anak-anak. Stage 2 = bentuk evolusi: tubuh, sprite, skill,
 * dan stat berubah (pasif dikali mult). Syarat: level + pecahan + gold. */
const PET_EVOLUTION = {
  ember:   { name: 'Pyrelisk',    species: 'Kucing Api Penjaga',  reqLevel: 10, shards: 20,  gold: 1500,  mult: 1.8,
             skill: { name: 'Bara Sang Raja', target: 'enemies', cd: 4, power: 1.8, effect: 'burn', effectDesc: 'surai menyala membakar semua musuh (2 giliran)' } },
  bolt:    { name: 'Stormfang',   species: 'Anjing Badai',        reqLevel: 10, shards: 20,  gold: 1500,  mult: 1.8,
             skill: { name: 'Taring Guntur', target: 'enemy', cd: 3, power: 1.9, effect: 'stun25', effectDesc: '25% peluang melumpuhkan musuh 1 giliran' } },
  leafy:   { name: 'Verdantis',   species: 'Rubah Roh Bunga',     reqLevel: 10, shards: 20,  gold: 1500,  mult: 1.8,
             skill: { name: 'Panggilan Musim Semi', target: 'ally', cd: 3, power: 1.6, effect: 'hot', effectDesc: 'menyembuhkan tiap giliran (3 giliran)' } },
  pebble:  { name: 'Bastion',     species: 'Kura-kura Purba',     reqLevel: 10, shards: 20,  gold: 1500,  mult: 1.8,
             skill: { name: 'Tembok Kuno', target: 'ally', cd: 3, power: 2.2, effect: 'shield', effectDesc: 'perisai besar dari inti kristal purba' } },
  aqua:    { name: 'Tidecaller',  species: 'Roh Air Arus',         reqLevel: 10, shards: 20,  gold: 1500,  mult: 1.8,
             skill: { name: 'Ombak Besar', target: 'enemies', cd: 4, power: 1.4, effect: 'slow', effectDesc: 'gelombang melemahkan semua musuh (-20% atk)' } },
  zephyr:  { name: 'Skysovereign',species: 'Burung Hantu Angkasa',reqLevel: 10, shards: 40,  gold: 3500,  mult: 1.8,
             skill: { name: 'Badai Sayap', target: 'enemies', cd: 4, power: 1.2, effect: 'atkdown', effectDesc: 'putaran sayap menekan semua musuh' } },
  frost:   { name: 'Glacira',     species: 'Rubah Kristal Es',    reqLevel: 10, shards: 40,  gold: 3500,  mult: 1.8,
             skill: { name: 'Taring Gletser', target: 'enemy', cd: 4, power: 1.8, effect: 'freeze', effectDesc: 'membekukan musuh 1 giliran + dingin menusuk' } },
  toxic:   { name: 'Venomarch',   species: 'Katak Raja Beracun',  reqLevel: 10, shards: 40,  gold: 3500,  mult: 1.8,
             skill: { name: 'Hujan Racun', target: 'enemies', cd: 4, power: 1.3, effect: 'poison', effectDesc: 'meracuni semua musuh (3 giliran)' } },
  shadow:  { name: 'Duskmaw',     species: 'Kelelawar Jurang',    reqLevel: 10, shards: 80,  gold: 7000,  mult: 1.85,
             skill: { name: 'Sansai Bayang', target: 'enemy', cd: 3, power: 2.0, effect: 'lifesteal', effectDesc: 'menyerap 60% damage sebagai HP' } },
  terra:   { name: 'Monolith',    species: 'Golem Kuno',          reqLevel: 10, shards: 80,  gold: 7000,  mult: 1.85,
             skill: { name: 'Gempa Purba', target: 'enemies', cd: 4, power: 1.5, effect: 'defup', effectDesc: 'gempa ke semua musuh + pertahanan tim naik' } },
  lumen:   { name: 'Radiance',    species: 'Rubah Sembilan Cahaya',reqLevel: 10, shards: 160, gold: 14000, mult: 1.9,
             skill: { name: 'Fajar Sembilan Ekor', target: 'enemy', cd: 3, power: 2.2, effect: 'radiant', effectDesc: 'tebasan cahaya: damage besar + heal diri' } },
  nyx:     { name: 'Umbraxis',   species: 'Naga Bayang Dewasa',   reqLevel: 10, shards: 240, gold: 22000, mult: 1.95,
             skill: { name: 'Napas Kehampaan', target: 'enemies', cd: 4, power: 2.3, effect: 'burn', effectDesc: 'napas gelap membakar semua musuh (3 giliran)' } },
  celeste: { name: 'Seraphion',  species: 'Unicorn Bersayap',     reqLevel: 10, shards: 240, gold: 22000, mult: 1.95,
             skill: { name: 'Cahaya Serafim', target: 'ally', cd: 4, power: 3.0, effect: 'blessing', effectDesc: 'penyembuhan masif + bersihkan semua debuff' } },
  solara:  { name: 'Solaris',    species: 'Phoenix Matahari',    reqLevel: 10, shards: 400, gold: 40000, mult: 2.0,
             skill: { name: 'Supernova', target: 'enemies', cd: 4, power: 2.6, effect: 'burn', effectDesc: 'ledakan matahari ke semua musuh (3 giliran)' } },
  nocturne:{ name: 'Eclipseon',  species: 'Panther Gerhana',     reqLevel: 10, shards: 400, gold: 40000, mult: 2.0,
             skill: { name: 'Gerhana Total', target: 'enemy', cd: 3, power: 3.2, effect: 'voidlash', effectDesc: 'tebasan gerhana: crit +35% & serap HP' } },
};

/* ---------- GACHA (cermin server) ---------- */
/* ---------- v11: SKILL KEDUA per pet + ULTIMATE evolusi terakhir ----------
 * Setiap pet kini punya 2 skill aktif yang bergantian + 1 ULTIMATE yang hanya
 * terbuka saat evolusi terakhir (stage 2). Ultimatnya sinematik: lingkaran
 * summon + aura elemen + ledakan frame VFX aset internet. */
const PET_SKILL2 = {
  ember:   { name: 'Cakar Membara',     target: 'enemy',   cd: 3, power: 1.35, effect: 'burn',    effectDesc: 'tiga goresan api yang meninggalkan bara' },
  bolt:    { name: 'Lolongan Voltase',  target: 'enemies', cd: 4, power: 0.8,  effect: 'atkdown', effectDesc: 'ultrasonic statis membuat semua musuh goyah' },
  leafy:   { name: 'Tanduk Musim Semi', target: 'ally',    cd: 4, power: 1.2,  effect: 'shield',  effectDesc: 'daun hidup membentuk pelindung rimbun' },
  pebble:  { name: 'Gulingan Batu',     target: 'enemy',   cd: 3, power: 1.4,  effect: 'stun10',  effectDesc: 'mengguling menabrak kaki musuh' },
  aqua:    { name: 'Genangan Licin',    target: 'enemies', cd: 4, power: 0.9,  effect: 'slow',    effectDesc: 'air menjalar membuat musuh tergelincir' },
  zephyr:  { name: 'Terjaga Malam',     target: 'ally',    cd: 4, power: 1.0,  effect: 'hot',     effectDesc: 'pantauan si burung hantu menenangkanmu (3 giliran)' },
  frost:   { name: 'Napas Salju',       target: 'enemies', cd: 4, power: 0.9,  effect: 'slow',    effectDesc: 'kabut dingin memperlambat barisan musuh' },
  toxic:   { name: 'Kabut Racun',       target: 'enemies', cd: 4, power: 0.85, effect: 'poison',  effectDesc: 'kantung kulit menyemprot kabut beracun' },
  shadow:  { name: 'Pekat Menyelubungi',target: 'enemies', cd: 4, power: 0.8,  effect: 'atkdown', effectDesc: 'sayap malam meredupkan semangat musuh' },
  terra:   { name: 'Kulit Granit',      target: 'ally',    cd: 4, power: 1.2,  effect: 'shield',  effectDesc: 'lapisan batu hidup menutupi tubuhmu' },
  lumen:   { name: 'Berkat Cahaya',     target: 'ally',    cd: 4, power: 1.1,  effect: 'hot',     effectDesc: 'kilau ekor menyembuhkan luka perlahan' },
  nyx:     { name: 'Sayap Kegelapan',   target: 'enemies', cd: 4, power: 1.0,  effect: 'atkdown', effectDesc: 'bayangan sayap menekan semua musuh' },
  celeste: { name: 'Air Mancur Cahaya', target: 'ally',    cd: 4, power: 1.4,  effect: 'blessing',effectDesc: 'terusan cahaya suci membasuh debuff' },
  solara:  { name: 'Sayat Surya',       target: 'enemies', cd: 4, power: 1.2,  effect: 'burn',    effectDesc: 'hujan bulu matahari membakar area' },
  nocturne:{ name: 'Bayang Menindih',   target: 'enemies', cd: 4, power: 1.0,  effect: 'atkdown', effectDesc: 'bayangan panther menghimpit lawan' },
};
const PET_ULTIMATE = {
  ember:   { name: 'MAHKOTA BARA RAJA',   target: 'enemies', power: 2.6, effect: 'burn',     effectDesc: 'surai raja api meledak membakar seluruh medan (3 giliran)' },
  bolt:    { name: 'TARING BADAI',        target: 'enemy',   power: 3.0, effect: 'stun25',   effectDesc: 'petir bertubi-tubi dari taring badai' },
  leafy:   { name: 'TAMAN ABADI',         target: 'ally',    power: 2.6, effect: 'blessing', effectDesc: 'musim semi dipanggil: heal besar + regen' },
  pebble:  { name: 'BENTENG PURBA',       target: 'ally',    power: 3.2, effect: 'shield',   effectDesc: 'dinding kristal purba tak tertembus' },
  aqua:    { name: 'GELOMBANG PASANG',    target: 'enemies', power: 2.2, effect: 'slow',     effectDesc: 'ombak besar menenggelamkan semua musuh' },
  zephyr:  { name: 'MATA BADAI',          target: 'enemies', power: 2.0, effect: 'atkdown',  effectDesc: 'pusaran angin antah-berantah menghancurkan formasi' },
  frost:   { name: 'NOL ABSOLUT',         target: 'enemies', power: 2.4, effect: 'freeze',   effectDesc: 'dingin absolut membekukan waktu musuh' },
  toxic:   { name: 'RAWA MAUT',           target: 'enemies', power: 2.3, effect: 'poison',   effectDesc: 'murka raja katak meracuni segalanya (3 giliran)' },
  shadow:  { name: 'LAYANG JURANG',       target: 'enemy',   power: 3.0, effect: 'lifesteal',effectDesc: 'menyerap nyawa langsung dari kegelapan' },
  terra:   { name: 'GEMPA PURBA',         target: 'enemies', power: 2.2, effect: 'stun25',   effectDesc: 'monolit bangkit dan mengguncang bumi' },
  lumen:   { name: 'SEMBILAN FAJAR',      target: 'enemies', power: 2.8, effect: 'radiant',  effectDesc: 'sembilan ekor menyala menjadi fajar yang menampar' },
  nyx:     { name: 'GERHANA NAPAS',       target: 'enemies', power: 3.0, effect: 'burn',     effectDesc: 'napas kehampaan memadamkan semua cahaya' },
  celeste: { name: 'SERAFIM TURUN',       target: 'ally',    power: 3.4, effect: 'blessing', effectDesc: 'cahaya surga menyembuhkan dan menyucikan' },
  solara:  { name: 'SUPERNOVA MATAHARI',  target: 'enemies', power: 3.2, effect: 'burn',     effectDesc: 'reinkarnasi matahari meledak di medan perang' },
  nocturne:{ name: 'GERHANA TOTAL',       target: 'enemy',   power: 3.6, effect: 'voidlash', effectDesc: 'satu tebasan menelan cahaya dunia' },
};
(function () {
  Object.entries(PET_SKILL2).forEach(([id, s2]) => {
    if (PETS[id]) PETS[id].skills = [PETS[id].skill, s2].filter(Boolean);
  });
  Object.entries(PET_ULTIMATE).forEach(([id, ult]) => {
    if (PET_EVOLUTION[id]) PET_EVOLUTION[id].ultimate = ult;
  });
})();
// Elemen -> sheet VFX (aset internet) untuk proyektil & ledakan skill pet.
const PET_ELEMENT_VFX = {
  fire: 'vfx_fire', darkfire: 'vfx_fire', solar: 'vfx_fire', bolt: 'vfx_lightning',
  nature: 'vfx_snake', earth: 'vfx_spikes', water: 'vfx_water', wind: 'vfx_tornado',
  ice: 'vfx_ice', poison: 'vfx_snake', dark: 'vfx_arcane', void: 'vfx_arcane',
  light: 'vfx_lpc_effects', holy: 'vfx_lpc_effects',
};
const PET_ULT_VFX = {
  fire: 'vfx_firelion', darkfire: 'vfx_firelion', solar: 'vfx_firelion', bolt: 'vfx_lightning',
  nature: 'vfx_snake', earth: 'vfx_spikes', water: 'vfx_tentacle', wind: 'vfx_tornado',
  ice: 'vfx_icetacle', poison: 'vfx_snake', dark: 'vfx_arcane', void: 'vfx_arcane',
  light: 'vfx_aura_fire', holy: 'vfx_aura_fire',
};

const GACHA = {
  cost: 100, cost10: 900,
  rates: { common: 0.42, uncommon: 0.27, rare: 0.17, epic: 0.085, legendary: 0.047, mythic: 0.008 },
  pityEpicAt: 20, pityLegendaryAt: 60, pityMythicAt: 150,
  shardFromDupe: { common: 6, uncommon: 12, rare: 25, epic: 50, legendary: 100, mythic: 200 },
  goldToGems: { rate: 1000, gems: 60 },
};
// Nama sheet sprite pet sesuai pangkat evolusi (fallback bila atlas tak ada).
function petSheetKey(petId, stage) { return 'asset_pet_' + petId + (stage >= 2 ? '_evo' : ''); }
/* ---------- v12 §3: ATLAS PET — 30 sheet menjadi SATU tekstur ----------
 * Semua akses sprite pet lewat helper ini; bila atlas termuat, frame bernama
 * dipakai (1 request HTTP + 1 tekstur GPU); bila tidak, fallback ke sheet
 * terpisah lama (game tetap jalan). */
const PETS_ATLAS_KEY = 'pets_atlas';
function petFrameName(petId, stage, idx) { return petId + (stage >= 2 ? '_evo' : '') + '_' + idx; }
function petsAtlasReady(scene) {
  try { return scene.textures.exists(PETS_ATLAS_KEY) && scene.textures.get(PETS_ATLAS_KEY).has(petFrameName('ember', 1, 0)); } catch (_) { return false; }
}
function petTexExists(scene, petId, stage) {
  if (petsAtlasReady(scene)) { try { return scene.textures.get(PETS_ATLAS_KEY).has(petFrameName(petId, stage || 1, 0)); } catch (_) { return false; } }
  return scene.textures.exists(petSheetKey(petId, stage || 1));
}
function petAddSprite(scene, x, y, petId, stage) {
  if (petsAtlasReady(scene)) return scene.add.sprite(x, y, PETS_ATLAS_KEY, petFrameName(petId, stage || 1, 0));
  return scene.add.sprite(x, y, petSheetKey(petId, stage || 1), 0);
}
function petSetFrame(spr, petId, stage, idx) {
  try {
    if (spr.texture.key === PETS_ATLAS_KEY) spr.setFrame(petFrameName(petId, stage || 1, idx));
    else spr.setFrame(idx);
  } catch (_) {}
}
function petXpForLevel(level) { if (level >= PET_LEVEL_CAP) return Infinity; return Math.floor(60 * Math.pow(level, 1.55) + 40 * level); }
function petSkillScale(level) { return 1 + (level - 1) * 0.05; }
function petPassiveAt(pet, level, stage) {
  const mult = stage >= 2 && PET_EVOLUTION[pet.id] ? PET_EVOLUTION[pet.id].mult : 1;
  const out = {};
  for (const [k, v] of Object.entries(pet.passive || {})) out[k] = Math.round((v.base + (level - 1) * v.growth) * mult);
  return out;
}
const PET_RARITY_INFO = {
  common:    { name: 'Umum',      color: '#9ca3af', glow: 0x9ca3af },
  uncommon:  { name: 'Tidak Umum',color: '#4ade80', glow: 0x4ade80 },
  rare:      { name: 'Langka',    color: '#38bdf8', glow: 0x38bdf8 },
  epic:      { name: 'Epik',      color: '#c084fc', glow: 0xc084fc },
  legendary: { name: 'Legendaris',color: '#facc15', glow: 0xfacc15 },
  mythic:    { name: 'Mistik',    color: '#f43f5e', glow: 0xf43f5e },
};
const PET_ELEMENT_INFO = {
  fire: { name: 'Api',    color: '#fb923c' }, bolt: { name: 'Listrik', color: '#fde047' },
  nature: { name: 'Alam', color: '#4ade80' }, earth: { name: 'Bumi',   color: '#a8a29e' },
  water: { name: 'Air',   color: '#38bdf8' }, wind: { name: 'Angin',   color: '#7dd3fc' },
  ice: { name: 'Es',      color: '#bae6fd' }, poison: { name: 'Racun', color: '#a3e635' },
  dark: { name: 'Gelap',  color: '#a78bfa' }, light: { name: 'Cahaya', color: '#fde68a' },
  darkfire: { name: 'Bayang Membara', color: '#c084fc' }, holy: { name: 'Suci', color: '#f9a8d4' },
  solar: { name: 'Matahari', color: '#fbbf24' }, void: { name: 'Kehampaan', color: '#a78bfa' },
};
const PET_ROLE_INFO = { dps: 'Penyerang', tank: 'Pelindung', support: 'Pendukung', hybrid: 'Serba Bisa' };

/* ---------- v12: SEGITIGA ELEMEN (satu bahasa strategis untuk pet + hero + monster) ----------
 * 14 elemen dipetakan ke 6 kelompok besar yang mudah dibaca:
 *   api: fire/darkfire/solar | air: water/ice | alam: nature/poison/earth
 *   listrik: bolt/wind       | cahaya: light/holy | bayang: dark/void
 * Siklus: api > alam > listrik > air > api  (membakar, membumikan, menghantar, memadamkan)
 * Dualitas: cahaya <-> bayang saling menindas.
 * Keunggulan x1.25 + telegraf visual (ikon + warna angka); kelemahan x0.8. */
const ELEM_GROUP = {
  fire: 'api', darkfire: 'api', solar: 'api',
  water: 'air', ice: 'air',
  nature: 'alam', poison: 'alam', earth: 'alam',
  bolt: 'listrik', wind: 'listrik',
  light: 'cahaya', holy: 'cahaya',
  dark: 'bayang', void: 'bayang',
};
const ELEM_BEATS = { api: 'alam', alam: 'listrik', listrik: 'air', air: 'api' };
const ELEM_GROUP_INFO = {
  api:     { name: 'API',     color: '#fb923c', glyph: 'A' },
  air:     { name: 'AIR',     color: '#38bdf8', glyph: 'W' },
  alam:    { name: 'ALAM',    color: '#4ade80', glyph: 'N' },
  listrik: { name: 'LISTRIK', color: '#fde047', glyph: 'E' },
  cahaya:  { name: 'CAHAYA',  color: '#fde68a', glyph: 'L' },
  bayang:  { name: 'BAYANG',  color: '#a78bfa', glyph: 'S' },
};
function elemGroup(el) { return ELEM_GROUP[el] || null; }
/* Multiplikator keunggulan penyerang vs pembela. */
function elemAdvantage(attEl, defEl) {
  const a = ELEM_GROUP[attEl], d = ELEM_GROUP[defEl];
  if (!a || !d) return 1;
  if (ELEM_BEATS[a] === d) return 1.25;
  if (ELEM_BEATS[d] === a) return 0.8;
  if ((a === 'cahaya' && d === 'bayang') || (a === 'bayang' && d === 'cahaya')) return 1.2; // dualitas
  return 1;
}
function elemAdvantageInfo(attEl, defEl) {
  const m = elemAdvantage(attEl, defEl);
  if (m > 1) return { mult: m, adv: 'up', group: ELEM_GROUP_INFO[ELEM_GROUP[attEl]] };
  if (m < 1) return { mult: m, adv: 'down', group: ELEM_GROUP_INFO[ELEM_GROUP[attEl]] };
  return { mult: 1, adv: null, group: null };
}
/* Telegraf visual keunggulan: label nama grup (colorblind-safe: teks, bukan
 * cuma warna) + percikan. Dipanggil saat keunggulan/kelemahan terpicu. */
function elemAdvantageFlash(scene, x, y, info) {
  if (!info || !info.adv || !scene) return;
  const c = Phaser.Display.Color.HexStringToColor(info.group.color).color;
  const txt = scene.add.text(x, y - 46, info.adv === 'up' ? '! ' + info.group.name : info.group.name + ' LEMAH', {
    fontFamily: F_HEAD, fontSize: '9px', color: info.group.color, stroke: '#0b0b12', strokeThickness: 3,
  }).setOrigin(0.5).setDepth(890);
  scene.tweens.add({ targets: txt, y: y - 66, alpha: 0, duration: 760, ease: 'Quad.easeOut', onComplete: () => txt.destroy() });
  if (scene.textures.exists('fx_tex_sparkle')) {
    for (let i = 0; i < 4; i++) {
      const sp = scene.add.image(x + (i - 1.5) * 12, y - 34, 'fx_tex_sparkle').setTint(c).setBlendMode(Phaser.BlendModes.ADD).setScale(0.13).setDepth(889);
      scene.tweens.add({ targets: sp, y: y - 52, alpha: 0, duration: 520 + i * 60, onComplete: () => sp.destroy() });
    }
  }
}

// Ikon item (PNG di assets/icons/) yang ikut dimuat saat boot.
const PET_ITEM_ICON_KEYS = [
  'w_sword', 'w_axe', 'w_hammer', 'w_spear', 'w_staff', 'w_wand', 'w_orb', 'w_tome', 'w_dagger', 'w_katana', 'w_claw', 'w_bow',
  'a_light', 'a_chain', 'a_plate', 'a_shield',
  'c_ring', 'c_earring', 'c_cloak', 'c_crown', 'c_pendant', 'c_bracer', 'c_charm', 'c_angel', 'c_hourglass', 'c_coin',
  'p_heal', 'p_mana', 'p_elixir', 'p_str', 'p_spd', 'p_def', 'p_poison', 'p_regen',
  'm_jelly', 'm_tail', 'm_wing', 'm_ear', 'm_bone', 'm_pelt', 'm_venom', 'm_ember', 'm_fang', 'm_feather', 'm_shell', 'm_shard', 'm_bandage', 'm_tusk', 'm_core', 'm_ecto', 'm_fur', 'm_horn', 'm_scale', 'm_heart', 'm_whistle', 'm_snack',
  'chest', 'key', 'mimic', 'paw_w',
];
// v9: ikon UI pixel putih 48px (assets/ui/icons) — tintable, tanpa canvas.
const UI_ICON_KEYS = ['arrow', 'back', 'bag', 'book', 'bow', 'chat', 'check', 'chest', 'coin', 'compass', 'copy', 'cross', 'crown', 'door', 'dungeon', 'exit', 'eye', 'fire', 'flag', 'friends', 'gear', 'hammer', 'heart', 'home', 'lock', 'mana', 'map', 'medal', 'minus', 'party', 'paw', 'person', 'plus', 'potion', 'rage', 'refresh', 'ribbon', 'scroll', 'search', 'send', 'settings', 'shield', 'skill', 'skull', 'sound', 'sparkle', 'star', 'sword', 'swords', 'trophy', 'user'];

// Ikon vektor per-tipe item (dipakai inventory/forge/market bila PNG tersedia).
function itemIconKey(it) {
  if (!it) return null;
  const t = it.type || '';
  const map = { sword: 'w_sword', axe: 'w_axe', hammer: 'w_hammer', spear: 'w_spear', staff: 'w_staff', wand: 'w_wand', orb: 'w_orb', tome: 'w_tome', dagger: 'w_dagger', katana: 'w_katana', claw: 'w_claw', bow: 'w_bow' };
  if (it.cat === 'weapon') return map[t] || 'w_sword';
  // FIX v8: dulu baca it.type (kosong utk armor — field aslinya atype) dan
  // map lama medium/heavy tidak pernah cocok -> SEMUA zirah tampil rantai.
  if (it.cat === 'armor') return { light: 'a_light', coat: 'a_light', shroud: 'a_light', mail: 'a_chain', scale: 'a_chain', plate: 'a_plate', aegis: 'a_plate', bulwark: 'a_plate', shield: 'a_shield', medium: 'a_chain', heavy: 'a_plate' }[it.atype || it.type] || 'a_light';
  if (it.cat === 'accessory') {
    if (/crown/i.test(it.id)) return 'c_crown';
    if (/cloak/i.test(it.id)) return 'c_cloak';
    if (/ring/i.test(it.id)) return 'c_ring';
    if (/earring|crit/i.test(it.id)) return 'c_earring';
    if (/pendant|blood/i.test(it.id)) return 'c_pendant';
    if (/bracer|thorn/i.test(it.id)) return 'c_bracer';
    if (/charm|storm/i.test(it.id)) return 'c_charm';
    if (/angel/i.test(it.id)) return 'c_angel';
    if (/hourglass|time/i.test(it.id)) return 'c_hourglass';
    if (/coin|lucky/i.test(it.id)) return 'c_coin';
    return 'c_ring';
  }
  if (it.cat === 'potion') {
    if (/heal/.test(it.id)) return 'p_heal';
    if (/mana/.test(it.id)) return 'p_mana';
    if (/elixir/.test(it.id)) return 'p_elixir';
    if (/strength|berserk/.test(it.id)) return 'p_str';
    if (/swift/.test(it.id)) return 'p_spd';
    if (/guard|defend/.test(it.id)) return 'p_def';
    if (/poison|venom|weaken|paralyze/.test(it.id)) return 'p_poison';
    if (/regen/.test(it.id)) return 'p_regen';
    return 'p_heal';
  }
  if (it.cat === 'material') {
    if (/jelly/.test(it.id)) return 'm_jelly';
    if (/tail/.test(it.id)) return 'm_tail';
    if (/wing/.test(it.id)) return 'm_wing';
    if (/ear/.test(it.id)) return 'm_ear';
    if (/bone/.test(it.id)) return 'm_bone';
    if (/pelt|fur/.test(it.id)) return 'm_pelt';
    if (/venom/.test(it.id)) return 'm_venom';
    if (/ember/.test(it.id)) return 'm_ember';
    if (/fang/.test(it.id)) return 'm_fang';
    if (/feather/.test(it.id)) return 'm_feather';
    if (/shell/.test(it.id)) return 'm_shell';
    if (/shard/.test(it.id)) return 'm_shard';
    if (/bandage/.test(it.id)) return 'm_bandage';
    if (/tusk/.test(it.id)) return 'm_tusk';
    if (/core/.test(it.id)) return 'm_core';
    if (/ecto/.test(it.id)) return 'm_ecto';
    if (/yeti/.test(it.id)) return 'm_fur';
    if (/horn/.test(it.id)) return 'm_horn';
    if (/scale/.test(it.id)) return 'm_scale';
    if (/heart/.test(it.id)) return 'm_heart';
    if (/whistle/.test(it.id)) return 'm_whistle';
    if (/snack/.test(it.id)) return 'm_snack';
    return 'm_bone';
  }
  return null;
}

// Toast pet (dipanggil dari konteks non-scene seperti Data) — cari scene aktif.
function petToast(title, message, color) {
  try {
    const scenes = window.__game ? window.__game.scene.getScenes(true) : [];
    const sc = scenes[scenes.length - 1];
    if (sc) Toast.show(sc, { title, message, icon: 'paw', color });
  } catch (_) {}
}

// State pet pemain (dimuat dari /api/rpg/pets saat login).
const PetState = {
  active: null,        // petId aktif
  owned: {},           // petId -> { level, xp }
  loaded: false,
  get activePet() { return this.active ? PETS[this.active] : null; },
  get activeLevel() { return (this.owned[this.active] || {}).level || 1; },
  isOwned(id) { return !!this.owned[id]; },
  level(id) { return (this.owned[id] || {}).level || 0; },
  xpNeed(id) { const lv = this.level(id) || 1; return petXpForLevel(Math.min(lv, PET_LEVEL_CAP - 1)); },
  async load() {
    if (!CFG.server) { // demo lokal: ember milik default biar fitur bisa dicoba
      if (!this.loaded) { this.owned = { ember: { level: 3, xp: 40 } }; this.active = 'ember'; this.loaded = true; }
      return;
    }
    const d = await api('/api/rpg/pets');
    if (d && d.pets) {
      this.owned = {}; this.active = d.activePetId;
      for (const p of d.pets) if (p.owned) this.owned[p.id] = { level: p.level, xp: p.xp, stage: p.stage || 1 };
      this.loaded = true;
      Bus.emit('pets', this);
    }
  },
  async setActive(petId) {
    if (!this.owned[petId]) return false;
    if (CFG.server) {
      const r = await api('/api/rpg/pet/activate', { method: 'POST', body: { petId } });
      if (!r || r.error) return false;
    }
    this.active = petId;
    Bus.emit('pets', this);
    return true;
  },
  stage(petId) { return ((this.owned[petId] || {}).stage) || 1; },
  applyEvolve(petId) { // hasil POST /pet/evolve
    if (this.owned[petId]) { this.owned[petId].stage = 2; Bus.emit('pets', this); }
  },
  applyGacha(result) { // hasil POST /gacha/pull: pulls[], gems, petShards
    for (const p of (result.pulls || [])) {
      if (!p.duplicate) this.owned[p.petId] = { level: 1, xp: 0, stage: 1 };
    }
    Bus.emit('pets', this);
  },
  applyXp(xpInfo) { // dari rewards battle/dungeon: { id, level, xp, leveled, capped }
    if (xpInfo && xpInfo.id && xpInfo.level) {
      const before = (this.owned[xpInfo.id] || {}).level || 1;
      const prevStage = (this.owned[xpInfo.id] || {}).stage || 1;
      this.owned[xpInfo.id] = { level: xpInfo.level, xp: xpInfo.xp || 0, stage: prevStage };
      Bus.emit('pets', this);
      return xpInfo.level > before ? xpInfo.level - before : 0;
    }
    return 0;
  },
};

/* ---------- Companion pet: sprite yang menemani (spring follow + idle bob + FX) ---------- */
// Dipakai di Dungeon, QuestBattle, Lobby multiplayer, dan Profile.
// opts: { x, y, depth, scale, flip, follow: {get: () => ({x,y,flip})}, interactive }
function spawnPetCompanion(scene, petId, opts = {}) {
  const pet = PETS[petId];
  const stage = opts.stage || (PetState.stage ? PetState.stage(petId) : 1) || 1;
  const useAtlas = petsAtlasReady(scene);
  const sheetKey = useAtlas ? PETS_ATLAS_KEY : petSheetKey(petId, stage);
  if (!pet || !petTexExists(scene, petId, stage)) return null;
  const scale = (opts.scale || 2.0) * (stage >= 2 ? 1.16 : 1);
  const c = scene.add.container(opts.x || 0, opts.y || 0).setDepth(opts.depth != null ? opts.depth : 20);
  const flip = !!opts.flip;

  // Bayangan.
  const shadow = scene.textures.exists('fx_tex_shadow')
    ? scene.add.image(0, 2, 'fx_tex_shadow').setAlpha(0.34).setDisplaySize(40, 13)
    : scene.add.image(0, 2, 'fx_tex_shadow').setDisplaySize(34, 10).setAlpha(0.45);
  c.add(shadow);

  // Aura per rarity (common polos, makin tinggi makin ramai) — ASET glow +
  // sparkle mengorbit; tidak lagi menggambar lingkaran canvas per-frame.
  const rar = PET_RARITY_INFO[pet.rarity];
  let aura = null, auraPulse = 0, auraSparks = [], auraRing = null;
  if (pet.rarity !== 'common' && scene.textures.exists('fx_tex_glow')) {
    aura = scene.add.image(0, -14, 'fx_tex_glow').setBlendMode(Phaser.BlendModes.ADD);
    c.addAt(aura, 0);
    if (pet.rarity === 'legendary' || pet.rarity === 'mythic') {
      const nS = pet.rarity === 'mythic' ? 6 : 4;
      for (let i = 0; i < nS; i++) {
        const sp = scene.add.image(0, -14, 'fx_tex_sparkle').setBlendMode(Phaser.BlendModes.ADD).setScale(0.14);
        c.addAt(sp, 2); auraSparks.push(sp);
      }
    }
    if (stage >= 2 && scene.textures.exists('fx_tex_ring')) {
      auraRing = scene.add.image(0, -14, 'fx_tex_ring').setTint(0xfde68a).setBlendMode(Phaser.BlendModes.ADD).setScale(0.22, 0.11);
      c.addAt(auraRing, 1);
    }
  }

  // v11: sprite utama — sheet internet 16 frame @64px:
  // [0-3 idle][4-9 run][10-13 attack][14-15 hurt]. Animasi Phaser asli.
  const spr = (useAtlas ? scene.add.sprite(0, -12, PETS_ATLAS_KEY, petFrameName(petId, stage, 0)) : scene.add.sprite(0, -12, sheetKey, 0)).setOrigin(0.5, 1).setScale(flip ? -scale : scale, scale);
  c.add(spr);
  // v12: taksonomi gerak data-driven (flying/aquatic/ground/burrow) — bukan hardcode.
  const mv = pet.movement || 'ground';
  const flying = mv === 'flying';
  const aquatic = mv === 'aquatic';
  const burrower = mv === 'burrow';
  const atkType = pet.attackType || 'magic';
  const ap = 'petv11_' + petId + (stage >= 2 ? '_evo' : '');
  if (!scene.anims.exists(ap + '_idle')) {
    const FR = (a, b) => [...Array(b - a)].map((_, i) => ({ key: sheetKey, frame: useAtlas ? petFrameName(petId, stage, a + i) : a + i }));
    scene.anims.create({ key: ap + '_idle', frames: FR(0, 4), frameRate: 5, repeat: -1 });
    scene.anims.create({ key: ap + '_run', frames: FR(4, 10), frameRate: 13, repeat: -1 });
    scene.anims.create({ key: ap + '_attack', frames: FR(10, 14), frameRate: 12, repeat: 0 });
    scene.anims.create({ key: ap + '_hurt', frames: FR(14, 16), frameRate: 7, repeat: 0 });
    // v12 idle variants: 'bosan' (lambat mengantuk) + 'milih gerak' (goyah cepat).
    scene.anims.create({ key: ap + '_idle2', frames: [FR(0, 1)[0], FR(0, 1)[0], FR(1, 2)[0], FR(1, 2)[0], FR(2, 3)[0]], frameRate: 2, repeat: -1 });
    scene.anims.create({ key: ap + '_idle3', frames: [FR(2, 3)[0], FR(3, 4)[0], FR(2, 3)[0], FR(3, 4)[0]], frameRate: 9, repeat: 0 });
  }
  let petAnim = 'idle';
  const setPetAnim = (a) => {
    if (petAnim === a) return;
    petAnim = a;
    try { spr.play(ap + '_' + a, true); } catch (_) {}
  };
  try { spr.play(ap + '_idle'); } catch (_) {}

  const st = {
    container: c, sprite: spr, petId, pet, stage, sheetKey, flying, aquatic, burrower, atkType,
    vx: 0, vy: 0, bobT: R(0, 10), attackUntil: 0, dead: false,
    idleNextT: 0, idleMode: 0, idleModeUntil: 0, burrowed: false, burrowNextT: R(4000, 9000), burrowPop: null,
    attack() { // v12: animasi serang asli + gaya sesuai attackType
      this.attackUntil = scene.time.now + (this.atkType === 'melee' ? 420 : 340);
      if (this.burrowed) { this.burrowed = false; scene.tweens.add({ targets: spr, alpha: 1, y: '-12', duration: 160 }); } // muncul duluan
      setPetAnim('attack');
      if (this.atkType === 'melee') {
        scene.tweens.add({ targets: c, scaleX: { from: 1.22, to: 1 }, scaleY: { from: 0.9, to: 1 }, duration: 260, ease: 'Back.easeOut' });
      } else if (this.atkType === 'magic' || this.atkType === 'support') {
        scene.tweens.add({ targets: c, scaleX: { from: 1.12, to: 1 }, duration: 220 });
        if (scene.textures.exists('fx_tex_glow')) { // kilat channel mantera
          const ch = scene.add.image(0, -16, 'fx_tex_glow').setBlendMode(Phaser.BlendModes.ADD).setScale(0.14).setDepth(79);
          c.addAt(ch, 1);
          scene.tweens.add({ targets: ch, alpha: 0, scale: 0.3, duration: 240, onComplete: () => ch.destroy() });
        }
      } else {
        scene.tweens.add({ targets: c, scaleX: { from: 0.92, to: 1 }, duration: 200 }); // recoil lemparan
      }
      scene.time.delayedCall(360, () => { if (!this.dead) petAnim = ''; });
    },
    hurt() { try { spr.play(ap + '_hurt'); } catch (_) {} scene.time.delayedCall(320, () => { petAnim = ''; }); },
    setFlip(f) { if (!!f !== (spr.scaleX < 0)) spr.setScale(f ? -scale : scale, scale); },
    destroy() { this.dead = true; c.destroy(); },
    update(dt, target) {
      if (this.dead) return;
      const now = scene.time.now;
      // Spring follow: percepat menuju titik target di samping karakter.
      if (target) {
        const k = 0.028, damp = 0.86;
        this.vx = (this.vx + (target.x - c.x) * k) * damp;
        this.vy = (this.vy + (target.y - c.y) * k) * damp;
        c.x += this.vx; c.y += this.vy;
        if (Math.abs(this.vx) > 0.4) this.setFlip(this.vx < 0);
      }
      const moving = Math.abs(this.vx) > 0.9 || Math.abs(this.vy) > 0.9;
      // v12 BURROW: pet penggali sesekali menghilang ke tanah lalu muncul lagi.
      if (this.burrower) {
        if (!this.burrowed && !moving && now > this.burrowNextT) {
          this.burrowed = true;
          this.burrowPop = now + R(1400, 2400);
          scene.tweens.add({ targets: spr, alpha: 0.12, y: '-=6', duration: 240, ease: 'Quad.easeIn' });
        }
        if (this.burrowed && (now > this.burrowPop || moving)) {
          this.burrowed = false;
          this.burrowNextT = now + R(6000, 12000);
          scene.tweens.add({ targets: spr, alpha: 1, y: '-12', duration: 200, ease: 'Back.easeOut' });
          if (scene.textures.exists('fx_tex_smoke')) {
            const puf = scene.add.image(c.x, c.y - 4, 'fx_tex_smoke').setAlpha(0.55).setScale(0.12).setDepth(79);
            scene.tweens.add({ targets: puf, alpha: 0, scale: 0.3, duration: 300, onComplete: () => puf.destroy() });
          }
        }
      }
      // v12 IDLE VARIANTS ("kepribadian"): bosan / regang, probabilistik.
      if (now >= this.attackUntil && !this.burrowed) {
        if (!moving) {
          if (!this.idleNextT) this.idleNextT = now + R(5000, 10000);
          if (this.idleMode === 1) { // mode bosan aktif
            if (now > this.idleModeUntil) { this.idleMode = 0; this.idleNextT = now + R(5000, 10000); setPetAnim('idle'); }
            else if (petAnim !== 'idle2') setPetAnim('idle2');
          } else if (now > this.idleNextT) {
            if (Math.random() < 0.55) { this.idleMode = 1; this.idleModeUntil = now + R(2200, 3800); }
            else { setPetAnim('idle3'); this.idleNextT = now + R(5000, 10000); } // goyah sebentar
          } else if (petAnim === 'idle3' || petAnim === 'idle2') setPetAnim('idle');
          else if (petAnim !== 'idle') setPetAnim('idle');
        } else setPetAnim('run');
      }
      // Pet terbang melayang halus; air bergoyang lembut; darat bob + squash.
      this.bobT += dt * (flying ? 0.006 : aquatic ? 0.005 : 0.004);
      const bob = Math.sin(this.bobT) * (flying ? 4.2 : aquatic ? 3.4 : 2.2);
      const squash = (flying || aquatic) ? 1 : 1 + Math.sin(this.bobT * 2) * 0.03;
      spr.setY(-12 + bob);
      spr.setScale((this.vx < 0 ? -1 : 1) * scale * squash, scale * (2 - squash));
      if (aquatic) spr.setRotation(Math.sin(this.bobT) * 0.09); else spr.setRotation(0);
      // Aura (aset) mengikuti napas.
      if (aura) {
        auraPulse += dt * 0.003;
        const rr = 15 + Math.sin(auraPulse) * 1.5;
        aura.setTint(rar.glow).setAlpha(pet.rarity === 'uncommon' ? 0.16 : 0.24).setScale((rr * 2) / 128, (rr * 1.16) / 128);
        for (let i = 0; i < auraSparks.length; i++) {
          const a = auraPulse * (pet.rarity === 'mythic' ? 1.9 : 1.4) + i * Math.PI * 2 / auraSparks.length;
          auraSparks[i].setPosition(Math.cos(a) * (rr + 8), -14 + Math.sin(a) * (rr + 8) * 0.5)
            .setAlpha(0.7 + Math.sin(auraPulse * 3 + i) * 0.25);
          if (pet.rarity === 'mythic') auraSparks[i].setTint([0xf43f5e, 0xfbbf24, 0x4ade80, 0x38bdf8, 0xc084fc, 0xf9a8d4][i % 6]);
        }
        if (auraRing) auraRing.setAlpha(0.35 + Math.sin(auraPulse * 2) * 0.18).setRotation(auraPulse * 0.5);
      }
    },
  };
  // Hook update scene (sekali pasang, otomatis bersih).
  const upd = (time, delta) => {
    if (st.dead) { scene.events.off('update', upd); return; }
    let target = null;
    if (opts.follow && typeof opts.follow.get === 'function') {
      try { target = opts.follow.get(); } catch (_) {}
    }
    st.update(delta, target);
  };
  scene.events.on('update', upd);
  scene.events.once('shutdown', () => st.destroy());
  return st;
}

// FX ledakan skill pet sesuai elemen — dipanggil saat pet menyerang (semua scene).
/* FX ledakan skill pet sesuai elemen — SEMUA pakai aset fx/ (glow, sparkle,
 * streak, ring) + aset batu deco. Canvas hanya fallback terakhir. */
/* ---------- v11: VFX PLAYER (sheet frame animasi aset internet) ---------- */
function vfxFrameCount(scene, key) {
  try {
    const fr = scene.textures.get(key).frames;
    let n = Object.keys(fr).length;
    if (fr.__BASE) n -= 1; // Phaser menambah frame __BASE — jangan dihitung.
    return Math.max(1, n);
  } catch (_) { return 8; }
}
function playVfx(scene, key, x, y, opts = {}) {
  if (!scene || !scene.textures.exists(key)) return null;
  const n = vfxFrameCount(scene, key);
  const fps = opts.fps || 14;
  const akey = 'vfxplay_' + key;
  if (!scene.anims.exists(akey)) {
    scene.anims.create({ key: akey, frames: scene.anims.generateFrameNumbers(key, { start: 0, end: n - 1 }), frameRate: fps, repeat: 0 });
  }
  const sp = scene.add.sprite(x, y, key, 0).setDepth(opts.depth != null ? opts.depth : 880).setScale(opts.scale || 1);
  sp.setBlendMode(opts.solid ? Phaser.BlendModes.NORMAL : Phaser.BlendModes.ADD);
  if (opts.alpha != null) sp.setAlpha(opts.alpha);
  if (opts.tint) sp.setTint(opts.tint);
  if (opts.angle) sp.setRotation(opts.angle);
  try { sp.play(akey, true); } catch (_) {}
  sp.once('animationcomplete', () => { try { sp.destroy(); } catch (_) {} });
  scene.time.delayedCall(Math.ceil(n / fps) * 1000 + 420, () => { try { sp.destroy(); } catch (_) {} });
  return sp;
}
/* v13: LEDAKAN aset Craftpix (paket user) — peta nama semantik -> sheet.
 * Selalu DITAMBAHKAN di atas VFX lama (enhance, bukan menggantikan) sehingga
 * tidak ada efek yang di-nerf. kind: orange/circle/blue/oval/gas/gasc/two/
 * nuke/fire/light/smoke/boss (acak mengesankan). */
const EXPL_SHEET = {
  orange: 'fx_expl_orange', circle: 'fx_expl_circle', blue: 'fx_expl_blue', oval: 'fx_expl_oval',
  gas: 'fx_expl_gas', gasc: 'fx_expl_gasc', two: 'fx_expl_two', nuke: 'fx_expl_nuke',
  fire: 'fx_expl_fire', light: 'fx_expl_light', smoke: 'fx_expl_smoke',
};
function playExplosion(scene, kind, x, y, opts = {}) {
  const key = EXPL_SHEET[kind] || EXPL_SHEET.orange;
  if (!scene || !scene.textures.exists(key)) return null;
  const big = opts.big ? 1.55 : 1;
  return playVfx(scene, key, x, y, {
    scale: (opts.scale != null ? opts.scale : 1.0) * big,
    fps: opts.fps || 16,
    depth: opts.depth != null ? opts.depth : 878,
    alpha: opts.alpha,
    tint: opts.tint,
  });
}
/* v11: proyektil skill pet — orb elemen meluncur lalu MELEDAK saat kena;
 * damage dipanggil di momen IMPACT (memperbaiki bug 'kelihatan miss tapi kena'). */
function fxPetProjectile(scene, x, y, tx, ty, element, onHit, scale = 1) {
  const einfo = PET_ELEMENT_INFO[element] || {};
  const col = Phaser.Display.Color.HexStringToColor(einfo.color || '#ffffff').color;
  const key = scene.textures.exists('fx_tex_glow') ? 'fx_tex_glow' : 'fx_tex_flash';
  const orb = scene.add.image(x, y - 18, key).setDepth(870).setScale(0.36 * scale).setBlendMode(Phaser.BlendModes.ADD).setTint(col);
  const core = scene.textures.exists('fx_tex_sparkle')
    ? scene.add.image(x, y - 18, 'fx_tex_sparkle').setDepth(871).setScale(0.2 * scale).setBlendMode(Phaser.BlendModes.ADD).setTint(0xffffff)
    : null;
  const dist = Math.hypot(tx - x, ty - y);
  const dur = Math.max(200, Math.min(430, dist * 1.15));
  let lastTrail = 0;
  scene.tweens.add({
    targets: [orb, core].filter(Boolean), x: tx, y: ty - 22, duration: dur, ease: 'Quad.easeIn',
    onUpdate: () => {
      if (core) core.setRotation(core.rotation + 0.4);
      const now = scene.time.now;
      if (now - lastTrail > 46 && scene.textures.exists('fx_tex_sparkle')) {
        lastTrail = now;
        const tr = scene.add.image(orb.x, orb.y, 'fx_tex_sparkle').setDepth(869).setScale(R(0.05, 0.11)).setAlpha(0.85).setBlendMode(Phaser.BlendModes.ADD).setTint(col);
        scene.tweens.add({ targets: tr, alpha: 0, scale: 0.02, duration: 260, onComplete: () => tr.destroy() });
      }
    },
    onComplete: () => {
      const ox = orb.x, oy = orb.y;
      orb.destroy(); if (core) core.destroy();
      playVfx(scene, PET_ELEMENT_VFX[element] || 'vfx_arcane', ox, oy, { scale: 0.9 * scale, fps: 16, depth: 875 });
      fxRing(scene, ox, oy, col, 54, 320);
      fxSparks(scene, ox, oy, col, 12);
      if (onHit) onHit();
    },
  });
  return dur;
}
/* v11: sinematik ULTIMATE pet — lingkaran summon + aura + guncangan + ledakan besar. */
function petUltimateCinematic(scene, pet, x, y, element, onBurst) {
  const einfo = PET_ELEMENT_INFO[element] || {};
  const col = Phaser.Display.Color.HexStringToColor(einfo.color || '#ffffff').color;
  const c = Phaser.Display.Color.IntegerToColor(col);
  playVfx(scene, 'vfx_circle', x, y + 8, { scale: 0.9, fps: 10, depth: 869, tint: col });
  const auraKey = (element === 'light' || element === 'holy' || element === 'fire' || element === 'solar') ? 'vfx_aura_fire'
    : (element === 'dark' || element === 'void' || element === 'darkfire') ? 'vfx_aura_purple' : 'vfx_aura_blue';
  playVfx(scene, auraKey, x, y - 44, { scale: 0.72, fps: 16, depth: 871, tint: col });
  try {
    scene.cameras.main.flash(150, c.red * 255, c.green * 255, c.blue * 255);
    scene.cameras.main.shake(280, 0.006);
  } catch (_) {}
  // v12: lapisan sinematik bersama (slow-mo + vignette + judul ultimate).
  cinematicUltimate(scene, { color: col, name: ((pet && pet.name) ? pet.name.toUpperCase() + ': ' : '') + 'ULTIMATE', dur: 850 });
  scene.time.delayedCall(430, () => {
    playVfx(scene, PET_ULT_VFX[element] || 'vfx_fire', x, y - 52, { scale: 2.3, fps: 16, depth: 876 });
    // v13: lapisan ledakan besar (aset Craftpix) di bawah VFX elemen — ultimate terasa menghancurkan.
    playExplosion(scene, 'nuke', x, y - 46, { scale: 2.1, big: true, depth: 875 });
    if (onBurst) onBurst();
  });
}
function petSkillFx(scene, x, y, tx, ty, element) {
  const col = Phaser.Display.Color.HexStringToColor((PET_ELEMENT_INFO[element] || {}).color || '#ffffff').color;
  const ang = Math.atan2(ty - y, tx - x);
  const has = (k) => scene.textures.exists('fx_tex_' + k);
  const imgP = (key, px, py, tint, sc, dur, to) => {
    const p = scene.add.image(px, py, 'fx_tex_' + key).setTint(tint).setBlendMode(Phaser.BlendModes.ADD).setDepth(60).setScale(sc);
    scene.tweens.add(Object.assign({ targets: p, alpha: 0, duration: dur, onComplete: () => p.destroy() }, to || {}));
    return p;
  };
  if (element === 'fire' || element === 'darkfire') {
    for (let i = 0; i < 7; i++) {
      imgP('glow', x, y - 14, element === 'fire' ? 0xfb923c : 0xa855f7, R(0.10, 0.20), R(260, 480),
        { x: x + Math.cos(ang) * R(30, 70) + R(-8, 8), y: y - 14 + Math.sin(ang) * R(10, 40) - R(4, 26), scale: 0.04 });
    }
  } else if (element === 'bolt') {
    if (has('streak')) {
      for (let i = 1; i <= 5; i++) {
        const bx = x + (tx - x) * (i / 5) + R(-9, 9);
        const by = y - 20 + (ty - 20 - (y - 20)) * (i / 5) + R(-7, 7);
        const seg = scene.add.image(bx, by, 'fx_tex_streak').setTint(0xfde047).setBlendMode(Phaser.BlendModes.ADD).setDepth(60).setScale(0.30, 0.55).setRotation(Math.PI / 2 + ang);
        scene.tweens.add({ targets: seg, alpha: 0, duration: 160, delay: i * 14, onComplete: () => seg.destroy() });
      }
    }
    imgP('glow', tx, ty - 18, 0xfde047, 0.32, 190);
  } else if (element === 'ice') {
    for (let i = 0; i < 6; i++) {
      if (!has('sparkle')) break;
      imgP('sparkle', tx + R(-14, 14), ty + R(-2, 4), 0xbae6fd, R(0.08, 0.16), R(240, 420), { y: ty - R(6, 26), angle: R(-40, 40) });
    }
  } else if (element === 'nature' || element === 'holy' || element === 'light') {
    fxRing(scene, x, y - 14, col, 36, 460);
    for (let i = 0; i < 6; i++) {
      if (!has('sparkle')) break;
      imgP('sparkle', x + R(-16, 16), y - 8, col, R(0.07, 0.13), R(400, 700), { y: y - R(20, 46), angle: R(-160, 160) });
    }
  } else if (element === 'water') {
    for (let i = 0; i < 8; i++) {
      const a2 = ang + R(-0.7, 0.7);
      imgP('glow', x, y - 12, 0x38bdf8, 0.07, R(240, 420), { x: x + Math.cos(a2) * R(24, 60), y: y - 12 + Math.sin(a2) * R(8, 30) });
    }
  } else if (element === 'wind') {
    for (let i = 0; i < 3; i++) {
      imgP('streak', x + Math.cos(ang) * (10 + i * 10), y - 14 + Math.sin(ang) * (10 + i * 10), 0x7dd3fc, 0.30, 300 + i * 90,
        { x: x + Math.cos(ang) * (34 + i * 14), y: y - 14 + Math.sin(ang) * (34 + i * 14), rotation: ang });
    }
  } else if (element === 'poison') {
    for (let i = 0; i < 6; i++) {
      imgP('glow', x + R(-6, 6), y - 14, 0xa3e635, R(0.08, 0.14), R(300, 520), { x: tx + R(-12, 12), y: ty - R(4, 22) });
    }
  } else if (element === 'earth') {
    for (let i = 0; i < 5; i++) {
      const rx = x + R(-20, 20);
      if (scene.textures.exists('asset_deco_rock1')) {
        const rk = scene.add.image(rx, ty, 'asset_deco_rock1').setOrigin(0.5, 1).setScale(R(0.30, 0.55)).setDepth(60).setFlipX(Math.random() < 0.5);
        scene.tweens.add({ targets: rk, y: ty - R(14, 34), angle: R(-24, 24), duration: R(260, 420), yoyo: true, onComplete: () => rk.destroy() });
      } else {
        imgP('glow', rx, ty, 0x78716c, 0.12, 320, { y: ty - R(14, 34) });
      }
    }
    try { scene.cameras.main.shake(90, 0.003); } catch (_) {}
  } else { // dark & default
    for (let i = 0; i < 6; i++) {
      imgP('glow', x, y - 14, 0xa78bfa, R(0.08, 0.15), R(280, 460), { x: x + (tx - x) * 0.5 + R(-14, 14), y: y - 14 + (ty - y) * 0.5 - R(6, 26) });
    }
  }
}

// ---------- Item katalog (senjata Archer menggantikan Healer) ----------
const ITEMS = {
  // SENJATA WARRIOR (8)
  w_rusty:       { id: 'w_rusty', name: 'Pedang Karatan', cat: 'weapon', type: 'sword', class: 'warrior', tier: 'common', atk: 3, price: 80, effect: { kind: 'cleave', pct: 0.08 }, desc: 'Pedang tua, tapi masih bisa dipakai.' },
  w_steel:       { id: 'w_steel', name: 'Pedang Baja', cat: 'weapon', type: 'sword', class: 'warrior', tier: 'uncommon', atk: 7, price: 250, effect: { kind: 'critDmg', pct: 0.15 }, desc: 'Ditempa dari baja berkualitas — sisi tajamnya menaikkan critical.' },
  w_iron_axe:    { id: 'w_iron_axe', name: 'Kapak Besi', cat: 'weapon', type: 'axe', class: 'warrior', tier: 'uncommon', atk: 9, price: 280, effect: { kind: 'execute', pct: 0.12 }, desc: 'Kapak berat yang mudah menjatuhkan musuh lemah.' },
  w_elven:       { id: 'w_elven', name: 'Pedang Elf', cat: 'weapon', type: 'sword', class: 'warrior', tier: 'rare', atk: 13, spd: 2, price: 600, effect: { kind: 'lifesteal', pct: 0.06 }, desc: 'Ringan dan tajam, buatan pengrajin elf — sedikit menyerap nyawa.' },
  w_warhammer:   { id: 'w_warhammer', name: 'Palu Perang', cat: 'weapon', type: 'hammer', class: 'warrior', tier: 'rare', atk: 14, def: 2, price: 650, effect: { kind: 'cleave', pct: 0.3 }, desc: 'Ayunan palunya menyapu musuh di sekitar.' },
  w_knight_spear:{ id: 'w_knight_spear', name: 'Tombak Ksatria', cat: 'weapon', type: 'spear', class: 'warrior', tier: 'epic', atk: 20, spd: 4, price: 1400, effect: { kind: 'cleave', pct: 0.35 }, desc: 'Jangkauan jauh — tebasan menyapu beberapa musuh sekaligus.' },
  w_dragon:      { id: 'w_dragon', name: 'Pedang Taring Naga', cat: 'weapon', type: 'sword', class: 'warrior', tier: 'epic', atk: 22, price: 1500, effect: { kind: 'lifesteal', pct: 0.15 }, desc: 'Ditempa dari taring naga asli. Menghisap nyawa musuh.' },
  w_omega:       { id: 'w_omega', name: 'Pedang Legenda OMEGA', cat: 'weapon', type: 'sword', class: 'warrior', tier: 'mythic', atk: 35, crit: 5, price: 4000, effect: { kind: 'cleave', pct: 0.5 }, desc: 'Senjata para legenda. Tebasannya menyapu seluruh medan.' },
  // SENJATA MAGE (7)
  w_wood_staff:  { id: 'w_wood_staff', name: 'Tongkat Kayu', cat: 'weapon', type: 'staff', class: 'mage', tier: 'common', atk: 4, price: 80, effect: { kind: 'manaRegen', val: 3 }, desc: 'Tongkat sederhana yang mengalirkan mana perlahan.' },
  w_flame_wand:  { id: 'w_flame_wand', name: 'Tongkat Api', cat: 'weapon', type: 'wand', class: 'mage', tier: 'uncommon', atk: 8, price: 260, effect: { kind: 'poison', dot: 0.1, turns: 2 }, desc: 'Ujungnya menyala — serangan membakar musuh (damage per giliran).' },
  w_arcane_orb:  { id: 'w_arcane_orb', name: 'Bola Arcanum', cat: 'weapon', type: 'orb', class: 'mage', tier: 'rare', atk: 13, crit: 3, price: 620, effect: { kind: 'critDmg', pct: 0.3 }, desc: 'Kristal arcanum yang memusatkan energi ke satu titik lemah.' },
  w_void_orb:    { id: 'w_void_orb', name: 'Bola Kehampaan', cat: 'weapon', type: 'orb', class: 'mage', tier: 'rare', atk: 12, spd: 2, price: 640, effect: { kind: 'manaRegen', val: 8 }, desc: 'Menyerap energi kehampaan — MP pulih jauh lebih cepat.' },
  w_frost_staff: { id: 'w_frost_staff', name: 'Tongkat Es', cat: 'weapon', type: 'staff', class: 'mage', tier: 'epic', atk: 20, spd: 3, price: 1450, effect: { kind: 'manaRegen', val: 6 }, desc: 'Dingin membekukan — memulihkan MP tiap giliran.' },
  w_meteor_tome: { id: 'w_meteor_tome', name: 'Kitab Meteor', cat: 'weapon', type: 'tome', class: 'mage', tier: 'epic', atk: 23, price: 1550, effect: { kind: 'execute', pct: 0.25 }, desc: 'Kitab kuno. Siram musuh yang nyaris tumbang.' },
  w_archstaff:   { id: 'w_archstaff', name: 'Tongkat Archmage', cat: 'weapon', type: 'staff', class: 'mage', tier: 'mythic', atk: 36, crit: 8, price: 4100, effect: { kind: 'manaRegen', val: 12 }, desc: 'Tongkat sang Archmage. Energi sihir mengalir tanpa henti.' },
  // SENJATA ASSASSIN (7)
  w_rusty_dagger:{ id: 'w_rusty_dagger', name: 'Belati Karatan', cat: 'weapon', type: 'dagger', class: 'assassin', tier: 'common', atk: 3, spd: 2, price: 80, effect: { kind: 'poison', dot: 0.06, turns: 2 }, desc: 'Belati kecil berkarat — sisa racunnya masih menusuk.' },
  w_sharp_katana:{ id: 'w_sharp_katana', name: 'Katana Tajam', cat: 'weapon', type: 'katana', class: 'assassin', tier: 'uncommon', atk: 7, spd: 2, price: 270, effect: { kind: 'critDmg', pct: 0.2 }, desc: 'Bilah ramping setajam silet — critical terasa lebih sakit.' },
  w_venom_claw:  { id: 'w_venom_claw', name: 'Cakar Beracun', cat: 'weapon', type: 'claw', class: 'assassin', tier: 'rare', atk: 12, crit: 3, price: 640, effect: { kind: 'poison', dot: 0.15, turns: 3 }, desc: 'Cakar berlapis racun — meracuni lawan tiap serangan.' },
  w_twin_fang:   { id: 'w_twin_fang', name: 'Belati Taring Kembar', cat: 'weapon', type: 'dagger', class: 'assassin', tier: 'rare', atk: 11, spd: 4, price: 660, effect: { kind: 'cleave', pct: 0.25 }, desc: 'Sepasang belati viper — tebasan ganda menyapu ke depan.' },
  w_shadow_bow:  { id: 'w_shadow_bow', name: 'Busur Bayangan', cat: 'weapon', type: 'bow', class: 'assassin', tier: 'epic', atk: 20, crit: 6, price: 1450, effect: { kind: 'critDmg', pct: 0.25 }, desc: 'Panah bayangan yang selalu menemukan titik lemah.' },
  w_night_katana:{ id: 'w_night_katana', name: 'Katana Malam', cat: 'weapon', type: 'katana', class: 'assassin', tier: 'epic', atk: 21, spd: 5, price: 1500, effect: { kind: 'execute', pct: 0.2 }, desc: 'Ditempa di bawah bulan — mematikan bagi musuh sekarat.' },
  w_phantom:     { id: 'w_phantom', name: 'Belati Phantom', cat: 'weapon', type: 'dagger', class: 'assassin', tier: 'mythic', atk: 33, crit: 12, spd: 8, price: 4000, effect: { kind: 'execute', pct: 0.3 }, desc: 'Belati yang menembus bayangan dan jantung sekaligus.' },
  // SENJATA ARCHER (6 — menggantikan Healer)
  w_short_bow:   { id: 'w_short_bow', name: 'Busur Pemburu', cat: 'weapon', type: 'bow', class: 'archer', tier: 'common', atk: 4, price: 80, effect: { kind: 'critDmg', pct: 0.1 }, desc: 'Busur kayu lurus. Berat tarikannya jujur, panahnya juga.' },
  w_hunt_longbow:{ id: 'w_hunt_longbow', name: 'Longbow Pemburu', cat: 'weapon', type: 'bow', class: 'archer', tier: 'uncommon', atk: 8, spd: 2, price: 260, effect: { kind: 'critDmg', pct: 0.15 }, desc: 'Lengkung tinggi warisan pemburu tua — bidikan sedikit lebih tajam.' },
  w_recurve_bow: { id: 'w_recurve_bow', name: 'Busur Recurve', cat: 'weapon', type: 'bow', class: 'archer', tier: 'rare', atk: 13, crit: 3, price: 620, effect: { kind: 'critDmg', pct: 0.25 }, desc: 'Ujungnya melengkung dua arah. Tenang menembus angin.' },
  w_bone_bow:    { id: 'w_bone_bow', name: 'Busur Tulang', cat: 'weapon', type: 'bow', class: 'archer', tier: 'rare', atk: 12, spd: 4, price: 640, effect: { kind: 'poison', dot: 0.08, turns: 3 }, desc: 'Dirangkai dari tulang makhluk gua. Lukanya suka bernanah.' },
  w_elven_bow:   { id: 'w_elven_bow', name: 'Busur Elf', cat: 'weapon', type: 'bow', class: 'archer', tier: 'epic', atk: 20, crit: 5, price: 1400, effect: { kind: 'critDmg', pct: 0.3 }, desc: 'Kayu elf yang selalu ingat ke mana panah harus pergi.' },
  w_windseeker:  { id: 'w_windseeker', name: 'Windseeker', cat: 'weapon', type: 'bow', class: 'archer', tier: 'mythic', atk: 34, crit: 10, spd: 6, price: 4000, effect: { kind: 'critDmg', pct: 0.4 }, desc: 'Busur legendaris yang menembak sebelum kamu sempat berpikir.' },
  // ZIRAH (13)
  a_leather:     { id: 'a_leather', name: 'Baju Kulit', cat: 'armor', atype: 'light', tier: 'common', def: 3, price: 80, effect: { kind: 'regen', val: 1 }, desc: 'Perlindungan dasar yang memulihkan luka perlahan.' },
  a_padded_vest: { id: 'a_padded_vest', name: 'Rompi Empuk', cat: 'armor', atype: 'light', tier: 'common', def: 2, hp: 10, price: 85, effect: { kind: 'thorns', pct: 0.05 }, desc: 'Rompi tebal yang memantulkan sedikit pukulan.' },
  a_chain:       { id: 'a_chain', name: 'Baju Rantai', cat: 'armor', atype: 'mail', tier: 'uncommon', def: 7, price: 250, effect: { kind: 'thorns', pct: 0.08 }, desc: 'Anyaman rantai yang memantulkan serangan.' },
  a_ranger_coat: { id: 'a_ranger_coat', name: 'Jaket Ranger', cat: 'armor', atype: 'coat', tier: 'uncommon', def: 5, spd: 3, price: 260, effect: { kind: 'dodge', pct: 0.06 }, desc: 'Jaket pelari rimba — serangan musuh kadang meleset.' },
  a_guardian:    { id: 'a_guardian', name: 'Zirah Penjaga', cat: 'armor', atype: 'plate', tier: 'rare', def: 12, hp: 20, price: 620, effect: { kind: 'shield', pct: 0.12 }, desc: 'Zirah penjaga yang memberi perisai di awal bertempur.' },
  a_plate:       { id: 'a_plate', name: 'Baju Pelat', cat: 'armor', atype: 'plate', tier: 'rare', def: 13, price: 600, effect: { kind: 'thorns', pct: 0.15 }, desc: 'Pelat baja tebal — musuh yang menyerang ikut terluka.' },
  a_mithril_mail:{ id: 'a_mithril_mail', name: 'Zirah Mithril', cat: 'armor', atype: 'mail', tier: 'rare', def: 11, spd: 2, mp: 10, price: 640, effect: { kind: 'manaRegen', val: 4 }, desc: 'Ringan berkilau — mana mengalir lebih lancar.' },
  a_dragon:      { id: 'a_dragon', name: 'Zirah Sisik Naga', cat: 'armor', atype: 'scale', tier: 'epic', def: 22, price: 1500, effect: { kind: 'thorns', pct: 0.25 }, desc: 'Sisik naga memantulkan seperempat damage ke penyerang.' },
  a_titan_aegis: { id: 'a_titan_aegis', name: 'Aegis Titan', cat: 'armor', atype: 'aegis', tier: 'epic', def: 18, hp: 40, price: 1450, effect: { kind: 'shield', pct: 0.2 }, desc: 'Perisai raksasa para titan — pelindung awal yang tebal.' },
  a_frost_bulwark:{ id: 'a_frost_bulwark', name: 'Benteng Beku', cat: 'armor', atype: 'bulwark', tier: 'epic', def: 20, mp: 15, price: 1500, effect: { kind: 'regen', val: 5 }, desc: 'Kegelapan es yang terus memulihkan tubuhnya.' },
  a_omega:       { id: 'a_omega', name: 'Zirah Suci OMEGA', cat: 'armor', atype: 'aegis', tier: 'mythic', def: 35, spd: 5, price: 4000, effect: { kind: 'shield', pct: 0.25 }, desc: 'Diberkati guild tertinggi. Memberi perisai saat bertempur.' },
  a_void_shroud: { id: 'a_void_shroud', name: 'Selubung Kehampaan', cat: 'armor', atype: 'shroud', tier: 'mythic', def: 26, spd: 6, price: 4200, effect: { kind: 'dodge', pct: 0.12 }, desc: 'Tubuhmu setengah ada di dimensi lain — serangan menembus kosong.' },
  a_phoenix_mail:{ id: 'a_phoenix_mail', name: 'Zirah Phoenix', cat: 'armor', atype: 'scale', tier: 'mythic', def: 30, hp: 50, price: 4400, effect: { kind: 'revive', pct: 0.3 }, desc: 'Seperti phoenix: bangkit sekali dari kematian dengan 30% HP.' },
  // AKSESORIS (13)
  c_lucky_coin:  { id: 'c_lucky_coin', name: 'Koin Keberuntungan', cat: 'accessory', ctype: 'coin', tier: 'common', spd: 1, price: 120, effect: { kind: 'goldFind', pct: 0.1 }, desc: 'Koin kuno yang selalu menarik emas ke arahmu.' },
  c_swift:       { id: 'c_swift', name: 'Cincin Gesit', cat: 'accessory', ctype: 'ring', tier: 'uncommon', spd: 3, price: 100, effect: { kind: 'dodge', pct: 0.04 }, desc: 'Gerakanmu lebih ringan — sedikit peluang menghindar.' },
  c_crit:        { id: 'c_crit', name: 'Anting Kritis', cat: 'accessory', ctype: 'earring', tier: 'uncommon', crit: 3, price: 100, effect: { kind: 'critDmg', pct: 0.15 }, desc: 'Menajamkan insting — critical lebih berdarah.' },
  c_mana_ring:   { id: 'c_mana_ring', name: 'Cincin Mana', cat: 'accessory', ctype: 'ring', tier: 'uncommon', mp: 15, price: 180, effect: { kind: 'manaRegen', val: 3 }, desc: 'Cincin safir yang meneteskan mana perlahan.' },
  c_cloak:       { id: 'c_cloak', name: 'Jubah Bayangan', cat: 'accessory', ctype: 'cloak', tier: 'rare', spd: 6, crit: 2, price: 400, effect: { kind: 'dodge', pct: 0.08 }, desc: 'Menyatu dengan bayangan — serangan meleset lebih sering.' },
  c_vital:       { id: 'c_vital', name: 'Gelang Vitalitas', cat: 'accessory', ctype: 'bracelet', tier: 'rare', hp: 40, price: 420, effect: { kind: 'regen', val: 2 }, desc: 'Menguatkan daya tahan tubuh dan memulihkannya.' },
  c_blood_pendant:{ id: 'c_blood_pendant', name: 'Liontin Darah', cat: 'accessory', ctype: 'necklace', tier: 'rare', atk: 6, price: 450, effect: { kind: 'lifesteal', pct: 0.08 }, desc: 'Berdenyut seperti jantung — menyerap nyawa musuh.' },
  c_thorn_bracer:{ id: 'c_thorn_bracer', name: 'Deker Duri', cat: 'accessory', ctype: 'bracer', tier: 'rare', def: 4, price: 440, effect: { kind: 'thorns', pct: 0.12 }, desc: 'Duri hitam yang melukai siapa pun yang menyerangmu.' },
  c_crown:       { id: 'c_crown', name: 'Mahkota Raja', cat: 'accessory', ctype: 'crown', tier: 'epic', spd: 10, crit: 5, price: 1200, effect: { kind: 'goldFind', pct: 0.15 }, desc: 'Harta karun para raja — emas mengalir lebih deras.' },
  c_storm_charm: { id: 'c_storm_charm', name: 'Jimat Badai', cat: 'accessory', ctype: 'charm', tier: 'epic', crit: 8, price: 1250, effect: { kind: 'critDmg', pct: 0.4 }, desc: 'Listrik badai meledak di setiap critical.' },
  c_guardian_angel:{ id: 'c_guardian_angel', name: 'Pelindung Malaikat', cat: 'accessory', ctype: 'amulet', tier: 'epic', def: 6, hp: 30, price: 1300, effect: { kind: 'shield', pct: 0.15 }, desc: 'Sayap halus membentuk perisai cahaya di awal bertempur.' },
  c_phoenix:     { id: 'c_phoenix', name: 'Kalung Phoenix', cat: 'accessory', ctype: 'necklace', tier: 'mythic', hp: 50, crit: 8, price: 4000, effect: { kind: 'lifesteal', pct: 0.12 }, desc: 'Abu phoenix — menghidupkan kembali semangatmu.' },
  c_time_hourglass:{ id: 'c_time_hourglass', name: 'Jam Pasir Waktu', cat: 'accessory', ctype: 'hourglass', tier: 'mythic', spd: 8, price: 4200, effect: { kind: 'revive', pct: 0.25 }, desc: 'Mengulang sekejap waktu — bangkit sekali dengan 25% HP.' },
  // MATERIAL (20 — drop monster untuk forge)
  m_slime_jelly: { id: 'm_slime_jelly', name: 'Jeli Slime', cat: 'material', mtype: 'jelly', tier: 'common', price: 12, use: { kind: 'heal', val: 15 }, desc: 'Gumpalan jeli lengket. Dimakan: pulihkan 15 HP.' },
  m_rat_tail:    { id: 'm_rat_tail', name: 'Ekor Tikus', cat: 'material', mtype: 'bone', tier: 'common', price: 10, use: { kind: 'mana', val: 10 }, desc: 'Ekor kering tikus kerangka. Dimakan: pulihkan 10 MP.' },
  m_bat_wing:    { id: 'm_bat_wing', name: 'Sayap Kelelawar', cat: 'material', mtype: 'wing', tier: 'common', price: 12, use: { kind: 'swift', val: 0.1, turns: 2 }, desc: 'Sayap tipis jurang. Konsumsi: hindar +10% (2 giliran).' },
  m_goblin_ear:  { id: 'm_goblin_ear', name: 'Telinga Goblin', cat: 'material', mtype: 'organ', tier: 'common', price: 15, use: { kind: 'heal', val: 20 }, desc: 'Telinga runcing goblin. Dimakan: pulihkan 20 HP.' },
  m_bone:        { id: 'm_bone', name: 'Tulang', cat: 'material', mtype: 'bone', tier: 'common', price: 10, use: { kind: 'strength', val: 0.1, turns: 2 }, desc: 'Tulang kerangka hidup. Digerus: ATK +10% (2 giliran).' },
  m_wolf_pelt:   { id: 'm_wolf_pelt', name: 'Bulu Serigala', cat: 'material', mtype: 'pelt', tier: 'uncommon', price: 22, use: { kind: 'shield', val: 0.1 }, desc: 'Bulu tebal serigala. Dililitkan: perisai 10% HP maks.' },
  m_venom_sac:   { id: 'm_venom_sac', name: 'Kantong Racun', cat: 'material', mtype: 'organ', tier: 'uncommon', price: 26, use: { kind: 'poison', val: 12, turns: 2 }, desc: 'Kantong racun laba-laba. Konsumsi: racun 12/giliran (2 giliran).' },
  m_imp_ember:   { id: 'm_imp_ember', name: 'Bara Iblis Kecil', cat: 'material', mtype: 'ember', tier: 'uncommon', price: 24, use: { kind: 'strength', val: 0.15, turns: 2 }, desc: 'Bara yang masih menyala. Konsumsi: ATK +15% (2 giliran).' },
  m_hyena_fang:  { id: 'm_hyena_fang', name: 'Taring Hyena', cat: 'material', mtype: 'bone', tier: 'uncommon', price: 22, use: { kind: 'heal', val: 25 }, desc: 'Taring tajam hyena gurun. Dimakan: pulihkan 25 HP.' },
  m_vulture_feather:{ id: 'm_vulture_feather', name: 'Bulu Nasar', cat: 'material', mtype: 'wing', tier: 'uncommon', price: 22, use: { kind: 'swift', val: 0.12, turns: 2 }, desc: 'Bulu burung nasar. Konsumsi: hindar +12% (2 giliran).' },
  m_turtle_shell:{ id: 'm_turtle_shell', name: 'Tempurung Kura', cat: 'material', mtype: 'shell', tier: 'rare', price: 40, use: { kind: 'shield', val: 0.15 }, desc: 'Tempurung kura raksasa. Dipakai: perisai 15% HP maks.' },
  m_gargoyle_shard:{ id: 'm_gargoyle_shard', name: 'Pecahan Gargoyle', cat: 'material', mtype: 'shard', tier: 'rare', price: 42, use: { kind: 'strength', val: 0.12, turns: 3 }, desc: 'Pecahan batu gargoyle. Digerus: ATK +12% (3 giliran).' },
  m_mummy_bandage:{ id: 'm_mummy_bandage', name: 'Perban Mumi', cat: 'material', mtype: 'bandage', tier: 'rare', price: 40, use: { kind: 'regen', val: 15, turns: 3 }, desc: 'Perban kuno. Dililitkan: regen 15 HP/giliran (3 giliran).' },
  m_orc_tusk:    { id: 'm_orc_tusk', name: 'Taring Orc', cat: 'material', mtype: 'bone', tier: 'rare', price: 45, use: { kind: 'strength', val: 0.2, turns: 2 }, desc: 'Taring besar orc. Digerus: ATK +20% (2 giliran).' },
  m_golem_core:  { id: 'm_golem_core', name: 'Inti Golem', cat: 'material', mtype: 'core', tier: 'rare', price: 50, use: { kind: 'shield', val: 0.2 }, desc: 'Inti batu berenergi. Dipakai: perisai 20% HP maks.' },
  m_wraith_ecto: { id: 'm_wraith_ecto', name: 'Ektoplasma', cat: 'material', mtype: 'ecto', tier: 'epic', price: 70, use: { kind: 'mana', val: 60 }, desc: 'Arwah yang membeku. Konsumsi: pulihkan 60 MP.' },
  m_yeti_fur:    { id: 'm_yeti_fur', name: 'Bulu Yeti', cat: 'material', mtype: 'pelt', tier: 'epic', price: 80, use: { kind: 'regen', val: 20, turns: 3 }, desc: 'Bulu tebal yeti salju. Dipakai: regen 20 HP/giliran (3 giliran).' },
  m_minotaur_horn:{ id: 'm_minotaur_horn', name: 'Tanduk Minotaur', cat: 'material', mtype: 'horn', tier: 'epic', price: 95, use: { kind: 'berserk', val: 0.4, turns: 2 }, desc: 'Tanduk sang minotaur. Digerus: ATK +40% (2 giliran).' },
  m_dragon_scale:{ id: 'm_dragon_scale', name: 'Sisik Naga', cat: 'material', mtype: 'scale', tier: 'epic', price: 110, use: { kind: 'shield', val: 0.25 }, desc: 'Sisik naga purba. Dipakai: perisai 25% HP maks.' },
  m_demon_heart: { id: 'm_demon_heart', name: 'Jantung Iblis', cat: 'material', mtype: 'heart', tier: 'mythic', price: 220, use: { kind: 'elixir' }, desc: 'Masih berdetak. Dikonsumsi: pulihkan HP & MP penuh.' },
  // ITEM PET (seruling panggil & camilan).
  m_whistle_cracked: { id: 'm_whistle_cracked', name: 'Seruling Retak', cat: 'material', mtype: 'whistle', tier: 'uncommon', price: 350, use: { kind: 'petroll', pool: ['common'] }, desc: 'Suaranya serak, tapi cukup memanggil sahabat kecil (pet umum).' },
  m_whistle_silver:  { id: 'm_whistle_silver', name: 'Seruling Perak', cat: 'material', mtype: 'whistle', tier: 'rare', price: 900, use: { kind: 'petroll', pool: ['common', 'uncommon', 'rare'] }, desc: 'Nada peraknya menembus jauh — bisa memanggil pet langka.' },
  m_whistle_gold:    { id: 'm_whistle_gold', name: 'Seruling Emas', cat: 'material', mtype: 'whistle', tier: 'epic', price: 2200, use: { kind: 'petroll', pool: ['rare', 'epic'] }, desc: 'Gema keemasan yang menarik perhatian makhluk agung.' },
  m_whistle_mythic:  { id: 'm_whistle_mythic', name: 'Seruling Mistik', cat: 'material', mtype: 'whistle', tier: 'mythic', price: 5000, use: { kind: 'petroll', pool: ['epic', 'legendary'] }, desc: 'Dipahat dari tulang dewa yang dilupakan. Yang datang bukan sembarang makhluk.' },
  m_snack:           { id: 'm_snack', name: 'Camilan Pet', cat: 'material', mtype: 'snack', tier: 'common', price: 60, use: { kind: 'petxp', val: 50 }, desc: 'Biskuit ikan kering. Pet aktif +50 XP.' },
  m_snack_l:         { id: 'm_snack_l', name: 'Hidangan Pet', cat: 'material', mtype: 'snack', tier: 'rare', price: 200, use: { kind: 'petxp', val: 150 }, desc: 'Sajian lengkap berbahan langka. Pet aktif +150 XP.' },
};
const itemById = (id) => ITEMS[id] || null;
function itemsForClass(classKey, cat = 'weapon') {
  return Object.values(ITEMS).filter((it) => it.cat === cat && (!it.class || it.class === classKey));
}
function weaponEffect(id) { const it = itemById(id); return it && it.effect ? it.effect : null; }

// Ramuan & racun (16).
const POISONS = {
  p_heal_s:   { id: 'p_heal_s', name: 'Ramuan Kecil', kind: 'heal', val: 40, price: 20, tier: 'common', desc: 'Pulihkan 40 HP.' },
  p_heal_m:   { id: 'p_heal_m', name: 'Ramuan Sedang', kind: 'heal', val: 100, price: 50, tier: 'uncommon', desc: 'Pulihkan 100 HP.' },
  p_heal_l:   { id: 'p_heal_l', name: 'Ramuan Besar', kind: 'heal', val: 250, price: 120, tier: 'rare', desc: 'Pulihkan 250 HP.' },
  p_mana:     { id: 'p_mana', name: 'Ramuan Mana', kind: 'mana', val: 50, price: 40, tier: 'uncommon', desc: 'Pulihkan 50 MP.' },
  p_mana_l:   { id: 'p_mana_l', name: 'Ramuan Mana Besar', kind: 'mana', val: 120, price: 95, tier: 'rare', desc: 'Pulihkan 120 MP.' },
  p_strength: { id: 'p_strength', name: 'Ramuan Kekuatan', kind: 'strength', val: 0.35, turns: 3, price: 90, tier: 'rare', desc: 'ATK +35% selama 3 giliran.' },
  p_berserk:  { id: 'p_berserk', name: 'Ramuan Amuk', kind: 'berserk', val: 0.6, turns: 2, price: 140, tier: 'epic', desc: 'ATK +60% selama 2 giliran — amukan total.' },
  p_swift:    { id: 'p_swift', name: 'Ramuan Kilat', kind: 'swift', val: 0.25, turns: 3, price: 85, tier: 'rare', desc: 'Peluang menghindar +25% selama 3 giliran.' },
  p_regen:    { id: 'p_regen', name: 'Ramuan Regenerasi', kind: 'regen', val: 25, turns: 4, price: 80, tier: 'rare', desc: 'Regen +25 HP/giliran selama 4 giliran.' },
  p_manareg:  { id: 'p_manareg', name: 'Ramuan Fokus', kind: 'manaRegen', val: 15, turns: 4, price: 70, tier: 'rare', desc: 'Regen +15 MP/giliran selama 4 giliran.' },
  p_guard:    { id: 'p_guard', name: 'Ramuan Pelindung', kind: 'shield', val: 0.3, price: 130, tier: 'epic', desc: 'Perisai 30% HP maks seketika.' },
  p_poison:   { id: 'p_poison', name: 'Racun Mematikan', kind: 'poison', val: 30, turns: 3, price: 110, tier: 'epic', desc: 'Racuni musuh: -30 HP/giliran selama 3 giliran.' },
  p_venom:    { id: 'p_venom', name: 'Racun Viper', kind: 'venom', val: 55, turns: 3, price: 160, tier: 'epic', desc: 'Racun super: -55 HP/giliran selama 3 giliran.' },
  p_weaken:   { id: 'p_weaken', name: 'Racun Pelemah', kind: 'weaken', val: 0.4, turns: 3, price: 85, tier: 'uncommon', desc: 'Melemahkan ATK musuh -40% selama 3 giliran.' },
  p_paralyze: { id: 'p_paralyze', name: 'Racun Lumpuh', kind: 'paralyze', val: 1, turns: 2, price: 180, tier: 'epic', desc: 'Lumpuhkan musuh — ia melewatkan 2 giliran.' },
  p_elixir:   { id: 'p_elixir', name: 'Elixir', kind: 'elixir', val: 1, price: 300, tier: 'epic', desc: 'Pulihkan HP & MP sepenuhnya.' },
};
const poisonById = (id) => POISONS[id] || null;

// ---------- FORGE (pandai besi) — cermin utils/rpgItems.js ----------
const FORGE_RECIPES = [
  { out: 'w_iron_axe', cost: { m_slime_jelly: 4, m_bone: 2 } },
  { out: 'w_steel', cost: { m_goblin_ear: 4, m_imp_ember: 2 } },
  { out: 'w_arcane_orb', cost: { m_golem_core: 3, m_wraith_ecto: 1 } },
  { out: 'w_venom_claw', cost: { m_venom_sac: 4, m_bat_wing: 2 } },
  { out: 'w_warhammer', cost: { m_orc_tusk: 3, m_bone: 4 } },
  { out: 'w_hunt_longbow', cost: { m_wolf_pelt: 3, m_bat_wing: 2 } },
  { out: 'w_frost_staff', cost: { m_yeti_fur: 3, m_golem_core: 1 } },
  { out: 'w_knight_spear', cost: { m_orc_tusk: 5, m_minotaur_horn: 1 } },
  { out: 'w_shadow_bow', cost: { m_vulture_feather: 4, m_wraith_ecto: 2 } },
  { out: 'w_recurve_bow', cost: { m_turtle_shell: 2, m_vulture_feather: 3 } },
  { out: 'w_bone_bow', cost: { m_bone: 6, m_gargoyle_shard: 2 } },
  { out: 'w_meteor_tome', cost: { m_imp_ember: 5, m_gargoyle_shard: 2 } },
  { out: 'w_dragon', cost: { m_dragon_scale: 4, m_minotaur_horn: 1 } },
  { out: 'w_void_orb', cost: { m_gargoyle_shard: 3, m_wraith_ecto: 2 } },
  { out: 'w_twin_fang', cost: { m_hyena_fang: 4, m_venom_sac: 2 } },
  { out: 'w_elven_bow', cost: { m_yeti_fur: 3, m_dragon_scale: 2 } },
  { out: 'w_phantom', cost: { m_wraith_ecto: 5, m_demon_heart: 1 } },
  { out: 'w_omega', cost: { m_demon_heart: 3, m_dragon_scale: 5 } },
  { out: 'w_archstaff', cost: { m_wraith_ecto: 6, m_demon_heart: 2 } },
  { out: 'w_windseeker', cost: { m_dragon_scale: 3, m_gargoyle_shard: 3, m_demon_heart: 1 } },
  { out: 'a_chain', cost: { m_wolf_pelt: 3, m_bone: 3 } },
  { out: 'a_ranger_coat', cost: { m_wolf_pelt: 4, m_bat_wing: 3 } },
  { out: 'a_guardian', cost: { m_turtle_shell: 3, m_golem_core: 1 } },
  { out: 'a_plate', cost: { m_gargoyle_shard: 4, m_orc_tusk: 2 } },
  { out: 'a_mithril_mail', cost: { m_golem_core: 2, m_gargoyle_shard: 3 } },
  { out: 'a_dragon', cost: { m_dragon_scale: 4, m_minotaur_horn: 1 } },
  { out: 'a_titan_aegis', cost: { m_minotaur_horn: 2, m_golem_core: 3 } },
  { out: 'a_phoenix_mail', cost: { m_demon_heart: 2, m_dragon_scale: 4 } },
  { out: 'c_vital', cost: { m_mummy_bandage: 3, m_slime_jelly: 4 } },
  { out: 'c_blood_pendant', cost: { m_venom_sac: 3, m_wraith_ecto: 2 } },
  { out: 'c_thorn_bracer', cost: { m_hyena_fang: 3, m_gargoyle_shard: 2 } },
  { out: 'c_storm_charm', cost: { m_imp_ember: 4, m_wraith_ecto: 3 } },
  { out: 'c_guardian_angel', cost: { m_mummy_bandage: 4, m_yeti_fur: 3 } },
  { out: 'c_time_hourglass', cost: { m_demon_heart: 2, m_wraith_ecto: 5 } },
];
const forgeRecipeFor = (out) => FORGE_RECIPES.find((r) => r.out === out) || null;

// ---------- Dungeon ----------
const DUNGEON = {
  bossEvery: 5, minFloors: 8, maxFloors: 20, discoverChance: 0.18,
  floors: [
    { from: 1, to: 4, pool: ['slime', 'goblin', 'wolf', 'rat', 'bat'] },
    { from: 5, to: 9, pool: ['skeleton', 'orc', 'wolf', 'snake', 'imp', 'spider', 'hyena', 'scorpion', 'vulture'] },
    { from: 10, to: 14, pool: ['golem', 'wraith', 'orc', 'turtle', 'gargoyle', 'spider', 'mummy'] },
    { from: 15, to: 99, pool: ['golem', 'wraith', 'gargoyle', 'minotaur', 'yeti', 'deceased'] },
  ],
};
const DUNGEON_NAME_POOL = [
  { name: 'Gua Kegelapan', theme: 'cave' }, { name: 'Kastil Berhantu', theme: 'night' },
  { name: 'Reruntuhan Terlupakan', theme: 'ruins' }, { name: 'Tambang Kuno', theme: 'cave' },
  { name: 'Menara Penyihir', theme: 'volcano' }, { name: 'Katakomba Tersembunyi', theme: 'night' },
  { name: 'Gua Kristal', theme: 'snow' }, { name: 'Nekropolis', theme: 'ruins' },
  { name: 'Sarang Naga', theme: 'volcano' }, { name: 'Hutan Batu', theme: 'forest' },
  { name: 'Sumur Tanpa Dasar', theme: 'cave' }, { name: 'Pemakaman Kuno', theme: 'night' },
  { name: 'Lembah Bayangan', theme: 'night' }, { name: 'Puncak Beku', theme: 'snow' },
  { name: 'Oasis Tersembunyi', theme: 'oasis' }, { name: 'Padang Pasir', theme: 'oasis' },
];
function dungeonPoolFor(floor) { return DUNGEON.floors.find((r) => floor >= r.from && floor <= r.to) || DUNGEON.floors[0]; }
function makeDungeon(nameData) { return { id: uid(), name: nameData.name, theme: nameData.theme, floors: R(DUNGEON.minFloors, DUNGEON.maxFloors), cleared: 0, unlocked: 1 }; }
function defaultDungeons() { return [makeDungeon(DUNGEON_NAME_POOL[0])]; }
const THEME_MONSTERS = {
  cave: ['slime', 'goblin', 'skeleton', 'golem', 'rat', 'bat', 'spider'],
  night: ['skeleton', 'wraith', 'wolf', 'bat', 'gargoyle'],
  ruins: ['skeleton', 'golem', 'wraith', 'gargoyle', 'spider'],
  volcano: ['orc', 'golem', 'dragon', 'imp', 'gargoyle'],
  snow: ['wolf', 'wraith', 'slime', 'turtle', 'yeti'],
  forest: ['slime', 'goblin', 'wolf', 'spider', 'imp', 'snake'],
  oasis: ['hyena', 'scorpion', 'vulture', 'snake', 'mummy', 'deceased', 'wolf'],
};
const THEME_BOSS = { cave: 'demonlord', night: 'demonlord', ruins: 'minotaur', volcano: 'dragon', snow: 'yeti', forest: 'minotaur', oasis: 'minotaur' };
function dungeonMonsterPool(floor, theme) {
  const base = dungeonPoolFor(floor).pool;
  const themed = THEME_MONSTERS[theme];
  if (themed) { const inter = base.filter((id) => themed.includes(id)); if (inter.length) return inter; }
  return base;
}
// Peluang lantai punya peti (lantai boss selalu ada) & peluang mimic.
function floorHasChest(floor) { return floor % DUNGEON.bossEvery === 0 || Math.random() < 0.55; }
function mimicChance(floor) { return Math.min(0.22, 0.06 + floor * 0.005); }

// Lokasi quest -> latar.
const LOCATIONS = {
  bridge:  { name: 'Jembatan Tua',  sky: [0x1e3a8a, 0x60a5fa, 0xfbbf24], ground: 0x78350f, deco: ['stone', 'rock'], part: 'firefly' },
  forest:  { name: 'Hutan Berkabut', sky: [0x14532d, 0x22c55e, 0xfde68a], ground: 0x365314, deco: ['tree', 'bush', 'mushroom', 'fairy', 'predator', 'flystone'], part: 'leaf' },
  cave:    { name: 'Gua Gelap',     sky: [0x0b1120, 0x1f2937, 0x374151], ground: 0x1f2937, deco: ['crystal', 'crystalCluster', 'rock'], part: 'ember' },
  ruins:   { name: 'Reruntuhan Kuil', sky: [0x3b0764, 0x7c3aed, 0xf0abfc], ground: 0x4c1d95, deco: ['pillar', 'gravestone', 'rock'], part: 'firefly' },
  night:   { name: 'Hutan Malam',   sky: [0x020617, 0x0f172a, 0x1e3a8a], ground: 0x111827, deco: ['tree', 'gravestone', 'lantern', 'fairy'], part: 'star' },
  volcano: { name: 'Lereng Gunung', sky: [0x450a0a, 0xdc2626, 0xfbbf24], ground: 0x7f1d1d, deco: ['rock', 'crystal'], part: 'ember' },
  snow:    { name: 'Gunung Bersalju', sky: [0x1e293b, 0x94a3b8, 0xf8fafc], ground: 0xe2e8f0, deco: ['pine', 'rock'], part: 'snow' },
  lake:    { name: 'Danau Terpencil', sky: [0x0c4a6e, 0x38bdf8, 0xa5f3fc], ground: 0x155e75, deco: ['reed', 'flower', 'fairy', 'flystone'], part: 'firefly' },
  desert:  { name: 'Gurun Pasir',   sky: [0x7c2d12, 0xf59e0b, 0xfde68a], ground: 0xc2410c, deco: ['cactus', 'rock'], part: 'sand' },
  oasis:   { name: 'Oasis Gurun',   sky: [0x7c2d12, 0xf59e0b, 0xfde68a], ground: 0xd9a441, deco: ['cactus', 'bush'], part: 'sand' },
  mountain:{ name: 'Jalan Pegunungan', sky: [0x134e4a, 0x2dd4bf, 0xfef3c7], ground: 0x374151, deco: ['rock', 'pine'], part: 'leaf' },
};

// Quest seed (mode demo).
const SEED_QUESTS = [
  { id: 1, title: 'Hama di Ladang', desc: 'Slime menyerbu ladang warga di pinggir hutan.', location: 'forest', monster: 'slime', count: 3, tier: 'normal', rewardXp: 120, rewardGold: 60, rewardRep: 5 },
  { id: 2, title: 'Gua Berbisik', desc: 'Sesuatu bergerak di kedalaman gua gelap itu.', location: 'cave', monster: 'bat', count: 4, tier: 'normal', rewardXp: 160, rewardGold: 80, rewardRep: 5 },
  { id: 3, title: 'Serigala Lapar', desc: 'Serigala buas meneror jalan pegunungan.', location: 'mountain', monster: 'wolf', count: 3, tier: 'normal', rewardXp: 220, rewardGold: 110, rewardRep: 8 },
  { id: 4, title: 'Kerangka yang Bangkit', desc: 'Kerangka hidup muncul di katakomba tua.', location: 'ruins', monster: 'skeleton', count: 4, tier: 'normal', rewardXp: 280, rewardGold: 140, rewardRep: 8 },
  { id: 5, title: 'Koboi Gurun', desc: 'Hyena mengoyak karavan di gurun pasir.', location: 'desert', monster: 'hyena', count: 4, tier: 'normal', rewardXp: 260, rewardGold: 130, rewardRep: 8 },
  { id: 6, title: 'Sang Penunggu', desc: 'Boss menunggu di ujung reruntuhan kuil.', location: 'ruins', monster: 'minotaur', count: 1, tier: 'boss', rewardXp: 1200, rewardGold: 600, rewardRep: 30 },
];

// RANK untuk tampilan (cermin rpgData).
const RANKS = [
  { key: 'G', name: 'Novice', color: 0x9CA3AF }, { key: 'F', name: 'Apprentice', color: 0xA3A3A3 },
  { key: 'E', name: 'Iron', color: 0x78716C }, { key: 'D', name: 'Bronze', color: 0xB45309 },
  { key: 'C', name: 'Silver', color: 0xCBD5E1 }, { key: 'B', name: 'Gold', color: 0xEAB308 },
  { key: 'A', name: 'Platinum', color: 0x22D3EE }, { key: 'S', name: 'Diamond', color: 0x38BDF8 },
  { key: 'SS', name: 'Mythril', color: 0x6366F1 }, { key: 'SSS', name: 'Adamantite', color: 0xA855F7 },
  { key: 'EX', name: 'Divine', color: 0xF59E0B }, { key: 'Ω', name: 'Celestial', color: 0xEF4444 },
];
const rankInfo = (k) => RANKS.find((r) => r.key === k) || RANKS[0];
/* ============================================================================
 * 3. DATA LAYER (demo/localStorage <-> server API) + REALTIME CLIENT
 * ----------------------------------------------------------------------------
 * Semua mutasi game penting lewat metode Data.* — di mode server diteruskan ke
 * API (validasi & roll di server), di mode demo dimainkan lokal. UI selalu
 * membaca Data.char sehingga kedua mode terasa sama.
 * ========================================================================== */
const Store = {
  get(key, def) { try { const v = localStorage.getItem('kz_rpg2_' + key); return v == null ? def : JSON.parse(v); } catch (_) { return def; } },
  set(key, val) { try { localStorage.setItem('kz_rpg2_' + key, JSON.stringify(val)); } catch (_) {} },
};

async function api(path, opts = {}) {
  if (!CFG.server) return null;
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 10000);
    const res = await fetch(CFG.apiBase + path, {
      headers: { 'Content-Type': 'application/json', 'X-RPG-Guild': (localStorage.getItem('kzGuild') || '').trim() },
      credentials: 'same-origin',
      ...opts,
      signal: ctrl.signal,
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });
    clearTimeout(t);
    const data = await res.json().catch(() => null);
    if (!res.ok) return { error: (data && data.error) || ('HTTP ' + res.status), _status: res.status };
    return data;
  } catch (_) { return { error: 'Koneksi server terputus.', _offline: true }; }
}

function defaultChar() {
  return {
    name: CFG.username || 'Petualang',
    classKey: null,
    level: 1, xp: 0, xpForNext: 250,
    gold: 250, silver: 0, copper: 0,
    rankKey: 'G', title: '', friendId: null, unlockedTitles: [],
    statPoints: 0, skillPoints: 1,
    monstersKilled: 0, questsCompleted: 0, dungeonsCleared: 0, bossesDefeated: 0,
    wins: 0, losses: 0, floorsCleared: 0, chestsOpened: 0, mimicsKilled: 0, itemsCrafted: 0,
    reputation: 0,
    alloc: { hp: 0, mp: 0, atk: 0, def: 0, spd: 0, crit: 0 },
    customization: { skin: 0xf1c27d, hairStyle: 'short', hairColor: 0x1f2937, outfit: 0xdc2626, pants: 0x472a19, shoes: 0x0b0b12 },
    equipped: { weapon: null, armor: null, accessory: null },
    inventory: { p_heal_s: 3, p_mana: 2, p_strength: 1, w_rusty: 1 },
    skills: [],
    activeQuests: [],
    completedQuestIds: [],
    dungeons: null,
  };
}

// Event bus ringan: scene berlangganan perubahan data (mis. gold berubah).
const Bus = {
  map: {},
  on(ev, fn) { (this.map[ev] = this.map[ev] || []).push(fn); },
  emit(ev, data) { (this.map[ev] || []).forEach((fn) => { try { fn(data); } catch (_) {} }); },
};

const Data = {
  char: null,
  achievements: [],       // cache daftar achievement (server/demo)
  achCategories: [],
  pendingAchToasts: [],   // achievement baru terbuka -> toast
  load() {
    if (CFG.server) return this.loadServer();
    this.char = Store.get('char', null) || defaultChar();
    this.afterLoad();
    return Promise.resolve(this.char);
  },
  async loadServer() {
    const d = await api('/api/rpg/me');
    // WAJIB: kalau server bilang belum login, JANGAN fallback ke karakter baru —
    // tampilkan halaman login (dulu bug ini bikin progres "balik dari awal").
    if (d && d._status === 401) { this.authFailed = true; this.char = null; return null; }
    if (d && d.char) { this.char = d.char; this.afterLoad(); return this.char; }
    if (d && d.error) { this.serverError = d.error; }
    this.char = defaultChar();
    this.afterLoad();
    return this.char;
  },
  afterLoad() {
    SkillState.set(this.char.skills);
    if (!this.char.dungeons || !this.char.dungeons.length) {
      // Deterministik per sesi: dungeon pertama selalu ada.
      this.char.dungeons = defaultDungeons();
    }
    if (CFG.server) this.refreshAchievements(true);
  },
  async reload() {
    if (CFG.server) { await this.loadServer(); Bus.emit('char', this.char); }
    else { this.char = Store.get('char', this.char); Bus.emit('char', this.char); }
  },
  hasClass() { return !!this.char.classKey; },
  save() {
    if (CFG.server) { api('/api/rpg/save', { method: 'POST', body: { char: this.char } }); return; }
    Store.set('char', this.char);
  },

  // ---------- Class ----------
  async chooseClass(classKey) {
    if (CFG.server) {
      const r = await api('/api/rpg/class', { method: 'POST', body: { classKey } });
      // afterLoad WAJIB: respons server untuk karakter baru punya dungeons=null
      // (belum ada progres) — tanpa normalisasi ini, DungeonSelect crash
      // "Cannot read properties of null (reading 'slice')" (bug v2026.09.26).
      if (r && r.char) { this.char = r.char; this.afterLoad(); return true; }
      return false;
    }
    this.char.classKey = classKey;
    this.char.skillPoints = Math.max(this.char.skillPoints || 0, 1);
    this.save();
    return true;
  },

  // ---------- Quest ----------
  quests() {
    if (CFG.server) return api('/api/rpg/quests').then((d) => (d && d.quests) || []);
    const active = new Set(this.char.activeQuests || []);
    return Promise.resolve(SEED_QUESTS.map((q) => ({ ...q, accepted: active.has(q.id), done: (this.char.completedQuestIds || []).includes(q.id) })));
  },
  async acceptQuest(questId) {
    if (CFG.server) { await api('/api/rpg/quest/accept', { method: 'POST', body: { questId } }); return; }
    const active = this.char.activeQuests || (this.char.activeQuests = []);
    if (!active.includes(questId)) active.push(questId);
    this.save();
  },

  // ---------- Battle quest ----------
  async submitBattle({ win, questId }) {
    if (CFG.server) {
      const r = await api('/api/rpg/battle', { method: 'POST', body: { win, questId } });
      if (r && r.rewards) this.handleServerRewards(r.rewards, r.rewards.drops);
      await this.reload();
      return r;
    }
    if (win) {
      const q = SEED_QUESTS.find((x) => x.id === questId);
      const mon = q ? monsterById(q.monster) : null;
      this.char.xp += (q ? q.rewardXp : 20) + (mon ? mon.xp * (q ? q.count : 1) : 0);
      this.char.gold += (q ? q.rewardGold : 10) + (mon ? mon.gold * (q ? q.count : 1) : 0);
      this.char.monstersKilled = (this.char.monstersKilled || 0) + (q ? q.count : 1);
      this.char.wins = (this.char.wins || 0) + 1;
      if (q && q.rewardRep) this.char.reputation = (this.char.reputation || 0) + q.rewardRep;
      // Drop material (roll lokal utk demo).
      if (mon && MONSTER_DROPS[mon.id]) {
        for (const d of MONSTER_DROPS[mon.id]) if (Math.random() < d.rate) this.addItem(d.id, 1);
      }
      this.levelUpLocal();
      if (questId != null) this.completeQuest(questId);
    } else {
      this.char.losses = (this.char.losses || 0) + 1;
    }
    this.save();
    Bus.emit('char', this.char);
    return { ok: true };
  },
  completeQuest(questId) {
    const done = this.char.completedQuestIds || (this.char.completedQuestIds = []);
    if (!done.includes(questId)) done.push(questId);
    this.char.questsCompleted = (this.char.questsCompleted || 0) + 1;
    this.char.activeQuests = (this.char.activeQuests || []).filter((q) => q !== questId);
  },
  levelUpLocal() {
    // Kurva XP lokal menyederhanakan server: 50L^2 + 150L + 50.
    const need = (l) => Math.floor(50 * l * l + 150 * l + 50);
    let ups = 0;
    while (this.char.xp >= need(this.char.level) && this.char.level < 100) {
      this.char.xp -= need(this.char.level);
      this.char.level += 1; ups++;
      this.char.skillPoints = (this.char.skillPoints || 0) + 1 + (this.char.level % 5 === 0 ? 1 : 0);
      this.char.statPoints = (this.char.statPoints || 0) + 3;
    }
    this.char.xpForNext = need(this.char.level);
    if (ups > 0) Bus.emit('levelup', { to: this.char.level, ups });
    return ups;
  },
  handleServerRewards(rewards, drops) {
    if (!rewards) return;
    if (rewards.levelUp) Bus.emit('levelup', { to: rewards.levelUp.to, ups: rewards.levelUp.to - rewards.levelUp.from });
    // Pet aktif ikut naik level -> toast kecil.
    if (rewards.petXp || (rewards.pet && rewards.pet.level)) {
      const info = rewards.pet && rewards.pet.id ? rewards.pet : rewards.petXp;
      const ups = PetState.applyXp(info);
      if (ups > 0) {
        const p = PetState.activePet;
        petToast((p ? p.name : 'Pet') + ' naik level!', 'Sekarang level ' + PetState.activeLevel + ' — bonus pasifnya menguat.', PET_RARITY_INFO[p ? p.rarity : 'common'].glow);
      }
    }
  },

  // ---------- Dungeon ----------
  // Selalu array — karakter baru dari server bisa punya dungeons null/undefined.
  dungeons() { const d = this.char && this.char.dungeons; return Array.isArray(d) ? d : []; },
  getDungeon(id) { return this.dungeons().find((d) => d.id === id) || this.dungeons()[0]; },
  maybeDiscoverDungeon(p = DUNGEON.discoverChance) {
    if (!Array.isArray(this.char.dungeons)) this.char.dungeons = defaultDungeons();
    if (Math.random() >= p) return null;
    const used = new Set(this.dungeons().map((d) => d.name));
    const candidates = DUNGEON_NAME_POOL.filter((n) => !used.has(n.name));
    if (!candidates.length) return null;
    const nd = makeDungeon(pick(candidates));
    this.char.dungeons.push(nd);
    this.save();
    return nd;
  },
  async completeDungeonFloor(dungeonId, floor) {
    const d = this.getDungeon(dungeonId);
    d.cleared = Math.max(d.cleared, floor);
    d.unlocked = Math.max(d.unlocked, Math.min(d.floors, floor + 1));
    if (floor >= d.floors && !d.completed) {
      d.completed = true;
      this.char.dungeonsCleared = (this.char.dungeonsCleared || 0) + 1;
    }
    this.char.floorsCleared = (this.char.floorsCleared || 0) + 1;
    if (CFG.server) {
      await api('/api/rpg/dungeon/floor', { method: 'POST', body: { dungeonId, floor } });
    } else {
      this.save();
    }
  },
  // Bunuh monster di dungeon — xp/gold/drop dari SERVER (anti-cheat).
  async dungeonKill({ monsterId, floor, isBoss, isChampion, isMimic }) {
    if (CFG.server) {
      const r = await api('/api/rpg/dungeon/kill', { method: 'POST', body: { monsterId, floor, isBoss, isChampion, isMimic } });
      if (r && !r.error) {
        if (r.wallet) this.char.gold = r.wallet.gold;
        if (r.rewards && r.rewards.drops) r.rewards.drops.forEach((id) => this.addItem(id, 1));
        this.char.monstersKilled = (this.char.monstersKilled || 0) + 1;
        if (isMimic) this.char.mimicsKilled = (this.char.mimicsKilled || 0) + 1;
        if (isBoss) this.char.bossesDefeated = (this.char.bossesDefeated || 0) + 1;
        if (r.rewards && r.rewards.levelUp) Bus.emit('levelup', { to: r.rewards.levelUp.to, ups: r.rewards.levelUp.to - r.rewards.levelUp.from });
        Bus.emit('char', this.char);
        this.checkAchievementsSoon();
        return r.rewards || { xp: 0, gold: 0, drops: [] };
      }
      return null;
    }
    // Demo: roll lokal.
    const mon = isMimic ? { xp: 90 + floor * 20, gold: 120 + floor * 22 } : monsterById(monsterId);
    let xp = Math.round(mon.xp * 0.8), gold = Math.round(mon.gold * 0.8);
    if (isChampion) { xp = Math.round(xp * 2.2); gold = Math.round(gold * 2.2); }
    if (isBoss && !isMimic) { xp = Math.round(xp * 1.2); gold = Math.round(gold * 1.2); }
    if (isMimic) { gold = Math.round(gold * 1.6); }
    const drops = [];
    if (!isMimic) {
      for (const d of (MONSTER_DROPS[monsterId] || [])) if (Math.random() < d.rate) { drops.push(d.id); this.addItem(d.id, 1); }
    } else {
      const mats = Object.keys(MONSTER_DROPS);
      const extra = pick(mats);
      drops.push(MONSTER_DROPS[extra][0].id); this.addItem(MONSTER_DROPS[extra][0].id, 1);
    }
    this.char.xp += xp; this.char.gold += gold;
    this.char.monstersKilled = (this.char.monstersKilled || 0) + 1;
    if (isMimic) this.char.mimicsKilled = (this.char.mimicsKilled || 0) + 1;
    if (isBoss && !isMimic) this.char.bossesDefeated = (this.char.bossesDefeated || 0) + 1;
    this.levelUpLocal();
    this.save();
    Bus.emit('char', this.char);
    this.checkAchievementsSoon();
    return { xp, gold, drops };
  },
  // Buka peti — rarity & isi dari SERVER.
  async openChest({ floor, tier }) {
    if (CFG.server) {
      const r = await api('/api/rpg/dungeon/chest', { method: 'POST', body: { floor, tier } });
      if (r && !r.error && r.loot) {
        if (r.wallet) this.char.gold = r.wallet.gold;
        if (r.loot.item) this.addItem(r.loot.item, 1);
        this.char.chestsOpened = (this.char.chestsOpened || 0) + 1;
        // Pet dari peti! (roll server; duplikat sudah dikonversi camilan).
        if (r.loot.pet) {
          const isNew = !PetState.owned[r.loot.pet];
          if (isNew) PetState.owned[r.loot.pet] = { level: 1, xp: 0 };
          if (!PetState.active) PetState.active = r.loot.pet;
          if (r.loot.petDuplicate) this.addItem('m_snack_l', 1);
          Bus.emit('pets', PetState);
          Bus.emit('petObtained', { petId: r.loot.pet, duplicate: !!r.loot.petDuplicate, from: 'chest' });
        }
        Bus.emit('char', this.char);
        this.checkAchievementsSoon();
        return r.loot;
      }
      return null;
    }
    // Demo: roll lokal (cermin rpgWorld.js).
    const band = Math.min(4, Math.floor((floor - 1) / 5));
    const weights = [
      { common: 62, uncommon: 26, rare: 9, epic: 2.4, legendary: 0.5, mythic: 0.08 },
      { common: 46, uncommon: 30, rare: 16, epic: 5.5, legendary: 1.6, mythic: 0.25 },
      { common: 32, uncommon: 30, rare: 23, epic: 10, legendary: 3.4, mythic: 0.6 },
      { common: 20, uncommon: 27, rare: 28, epic: 16, legendary: 6.2, mythic: 1.2 },
      { common: 12, uncommon: 22, rare: 30, epic: 22, legendary: 10, mythic: 2.4 },
    ][band];
    const bias = tier === 'gold' ? 2 : tier === 'silver' ? 1 : 0;
    const w = { ...weights };
    for (let i = 0; i < bias; i++) {
      for (let t = TIER_ORDER.length - 1; t > 0; t--) {
        const shift = w[TIER_ORDER[t - 1]] * 0.18;
        w[TIER_ORDER[t - 1]] -= shift; w[TIER_ORDER[t]] += shift;
      }
    }
    const total = TIER_ORDER.reduce((s, t) => s + w[t], 0);
    let roll = Math.random() * total, lootTier = 'common';
    for (const t of TIER_ORDER) { roll -= w[t]; if (roll <= 0) { lootTier = t; break; } }
    const mult = tier === 'gold' ? 3 : tier === 'silver' ? 1.8 : 1;
    const gold = Math.round((24 + floor * 11 + R(0, 18 + floor * 6)) * mult);
    let item = null;
    if (tier !== 'wood' || Math.random() < 0.65) {
      const pools = {
        common: ['w_rusty', 'w_wood_staff', 'w_rusty_dagger', 'w_short_bow', 'a_leather', 'a_padded_vest', 'c_lucky_coin', 'p_heal_s', 'p_heal_m', 'p_mana'],
        uncommon: ['w_steel', 'w_iron_axe', 'w_flame_wand', 'w_hunt_longbow', 'w_sharp_katana', 'a_chain', 'a_ranger_coat', 'c_swift', 'c_crit', 'c_mana_ring', 'p_heal_m', 'p_mana', 'p_weaken'],
        rare: ['w_elven', 'w_warhammer', 'w_arcane_orb', 'w_void_orb', 'w_venom_claw', 'w_twin_fang', 'w_recurve_bow', 'w_bone_bow', 'a_guardian', 'a_plate', 'a_mithril_mail', 'c_cloak', 'c_vital', 'c_blood_pendant', 'c_thorn_bracer', 'p_heal_l', 'p_mana_l', 'p_strength', 'p_swift', 'p_regen', 'p_manareg'],
        epic: ['w_knight_spear', 'w_dragon', 'w_frost_staff', 'w_meteor_tome', 'w_shadow_bow', 'w_night_katana', 'w_elven_bow', 'a_dragon', 'a_titan_aegis', 'a_frost_bulwark', 'c_crown', 'c_storm_charm', 'c_guardian_angel', 'p_berserk', 'p_guard', 'p_poison', 'p_venom', 'p_paralyze', 'p_elixir'],
        legendary: ['w_dragon', 'w_elven_bow', 'a_dragon', 'a_titan_aegis', 'c_crown', 'p_elixir'],
        mythic: ['w_omega', 'w_archstaff', 'w_phantom', 'w_windseeker', 'a_omega', 'a_void_shroud', 'a_phoenix_mail', 'c_phoenix', 'c_time_hourglass'],
      };
      item = pick(pools[lootTier] || pools.common);
      this.addItem(item, 1);
    }
    this.char.gold += gold;
    this.char.chestsOpened = (this.char.chestsOpened || 0) + 1;
    this.save();
    Bus.emit('char', this.char);
    this.checkAchievementsSoon();
    return { gold, item, tier: lootTier };
  },

  // ---------- Inventory ----------
  addItem(id, qty = 1) {
    const inv = this.char.inventory || (this.char.inventory = {});
    inv[id] = (inv[id] || 0) + qty;
  },
  removeItem(id, qty = 1) {
    const inv = this.char.inventory || (this.char.inventory = {});
    if ((inv[id] || 0) < qty) return false;
    inv[id] -= qty; if (inv[id] <= 0) delete inv[id];
    return true;
  },
  async equip(id) {
    const it = itemById(id);
    if (!it) return { ok: false, error: 'Item tidak dikenal.' };
    const slot = { weapon: 'weapon', armor: 'armor', accessory: 'accessory' }[it.cat];
    if (!slot) return { ok: false, error: 'Item ini tidak bisa dipasang.' };
    if (it.cat === 'weapon' && it.class && it.class !== this.char.classKey) {
      return { ok: false, error: 'Senjata ini hanya untuk ' + ((CLASSES[it.class] || {}).name || it.class) + '.' };
    }
    if (CFG.server) {
      const r = await api('/api/rpg/item/equip', { method: 'POST', body: { itemId: id } });
      if (r && !r.error) {
        this.removeItem(id, 1);
        const prev = this.char.equipped[slot];
        if (prev) this.addItem(prev, 1);
        this.char.equipped[slot] = id;
        await this.reload();
        Bus.emit('char', this.char);
        return { ok: true };
      }
      return { ok: false, error: (r && r.error) || 'Gagal memasang item.' };
    }
    if (!this.removeItem(id, 1)) return { ok: false, error: 'Item tidak ada di tas.' };
    const prev = this.char.equipped[slot];
    if (prev) this.addItem(prev, 1);
    this.char.equipped[slot] = id;
    this.save();
    return { ok: true };
  },
  async unequip(slot) {
    if (CFG.server) {
      const r = await api('/api/rpg/item/unequip', { method: 'POST', body: { slot } });
      if (r && !r.error) {
        const prev = this.char.equipped[slot];
        if (prev) { this.addItem(prev, 1); this.char.equipped[slot] = null; }
        await this.reload();
        Bus.emit('char', this.char);
        return { ok: true };
      }
      return { ok: false, error: (r && r.error) || 'Gagal melepas item.' };
    }
    const prev = this.char.equipped[slot];
    if (!prev) return { ok: false, error: 'Slot itu kosong.' };
    this.addItem(prev, 1);
    this.char.equipped[slot] = null;
    this.save();
    return { ok: true };
  },
  async useItem(id) {
    const it = itemById(id);
    const pz = poisonById(id);
    const usable = pz ? { kind: pz.kind, val: pz.val, turns: pz.turns } : (it && it.use);
    if (!usable) return { ok: false, error: 'Item ini tidak bisa dipakai.' };
    if (CFG.server) {
      const r = await api('/api/rpg/item/use', { method: 'POST', body: { itemId: id } });
      if (r && !r.error) {
        this.removeItem(id, 1);
        // Seruling panggil pet: reveal pet hasil roll server.
        if (r.pet) {
          const petId = r.pet.id;
          const pet = PETS[petId];
          if (pet) {
            if (r.pet.duplicate) {
              petToast('Seruling memanggil ' + pet.name + '...', 'Tapi dia sudah bersamamu. Dapat camilan sebagai gantinya.', 0xfde68a);
            } else {
              if (!PetState.owned[petId]) PetState.owned[petId] = { level: r.pet.level || 1, xp: 0 };
              if (!PetState.active) PetState.active = petId;
              Bus.emit('pets', PetState);
              Bus.emit('petObtained', { petId, duplicate: false, from: 'whistle' });
              petToast('SAHABAT BARU: ' + pet.name + '!', pet.species + ' — ' + PET_RARITY_INFO[pet.rarity].name + '. Cek menu Koleksi Pet.', PET_RARITY_INFO[pet.rarity].glow);
              Sfx.levelup();
            }
          }
        }
        // Camilan pet: XP naik.
        if (r.pet && r.pet.id && r.pet.level && !r.pet.duplicate && (usable.kind === 'petxp')) {
          const ups = PetState.applyXp(r.pet);
          const p = PetState.activePet;
          if (ups > 0 && p) petToast(p.name + ' naik level!', 'Sekarang level ' + (r.pet.level) + '.', PET_RARITY_INFO[p.rarity].glow);
        } else if (r.pet && r.pet.level && (usable.kind === 'petxp')) {
          PetState.applyXp(r.pet);
        }
        Bus.emit('char', this.char);
        return { ok: true, effect: usable };
      }
      return { ok: false, error: (r && r.error) || 'Gagal memakai item.' };
    }
    if (!this.removeItem(id, 1)) return { ok: false, error: 'Item habis.' };
    this.save();
    return { ok: true, effect: usable };
  },
  async sellItem(id, qty = 1) {
    const it = itemById(id) || poisonById(id);
    if (!it) return { ok: false, error: 'Item tidak dikenal.' };
    if (CFG.server) {
      const r = await api('/api/rpg/item/sell', { method: 'POST', body: { itemId: id, qty } });
      if (r && !r.error) {
        this.removeItem(id, qty);
        if (r.wallet) this.char.gold = r.wallet.gold; else this.char.gold += r.gold || 0;
        Bus.emit('char', this.char);
        return { ok: true, gold: r.gold };
      }
      return { ok: false, error: (r && r.error) || 'Gagal menjual.' };
    }
    if (!this.removeItem(id, qty)) return { ok: false, error: 'Jumlah tidak cukup.' };
    const gain = Math.max(1, Math.floor((it.price || 10) / 2)) * qty;
    this.char.gold += gain;
    this.save();
    Bus.emit('char', this.char);
    return { ok: true, gold: gain };
  },

  // ---------- Stat & Skill ----------
  async allocateStat(stat, points = 1) {
    const STEP = { hp: 10, mp: 6, atk: 2, def: 2, spd: 1, crit: 1 };
    if (!STEP[stat]) return { ok: false, error: 'Stat tidak valid.' };
    if (CFG.server) {
      const r = await api('/api/rpg/stat', { method: 'POST', body: { stat, points } });
      if (r && !r.error) {
        this.char.statPoints = r.statPoints;
        this.char.alloc = this.char.alloc || {};
        this.char.alloc[stat] = (this.char.alloc[stat] || 0) + (r.added || 0);
        await this.reload();
        Bus.emit('char', this.char);
        return { ok: true, added: r.added };
      }
      return { ok: false, error: (r && r.error) || 'Gagal alokasi stat.' };
    }
    if ((this.char.statPoints || 0) < points) return { ok: false, error: 'Poin tidak cukup.' };
    this.char.statPoints -= points;
    this.char.alloc = this.char.alloc || {};
    this.char.alloc[stat] = (this.char.alloc[stat] || 0) + STEP[stat] * points;
    this.save();
    Bus.emit('char', this.char);
    return { ok: true, added: STEP[stat] * points };
  },
  async unlockSkill(skillId) {
    if (CFG.server) {
      const r = await api('/api/rpg/skill', { method: 'POST', body: { skillId } });
      if (r && !r.error) {
        SkillState.levels[skillId] = r.newLevel;
        this.char.skillPoints = r.skillPoints;
        const known = this.char.skills.find((s) => s.id === skillId);
        if (known) known.level = r.newLevel; else this.char.skills.push({ id: skillId, level: r.newLevel });
        Bus.emit('char', this.char);
        return { ok: true, newLevel: r.newLevel };
      }
      return { ok: false, error: (r && r.error) || 'Gagal membuka skill.' };
    }
    const def = skillById(this.char.classKey, skillId);
    if (!def) return { ok: false, error: 'Skill tidak dikenal.' };
    const cur = SkillState.get(skillId);
    if (cur >= def.maxLevel) return { ok: false, error: 'Skill sudah level maksimal.' };
    if (this.char.level < def.reqLevel) return { ok: false, error: 'Butuh level ' + def.reqLevel + '.' };
    for (const req of def.requires) if (SkillState.get(req) < 1) {
      const rd = skillById(this.char.classKey, req);
      return { ok: false, error: 'Butuh ' + (rd ? rd.name : req) + ' dulu.' };
    }
    if ((this.char.skillPoints || 0) < def.cost) return { ok: false, error: 'Skill point kurang.' };
    this.char.skillPoints -= def.cost;
    SkillState.levels[skillId] = cur + 1;
    const known = this.char.skills.find((s) => s.id === skillId);
    if (known) known.level = cur + 1; else this.char.skills.push({ id: skillId, level: cur + 1 });
    this.save();
    Bus.emit('char', this.char);
    return { ok: true, newLevel: cur + 1 };
  },

  // ---------- Forge ----------
  async craft(out) {
    const recipe = forgeRecipeFor(out);
    if (!recipe) return { ok: false, error: 'Resep tidak dikenal.' };
    if (CFG.server) {
      const r = await api('/api/rpg/craft', { method: 'POST', body: { out } });
      if (r && !r.error) {
        Object.entries(recipe.cost).forEach(([m, n]) => this.removeItem(m, n));
        this.addItem(out, 1);
        this.char.itemsCrafted = (this.char.itemsCrafted || 0) + 1;
        Bus.emit('char', this.char);
        this.checkAchievementsSoon();
        return { ok: true, item: r.item };
      }
      return { ok: false, error: (r && r.error) || 'Bahan kurang.' };
    }
    for (const [m, n] of Object.entries(recipe.cost)) {
      if (((this.char.inventory || {})[m] || 0) < n) {
        const it = itemById(m);
        return { ok: false, error: 'Bahan kurang: ' + (it ? it.name : m) };
      }
    }
    Object.entries(recipe.cost).forEach(([m, n]) => this.removeItem(m, n));
    this.addItem(out, 1);
    this.char.itemsCrafted = (this.char.itemsCrafted || 0) + 1;
    this.save();
    Bus.emit('char', this.char);
    this.checkAchievementsSoon();
    return { ok: true, item: { id: out } };
  },

  // ---------- Leaderboard ----------
  leaderboard(category = 'level') {
    if (CFG.server) return api('/api/rpg/leaderboard?category=' + category).then((d) => d && !d.error ? d : { list: [], myRank: null });
    const me = { name: this.char.name || 'Kamu', level: this.char.level, classKey: this.char.classKey, isMe: true, rankKey: this.char.rankKey, value: this.char.level };
    const bots = [
      { name: 'Lunara', level: 42, classKey: 'mage', rankKey: 'A', value: 42 },
      { name: 'Bram', level: 38, classKey: 'warrior', rankKey: 'B', value: 38 },
      { name: 'Sari', level: 33, classKey: 'assassin', rankKey: 'B', value: 33 },
      { name: 'Danu', level: 27, classKey: 'archer', rankKey: 'C', value: 27 },
      { name: 'Guntur', level: 19, classKey: 'warrior', rankKey: 'D', value: 19 },
      { name: 'Raka', level: 11, classKey: 'assassin', rankKey: 'E', value: 11 },
    ];
    const list = [...bots, me].sort((a, b) => b.value - a.value).map((p, i) => ({ ...p, rank: i + 1 }));
    return Promise.resolve({ list, myRank: { rank: list.find((x) => x.isMe).rank, value: me.value }, category });
  },

  // ---------- Achievements ----------
  async refreshAchievements(silent = false) {
    if (CFG.server) {
      const r = await api('/api/rpg/achievements');
      if (r && !r.error && r.list) {
        this.achievements = r.list;
        this.achCategories = r.categories || [];
        if (!silent && r.newlyUnlocked && r.newlyUnlocked.length) this.queueAchToasts(r.newlyUnlocked);
        else if (silent && r.newlyUnlocked && r.newlyUnlocked.length) this.queueAchToasts(r.newlyUnlocked);
        Bus.emit('achievements', this.achievements);
      }
      return;
    }
    // Demo: evaluasi lokal (subset counter).
    const c = this.char;
    const defs = DEMO_ACHIEVEMENTS;
    const list = defs.map((def) => {
      let cur = 0;
      if (def.stat === 'friends') cur = 0;
      else if (def.stat === 'matKinds') cur = Object.keys(c.inventory || {}).filter((id) => (itemById(id) || {}).cat === 'material').length;
      else if (def.stat === 'gold') cur = c.gold;
      else cur = c[def.stat] || 0;
      return { ...def, progress: { current: Math.min(cur, def.target), target: def.target }, unlocked: cur >= def.target, claimed: !!(this.claimedAch || {})[def.id] };
    });
    const newOnes = list.filter((a) => a.unlocked && !(this.achievements || []).some((b) => b.id === a.id && b.unlocked)).map((a) => a.id);
    this.achievements = list;
    this.achCategories = [
      { key: 'battle', name: 'Pertempuran' }, { key: 'dungeon', name: 'Dungeon' },
      { key: 'craft', name: 'Kerajinan' }, { key: 'collect', name: 'Koleksi' }, { key: 'progress', name: 'Progresi' },
    ];
    if (newOnes.length) this.queueAchToasts(newOnes);
    Bus.emit('achievements', this.achievements);
  },
  queueAchToasts(ids) {
    for (const id of ids) this.pendingAchToasts.push(id);
    Bus.emit('achToast', ids);
  },
  checkAchievementsSoon() { clearTimeout(this._achT); this._achT = setTimeout(() => this.refreshAchievements(true), 1200); },
  async claimAchievement(achId) {
    if (CFG.server) {
      const r = await api('/api/rpg/achievements/claim', { method: 'POST', body: { achId } });
      if (r && !r.error) {
        const a = this.achievements.find((x) => x.id === achId);
        if (a) a.claimed = true;
        if (r.reward && r.reward.title) {
          this.char.unlockedTitles = this.char.unlockedTitles || [];
          if (!this.char.unlockedTitles.includes(r.reward.title)) this.char.unlockedTitles.push(r.reward.title);
        }
        await this.reload();
        Bus.emit('achievements', this.achievements);
        return { ok: true, reward: r.reward };
      }
      return { ok: false, error: (r && r.error) || 'Gagal klaim.' };
    }
    const a = (this.achievements || []).find((x) => x.id === achId);
    if (!a || !a.unlocked) return { ok: false, error: 'Syarat belum terpenuhi.' };
    if (a.claimed) return { ok: false, error: 'Sudah diambil.' };
    a.claimed = true;
    this.claimedAch = this.claimedAch || {};
    this.claimedAch[achId] = 1;
    if (a.reward) {
      if (a.reward.gold) this.char.gold += a.reward.gold;
      if (a.reward.xp) { this.char.xp += a.reward.xp; this.levelUpLocal(); }
      if (a.reward.title) {
        this.char.unlockedTitles = this.char.unlockedTitles || [];
        if (!this.char.unlockedTitles.includes(a.reward.title)) this.char.unlockedTitles.push(a.reward.title);
      }
    }
    Store.set('claimedAch', this.claimedAch);
    this.save();
    Bus.emit('achievements', this.achievements);
    return { ok: true, reward: a.reward };
  },
  async saveProfile(fields) {
    if (CFG.server) {
      const r = await api('/api/rpg/profile', { method: 'POST', body: fields });
      if (r && !r.error) { await this.reload(); return { ok: true }; }
      return { ok: false, error: (r && r.error) || 'Gagal menyimpan.' };
    }
    if (fields.gameName != null) this.char.name = String(fields.gameName).slice(0, 16);
    if (fields.title != null) this.char.title = fields.title;
    this.save();
    return { ok: true };
  },
};

// Achievement definisi versi ringkas (demo). Server punya versi lengkap.
const DEMO_ACHIEVEMENTS = [
  { id: 'first_blood', name: 'Darah Pertama', cat: 'battle', icon: 'sword', desc: 'Kalahkan monster pertamamu.', stat: 'monstersKilled', target: 1, reward: { gold: 50, xp: 20 } },
  { id: 'slayer_50', name: 'Pembasmi', cat: 'battle', icon: 'sword', desc: 'Kalahkan 50 monster.', stat: 'monstersKilled', target: 50, reward: { gold: 300, xp: 150, title: 'Pembasmi' } },
  { id: 'slayer_250', name: 'Pemburu Kejam', cat: 'battle', icon: 'sword', desc: 'Kalahkan 250 monster.', stat: 'monstersKilled', target: 250, reward: { gold: 1200, xp: 600, title: 'Pemburu Kejam' } },
  { id: 'slayer_1000', name: 'Mimpi Buruk Monster', cat: 'battle', icon: 'skull', desc: 'Kalahkan 1.000 monster.', stat: 'monstersKilled', target: 1000, reward: { gold: 6000, xp: 3000, title: 'Mimpi Buruk' } },
  { id: 'win_1', name: 'Kemenangan Pertama', cat: 'battle', icon: 'trophy', desc: 'Menangkan battle pertamamu.', stat: 'wins', target: 1, reward: { gold: 40, xp: 20 } },
  { id: 'win_100', name: 'Sang Juara', cat: 'battle', icon: 'trophy', desc: 'Menangkan 100 battle.', stat: 'wins', target: 100, reward: { gold: 1500, xp: 800, title: 'Sang Juara' } },
  { id: 'win_500', name: 'Tak Terkalahkan', cat: 'battle', icon: 'trophy', desc: 'Menangkan 500 battle.', stat: 'wins', target: 500, reward: { gold: 8000, xp: 4000, title: 'Tak Terkalahkan' } },
  { id: 'boss_1', name: 'Pembunuh Boss', cat: 'battle', icon: 'skull', desc: 'Kalahkan boss pertamamu.', stat: 'bossesDefeated', target: 1, reward: { gold: 400, xp: 250 } },
  { id: 'boss_10', name: 'Penakluk Raksasa', cat: 'battle', icon: 'skull', desc: 'Kalahkan 10 boss.', stat: 'bossesDefeated', target: 10, reward: { gold: 2500, xp: 1500, title: 'Penakluk Raksasa' } },
  { id: 'floor_10', name: 'Penjelajah Muda', cat: 'dungeon', icon: 'compass', desc: 'Selesaikan 10 lantai dungeon.', stat: 'floorsCleared', target: 10, reward: { gold: 250, xp: 150 } },
  { id: 'floor_100', name: 'Kaki Tangan Kuat', cat: 'dungeon', icon: 'compass', desc: 'Selesaikan 100 lantai dungeon.', stat: 'floorsCleared', target: 100, reward: { gold: 2000, xp: 1200, title: 'Penjelajah Sejati' } },
  { id: 'dungeon_1', name: 'Rumah Baru', cat: 'dungeon', icon: 'door', desc: 'Taklukkan satu dungeon penuh.', stat: 'dungeonsCleared', target: 1, reward: { gold: 500, xp: 300 } },
  { id: 'dungeon_10', name: 'Kunci Segala Pintu', cat: 'dungeon', icon: 'door', desc: 'Taklukkan 10 dungeon penuh.', stat: 'dungeonsCleared', target: 10, reward: { gold: 3000, xp: 2000, title: 'Pembuka Jalan' } },
  { id: 'chest_25', name: 'Tangan Panas', cat: 'dungeon', icon: 'chest', desc: 'Buka 25 peti harta.', stat: 'chestsOpened', target: 25, reward: { gold: 350, xp: 150 } },
  { id: 'chest_150', name: 'Pemburu Harta', cat: 'dungeon', icon: 'chest', desc: 'Buka 150 peti harta.', stat: 'chestsOpened', target: 150, reward: { gold: 2500, xp: 1200, title: 'Pemburu Harta' } },
  { id: 'mimic_1', name: 'Ada Apa dengan Peti Itu', cat: 'dungeon', icon: 'chest', desc: 'Kalahkan mimic penyamar pertamamu.', stat: 'mimicsKilled', target: 1, reward: { gold: 200, xp: 150 } },
  { id: 'mimic_15', name: 'Pembongkar Mimik', cat: 'dungeon', icon: 'chest', desc: 'Kalahkan 15 mimic.', stat: 'mimicsKilled', target: 15, reward: { gold: 1800, xp: 1000, title: 'Pembongkar Mimik' } },
  { id: 'craft_1', name: 'Pukulan Pertama', cat: 'craft', icon: 'hammer', desc: 'Tempa item pertamamu di pandai besi.', stat: 'itemsCrafted', target: 1, reward: { gold: 60, xp: 30 } },
  { id: 'craft_25', name: 'Ahli Tempa', cat: 'craft', icon: 'hammer', desc: 'Tempa 25 item.', stat: 'itemsCrafted', target: 25, reward: { gold: 1500, xp: 800, title: 'Ahli Tempa' } },
  { id: 'craft_100', name: 'Master Pandai Besi', cat: 'craft', icon: 'hammer', desc: 'Tempa 100 item.', stat: 'itemsCrafted', target: 100, reward: { gold: 6000, xp: 3500, title: 'Master Tempa' } },
  { id: 'mat_10', name: 'Penimbun Bahan', cat: 'collect', icon: 'bag', desc: 'Punya 10 jenis material sekaligus.', stat: 'matKinds', target: 10, reward: { gold: 400, xp: 200 } },
  { id: 'rich_10k', name: 'Kantong Tebal', cat: 'collect', icon: 'coin', desc: 'Punya 10.000 KZC sekaligus.', stat: 'gold', target: 10000, reward: { gold: 500, xp: 200 } },
  { id: 'rich_100k', name: 'Kaya Raya', cat: 'collect', icon: 'coin', desc: 'Punya 100.000 KZC sekaligus.', stat: 'gold', target: 100000, reward: { gold: 5000, xp: 2000, title: 'Kaya Raya' } },
  { id: 'level_10', name: 'Bukan Pemula Lagi', cat: 'progress', icon: 'star', desc: 'Capai level 10.', stat: 'level', target: 10, reward: { gold: 200, xp: 100 } },
  { id: 'level_25', name: 'Nama Mulai Dikenal', cat: 'progress', icon: 'star', desc: 'Capai level 25.', stat: 'level', target: 25, reward: { gold: 1000, xp: 500 } },
  { id: 'level_50', name: 'Veteran', cat: 'progress', icon: 'star', desc: 'Capai level 50.', stat: 'level', target: 50, reward: { gold: 4000, xp: 2000, title: 'Veteran' } },
  { id: 'level_100', name: 'Puncak Kekuatan', cat: 'progress', icon: 'crown', desc: 'Capai level 100.', stat: 'level', target: 100, reward: { gold: 20000, xp: 0, title: 'Sang Legenda' } },
  { id: 'quest_1', name: 'Tangan Kurang Gatal', cat: 'progress', icon: 'scroll', desc: 'Selesaikan quest pertamamu.', stat: 'questsCompleted', target: 1, reward: { gold: 60, xp: 40 } },
  { id: 'quest_25', name: 'Andalan Guild', cat: 'progress', icon: 'scroll', desc: 'Selesaikan 25 quest.', stat: 'questsCompleted', target: 25, reward: { gold: 900, xp: 500 } },
  { id: 'quest_100', name: 'Wajah Papan Quest', cat: 'progress', icon: 'scroll', desc: 'Selesaikan 100 quest.', stat: 'questsCompleted', target: 100, reward: { gold: 3500, xp: 1800, title: 'Andalan Guild' } },
];
Data.claimedAch = Store.get('claimedAch', {});

/* ---------- Realtime (WebSocket) client ---------- */
/* Status koneksi dibuat EXPLISIT supaya fitur multiplayer/chat tidak pernah
 * gagal diam-diam: UI bisa menampilkan alasan (mode demo / menyambungkan /
 * terputus + sebabnya) dan chat punya fallback REST saat WS diblokir proxy. */
const Rt = {
  ws: null, connected: false, everConnected: false,
  state: 'idle', // idle | demo | connecting | open | down
  lastError: '', tries: 0,
  handlers: {},
  on(t, fn) { (this.handlers[t] = this.handlers[t] || []).push(fn); },
  emit(t, data) { (this.handlers[t] || []).forEach((fn) => { try { fn(data); } catch (_) {} }); },
  setState(s, err) {
    this.state = s; this.lastError = err || '';
    this.emit('rt.state', { state: s, error: this.lastError, tries: this.tries });
  },
  reason(ev) {
    const code = ev && ev.code;
    if (code === 4003) return 'domain belum terdaftar di ALLOWED_DOMAINS server';
    if (code === 1008) return 'sesi login habis — buka ulang web bot';
    if (this.tries >= 2) return 'server/hosting tidak meneruskan koneksi realtime (WebSocket)';
    return 'koneksi terputus';
  },
  connect() {
    if (!CFG.server || !window.WebSocket) { if (CFG.server) this.setState('down', 'browser tidak mendukung WebSocket'); else this.setState('demo', ''); return; }
    this.setState('connecting');
    try {
      const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${proto}//${location.host}/ws`);
      this.ws = ws;
      ws.onopen = () => { this.connected = true; this.everConnected = true; this.tries = 0; this.setState('open'); this.emit('open'); };
      ws.onclose = (ev) => {
        this.connected = false;
        this.tries++;
        // v12: bedakan 'down' (belum pernah nyambung) vs 'reconnecting'
        // (pernah nyambung lalu putus) — indikator jadi jujur.
        this.setState(this.everConnected ? 'reconnecting' : 'down', this.reason(ev));
        this.emit('close');
        clearTimeout(this._rt); this._rt = setTimeout(() => this.connect(), Math.min(15000, 4000 + this.tries * 1000)); // auto-reconnect (backoff)
      };
      ws.onerror = () => { try { ws.close(); } catch (_) {} };
      ws.onmessage = (ev) => {
        let m = null;
        try { m = JSON.parse(ev.data); } catch (_) { return; }
        if (m && m.t) this.emit(m.t, m);
      };
    } catch (e) { this.setState('down', String((e && e.message) || 'gagal menyambung')); }
  },
  send(t, data = {}) {
    if (this.ws && this.connected) { try { this.ws.send(JSON.stringify({ t, ...data })); return true; } catch (_) {} }
    return false; // PANGGILER wajib menangani false -> beri tahu user / fallback REST.
  },
  /* Handler ter-scoped per scene: shutdown sebuah scene hanya melepas
   * listener MILIKNYA sendiri. (Dulu: scene yang shutdown menghapus SEMUA
   * handler global — listener scene lain ikut musnah -> lobby macet
   * "Memuat daftar lobby...", chat berhenti update, toast dobel, dll.) */
  scoped() {
    const own = {};
    return {
      on: (t, fn) => {
        (this.handlers[t] = this.handlers[t] || []).push(fn);
        (own[t] = own[t] || []).push(fn);
      },
      off: () => {
        for (const t of Object.keys(own)) {
          this.handlers[t] = (this.handlers[t] || []).filter((f) => own[t].indexOf(f) < 0);
          if (!this.handlers[t].length) delete this.handlers[t];
        }
      },
    };
  },
};

/* ============================================================================
 * 4. STAT EFEKTIF (class + alokasi + passive skill + equipment)
 * ========================================================================== */
function computeStats(char) {
  const cls = CLASSES[char.classKey] || CLASSES.warrior;
  const lvl = char.level - 1;
  const s = {};
  for (const k of Object.keys(cls.base)) s[k] = cls.base[k] + cls.growth[k] * lvl;
  const al = char.alloc || {};
  s.hp += al.hp || 0; s.mp += al.mp || 0; s.atk += al.atk || 0;
  s.def += al.def || 0; s.spd += al.spd || 0; s.crit += al.crit || 0;
  // Passive skills.
  for (const sk of (char.skills || [])) {
    const def = skillById(char.classKey, sk.id);
    if (!def || def.type !== 'passive') continue;
    const e = def.effect, l = sk.level || 1;
    if (e.defPct) s.def *= (1 + e.defPct * l);
    if (e.atkPct) s.atk *= (1 + e.atkPct * l);
    if (e.spdPct) s.spd *= (1 + e.spdPct * l);
    if (e.hpPct) s.hp *= (1 + e.hpPct * l);
    if (e.critPct) s.crit += e.critPct * 100 * l;
  }
  // Equipment flat.
  for (const slot of ['weapon', 'armor', 'accessory']) {
    const it = itemById(char.equipped && char.equipped[slot]);
    if (it) { if (it.hp) s.hp += it.hp; if (it.mp) s.mp += it.mp; if (it.atk) s.atk += it.atk; if (it.def) s.def += it.def; if (it.spd) s.spd += it.spd; if (it.crit) s.crit += it.crit; }
  }
  for (const k of Object.keys(s)) s[k] = Math.round(s[k]);
  return s;
}
function skillEffectScaled(def, level) {
  // Serangan naik +10% per level di atas 1 (selaras engine bot).
  const e = { ...def.effect };
  if (e.dmg) e.dmg = e.dmg + (level - 1) * 0.1;
  if (e.heal) e.heal = e.heal + (level - 1) * 0.1;
  if (e.healAoe) e.healAoe = e.healAoe + (level - 1) * 0.1;
  if (e.shield) e.shield = e.shield + (level - 1) * 0.03;
  return e;
}
function effectText(effect) {
  if (!effect) return '';
  const pct = effect.pct != null ? Math.round(effect.pct * 100) + '%' : '';
  switch (effect.kind) {
    case 'lifesteal': return 'Menghisap nyawa ' + pct + ' dari damage';
    case 'cleave': return 'Sabetan menyapu (' + pct + ' strike tambahan)';
    case 'poison': return 'Racuni musuh (' + Math.round(effect.dot * 100) + '% ATK, ' + (effect.turns || 3) + ' giliran)';
    case 'execute': return 'Eksekusi x1.8 vs musuh HP < ' + pct;
    case 'critDmg': return 'Critical damage +' + pct;
    case 'manaRegen': return 'Regenerasi +' + effect.val + ' MP/giliran';
    case 'shield': return 'Perisai ' + pct + ' HP maks saat bertempur';
    case 'thorns': return 'Memantulkan ' + pct + ' damage ke penyerang';
    case 'regen': return 'Regenerasi +' + effect.val + ' HP/giliran';
    case 'dodge': return 'Peluang menghindar +' + pct;
    case 'goldFind': return 'Gold dari monster +' + pct;
    case 'revive': return 'Bangkit 1x dengan ' + pct + ' HP saat tumbang';
    case 'heal': case 'elixir': return 'Pulihkan HP' + (effect.val ? ' ' + effect.val : ' & MP penuh');
    case 'mana': return 'Pulihkan ' + effect.val + ' MP';
    case 'petroll': return 'Memanggil pet acak saat dipakai';
    case 'petxp': return 'Pet aktif +' + effect.val + ' XP';
    case 'strength': case 'berserk': return 'ATK +' + Math.round(effect.val * 100) + '% (' + (effect.turns || 2) + ' giliran)';
    case 'swift': return 'Hindar +' + Math.round(effect.val * 100) + '% (' + (effect.turns || 2) + ' giliran)';
    default: return '';
  }
}
function xpNeed(level) { return Math.floor(50 * level * level + 150 * level + 50); }
function monsterForLevel(level, tier) {
  const pool = MONSTERS.filter((m) => m.level <= level + 3 && (!tier || m.tier === tier));
  return pool.length ? pick(pool) : MONSTERS[0];
}
function buildEncounter(quest) {
  const base = monsterById(quest.monster) || monsterForLevel(1, quest.tier);
  const list = [];
  for (let i = 0; i < quest.count; i++) {
    const jitter = RF(0.85, 1.15);
    list.push({ ...base, name: base.name, hp: Math.round(base.hp * jitter), hpMax: Math.round(base.hp * jitter), atk: Math.round(base.atk * jitter), def: Math.round(base.def * jitter), defeated: false });
  }
  return list;
}
/* ============================================================================
 * 4. SPRITE & IKON — SEMUA ASET (v9: nol canvas, nol generator prosedural)
 * ========================================================================== */
const ATLAS_KEY = 'atlas0x72';

function toColorInt(c, fallback) {
  if (typeof c === 'number' && isFinite(c)) return c >>> 0;
  if (typeof c === 'string') {
    const m = /^#?([0-9a-f]{6})$/i.exec(c.trim());
    if (m) return parseInt(m[1], 16);
  }
  return fallback;
}

function iconTexture(scene, name, color = 0xf8fafc) {
  // v9: ikon = ASET PNG pixel putih 48px (di-tint pemakainya) — nol canvas.
  if (scene.textures.exists('ui_icon_' + name)) return 'ui_icon_' + name;
  if (scene.textures.exists('asset_icon_m_core')) return 'asset_icon_m_core';
  return scene.textures.exists('fx_tex_glow') ? 'fx_tex_glow' : '__DEFAULT';
}
// Ikon bernama aset PNG (assets/icons + fx) — dipakai DULU sebelum ui_icon.
// Art berwarna tidak di-tint (biar warna aslinya utuh); hanya fx yang di-tint.
const ICON_ASSET_MAP = {
  sword: 'w_sword', axe: 'w_axe', bow: 'w_bow', hammer: 'w_hammer', spear: 'w_spear',
  staff: 'w_staff', wand: 'w_wand', dagger: 'w_dagger', katana: 'w_katana', claw: 'w_claw',
  orb: 'w_orb', tome: 'w_tome', book: 'w_tome', swords: 'w_sword',
  shield: 'a_shield', armor: 'a_plate', crown: 'c_crown', ring: 'c_ring', coin: 'c_coin',
  potion: 'p_heal', poison: 'p_poison', key: 'key', chest: 'chest', paw: 'paw_w',
  gem: 'm_core', heart: 'm_heart',
};
// Sprite ikon siap pakai.
function iconImage(scene, x, y, name, { size = 24, color = 0xf8fafc, origin = 0.5 } = {}) {
  const asset = ICON_ASSET_MAP[name];
  if (asset && scene.textures.exists('asset_icon_' + asset)) {
    const k = 'asset_icon_' + asset;
    const im = scene.add.image(x, y, k).setOrigin(origin, origin);
    const t = scene.textures.get(k);
    const iw = Math.max(1, t.getSourceImage().width), ih = Math.max(1, t.getSourceImage().height);
    im.setDisplaySize(size, size * (ih / iw));
    return im;
  }
  if ((name === 'sparkle' || name === 'star') && scene.textures.exists('fx_tex_' + (name === 'star' ? 'star' : 'sparkle'))) {
    const k = 'fx_tex_' + (name === 'star' ? 'star' : 'sparkle');
    // Blend NORMAL + tint: sebagai IKON harus solid terbaca, bukan glow ADD yang tenggelam di tombol gelap.
    return scene.add.image(x, y, k).setTint(color).setOrigin(origin, origin).setDisplaySize(size * 1.6, size * 1.6);
  }
  const key = iconTexture(scene, name, color);
  const img = scene.add.image(x, y, key).setOrigin(origin, origin).setDisplaySize(size, size);
  // v10: ikon = pixel art BERWARNA (bukan siluet putih) -> tidak di-tint.
  return img;
}

/* ---------- HERO: atlas per class + fallback prosedural ----------
 * FIX SPAWN: setiap sprite kaki-ditanah (origin 0.5,1) kini body-nya
 * dihitung dari UKURAN FRAME ASLI (frameH) sehingga dasar body SELALU
 * persis di kaki — tidak lagi "tenggelam ke tanah" / melayang.
 * (Bug lama: offset body fix 6+22=28 utk semua monster — monster frame
 * 32x36 (golem/naga/minotaur) tenggelam, frame 16x16 melayang.) */
const HERO_ASSET = {
  warrior: { idle: 'knight_m_idle_anim', run: 'knight_m_run_anim', hit: 'knight_m_hit_anim', frameH: 28 },
  mage:    { idle: 'wizzard_m_idle_anim', run: 'wizzard_m_run_anim', hit: 'wizzard_m_hit_anim', frameH: 28 },
  assassin:{ idle: 'elf_m_idle_anim', run: 'elf_m_run_anim', hit: 'elf_m_hit_anim', frameH: 28 },
  archer:  { composite: true, idle: 'elf_m_idle_anim', run: 'elf_m_run_anim', hit: 'elf_m_hit_anim', frameH: 28 },
};

/* ---------- v12: makeInteractive (§1B) ----------
 * AKAR BUG "s.hitAreaCallback is not a function": Phaser 3.85 membiarkan
 * setInteractive(config) pada objek nol-ukuran/tanpa frame menciptakan objek
 * input dengan hitArea=null & hitAreaCallback=null -> crash saat hover.
 * Utilitas ini SELALU memasang shape + callback eksplisit, MEMVALIDASI hasil,
 * dan menunda/menolak aktivasi bila objek belum layak interaktif. */
function makeInteractive(go, opts = {}) {
  if (!go) return go;
  const activate = () => {
    try {
      // v12.2 FIX AKAR (hit-area basis kiri-atas): Phaser menggeser koordinat
      // yang diterima hitAreaCallback dengan displayOrigin objek (lihat
      // InputPlugin.pointWithinInteractiveObject: e += displayOriginX) — jadi
      // ruang koordinat hit area adalah KIRI-ATAS objek (0,0 = sudut kiri-atas
      // visual), BUKAN titik origin. Shape lama Rectangle(-w/2,-h/2,w,h)
      // (center-based) membuat hanya kuadran kiri-atas objek yang bisa diklik.
      // Rumus universal di bawah memusatkan region w x h pada bounds objek:
      //  - objek origin .5 (Rectangle/Image/Text/Nineslice): shape (0,0,w,h)
      //    = persis bounds visual;
      //  - Container (displayOrigin 0, tanpa ukuran intrinsik => ow/oh = 0):
      //    shape tetap centered — sama dengan konvensi lama;
      //  - w/h custom lebih besar/kecil dari objek: area meluber/mengecil
      //    simetris dari pusat objek.
      // ow/oh memakai ukuran TAK-TERSKALA (go.width) karena ruang koordinat
      // callback berada pada ruang lokal pra-skala; objek yang di-rescale
      // (setDisplaySize) tetap terhitung benar.
      const ow = go.width || go.displayWidth || 0;
      const oh = go.height || go.displayHeight || 0;
      const w = opts.w != null ? opts.w : ow;
      const h = opts.h != null ? opts.h : oh;
      if (!(w > 0) || !(h > 0)) return false; // belum berukuran -> coba lagi nanti
      const ox = opts.ox || 0, oy = opts.oy || 0;
      const shape = opts.shape || new Phaser.Geom.Rectangle(ox + (ow - w) / 2, oy + (oh - h) / 2, w, h);
      const cb = opts.callback || Phaser.Geom.Rectangle.Contains;
      go.setInteractive(shape, cb, !!opts.dropZone);
      const ok = go.input && go.input.hitArea && typeof go.input.hitAreaCallback === 'function';
      if (!ok) {
        try { go.disableInteractive(); } catch (_) {}
        console.warn('[makeInteractive] validasi gagal utk', (go.type || (go.texture && go.texture.key) || 'obj'), '- interaksi tidak diaktifkan');
        return true; // sudah ditangani: jangan retry
      }
      go.input.customHitArea = true;
      if (opts.useHandCursor || opts.cursor) go.input.cursor = opts.cursor || 'pointer';
      if (opts.onDown) go.on('pointerdown', opts.onDown);
      return true;
    } catch (e) { console.warn('[makeInteractive] error:', e && e.message); return true; }
  };
  if (activate()) return go;
  // Objek belum berukuran (frame belum siap / container kosong): tunda maks 3x.
  go.__mkIntTries = (go.__mkIntTries || 0) + 1;
  if (go.scene && go.__mkIntTries <= 3) go.scene.time.delayedCall(40, () => makeInteractive(go, opts));
  else console.warn('[makeInteractive] objek tak pernah berukuran - interaksi dibatalkan');
  return go;
}
function atlasHas(scene, frame) {
  try { return scene.textures.exists(ATLAS_KEY) && scene.textures.get(ATLAS_KEY).has(frame); } catch (_) { return false; }
}

// Body rapi: dasar body = dasar frame (kaki). Lebar ~78% frame.
function footBody(frameW, frameH, widthFrac = 0.78) {
  const w = Math.max(6, Math.round(frameW * widthFrac));
  const h = Math.max(8, Math.round(frameH * 0.86));
  return { w, h, ox: Math.round((frameW - w) / 2), oy: frameH - h };
}

/* ---------- HERO SHEET v13: 3328x2048 (13 kolom x 8 baris @256px) ----------
 * 4 karakter BERBEDA per class (permintaan user: karakter diganti, animasi
 * & efek kontrak tetap): WARRIOR = Dark Knight (comphonia, CC0 — zirah
 * lengkap + pedang + perisai, Slash 46f/Kick/Impact/Casting), MAGE = Maya
 * penyihir cewek chibi (CC0 — topi runcing + gaun + orb spell menggambar
 * langsung di baris cast), ARCHER = pemanah hud hd (mh-studios, CC0 — busur
 * selalu terlihat, shoot 22 frame draw->lepas), ASSASSIN = prototipe Craftpix
 * (bebas pakai — stealth/double strike/teleport, VFX menyala bawaan).
 * Baris: 0 cast (7f) | 1 walk (9f) | 2 slash (6f) | 3 shoot (7f dari kolom 2,
 * khusus archer) | 4 hurt (1f) | 5 idle (kol 0-1) + combat (kol 2-3)
 * | 6 jump (5f) | 7 run (8f). Semua menghadap KANAN; flipX menangani kiri.
 * Kaki di ground 244/256; k per class menjaga tinggi tampil ~91px. */
const HERO_LPC = {
  warrior:  { sheet: 'hero_lpc_warrior',  walk: 1, attack: 2, attackN: 6, attackFps: 14, idleRow: 5, runRow: 7, jumpRow: 6, castRow: 0, hurtRow: 4, k: 0.139 },
  mage:     { sheet: 'hero_lpc_mage',     walk: 1, attack: 0, attackN: 7, attackFps: 13, idleRow: 5, runRow: 7, jumpRow: 6, castRow: 0, hurtRow: 4, attackCast: true, k: 0.134 },
  assassin: { sheet: 'hero_lpc_assassin', walk: 1, attack: 2, attackN: 6, attackFps: 15, idleRow: 5, runRow: 7, jumpRow: 6, castRow: 0, hurtRow: 4, k: 0.160 },
  archer:   { sheet: 'hero_lpc_archer',   walk: 1, attack: 3, attackN: 7, attackFps: 20, idleRow: 5, runRow: 7, jumpRow: 6, castRow: 0, hurtRow: 4, attackFrom: 2, k: 0.134 },
};
function lpcFrame(row, col) { return row * 13 + col; }
function heroLpcAnims(scene, classKey) {
  const d = HERO_LPC[classKey];
  if (!d || !scene.textures.exists(d.sheet)) return null;
  const p = 'herolpc_' + classKey;
  if (!scene.anims.exists(p + '_walk')) {
    const fr = (row, from, to) => [...Array(to - from)].map((_, i) => ({ key: d.sheet, frame: lpcFrame(row, from + i) }));
    // v13: idle NYATA (kolom 0-0-1, siklus napas) + combat idle (2-2-3) + run (8 frame) + jump.
    scene.anims.create({ key: p + '_idle', frames: [fr(d.idleRow, 0, 1)[0], fr(d.idleRow, 0, 1)[0], fr(d.idleRow, 1, 2)[0]], frameRate: 3, repeat: -1 });
    scene.anims.create({ key: p + '_combat', frames: [fr(d.idleRow, 2, 3)[0], fr(d.idleRow, 2, 3)[0], fr(d.idleRow, 3, 4)[0]], frameRate: 3, repeat: -1 });
    scene.anims.create({ key: p + '_cast', frames: fr(d.castRow != null ? d.castRow : 0, 0, 7), frameRate: 6, repeat: -1 });
    scene.anims.create({ key: p + '_walk', frames: fr(d.walk, 0, 9), frameRate: 12, repeat: -1 });
    scene.anims.create({ key: p + '_run', frames: fr(d.runRow, 0, 8), frameRate: 16, repeat: -1 });
    scene.anims.create({ key: p + '_jump', frames: fr(d.jumpRow, 0, 5), frameRate: 9, repeat: 0 });
    scene.anims.create({ key: p + '_attack', frames: fr(d.attack, d.attackFrom || 0, (d.attackFrom || 0) + d.attackN), frameRate: d.attackFps, repeat: 0 });
    scene.anims.create({ key: p + '_hurt', frames: [fr(d.hurtRow != null ? d.hurtRow : 4, 0, 1)[0]], frameRate: 1, repeat: 0 });
  }
  return { key: d.sheet, frame: lpcFrame(d.walk, 0), idle: p + '_idle', combat: p + '_combat', walk: p + '_walk', run: p + '_run', jump: p + '_jump', attack: p + '_attack', cast: p + '_cast', hurt: p + '_hurt', isAtlas: true, lpc: true, frameW: 256, frameH: 256 };
}

/* ---------- HERO v3: sheet hasil AI (archer & assassin — desain eksklusif) ----------
 * Archer: 8 frame [idle1 idle2 run1 run2 jump shootA shootB hurt]
 * Assassin: 6 frame [idle1 idle2 run1 run2 slash1 slash2] */
const HERO_V3 = {
  archer:   { sheet: 'hero_archer_v3',   idle: [0, 1], run: [2, 3], attack: [5, 6], hurt: 7, frameW: 56, frameH: 56 },
  assassin: { sheet: 'hero_assassin_v3', idle: [0, 1], run: [2, 3], attack: [4, 5], hurt: 3, frameW: 56, frameH: 56 },
};
function heroAtlasAnims(scene, classKey) {
  const lpc = heroLpcAnims(scene, classKey);
  if (lpc) return lpc; // atlas LPC penuh = prioritas tertinggi
  const v3 = HERO_V3[classKey];
  if (v3 && scene.textures.exists(v3.sheet)) {
    const prefix = 'heroeanim_' + classKey + '_v3';
    if (!scene.anims.exists(prefix + '_idle')) {
      const fr = (frames) => frames.map((f) => ({ key: v3.sheet, frame: f }));
      scene.anims.create({ key: prefix + '_idle', frames: fr(v3.idle), frameRate: 3, repeat: -1 });
      scene.anims.create({ key: prefix + '_walk', frames: fr(v3.run), frameRate: 9, repeat: -1 });
      scene.anims.create({ key: prefix + '_attack', frames: fr(v3.attack), frameRate: 10, repeat: 0 });
      if (v3.hurt != null) scene.anims.create({ key: prefix + '_hurt', frames: [{ key: v3.sheet, frame: v3.hurt }], frameRate: 1, repeat: 0 });
    }
    return { key: v3.sheet, frame: 0, idle: prefix + '_idle', walk: prefix + '_walk', attack: prefix + '_attack', hurt: prefix + '_hurt', isAtlas: true, v3: true, frameW: v3.frameW, frameH: v3.frameH };
  }
  const def = HERO_ASSET[classKey] || HERO_ASSET.warrior;
  const prefix = 'heroeanim_' + classKey;
  if (atlasHas(scene, def.idle + '_f0')) {
    if (!scene.anims.exists(prefix + '_idle')) {
      const fr = (name, n) => [...Array(n)].map((_, i) => ({ key: ATLAS_KEY, frame: name + '_f' + i }));
      scene.anims.create({ key: prefix + '_idle', frames: fr(def.idle, 4), frameRate: 7, repeat: -1 });
      scene.anims.create({ key: prefix + '_walk', frames: fr(def.run, 4), frameRate: 10, repeat: -1 });
      scene.anims.create({ key: prefix + '_attack', frames: [{ key: ATLAS_KEY, frame: def.hit + '_f0' }], frameRate: 1, repeat: 0 });
    }
    return { key: ATLAS_KEY, frame: def.idle + '_f0', idle: prefix + '_idle', walk: prefix + '_walk', attack: prefix + '_attack', isAtlas: true };
  }
  return null;
}

function heroVisual(scene, classKey, customization, scale = 3.4) {
  const a = heroAtlasAnims(scene, classKey);
  if (a) {
    if (a.lpc) {
      // v13: sheet 256px — konten karakter ~167-200px. Faktor k per class
      // menjaga tinggi tampil konsisten dengan hero lama (konten 48px x 1.9 ~ 91px).
      const d = HERO_LPC[classKey] || HERO_LPC.warrior;
      return { key: a.key, frame: a.frame, anim: { idle: a.idle, combat: a.combat, walk: a.walk, run: a.run, jump: a.jump, attack: a.attack, cast: a.cast, hurt: a.hurt }, scale: Math.max(0.34, scale * (d.k || 0.14)), isAtlas: true, frameW: 256, frameH: 256, lpc: true, body: { w: 104, h: 176, ox: 76, oy: 80 } };
    }
    if (a.v3) {
      // Sheet v3 pakai frame 56px — setengah skala LPC 28px biar tinggi tampil sama.
      return { key: a.key, frame: a.frame, anim: { idle: a.idle, walk: a.walk, attack: a.attack, hurt: a.hurt }, scale: scale / 2, isAtlas: true, frameW: a.frameW, frameH: a.frameH, v3: true };
    }
    const def = HERO_ASSET[classKey] || HERO_ASSET.warrior;
    return { key: a.key, frame: a.frame, anim: { idle: a.idle, walk: a.walk, attack: a.attack }, scale, isAtlas: true, frameW: 16, frameH: def.frameH || 28 };
  }
  // v9: fallback TERAKHIR = frame 0 sheet hero mana pun yang termuat (nol canvas).
  const sk = ['hero_lpc_' + classKey, 'hero_lpc_warrior', 'hero_archer_v3', 'hero_assassin_v3'].find((k) => scene.textures.exists(k)) || '__DEFAULT';
  if (scene.textures.exists(sk)) {
    const ak = sk + '_anims';
    if (!scene.anims.exists(ak)) {
      const fr = [{ key: sk, frame: 0 }];
      scene.anims.create({ key: ak + '_idle', frames: fr, frameRate: 1, repeat: -1 });
      scene.anims.create({ key: ak + '_walk', frames: fr, frameRate: 1, repeat: -1 });
      scene.anims.create({ key: ak + '_attack', frames: fr, frameRate: 1, repeat: 0 });
      scene.anims.create({ key: ak + '_hurt', frames: fr, frameRate: 1, repeat: 0 });
    }
    return { key: sk, frame: 0, anim: { idle: ak + '_idle', walk: ak + '_walk', attack: ak + '_attack', hurt: ak + '_hurt' }, scale: scale * 1.6, isAtlas: false, frameW: 16, frameH: 28 };
  }
  return null;
}

/* ---------- HERO GEAR: equipment terlihat di karakter ----------
 * Senjata di tangan (ikut ayun saat menyerang), zirah jadi jubah di punggung,
 * aksesori jadi efek melayang. Dipakai di Dungeon & Battle. */
function weaponTypeFor(classKey, equippedId) {
  if (equippedId) {
    const it = itemById(equippedId);
    if (it && it.type) return it.type;
  }
  return { warrior: 'sword', mage: 'staff', assassin: 'dagger', archer: 'bow' }[classKey] || 'sword';
}
function armorGearFor(equippedId) {
  if (!equippedId) return null;
  const it = itemById(equippedId);
  const t = (it && it.type) || '';
  return { light: 'cape_light', medium: 'cape_chain', heavy: 'cape_plate', shield: 'shield' }[t] || 'cape_light';
}
function accessoryFxFor(equippedId) {
  if (!equippedId) return null;
  const id = String(equippedId);
  if (/crown|angel|holy|divine/.test(id)) return 'acc_halo';
  if (/cloak|wing|seraph|feather/.test(id)) return 'acc_wings';
  if (/charm|storm|orb|crystal/.test(id)) return 'acc_orb';
  if (/coin|lucky|star|time|hourglass/.test(id)) return 'acc_star';
  return 'acc_star';
}
// rarity tint utk senjata (common abu ... mythik merah menyala).
const GEAR_TIER_TINT = { common: 0xffffff, uncommon: 0xbfe8c0, rare: 0xa8d4ff, epic: 0xd8b4fe, legendary: 0xfde68a, mythic: 0xffb3ba };
function createHeroGear(scene, hero, classKey, equipped, opts = {}) {
  const wType = weaponTypeFor(classKey, equipped && equipped.weapon);
  const wKey = 'gear_wpn_' + wType;
  const tier = (itemById(equipped && equipped.weapon) || {}).tier || 'common';
  const scaleBase = opts.scale || 1.0;
  const gear = { hero, wType, dead: false, swingT: 0, bobT: 0, weapon: null };

  // v11: atlas LPC baru sudah menyertakan senjata animasi di tangan —
  // overlay senjata statis DILEWATI agar tidak dobel (jubah/aksesori tetap).
  let weapon = null;
  if (!opts.noWeapon && scene.textures.exists(wKey)) {
    weapon = scene.add.image(0, 0, wKey).setDepth(opts.depth != null ? opts.depth + 1 : 10).setScale(scaleBase);
    if (GEAR_TIER_TINT[tier] && tier !== 'common') weapon.setTint(GEAR_TIER_TINT[tier]);
    gear.weapon = weapon;
  }

  // Zirah: jubah di punggung (di belakang hero).
  const aGear = armorGearFor(equipped && equipped.armor);
  let cape = null;
  if (aGear && scene.textures.exists('gear_' + aGear)) {
    cape = scene.add.image(0, 0, 'gear_' + aGear).setDepth((opts.depth != null ? opts.depth : 9) - 1).setScale(scaleBase * 0.9).setAlpha(0.96);
    gear.cape = cape;
  }

  // Aksesori: efek melayang.
  const accKey = accessoryFxFor(equipped && equipped.accessory);
  let acc = null;
  if (accKey && scene.textures.exists('gear_' + accKey)) {
    acc = scene.add.image(0, 0, 'gear_' + accKey).setDepth((opts.depth != null ? opts.depth : 9) + 1).setScale(scaleBase * 0.75);
    gear.acc = acc;
    gear.accKey = accKey;
  }

  const handOffset = opts.handOffset || { x: 15, y: -34 }; // relatif dari kaki hero (origin 0.5,1)

  gear.swing = function () {
    this.swingT = scene.time.now;
    if (!weapon) return;
    if (this.wType === 'bow') {
      // Busur: sedikit mundur lalu maju (recoil).
      scene.tweens.add({ targets: weapon, x: weapon.x - 4, duration: 70, yoyo: true, ease: 'Quad.easeOut' });
    } else {
      // Senjata melee: ayun busur besar.
      const baseA = weapon.angle;
      scene.tweens.add({ targets: weapon, angle: baseA - 78, duration: 90, ease: 'Quad.easeOut', onComplete: () => {
        scene.tweens.add({ targets: weapon, angle: baseA, duration: 150, ease: 'Back.easeOut' });
      } });
    }
  };

  gear.update = function (dt) {
    if (this.dead || !hero.active) { this.destroy(); return; }
    const flip = hero.flipX;
    const dir = flip ? -1 : 1;
    const H = hero.displayHeight || 90;
    const swing = scene.time.now - this.swingT < 220;
    this.bobT += dt * 0.005;
    const bob = Math.sin(this.bobT) * 1.4;
    // Senjata: di tangan, sudut condong ke atas; sedikit naik saat menyerang.
    if (weapon) {
      const wx = hero.x + dir * handOffset.x;
      const wy = hero.y + handOffset.y + bob - (swing ? 6 : 0);
      weapon.setPosition(wx, wy);
      weapon.setFlipX(flip);
      weapon.setAngle((flip ? 32 : -32) + (swing ? dir * -14 : 0));
    }
    // Robe di punggung: mengikuti gerak, berkibar.
    if (cape) {
      cape.setPosition(hero.x - dir * 9, hero.y - H * 0.52 + bob * 0.6);
      cape.setFlipX(flip);
      cape.setAngle(dir * (4 + Math.sin(this.bobT * 1.6) * 5));
    }
    // Aksesori melayang.
    if (acc) {
      if (this.accKey === 'acc_halo') {
        acc.setPosition(hero.x, hero.y - H - 8 + Math.sin(this.bobT * 0.8) * 2);
        acc.setRotation(acc.rotation + 0.02);
      } else if (this.accKey === 'acc_orb') {
        const a = this.bobT * 1.4;
        acc.setPosition(hero.x + Math.cos(a) * 30, hero.y - H * 0.55 + Math.sin(a) * 14);
      } else if (this.accKey === 'acc_wings') {
        acc.setPosition(hero.x - dir * 12, hero.y - H * 0.62);
        acc.setFlipX(flip);
        acc.setScale(scaleBase * 0.75 * (1 + Math.sin(this.bobT * 3) * 0.08), scaleBase * 0.75);
      } else {
        acc.setPosition(hero.x + dir * 10, hero.y - H - 4 + Math.sin(this.bobT * 2) * 3);
        acc.setRotation(acc.rotation - dir * 0.03);
      }
    }
  };
  gear.destroy = function () {
    this.dead = true;
    try { weapon.destroy(); } catch (_) {}
    if (cape) try { cape.destroy(); } catch (_) {}
    if (acc) try { acc.destroy(); } catch (_) {}
  };
  const upd = (time, delta) => { if (!gear.dead) gear.update(delta); };
  scene.events.on('update', upd);
  scene.events.once('shutdown', () => gear.destroy());
  return gear;
}

/* ---------- MONSTER: pemetaan atlas + tint + TINGGI FRAME ASLI ----------
 * frameH dipakai footBody() supaya body physics berakhir persis di kaki. */
const MONSTER_ASSET = {
  slime:     { base: 'slug_anim',            tint: 0x63d98e, s: 3.0, frameH: 23 },
  rat:       { base: 'tiny_slug_anim',       tint: 0xb9b6ae, s: 2.2, frameH: 16 },
  bat:       { base: 'imp_idle_anim',        tint: 0x8f9bff, s: 2.2, frameH: 16, fly: true, runBase: 'imp_run_anim' },
  spider:    { base: 'goblin_idle_anim',     tint: 0x3d4457, s: 2.6, frameH: 16, runBase: 'goblin_run_anim' },
  snake:     { base: 'muddy_anim',           tint: 0x74b24a, s: 2.6, frameH: 16 },
  wolf:      { base: 'chort_idle_anim',      tint: 0x9aa7bd, s: 2.8, frameH: 23, runBase: 'chort_run_anim' },
  goblin:    { base: 'goblin_idle_anim',     tint: 0xffffff, s: 2.8, frameH: 16, runBase: 'goblin_run_anim' },
  skeleton:  { base: 'skelet_idle_anim',     tint: 0xf3f5f7, s: 2.8, frameH: 16, runBase: 'skelet_run_anim' },
  imp:       { base: 'imp_idle_anim',        tint: 0xffffff, s: 2.6, frameH: 16, runBase: 'imp_run_anim' },
  turtle:    { base: 'swampy_anim',          tint: 0x2fc4b0, s: 2.8, frameH: 16 },
  hyena:     { base: 'wogol_idle_anim',      tint: 0xd9b27c, s: 2.8, frameH: 23, runBase: 'wogol_run_anim' },
  scorpion:  { base: 'tiny_zombie_idle_anim',tint: 0xc47a2e, s: 2.0, frameH: 16, runBase: 'tiny_zombie_run_anim' },
  vulture:   { base: 'imp_idle_anim',        tint: 0x9a6a3a, s: 2.4, frameH: 16, fly: true, runBase: 'imp_run_anim' },
  orc:       { base: 'orc_warrior_idle_anim',tint: 0xffffff, s: 3.2, frameH: 23, runBase: 'orc_warrior_run_anim' },
  gargoyle:  { base: 'masked_orc_idle_anim', tint: 0x8e9aa8, s: 3.0, frameH: 23, runBase: 'masked_orc_run_anim' },
  mummy:     { base: 'zombie_anim',          tint: 0xd9c391, s: 2.8, frameH: 16, firstFrame: 1 },
  deceased:  { base: 'zombie_anim',          tint: 0x8a919c, s: 2.8, frameH: 16, firstFrame: 1 },
  golem:     { base: 'big_zombie_idle_anim', tint: 0x8d8577, s: 3.2, frameH: 36, runBase: 'big_zombie_run_anim' },
  wraith:    { base: 'necromancer_anim',     tint: 0xb18cff, s: 3.0, frameH: 23 },
  minotaur:  { base: 'ogre_idle_anim',       tint: 0xc98d4b, s: 3.4, frameH: 36, runBase: 'ogre_run_anim' },
  yeti:      { base: 'big_zombie_idle_anim', tint: 0xeef6ff, s: 3.4, frameH: 36, runBase: 'big_zombie_run_anim' },
  dragon:    { base: 'big_demon_idle_anim',  tint: 0xe0564a, s: 3.6, frameH: 36, runBase: 'big_demon_run_anim' },
  demonlord: { base: 'big_demon_idle_anim',  tint: 0xffffff, s: 4.0, frameH: 36, runBase: 'big_demon_run_anim' },
};
function firstFrameName(def) {
  const f = def.firstFrame || 0;
  return def.base + '_f' + f;
}
function ensureAtlasMonsterAnims(scene) {
  for (const m of MONSTERS) {
    const def = MONSTER_ASSET[m.id];
    if (!def) continue;
    const f0 = def.firstFrame || 0;
    if (!atlasHas(scene, def.base + '_f' + f0)) continue;
    const nIdle = [...Array(5 - f0)].filter((_, i) => atlasHas(scene, def.base + '_f' + (f0 + i))).length || 1;
    const idleKey = 'monz_' + m.id + '_idle';
    const runKey = 'monz_' + m.id + '_run';
    if (!scene.anims.exists(idleKey)) {
      const fr = (name, start, n) => [...Array(n)].map((_, i) => ({ key: ATLAS_KEY, frame: name + '_f' + (start + i) }));
      scene.anims.create({ key: idleKey, frames: fr(def.base, f0, nIdle), frameRate: 6, repeat: -1 });
      const runBase = def.runBase || def.base.replace('_idle', '_run');
      if (atlasHas(scene, runBase + '_f0')) {
        scene.anims.create({ key: runKey, frames: fr(runBase, 0, Math.min(4, nIdle + 1) || 4), frameRate: 10, repeat: -1 });
      }
    }
  }
}
function monsterScale(scene, m) {
  const def = MONSTER_ASSET[m.id];
  if (def && atlasHas(scene, firstFrameName(def))) return def.s;
  return 3;
}
const MONSTER_FRAME = 48;
function monsterTexture(scene, m) {
  const assetKey = 'asset_mon_' + m.id;
  if (scene.textures.exists(assetKey)) return assetKey;
  // v9: fallback = aset monster lain yang termuat (nol canvas).
  for (const m2 of MONSTERS) {
    if (scene.textures.exists('asset_mon_' + m2.id)) return 'asset_mon_' + m2.id;
  }
  return scene.textures.exists('asset_deco_rock2') ? 'asset_deco_rock2' : '__DEFAULT';
}
function ensureMonsterAnims(scene) {
  ensureAtlasMonsterAnims(scene);
  for (const m of MONSTERS) {
    const def = MONSTER_ASSET[m.id];
    if (def && atlasHas(scene, firstFrameName(def))) continue;
    const key = 'asset_mon_' + m.id;
    if (!scene.textures.exists(key)) continue;
    const tex = scene.textures.get(key);
    let frames = 1;
    try { frames = Math.max(1, Math.floor(tex.getSourceImage().width / MONSTER_FRAME)); } catch (_) { frames = 1; }
    const animKey = 'mon_anim_' + m.id;
    if (frames >= 2 && !scene.anims.exists(animKey)) {
      scene.anims.create({ key: animKey, frames: scene.anims.generateFrameNumbers(key, { start: 0, end: frames - 1 }), frameRate: 5, repeat: -1 });
    }
  }
}
function playMonsterAnim(scene, sprite, m, moving = false) {
  const def = MONSTER_ASSET[m.id];
  if (def) {
    const want = (moving ? 'monz_' + m.id + '_run' : 'monz_' + m.id + '_idle');
    const fallback = 'monz_' + m.id + '_idle';
    const key = scene.anims.exists(want) ? want : (scene.anims.exists(fallback) ? fallback : null);
    if (key) {
      try { if (!sprite.anims.isPlaying || sprite.anims.currentAnim.key !== key) sprite.play(key); return; } catch (_) {}
    }
  }
  const animKey = 'mon_anim_' + m.id;
  if (scene.anims.exists(animKey)) {
    try { if (!sprite.anims.isPlaying || sprite.anims.currentAnim.key !== animKey) sprite.play(animKey); return; } catch (_) {}
  }
  if (!sprite._bobTween) {
    const baseY = sprite.y, baseS = sprite.scaleY;
    sprite._bobTween = scene.tweens.add({ targets: sprite, y: baseY - 3, scaleY: baseS * 0.96, duration: RF(500, 800), yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
  }
}
function stopMonsterAnim(sprite) { try { sprite.anims.stop(); sprite.setFrame(0); } catch (_) {} }

/* ---------- PETI: animasi buka + mimic ---------- */
function ensureChestAnims(scene) {
  const kinds = [
    { tier: 'wood', base: 'chest_empty_open_anim' },
    { tier: 'silver', base: 'chest_full_open_anim' },
    { tier: 'gold', base: 'chest_full_open_anim' },
    { tier: 'mimic', base: 'chest_mimic_open_anim' },
  ];
  for (const k of kinds) {
    const key = 'chestz_open_' + k.tier;
    if (scene.anims.exists(key)) continue;
    if (atlasHas(scene, k.base + '_f0')) {
      scene.anims.create({ key, frames: ['f0', 'f1', 'f2'].map((f) => ({ key: ATLAS_KEY, frame: k.base + '_' + f })), frameRate: 8, repeat: 0 });
    }
  }
}
// v9: fallback ikon item = ikon pixel ASET per kategori (nol canvas).
function itemIconTexture(scene, id) {
  const it = itemById(id) || poisonById(id);
  if (!it) return iconTexture(scene, 'bag');
  const cat = it.cat || 'potion';
  const name = cat === 'weapon' ? (it.type === 'bow' ? 'bow' : (ICON_ASSET_MAP[it.type] ? it.type : 'sword'))
    : cat === 'material' ? 'gem'
    : cat === 'armor' ? 'shield'
    : cat === 'accessory' ? 'crown'
    : 'potion';
  return iconTexture(scene, name);
}
// Ikon PNG asli (assets/icons/, render dari game-icons.net) bila tersedia.
const ITEM_ART_KEYS = { w_rusty: 'w_rusty', w_steel: 'w_steel', w_elven: 'w_elven', w_dragon: 'w_dragon', w_omega: 'w_omega' };
function itemPngIconKey(id) {
  const it = itemById(id) || poisonById(id);
  if (!it) return null;
  const art = ITEM_ART_KEYS[id];
  if (art && window.__itemArtLoaded && window.__itemArtLoaded[art]) return 'asset_art_' + art;
  const k = itemIconKey(it);
  return (k && window.__petIconLoaded && window.__petIconLoaded[k]) ? 'asset_icon_' + k : null;
}
function addItemIcon(scene, x, y, id, box = 40) {
  const png = itemPngIconKey(id);
  if (png && scene.textures.exists(png)) return scene.add.image(x, y, png).setDisplaySize(box, box);
  const key = itemIconTexture(scene, id);
  const im = scene.add.image(x, y, key).setDisplaySize(box, box);
  if (key.indexOf('ui_icon_') === 0) {
    const it = itemById(id) || poisonById(id);
    if (it) im.setTint(tierInfo(it.tier).color); // fallback putih -> tint tier
  }
  return im;
}
// Ikon item dengan bingkai rarity (dipakai kartu loot & inventori).
function addRarityIcon(scene, x, y, id, box = 44) {
  const it = itemById(id) || poisonById(id);
  const ti = tierInfo((it || {}).tier);
  const cont = scene.add.container(x, y);
  // v9: bingkai rarity = blok aset + outline 9-slice di-tint warna tier.
  cont.add(uiFill(scene, -box / 2, -box / 2, box, box, 0x0b1220, 0.88, 0));
  cont.add(uiSlice(scene, 0, 0, box, box, 'ui_outline', ti.color).setAlpha(0.9));
  const icon = addItemIcon(scene, 0, 0, id, box - 12);
  cont.add(icon);
  return cont;
}
// Ikon skill: lingkaran + ikon vektor sesuai jenis efek.
function skillIconKey(scene, def, classKey) {
  const color = toColorInt((def.fx && def.fx.color) || ((CLASSES[classKey] || {}).color), 0x7c3aed);
  const iconName = skillIconName(def);
  return iconTexture(scene, iconName, 0xffffff);
}
function skillIconName(def) {
  const e = def.effect || {};
  // v10: pasif variatif (v9 semua 'shield' -> grid penuh perisai monoton).
  if (def.type === 'passive') {
    if (e.mpRegen || e.mana || e.mp) return 'mana';
    if (e.hpRegen || e.regen) return 'heart';
    if (e.crit || e.critBonus) return 'eye';
    if (e.def || e.defense || e.shield) return 'shield';
    if (e.spd || e.speed || e.evasion) return 'skill';
    if (e.atk || e.atkBuff || e.dmg) return 'sword';
    return 'sparkle';
  }
  if (e.heal || e.healAoe) return 'heart';
  if (e.shield) return 'shield';
  if (e.dot) return 'potion';
  if (e.mark) return 'eye';
  if (e.hits && e.hits > 1) return 'swords';
  const fxk = def.fx && def.fx.kind;
  if (fxk === 'fireball' || fxk === 'meteor' || fxk === 'void') return 'fire';
  if (fxk === 'frost') return 'mana';
  if (fxk === 'arrow' || fxk === 'arrowrain' || fxk === 'snipe') return 'bow';
  if (fxk === 'flurry' || fxk === 'dash' || fxk === 'execute') return 'sword';
  return 'sword';
}

/* ---------- AUDIO (WebAudio prosedural, tanpa file) ---------- */
const Sfx = {
  ctx: null, master: null, muted: false,
  init() {
    if (this.ctx) return;
    try {
      this.ctx = new (window.AudioContext || window.webkitAudioContext)();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.32;
      this.master.connect(this.ctx.destination);
    } catch (_) {}
  },
  tone(freq, dur, type = 'square', vol = 0.5, slide = 0) {
    if (!this.ctx || this.muted) return;
    try {
      const o = this.ctx.createOscillator(), g = this.ctx.createGain();
      o.type = type; o.frequency.value = freq;
      if (slide) o.frequency.linearRampToValueAtTime(freq + slide, this.ctx.currentTime + dur);
      g.gain.setValueAtTime(vol, this.ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + dur);
      o.connect(g); g.connect(this.master);
      o.start(); o.stop(this.ctx.currentTime + dur);
    } catch (_) {}
  },
  noise(dur = 0.12, vol = 0.25) {
    if (!this.ctx || this.muted) return;
    try {
      const n = Math.floor(this.ctx.sampleRate * dur);
      const buf = this.ctx.createBuffer(1, n, this.ctx.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);
      const src = this.ctx.createBufferSource(); src.buffer = buf;
      const g = this.ctx.createGain(); g.gain.value = vol;
      src.connect(g); g.connect(this.master); src.start();
    } catch (_) {}
  },
  hit() { this.tone(160, 0.09, 'square', 0.4, -60); this.noise(0.06, 0.15); },
  hurt() { this.tone(110, 0.16, 'sawtooth', 0.35, -40); },
  jump() { this.tone(300, 0.12, 'square', 0.22, 220); },
  dash() { this.noise(0.1, 0.2); this.tone(500, 0.08, 'sine', 0.2, 300); },
  chest() { this.tone(520, 0.1, 'square', 0.3); setTimeout(() => this.tone(660, 0.14, 'square', 0.3), 90); setTimeout(() => this.tone(880, 0.2, 'square', 0.25), 200); },
  coin() { this.tone(900, 0.07, 'square', 0.22); setTimeout(() => this.tone(1300, 0.1, 'square', 0.2), 60); },
  potion() { this.tone(400, 0.12, 'sine', 0.3, 200); },
  levelup() { [440, 550, 660, 880].forEach((f, i) => setTimeout(() => this.tone(f, 0.14, 'square', 0.28), i * 90)); },
  victory() { [523, 659, 784, 1047].forEach((f, i) => setTimeout(() => this.tone(f, 0.18, 'triangle', 0.3), i * 120)); },
  defeat() { [400, 350, 300, 200].forEach((f, i) => setTimeout(() => this.tone(f, 0.2, 'sawtooth', 0.25), i * 140)); },
  skill() { this.tone(700, 0.1, 'sine', 0.3, 250); this.noise(0.08, 0.1); },
  // v11: fanfare ultimate pet — sweep naik + gema.
  ult() { this.tone(320, 0.32, 'sawtooth', 0.22, 500); this.tone(640, 0.26, 'sine', 0.2, 420); this.noise(0.3, 0.16); },
  forge() { this.noise(0.05, 0.3); this.tone(1200, 0.05, 'square', 0.15); },
  click() { this.tone(600, 0.05, 'square', 0.15); },
  hover() { this.tone(1250, 0.03, 'square', 0.05); },
  whoosh() { this.noise(0.08, 0.09); this.tone(340, 0.1, 'sine', 0.09, -160); },
  pop() { this.tone(540, 0.06, 'square', 0.14, 150); },
  ambient() { /* hening — musik opsional dikembangkan nanti */ },
};

/* ---------- FX visual ---------- */
/* ---------- v12 §1A: RenderResourcePool ------------------------------------
 * Penjaga permanen untuk SELURUH kelas bug kebocoran sumber daya GPU:
 * setiap tekstur dinamis (dynamic/render texture, alias addImage) WAJIB
 * dibuat lewat pool. Pool melacak purpose, MEMPERINGATKAN konsol bila satu
 * purpose membuat tekstur baru alih-alih reuse, dan melepas resource saat
 * scene shutdown/destroy. Hook QA: window.__kzRRP. */
const RenderResourcePool = {
  _byPurpose: {}, // purpose -> { key, sceneKey }
  _byScene: {},   // sceneKey -> [key]
  stats() { return { purposes: Object.keys(this._byPurpose).length, scenes: Object.keys(this._byScene).length }; },
  dynamicTexture(scene, purpose, factory) {
    const sceneKey = (scene.scene && scene.scene.key) || (scene.sys && scene.sys.settings.key) || 'unknown';
    const existing = this._byPurpose[purpose];
    if (existing) {
      if (existing.sceneKey !== sceneKey) console.warn('[RenderResourcePool] purpose "' + purpose + '" dibuat ulang oleh scene ' + sceneKey + ' (sudah ada dari ' + existing.sceneKey + ') — harusnya reuse.');
      return scene.textures.get(existing.key);
    }
    const key = factory();
    this._byPurpose[purpose] = { key, sceneKey };
    (this._byScene[sceneKey] = this._byScene[sceneKey] || []).push(key);
    const release = () => {
      try { if (scene.textures.exists(key)) scene.textures.remove(key); } catch (_) {}
      delete this._byPurpose[purpose];
      const arr = this._byScene[sceneKey];
      if (arr) { const i = arr.indexOf(key); if (i >= 0) arr.splice(i, 1); }
    };
    if (scene.events) { scene.events.once('shutdown', release); scene.events.once('destroy', release); }
    return scene.textures.get(key);
  },
};
window.__kzRRP = RenderResourcePool; // hook QA / dev console
function ensurePixelTex(scene) {
  // v9: partikel = aset asli (alias di-set saat boot); tanpa canvas.
  // v12: dialirkan lewat RenderResourcePool (tercatat + auto-release + warn duplikat).
  if (!scene.textures.exists('fxpix') && scene.textures.exists('fx_tex_pixel')) {
    try { RenderResourcePool.dynamicTexture(scene, 'fxpix-particles', () => {
      scene.textures.addImage('fxpix', scene.textures.get('fx_tex_pixel').getSourceImage());
      return 'fxpix';
    }); } catch (_) {}
  }
}
function fxNum(scene, x, y, text, color = '#f8fafc', size = 14, big = false) {
  // Angka damage AAA: jitter posisi anti tumpuk + pop + kemiringan dinamis.
  const jx = x + R(-9, 9), jy = y + R(-5, 5);
  const t = scene.add.text(jx, jy, String(text), { fontFamily: F_PIX, fontSize: (big ? size + 3 : size) + 'px', color, stroke: '#0b0b12', strokeThickness: big ? 5 : 3 }).setOrigin(0.5).setDepth(1600).setAngle(R(-8, 8));
  scene.tweens.add({ targets: t, y: jy - (big ? 50 : 32), alpha: 0, duration: big ? 950 : 720, ease: 'Quad.easeOut', onComplete: () => t.destroy() });
  scene.tweens.add({ targets: t, scale: { from: 0.35, to: big ? 1.28 : 1.08 }, duration: 190, ease: 'Back.easeOut' });
  if (big) scene.tweens.add({ targets: t, scale: 1, duration: 260, delay: 210, ease: 'Sine.easeOut' });
}
function fxRing(scene, x, y, color, r = 50, dur = 350) {
  // ASET: cincin cahaya fx/ring.png (tekstur 256px, diameter penuh = 2r).
  if (scene.textures.exists('fx_tex_ring')) {
    const im = scene.add.image(x, y, 'fx_tex_ring').setTint(color).setBlendMode(Phaser.BlendModes.ADD).setDepth(1500).setScale((2 * r * 0.36) / 256);
    scene.tweens.add({ targets: im, scale: (2 * r) / 256, alpha: 0, duration: dur, ease: 'Quad.easeOut', onComplete: () => im.destroy() });
    return;
  }
  const c = scene.add.image(x, y, scene.textures.exists('fx_tex_glow') ? 'fx_tex_glow' : 'fx_tex_flash').setTint(color).setBlendMode(Phaser.BlendModes.ADD).setDepth(1500).setScale(0.1);
  scene.tweens.add({ targets: c, scale: (2 * r) / 128, alpha: 0, duration: dur, onComplete: () => c.destroy() });
}
function fxSparks(scene, x, y, color = 0xffe08a, n = 10) {
  ensurePixelTex(scene);
  const p = scene.add.particles(x, y, 'fxpix', {
    speed: { min: 70, max: 235 }, angle: { min: 0, max: 360 }, scale: { start: 1.35, end: 0 },
    gravityY: 460, alpha: { start: 1, end: 0 }, lifespan: 430, tint: color, blendMode: 'ADD', emitting: false,
  }).setDepth(1500);
  p.explode(n + 4);
  scene.time.delayedCall(560, () => p.destroy());
}
function fxAura(scene, x, y, r, color, dur = -1) {
  // ASET: glow lembut fx/glow.png — napas mengembang-mengecil.
  if (scene.textures.exists('fx_tex_glow')) {
    const c = scene.add.image(x, y, 'fx_tex_glow').setTint(color).setAlpha(0.18).setBlendMode(Phaser.BlendModes.ADD).setDepth(-1).setScale((r * 2) / 128);
    scene.tweens.add({ targets: c, alpha: { from: 0.12, to: 0.30 }, scale: { from: (r * 1.84) / 128, to: (r * 2.2) / 128 }, duration: 900, yoyo: true, repeat: -1 });
    if (dur > 0) scene.time.delayedCall(dur, () => c.destroy());
    return c;
  }
  const c = scene.add.image(x, y, scene.textures.exists('fx_tex_flash') ? 'fx_tex_flash' : 'fx_tex_glow').setTint(color).setAlpha(0.16).setBlendMode(Phaser.BlendModes.ADD).setDepth(-1).setDisplaySize(r * 2, r * 2);
  scene.tweens.add({ targets: c, alpha: { from: 0.1, to: 0.26 }, scale: { from: 0.92, to: 1.1 }, duration: 900, yoyo: true, repeat: -1 });
  if (dur > 0) scene.time.delayedCall(dur, () => c.destroy());
  return c;
}
function fxFlash(scene, color = 0xffffff, dur = 90, alpha = 0.2) {
  // ASET: fx/flash.png di-stretch layar penuh.
  if (scene.textures.exists('fx_tex_flash')) {
    const r = scene.add.image(0, 0, 'fx_tex_flash').setTint(color).setAlpha(alpha).setOrigin(0).setScrollFactor(0).setDepth(3000).setDisplaySize(scene.scale.width + 4, scene.scale.height + 4);
    scene.tweens.add({ targets: r, alpha: 0, duration: dur, onComplete: () => r.destroy() });
    return;
  }
  const r = uiFill(scene, 0, 0, scene.scale.width + 4, scene.scale.height + 4, color, alpha, 0).setScrollFactor(0).setDepth(3000);
  scene.tweens.add({ targets: r, alpha: 0, duration: dur, onComplete: () => r.destroy() });
}
/* Bintang ledak 4 arah (fx/star.png) — crit & ultimate. */
function fxStar(scene, x, y, color = 0xfbbf24, scale = 0.8) {
  if (!scene.textures.exists('fx_tex_star')) return;
  const st = scene.add.image(x, y, 'fx_tex_star').setTint(color).setBlendMode(Phaser.BlendModes.ADD).setDepth(1501).setScale(scale * 0.3).setAngle(R(-30, 30));
  scene.tweens.add({ targets: st, scale: scale * 1.55, alpha: 0, duration: 330, ease: 'Quad.easeOut', onComplete: () => st.destroy() });
}
/* Puff debu (fx/smoke.png) — mendarat, mati musuh, impact meteor. */
function fxDust(scene, x, y, n = 3) {
  if (!scene.textures.exists('fx_tex_smoke')) return;
  for (let i = 0; i < n; i++) {
    const d = scene.add.image(x + RF(-10, 10), y - RF(0, 6), 'fx_tex_smoke').setTint(0x8a93a8).setAlpha(0.5).setDepth(845).setScale(RF(0.18, 0.30), RF(0.10, 0.18));
    scene.tweens.add({ targets: d, x: d.x + RF(-26, 26), y: d.y - RF(8, 22), alpha: 0, scaleX: d.scaleX * 1.9, duration: R(320, 520), onComplete: () => d.destroy() });
  }
}
function shake(scene, intensity = 6) { scene.cameras.main.shake(120, intensity * 0.01); }

/* ---------- Transisi scene sinematik + vignette + header pixel ----------
 * Semua perpindahan scene kini: fade-out cepat + sfx whoosh, lalu scene baru
 * fade-in + dolly halus (zoom 1.018 -> 1). Diimplementasikan TERPUSAT via
 * monkey-patch ScenePlugin.start + dekorator kelas scene — seragam di semua
 * scene tanpa menyentuh kode tiap scene. scene.restart() TIDAK di-fade agar
 * pergantian tab/filter tetap instan-responsif. */
let KZ_LAST_SCENE = null;
function installSceneTransitions() {
  const proto = Phaser.Scenes.ScenePlugin.prototype;
  const origStart = proto.start;
  proto.start = function (key, data) {
    const sc = this.scene;
    if (!sc || !sc.cameras || !sc.cameras.main || sc.__kzGoing) return origStart.call(this, key, data);
    sc.__kzGoing = true;
    Sfx.whoosh();
    sc.cameras.main.fadeOut(130, 8, 12, 24);
    sc.time.delayedCall(145, () => { try { origStart.call(this, key, data); } catch (_) {} });
  };
}
function withSceneFX(SceneClass) {
  const Wrapped = class extends SceneClass {
    create(...args) {
      // v13: scene PERTAMA yang hidup = Phaser sudah mengambil alih peran
      // "loading" -> splash DOM WAJIB tutup di sini (dulu hanya LobbyScene,
      // sehingga jalur Login/ClassSelect/macet bisa meninggalkan veil putih).
      try { if (window.kzSplashHide) window.kzSplashHide(); } catch (_) {}
      const key = this.scene.key;
      const isNav = KZ_LAST_SCENE !== key; // datang dari scene lain (bukan restart tab)
      this.__kzGoing = false;
      super.create(...args);
      KZ_LAST_SCENE = key;
      if (!isNav) return;
      try {
        const cam = this.cameras.main;
        if (cam && !this.__kzGoing) {
          cam.fadeIn(230, 8, 12, 24);
          cam.setZoom(1.018);
          this.tweens.add({ targets: cam, zoom: 1, duration: 430, ease: 'Cubic.easeOut' });
        }
      } catch (_) {}
    }
  };
  return Wrapped;
}
// Vignette sinematik untuk scene gameplay (dungeon/battle) — gradasi radial
// lembut di tepi layar, di bawah HUD agar teks tetap tajam.
function ensureVignette(scene) {
  // v9: vignette = aset radial ui/vignette.png (dibuat saat build, bukan runtime).
}
function addVignette(scene, depth = 899) {
  if (!scene.textures.exists('ui_vignette')) return null;
  const W = scene.scale.width, H = scene.scale.height;
  return scene.add.image(W / 2, H / 2, 'ui_vignette').setDisplaySize(W * 1.28, H * 1.28).setScrollFactor(0).setDepth(depth).setAlpha(0.85);
}
// Header scene pixel AAA: judul F_HEAD berlapis bayangan + garis aksen berpaku.
function sceneHeader(scene, title, subtitle, { y = null, color = '#f8fafc', accent = null, size = 19 } = {}) {
  const W = scene.scale.width, H = scene.scale.height;
  const ty = y != null ? y : Math.max(46, H * 0.05);
  const acc = accent != null ? accent : PAL.gold;
  const sh = scene.add.text(W / 2 + 2, ty + 3, title, { fontFamily: F_HEAD, fontSize: size + 'px', color: '#0b0b12' }).setOrigin(0.5);
  const t = scene.add.text(W / 2, ty, title, { fontFamily: F_HEAD, fontSize: size + 'px', color, stroke: '#0b0b12', strokeThickness: 2 }).setOrigin(0.5);
  let sc = 1;
  const maxW = W * 0.86;
  if (t.width > maxW) { sc = maxW / t.width; t.setScale(sc); sh.setScale(sc); }
  const lw = Math.min(maxW, t.width * sc + 30);
  const uy = ty + size * 0.72 * sc + 7;
  // v9: garis aksen dari aset putih (tint akurat, pixel presisi).
  uiFill(scene, W / 2 - lw / 2, uy, lw, 3, acc, 0.92, 0);
  uiFill(scene, W / 2 - lw / 2 - 6, uy - 2, 4, 7, acc, 0.5, 0);
  uiFill(scene, W / 2 + lw / 2 + 2, uy - 2, 4, 7, acc, 0.5, 0);
  if (subtitle) scene.add.text(W / 2, uy + 13, subtitle, { fontFamily: F_PIX, fontSize: '10px', color: '#8b96ab' }).setOrigin(0.5);
  return t;
}
/* ============================================================================
 * 5. UI HELPER + BACKGROUND
 * ========================================================================== */
/* ---------- UI KIT ASET (v9): nol canvas untuk semua chrome UI ---------- */
const UI_KIT_SLICES = {
  ui_btn: { l: 14, r: 14, t: 14, b: 14 }, ui_btn_hover: { l: 14, r: 14, t: 14, b: 14 },
  ui_panel: { l: 18, r: 18, t: 18, b: 18 }, ui_header: { l: 14, r: 14, t: 10, b: 10 },
  ui_hud: { l: 14, r: 14, t: 14, b: 14 }, ui_tile: { l: 12, r: 12, t: 12, b: 12 },
  ui_toast: { l: 16, r: 16, t: 14, b: 14 }, ui_bar_frame: { l: 4, r: 4, t: 4, b: 4 },
  ui_outline: { l: 2, r: 2, t: 2, b: 2 },
};
// Blok warna polos dari aset putih (pengganti add.rectangle/fillRect visual).
function uiFill(scene, x, y, w, h, color = 0x000000, alpha = 1, origin = 0.5) {
  const key = scene.textures.exists('ui_white') ? 'ui_white' : (scene.textures.exists('fx_tex_flash') ? 'fx_tex_flash' : '__DEFAULT');
  return scene.add.image(x, y, key).setTint(color).setAlpha(alpha).setDisplaySize(Math.max(1, w), Math.max(1, h)).setOrigin(origin, origin);
}
// Bingkai 9-slice dari aset UI kit (tintable).
function uiSlice(scene, x, y, w, h, texKey = 'ui_panel', tint = 0xffffff, corner = null) {
  if (scene.textures.exists(texKey) && scene.add.nineslice) {
    const c = corner || UI_KIT_SLICES[texKey] || { l: 12, r: 12, t: 12, b: 12 };
    try {
      return scene.add.nineslice(x, y, texKey, undefined, Math.max(4, w), Math.max(4, h), c.l, c.r, c.t, c.b).setTint(tint);
    } catch (_) {}
  }
  return uiFill(scene, x, y, w, h, tint === 0xffffff ? 0x131b2c : tint, 1);
}
// Bar progres berbasis aset: bingkai 9-slice + isi tileSprite (lebar dinamis).
function uiBar(scene, x, y, w, h, ratio, color, { frameTint = 0xffffff, depth = null } = {}) {
  const cont = scene.add.container(x, y);
  const fr = uiSlice(scene, 0, 0, w, h, 'ui_bar_frame', frameTint).setOrigin(0.5);
  cont.add(fr);
  let fill = null;
  const iw = Math.max(1, (w - 4) * clamp(ratio == null ? 1 : ratio, 0, 1));
  if (scene.textures.exists('ui_bar_fill')) {
    fill = scene.add.tileSprite(-(w - 4) / 2 + iw / 2 - iw / 2, 0, iw, Math.max(2, h - 4), 'ui_bar_fill').setTint(color);
    fill.setX(-(w - 4) / 2 + iw / 2);
    cont.add(fill);
  } else {
    fill = uiFill(scene, -(w - 4) / 2, -(h - 4) / 2, iw, h - 4, color, 1, 0);
    cont.add(fill);
  }
  cont.__fill = fill;
  if (depth != null) cont.setDepth(depth);
  cont.setFillRatio = (r2) => {
    const w2 = Math.max(1, (w - 4) * clamp(r2 == null ? 1 : r2, 0, 1));
    if (fill && fill.width != null) { fill.width = w2; fill.setX(-(w - 4) / 2 + w2 / 2); }
    return cont;
  };
  return cont;
}
// Set scrollFactor 0 rekursif (container + anak) untuk objek HUD fixed.
function ssf0(obj) {
  try { obj.setScrollFactor(0); if (obj.list) obj.list.forEach(ssf0); } catch (_) {}
  return obj;
}
// Latar scene berbasis aset (stretch cover + gelap opsional).
function sceneBgImage(scene, key, { dark = 0, depth = -100 } = {}) {
  if (!scene.textures.exists(key)) return null;
  const W = scene.scale.width, H = scene.scale.height;
  const im = scene.add.image(W / 2, H / 2, key).setDisplaySize(W + 2, H + 2).setDepth(depth).setScrollFactor(0);
  if (dark > 0) uiFill(scene, W / 2, H / 2, W + 2, H + 2, 0x050810, dark).setScrollFactor(0).setDepth(depth + 1);
  return im;
}
function makeButton(scene, x, y, w, h, label, { color = 0x2a3650, textColor = '#f8fafc', size = 16, icon = null, iconColor = 0xf8fafc, disabled = false, onClick, onDown, onRelease } = {}) {
  // v9: tombol = ASET 9-slice (ui/btn) di-tint + varian hover; tekan = turun.
  // Label auto-fit — TIDAK PERNAH luber keluar tombol apa pun teksnya.
  const cont = scene.add.container(x, y);
  const hasKit = scene.textures.exists('ui_btn') && scene.add.nineslice;
  let bgN = null, bgH = null, bgF = null;
  if (hasKit) {
    const c = UI_KIT_SLICES.ui_btn;
    bgN = scene.add.nineslice(0, 0, 'ui_btn', undefined, w, h, c.l, c.r, c.t, c.b).setTint(color);
    bgH = scene.add.nineslice(0, 0, 'ui_btn_hover', undefined, w, h, c.l, c.r, c.t, c.b).setTint(color).setVisible(false);
    cont.add(bgN); cont.add(bgH);
  } else {
    bgF = uiFill(scene, 0, 0, w, h, color);
    cont.add(bgF);
  }
  let txt = null, ico = null;
  if (icon) {
    ico = iconImage(scene, -w / 2 + 19, 0, icon, { size: Math.min(h - 18, 24), color: iconColor });
    cont.add(ico);
  }
  txt = scene.add.text(0, 0, label, { fontFamily: F_PIX, fontSize: size + 'px', color: disabled ? '#94a3b8' : textColor });
  const maxW = w - (icon ? 52 : 16);
  if (txt.width > maxW) txt.setScale(Math.max(0.55, maxW / txt.width));
  if (icon) {
    // v10 FIX AKAR: teks tombol berikon dulunya mulai di tengah (x=13) sehingga
    // label panjang SELALU meluber ke kanan tombol. Kini grup [ikon+teks]
    // dipusatkan dan teks mulai tepat setelah ikon — muat di semua lebar.
    const icoW = Math.min(h - 18, 24), gap = 8;
    const groupW = icoW + gap + txt.width * txt.scaleX;
    const startX = -groupW / 2;
    ico.setX(startX + icoW / 2);
    txt.setOrigin(0, 0.5).setX(startX + icoW + gap);
  } else {
    txt.setOrigin(0.5, 0.5).setX(0);
  }
  cont.add(txt);
  const area = makeInteractive(scene.add.rectangle(0, 0, w + 6, h + 6, 0x000000, 0.001), { useHandCursor: !disabled });
  cont.add(area);
  const nudge = (on) => { if (txt) txt.y = on ? 1.5 : 0; if (ico) ico.y = on ? 1.5 : 0; };
  if (!disabled && (onClick || onDown || onRelease)) {
    area.on('pointerover', () => {
      if (bgH) bgH.setVisible(true);
      Sfx.hover();
      if (!cont.__kzHold) scene.tweens.add({ targets: cont, scale: 1.035, duration: 90, ease: 'Quad.easeOut' });
    });
    area.on('pointerout', () => { if (bgH) bgH.setVisible(false); if (onRelease) onRelease(); scene.tweens.add({ targets: cont, scale: 1, duration: 110 }); });
    area.on('pointerdown', () => { if (bgH) bgH.setY(2); nudge(true); cont.__kzHold = true; scene.tweens.add({ targets: cont, scale: 0.97, duration: 70 }); if (onDown) onDown(); });
    area.on('pointerup', () => { if (bgH) bgH.setY(0); nudge(false); cont.__kzHold = false; scene.tweens.add({ targets: cont, scale: 1.035, duration: 90 }); if (onClick) onClick(); if (onRelease) onRelease(); });
  } else if (disabled) {
    cont.setAlpha(0.55);
  }
  cont.labelText = txt;
  cont.fitLabel = () => {
    if (!txt) return;
    txt.setScale(1);
    const mW = w - (icon ? 52 : 16);
    if (txt.width > mW) txt.setScale(Math.max(0.55, mW / txt.width));
    if (icon && ico) {
      const icoW2 = Math.min(h - 18, 24), gap2 = 8;
      const gw = icoW2 + gap2 + txt.width * txt.scaleX;
      ico.setX(-gw / 2 + icoW2 / 2);
      txt.setX(-gw / 2 + icoW2 + gap2);
    }
  };
  cont.setIcon = (name, c) => { if (ico) { ico.setTexture(iconTexture(scene, name, c || iconColor)); ico.clearTint(); ico.setDisplaySize(Math.min(h - 18, 24), Math.min(h - 18, 24)); } };
  // setScrollFactor harus menular ke ANAK (termasuk area input) — kalau tidak,
  // area klik tombol "melayang" menjauh dari tampilannya saat kamera scroll.
  const _origSSF = cont.setScrollFactor.bind(cont);
  cont.setScrollFactor = function (x, y) {
    _origSSF(x, y);
    for (const child of this.list) { if (child && child.setScrollFactor) child.setScrollFactor(x, y !== undefined ? y : x); }
    return this;
  };
  return cont;
}
function menuCard(scene, x, y, w, h, { title = '', subtitle = '', icon = 'star', color = 0x1f2937, disabled = false, onClick }) {
  // v9: kartu menu = aset tile 9-slice + aksen kiri + outline berwarna.
  const cont = scene.add.container(x, y);
  cont.add(uiSlice(scene, 0, 0, w, h, 'ui_tile', 0x141d2e));
  const acc = uiFill(scene, -w / 2, -h / 2, 6, h, color, disabled ? 0.16 : 0.42, 0);
  cont.add(acc);
  const ol = uiSlice(scene, 0, 0, w - 2, h - 2, 'ui_outline', color).setAlpha(disabled ? 0.35 : 0.55);
  cont.add(ol);
  const ico = iconImage(scene, -w / 2 + 30, 0, icon, { size: 26, color });
  cont.add(ico);
  cont.add(scene.add.text(-w / 2 + 52, -9, title, { fontFamily: F_UI, fontSize: '16px', color: disabled ? '#64748b' : '#f8fafc', fontStyle: 'bold' }).setOrigin(0, 0.5));
  cont.add(scene.add.text(-w / 2 + 52, 10, subtitle, { fontFamily: F_UI, fontSize: '11px', color: disabled ? '#475569' : '#8b96ab' }).setOrigin(0, 0.5));
  if (!disabled) {
    const area = makeInteractive(scene.add.rectangle(0, 0, w, h, 0x000000, 0.001), { useHandCursor: true });
    cont.add(area);
    area.on('pointerover', () => { acc.setAlpha(0.8); ol.setAlpha(0.95); cont.setY(y - 2); });
    area.on('pointerout', () => { acc.setAlpha(0.42); ol.setAlpha(0.55); cont.setY(y); });
    area.on('pointerup', () => { Sfx.click(); if (onClick) onClick(); });
  } else cont.setAlpha(0.55);
  return cont;
}
function panel(scene, x, y, w, h, color = 0x131b2c, alpha = 0.96, radius = 10) {
  // v9: panel = aset 9-slice (ui/panel, tint warna) + bayangan aset — x,y = kiri-atas.
  const cont = scene.add.container(0, 0);
  const c = UI_KIT_SLICES.ui_panel;
  if (scene.textures.exists('ui_panel') && scene.add.nineslice) {
    try {
      const sh = scene.add.nineslice(x + 3, y + 5, 'ui_panel', undefined, w, h, c.l, c.r, c.t, c.b).setTint(0x000000).setAlpha(0.34).setOrigin(0, 0);
      const pn = scene.add.nineslice(x, y, 'ui_panel', undefined, w, h, c.l, c.r, c.t, c.b).setOrigin(0, 0).setAlpha(alpha);
      // aset panel grayscale terang -> tint gandakan agar gelap sesuai warna asli.
      const bc = Phaser.Display.Color.IntegerToColor(color);
      const tint = Phaser.Display.Color.GetColor(
        Math.min(255, Math.round(bc.red * 1.35)), Math.min(255, Math.round(bc.green * 1.35)), Math.min(255, Math.round(bc.blue * 1.35)));
      pn.setTint(tint);
      cont.add(sh); cont.add(pn);
      cont.__panelSlice = pn;
    } catch (_) {}
  }
  if (!cont.list.length) {
    cont.add(uiFill(scene, x, y, w, h, color, alpha, 0));
  }
  return cont;
}
function floatText(scene, x, y, text, color = '#f8fafc', size = 18) {
  const t = scene.add.text(x, y, text, { fontFamily: F_PIX, fontSize: size + 'px', color, stroke: '#0b0b12', strokeThickness: 4 }).setOrigin(0.5);
  scene.tweens.add({ targets: t, y: y - 34, alpha: 0, duration: 850, ease: 'Quad.easeOut', onComplete: () => t.destroy() });
}
// Toast notifikasi (achievement, info) — muncul atas, tidak pakai emoji.
const Toast = {
  show(scene, { title = '', message = '', icon = 'star', color = 0xf2c230 }) {
    // v12: dedup — toast identik dalam 4.5 detik tidak ditumpuk (akar 3x
    // "BELUM TERSAMBUNG KE SERVER" bertindih di lobby saat klik cepat).
    const tkey = title + '|' + message;
    const tnow = Date.now();
    if (Toast._last && Toast._last.key === tkey && tnow - Toast._last.t < 4500) return;
    Toast._last = { key: tkey, t: tnow };
    if ((Toast._n || 0) >= 3) return; // v10: maks 3 — tidak menumpuk menutupi UI
    const W = scene.scale.width;
    const y = 64 + (Toast._n || 0) * 62;
    Toast._n = (Toast._n || 0) + 1;
    const width = Math.min(400, W - 30);
    const cont = scene.add.container(W / 2, -60).setScrollFactor(0).setDepth(4000);
    // v9: toast = aset 9-slice gelap + strip aksen + outline warna.
    cont.add(uiSlice(scene, 0, 0, width, 52, 'ui_toast', 0xffffff));
    cont.add(uiFill(scene, -width / 2, -26, 5, 52, color, 0.95, 0));
    cont.add(uiSlice(scene, 0, 0, width - 5, 47, 'ui_outline', color).setAlpha(0.85));
    const tIco = iconImage(scene, -width / 2 + 28, 0, icon, { size: 26, color });
    cont.add(tIco);
    cont.add(scene.add.text(-width / 2 + 50, -11, title, { fontFamily: F_PIX, fontSize: '12px', color: '#f8fafc' }).setOrigin(0, 0.5));
    cont.add(scene.add.text(-width / 2 + 50, 8, message, { fontFamily: F_UI, fontSize: '11px', color: '#94a3b8', wordWrap: { width: width - 70 } }).setOrigin(0, 0.5));
    scene.tweens.add({ targets: tIco, scale: tIco.scale * 1.22, duration: 170, yoyo: true, ease: 'Quad.easeOut' });
    scene.tweens.add({ targets: cont, y, duration: 320, ease: 'Back.easeOut' });
    scene.tweens.add({ targets: cont, y: -80, alpha: 0, delay: 3400, duration: 320, ease: 'Quad.easeIn', onComplete: () => { cont.destroy(); Toast._n = Math.max(0, (Toast._n || 1) - 1); } });
    Sfx.pop();
  },
  _n: 0,
};

/* ---------- Dekorasi latar: SEMUA dari aset (v9) ---------- */
const BG_ALIAS = { bridge: 'mountain', ruins: 'cave', night: 'forest', snow: 'mountain' };
const TERRA_LOC = { forest: 'forest', night: 'night', cave: 'cave', ruins: 'ruins', volcano: 'volcano', snow: 'snow', lake: 'oasis', desert: 'oasis', oasis: 'oasis', bridge: 'ruins', mountain: 'snow' };
const DECO_ASSET = {
  tree: 'asset_tree', pine: 'asset_tree', stone: 'asset_deco_rock1', rock: 'asset_deco_rock2',
  pillar: 'asset_deco_rock3', crystal: 'asset_deco_crystal', crystalCluster: 'asset_deco_crystal',
  cactus: 'asset_deco_cactus', reed: 'asset_deco_bush', mushroom: 'asset_deco_mushroom',
  flower: 'asset_deco_bush', gravestone: 'asset_deco_gravestone', bush: 'asset_deco_bush',
  lantern: 'asset_deco_lamp', lamp: 'asset_deco_lamp', web: 'asset_deco_web', bones: 'asset_deco_bones',
  vine: 'asset_deco_vine', urn: 'asset_deco_urn', bannerwall: 'asset_deco_bannerwall', fence: 'asset_deco_fence',
  sign: 'asset_deco_sign', snowpile: 'asset_deco_snowpile', lavacrack: 'asset_deco_lavacrack',
  icecrystal: 'asset_deco_icecrystal', stalagmite: 'asset_deco_stalagmite',
};
// v13: deco BERANIMASI Craftpix (paket user) — sprite + anim, bukan image statis.
const DECO_SPRITE_ANIM = {
  fairy:    { key: 'asset_deco_fairy',    anim: 'deco_fairy_anim',    end: 11, fps: 8,  blend: 'ADD', float: [10, 22] },
  predator: { key: 'asset_deco_predator', anim: 'deco_predator_anim', end: 8,  fps: 7,  blend: null,  float: null },
  flystone: { key: 'asset_deco_flystone', anim: 'deco_flystone_anim', end: 5,  fps: 6,  blend: null,  float: [8, 16] },
};
function ensureDecoAnims(scene) {
  for (const cfg of Object.values(DECO_SPRITE_ANIM)) {
    if (!scene.textures.exists(cfg.key) || scene.anims.exists(cfg.anim)) continue;
    try { scene.anims.create({ key: cfg.anim, frames: scene.anims.generateFrameNumbers(cfg.key, { start: 0, end: cfg.end }), frameRate: cfg.fps, repeat: -1 }); } catch (_) {}
  }
}
function placeBgDecoImage(scene, type, dx, base, i) {
  // v13: tipe beranimasi (fairy/predator/flystone) -> sprite + tween hidup.
  const sp = DECO_SPRITE_ANIM[type];
  if (sp && scene.textures.exists(sp.key)) {
    ensureDecoAnims(scene);
    let scale = type === 'predator' ? RF(0.85, 1.3) : (type === 'flystone' ? RF(0.55, 0.95) : RF(0.9, 1.5));
    const o = scene.add.sprite(dx, base, sp.key, 0).setOrigin(0.5, 1).setScale(scale).setDepth(-5).setFlipX(i % 2 === 0);
    if (type === 'fairy') { o.setY(base - RF(26, 60)); o.setDepth(-4); }
    if (type === 'flystone') o.setDepth(-7).setAlpha(0.92);
    if (sp.blend === 'ADD') o.setBlendMode(Phaser.BlendModes.ADD);
    try { o.play(sp.anim); } catch (_) {}
    if (sp.float) scene.tweens.add({ targets: o, y: o.y - RF(sp.float[0], sp.float[1]), duration: RF(1800, 3200), yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    return;
  }
  const key = DECO_ASSET[type];
  if (!key || !scene.textures.exists(key)) key = 'asset_deco_rock1';
  if (!scene.textures.exists(key)) return;
  const sc = type === 'tree' ? RF(0.9, 1.25) : RF(0.85, 1.3);
  scene.add.image(dx, base, key).setOrigin(0.5, 1).setScale(sc).setFlipX(i % 2 === 0);
}
function buildLivingBackground(scene, locationKey, { animated = true } = {}) {
  const loc = LOCATIONS[locationKey] || LOCATIONS.forest;
  const W = scene.scale.width, H = scene.scale.height;
  const container = scene.add.container(0, 0);
  const bgAssetKey = 'asset_bg_' + (BG_ALIAS[locationKey] || locationKey);
  const hasBg = scene.textures.exists(bgAssetKey);
  // Garis tanah: 80% tinggi layar — pita tanah digambar eksplisit di ATAS aset
  // supaya posisi berdiri karakter tidak ambigu (lihat fix spawn).
  const groundY = H * 0.80;
  if (hasBg) {
    const bgImg = scene.add.image(W / 2, H / 2, bgAssetKey);
    const sc = Math.max(W / bgImg.width, H / bgImg.height);
    bgImg.setDisplaySize(bgImg.width * sc, bgImg.height * sc);
    container.add(bgImg);
  } else if (scene.textures.exists('asset_bgx_bg_sky_day')) {
    // v9: fallback langit siang + pegunungan + matahari glow — semua aset.
    const bgImg = scene.add.image(W / 2, H / 2, 'asset_bgx_bg_sky_day');
    const sc = Math.max(W / bgImg.width, H / bgImg.height);
    bgImg.setDisplaySize(bgImg.width * sc, bgImg.height * sc);
    container.add(bgImg);
    if (scene.textures.exists('asset_bgx_mountains')) {
      const mh = H * 0.24;
      const mt = scene.add.tileSprite(W / 2, groundY - mh / 2 - 8, W, mh, 'asset_bgx_mountains').setAlpha(0.9);
      container.add(mt);
    }
    container.add(scene.add.image(W * 0.72, H * 0.2, 'fx_tex_glow').setTint(loc.sky[2] != null ? loc.sky[2] : 0xffffff).setAlpha(0.5).setScale(1.6).setBlendMode(Phaser.BlendModes.ADD));
  } else {
    container.add(uiFill(scene, W / 2, H / 2, W, H, loc.sky && loc.sky[0] != null ? loc.sky[0] : 0x14532d));
    container.add(scene.add.image(W * 0.72, H * 0.22, 'fx_tex_glow').setTint(loc.sky && loc.sky[2] != null ? loc.sky[2] : 0xffffff).setAlpha(0.4).setScale(1.6).setBlendMode(Phaser.BlendModes.ADD));
  }
  const cloudKeys = ['asset_cloud1', 'asset_cloud2', 'asset_cloud3'].filter((k) => scene.textures.exists(k));
  if (cloudKeys.length && locationKey !== 'cave') {
    for (let i = 0; i < 3; i++) {
      const cloud = scene.add.image(-120, R(H * 0.1, H * 0.45), cloudKeys[i % cloudKeys.length]).setAlpha(0.9);
      container.add(cloud);
      scene.tweens.add({ targets: cloud, x: W + 120, duration: R(32000, 52000), repeat: -1, delay: i * 9000, onRepeat: () => { cloud.y = R(H * 0.08, H * 0.5); } });
    }
  }
  if (loc.part === 'star') {
    // v9: bintang = titik aset glow kecil (tanpa shape).
    for (let i = 0; i < 50; i++) {
      const st = scene.add.image(R(0, W), R(0, H * 0.5), scene.textures.exists('fx_tex_flash') ? 'fx_tex_flash' : 'fx_tex_glow').setDisplaySize(R(2, 4), R(2, 4)).setAlpha(RF(0.4, 1));
      container.add(st);
    }
  }
  if (!hasBg) {
    const deco = scene.add.container(0, 0);
    const decoTypes = Array.isArray(loc.deco) ? loc.deco : [loc.deco || 'rock'];
    for (let i = 0; i < 9; i++) {
      const dx = 16 + (i / 9) * (W + 160);
      placeBgDecoImage(scene, decoTypes[i % decoTypes.length], dx, groundY, i);
    }
    const rockKeys = ['asset_deco_rock1', 'asset_deco_rock2', 'asset_deco_rock3', 'asset_deco_rock4'].filter((k) => scene.textures.exists(k));
    for (let i = 0; i < 4 && rockKeys.length; i++) {
      const rock = scene.add.image(R(W * 0.06, W * 0.94), groundY - 6, rockKeys[i % rockKeys.length]).setScale(R(12, 20) / 10).setAlpha(0.95);
      deco.add(rock);
    }
    container.add(deco);
  }
  // Pita tanah eksplisit — v9: tile terrain aset + garis cap (nol canvas).
  const terraTheme = TERRA_LOC[locationKey] || 'forest';
  const terraKey = buildTerrainTextures(scene, terraTheme);
  const gh = H - groundY;
  const lightHex = { forest: 0x4ade80, night: 0x2f6b4f, cave: 0x6b7280, ruins: 0x8b7fb8, volcano: 0xb91c1c, snow: 0xffffff, lake: 0x2dd4bf, bridge: 0x8a6a3a, desert: 0xfbbf24, oasis: 0x4ade80, mountain: 0x9ca3af }[locationKey] || 0x4ade80;
  if (scene.textures.exists(terraKey) && terraKey !== 'fx_tex_flash') {
    container.add(scene.add.tileSprite(W / 2, groundY + gh / 2, W, gh, terraKey).setTileScale(2, 2));
  } else {
    container.add(uiFill(scene, W / 2, groundY + gh / 2, W, gh, loc.ground != null ? loc.ground : 0x1f2937));
  }
  const capKey = 'terratex_' + terraTheme + '_cap';
  if (scene.textures.exists(capKey)) {
    container.add(scene.add.tileSprite(W / 2, groundY + 8, W, 14, capKey).setOrigin(0.5, 0).setTileScale(2, 2));
  }
  container.add(uiFill(scene, 0, groundY, W, 5, lightHex, 0.95, 0));
  container.add(uiFill(scene, 0, groundY + 5, W, 3, 0x000000, 0.25, 0));
  // Partikel hidup.
  const partColors = { firefly: [0xfde68a, 0xf2c230], leaf: [0x4ade80, 0x86efac], ember: [0xf59e0b, 0xef4444], star: [0xffffff], snow: [0xffffff, 0xe0f2ff], sand: [0xfde68a] };
  const cols = partColors[loc.part] || partColors.firefly;
  const em = scene.add.particles(0, 0, scene.textures.exists('dot') ? 'dot' : 'fx_tex_pixel', {
    x: { min: 0, max: W }, y: H * 0.6,
    lifespan: 4000, speedY: { min: -30, max: -8 }, speedX: { min: -14, max: 14 },
    scale: { min: 0.3, max: 1 }, quantity: 2, frequency: 260, tint: cols, emitting: animated,
  });
  container.add(em);
  return { container, groundY, loc };
}
function buildLobbyBackground(scene) {
  const W = scene.scale.width, H = scene.scale.height;
  const container = scene.add.container(0, 0);
  // v9: lobby = aula kastil hangat (aset eksklusif) -> fallback parallax hutan -> blok.
  let used = 0;
  if (scene.textures.exists('asset_bgx_bg_lobby')) {
    const img = scene.add.image(W / 2, H / 2, 'asset_bgx_bg_lobby');
    const sc = Math.max(W / img.width, H / img.height);
    img.setDisplaySize(img.width * sc, img.height * sc);
    container.add(img); used++;
    container.add(uiFill(scene, W / 2, H / 2, W, H, 0x0a0710, 0.18));
  } else {
    ['asset_parallax_forest_sky', 'asset_parallax_forest_clouds', 'asset_parallax_forest_flora1', 'asset_parallax_forest_flora2'].forEach((key) => {
      if (!scene.textures.exists(key)) return;
      const img = scene.add.image(W / 2, H, key).setOrigin(0.5, 1);
      const sc = Math.max(W / img.width, H / img.height);
      img.setDisplaySize(img.width * sc, img.height * sc);
      container.add(img); used++;
    });
  }
  if (!used) container.add(uiFill(scene, W / 2, H / 2, W, H, 0x14532d));
  const cloudKeys = ['asset_cloud1', 'asset_cloud2', 'asset_cloud3'].filter((k) => scene.textures.exists(k));
  for (let i = 0; i < 3 && cloudKeys.length; i++) {
    const cloud = scene.add.image(-120, R(H * 0.1, H * 0.42), cloudKeys[i % cloudKeys.length]).setAlpha(0.9);
    container.add(cloud);
    scene.tweens.add({ targets: cloud, x: W + 120, duration: R(36000, 56000), repeat: -1, delay: i * 9000, onRepeat: () => { cloud.y = R(H * 0.08, H * 0.42); } });
  }
  const em = scene.add.particles(0, 0, scene.textures.exists('dot') ? 'dot' : 'fx_tex_pixel', {
    x: { min: 0, max: W }, y: H, lifespan: 4000, speedY: { min: -40, max: -10 }, speedX: { min: -14, max: 14 },
    scale: { min: 0.3, max: 1 }, quantity: 2, frequency: 240, tint: [0xfde68a, 0xf2c230],
  });
  container.add(em);
  return { container, groundY: H * 0.86 };
}

/* ---------- Tema dungeon + parallax + tekstur tanah ---------- */
function dungeonTheme(theme) {
  const map = {
    cave:    { label: 'Gua',       accent: 0x38bdf8, cap: 0x4b5563, capLight: 0x6b7280, dirt: 0x1f2937, dirtDark: 0x111827, deco: ['stalagmite', 'crystal', 'skull', 'crate'], part: [0x38bdf8, 0xa78bfa] },
    night:   { label: 'Kastil',    accent: 0xa78bfa, cap: 0x374151, capLight: 0x4b5563, dirt: 0x111827, dirtDark: 0x0b1120, deco: ['column', 'bannerruins', 'skull', 'crate'], part: [0xa78bfa, 0x6366f1] },
    ruins:   { label: 'Reruntuhan',accent: 0xf0abfc, cap: 0x57534e, capLight: 0x78716c, dirt: 0x292524, dirtDark: 0x1c1917, deco: ['column', 'gravestone', 'crate'], part: [0xf0abfc, 0xc084fc] },
    volcano: { label: 'Gunung Api',accent: 0xf97316, cap: 0x7f1d1d, capLight: 0x991b1b, dirt: 0x450a0a, dirtDark: 0x2a0505, deco: ['lavacrack', 'rock2', 'crate'], part: [0xf97316, 0xef4444] },
    snow:    { label: 'Salju',     accent: 0x93c5fd, cap: 0xe2e8f0, capLight: 0xf8fafc, dirt: 0x94a3b8, dirtDark: 0x64748b, deco: ['snowpile', 'icecrystal', 'crate'], part: [0xffffff, 0xe0f2ff] },
    forest:  { label: 'Hutan',     accent: 0x4ade80, cap: 0x365314, capLight: 0x4d7c0f, dirt: 0x1a2e05, dirtDark: 0x0f1c02, deco: ['mushroom', 'tree', 'bush'], part: [0x4ade80, 0xa3e635] },
    oasis:   { label: 'Oasis',     accent: 0xfbbf24, cap: 0xd9a441, capLight: 0xf0c568, dirt: 0x92400e, dirtDark: 0x5f2c06, deco: ['cactus', 'bush', 'crate'], part: [0xfde68a, 0xfbbf24] },
  };
  return map[theme] || map.cave;
}
function buildThemeParallax(scene, theme, W, H) {
  const T = dungeonTheme(theme);
  const layers = [];
  // Latar dasar: aset gambar penuh per tema (fallback gradasi).
  const bgKey = 'asset_bg_' + theme;
  if (scene.textures.exists(bgKey)) {
    const bgImg = scene.add.image(W / 2, H / 2, bgKey).setScrollFactor(0).setDepth(-30);
    const sc = Math.max(W / bgImg.width, H / bgImg.height) * 1.06;
    bgImg.setScale(sc);
    // Gelapkan sedikit supaya gameplay tetap terbaca.
    const dim = uiFill(scene, W / 2, H / 2, W, H, 0x000000, 0.30).setScrollFactor(0).setDepth(-29);
    layers.push({ obj: { tilePositionX: 0, destroy() { bgImg.destroy(); dim.destroy(); } }, factor: 0 });
  } else {
    const bg = uiFill(scene, W / 2, H / 2, W, H, T.dirtDark).setScrollFactor(0).setDepth(-30);
    layers.push({ obj: { tilePositionX: 0, destroy() { bg.destroy(); } }, factor: 0 });
  }
  // Lapisan tengah: strip siluet aset (parallax pelan) — jatuh dari atas ke bawah layar.
  const stripKey = 'strip_' + theme;
  if (scene.textures.exists(stripKey)) {
    const tex = scene.textures.get(stripKey);
    const stripH = Math.min(H * 0.55, 300);
    const scale = stripH / tex.getSourceImage().height;
    const tileW = tex.getSourceImage().width * scale;
    const strip = scene.add.tileSprite(W / 2, H - stripH / 2 + 40, W + tileW, stripH, stripKey).setScrollFactor(0).setDepth(-26);
    strip.setTileScale(scale, scale);
    layers.push({ obj: strip, factor: 0.22 });
    // Kabut lembut di atas strip.
    const fog = scene.add.tileSprite(W / 2, H - stripH / 2 - 10, W + 200, 90, '__WHITE').setScrollFactor(0).setDepth(-25).setAlpha(0.0);
    fog.setTint(0x0b1120); fog.blendMode = Phaser.BlendModes.ADD;
    scene.tweens.add({ targets: fog, alpha: 0.10, duration: 2600, yoyo: true, repeat: -1 });
    layers.push({ obj: { tilePositionX: 0, destroy() { fog.destroy(); } }, factor: 0.10 });
  }
  // Berkas cahaya diagonal (god rays) — subtle, tema gelap saja.
  if (['cave', 'night', 'ruins'].includes(theme)) {
    for (let i = 0; i < 3; i++) {
      const ray = uiFill(scene, W * (0.2 + i * 0.3), -20, 46, H * 0.85, 0xfff2d8, 0.035).setScrollFactor(0).setDepth(-24).setAngle(9 + i * 3).setBlendMode(Phaser.BlendModes.ADD).setOrigin(0.5, 0);
      scene.tweens.add({ targets: ray, alpha: { from: 0.015, to: 0.06 }, duration: R(1800, 3200), yoyo: true, repeat: -1, delay: i * 500 });
      layers.push({ obj: { tilePositionX: 0, destroy() { ray.destroy(); } }, factor: 0 });
    }
  }
  return layers;
}
function buildTerrainTextures(scene, theme) {
  const T = dungeonTheme(theme);
  const key = 'terra_fill_' + theme;
  if (scene.textures.exists(key)) return key;
  // v8: tile terrain asli (assets/tiles/terr_<theme>_fill.png) > canvas.
  if (scene.textures.exists('terratex_' + theme + '_fill')) {
    try { scene.textures.addImage(key, scene.textures.get('terratex_' + theme + '_fill').getSourceImage()); return key; } catch (_) {}
  }
  // v9: fallback = aset tema lain yang termuat (nol canvas).
  for (const t of ['cave', 'night', 'ruins', 'volcano', 'snow', 'forest', 'oasis']) {
    if (scene.textures.exists('terratex_' + t + '_fill')) return 'terratex_' + t + '_fill';
  }
  return scene.textures.exists('fx_tex_flash') ? 'fx_tex_flash' : '__DEFAULT';
}
function addAmbientParticles(scene, theme, W, H) {
  const T = dungeonTheme(theme);
  return scene.add.particles(0, 0, scene.textures.exists('dot') ? 'dot' : 'fx_tex_pixel', {
    x: { min: 0, max: W }, y: { min: 0, max: H * 0.5 },
    lifespan: 5000, speedY: { min: 12, max: 40 }, speedX: { min: -10, max: 10 },
    scale: { min: 0.10, max: 0.34 }, alpha: { start: 0.55, end: 0 },
    quantity: 1, frequency: 320, tint: T.part, blendMode: Phaser.BlendModes.ADD,
  }).setScrollFactor(0).setDepth(-15);
}
function addTorch(scene, x, y, color) {
  // v8: obor aset pixel-art + nyala sparkle + glow — tanpa gambar canvas.
  if (scene.textures.exists('asset_deco_torch')) {
    scene.add.image(x, y, 'asset_deco_torch').setOrigin(0.5, 1).setScale(1.5).setDepth(-5);
  } else if (scene.textures.exists('fx_tex_flash')) {
    scene.add.image(x, y - 13, 'fx_tex_flash').setTint(0x3a2712).setDisplaySize(10, 30).setOrigin(0.5, 1).setDepth(-5);
  }
  const flame = scene.add.image(x, y - 40, scene.textures.exists('fx_tex_sparkle') ? 'fx_tex_sparkle' : 'fx_tex_flash').setTint(color).setScale(0.24).setBlendMode(Phaser.BlendModes.ADD).setDepth(-5);
  const glow = scene.add.image(x, y - 40, scene.textures.exists('fx_tex_glow') ? 'fx_tex_glow' : 'fx_tex_flash').setTint(color).setScale(0.4, 0.32).setAlpha(0.28).setBlendMode(Phaser.BlendModes.ADD).setDepth(-6);
  scene.tweens.add({ targets: [flame, glow], scale: { from: 0.85, to: 1.2 }, alpha: { from: 0.75, to: 1 }, duration: R(300, 500), yoyo: true, repeat: -1 });
}
/* ============================================================================
 * 6. SCENE: BOOT / LOGIN / LOBBY / CLASS SELECT / QUEST BOARD
 * ========================================================================== */
class BootScene extends Phaser.Scene {
  constructor() { super('Boot'); }
  preload() {
    this.load.on('progress', (v) => {
      const bar = document.getElementById('bootBar');
      if (bar) bar.style.width = Math.round(v * 100) + '%';
    });
    // CACHE-BUSTING per build: server menyajikan aset dengan cache 7 hari
    // (immutable) demi performa. Tanpa ?v=, browser bisa memakai sprite/ikon
    // LAMA dari deploy sebelumnya -> "game tiba-tiba jelek diam-diam".
    // Dengan ?v=KZ_BUILD, setiap build baru = URL baru = aset segar sekali
    // fetch, lalu cache 7 hari lagi untuk build itu. WAJIB konsisten dengan
    // <meta kz-build> di rpg.html dan GAME_BUILD di rpgServer.js.
    const AV = '?v=' + KZ_BUILD;
    this.load.atlas(ATLAS_KEY, 'assets/atlas.png' + AV, 'assets/atlas.json' + AV);
    ['forest', 'cave', 'lake', 'desert', 'volcano', 'mountain', 'oasis'].forEach((k) => this.load.image('asset_bg_' + k, 'assets/backgrounds/' + k + '.png' + AV));
    this.load.image('asset_bg_oasis2', 'assets/backgrounds/oasis2.png' + AV);
    ['cloud4', 'cloud5'].forEach((n) => this.load.image('asset_' + n, 'assets/deco/' + n + '.png' + AV));
    this.load.image('asset_tree', 'assets/tiles/tree.png' + AV);
    this.load.image('asset_rock', 'assets/tiles/rock.png' + AV);
    this.load.image('asset_rock1', 'assets/deco/rock1.png' + AV);
    this.load.image('asset_rock2', 'assets/deco/rock2.png' + AV);
    this.load.image('asset_rock3', 'assets/deco/rock3.png' + AV);
    this.load.image('asset_cloud1', 'assets/deco/cloud1.png' + AV);
    this.load.image('asset_cloud2', 'assets/deco/cloud2.png' + AV);
    this.load.image('asset_cloud3', 'assets/deco/cloud3.png' + AV);
    ['rock1', 'rock2', 'rock3', 'rock4', 'rock_snow1', 'rock_snow2', 'rock_ice1', 'stalagmite1', 'stalagmite2', 'stalagmite3']
      .forEach((n) => this.load.image('asset_deco_' + n, 'assets/deco/rocks/' + n + '.png' + AV));
    ['sky', 'clouds', 'flora1', 'flora2'].forEach((n) => this.load.image('asset_parallax_forest_' + n, 'assets/backgrounds/forest_layers/' + n + '.png' + AV));
    // Sprite sheet monster craftpix (fallback bila atlas tidak tersedia).
    MONSTERS.forEach((m) => { try { this.load.spritesheet('asset_mon_' + m.id, 'assets/monsters/' + m.id + '.png' + AV, { frameWidth: 48, frameHeight: 48 }); } catch (_) {} });
    // v12 §3: SEMUA pet dalam SATU atlas (30 sheet -> 1 file): 1 request HTTP
    // + 1 tekstur GPU = tekanan memori grafis jauh berkurang (mendukung fix
    // Framebuffer §1A). Fallback ke sheet terpisah tetap disediakan bila atlas
    // gagal dimuat (deploy terpotong) supaya game tidak pernah kosong pet.
    this.load.atlas(PETS_ATLAS_KEY, 'assets/pets_atlas.png' + AV, 'assets/pets_atlas.json' + AV);
    window.__kzPetsAtlasOk = false;
    this.load.once('complete', () => {
      if (!this.textures.exists(PETS_ATLAS_KEY)) return;
      if (!petsAtlasReady(this)) {
        PET_ORDER.forEach((p) => {
          try {
            this.load.spritesheet('asset_pet_' + p, 'assets/pets/' + p + '.png' + AV, { frameWidth: 64, frameHeight: 64 });
            this.load.spritesheet('asset_pet_' + p + '_evo', 'assets/pets/' + p + '_evo.png' + AV, { frameWidth: 64, frameHeight: 64 });
          } catch (_) {}
        });
        this.load.start();
      } else window.__kzPetsAtlasOk = true;
    });
    // Hero sheet baru (archer & assassin — beda total dari class lain).
    try {
      this.load.spritesheet('hero_archer_v3', 'assets/hero/archer_sheet.png' + AV, { frameWidth: 56, frameHeight: 56 });
      this.load.spritesheet('hero_assassin_v3', 'assets/hero/assassin_sheet.png' + AV, { frameWidth: 56, frameHeight: 56 });
    } catch (_) {}
    // HERO SHEET v13 (3328x2048, 13 kolom x 8 baris @256px) — 4 karakter beda:
    // Dark Knight / Maya / pemanah hd / prototipe. Baris: 0 cast, 1 walk,
    // 2 slash, 3 shoot, 4 hurt, 5 idle+combat, 6 jump, 7 run. Arah: kanan.
    ['warrior', 'mage', 'assassin', 'archer'].forEach((c) => {
      try { this.load.spritesheet('hero_lpc_' + c, 'assets/hero/' + c + '.png' + AV, { frameWidth: 256, frameHeight: 256 }); } catch (_) {}
    });
    // Senjata & gear yang terlihat dipakai karakter.
    ['sword','axe','hammer','spear','staff','wand','orb','tome','dagger','katana','claw','bow'].forEach((w) => {
      try { this.load.image('gear_wpn_' + w, 'assets/gear/wpn_' + w + '.png' + AV); } catch (_) {}
    });
    try { this.load.image('gear_arrow', 'assets/gear/arrow.png' + AV); } catch (_) {}
    ['cape_light','cape_chain','cape_plate','shield','acc_wings','acc_halo','acc_orb','acc_star'].forEach((g) => {
      try { this.load.image('gear_' + g, 'assets/gear/' + g + '.png' + AV); } catch (_) {}
    });
    // Strip parallax per tema + tekstur FX.
    ['cave','castle','ruins','volcano','snow','forest','oasis'].forEach((t) => {
      try { this.load.image('strip_' + t, 'assets/backgrounds/strips/' + t + '.png' + AV); } catch (_) {}
    });
    ['glow','sparkle','slash','streak'].forEach((f) => {
      try { this.load.image('fx_tex_' + f, 'assets/fx/' + f + '.png' + AV); } catch (_) {}
    });
    // v8: FX tambahan (ring/pixel/shadow/flash/star/smoke) + dekorasi pixel-art
    // + tile terrain per-tema + art eksklusif senjata legendaris.
    ['ring','pixel','shadow','flash','star','smoke'].forEach((f) => {
      try { this.load.image('fx_tex_' + f, 'assets/fx/' + f + '.png' + AV); } catch (_) {}
    });
    // v11: VFX skill animasi aset internet (OpenGameArt) — frame 128px (magic pack 64px).
    ['vfx_fire','vfx_ice','vfx_water','vfx_arcane','vfx_slash','vfx_circle','vfx_aura_fire','vfx_aura_blue','vfx_aura_purple','vfx_lpc_effects'].forEach((f) => {
      try { this.load.spritesheet(f, 'assets/fx/' + f + '.png' + AV, { frameWidth: 128, frameHeight: 128 }); } catch (_) {}
    });
    ['vfx_firelion','vfx_iceshield','vfx_lightning','vfx_snake','vfx_tornado','vfx_spikes','vfx_tentacle','vfx_icetacle'].forEach((f) => {
      try { this.load.spritesheet(f, 'assets/fx/' + f + '.png' + AV, { frameWidth: 64, frameHeight: 64 }); } catch (_) {}
    });
    // v13: ATLAS LEDAKAN Craftpix dari paket user (free license) — 11 varian
    // (oranye/biru/gas/nuklir/petir/asap...) untuk kill, ultimate, meteor.
    ['fx_expl_orange','fx_expl_circle','fx_expl_blue','fx_expl_oval','fx_expl_gas','fx_expl_gasc','fx_expl_two','fx_expl_nuke','fx_expl_fire','fx_expl_light','fx_expl_smoke'].forEach((f) => {
      try { this.load.spritesheet(f, 'assets/fx/' + f + '.png' + AV, { frameWidth: 128, frameHeight: 128 }); } catch (_) {}
    });
    // v13: DECO Craftpix dari paket user — peri bercahaya, tanaman predator,
    // pulau batu melayang (deco ambient beranimasi untuk tema hutan/danau).
    try { this.load.spritesheet('asset_deco_fairy', 'assets/deco/fairy.png' + AV, { frameWidth: 32, frameHeight: 32 }); } catch (_) {}
    try { this.load.spritesheet('asset_deco_predator', 'assets/deco/predator.png' + AV, { frameWidth: 224, frameHeight: 80 }); } catch (_) {}
    try { this.load.spritesheet('asset_deco_flystone', 'assets/deco/flystone.png' + AV, { frameWidth: 160, frameHeight: 128 }); } catch (_) {}
    ['stalagmite','crystal','icecrystal','mushroom','bush','cactus','gravestone','snowpile','lavacrack','torch'].forEach((n) => {
      try { this.load.image('asset_deco_' + n, 'assets/deco/' + n + '.png' + AV); } catch (_) {}
    });
    ['cave','night','ruins','volcano','snow','forest','oasis'].forEach((t) => {
      try { this.load.image('terratex_' + t + '_fill', 'assets/tiles/terr_' + t + '_fill.png' + AV); } catch (_) {}
      try { this.load.image('terratex_' + t + '_cap', 'assets/tiles/terr_' + t + '_cap.png' + AV); } catch (_) {}
    });
    ['w_rusty','w_steel','w_elven','w_dragon','w_omega'].forEach((n) => {
      try { this.load.image('asset_art_' + n, 'assets/items/' + n + '.png' + AV); } catch (_) {}
    });
    // v9: UI KIT 9-slice + ikon pixel + objek interaksi + latar scene + deco baru.
    ['white','outline','btn','btn_hover','panel','header','hud','bar_frame','bar_fill','tile','toast','prompt','badge','orb','divider','key_e','pedestal','vignette'].forEach((n) => {
      try { this.load.image('ui_' + n, 'assets/ui/' + n + '.png' + AV); } catch (_) {}
    });
    UI_ICON_KEYS.forEach((k) => { try { this.load.image('ui_icon_' + k, 'assets/ui/icons/' + k + '.png' + AV); } catch (_) {} });
    ['chest_wood','chest_silver','chest_gold','chest_mimic'].forEach((n) => {
      try { this.load.spritesheet('itx_' + n, 'assets/interact/' + n + '.png' + AV, { frameWidth: 32, frameHeight: 32 }); } catch (_) {}
    });
    try { this.load.spritesheet('itx_merchant', 'assets/interact/merchant.png' + AV, { frameWidth: 48, frameHeight: 64 }); } catch (_) {}
    try { this.load.spritesheet('itx_altar', 'assets/interact/altar.png' + AV, { frameWidth: 48, frameHeight: 64 }); } catch (_) {}
    try { this.load.spritesheet('itx_portal', 'assets/interact/portal.png' + AV, { frameWidth: 64, frameHeight: 96 }); } catch (_) {}
    try { this.load.image('itx_merchant_stall', 'assets/interact/merchant_stall.png' + AV); } catch (_) {}
    try { this.load.image('itx_secret_crack', 'assets/interact/secret_crack.png' + AV); } catch (_) {}
    try { this.load.spritesheet('itx_smith', 'assets/interact/smith.png' + AV, { frameWidth: 40, frameHeight: 54 }); } catch (_) {}
    try { this.load.spritesheet('asset_deco_campfire', 'assets/deco/campfire.png' + AV, { frameWidth: 40, frameHeight: 40 }); } catch (_) {}
    ['bg_login','bg_lobby','bg_class','bg_forge','bg_sky_day','mountains'].forEach((n) => {
      try { this.load.image('asset_bgx_' + n, 'assets/backgrounds/' + n + '.png' + AV); } catch (_) {}
    });
    ['sign','lamp','web','bones','vine','urn','bannerwall','fence','tent'].forEach((n) => {
      try { this.load.image('asset_deco_' + n, 'assets/deco/' + n + '.png' + AV); } catch (_) {}
    });
    // Ikon item (game-icons.net, render lokal — lihat assets/README.md).
    PET_ITEM_ICON_KEYS.forEach((k) => { try { this.load.image('asset_icon_' + k, 'assets/icons/' + k + '.png' + AV); } catch (_) {} });
    // DEPLOY GUARD: aset yang gagal dimuat dicatat (bukan diabaikan diam-diam).
    // 1-2 file kecil gagal -> fallback prosedural tetap jalan. BANYAK gagal
    // berarti deploy tidak lengkap -> banner peringatan ditampilkan di create().
    window.__kzAssetFails = [];
    this.load.on('loaderror', (file) => {
      try { window.__kzAssetFails.push(String((file && (file.url || file.key)) || '?')); } catch (_) {}
    });
    // v13 WATCHDOG MUAT: jaringan sangat lambat / macet -> dulu splash progress
    // berhenti diam-diam selamanya. Kini: 20s tanpa kemajuan = sub splash
    // berubah jadi peringatan + tombol Coba Lagi (reload) muncul.
    window.__kzLoadLastProgress = 0;
    window.__kzLoadLastChange = Date.now();
    this.load.on('progress', (v) => {
      if (v > (window.__kzLoadLastProgress || 0) + 0.001) {
        window.__kzLoadLastProgress = v;
        window.__kzLoadLastChange = Date.now();
      }
    });
    if (!window.__kzLoadDog) {
      window.__kzLoadDog = setInterval(function () {
        if (window.__kzSplashDone) { clearInterval(window.__kzLoadDog); return; }
        const idle = Date.now() - (window.__kzLoadLastChange || Date.now());
        if (idle > 20000) {
          try {
            const sub = document.querySelector('#boot .sub');
            if (sub) sub.textContent = 'Koneksi lambat — periksa jaringanmu';
            const btn = document.getElementById('bootRetry');
            if (btn) btn.style.display = 'block';
          } catch (_) {}
        }
      }, 4000);
    }
  }
  create() {
    window.addEventListener('pointerdown', () => { Sfx.init(); }, { once: true });
    // v12 §1A: boot WebGL sukses -> hapus flag mode aman sesi ini.
    if (window.__kzRenderer === 'webgl') { try { sessionStorage.removeItem('kzSafeMode'); } catch (_) {} }
    // ---- v12 §3: DEV-MODE ASSET MANIFEST CHECK -----------------------------
    // (aktif dengan ?dev=1) — kekurangan state animasi per unit jadi
    // PERINGATAN KERAS di konsol, bukan bug visual senyap.
    try {
      if (/[?&]dev=1/.test(location.search)) {
        const need = [];
        PET_ORDER.forEach((p) => {
          ['asset_pet_' + p, 'asset_pet_' + p + '_evo'].forEach((k) => {
            const t = this.textures.exists(k) ? this.textures.get(k) : null;
            const n = t ? Object.keys(t.frames).length - 1 : 0;
            if (n < 16) need.push(k + ' (' + n + '/16 frame: idle/run/attack/hurt)');
          });
        });
        ['warrior', 'mage', 'assassin', 'archer'].forEach((c) => {
          const k = 'hero_lpc_' + c;
          const t = this.textures.exists(k) ? this.textures.get(k) : null;
          const n = t ? Object.keys(t.frames).length - 1 : 0;
          if (n < 104) need.push(k + ' (' + n + '/104 frame sheet v13)');
        });
        if (need.length) console.warn('[AssetManifest] UNIT KURANG STATE:\n - ' + need.join('\n - '));
        else console.log('[AssetManifest] semua unit lengkap: idle/move/attack(+cast mage)/hurt.');
      }
    } catch (_) {}
    // ---- DEPLOY GUARD 1: aset gagal dimuat --------------------------------
    const fails = window.__kzAssetFails || [];
    if (fails.length >= 3) {
      window.showDeployBanner(
        'PERINGATAN DEPLOY: ' + fails.length + ' aset game gagal dimuat',
        'Kemungkinan file di server tidak lengkap (upload terpotong / folder lama bercampur). ' +
        'Hapus folder lama di hosting, upload ulang zip terbaru, lalu muat ulang halaman ini. Detail: ' + fails.slice(0, 6).join(', '),
      );
    }
    // ---- DEPLOY GUARD 2: build client vs build server ---------------------
    if (CFG.server) {
      fetch(CFG.apiBase + '/api/rpg/build-info').then((r) => (r.ok ? r.json() : null)).then((info) => {
        if (info && info.build && info.build !== KZ_BUILD) {
          window.showDeployBanner(
            'File game campur versi',
            'Client build ' + KZ_BUILD + ' berbeda dengan server build ' + info.build + '. ' +
            'Sebagian file game masih versi lama — deploy ulang dari zip terbaru (hapus folder lama dulu).',
            'warn',
          );
        }
      }).catch(() => {});
    }
    // Catat ikon PNG yang berhasil dimuat (dipakai addItemIcon utk pilih PNG vs prosedural).
    window.__petIconLoaded = {};
    for (const k of PET_ITEM_ICON_KEYS) { if (this.textures.exists('asset_icon_' + k)) window.__petIconLoaded[k] = true; }
    // FILTER PER-JENIS ASET: game berjalan pixelArt (NEAREST) — pas untuk sprite
    // pixel, tapi MERUSAK ikon PNG 512px render vektor (downscale NEAREST =
    // noise). Ikon, glow FX, dan latar painterly memakai LINEAR.
    const linearTex = (k) => { try { const t = this.textures.get(k); if (t && t.key !== '__DEFAULT' && t.setFilter) t.setFilter(Phaser.Textures.FilterMode.LINEAR); } catch (_) {} };
    PET_ITEM_ICON_KEYS.forEach((k) => linearTex('asset_icon_' + k));
    ['glow', 'sparkle', 'slash', 'streak', 'ring', 'pixel', 'shadow', 'flash', 'star', 'smoke'].forEach((f) => linearTex('fx_tex_' + f));
    // Alias global: partikel lama ('fxpix', 'dot') kini memakai ASET asli.
    try {
      if (this.textures.exists('fx_tex_pixel')) { this.textures.addImage('fxpix', this.textures.get('fx_tex_pixel').getSourceImage()); linearTex('fxpix'); }
      if (this.textures.exists('fx_tex_glow')) { this.textures.addImage('dot', this.textures.get('fx_tex_glow').getSourceImage()); linearTex('dot'); }
    } catch (_) {}
    // Art eksklusif senjata legendaris tercatat agar itemPngIconKey pakai itu.
    window.__itemArtLoaded = {};
    ['w_rusty', 'w_steel', 'w_elven', 'w_dragon', 'w_omega'].forEach((n) => { if (this.textures.exists('asset_art_' + n)) window.__itemArtLoaded[n] = true; });
    ['forest', 'cave', 'lake', 'desert', 'volcano', 'mountain', 'oasis', 'oasis2'].forEach((k) => linearTex('asset_bg_' + k));
    ['cave', 'castle', 'ruins', 'volcano', 'snow', 'forest', 'oasis'].forEach((t) => linearTex('strip_' + t));
    ['sky', 'clouds', 'flora1', 'flora2'].forEach((n) => linearTex('asset_parallax_forest_' + n));
    ['white','outline','btn','btn_hover','panel','header','hud','bar_frame','bar_fill','tile','toast','prompt','badge','orb','divider','key_e','pedestal','vignette'].forEach((n) => linearTex('ui_' + n));
    UI_ICON_KEYS.forEach((k) => linearTex('ui_icon_' + k));
    // v10: sprite interaksi = pixel art -> WAJIB NEAREST (LINEAR bikin blur licin).
    ['bg_login','bg_lobby','bg_class','bg_forge','bg_sky_day','mountains'].forEach((n) => linearTex('asset_bgx_' + n));
    ['sign','lamp','web','bones','vine','urn','bannerwall','fence','tent'].forEach((n) => linearTex('asset_deco_' + n));
    ensureAtlasMonsterAnims(this);
    Data.load().then(async () => {
      // Mode server + belum login -> halaman login (JANGAN mulai game baru).
      if (CFG.server && Data.authFailed) { this.scene.start('Login'); return; }
      Rt.connect();
      // Pet HARUS termuat sebelum Lobby render pratinjau (anti race).
      try { await PetState.load(); } catch (_) {}
      this.scene.start('Lobby');
    });
  }
}

/* ---------- LOGIN: gerbang Discord (mode server saja) ---------- */
class LoginScene extends Phaser.Scene {
  constructor() { super('Login'); }
  create() {
    const W = this.scale.width, H = this.scale.height;
    // v9: latar login = aset hutan malam + bulan + bintang (nol canvas).
    if (this.textures.exists('asset_bgx_bg_login')) {
      const bg = this.add.image(W / 2, H / 2, 'asset_bgx_bg_login');
      const sc = Math.max(W / bg.width, H / bg.height);
      bg.setDisplaySize(bg.width * sc, bg.height * sc);
    } else {
      uiFill(this, 0, 0, W, H, 0x0a0f1c, 1, 0);
    }
    this.add.text(W / 2, H * 0.3, 'KIZHOO ADVENTURE', { fontFamily: F_HEAD, fontSize: '22px', color: '#fde68a', stroke: '#0b0b12', strokeThickness: 5 }).setOrigin(0.5);
    this.add.text(W / 2, H * 0.36, 'Masuk dengan Discord untuk melanjutkan petualanganmu', { fontFamily: F_UI, fontSize: '14px', color: '#8b96ab' }).setOrigin(0.5);
    // Kartu panel.
    panel(this, W / 2 - 190, H * 0.47, 380, 190, 0x131b2c, 0.97, 14);
    this.add.text(W / 2, H * 0.47 + 40, 'Progres tersimpan di akun Discord-mu.', { fontFamily: F_UI, fontSize: '14px', color: '#e2e8f0' }).setOrigin(0.5);
    this.add.text(W / 2, H * 0.47 + 66, 'Level, item, teman, dan achievement tidak akan hilang.', { fontFamily: F_UI, fontSize: '12px', color: '#8b96ab' }).setOrigin(0.5);
    makeButton(this, W / 2, H * 0.47 + 120, 260, 52, 'Login dengan Discord', { color: 0x5865F2, icon: 'user', size: 15, onClick: () => { location.href = '/auth/login?next=' + encodeURIComponent('/rpg'); } });
    if (Data.serverError) this.add.text(W / 2, H * 0.75, Data.serverError, { fontFamily: F_UI, fontSize: '12px', color: '#fca5a5' }).setOrigin(0.5);
  }
}

/* ---------- LOBBY: menu utama ---------- */
class LobbyScene extends Phaser.Scene {
  constructor() { super('Lobby'); }
  create() {
    const W = this.scale.width, H = this.scale.height;
    try { if (window.kzSplashHide) window.kzSplashHide(); } catch (_) {}
    this.bg = buildLobbyBackground(this);
    // Redupkan latar sedikit supaya panel & menu di atasnya lebih pop out.
    if (this.bg && this.bg.container) this.bg.container.setAlpha(0.87);
    const c = Data.char;
    const cls = CLASSES[c.classKey];
    // v9: gradasi redup atas — pita aset bertingkat (tanpa canvas).
    [0.42, 0.30, 0.18, 0.08].forEach((a, i) => uiFill(this, W / 2, (H * 0.30) * (i / 4) + (H * 0.30) / 8, W, (H * 0.30) / 4 + 1, 0x000000, a));

    // Banner judul — plakat pixel dengan teks berlapis + glint periodik.
    const bannerW = Math.min(460, W * 0.52);
    const bannerTop = H * 0.045;
    // v9: banner judul = aset header 9-slice + bayangan + paku emas.
    uiFill(this, W / 2 + 3, bannerTop + 55, bannerW, 100, 0x000000, 0.35);
    uiSlice(this, W / 2, bannerTop + 50, bannerW, 100, 'ui_header', 0xffffff);
    [[-bannerW / 2 + 10, 10], [bannerW / 2 - 10, 10], [-bannerW / 2 + 10, 90], [bannerW / 2 - 10, 90]].forEach(([ox, oy]) => {
      uiFill(this, W / 2 + ox, bannerTop + oy, 5, 5, PAL.gold, 0.85);
    });
    const titleGrp = this.add.container(W / 2, bannerTop + 42);
    const tShadow = this.add.text(3, 4, 'KIZHOO', { fontFamily: F_HEAD, fontSize: '34px', color: '#7c2d12' }).setOrigin(0.5);
    const tMain = this.add.text(0, 0, 'KIZHOO', { fontFamily: F_HEAD, fontSize: '34px', color: '#fde68a' }).setOrigin(0.5);
    const tGlint = this.add.text(0, -5, 'KIZHOO', { fontFamily: F_HEAD, fontSize: '34px', color: '#ffffff' }).setOrigin(0.5).setAlpha(0);
    titleGrp.add([tShadow, tMain, tGlint]);
    this.add.text(W / 2, bannerTop + 76, 'A D V E N T U R E', { fontFamily: F_PIX, fontSize: '13px', color: '#f2c230' }).setOrigin(0.5);
    // Hidup: mengambang halus + kilau menyapu tiap beberapa detik.
    this.tweens.add({ targets: titleGrp, y: bannerTop + 38, duration: 2200, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    this.tweens.add({ targets: tGlint, alpha: { from: 0, to: 0.45 }, duration: 230, yoyo: true, repeat: -1, repeatDelay: 3700 });

    // HUD status pemain — plakat pixel.
    const hudY = H * 0.045 + 96 + 34;
    const hudW = Math.min(470, W * 0.62);
    // v9: plakat HUD = aset hud 9-slice + outline warna class.
    uiFill(this, W / 2 + 2, hudY - 21, hudW, 46, 0x000000, 0.32);
    uiSlice(this, W / 2, hudY - 3, hudW, 46, 'ui_hud', 0xffffff);
    uiSlice(this, W / 2, hudY - 3, hudW - 5, 41, 'ui_outline', cls ? cls.color : PAL.gold).setAlpha(0.55);
    const rk = rankInfo(c.rankKey);
    const hudTxt = this.add.text(W / 2, hudY - 3, `${c.name || 'Petualang'}  •  ${cls ? cls.name : ''}  •  Lv.${c.level}  •  ${fmt(c.gold)} KZC`, {
      fontFamily: F_PIX, fontSize: '12.5px', color: '#dbeafe' }).setOrigin(0.5);
    if (hudTxt.width > hudW - 26) hudTxt.setScale((hudW - 26) / hudTxt.width);
    // SERVER DOMPET (guild switcher): KZC RPG = saldo /economy PER-SERVER.
    // Dulu web selalu menampilkan saldo guild mutual pertama — beda dengan
    // /balance di server Discord lain yang diikuti user -> "gak sinkron".
    if (CFG.server) {
      api('/api/me/guilds').then((r) => {
        const guilds = Array.isArray(r) ? r : ((r && r.guilds) || []);
        if (!guilds.length) return;
        const picked = (localStorage.getItem('kzGuild') || '').trim();
        const cur = guilds.find((g) => g.id === picked) || guilds[0];
        const chip = makeButton(this, 96, bannerTop + 18, 172, 30, 'Dompet: ' + (cur ? cur.name : '-'), {
          color: 0x1e293b, size: 9.5, icon: 'gear',
          onClick: () => {
            const veil = uiFill(this, W / 2, H / 2, W, H, 0x000000, 0.82).setDepth(3000);
            const box = this.add.container(W / 2, H / 2).setDepth(3001);
            const n = Math.min(guilds.length, 5);
            const bw2 = Math.min(420, W - 30);
            const bh2 = 60 + n * 46 + 48;
            box.add(uiSlice(this, 0, 0, bw2, bh2, 'ui_panel', 0x0b1220));
            box.add(uiSlice(this, 0, 0, bw2 - 4, bh2 - 4, 'ui_outline', PAL.gold).setAlpha(0.6));
            box.add(this.add.text(0, -bh2 / 2 + 22, 'PILIH SERVER DOMPET', { fontFamily: F_HEAD, fontSize: '12px', color: '#fde68a' }).setOrigin(0.5));
            box.add(this.add.text(0, -bh2 / 2 + 42, 'Saldo KZC disimpan terpisah per server Discord.', { fontFamily: F_UI, fontSize: '10px', color: '#8b96ab' }).setOrigin(0.5));
            guilds.slice(0, 5).forEach((g, i) => {
              const sel = cur && g.id === cur.id;
              box.add(makeButton(this, 0, -bh2 / 2 + 72 + i * 46, bw2 - 40, 38, g.name + (sel ? '  (dipakai)' : ''), {
                color: sel ? 0x0891b2 : 0x1f2937, size: 11, icon: sel ? 'check' : 'party',
                onClick: () => { localStorage.setItem('kzGuild', g.id); location.reload(); },
              }));
            });
            box.add(makeButton(this, 0, bh2 / 2 - 26, bw2 - 40, 34, 'Tutup', { color: 0x334155, size: 11, onClick: () => { veil.destroy(); box.destroy(); } }));
          },
        });
        this.events.once('shutdown', () => { try { chip.destroy(); } catch (_) {} });
      });
    }
    // Notifikasi poin belum terpakai.
    const notif = [];
    if ((c.statPoints || 0) > 0) notif.push(`${c.statPoints} poin stat`);
    if ((c.skillPoints || 0) > 0) notif.push(`${c.skillPoints} poin skill`);
    if (notif.length) {
      const badge = this.add.container(W / 2 + hudW / 2 + 46, hudY);
      badge.add(this.add.image(0, 0, 'ui_badge').setDisplaySize(46, 46).setTint(0x16a34a));
      badge.add(this.add.image(0, 0, 'ui_badge').setDisplaySize(36, 36).setTint(0x0b1220).setAlpha(0.4));
      badge.add(iconImage(this, 0, 0, 'plus', { size: 20, color: 0xfde68a }));
      this.tweens.add({ targets: badge, scale: { from: 1, to: 1.12 }, duration: 600, yoyo: true, repeat: -1 });
      this.add.text(badge.x, badge.y + 30, notif.join('\n'), { fontFamily: F_UI, fontSize: '10px', color: '#86efac', align: 'center' }).setOrigin(0.5);
    }

    // Pratinjau hero.
    const menuX = c.classKey ? W * 0.64 : W / 2;
    if (c.classKey) {
      const heroX = W * 0.19, heroY = H * 0.78;
      // v9: pedestal = aset pixel-art berlapis + kolom cahaya lembut.
      if (this.textures.exists('ui_pedestal')) {
        this.add.image(heroX, heroY + 4, 'ui_pedestal').setOrigin(0.5, 0.6).setDepth(0);
      } else {
        uiFill(this, heroX, heroY + 4, 104, 22, 0x232f4d, 1).setDepth(0);
      }
      const lightCol = uiFill(this, heroX, heroY - 130, 88, 260, 0xfde68a, 0.05).setDepth(-1).setBlendMode(Phaser.BlendModes.ADD);
      this.tweens.add({ targets: lightCol, alpha: { from: 0.04, to: 0.09 }, duration: 2600, yoyo: true, repeat: -1 });
      const hv = heroVisual(this, c.classKey, c.customization, 4.4);
      const hero = this.add.sprite(heroX, heroY, hv.key, hv.frame || 0).setOrigin(0.5, 1).setScale(hv.scale).setDepth(1);
      try { hero.play(hv.anim.idle); } catch (_) {}
      this.add.text(heroX, heroY + 24, c.name || 'Petualang', { fontFamily: F_UI, fontSize: '13px', color: '#e2e8f0', fontStyle: 'bold' }).setOrigin(0.5).setDepth(1);
      if (c.title) this.add.text(heroX, heroY + 42, c.title, { fontFamily: F_UI, fontSize: '11px', color: '#' + rk.color.toString(16).padStart(6, '0') }).setOrigin(0.5).setDepth(1);
      // Pet aktif menemani pratinjau hero.
      if (PetState.active && petTexExists(this, PetState.active, PetState.stage(PetState.active))) {
        spawnPetCompanion(this, PetState.active, {
          x: heroX + 64, y: heroY, depth: 2, scale: 1.8,
          follow: { get: () => ({ x: heroX + 64, y: heroY }) },
        });
        this.add.text(heroX + 64, heroY + 22, PetState.activePet ? PetState.activePet.name : '', { fontFamily: F_UI, fontSize: '10px', color: '#' + (PetState.activePet ? PET_RARITY_INFO[PetState.activePet.rarity].color.slice(1) : '9ca3af') }).setOrigin(0.5).setDepth(2);
      }
    }

    // Menu kartu.
    const locked = !c.classKey;
    const entries = [
      { title: locked ? 'Mulai Petualangan' : 'Petualangan', subtitle: locked ? 'Buat karaktermu lalu mulai bertualang' : 'Terima quest dan selesaikan misi guild', code: 'A', icon: 'scroll', color: 0x16a34a, cb: () => this.scene.start(c.classKey ? 'QuestBoard' : 'ClassSelect') },
      { title: 'Dungeon', subtitle: 'Jelajahi dungeon dan taklukkan boss', code: 'D', icon: 'dungeon', color: 0x7c3aed, cb: () => this.scene.start('DungeonSelect') },
      { title: 'Skill Tree', subtitle: 'Bangun karaktermu lewat 10 skill per class', code: 'S', icon: 'skill', color: 0xec4899, cb: () => this.scene.start(c.classKey ? 'SkillTree' : 'ClassSelect'), disabled: locked },
      { title: 'Koleksi Pet', subtitle: PetState.active ? (PetState.activePet ? PetState.activePet.name + ' menemanimu — lihat koleksimu' : 'Sahabat kecil penemani perjalanan') : 'Panggil dan rawat sahabat kecilmu', code: 'B', icon: 'paw', color: 0x65a30d, cb: () => this.scene.start(c.classKey ? 'Pets' : 'ClassSelect'), disabled: locked },
      { title: 'Inventori', subtitle: 'Kelola senjata, zirah, dan aksesoris', code: 'I', icon: 'bag', color: 0xd97706, cb: () => this.scene.start(c.classKey ? 'Inventory' : 'ClassSelect'), disabled: locked },
      { title: 'Pandai Besi', subtitle: 'Tempa material jadi senjata dan zirah', code: 'F', icon: 'hammer', color: 0xb45309, cb: () => this.scene.start(c.classKey ? 'Forge' : 'ClassSelect'), disabled: locked },
      { title: 'Profil', subtitle: 'Kartu rank, statistik & alokasi poin', code: 'P', icon: 'person', color: 0x0891b2, cb: () => this.scene.start('Profile') },
      { title: 'Achievement', subtitle: 'Buka prestasi dan klaim hadiahnya', code: 'V', icon: 'trophy', color: 0xca8a04, cb: () => this.scene.start('Achievements') },
      { title: 'Papan Peringkat', subtitle: 'Posisimu di antara para petualang', code: 'R', icon: 'medal', color: 0x0ea5e9, cb: () => this.scene.start('Leaderboard') },
      { title: 'Teman', subtitle: 'Tambah teman, chat, dan lihat siapa online', code: 'T', icon: 'friends', color: 0x06b6d4, cb: () => this.scene.start('Friends') },
      { title: 'Lobby Multiplayer', subtitle: 'Rame-rame maksimal 4 orang di party', code: 'M', icon: 'party', color: 0xf97316, cb: () => this.scene.start('MultiplayerLobby') },
      { title: 'Gacha Pet', subtitle: 'Satu-satunya cara mendapat pet — mythic sangat langka', code: 'G', icon: 'sparkle', color: 0xe879f9, cb: () => this.scene.start('Gacha'), disabled: locked },
      { title: 'Menara Tanpa Ujung', subtitle: 'Naik terus, hadiah makin besar', code: 'N', icon: 'compass', color: 0x4338ca, cb: () => this.scene.start('TowerInfo'), disabled: locked },
      { title: 'World Boss', subtitle: 'Boss mingguan — HP bersama seluruh pemain', code: 'W', icon: 'skull', color: 0xdc2626, cb: () => this.scene.start('WorldBoss'), disabled: locked },
      { title: 'Rumah Lelang', subtitle: 'Jual-beli item dengan pemain lain', code: 'L', icon: 'coin', color: 0xca8a04, cb: () => this.scene.start('Auction'), disabled: locked },
    ];
    // Grid menu kompak (3 kolom desktop / 2 kolom hp) — 15 entri tetap rapi.
    // gridTop dijamin DI BAWAH plakat HUD — di landscape desktop, grid di
    // kanan dan HUD di tengah pernah saling menabrak (fix overlap nyata).
    const perRow = W > 620 ? 3 : 2;
    const rows = Math.ceil(entries.length / perRow);
    const tileW = Math.min(230, (Math.min(W * (locked ? 0.94 : 0.66), 720) - (perRow - 1) * 10) / perRow);
    const gridTop = Math.max(H * 0.16, hudY + 46);
    const gapV = Math.max(46, Math.min(64, (H - 80 - gridTop) / rows));
    const tileH = Math.min(58, gapV - 8);
    const gridW = perRow * tileW + (perRow - 1) * 10;
    const gridX0 = menuX - gridW / 2 + tileW / 2;
    entries.forEach((e, i) => {
      const col = i % perRow, row = Math.floor(i / perRow);
      const tx = gridX0 + col * (tileW + 10);
      const ty = gridTop + row * gapV + tileH / 2;
      const tile = this.add.container(tx, ty).setDepth(3);
      const wTile = tileW, hTile = tileH;
      // v9: tile menu = aset 9-slice + aksen kiri + outline warna (nol canvas).
      tile.add(uiSlice(this, 0, 0, wTile, hTile, 'ui_tile', e.disabled ? 0x0d1526 : 0x121a2b));
      const tAcc = uiFill(this, -wTile / 2 + 2, -hTile / 2 + 2, 5, hTile - 4, e.color, e.disabled ? 0.10 : 0.24, 0);
      const tOl = uiSlice(this, 0, 0, wTile - 5, hTile - 5, 'ui_outline', e.disabled ? 0x1e293b : e.color).setAlpha(e.disabled ? 0.5 : 0.62);
      tile.add(tAcc); tile.add(tOl);
      const drawTile = (hovered) => {
        tAcc.setAlpha(e.disabled ? 0.10 : (hovered ? 0.5 : 0.24));
        tOl.setAlpha(e.disabled ? 0.5 : (hovered ? 1 : 0.62));
      };
      drawTile(false);
      // Ikon dalam bingkai kotak kecil bergaya pixel.
      const ibox = Math.min(34, hTile - 14);
      tile.add(uiFill(this, -wTile / 2 + 8, -ibox / 2, ibox, ibox, e.color, e.disabled ? 0.08 : 0.16, 0));
      tile.add(uiSlice(this, -wTile / 2 + 8 + ibox / 2, 0, ibox, ibox, 'ui_outline', e.color).setAlpha(e.disabled ? 0.25 : 0.55));
      const ic = iconImage(this, -wTile / 2 + 8 + ibox / 2, 0, e.icon, { size: ibox - 10, color: e.disabled ? 0x475569 : 0xf8fafc });
      tile.add(ic);
      const tT = this.add.text(-wTile / 2 + 8 + ibox + 9, 0, e.title, { fontFamily: F_PIX, fontSize: '11px', color: e.disabled ? '#475569' : '#e2e8f0', wordWrap: { width: wTile - ibox - 26 } }).setOrigin(0, 0.5);
      if (tT.width > wTile - ibox - 26) tT.setScale((wTile - ibox - 26) / tT.width);
      tile.add(tT);
      if (!e.disabled) {
        // v12.2: via makeInteractive (validasi + shape eksplisit; utk Container
        // displayOrigin = 0 sehingga shape centered tetap benar).
        makeInteractive(tile, { w: wTile, h: hTile, useHandCursor: true });
        tile.on('pointerover', () => {
          drawTile(true); Sfx.hover();
          this.tweens.add({ targets: tile, scale: 1.05, y: ty - 2, duration: 100, ease: 'Quad.easeOut' });
          this.tweens.add({ targets: ic, angle: { from: -8, to: 8 }, duration: 70, yoyo: true, repeat: 2 });
        });
        tile.on('pointerout', () => { drawTile(false); this.tweens.add({ targets: tile, scale: 1, y: ty, duration: 120 }); });
        tile.on('pointerdown', () => { Sfx.click(); e.cb(); });
      }
      // Intro berurutan: pop-in mengepulkan diri satu per satu.
      tile.setAlpha(0).setY(ty + 14);
      this.tweens.add({ targets: tile, alpha: 1, y: ty, duration: 300, delay: 130 + i * 36, ease: 'Back.easeOut' });
    });

    // Tombol chat mengambang (buka overlay chat dari scene mana pun).
    const chatBtn = makeButton(this, W - 54, H - 50, 76, 48, 'Chat', { color: 0x0e7490, icon: 'chat', size: 12, onClick: () => this.scene.launch('ChatOverlay', { back: 'Lobby' }) });
    chatBtn.setScrollFactor(0).setDepth(500);

    // Footer.
    this.add.text(W / 2, H - 14, 'Kizhoo Adventure  •  build ' + KZ_BUILD + '  •  jalan di HP dan PC  •  mode ' + (CFG.server ? 'server' : 'demo'), {
      fontFamily: F_UI, fontSize: '11px', color: '#64748b' }).setOrigin(0.5);

    // Toast achievement tertunda.
    Bus.on('achToast', (ids) => {
      for (const id of ids.slice(0, 3)) {
        const a = (Data.achievements || []).find((x) => x.id === id);
        if (a) Toast.show(this, { title: 'Achievement terbuka: ' + a.name, message: a.desc, icon: a.icon || 'trophy', color: 0xca8a04 });
      }
    });
    if (Data.pendingAchToasts && Data.pendingAchToasts.length) {
      const ids = Data.pendingAchToasts.splice(0, 3);
      for (const id of ids) {
        const a = (Data.achievements || []).find((x) => x.id === id);
        if (a) Toast.show(this, { title: 'Achievement terbuka: ' + a.name, message: a.desc, icon: a.icon || 'trophy', color: 0xca8a04 });
      }
    }
    // Naik level saat bermain? (kasus jarang di lobby)
    Bus.on('levelup', (info) => {
      Toast.show(this, { title: 'Naik ke level ' + info.to + '!', message: 'Buka Profil untuk alokasi poin stat & skill.', icon: 'star', color: 0x16a34a });
    });
  }
}

/* ---------- CLASS SELECT ---------- */
class ClassSelectScene extends Phaser.Scene {
  constructor() { super('ClassSelect'); }
  create() {
    const W = this.scale.width, H = this.scale.height;
    // v9: latar aula guild (aset) + gelap halus agar kartu pop.
    if (this.textures.exists('asset_bgx_bg_class')) {
      const bg = this.add.image(W / 2, H / 2, 'asset_bgx_bg_class');
      const sc = Math.max(W / bg.width, H / bg.height);
      bg.setDisplaySize(bg.width * sc, bg.height * sc);
      uiFill(this, W / 2, H / 2, W, H, 0x050810, 0.25);
    } else {
      uiFill(this, 0, 0, W, H, 0x0a0f1c, 1, 0);
    }
    sceneHeader(this, 'PILIH CLASS', 'Pilihan bisa diganti kapan saja lewat tombol di bawah', { y: H * 0.07 });

    const keys = CLASS_KEYS;
    const cardW = Math.min(272, W / keys.length - 20), cardH = H * 0.60;
    keys.forEach((k, i) => {
      const cls = CLASSES[k];
      const x = W / (keys.length + 1) * (i + 1), y = H * 0.48;
      const card = this.add.container(x, y);
      // v9: kartu class = aset tile 9-slice + band warna + outline class.
      card.add(uiFill(this, 3, -cardH / 2 + 5, cardW, cardH, 0x000000, 0.4, 0));
      card.add(uiSlice(this, 0, 0, cardW, cardH, 'ui_tile', 0x121a2b));
      const cBand = uiFill(this, -cardW / 2, -cardH / 2, cardW, 60, cls.color, 0.16, 0);
      const cOl = uiSlice(this, 0, 0, cardW - 4, cardH - 4, 'ui_outline', cls.color).setAlpha(0.85);
      card.add(cBand); card.add(cOl);
      const drawCard = (hovered) => {
        cBand.setAlpha(hovered ? 0.26 : 0.16);
        cOl.setAlpha(hovered ? 1 : 0.85);
      };
      drawCard(false);
      card.add(this.add.text(0, -cardH / 2 + 28, cls.name, { fontFamily: F_HEAD, fontSize: '15px', color: '#ffffff' }).setOrigin(0.5));
      card.add(this.add.text(0, -cardH / 2 + 52, cls.role, { fontFamily: F_PIX, fontSize: '10px', color: '#94a3b8' }).setOrigin(0.5));

      // Pratinjau animasi.
      const hv0 = heroVisual(this, k, null, 2.6);
      const prev = this.add.sprite(0, -cardH / 2 + 158, hv0.key, hv0.frame || 0).setOrigin(0.5, 1).setScale(hv0.scale);
      try { prev.play(hv0.anim.idle); } catch (_) {}
      card.add(prev);
      card.add(this.add.image(0, -cardH / 2 + 161, 'fx_tex_shadow').setDisplaySize(74, 18).setAlpha(0.5));

      const stats = [['HP', cls.base.hp], ['MP', cls.base.mp], ['ATK', cls.base.atk], ['DEF', cls.base.def], ['SPD', cls.base.spd], ['CRIT', cls.base.crit + '%']];
      const max = Math.max(...stats.map((s) => Number(String(s[1]).replace('%', ''))));
      stats.forEach((s, si) => {
        const sy = -cardH / 2 + 196 + si * 24;
        card.add(this.add.text(-cardW / 2 + 16, sy, s[0], { fontFamily: F_PIX, fontSize: '10px', color: '#8b96ab' }).setOrigin(0, 0.5));
        const bw2 = cardW - 112;
        // v9: stat bar = aset (frame + isi tileSprite).
        card.add(uiBar(this, -cardW / 2 + 54 + bw2 / 2, sy, bw2, 8, Number(String(s[1]).replace('%', '')) / max, cls.color, { frameTint: 0x1e293b }));
        card.add(this.add.text(cardW / 2 - 18, sy, s[1], { fontFamily: F_PIX, fontSize: '10px', color: '#e2e8f0' }).setOrigin(1, 0.5));
      });
      card.add(this.add.text(0, cardH / 2 - 78, cls.desc, { fontFamily: F_UI, fontSize: '11.5px', color: '#94a3b8', align: 'center', wordWrap: { width: cardW - 26 } }).setOrigin(0.5, 1));
      // Zona hover (di bawah tombol agar tombol tetap bisa diklik).
      const zone = makeInteractive(this.add.rectangle(0, 0, cardW, cardH, 0x000000, 0.001), { useHandCursor: true });
      card.add(zone);
      zone.on('pointerover', () => {
        drawCard(true); Sfx.hover();
        this.tweens.add({ targets: card, y: y - 8, duration: 130, ease: 'Quad.easeOut' });
        this.tweens.add({ targets: prev, scale: hv0.scale * 1.09, duration: 160, ease: 'Quad.easeOut' });
      });
      zone.on('pointerout', () => {
        drawCard(false);
        this.tweens.add({ targets: card, y: y, duration: 160 });
        this.tweens.add({ targets: prev, scale: hv0.scale, duration: 160 });
      });
      card.add(makeButton(this, 0, cardH / 2 - 26, cardW - 40, 40, 'Pilih', { color: cls.color, size: 15, onClick: async () => {
        const ok = await Data.chooseClass(k);
        if (ok) { Sfx.victory(); this.scene.start('Lobby'); }
      } }));
      // Intro stagger: meluncur dari sisi kiri/kanan bergantian.
      card.setAlpha(0).setX(x + (i % 2 === 0 ? -46 : 46));
      this.tweens.add({ targets: card, alpha: 1, x, duration: 380, delay: 90 + i * 110, ease: 'Cubic.easeOut' });
    });
    makeButton(this, W / 2, H - 30, 200, 42, 'Kembali', { color: 0x1f2937, icon: 'back', size: 14, onClick: () => this.scene.start('Lobby') });
  }
}

/* ---------- QUEST BOARD ---------- */
class QuestBoardScene extends Phaser.Scene {
  constructor() { super('QuestBoard'); }
  create() {
    const W = this.scale.width, H = this.scale.height;
    // v9: papan quest kayu — pita aset bertingkat + garis papan + header aset.
    uiFill(this, W / 2, H / 2, W, H, 0x241a10);
    uiFill(this, W / 2, H * 0.25, W, H / 2, 0x3a2a18, 0.45);
    uiFill(this, W / 2, H * 0.78, W, H * 0.44, 0x120c06, 0.5);
    for (let x = 32; x < W; x += 64) uiFill(this, x, H / 2, 2, H, 0x000000, 0.10);
    uiFill(this, W / 2, 45, W, 90, 0x000000, 0.30);
    uiFill(this, W / 2, H - 30, W, 60, 0x000000, 0.30);
    const headerW = Math.min(560, W * 0.62);
    uiSlice(this, W / 2, 45, headerW, 62, 'ui_header', 0xffffff);
    uiFill(this, W / 2 - headerW / 2 + 8, 20, 8, 8, 0x1c130d, 1);
    uiFill(this, W / 2 + headerW / 2 - 8, 20, 8, 8, 0x1c130d, 1);
    this.add.text(W / 2 + 2, 47, 'PAPAN QUEST GUILD', { fontFamily: F_HEAD, fontSize: '16px', color: '#1c130d' }).setOrigin(0.5);
    this.add.text(W / 2, 44, 'PAPAN QUEST GUILD', { fontFamily: F_HEAD, fontSize: '16px', color: '#f3e3c3' }).setOrigin(0.5);
    this.add.text(W / 2, 70, 'Pilih quest yang ingin dikerjakan', { fontFamily: F_PIX, fontSize: '10px', color: '#c9ad7f' }).setOrigin(0.5);

    Data.quests().then((quests) => {
      const active = quests.filter((q) => q.accepted && !q.done);
      const available = quests.filter((q) => !q.done && !q.accepted);
      if (!quests.length) this.add.text(W / 2, H / 2, 'Belum ada quest tersedia.', { fontFamily: F_UI, fontSize: '20px', color: '#f3e3c3' }).setOrigin(0.5);
      if (active.length) {
        this.add.text(W / 2, H * 0.115, 'SEDANG BERJALAN', { fontFamily: F_HEAD, fontSize: '10px', color: '#f2c230' }).setOrigin(0.5);
        active.forEach((q, i) => this.questCard(q, W / 2, H * 0.20 + i * 96, true));
      }
      const startY = active.length ? H * 0.20 + active.length * 96 + 26 : H * 0.16;
      this.add.text(W / 2, startY - 16, 'TERSEDIA', { fontFamily: F_HEAD, fontSize: '10px', color: '#a78bfa' }).setOrigin(0.5);
      available.forEach((q, i) => {
        const row = Math.floor(i / 2), col = i % 2;
        const x = W * 0.5 + (col - 0.5) * (W * 0.44);
        const y = startY + 30 + row * 128 + 40;
        if (y < H - 60) this.questCard(q, x, y, false);
      });
    });
    makeButton(this, W / 2, H - 32, 200, 44, 'Kembali', { color: 0x1f2937, icon: 'back', size: 14, onClick: () => this.scene.start('Lobby') });
  }
  questCard(q, x, y, isActive) {
    const w = Math.min(560, this.scale.width * 0.42), h = 88;
    const mon = monsterById(q.monster);
    const tierCol = TIERS[mon.tier === 'worldboss' || mon.tier === 'boss' ? 'legendary' : mon.tier === 'elite' ? 'epic' : 'common'];
    // v9: kartu quest = tile aset tint kertas + aksen tier + outline emas aktif.
    uiFill(this, x + 3, y - h / 2 + 5, w, h, 0x000000, 0.35, 0);
    uiSlice(this, x, y, w, h, 'ui_tile', 0xd9c39a);
    uiFill(this, x - w / 2, y - h / 2, 7, h, tierCol.color, 1, 0);
    if (isActive) uiSlice(this, x, y, w + 6, h + 6, 'ui_outline', 0xf2c230).setAlpha(0.95);
    const iconX = x - w / 2 + 30;
    this.add.image(iconX, y, 'ui_badge').setDisplaySize(44, 44).setTint(0x1c130d).setAlpha(0.88);
    this.add.image(iconX, y, 'ui_outline').setDisplaySize(44, 44).setTint(tierCol.color);
    iconImage(this, iconX, y, mon.tier === 'boss' || mon.tier === 'worldboss' ? 'skull' : 'sword', { size: 22, color: 0xf3e3c3 });
    const tx = x - w / 2 + 58;
    this.add.text(tx, y - 24, q.title + (q.done ? ' (selesai)' : ''), { fontFamily: F_UI, fontSize: '15px', color: '#2c1a08', fontStyle: 'bold' }).setOrigin(0, 0.5);
    const locName = (LOCATIONS[q.location] || {}).name || 'Lokasi';
    this.add.text(tx, y - 3, locName + '  •  ' + q.count + 'x ' + mon.name, { fontFamily: F_UI, fontSize: '12px', color: '#5a4326' }).setOrigin(0, 0.5);
    this.add.text(tx, y + 21, fmt(q.rewardXp) + ' XP  •  ' + fmt(q.rewardGold) + ' KZC  •  ' + (q.rewardRep || 0) + ' Rep', { fontFamily: F_UI, fontSize: '11px', color: '#7a4a10', fontStyle: 'bold' }).setOrigin(0, 0.5);
    makeButton(this, x + w / 2 - 64, y, 100, 40, isActive ? 'Kerjakan' : 'Ambil', { color: isActive ? 0x16a34a : 0x7c3aed, size: 13, onClick: () => {
      if (isActive || q.accepted) this.scene.start('QuestBattle', { quest: q });
      else Data.acceptQuest(q.id).then(() => this.scene.restart());
    } });
  }
}
/* ============================================================================
 * 7. SCENE: QUEST BATTLE (turn-based + animasi skill per jenis)
 * ========================================================================== */
class QuestBattleScene extends Phaser.Scene {
  constructor() { super('QuestBattle'); }
  init(data) { this.quest = data.quest; }
  create() {
    const W = this.scale.width, H = this.scale.height;
    this.bg = buildLivingBackground(this, this.quest.location, { animated: true });
    this.busy = false;

    const stats = computeStats(Data.char);
    this.p = {
      hp: stats.hp, hpMax: stats.hp, mp: stats.mp, mpMax: stats.mp,
      atk: stats.atk, def: stats.def, spd: stats.spd, crit: stats.crit,
      buffPct: 0, buffTurns: 0, regen: 0, regenTurns: 0, manaRegen: 0, manaRegenTurns: 0,
      shield: 0, defending: false, evasionPct: 0, evasionTurns: 0,
    };
    // Efek equipment gabungan.
    this.eff = {};
    for (const slot of ['weapon', 'armor', 'accessory']) {
      const eq = itemById(Data.char.equipped && Data.char.equipped[slot]);
      if (!eq || !eq.effect) continue;
      const e = eq.effect;
      const K = e.kind;
      if (K === 'cleave') this.eff.cleave = Math.max(this.eff.cleave || 0, e.pct);
      else if (K === 'lifesteal') this.eff.lifesteal = (this.eff.lifesteal || 0) + e.pct;
      else if (K === 'manaRegen') this.eff.manaRegen = (this.eff.manaRegen || 0) + e.val;
      else if (K === 'execute') this.eff.execute = Math.max(this.eff.execute || 0, e.pct);
      else if (K === 'poison') this.eff.poison = Math.max(this.eff.poison || 0, e.dot);
      else if (K === 'critDmg') this.eff.critDmg = (this.eff.critDmg || 0) + e.pct;
      else if (K === 'shield') this.eff.shield = Math.max(this.eff.shield || 0, e.pct);
      else if (K === 'thorns') this.eff.thorns = Math.max(this.eff.thorns || 0, e.pct);
      else if (K === 'regen') this.eff.regen = (this.eff.regen || 0) + e.val;
      else if (K === 'dodge') this.eff.dodge = (this.eff.dodge || 0) + e.pct;
      else if (K === 'goldFind') this.eff.goldFind = (this.eff.goldFind || 0) + e.pct;
      else if (K === 'revive') this.eff.revive = Math.max(this.eff.revive || 0, e.pct);
    }
    this.p.shield = this.eff.shield ? Math.round(this.p.hpMax * this.eff.shield) : 0;
    this.reviveUsed = false;
    this.combo = 0;
    this.enemies = buildEncounter(this.quest);
    this.log = [];

    // Judul lokasi berlapis bayangan (vignette tidak dipakai di sini — tombol
    // battle ber-depth default 0 dan akan ikut tergelapkan di sudut layar).
    this.add.text(W / 2 + 2, H * 0.045 + 3, (LOCATIONS[this.quest.location] || {}).name || 'Lokasi', { fontFamily: F_HEAD, fontSize: '14px', color: '#0b0b12' }).setOrigin(0.5);
    this.add.text(W / 2, H * 0.045, (LOCATIONS[this.quest.location] || {}).name || 'Lokasi', { fontFamily: F_HEAD, fontSize: '14px', color: '#ffffff', stroke: '#0b0b12', strokeThickness: 2 }).setOrigin(0.5);
    this.add.text(W / 2, H * 0.045 + 26, this.quest.count + ' ' + (monsterById(this.quest.monster) || {}).name + ' di sini', { fontFamily: F_PIX, fontSize: '11px', color: '#e2e8f0' }).setOrigin(0.5);

    // Sprite hero & musuh — kaki di garis tanah.
    const hv = heroVisual(this, Data.char.classKey, Data.char.customization, 4.6);
    this.heroSprite = this.add.sprite(W * 0.20, this.bg.groundY, hv.key, hv.frame || 0).setOrigin(0.5, 1).setScale(hv.scale).setDepth(10);
    try { this.heroSprite.play(hv.anim.idle); } catch (_) {}
    this.add.image(W * 0.20, this.bg.groundY + 5, 'fx_tex_shadow').setDisplaySize(96, 20).setAlpha(0.45).setDepth(9);
    // GEAR terlihat: senjata di tangan + jubah zirah + aksesori (turn-based).
    this.heroGear = createHeroGear(this, this.heroSprite, Data.char.classKey, Data.char.equipped || {}, { scale: 1.35, noWeapon: !!hv.lpc, depth: 10, handOffset: { x: hv.lpc ? 24 : (hv.v3 ? 22 : 18), y: hv.lpc ? -62 : (hv.v3 ? -54 : -44) } });
    // Pet menemani di battle (sheet sesuai pangkat evolusi).
    this.petComp = null;
    this.petCd = 1; // skill siap di giliran ke-2
    if (PetState.active && petTexExists(this, PetState.active, PetState.stage(PetState.active))) {
      this.petComp = spawnPetCompanion(this, PetState.active, {
        x: W * 0.13, y: this.bg.groundY + 6, depth: 10, scale: 1.9,
        follow: { get: () => ({ x: this.heroSprite.x - 92, y: this.bg.groundY + 6 }) },
      });
      const pass = petPassiveAt(PetState.activePet, PetState.activeLevel, PetState.stage(PetState.active));
      this.petAtk = Math.max(3, Math.round(((pass.atk || 4) + 3 + PetState.activeLevel * 0.8) * (PetState.stage(PetState.active) >= 2 ? 1.35 : 1)));
    }
    ensureMonsterAnims(this);
    this.enemySprites = this.enemies.map((e, i) => {
      const ex = W * 0.54 + (i % 3) * 118, row = Math.floor(i / 3);
      const ey = this.bg.groundY - row * 30;
      const def = MONSTER_ASSET[e.id];
      let sp;
      if (def && atlasHas(this, firstFrameName(def))) {
        sp = this.add.sprite(ex, ey, ATLAS_KEY, firstFrameName(def)).setOrigin(0.5, 1).setScale(def.s).setTint(def.tint);
        sp._feet = true;
      } else {
        sp = this.add.sprite(ex, ey - 24, monsterTexture(this, e)).setScale(monsterScale(this, e)).setOrigin(0.5, 0.6);
        sp._feet = false;
      }
      sp.setDepth(12 - row);
      playMonsterAnim(this, sp, e);
      this.add.image(ex, ey + 4, 'fx_tex_shadow').setDisplaySize(58, 16).setAlpha(0.55).setDepth(11 - row);
      if (e.defeated) sp.setVisible(false);
      if (def && def.fly) this.tweens.add({ targets: sp, y: ey - 14, duration: RF(900, 1300), yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
      return sp;
    });

    this.buildHud();
    this.buildControls();
    this.renderState();
    this.addLog(this.quest.title);
    this.addLog('Muncul ' + this.enemies.length + ' ' + this.enemies[0].name + '.');
    // v12 §6: INISIATIF — SPD tinggi memberi pukulan pembuka (taktik ringan).
    window.__kzBattleSpeed = 1;
    const avgLv = Math.round(this.enemies.reduce((s, e) => s + (e.level || 1), 0) / Math.max(1, this.enemies.length));
    if (stats.spd >= avgLv + 8 && this.enemies[0]) {
      const t0 = this.enemies[0];
      const dmg0 = Math.max(2, Math.round(stats.atk * 0.35));
      t0.hp -= dmg0;
      const sp0 = this.enemySprites[0];
      if (sp0) { this.slashFx(sp0.x, sp0.y - sp0.displayHeight * 0.5, 0xfde68a); floatText(this, sp0.x, sp0.y - sp0.displayHeight - 26, String(dmg0), '#fde68a', 15); }
      this.addLog('INISIATIF! Refleks cepatmu menyentil ' + t0.name + ' lebih dulu.');
      if (t0.hp <= 0) this.killEnemy(t0);
    }
  }

  buildHud() {
    // v9: HUD battle = aset (frame 9-slice + bar tileSprite).
    this.hudG = null;
    this.hudFrame = uiSlice(this, 14 + 160, 14 + 36, 320, 72, 'ui_hud', 0xffffff);
    this.hpBar = uiBar(this, 20 + 150, 46, 300, 12, 1, 0xef4444);
    this.mpBar = uiBar(this, 20 + 150, 64, 300, 8, 1, 0x3b82f6);
    this.shieldBar = uiFill(this, 20, 35, 300, 3, 0xfde68a, 0.9, 0).setVisible(false);
    // v12 §6: meter ULTIMATE (ungu) — terisi lewat aksi normal.
    if (this.ultBar == null) { this.ultBar = uiBar(this, 20 + 150, 80, 300, 5, 0, 0x9333ea); this.add.text(20, 80, 'ULT', { fontFamily: F_PIX, fontSize: '7.5px', color: '#c084fc' }).setOrigin(1, 0.5); }
    this.drawUltMeter();
    this.drawHud();
  }
  drawHud() {
    if (this.hpBar) this.hpBar.setFillRatio(this.p.hpMax ? clamp(this.p.hp / this.p.hpMax, 0, 1) : 0);
    if (this.mpBar) this.mpBar.setFillRatio(this.p.mpMax ? clamp(this.p.mp / this.p.mpMax, 0, 1) : 0);
    if (this.shieldBar) {
      this.shieldBar.setVisible(this.p.shield > 0);
      if (this.p.shield > 0) this.shieldBar.displayWidth = Math.max(1, 300 * clamp(this.p.shield / this.p.hpMax, 0, 1));
    }
  }
  buildControls() {
    const W = this.scale.width, H = this.scale.height;
    const y = H - 64;
    this.controls = [];
    const addBtn = (label, color, icon, cb) => this.controls.push(makeButton(this, 0, y, 150, 56, label, { color, size: 14, icon, onClick: cb }).setDepth(DEPTH.CONTROLS));
    addBtn('Serang', 0xdc2626, 'sword', () => this.playerAction('attack'));
    addBtn('Skill', 0x7c3aed, 'skill', () => this.toggleSubMenu('skill'));
    addBtn('ULT', 0x6d28d9, 'rage', () => this.castHeroUlt());
    addBtn('Bertahan', 0x475569, 'shield', () => this.playerAction('defend'));
    addBtn('Ramuan', 0x0ea5e9, 'potion', () => this.toggleSubMenu('poison'));
    addBtn('Kabur', 0x334155, 'exit', () => this.playerAction('flee'));
    // Spacing adaptif: 6 tombol SELALU muat dalam lebar layar (portrait juga).
    const nB = this.controls.length;
    const step = nB > 1 ? Math.min(158, (W - 30 - 150) / (nB - 1)) : 0;
    this.controls.forEach((b, i) => b.setPosition(W / 2 + (i - (nB - 1) / 2) * step, y));
    // Tombol ULT: redup sampai meter penuh.
    this.ultBtn = this.controls[2];
    if (this.ultBtn) this.ultBtn.setAlpha((this.ultCharge || 0) >= 100 ? 1 : 0.55);
    // v12 §9-D2: FFWD — percepatan battle bagi pemain yang ingin cepat.
    const ff = makeButton(this, W - 66, 40, 100, 34, 'FFWD x1', { color: 0x1f2937, size: 11, icon: 'arrow', onClick: () => {
      this._ffwd = !this._ffwd;
      window.__kzBattleSpeed = this._ffwd ? 2 : 1;
      try { this.tweens.timeScale = this._ffwd ? 1.6 : 1; } catch (_) {}
      ff.labelText.setText('FFWD x' + (this._ffwd ? 2 : 1));
    } }).setDepth(DEPTH.CONTROLS);
    ff.labelText.setFontSize(10);
  }
  /* v12 §6: pengisian + UI meter ULTIMATE. */
  chargeUlt(v) {
    this.ultCharge = clamp((this.ultCharge || 0) + v, 0, 100);
    if (this.ultCharge >= 100 && !this.ultReady) {
      this.ultReady = true;
      Sfx.ult();
      this.addLog('ULTIMATE siap — tombol ULT menyala!');
      if (this.ultBtn) { this.ultBtn.setAlpha(1); this.tweens.add({ targets: this.ultBtn, scale: { from: 1, to: 1.05 }, duration: 420, yoyo: true, repeat: -1 }); }
    }
    this.drawUltMeter();
  }
  drawUltMeter() { if (this.ultBar) this.ultBar.setFillRatio(clamp((this.ultCharge || 0) / 100, 0, 1)); }
  /* v12 §6: finisher class — dibuka meter penuh, dibungkus sinematik. */
  async castHeroUlt() {
    if (this.busy || this.over) return;
    if ((this.ultCharge || 0) < 100) { this.addLog('Ultimate belum terisi (' + Math.floor(this.ultCharge || 0) + '%).'); return; }
    this.busy = true;
    this.ultCharge = 0; this.ultReady = false;
    this.drawUltMeter();
    if (this.ultBtn) { this.ultBtn.setAlpha(0.55); this.tweens.killTweensOf(this.ultBtn); this.ultBtn.setScale(1); }
    const ult = HERO_ULTS[Data.char.classKey] || HERO_ULTS.warrior;
    const p = this.p;
    this.addLog(ult.name + '!');
    await cinematicUltimate(this, { color: toColorInt(ult.color, 0xf59e0b), name: ult.name });
    const enemies = this.aliveEnemies();
    const tSprite0 = enemies.length ? this.enemySprites[this.enemies.indexOf(enemies[0])] : null;
    await this.skillFx({ fx: { kind: ult.fx, color: ult.color } }, tSprite0);
    const heroEl = CLASS_ELEM[Data.char.classKey] || null;
    for (const t of this.aliveEnemies()) {
      const sp = this.enemySprites[this.enemies.indexOf(t)];
      const em = elemAdvantageInfo(heroEl, t.element);
      const dmg = Math.max(5, Math.round(p.atk * ult.power * em.mult * RF(0.95, 1.1)));
      t.hp -= dmg;
      if (sp) {
        floatText(this, sp.x, sp.y - sp.displayHeight - 40, String(dmg), em.adv === 'up' ? em.group.color : '#fde68a', 22);
        if (em.adv) elemAdvantageFlash(this, sp.x, sp.y - sp.displayHeight * 0.5, em);
        sp.setTintFill(0xffffff);
        this.time.delayedCall(140, () => { if (sp.active) { sp.clearTint(); const md = MONSTER_ASSET[t.id]; if (md && md.tint) sp.setTint(md.tint); } });
      }
      if (t.hp <= 0) this.killEnemy(t);
    }
    battleHitStop(this, 110);
    shake(this, 10); fxFlash(this, 0xffffff, 160, 0.28);
    Sfx.ult();
    if (this.aliveEnemies().length === 0) { this.endBattle(true); return; }
    await wait(300);
    await this.petTurn();
    if (this.aliveEnemies().length === 0) { this.endBattle(true); return; }
    await this.enemyTurn();
    this.renderState();
    this.busy = false;
  }
  toggleSubMenu(kind) {
    if (this.subMenu) { this.subMenu.forEach((o) => o.destroy()); this.subMenu = null; return; }
    this.subMenu = [];
    const W = this.scale.width, H = this.scale.height;
    if (kind === 'skill') {
      const tree = SKILL_TREES[Data.char.classKey] || [];
      const unlocked = tree.filter((s) => s.type === 'active' && SkillState.get(s.id) > 0);
      if (!unlocked.length) { this.addLog('Belum ada skill aktif — buka di Skill Tree.'); return; }
      // Spacing adaptif: 6 tombol x 172px akan luber di layar portrait —
      // step menyusut otomatis agar SELALU muat dalam lebar layar.
      const nS = Math.min(unlocked.length, 6);
      const stepS = nS > 1 ? Math.min(172, (W - 30 - 164) / (nS - 1)) : 0;
      unlocked.slice(0, 6).forEach((s, i) => {
        const lvl = SkillState.get(s.id);
        const eff = skillEffectScaled(s, lvl);
        const btn = makeButton(this, W / 2 + (i - (nS - 1) / 2) * stepS, H - 112, 164, 46, s.name, {
          color: 0x4c1d95, size: 10.5, icon: skillIconName(s), disabled: this.p.mp < (eff.mp || 0),
          onClick: () => { this.subMenu.forEach((o) => o.destroy()); this.subMenu = null; this.playerAction('skill', { def: s, level: lvl }); },
        });
        btn.add(this.add.text(0, -12, 'Lv' + lvl + '  ' + (eff.mp || 0) + ' MP', { fontFamily: F_UI, fontSize: '9px', color: '#c4b5fd' }).setOrigin(0.5));
        this.subMenu.push(btn);
      });
    } else {
      const inv = Data.char.inventory || {};
      const poisons = Object.keys(inv).filter((id) => poisonById(id)).slice(0, 6);
      if (!poisons.length) { this.addLog('Tidak punya ramuan.'); return; }
      const nP = poisons.length;
      const stepP = nP > 1 ? Math.min(150, (W - 30 - 142) / (nP - 1)) : 0;
      poisons.forEach((id, i) => {
        const pz = poisonById(id);
        const btn = makeButton(this, W / 2 + (i - (nP - 1) / 2) * stepP, H - 112, 142, 44, pz.name + ' x' + inv[id], {
          color: 0x0c4a6e, size: 10.5, icon: 'potion',
          onClick: () => { this.subMenu.forEach((o) => o.destroy()); this.subMenu = null; this.playerAction('poison', pz); },
        });
        this.subMenu.push(btn);
      });
    }
  }
  addLog(msg) { this.log.unshift(msg); this.log = this.log.slice(0, 4); }

  /* ---------- ANIMASI SERANGAN & SKILL ---------- */
  /* v12 §4: serangan dasar Mage = pose cast -> kilat charge -> bolt arkana
   * homing -> ledakan di target. TANPA melee/lunge sama sekali. Damage tetap
   * diproses caller (sinkron dengan momen ledakan bila charge penuh). */
  async animMageCast(targetSprite) {
    const hero = this.heroSprite;
    const hx = hero.x, hy = hero.y - hero.displayHeight * 0.5;
    const tx = targetSprite ? targetSprite.x : hx + 180;
    const ty = targetSprite ? targetSprite.y - targetSprite.displayHeight * 0.5 : hy;
    // Spell charge (v12): cast beruntun menumpuk glow; stack penuh = pukulan diperkuat.
    this.mageCharge = Math.min(3, (this.mageCharge || 0) + 1);
    const empowered = this.mageCharge >= 3;
    if (empowered) this.mageCharge = 0;
    this.drawMageCharge();
    try { hero.play(this.heroAnimKey('cast') || this.heroAnimKey('attack')); } catch (_) {}
    // Charge VFX: orb arkana tumbuh di ujung tongkat.
    const col = empowered ? 0xc084fc : 0x8b5cf6;
    const orb = this.add.image(hx + 34, hy - 8, this.textures.exists('fx_tex_glow') ? 'fx_tex_glow' : 'fx_tex_flash').setTint(col).setBlendMode(Phaser.BlendModes.ADD).setDepth(80).setScale(empowered ? 0.02 : 0.06);
    this.tweens.add({ targets: orb, scale: empowered ? 0.62 : 0.3, duration: empowered ? 360 : 240, ease: 'Quad.easeOut' });
    for (let i = 0; i < (empowered ? 6 : 3); i++) {
      const sp = this.add.image(hx + RF(-26, 26), hy + RF(-20, 20), this.textures.exists('fx_tex_sparkle') ? 'fx_tex_sparkle' : 'fx_tex_flash').setTint(col).setBlendMode(Phaser.BlendModes.ADD).setScale(0.1).setDepth(79);
      this.tweens.add({ targets: sp, x: orb.x, y: orb.y, scale: 0.02, duration: 220 + i * 50, onComplete: () => sp.destroy() });
    }
    await wait(empowered ? 380 : 250);
    if (!orb.active) return;
    orb.destroy();
    // Bolt arkana homing -> ledakan.
    await this.projectileFx(hx + 30, hy - 6, tx, ty, { color: col, size: empowered ? 20 : 12 });
    playVfx(this, 'vfx_arcane', tx, ty, { scale: empowered ? 1.6 : 1.0, fps: 16, tint: empowered ? 0xc084fc : undefined });
    fxRing(this, tx, ty, col, empowered ? 88 : 54, 340);
    fxSparks(this, tx, ty, col, empowered ? 22 : 10);
    shake(this, empowered ? 7 : 3);
    if (empowered) { fxFlash(this, 0xc084fc, 130, 0.22); this.addLog('MANTRA TERISI PENUH: ledakan diperkuat!'); }
  }
  /* Indikator spell charge: orb kecil mengorbit Mage sesuai stack. */
  drawMageCharge() {
    if (this._chargeOrbs) { this._chargeOrbs.forEach((o) => o.destroy()); this._chargeOrbs = null; }
    const n = this.mageCharge || 0;
    if (!n || Data.char.classKey !== 'mage') return;
    this._chargeOrbs = [];
    for (let i = 0; i < n; i++) {
      const o = this.add.image(this.heroSprite.x, this.heroSprite.y - this.heroSprite.displayHeight - 14, this.textures.exists('fx_tex_sparkle') ? 'fx_tex_sparkle' : 'fx_tex_flash').setTint(0xa78bfa).setBlendMode(Phaser.BlendModes.ADD).setScale(0.16).setDepth(82);
      this._chargeOrbs.push(o);
    }
    if (this._chargeOrbEv) this._chargeOrbEv.remove();
    this._chargeOrbEv = this.time.addEvent({ delay: 16, loop: true, callback: () => {
      if (!this._chargeOrbs || !this.heroSprite.active) return;
      const t = this.time.now * 0.004;
      this._chargeOrbs.forEach((o, i) => {
        const a = t + (i * Math.PI * 2) / Math.max(1, this._chargeOrbs.length);
        o.setPosition(this.heroSprite.x + Math.cos(a) * 34, this.heroSprite.y - this.heroSprite.displayHeight * 0.62 + Math.sin(a) * 12).setAlpha(0.75 + Math.sin(t * 3 + i) * 0.2);
      });
    } });
  }
  animMelee(targetSprite) {
    const hero = this.heroSprite;
    const tx = targetSprite.x - 70;
    this.tweens.add({ targets: hero, x: tx, duration: 160, ease: 'Quad.easeIn', onComplete: () => {
      try { hero.play(this.heroAnimKey('attack')); } catch (_) {}
      this.slashFx(targetSprite.x - 20, targetSprite.y - targetSprite.displayHeight * 0.55, 0xfca5a5);
      this.tweens.add({ targets: hero, x: W0(this) * 0.20, duration: 240, delay: 130, ease: 'Quad.easeOut', onComplete: () => { try { hero.play(this.heroAnimKey('idle')); } catch (_) {} } });
    } });
  }
  heroAnimKey(kind) {
    const a = heroAtlasAnims(this, Data.char.classKey);
    return a ? a[kind] : null;
  }
  slashFx(x, y, color = 0xffffff) {
    if (this.textures.exists('fx_tex_slash')) {
      const sl = this.add.image(x, y, 'fx_tex_slash').setDepth(60).setTint(color).setBlendMode(Phaser.BlendModes.ADD);
      sl.setScale(0.2); sl.setAngle(-18);
      this.tweens.add({ targets: sl, scale: 0.95, angle: 12, alpha: 0, duration: 220, ease: 'Quad.easeOut', onComplete: () => sl.destroy() });
      fxSparks(this, x, y, color, 12);
      return;
    }
    // v9: fallback = aset glow (tanpa canvas).
    const sl = this.add.image(x, y, this.textures.exists('fx_tex_glow') ? 'fx_tex_glow' : 'fx_tex_flash').setDepth(60).setTint(color).setBlendMode(Phaser.BlendModes.ADD).setScale(0.2).setAngle(-18);
    this.tweens.add({ targets: sl, scale: 0.95, angle: 12, alpha: 0, duration: 220, ease: 'Quad.easeOut', onComplete: () => sl.destroy() });
    fxSparks(this, x, y, color, 12);
  }
  projectileFx(fromX, fromY, toX, toY, { color = 0xffffff, size = 8, trail = true, arc = 0 } = {}) {
    return new Promise((resolve) => {
      const p = this.add.image(fromX, fromY, this.textures.exists('fx_tex_glow') ? 'fx_tex_glow' : 'fx_tex_flash').setTint(color).setBlendMode(Phaser.BlendModes.ADD).setDepth(70).setScale(size / 40);
      if (arc > 0) {
        this.tweens.add({ targets: p, x: toX, duration: 340, ease: 'Quad.easeIn' });
        this.tweens.add({ targets: p, y: toY, duration: 340, ease: 'Sine.easeOut', onComplete: () => { p.destroy(); resolve(); } });
      } else {
        this.tweens.add({ targets: p, x: toX, y: toY, duration: 300, ease: 'Quad.easeIn', onComplete: () => { p.destroy(); resolve(); } });
      }
      if (trail) {
        const interval = setInterval(() => { if (!p.active) { clearInterval(interval); return; } const t = this.add.image(p.x, p.y, this.textures.exists('fx_tex_glow') ? 'fx_tex_glow' : 'fx_tex_flash').setTint(color).setAlpha(0.5).setDepth(69).setBlendMode(Phaser.BlendModes.ADD).setScale(size / 90); this.tweens.add({ targets: t, alpha: 0, scale: 0.2, duration: 200, onComplete: () => t.destroy() }); }, 30);
        setTimeout(() => clearInterval(interval), 400);
      }
    });
  }
  async skillFx(def, targetSprite) {
    const color = toColorInt((def.fx && def.fx.color) || '#ffffff', 0xffffff);
    const kind = (def.fx && def.fx.kind) || 'slash';
    const hero = this.heroSprite;
    const hx = hero.x, hy = hero.y - hero.displayHeight * 0.5;
    const tx = targetSprite ? targetSprite.x : hx, ty = targetSprite ? targetSprite.y - targetSprite.displayHeight * 0.5 : hy;
    switch (kind) {
      case 'slash': case 'cleave': {
        // v11: slash aset internet (6 frame) + slashFx klasik sebagai lapisan.
        playVfx(this, 'vfx_slash', tx, ty - 8, { scale: 1.15, tint: color, fps: 18, angle: RF(-0.5, 0.5) });
        this.slashFx(tx - 16, ty, color); this.slashFx(tx + 18, ty - 20, color);
        shake(this, 4); break;
      }
      case 'spin': {
        this.tweens.add({ targets: hero, angle: 360, duration: 380, onComplete: () => hero.setAngle(0) });
        this.enemies.forEach((e, i) => { if (!e.defeated) { const sp = this.enemySprites[i]; if (sp) { this.slashFx(sp.x, sp.y - sp.displayHeight * 0.5, color); playVfx(this, 'vfx_slash', sp.x, sp.y - sp.displayHeight * 0.5, { scale: 1.0, tint: color, fps: 18 }); } } });
        shake(this, 6); break;
      }
      case 'dash': {
        const ox = hero.x;
        this.tweens.add({ targets: hero, x: tx - 40, duration: 140, yoyo: true, ease: 'Quad.easeIn', onComplete: () => { hero.x = ox; } });
        playVfx(this, 'vfx_slash', tx, ty - 6, { scale: 1.1, tint: color, fps: 18 });
        this.slashFx(tx, ty, color); break;
      }
      case 'flurry': {
        for (let i = 0; i < 4; i++) setTimeout(() => { this.slashFx(tx + RF(-24, 24), ty + RF(-20, 20), color); playVfx(this, 'vfx_slash', tx + RF(-24, 24), ty + RF(-16, 16), { scale: 0.8, tint: color, fps: 20 }); }, i * 110);
        break;
      }
      case 'execute': {
        fxFlash(this, color, 160, 0.35); shake(this, 8);
        playVfx(this, 'vfx_slash', tx, ty - 8, { scale: 1.5, fps: 18 });
        this.slashFx(tx, ty, 0xffffff); this.slashFx(tx, ty, color); break;
      }
      case 'fireball': case 'void': {
        await this.projectileFx(hx, hy, tx, ty, { color, size: 14 });
        // v11: ledakan api/arcane animasi aset (8 frame) di titik jatuh.
        playVfx(this, kind === 'void' ? 'vfx_arcane' : 'vfx_fire', tx, ty, { scale: 1.25, tint: kind === 'void' ? color : undefined, fps: 16 });
        fxRing(this, tx, ty, color, 60, 320); fxSparks(this, tx, ty, color, 20); shake(this, 5);
        break;
      }
      case 'meteor': {
        // Meteor jatuh dari atas.
        const rock = this.textures.exists('asset_deco_rock2')
          ? this.add.image(W0(this) * 0.62, -40, 'asset_deco_rock2').setDepth(70).setScale(1.25).setAngle(24)
          : this.add.image(W0(this) * 0.62, -40, 'fx_tex_flash').setTint(color).setDisplaySize(32, 32).setDepth(70).setBlendMode(Phaser.BlendModes.ADD);
        if (this.textures.exists('fx_tex_glow')) {
          const rk = this.add.image(rock.x, rock.y, 'fx_tex_glow').setTint(color).setAlpha(0.7).setScale(0.6).setBlendMode(Phaser.BlendModes.ADD).setDepth(69);
          this.tweens.add({ targets: rk, x: tx, y: ty, duration: 420, ease: 'Quad.easeIn', onComplete: () => rk.destroy() });
        }
        await new Promise((res) => this.tweens.add({ targets: rock, x: tx, y: ty, duration: 420, ease: 'Quad.easeIn', onComplete: () => { rock.destroy(); res(); } }));
        playVfx(this, 'vfx_fire', tx, ty, { scale: 1.7, fps: 14 });
        fxRing(this, tx, ty, color, 90, 400); fxSparks(this, tx, ty, color, 30); fxFlash(this, color, 180, 0.3); shake(this, 10);
        break;
      }
      case 'frost': {
        this.enemies.forEach((e, i) => { if (!e.defeated) { const sp = this.enemySprites[i]; if (sp) { fxRing(this, sp.x, sp.y - sp.displayHeight * 0.5, 0x7dd3fc, 46, 300); playVfx(this, 'vfx_ice', sp.x, sp.y - sp.displayHeight * 0.5, { scale: 0.85, fps: 15, tint: 0xbfe8ff }); } } });
        break;
      }
      case 'arrow': case 'snipe': {
        try { hero.play(this.heroAnimKey('attack')); } catch (_) {}
        await this.projectileFx(hx, hy, tx, ty, { color: 0xe8e0c8, size: kind === 'snipe' ? 7 : 5, arc: 0 });
        playVfx(this, 'vfx_lpc_effects', tx, ty, { scale: kind === 'snipe' ? 0.8 : 0.5, fps: 14, tint: color });
        fxSparks(this, tx, ty, color, 10);
        if (kind === 'snipe') { fxFlash(this, 0xffffff, 90, 0.2); shake(this, 5); }
        break;
      }
      case 'arrowrain': {
        for (let i = 0; i < 8; i++) {
          const sx = tx + RF(-90, 90);
          this.projectileFx(sx, ty - 260, sx + RF(-16, 16), ty, { color: 0xfbbf24, size: 4, trail: false });
        }
        await new Promise((res) => setTimeout(res, 380));
        this.enemies.forEach((e, i) => { if (!e.defeated) { const sp = this.enemySprites[i]; if (sp) { fxSparks(this, sp.x, sp.y - sp.displayHeight * 0.5, color, 12); playVfx(this, 'vfx_lpc_effects', sp.x, sp.y - sp.displayHeight * 0.5, { scale: 0.6, fps: 14, tint: color }); } } });
        shake(this, 6);
        break;
      }
      case 'heal': case 'bloom': {
        playVfx(this, 'vfx_lpc_effects', hx, hy - 20, { scale: 0.9, fps: 12, tint: color });
        const ring = this.add.image(hx, hy, 'fx_tex_ring').setTint(color).setAlpha(0.25).setBlendMode(Phaser.BlendModes.ADD).setDepth(60).setScale(40 / 256);
        this.tweens.add({ targets: ring, scale: 140 / 256, alpha: 0, duration: 500, onComplete: () => ring.destroy() });
        ensurePixelTex(this);
        const parts = this.add.particles(hx, hy, 'fxpix', { speed: { min: 30, max: 90 }, angle: { min: 200, max: 340 }, scale: { start: 1.2, end: 0 }, lifespan: 600, tint: color, blendMode: 'ADD', emitting: false }).setDepth(60);
        parts.explode(16);
        this.time.delayedCall(700, () => parts.destroy());
        break;
      }
      case 'shield': case 'manashield': {
        playVfx(this, kind === 'manashield' ? 'vfx_arcane' : 'vfx_iceshield', hx, hy - 24, { scale: 0.85, fps: 12, tint: color });
        const sh = this.add.image(hx, hy, 'fx_tex_ring').setTint(color).setAlpha(0.32).setBlendMode(Phaser.BlendModes.ADD).setDepth(60).setScale(48 / 256);
        this.tweens.add({ targets: sh, scale: { from: 30 / 256, to: 52 / 256 }, alpha: { from: 0.2, to: 0.5 }, duration: 300, yoyo: true, onComplete: () => sh.destroy() });
        break;
      }
      case 'rage': case 'banner': {
        playVfx(this, 'vfx_aura_fire', hx, hy - 30, { scale: 0.8, fps: 16, tint: color });
        fxRing(this, hx, hy, color, 80, 420);
        hero.setTint(color);
        this.time.delayedCall(500, () => hero.clearTint());
        break;
      }
      case 'poison': {
        await this.projectileFx(hx, hy, tx, ty, { color: 0x84cc16, size: 8 });
        playVfx(this, 'vfx_snake', tx, ty - 6, { scale: 1.0, fps: 14, tint: 0xa3e635 });
        fxSparks(this, tx, ty, 0x84cc16, 14);
        break;
      }
      case 'smoke': {
        const smoke = this.add.image(hx, hy + 20, this.textures.exists('fx_tex_smoke') ? 'fx_tex_smoke' : 'fx_tex_flash').setTint(0x64748b).setAlpha(0.5).setDepth(60).setScale(0.16);
        this.tweens.add({ targets: smoke, scale: 1.1, alpha: 0, duration: 600, onComplete: () => smoke.destroy() });
        break;
      }
      case 'mark': {
        if (targetSprite) {
          playVfx(this, 'vfx_circle', targetSprite.x, targetSprite.y - 10, { scale: 0.55, fps: 10, tint: 0xf43f5e });
          const mk = this.add.text(targetSprite.x, targetSprite.y - targetSprite.displayHeight - 26, 'TARGET', { fontFamily: F_HEAD, fontSize: '8px', color: '#f43f5e', stroke: '#0b0b12', strokeThickness: 2 }).setOrigin(0.5).setDepth(60);
          this.tweens.add({ targets: mk, alpha: { from: 1, to: 0.3 }, duration: 300, yoyo: true, repeat: 3, onComplete: () => mk.destroy() });
        }
        break;
      }
      default: this.slashFx(tx, ty, color);
    }
    Sfx.skill();
  }
  renderState() {
    const W = this.scale.width, H = this.scale.height;
    if (this.statusText) this.statusText.destroy();
    const p = this.p;
    const buffs = [];
    if (p.buffTurns > 0) buffs.push('ATK +' + Math.round(p.buffPct * 100) + '% (' + p.buffTurns + ')');
    if (p.regenTurns > 0) buffs.push('Regen ' + p.regen + '/g (' + p.regenTurns + ')');
    if (p.manaRegenTurns > 0) buffs.push('MP +' + p.manaRegen + '/g (' + p.manaRegenTurns + ')');
    if (p.shield > 0) buffs.push('Perisai ' + Math.round(p.shield));
    if (p.evasionTurns > 0) buffs.push('Hindar ' + Math.round(p.evasionPct) + '% (' + p.evasionTurns + ')');
    if (this.combo >= 2) buffs.push('Combo x' + this.combo);
    const hpTxt = 'HP ' + Math.max(0, Math.round(p.hp)) + '/' + p.hpMax;
    const mpTxt = 'MP ' + Math.max(0, Math.round(p.mp)) + '/' + p.mpMax;
    this.statusText = this.add.text(16, 92, hpTxt + '    ' + mpTxt + (buffs.length ? '    ' + buffs.join('  ') : ''), { fontFamily: F_UI, fontSize: '13px', color: '#f8fafc', fontStyle: 'bold' });
    if (this.logText) this.logText.destroy();
    this.logText = this.add.text(W / 2, H - 128, this.log.map((l) => '> ' + l).join('\n'), { fontFamily: F_UI, fontSize: '12.5px', color: '#f1f5f9', align: 'center', backgroundColor: 'rgba(10,15,28,0.55)' }).setOrigin(0.5);
    this.drawHud();
    this.drawEnemyBars();
  }
  drawEnemyBars() {
    if (this.enemyBars) this.enemyBars.forEach((b) => b.destroy());
    this.enemyBars = [];
    this.enemies.forEach((e, i) => {
      if (e.defeated) return;
      const sp = this.enemySprites[i];
      if (!sp || !sp.visible) return;
      const bw = 46, bh = 6;
      const bx = sp.x - bw / 2, by = sp.y - sp.displayHeight - 16;
      // v9: bar musuh dari aset putih (tint) — nol canvas.
      const c = this.add.container(0, 0).setDepth(20);
      c.add(uiFill(this, bx - 1, by - 1, bw + 2, bh + 2, 0x0b0b12, 0.9, 0));
      c.add(uiFill(this, bx, by, bw, bh, 0x334155, 1, 0));
      const pct = Math.max(0, e.hp / e.hpMax);
      c.add(uiFill(this, bx, by, Math.max(1, bw * pct), bh, pct > 0.5 ? 0x4ade80 : pct > 0.25 ? 0xfacc15 : 0xef4444, 1, 0));
      if (e.markTurns > 0) c.add(this.add.image(bx + bw + 6, by + 3, 'fx_tex_flash').setTint(0xf43f5e).setDisplaySize(6, 6));
      this.enemyBars.push(c);
    });
  }
  aliveEnemies() { return this.enemies.filter((e) => !e.defeated); }

  damage(baseAtk, def, critChance) {
    const crit = Math.random() * 100 < (critChance || 5);
    let dmg = Math.max(1, Math.round(baseAtk * RF(0.9, 1.1) - def * 0.45));
    if (crit) dmg = Math.round(dmg * (1.6 + (this.eff.critDmg || 0)));
    return { dmg, crit };
  }

  async playerAction(action, arg) {
    if (this.busy || this.over) return;
    this.busy = true;
    const p = this.p;
    const enemies = this.aliveEnemies();
    const target = enemies[0];
    const tIdx = target ? this.enemies.indexOf(target) : -1;
    const tSprite = tIdx >= 0 ? this.enemySprites[tIdx] : null;

    try {
      if (action === 'attack') {
        if (!target) { this.endBattle(true); return; }
        const cleave = this.eff.cleave || 0;
        const exec = this.eff.execute || 0;
        const poisonEff = this.eff.poison || 0;
        const hitTargets = cleave ? enemies : [target];
        const heroEl = CLASS_ELEM[Data.char.classKey] || null;
        // v12: Mage TIDAK MELEE — pose cast + proyektil sihir (lihat animMageCast).
        if (Data.char.classKey === 'mage') await this.animMageCast(tSprite);
        else this.animMelee(tSprite);
        await wait(180);
        for (const t of hitTargets) {
          let { dmg, crit } = this.damage(p.atk, t.def, p.crit);
          if (exec && t.hp < t.hpMax * 0.3) dmg = Math.round(dmg * (1 + exec));
          if (cleave && t !== target) dmg = Math.round(dmg * cleave);
          const hem = elemAdvantageInfo(heroEl, t.element);
          dmg = Math.max(1, Math.round(dmg * hem.mult));
          t.hp -= dmg;
          this.combo++;
          const sp = this.enemySprites[this.enemies.indexOf(t)];
          if (sp) {
            floatText(this, sp.x, sp.y - sp.displayHeight - 26, String(dmg), crit ? '#fbbf24' : (hem.adv === 'up' ? hem.group.color : '#ffffff'), crit ? 22 : 17);
            if (hem.adv) elemAdvantageFlash(this, sp.x, sp.y - sp.displayHeight * 0.5, hem);
            sp.setTintFill(0xffffff);
            this.time.delayedCall(110, () => { if (sp.active) { const def = MONSTER_ASSET[t.id]; sp.clearTint(); if (def && def.tint) sp.setTint(def.tint); } });
          }
          this.addLog('Kamu menyerang ' + t.name + ': ' + dmg + ' damage.');
          if (crit && sp) { floatText(this, sp.x, sp.y - 60, 'CRIT', '#fbbf24', 22); battleHitStop(this, 60); }
          if (poisonEff && !t.dotTurns) { t.dot = Math.round(p.atk * poisonEff); t.dotTurns = 3; }
          if (this.eff.lifesteal) {
            const heal = Math.max(1, Math.round(dmg * this.eff.lifesteal));
            p.hp = Math.min(p.hpMax, p.hp + heal);
          }
          if (t.hp <= 0) this.killEnemy(t);
        }
        this.chargeUlt(9);
        Sfx.hit();
      } else if (action === 'skill') {
        const def = arg.def, lvl = arg.level || SkillState.get(def.id);
        const eff = skillEffectScaled(def, lvl);
        if (p.mp < (eff.mp || 0)) { this.addLog('MP kurang untuk ' + def.name + '.'); this.busy = false; return; }
        p.mp -= eff.mp || 0;
        this.addLog(def.name + '!');
        const heroEl = CLASS_ELEM[Data.char.classKey] || null;
        const skillEl = (def.fx && def.fx.elem) || heroEl;
        // v12: Mage selalu cast (spell) — skillFx sudah berbasis proyektil/AoE.
        await this.skillFx(def, tSprite);
        if (eff.dmg) {
          const hits = eff.hits || 1;
          const targets = eff.aoe ? enemies : (target ? [target] : []);
          for (const t of targets) {
            const sp = this.enemySprites[this.enemies.indexOf(t)];
            const sem = elemAdvantageInfo(skillEl, t.element);
            let total = 0, anyCrit = false;
            for (let h = 0; h < hits; h++) {
              const defEff = eff.pierce ? t.def * (1 - eff.pierce) : t.def;
              const amp = t.markTurns > 0 ? (1 + (t.markAmp || 0)) : 1;
              let { dmg, crit } = this.damage(p.atk * eff.dmg * amp, defEff, p.crit + (eff.critBonus ? eff.critBonus * 100 : 0));
              if (eff.execute && t.hp / t.hpMax < eff.execute) dmg = Math.round(dmg * 1.8);
              dmg = Math.max(1, Math.round(dmg * sem.mult));
              t.hp -= dmg; total += dmg; if (crit) anyCrit = true;
              if (t.hp <= 0) break;
            }
            if (sp) {
              floatText(this, sp.x, sp.y - sp.displayHeight - 26, String(total), anyCrit ? '#fbbf24' : (sem.adv === 'up' ? sem.group.color : hex(toColorInt((def.fx && def.fx.color) || '#ffffff', 0xffffff))), anyCrit ? 24 : 19);
              if (sem.adv) elemAdvantageFlash(this, sp.x, sp.y - sp.displayHeight * 0.5, sem);
            }
            this.addLog(t.name + ' terkena ' + total + ' damage.');
            if (t.hp <= 0) this.killEnemy(t);
          }
        }
        // v12: RESONANSI ELEMEN — skill hero se-grup dengan elemen pet aktif
        // menghasilkan bonus damage + FX cincin ganda (menghargai team-building).
        if (this.petComp && this.petComp.pet && skillEl && this.petComp.pet.element && ELEM_GROUP[skillEl] && ELEM_GROUP[skillEl] === ELEM_GROUP[this.petComp.pet.element]) {
          const bonus = Math.max(2, Math.round(p.atk * 0.18));
          if (target && !target.defeated) {
            target.hp -= bonus;
            if (tSprite) { floatText(this, tSprite.x + 30, tSprite.y - tSprite.displayHeight - 6, '+' + bonus, '#fde68a', 15); elemAdvantageFlash(this, tSprite.x, tSprite.y - tSprite.displayHeight * 0.4, { adv: 'up', group: ELEM_GROUP_INFO[ELEM_GROUP[skillEl]] }); }
            if (target.hp <= 0) this.killEnemy(target);
          }
          fxRing(this, this.heroSprite.x, this.heroSprite.y - 40, 0xfde68a, 92, 520);
          if (this.petComp.container) fxRing(this, this.petComp.container.x, this.petComp.container.y - 28, 0xfde68a, 54, 440);
          this.addLog('RESONANSI ELEMEN: ' + this.petComp.pet.name + ' menguatkan ' + def.name + '!');
        }
        if (eff.dot && target) { target.dot = Math.round(p.atk * eff.dot); target.dotTurns = eff.turns || 3; this.addLog(target.name + ' teracuni.'); }
        if (eff.heal) { const heal = Math.round(p.atk * eff.heal); p.hp = Math.min(p.hpMax, p.hp + heal); this.addLog('Pulih ' + heal + ' HP.'); }
        if (eff.healAoe) { const heal = Math.round(p.atk * eff.healAoe); p.hp = Math.min(p.hpMax, p.hp + heal); this.addLog('Tim dipulihkan ' + heal + ' HP.'); }
        if (eff.shield) { const sh = Math.round(p.hpMax * eff.shield); p.shield += sh; this.addLog('Perisai +' + sh + '.'); }
        if (eff.atkBuff) { p.buffPct = eff.atkBuff; p.buffTurns = (eff.turns || 3) + 1; this.addLog('ATK +' + Math.round(eff.atkBuff * 100) + '% (' + (eff.turns || 3) + ' giliran).'); }
        if (eff.evasion) { p.evasionPct = eff.evasion * 100; p.evasionTurns = (eff.turns || 2) + 1; }
        if (eff.mark && target) { target.markAmp = eff.mark; target.markTurns = (eff.turns || 3) + 1; this.addLog(target.name + ' bertanda pemburu.'); }
        this.chargeUlt(16);
      } else if (action === 'defend') {
        p.defending = true;
        const regen = Math.round(p.mpMax * 0.15);
        p.mp = Math.min(p.mpMax, p.mp + regen);
        this.chargeUlt(6);
        this.addLog('Bertahan. MP +' + regen + '.');
      } else if (action === 'poison') {
        const pz = arg;
        const r = await Data.useItem(pz.id);
        if (!r.ok) { this.addLog(r.error || 'Gagal memakai ramuan.'); this.busy = false; return; }
        const ef = r.effect || pz;
        const hb = 1 + (this.eff.healBoost || 0);
        if (ef.kind === 'heal') { const v = Math.round((ef.val || 0) * hb); p.hp = Math.min(p.hpMax, p.hp + v); this.addLog('Meminum ' + pz.name + ': +' + v + ' HP.'); }
        else if (ef.kind === 'elixir') { p.hp = p.hpMax; p.mp = p.mpMax; this.addLog('Elixir! HP & MP penuh.'); }
        else if (ef.kind === 'mana') { p.mp = Math.min(p.mpMax, p.mp + (ef.val || 0)); this.addLog('MP +' + ef.val + '.'); }
        else if (ef.kind === 'strength' || ef.kind === 'berserk') { p.buffPct = Math.max(p.buffPct, ef.val); p.buffTurns = (ef.turns || 2) + 1; this.addLog('ATK naik.'); }
        else if (ef.kind === 'swift') { p.evasionPct = Math.max(p.evasionPct, ef.val * 100); p.evasionTurns = (ef.turns || 3) + 1; this.addLog('Hindar naik.'); }
        else if (ef.kind === 'regen') { p.regen = Math.max(p.regen, ef.val); p.regenTurns = (ef.turns || 4) + 1; }
        else if (ef.kind === 'manaRegen') { p.manaRegen = Math.max(p.manaRegen, ef.val); p.manaRegenTurns = (ef.turns || 4) + 1; }
        else if (ef.kind === 'shield') { const sh = Math.round(p.hpMax * ef.val); p.shield += sh; this.addLog('Perisai +' + sh + '.'); }
        else if (ef.kind === 'poison' || ef.kind === 'venom') { if (target) { target.dot = Math.max(target.dot || 0, ef.val); target.dotTurns = Math.max(target.dotTurns || 0, ef.turns || 3); this.addLog(target.name + ' teracuni.'); } }
        else if (ef.kind === 'weaken') { if (target) { target.weakenMul = 1 - ef.val; target.weakenTurns = (ef.turns || 3) + 1; this.addLog(target.name + ' melemah.'); } }
        else if (ef.kind === 'paralyze') { if (target) { target.paralyzeTurns = Math.max(target.paralyzeTurns || 0, ef.turns || 2); this.addLog(target.name + ' lumpuh.'); } }
        Sfx.potion();
      } else if (action === 'flee') {
        const chance = Math.min(0.85, 0.4 + (p.spd - 10) * 0.02);
        if (Math.random() < chance) { this.addLog('Kabur berhasil.'); this.endBattle(null, true); return; }
        this.addLog('Gagal kabur.');
      }
    } catch (e) { console.error(e); }

    if (this.aliveEnemies().length === 0) { this.endBattle(true); return; }
    await wait(260);
    await this.petTurn();
    if (this.aliveEnemies().length === 0) { this.endBattle(true); return; }
    await this.enemyTurn();
    this.renderState();
    this.busy = false;
  }

  /* v12: pengiriman serangan pet sesuai attackType (data-driven).
   * melee = terjangan + tebasan; ranged = lemparan fisik tanpa glow;
   * magic = orb homing + ledakan elemen; support = perawatan ally. */
  petDeliverAttack(pet, target, tSprite, dmg, onHit) {
    const px = this.petComp ? this.petComp.container.x : this.heroSprite.x;
    const py = this.petComp ? this.petComp.container.y : this.heroSprite.y;
    const type = (pet && pet.attackType) || 'magic';
    const finish = () => {
      if (!target || target.defeated) { if (onHit) onHit(); return; }
      const em = elemAdvantageInfo(pet.element, target.element);
      const final = Math.max(1, Math.round(dmg * em.mult));
      target.hp -= final;
      const sp = tSprite;
      if (sp) {
        floatText(this, sp.x, sp.y - sp.displayHeight - 40, String(final), em.adv === 'up' ? em.group.color : pet.color, em.adv ? 16 : 13);
        if (em.adv) elemAdvantageFlash(this, sp.x, sp.y - sp.displayHeight * 0.5, em);
        sp.setTintFill(0xffffff);
        this.time.delayedCall(90, () => { if (sp.active) { sp.clearTint(); const md = MONSTER_ASSET[target.id]; if (md && md.tint) sp.setTint(md.tint); } });
      }
      this.addLog(pet.name + ' menyerang: ' + final + ' damage' + (em.adv === 'up' ? ' (elemen unggul)' : em.adv === 'down' ? ' (elemen lemah)' : '') + '.');
      if (target.hp <= 0) this.killEnemy(target);
      this.renderState();
      if (onHit) onHit();
    };
    if (type === 'melee' && tSprite) {
      const cc = this.petComp.container;
      const ox = cc.x, oy = cc.y;
      const dir = Math.sign(tSprite.x - ox) || 1;
      this.petComp.setFlip(dir < 0);
      this.tweens.add({ targets: cc, x: tSprite.x - dir * 56, y: tSprite.y, duration: 180, ease: 'Quad.easeIn', onComplete: () => {
        this.slashFx(tSprite.x - 14, tSprite.y - tSprite.displayHeight * 0.55, Phaser.Display.Color.HexStringToColor(pet.color).color);
        shake(this, 3);
        finish();
        this.tweens.add({ targets: cc, x: ox, y: oy, duration: 280, ease: 'Quad.easeOut' });
      } });
    } else if (type === 'ranged' && tSprite) {
      const col = Phaser.Display.Color.HexStringToColor(pet.color).color;
      const rock = this.add.image(px, py - 16, this.textures.exists('asset_deco_rock1') ? 'asset_deco_rock1' : 'fx_tex_flash').setDepth(80).setScale(0.28).setTint(col);
      const dist = Math.hypot(tSprite.x - px, tSprite.y - py);
      this.tweens.add({ targets: rock, x: tSprite.x, y: tSprite.y - tSprite.displayHeight * 0.5, duration: Math.max(200, Math.min(420, dist)), ease: 'Quad.easeIn',
        onUpdate: () => rock.setRotation(rock.rotation + 0.55),
        onComplete: () => { rock.destroy(); fxSparks(this, tSprite.x, tSprite.y - tSprite.displayHeight * 0.5, col, 8); finish(); } });
    } else if (type === 'support') {
      const p = this.p;
      if (p.hp < p.hpMax * 0.92) {
        const heal = Math.max(3, Math.round(dmg * 0.9));
        p.hp = Math.min(p.hpMax, p.hp + heal);
        playVfx(this, PET_ELEMENT_VFX[pet.element] || 'vfx_lpc_effects', this.heroSprite.x, this.heroSprite.y - 50, { scale: 0.8, fps: 12 });
        fxRing(this, this.heroSprite.x, this.heroSprite.y - 50, 0x86efac, 60, 420);
        floatText(this, this.heroSprite.x, this.heroSprite.y - 90, '+' + heal, '#86efac', 14);
        this.addLog(pet.name + ' merawat lukamu: +' + heal + ' HP.');
        this.renderState();
        if (onHit) onHit();
      } else if (tSprite) {
        fxPetProjectile(this, px, py, tSprite.x, tSprite.y, pet.element, finish, 0.7);
      } else if (onHit) onHit();
    } else if (tSprite) {
      fxPetProjectile(this, px, py, tSprite.x, tSprite.y, pet.element, finish);
    } else if (onHit) onHit();
  }
  // v11: giliran pet — 2 skill bergantian + ULTIMATE (evolusi terakhir, isi 4 giliran)
  // + proyektil sinkron: damage jatuh tepat saat ledakan menyentuh musuh.
  async petTurn() {
    const p = this.p;
    if (!this.petComp || this.petComp.dead || !this.petComp.pet) return;
    const pet = this.petComp.pet;
    const lv = PetState.activeLevel || 1;
    const scale = petSkillScale(lv);
    const enemies = this.aliveEnemies();
    const target = enemies[0];
    const tSprite = target ? this.enemySprites[this.enemies.indexOf(target)] : null;
    const px = this.petComp.container.x, py = this.petComp.container.y;
    const stage = (PetState.stage ? PetState.stage(PetState.active) : 1) || 1;
    const evo = PET_EVOLUTION[pet.id];
    if (this.petUltCharge == null) this.petUltCharge = 0;
    if (this.petSkillIdx == null) this.petSkillIdx = 0;
    this.petUltCharge++;
    // ---- ULTIMATE: hanya stage 2 (evolusi terakhir), terisi 4 giliran ----
    if (stage >= 2 && evo && evo.ultimate && this.petUltCharge >= 4 && enemies.length) {
      this.petUltCharge = 0;
      const ult = evo.ultimate;
      this.petComp.attack();
      Sfx.ult();
      this.addLog('★ ' + pet.name + ' melepaskan ' + ult.name + '!');
      const applyUlt = () => {
        const base = (this.petAtk || 5) * ult.power * scale;
        if (ult.target === 'enemy' || ult.target === 'enemies') {
          const tgts = ult.target === 'enemies' ? enemies : (target ? [target] : []);
          for (const t of tgts) {
            const sp = this.enemySprites[this.enemies.indexOf(t)];
            const em = elemAdvantageInfo(pet.element, t.element);
            const dmg = Math.max(5, Math.round(base * RF(0.95, 1.1) * em.mult));
            t.hp -= dmg;
            if (sp) { floatText(this, sp.x, sp.y - sp.displayHeight - 46, String(dmg), em.adv === 'up' ? em.group.color : pet.color, 21); if (em.adv) elemAdvantageFlash(this, sp.x, sp.y - sp.displayHeight * 0.5, em); playVfx(this, PET_ELEMENT_VFX[pet.element] || 'vfx_fire', sp.x, sp.y - 26, { scale: 1.15, fps: 16 }); }
            this.applyPetEffect(t, ult.effect, base);
            if (t.hp <= 0) this.killEnemy(t);
          }
          if (ult.effect === 'lifesteal' && target) {
            const heal = Math.max(2, Math.round(base * 0.6));
            p.hp = Math.min(p.hpMax, p.hp + heal);
            floatText(this, this.heroSprite.x, this.heroSprite.y - 90, '+' + heal, '#86efac', 15);
          }
          if (ult.effect === 'radiant') {
            const heal = Math.max(2, Math.round(p.hpMax * 0.08 * scale));
            p.hp = Math.min(p.hpMax, p.hp + heal);
            floatText(this, this.heroSprite.x, this.heroSprite.y - 90, '+' + heal, '#fde68a', 15);
          }
        } else if (ult.target === 'ally') {
          this.applyPetAllyBuffs(p, ult, scale, true);
        }
        this.renderState();
      };
      await new Promise((res) => petUltimateCinematic(this, pet, px, py, pet.element, () => { applyUlt(); res(); }));
      await wait(360);
      return;
    }
    this.petComp.attack();
    // ---- Serangan biasa (cooldown belum siap): gaya sesuai attackType ----
    if (this.petCd > 0) {
      this.petCd--;
      if (target && tSprite) {
        const dmg = Math.max(2, Math.round((this.petAtk || 5) * RF(0.7, 1.0)));
        await new Promise((res) => this.petDeliverAttack(pet, target, tSprite, dmg, res));
      }
      return;
    }
    // ---- SKILL: rotasi 2 skill v11 ----
    const skills = pet.skills && pet.skills.length ? pet.skills : [pet.skill];
    const sk = skills[this.petSkillIdx % skills.length];
    this.petSkillIdx++;
    this.petCd = sk.cd;
    const tx = tSprite ? tSprite.x : px, ty = tSprite ? tSprite.y : py;
    Sfx.skill();
    this.addLog(pet.name + ' menggunakan ' + sk.name + '!');
    const base = (this.petAtk || 5) * sk.power * scale;
    if (sk.target === 'enemy') {
      if (target && tSprite) {
        const dmg = Math.max(3, Math.round(base * RF(0.9, 1.1)));
        await new Promise((res) => this.petDeliverAttack(pet, target, tSprite, dmg, res));
        if (!target.defeated) this.applyPetEffect(target, sk.effect, base);
        if (target.hp <= 0) this.killEnemy(target);
        this.renderState();
      }
      if (sk.effect === 'lifesteal' || sk.effect === 'radiant') this.applyPetAllyBuffs(p, sk, scale);
    } else if (sk.target === 'enemies') {
      const tgts = enemies.slice();
      // ledakan di tiap musuh berurutan cepat (impact terasa)
      for (let i = 0; i < tgts.length; i++) {
        const sp = this.enemySprites[this.enemies.indexOf(tgts[i])];
        if (!tgts[i].defeated) await new Promise((res) => this.petDeliverAttack(pet, tgts[i], sp, Math.max(3, Math.round(base * RF(0.9, 1.1))), () => { this.applyPetEffect(tgts[i], sk.effect, base); res(); }));
      }
      this.renderState();
    } else {
      // skill ally: FX penyembuhan di hero
      this.applyPetAllyBuffs(p, sk, scale);
      playVfx(this, (PET_ELEMENT_VFX[pet.element] || 'vfx_lpc_effects'), this.heroSprite.x, this.heroSprite.y - 60, { scale: 1.0, fps: 14 });
      fxRing(this, this.heroSprite.x, this.heroSprite.y - 60, Phaser.Display.Color.HexStringToColor(pet.color).color, 66, 460);
    }
    await wait(200);
  }
  applyPetEffect(t, effect, base) {
    if (!t) return;
    if (effect === 'burn' || effect === 'poison') { t.dot = Math.max(t.dot || 0, Math.round(base * 0.25)); t.dotTurns = 3; }
    if (effect === 'freeze') { t.paralyzeTurns = Math.max(t.paralyzeTurns || 0, 1); this.addLog(t.name + ' membeku!'); }
    if (effect === 'stun10' && Math.random() < 0.1) { t.paralyzeTurns = Math.max(t.paralyzeTurns || 0, 1); this.addLog(t.name + ' bingung!'); }
    if (effect === 'stun25' && Math.random() < 0.25) { t.paralyzeTurns = Math.max(t.paralyzeTurns || 0, 1); this.addLog(t.name + ' lumpuh!'); }
    if (effect === 'slow' || effect === 'atkdown') { t.weakenMul = 0.85; t.weakenTurns = 3; }
  }
  applyPetAllyBuffs(p, sk, scale, isUlt) {
    if (sk.effect === 'hot') { p.regen = Math.max(p.regen, Math.round(p.hpMax * (isUlt ? 0.05 : 0.03) * scale)); p.regenTurns = 4; this.addLog('Regen mengalir.'); }
    if (sk.effect === 'shield') { const sh = Math.round((this.petAtk || 6) * (isUlt ? 2.2 : 1.2) * scale); p.shield += sh; this.addLog('Perisai pet +' + sh + '.'); }
    if (sk.effect === 'defup') { const sh = Math.round(p.hpMax * 0.08 * scale); p.shield += sh; this.addLog('Pertahanan menguat.'); }
    if (sk.effect === 'blessing') {
      const heal = Math.round(p.hpMax * (isUlt ? 0.34 : 0.28) * scale);
      p.hp = Math.min(p.hpMax, p.hp + heal);
      p.mp = Math.min(p.mpMax, p.mp + Math.round(p.mpMax * 0.15));
      for (const e of this.aliveEnemies()) { e.dotTurns = 0; e.dot = 0; }
      floatText(this, this.heroSprite.x, this.heroSprite.y - 90, '+' + heal, '#f9a8d4', 17);
      this.addLog('Berkat menyinari medan.');
    }
    if (sk.effect === 'radiant' || sk.effect === 'lifesteal') {
      const heal = Math.max(1, Math.round(p.hpMax * 0.05 * scale));
      p.hp = Math.min(p.hpMax, p.hp + heal);
      floatText(this, this.heroSprite.x, this.heroSprite.y - 90, '+' + heal, '#fde68a', 13);
    }
  }

  async enemyTurn() {
    const p = this.p;
    for (const e of this.aliveEnemies()) {
      // v12 §9-A3: ENRAGE — boss/elite berubah pola di bawah 50% HP.
      if (!e.enraged && e.hp > 0 && e.hp < e.hpMax * 0.5) {
        const mdef = monsterById(e.id) || {};
        if (mdef.tier === 'boss' || mdef.tier === 'worldboss' || mdef.tier === 'elite') {
          e.enraged = true;
          e.atk = Math.round(e.atk * 1.25);
          this.addLog(e.name + ' MENGAMUK! Serangannya menguat.');
          const spE = this.enemySprites[this.enemies.indexOf(e)];
          if (spE) { spE.setTint(0xef4444); this.tweens.add({ targets: spE, alpha: { from: 1, to: 0.78 }, duration: 320, yoyo: true, repeat: -1 }); }
          fxFlash(this, 0xef4444, 220, 0.25); shake(this, 7);
        }
      }
      if (e.paralyzeTurns > 0) { e.paralyzeTurns--; this.addLog(e.name + ' lumpuh.'); continue; }
      if (e.dotTurns > 0) { e.hp -= e.dot; e.dotTurns--; this.addLog(e.name + ' teracuni -' + e.dot + '.'); if (e.hp <= 0) { this.killEnemy(e); continue; } }
      if (e.weakenTurns > 0) { e.weakenTurns--; if (e.weakenTurns === 0) e.weakenMul = 1; }
      if (e.markTurns > 0) e.markTurns--;
      const dodge = (this.eff.dodge || 0) + (p.evasionTurns > 0 ? p.evasionPct / 100 : 0);
      if (Math.random() < dodge) { this.addLog('Kamu menghindar!'); continue; }
      let dmg = Math.max(1, Math.round(e.atk * RF(0.9, 1.1) * (e.weakenMul || 1) - p.def * (p.defending ? 0.8 : 0.45)));
      if (p.shield > 0) {
        const absorbed = Math.min(p.shield, dmg);
        p.shield -= absorbed; dmg -= absorbed;
        if (dmg <= 0) { this.addLog('Perisai menahan serangan ' + e.name + '.'); continue; }
      }
      p.hp -= dmg;
      this.chargeUlt(5);
      Sfx.hurt(); shake(this, 3);
      const sp = this.enemySprites[this.enemies.indexOf(e)];
      if (sp) { floatText(this, sp.x - 60, sp.y - 80, '-' + dmg, '#fca5a5', 15); this.projectileFx(sp.x, sp.y - sp.displayHeight * 0.5, this.heroSprite.x, this.heroSprite.y - this.heroSprite.displayHeight * 0.5, { color: 0xef4444, size: 6, trail: false }); }
      this.heroSprite.setTintFill(0xef4444);
      this.time.delayedCall(140, () => { if (this.heroSprite.active) this.heroSprite.clearTint(); });
      this.addLog(e.name + ' menyerang: ' + dmg + ' damage.');
      if (this.eff.thorns && sp) { const ref = Math.max(1, Math.round(dmg * this.eff.thorns)); e.hp -= ref; floatText(this, sp.x, sp.y - sp.displayHeight - 30, '-' + ref, '#fbbf24', 12); if (e.hp <= 0) this.killEnemy(e); }
      if (p.hp <= 0) {
        if (this.eff.revive && !this.reviveUsed) {
          this.reviveUsed = true;
          p.hp = Math.max(1, Math.round(p.hpMax * this.eff.revive));
          this.addLog('Bangkit kembali!');
          fxRing(this, this.heroSprite.x, this.heroSprite.y - 40, 0xf97316, 80, 500);
        } else { this.endBattle(false); return; }
      }
      await wait(200);
    }
    // Tick buff pemain.
    if (p.buffTurns > 0) { p.buffTurns--; if (p.buffTurns === 0) { p.buffPct = 0; this.addLog('Buff ATK habis.'); } }
    if (p.evasionTurns > 0) { p.evasionTurns--; if (p.evasionTurns === 0) p.evasionPct = 0; }
    if (p.regenTurns > 0) { p.hp = Math.min(p.hpMax, p.hp + p.regen); p.regenTurns--; }
    if (p.manaRegenTurns > 0) { p.mp = Math.min(p.mpMax, p.mp + p.manaRegen); p.manaRegenTurns--; }
    if (this.eff.manaRegen) p.mp = Math.min(p.mpMax, p.mp + this.eff.manaRegen);
    if (this.eff.regen) p.hp = Math.min(p.hpMax, p.hp + this.eff.regen);
    p.defending = false;
  }

  killEnemy(e) {
    if (e.defeated) return;
    e.defeated = true;
    const sp = this.enemySprites[this.enemies.indexOf(e)];
    if (sp) {
      stopMonsterAnim(sp);
      fxSparks(this, sp.x, sp.y - sp.displayHeight * 0.5, 0xffe08a, 16);
      battleHitStop(this, 80); // v12: hit-stop saat KO
      playExplosion(this, 'two', sp.x, sp.y - sp.displayHeight * 0.45, { scale: 0.9 }); // v13: ledakan KO
      this.tweens.add({ targets: sp, alpha: 0, y: sp.y + 14, angle: 80, duration: 320, onComplete: () => sp.setVisible(false) });
    }
    this.addLog(e.name + ' tumbang.');
  }

  async endBattle(win, fled = false) {
    if (this.over) return;
    this.over = true;
    const W = this.scale.width, H = this.scale.height;
    await wait(500);
    if (win === true) Sfx.victory(); else if (win === false) Sfx.defeat();
    await Data.submitBattle({ win: win === true, questId: this.quest.id });
    const bw = Math.min(460, W - 50);
    const col = win === true ? 0x16a34a : win === false ? 0xdc2626 : 0x475569;
    // v9: panel hasil = aset 9-slice + outline warna hasil.
    uiSlice(this, W / 2, H / 2, bw, 220, 'ui_panel', 0x0a0f1c).setAlpha(0.96).setScrollFactor(0).setDepth(2000);
    uiSlice(this, W / 2, H / 2, bw - 4, 216, 'ui_outline', col).setScrollFactor(0).setDepth(2000);
    this.add.text(W / 2, H / 2 - 64, win === true ? 'MENANG' : win === false ? 'KALAH' : 'KABUR', { fontFamily: F_HEAD, fontSize: '24px', color: win === true ? '#86efac' : win === false ? '#fca5a5' : '#cbd5e1' }).setOrigin(0.5).setDepth(2001);
    const q = this.quest;
    if (win === true) {
      const mon = monsterById(q.monster);
      const xp = q.rewardXp + (mon ? mon.xp * q.count : 0);
      const gold = q.rewardGold + (mon ? mon.gold * q.count : 0);
      this.add.text(W / 2, H / 2 - 18, 'Hadiah quest', { fontFamily: F_UI, fontSize: '13px', color: '#94a3b8' }).setOrigin(0.5).setDepth(2001);
      this.add.text(W / 2, H / 2 + 8, '+' + fmt(xp) + ' XP   +' + fmt(gold) + ' KZC', { fontFamily: F_UI, fontSize: '17px', color: '#fde68a', fontStyle: 'bold' }).setOrigin(0.5).setDepth(2001);
      ensurePixelTex(this);
      const conf = this.add.particles(0, 0, 'fxpix', {
        x: { min: W * 0.2, max: W * 0.8 }, y: -10, speedY: { min: 60, max: 160 }, speedX: { min: -30, max: 30 },
        scale: { min: 0.8, max: 1.6 }, alpha: { start: 1, end: 0.2 }, lifespan: 2600, quantity: 3, frequency: 40,
        tint: [0xfde68a, 0xf2c230, 0x86efac, 0x93c5fd, 0xfca5a5],
      }).setScrollFactor(0).setDepth(1999);
      this.time.delayedCall(2600, () => conf.destroy());
    } else {
      this.add.text(W / 2, H / 2 - 10, fled ? 'Kamu berhasil melarikan diri.' : 'Coba naikkan level atau pasang equipment lebih baik.', { fontFamily: F_UI, fontSize: '13px', color: '#94a3b8' }).setOrigin(0.5).setDepth(2001);
    }
    makeButton(this, W / 2, H / 2 + 68, 240, 50, 'Kembali ke Guild', { color: 0x16a34a, size: 14, onClick: () => this.scene.start('QuestBoard') }).setScrollFactor(0).setDepth(2002);
  }
}
function wait(ms) { return new Promise((res) => setTimeout(res, ms / (window.__kzBattleSpeed || 1))); } // v12: FFWD-aware
function W0(scene) { return scene.scale.width; }
/* ============================================================================
 * 8. SCENE: DUNGEON SELECT + DUNGEON (platformer)
 * ----------------------------------------------------------------------------
 * Perubahan besar v2:
 *   - FIX SPAWN BAWAH TANAH: semua body dihitung dari tinggi frame asli via
 *     footBody() — dasar body selalu persis di kaki sprite.
 *   - Peti hanya di SEBAGIAN lantai (floorHasChest), isi di-roll SERVER dengan
 *     sistem rarity (semakin langka semakin jarang).
 *   - MIMIC: penyamar peti yang membuka mulut & mengejar; drop lebih kaya.
 *   - Lantai selesai TIDAK memberi hadiah apa pun (hadiah dari peti & monster).
 *   - Archer menembak panah (proyektil); class lain melee arc.
 *   - Skill bisa dipakai di dungeon (tombol SKILL, pakai MP).
 * ========================================================================== */
class DungeonSelectScene extends Phaser.Scene {
  constructor() { super('DungeonSelect'); }
  create() {
    const W = this.scale.width, H = this.scale.height;
    // v9: latar biru gua — pita aset bertingkat.
    uiFill(this, W / 2, H / 2, W, H, 0x0b1120);
    uiFill(this, W / 2, H * 0.75, W, H / 2, 0x1a2540, 0.85);
    sceneHeader(this, 'DUNGEON', 'Pilih dungeon dan lantai — makin dalam, makin berbahaya', { y: H * 0.06 });

    const dungeons = Data.dungeons() || [];
    const cardW = Math.min(560, W * 0.62), cardH = 108;
    dungeons.slice(0, 6).forEach((d, i) => {
      const y = H * 0.16 + i * (cardH + 14) + cardH / 2;
      if (y > H - 70) return;
      const T = dungeonTheme(d.theme);
      // v9: kartu dungeon = tile aset + aksen tema + outline.
      uiFill(this, W / 2 + 3, y - cardH / 2 + 5, cardW, cardH, 0x000000, 0.35, 0);
      uiSlice(this, W / 2, y, cardW, cardH, 'ui_tile', 0x121a2b);
      uiFill(this, W / 2 - cardW / 2, y - cardH / 2, 6, cardH, T.accent, 0.9, 0);
      uiSlice(this, W / 2, y, cardW - 4, cardH - 4, 'ui_outline', T.accent).setAlpha(d.completed ? 0.9 : 0.45);
      iconImage(this, W / 2 - cardW / 2 + 38, y, 'door', { size: 40, color: T.accent });
      this.add.text(W / 2 - cardW / 2 + 72, y - 26, d.name + (d.completed ? '  — ditaklukkan' : ''), { fontFamily: F_UI, fontSize: '17px', color: '#f8fafc', fontStyle: 'bold' }).setOrigin(0, 0.5);
      this.add.text(W / 2 - cardW / 2 + 72, y - 4, T.label + '  •  ' + d.floors + ' lantai  •  lantai ' + d.unlocked + ' terbuka', { fontFamily: F_UI, fontSize: '12px', color: '#8b96ab' }).setOrigin(0, 0.5);
      // Bar progres lantai (aset).
      uiBar(this, W / 2 - cardW / 2 + 72 + 100, y + 16, 200, 8, clamp(d.cleared / d.floors, 0, 1), T.accent, { frameTint: 0x1e293b });
      this.add.text(W / 2 - cardW / 2 + 290, y + 16, Math.max(0, d.cleared) + '/' + d.floors, { fontFamily: F_UI, fontSize: '11px', color: '#cbd5e1' }).setOrigin(0, 0.5);
      // Pilih lantai.
      const floorOpts = [];
      for (let f = d.unlocked; f >= Math.max(1, d.unlocked - 2); f--) floorOpts.push(f);
      floorOpts.forEach((f, fi) => {
        makeButton(this, W / 2 + cardW / 2 - 76 - (floorOpts.length - 1 - fi) * 52, y, 46, 40, 'L' + f, {
          color: f === d.unlocked ? 0x16a34a : 0x1f2937, size: 12,
          onClick: () => this.scene.start('Dungeon', { dungeonId: d.id, floor: f }),
        });
      });
    });
    makeButton(this, W / 2, H - 32, 200, 44, 'Kembali', { color: 0x1f2937, icon: 'back', size: 14, onClick: () => this.scene.start('Lobby') });
  }
}

class DungeonScene extends Phaser.Scene {
  constructor() { super('Dungeon'); }
  init(data) {
    this.towerMode = !!(data && data.mode === 'tower');
    if (this.towerMode) {
      // Menara Tanpa Ujung: tema berganti tiap lantai, musuh makin nakal.
      const themes = ['cave', 'forest', 'night', 'ruins', 'snow', 'volcano', 'oasis'];
      this.dungeonId = 'tower';
      this.floor = (data && data.floor) || 1;
      this.dungeon = { id: 'tower', name: 'Menara Tanpa Ujung', theme: themes[(this.floor - 1) % themes.length], floors: 9999, difficulty: 1 + this.floor * 0.12 };
      this.carryHp = (typeof data.hp === 'number') ? data.hp : null;
      this.carryMp = (typeof data.mp === 'number') ? data.mp : null;
      return;
    }
    this.dungeonId = data.dungeonId;
    this.floor = data.floor || 1;
    this.dungeon = Data.getDungeon(this.dungeonId);
    this.carryHp = (typeof data.hp === 'number') ? data.hp : null;
    this.carryMp = (typeof data.mp === 'number') ? data.mp : null;
  }

  create() {
    const W = this.scale.width, H = this.scale.height;
    this.W = W; this.H = H;
    this.dead = false; this.over = false; this.busy = false;
    // v9: sistem interaksi — registry harus ADA sebelum objek mendaftar (exit, peti, dll).
    this.interactables = [];
    this._interactCur = null;
    this.invulnUntil = 0; this.moveDir = 0;
    this.holdDirs = new Set();
    this.coins = []; this.popups = [];
    this.arrows = [];

    this.worldW = 4200 + this.floor * 200;
    this.physics.world.setBounds(0, 0, this.worldW, H);

    const T = dungeonTheme(this.dungeon.theme);
    this.T = T;
    this.accent = T.accent;

    this.parallax = buildThemeParallax(this, this.dungeon.theme, W, H);
    buildTerrainTextures(this, this.dungeon.theme);
    this.ambient = addAmbientParticles(this, this.dungeon.theme, W, H);
    // Vignette sinematik — di bawah HUD (depth 1900+) agar teks tetap tajam.
    addVignette(this, 899);

    /* ---------- TERRAIN ---------- */
    this.platforms = this.physics.add.staticGroup();
    this.groundSegs = [];
    const baseY = H - 150;
    this.groundBaseY = baseY;
    let lvl = 0, x = 0;
    const segs = [];
    while (x < this.worldW) {
      const wSeg = R(260, 430);
      const nearSpawn = x < 700, nearExit = x > this.worldW - 700;
      if (!nearSpawn && !nearExit && Math.random() < 0.45) lvl = clamp(lvl + R(-1, 1), 0, 2);
      const yTop = baseY - lvl * 40;
      segs.push({ x, w: Math.min(wSeg, this.worldW - x), y: yTop });
      x += wSeg;
    }
    segs.forEach((s) => {
      // Body: pusat s.y+100, tinggi 200 -> BATAS ATAS persis di permukaan.
      this.platforms.create(s.x + s.w / 2, s.y + 100, '__DEFAULT').setVisible(false).setDisplaySize(s.w, 200).refreshBody();
      if (this.textures.exists('terra_fill_' + this.dungeon.theme)) {
        const ts = this.add.tileSprite(s.x + s.w / 2, s.y + 100, s.w, 200, 'terra_fill_' + this.dungeon.theme).setDepth(-8);
        ts.setTileScale(2, 2); // integer = pixel tajam, tanpa subpixel
      } else {
        uiFill(this, s.x + s.w / 2, s.y + 100, s.w, 200, T.dirt).setDepth(-8);
      }
      if (this.textures.exists('terratex_' + this.dungeon.theme + '_cap')) {
        this.add.tileSprite(s.x + s.w / 2, s.y - 7, s.w, 14, 'terratex_' + this.dungeon.theme + '_cap').setOrigin(0.5, 0).setDepth(-7);
      } else {
        uiFill(this, s.x + s.w / 2, s.y, s.w, 6, T.cap).setDepth(-7);
        uiFill(this, s.x + s.w / 2, s.y - 1, s.w, 2, T.capLight, 0.9).setDepth(-7);
        uiFill(this, s.x + s.w / 2, s.y + 3, s.w, 2, T.accent, 0.18).setDepth(-7);
      }
      uiFill(this, s.x + s.w / 2, s.y + 8, s.w, 4, 0x000000, 0.25).setDepth(-7);
      this.groundSegs.push(s);
    });

    // Platform apung.
    this.platformGroup = this.physics.add.staticGroup();
    for (let px = 560; px < this.worldW - 500; px += R(380, 560)) {
      const wPlat = R(3, 5) * 32;
      const y = baseY - R(110, 210);
      this.platformGroup.create(px, y + 8, '__DEFAULT').setVisible(false).setDisplaySize(wPlat, 16).refreshBody();
      if (this.textures.exists('terra_fill_' + this.dungeon.theme)) {
        const ts = this.add.tileSprite(px, y + 8, wPlat, 16, 'terra_fill_' + this.dungeon.theme).setDepth(-8);
        ts.setTileScale(1, 1);
      } else {
        uiFill(this, px, y + 8, wPlat, 16, T.dirt).setDepth(-8);
      }
      if (this.textures.exists('terratex_' + this.dungeon.theme + '_cap')) {
        this.add.tileSprite(px, y - 7, wPlat, 14, 'terratex_' + this.dungeon.theme + '_cap').setOrigin(0.5, 0).setDepth(-7);
      } else {
        uiFill(this, px, y, wPlat, 6, T.cap).setDepth(-7);
        uiFill(this, px, y - 1, wPlat, 2, T.capLight, 0.9).setDepth(-7);
      }
      // v9: gantungan tanah bawah platform = aset batu (tint tema, nol canvas).
      const dk = ['asset_deco_stalagmite1', 'asset_deco_stalagmite2', 'asset_deco_rock2'].find((k) => this.textures.exists(k));
      if (dk) {
        this.add.image(px - wPlat * 0.22, y + 16, dk).setOrigin(0.5, 0).setDepth(-8).setDisplaySize(R(16, 26), R(14, 30)).setTint(T.dirtDark);
        this.add.image(px + wPlat * 0.2, y + 16, dk).setOrigin(0.5, 0).setDepth(-8).setDisplaySize(R(14, 24), R(12, 26)).setTint(T.dirtDark);
      } else {
        uiFill(this, px - wPlat * 0.25, y + 16, 18, R(14, 30), T.dirtDark, 1, 0);
        uiFill(this, px + wPlat * 0.17, y + 16, 16, R(12, 26), T.dirtDark, 1, 0);
      }
    }

    this.placeDecor(T);
    for (let tx = 300; tx < this.worldW - 200; tx += R(430, 640)) addTorch(this, tx, this.groundAt(tx) - 4, T.accent);

    // Pintu keluar — PORTAL DIMENSI aset animasi (v9).
    this.exitX = this.worldW - 140;
    const ey = this.groundAt(this.exitX);
    if (this.textures.exists('itx_portal')) {
      if (!this.anims.exists('itx_portal_swirl')) this.anims.create({ key: 'itx_portal_swirl', frames: this.anims.generateFrameNumbers('itx_portal', { start: 0, end: 3 }), frameRate: 8, repeat: -1 });
      const po = this.add.sprite(this.exitX, ey, 'itx_portal', 0).setOrigin(0.5, 1).setScale(1.35).setDepth(-6);
      try { po.play('itx_portal_swirl'); } catch (_) {}
    } else if (atlasHas(this, 'doors_frame_left')) {
      this.add.image(this.exitX - 14, ey, ATLAS_KEY, 'doors_frame_left').setOrigin(0.5, 1).setScale(2.6).setDepth(-5);
      this.add.image(this.exitX + 14, ey, ATLAS_KEY, 'doors_frame_right').setOrigin(0.5, 1).setScale(2.6).setDepth(-5);
      if (atlasHas(this, 'doors_leaf_open')) this.add.image(this.exitX, ey - 2, ATLAS_KEY, 'doors_leaf_open').setOrigin(0.5, 1).setScale(2.6).setDepth(-6);
    }
    if (atlasHas(this, 'floor_stairs')) this.add.image(this.exitX, ey, ATLAS_KEY, 'floor_stairs').setOrigin(0.5, 1).setScale(2).setDepth(-7);
    const exitGlow = this.textures.exists('fx_tex_glow')
      ? this.add.image(this.exitX, ey - 52, 'fx_tex_glow').setTint(T.accent).setAlpha(0.2).setScale(0.85, 0.7).setBlendMode(Phaser.BlendModes.ADD).setDepth(-8)
      : this.add.image(this.exitX, ey - 52, 'fx_tex_flash').setTint(T.accent).setAlpha(0.14).setDisplaySize(88, 88).setBlendMode(Phaser.BlendModes.ADD).setDepth(-8);
    this.tweens.add({ targets: exitGlow, alpha: { from: 0.08, to: 0.28 }, scale: { from: 0.9, to: 1.15 }, duration: 800, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    this.add.text(this.exitX, ey - 142, 'KELUAR', { fontFamily: F_HEAD, fontSize: '10px', color: '#fde68a', stroke: '#0b0b12', strokeThickness: 3 }).setOrigin(0.5).setDepth(-4);
    // v9: turun lantai lewat tombol interaksi (bukan sentuh otomatis).
    this.registerInteract({ x: this.exitX, y: ey, top: 84, r: 80, icon: 'door', label: this.towerMode ? 'NAIK LANTAI' : 'TURUN LANTAI', can: () => !this.over && !this.dead, act: () => this.completeFloor() });

    this.buildVignette();

    /* ---------- PLAYER (body rapi: kaki persis di tanah) ---------- */
    const hv2 = heroVisual(this, Data.char.classKey, Data.char.customization, W < 560 ? 3.6 : 3.2);
    this.heroAnim = hv2.anim; this.heroIsAtlas = !!hv2.isAtlas;
    const spawnY = this.groundAt(120);
    this.player = this.physics.add.sprite(120, spawnY, hv2.key, hv2.frame || 0).setOrigin(0.5, 1).setScale(hv2.scale);
    try { this.player.play(hv2.anim.idle); } catch (_) {}
    this.player.setCollideWorldBounds(true);
    const fb = hv2.body || footBody(hv2.frameW || 16, hv2.frameH || 28);
    this.player.body.setSize(fb.w, fb.h, false);
    this.player.body.setOffset(fb.ox, fb.oy);
    this.physics.add.collider(this.player, this.platforms);
    this.physics.add.collider(this.player, this.platformGroup);

    // Pet companion: menemani + otomatis menyerang musuh terdekat.
    // Posisi follow di belakang-dada (y - 40) supaya tidak menimpa tombol
    // kontrol mobile di kiri bawah layar.
    this.petComp = null;
    this.petAtk = 0;
    this.petNextAttack = 0;
    if (PetState.active && petTexExists(this, PetState.active, PetState.stage(PetState.active))) {
      this.petComp = spawnPetCompanion(this, PetState.active, {
        x: 70, y: spawnY - 40, depth: 9, scale: 2.0,
        follow: { get: () => ({ x: this.player.x - 58 * (this.player.flipX ? -1 : 1), y: this.player.y + 4 }) }, // v12: kaki, bukan dada (fix pet di atas kepala)
      });
      const pass = petPassiveAt(PetState.activePet, PetState.activeLevel, PetState.stage(PetState.active));
      this.petAtk = Math.max(3, Math.round(((pass.atk || 4) + 3 + PetState.activeLevel * 0.8) * (PetState.stage(PetState.active) >= 2 ? 1.35 : 1)));
    }

    const st0 = computeStats(Data.char);
    this.maxHp = st0.hp; this.maxMp = st0.mp;
    this.baseAtk = st0.atk; this.baseDef = st0.def; this.baseCrit = st0.crit;
    this.playerHp = clamp(this.carryHp != null ? this.carryHp : this.maxHp, 1, this.maxHp);
    this.playerMp = clamp(this.carryMp != null ? this.carryMp : this.maxMp, 0, this.maxMp);
    this.eff = {};
    for (const slot of ['weapon', 'armor', 'accessory']) {
      const eq = itemById(Data.char.equipped && Data.char.equipped[slot]);
      if (!eq || !eq.effect) continue;
      const e = eq.effect;
      if (e.kind === 'cleave') this.eff.cleave = Math.max(this.eff.cleave || 0, e.pct);
      else if (e.kind === 'lifesteal') this.eff.lifesteal = (this.eff.lifesteal || 0) + e.pct;
      else if (e.kind === 'manaRegen') this.eff.manaRegen = (this.eff.manaRegen || 0) + e.val;
      else if (e.kind === 'execute') this.eff.execute = Math.max(this.eff.execute || 0, e.pct);
      else if (e.kind === 'poison') this.eff.poison = Math.max(this.eff.poison || 0, e.dot);
      else if (e.kind === 'critDmg') this.eff.critDmg = (this.eff.critDmg || 0) + e.pct;
      else if (e.kind === 'shield') this.eff.shield = Math.max(this.eff.shield || 0, e.pct);
      else if (e.kind === 'thorns') this.eff.thorns = Math.max(this.eff.thorns || 0, e.pct);
      else if (e.kind === 'regen') this.eff.regen = (this.eff.regen || 0) + e.val;
      else if (e.kind === 'dodge') this.eff.dodge = (this.eff.dodge || 0) + e.pct;
      else if (e.kind === 'goldFind') this.eff.goldFind = (this.eff.goldFind || 0) + e.pct;
      else if (e.kind === 'revive') this.eff.revive = Math.max(this.eff.revive || 0, e.pct);
    }
    this.shieldHp = this.eff.shield ? Math.round(this.maxHp * this.eff.shield) : 0;
    this.reviveUsed = false;
    this.buffAtk = 0; this.buffAtkUntil = 0;
    this.buffDodge = 0; this.buffDodgeUntil = 0;
    this.weakenUntil = 0; this.weakenVal = 0;
    this.regenHpPotion = 0; this.regenHpPotionUntil = 0;
    this.regenMpPotion = 0; this.regenMpPotionUntil = 0;
    this.poisonEdge = null;
    this._regenTick = 0;
    this.wasAirborne = false;
    this.coyoteUntil = 0; this.jumpBufUntil = 0;
    this.baseScale = hv2.scale;
    this.airJumps = 1; this.jumpLockUntil = 0;
    this.dashUntil = 0; this.dashCdUntil = 0; this.dashDir = 1; this._dashGravityOff = false;
    this.lastTapDir = 0; this.lastTapAt = 0;
    this.lungeDir = 1; this.lungeUntil = 0;
    this.stepHopUntil = 0;
    this.comboIdx = 0; this.comboUntil = 0;
    this.hitCombo = 0; this.hitComboUntil = 0;
    this._hitStops = 0;
    this.atkCdUntil = 0;
    this.ultCharge = 0; this.ultBtnRef = null; this._ultPulse = false; // ULTIMATE
    // GEAR: senjata/zirah/aksesori terlihat dipakai karakter di dungeon.
    this.heroGear = createHeroGear(this, this.player, Data.char.classKey, Data.char.equipped || {}, { scale: W < 560 ? 1.15 : 1.3, noWeapon: !!hv2.lpc, depth: 9, handOffset: { x: hv2.lpc ? 17 : (hv2.v3 ? 16 : 14), y: hv2.lpc ? -44 : (hv2.v3 ? -40 : -32) } });
    // Assassin: jejak bayangan saat lari.
    this._ghostAt = 0;
    // v9: bayangan & cahaya pemain = aset (tanpa fallback shape).
    this.shadow = this.add.image(this.player.x, spawnY + 2, this.textures.exists('fx_tex_shadow') ? 'fx_tex_shadow' : 'fx_tex_flash').setDepth(-1).setAlpha(0.4).setDisplaySize(48, 16);
    this.playerLight = this.add.image(this.player.x, this.player.y - 40, this.textures.exists('fx_tex_glow') ? 'fx_tex_glow' : 'fx_tex_flash').setDepth(-2).setTint(0xfff2d8).setAlpha(0.17).setScale(2.4, 1.9).setBlendMode(Phaser.BlendModes.ADD);

    /* ---------- MONSTER (body rapi per tinggi frame) ---------- */
    this.enemies = [];
    ensureMonsterAnims(this);
    ensureChestAnims(this);
    this.ensureCoinsAnim();
    const pool = dungeonMonsterPool(this.floor, this.dungeon.theme);
    const count = Math.min(9, 4 + Math.floor(this.floor * 0.8));
    for (let i = 0; i < count; i++) {
      const m = monsterById(pick(pool));
      const ex = R(560, this.worldW - 620);
      this.spawnMonster(m, ex, this.groundAt(ex));
    }
    const isBossFloor = (this.floor % DUNGEON.bossEvery === 0) || this.floor === this.dungeon.floors;
    this.bossAlive = false;
    if (isBossFloor) {
      const bossId = THEME_BOSS[this.dungeon.theme] || 'minotaur';
      const b = monsterById(bossId);
      const e = this.spawnMonster(b, this.worldW - 500, this.groundAt(this.worldW - 500), monsterScale(this, b) * 1.9);
      e.monster = { ...b, name: b.name + ' (' + this.dungeon.name + ')' };
      e.hp = Math.round(b.hp * 0.5); e.hpMax = e.hp; e.isBoss = true; e.homeX = this.worldW - 500;
      e.nextAtk = 0;
      this.enemies.push(e);
      this.bossAlive = true;
      this.bossRef = e;
      fxAura(this, e.x, e.y - 10, 60, 0xef4444, 900);
    }
    this.physics.add.overlap(this.player, this.enemies, (p, e) => this.touchEnemy(e));

    /* ---------- PETI (hanya di SEBAGIAN lantai) ---------- */
    this.chests = [];
    this.mimics = [];
    this.hasChestFloor = isBossFloor || floorHasChest(this.floor);
    if (this.hasChestFloor) {
      const chestCount = R(2, 4);
      for (let i = 0; i < chestCount; i++) {
        const cx = R(760, this.worldW - 760);
        if (this.floor >= 2 && Math.random() < mimicChance(this.floor)) this.spawnMimic(cx);
        else this.spawnChest(cx);
      }
    }

    /* ---------- ALTAR BERKAT (hampir separuh lantai punya) ---------- */
    this.altarObj = null;
    if (Math.random() < 0.45) this.spawnAltar(R(900, this.worldW - 1000));

    /* ---------- RUANG RAHASIA (retakan mencurigakan...) ---------- */
    this.secretObj = null;
    if (!this.towerMode && Math.random() < 0.35) this.spawnSecretDoor(R(1300, this.worldW - 1400));

    /* ---------- PEDAGANG MISTERIUS (jarang muncul) ---------- */
    this.merchantObj = null;
    if (!this.towerMode && Math.random() < 0.18) this.spawnMerchant(R(1600, this.worldW - 1600));

    /* ---------- HITBOX SERANGAN + KAMERA ---------- */
    this.attackHitbox = this.add.zone(0, 0, 70, 60);
    this.physics.add.existing(this.attackHitbox);
    this.attackHitbox.body.enable = false;
    this.cameras.main.setBounds(0, 0, this.worldW, H);
    this.cameras.main.startFollow(this.player, true, 0.09, 0.09);

    this.buildDungeonHud();
    this.buildDungeonControls();
    this.buildInteractUI();
    this.renderDungeonHud();
    // Lepas gerakan saat sentuhan lepas di mana pun (anti "jalan terus").
    this.input.on('pointerup', () => { this.holdDirs.clear(); });
    this.input.on('pointerout', () => {});

    this.cursors = this.input.keyboard.createCursorKeys();
    this.space = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
    this.wasd = this.input.keyboard.addKeys('A,D,W,S');
    this.input.keyboard.on('keydown-J', () => this.attack());
    this.input.keyboard.on('keydown-K', () => this.usePotion());
    this.input.keyboard.on('keydown-Q', () => this.useDungeonSkill());
    this.input.keyboard.on('keydown-SPACE', () => { this.jumpBufUntil = this.time.now + 130; });
    this.input.keyboard.on('keydown-SHIFT', () => this.tryDash(0));
    this.input.keyboard.on('keydown-L', () => this.tryDash(0));
    this.input.keyboard.on('keydown-R', () => this.castUltimate());
    ['keyup-SPACE', 'keyup-W', 'keyup-UP'].forEach((ev) => this.input.keyboard.on(ev, () => this.jumpCut()));

    this.scale.on('resize', this.onSceneResize, this);
    this.events.once('shutdown', () => {
      this.scale.off('resize', this.onSceneResize, this);
      this.dungeonHpText = null; this.hudG = null; this.hudC = null; this.comboText = null;
      this.dCtrl = []; this.parallax = []; this.ambient = null;
      this.enemies = []; this.chests = []; this.mimics = []; this.coins = []; this.arrows = [];
      this.interactables = []; this._interactCur = null;
      this.bossBar = null; this.bossRef = null;
    });

    this.updatePotionBadge();
    this.cameras.main.fadeIn(420, 0, 0, 0);
    this.floorBanner();
  }

  buildVignette() {
    const W = this.W, H = this.H;
    // v9: pita gelap tepi dari aset putih (tint) — nol canvas.
    uiFill(this, W / 2, 13, W, 26, 0x000000, 0.28).setScrollFactor(0).setDepth(-40);
    uiFill(this, W / 2, H - 13, W, 26, 0x000000, 0.28).setScrollFactor(0).setDepth(-40);
  }
  groundAt(x) {
    let best = this.groundBaseY, bd = 1e9;
    for (const s of this.groundSegs) {
      if (x >= s.x - 4 && x <= s.x + s.w + 4) return s.y;
      const d = Math.min(Math.abs(x - s.x), Math.abs(x - (s.x + s.w)));
      if (d < bd) { bd = d; best = s.y; }
    }
    return best;
  }
  placeDecor(T) {
    const decoTypes = T.deco || ['crate'];
    const groundDeco = (x, type) => {
      const y = this.groundAt(x);
      switch (type) {
        case 'column':
          if (atlasHas(this, 'column')) this.add.image(x, y, ATLAS_KEY, 'column').setOrigin(0.5, 1).setScale(2.4).setDepth(-6);
          break;
        case 'bannerruins':
          if (atlasHas(this, 'wall_banner_red')) this.add.image(x, y - 120, ATLAS_KEY, pick(['wall_banner_red', 'wall_banner_blue', 'wall_banner_yellow'])).setScale(2.2).setDepth(-6);
          break;
        case 'crate':
          if (atlasHas(this, 'crate')) this.add.image(x, y, ATLAS_KEY, 'crate').setOrigin(0.5, 1).setScale(RF(1.8, 2.4)).setDepth(-5);
          break;
        case 'skull':
          if (atlasHas(this, 'skull')) this.add.image(x, y, ATLAS_KEY, 'skull').setOrigin(0.5, 1).setScale(1.6).setDepth(-5);
          break;
        case 'stalagmite': {
          const sk = this.textures.exists('asset_deco_stalagmite') ? 'asset_deco_stalagmite' : 'asset_deco_stalagmite1';
          if (this.textures.exists(sk)) this.add.image(x, y, sk).setOrigin(0.5, 1).setScale(RF(1.3, 2.3)).setDepth(-6).setFlipX(Math.random() < 0.5);
          break;
        }
        case 'crystal': case 'icecrystal': {
          const c = type === 'icecrystal' ? 0x9bd7ff : T.accent;
          const h = R(16, 38);
          if (this.textures.exists('asset_deco_' + type)) {
            this.add.image(x, y, 'asset_deco_' + type).setOrigin(0.5, 1).setScale(RF(1.1, 2.0)).setDepth(-5).setFlipX(Math.random() < 0.5);
            if (this.textures.exists('fx_tex_glow')) {
              const glow2 = this.add.image(x, y - h * 0.55, 'fx_tex_glow').setTint(c).setAlpha(0.2).setScale(0.34).setBlendMode(Phaser.BlendModes.ADD).setDepth(-6);
              this.tweens.add({ targets: glow2, alpha: { from: 0.10, to: 0.28 }, scale: { from: 0.3, to: 0.4 }, duration: R(700, 1200), yoyo: true, repeat: -1 });
            }
            break;
          }
          const ck = this.textures.exists('asset_deco_' + type) ? 'asset_deco_' + type : 'asset_deco_crystal';
          this.add.image(x, y, this.textures.exists(ck) ? ck : 'asset_deco_rock1').setOrigin(0.5, 1).setScale(RF(1.1, 2.0)).setDepth(-5).setFlipX(Math.random() < 0.5);
          if (this.textures.exists('fx_tex_glow')) {
            const glow = this.add.image(x, y - h * 0.55, 'fx_tex_glow').setTint(c).setAlpha(0.14).setScale(0.3).setBlendMode(Phaser.BlendModes.ADD).setDepth(-6);
            this.tweens.add({ targets: glow, alpha: { from: 0.08, to: 0.22 }, duration: R(700, 1200), yoyo: true, repeat: -1 });
          }
          break;
        }
        case 'lavacrack': {
          if (this.textures.exists('asset_deco_lavacrack')) {
            this.add.image(x, y, 'asset_deco_lavacrack').setOrigin(0.5, 1).setScale(RF(1.1, 1.8)).setDepth(-6);
            if (this.textures.exists('fx_tex_glow')) {
              const lg = this.add.image(x, y - 6, 'fx_tex_glow').setTint(0xff7a3c).setAlpha(0.2).setScale(0.5, 0.14).setBlendMode(Phaser.BlendModes.ADD).setDepth(-6);
              this.tweens.add({ targets: lg, alpha: { from: 0.12, to: 0.38 }, duration: 900, yoyo: true, repeat: -1 });
            }
            break;
          }
          // fallback: retakan = glow aset tipis.
          if (this.textures.exists('fx_tex_glow')) {
            const glow = this.add.image(x, y - 2, 'fx_tex_glow').setTint(0xff7a3c).setAlpha(0.25).setScale(0.5, 0.06).setBlendMode(Phaser.BlendModes.ADD).setDepth(-6);
            this.tweens.add({ targets: glow, alpha: { from: 0.12, to: 0.35 }, duration: 900, yoyo: true, repeat: -1 });
          }
          break;
        }
        case 'mushroom': {
          if (this.textures.exists('asset_deco_mushroom')) {
            const msc = RF(1.0, 1.8);
            if (this.textures.exists('fx_tex_shadow')) this.add.image(x, y + 2, 'fx_tex_shadow').setDisplaySize(30 * msc, 8 * msc).setAlpha(0.35).setDepth(-6);
            this.add.image(x, y, 'asset_deco_mushroom').setOrigin(0.5, 1).setScale(msc).setDepth(-5).setFlipX(Math.random() < 0.5);
            break;
          }
          if (this.textures.exists('asset_deco_bush')) this.add.image(x, y, 'asset_deco_bush').setOrigin(0.5, 1).setScale(RF(0.5, 0.9)).setDepth(-5).setFlipX(Math.random() < 0.5);
          break;
        }
        case 'tree': {
          if (this.textures.exists('asset_tree')) {
            this.add.image(x, y + 2, 'asset_tree').setOrigin(0.5, 1).setScale(RF(1.15, 1.7)).setDepth(-6).setFlipX(Math.random() < 0.5);
            break;
          }
          if (this.textures.exists('asset_deco_rock1')) this.add.image(x, y, 'asset_deco_rock1').setOrigin(0.5, 1).setScale(RF(1.0, 1.6)).setDepth(-6).setTint(0x1d3a20);
          break;
        }
        case 'bush': {
          if (this.textures.exists('asset_deco_bush')) {
            this.add.image(x, y, 'asset_deco_bush').setOrigin(0.5, 1).setScale(RF(1.1, 1.8)).setDepth(-5).setFlipX(Math.random() < 0.5);
            break;
          }
          if (this.textures.exists('asset_deco_rock1')) this.add.image(x, y, 'asset_deco_rock1').setOrigin(0.5, 1).setScale(RF(0.9, 1.4)).setDepth(-5).setTint(0x1d7a3c);
          break;
        }
        case 'fairy': { // v13: peri bercahaya (Craftpix) — melayang + denyut lembut
          if (this.textures.exists('asset_deco_fairy')) {
            ensureDecoAnims(this);
            const f = this.add.sprite(x, y - RF(26, 64), 'asset_deco_fairy', 0).setScale(RF(0.9, 1.5)).setDepth(-4).setBlendMode(Phaser.BlendModes.ADD);
            try { f.play('deco_fairy_anim'); } catch (_) {}
            this.tweens.add({ targets: f, y: f.y - RF(10, 22), duration: RF(1500, 2600), yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
          }
          break;
        }
        case 'predator': { // v13: tanaman predator (Craftpix) — idle sway menakutkan
          if (this.textures.exists('asset_deco_predator')) {
            ensureDecoAnims(this);
            const sc = RF(0.85, 1.4);
            if (this.textures.exists('fx_tex_shadow')) this.add.image(x, y + 2, 'fx_tex_shadow').setDisplaySize(90 * sc, 12 * sc).setAlpha(0.3).setDepth(-6);
            const pr = this.add.sprite(x, y, 'asset_deco_predator', 0).setOrigin(0.5, 1).setScale(sc).setDepth(-5).setFlipX(Math.random() < 0.5);
            try { pr.play('deco_predator_anim'); } catch (_) {}
          }
          break;
        }
        case 'flystone': { // v13: pulau batu melayang (Craftpix) — latar mengapung
          if (this.textures.exists('asset_deco_flystone')) {
            ensureDecoAnims(this);
            const st = this.add.sprite(x, y, 'asset_deco_flystone', 0).setScale(RF(0.55, 1.0)).setDepth(-7).setFlipX(Math.random() < 0.5).setAlpha(0.92);
            try { st.play('deco_flystone_anim'); } catch (_) {}
            this.tweens.add({ targets: st, y: st.y - RF(8, 16), duration: RF(2200, 3800), yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
          }
          break;
        }
        case 'cactus': {
          if (this.textures.exists('asset_deco_cactus')) {
            this.add.image(x, y, 'asset_deco_cactus').setOrigin(0.5, 1).setScale(RF(1.1, 1.9)).setDepth(-5).setFlipX(Math.random() < 0.5);
            break;
          }
          if (this.textures.exists('asset_deco_bush')) this.add.image(x, y, 'asset_deco_bush').setOrigin(0.5, 1).setScale(RF(0.6, 1.0)).setDepth(-5).setTint(0x2f7a3f);
          break;
        }
        case 'gravestone': {
          if (this.textures.exists('asset_deco_gravestone')) {
            this.add.image(x, y, 'asset_deco_gravestone').setOrigin(0.5, 1).setScale(RF(1.1, 1.7)).setDepth(-5).setFlipX(Math.random() < 0.5);
            break;
          }
          if (this.textures.exists('asset_deco_rock2')) this.add.image(x, y, 'asset_deco_rock2').setOrigin(0.5, 1).setScale(RF(0.9, 1.3)).setDepth(-5).setTint(0x9aa3b2);
          break;
        }
        case 'snowpile': {
          if (this.textures.exists('asset_deco_snowpile')) {
            this.add.image(x, y, 'asset_deco_snowpile').setOrigin(0.5, 1).setScale(RF(1.2, 2.0)).setDepth(-5);
            break;
          }
          if (this.textures.exists('fx_tex_shadow')) this.add.image(x, y - 6, 'fx_tex_shadow').setAlpha(0.85).setDisplaySize(R(30, 50), R(14, 20));
          break;
        }
        case 'rock2': {
          const keys = ['asset_deco_rock1', 'asset_deco_rock2', 'asset_deco_rock3'].filter((k) => this.textures.exists(k));
          if (keys.length) this.add.image(x, y, pick(keys)).setOrigin(0.5, 1).setScale(R(14, 22) / 10).setDepth(-5);
          break;
        }
      }
    };
    for (let x = 340; x < this.worldW - 240; x += R(210, 420)) {
      groundDeco(x, pick(decoTypes));
    }
  }

  /* ---------- SPAWN: body physics dihitung dari tinggi frame ASLI ---------- */
  spawnMonster(m, x, groundY, scaleOverride) {
    const def = MONSTER_ASSET[m.id];
    let e;
    const scale = scaleOverride || monsterScale(this, m);
    if (def && atlasHas(this, firstFrameName(def))) {
      e = this.physics.add.sprite(x, groundY + 2, ATLAS_KEY, firstFrameName(def)).setOrigin(0.5, 1).setScale(scale).setTint(def.tint);
      // FIX INTI: dasar body = kaki -> monster tidak pernah tenggelam/melayang.
      const fb = footBody(16, def.frameH, 0.8);
      e.body.setSize(fb.w, fb.h, false);
      e.body.setOffset(fb.ox, fb.oy);
    } else {
      e = this.physics.add.sprite(x, groundY - 24, monsterTexture(this, m)).setScale(scale).setOrigin(0.5, 0.6);
      e.body.setSize(30, 30, true);
    }
    playMonsterAnim(this, e, m);
    e.setCollideWorldBounds(true);
    e.monster = m;
    e.defFly = !!(def && def.fly);
    if (e.defFly) {
      e.body.allowGravity = false;
      e.homeY = groundY - R(90, 150);
      e.setCollideWorldBounds(false);
    }
    e.hp = Math.round(m.hp * RF(0.8, 1.2)); e.hpMax = e.hp;
    e.dir = -1; e.homeX = x; e.state = 'patrol'; e.nextAtk = 0;
    const champChance = Math.min(0.28, 0.12 + this.floor * 0.006);
    if (!e.isBoss && Math.random() < champChance) {
      e.champion = true;
      e.setScale(e.scaleX * 1.28, e.scaleY * 1.28);
      e.hp = Math.round(e.hp * 2.2); e.hpMax = e.hp;
      e.setTint(0xffd9a0);
      e.aura = fxAura(this, x, groundY - 6, 38, 0xf2c230, -4);
      // Mahkota elite melayang + partikel percik.
      const crown = iconImage(this, x, groundY - e.displayHeight - 16, 'crown', { size: 20, color: 0xf2c230 });
      crown.setDepth(852);
      this.tweens.add({ targets: crown, y: crown.y - 5, duration: 700, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
      this.events.once('shutdown', () => { try { crown.destroy(); } catch (_) {} });
      const pet2 = this.add.particles(x, groundY - e.displayHeight * 0.6, 'fxpix', { lifespan: 600, speedY: { min: -30, max: -10 }, speedX: { min: -12, max: 12 }, scale: { start: 0.8, end: 0 }, quantity: 1, frequency: 220, tint: [0xf2c230, 0xffe08a] }).setDepth(851);
      this.events.once('shutdown', () => { try { pet2.destroy(); } catch (_) {} });
      e.monster = { ...m, name: 'Elite ' + m.name, atk: Math.round(m.atk * 1.35), xp: Math.round(m.xp * 2.5), gold: Math.round(m.gold * 2.5) };
    }
    // v9: bar HP musuh = blok aset (tint).
    e.hpBarBg = uiFill(this, e.x, e.y - e.displayHeight - 10, 40, 5, 0x0b0b12, 0.75).setDepth(850).setVisible(false);
    e.hpBar = uiFill(this, e.x, e.y - e.displayHeight - 10, 36, 3, 0xef4444, 1).setDepth(851).setVisible(false);
    this.physics.add.collider(e, this.platforms);
    this.physics.add.collider(e, this.platformGroup);
    this.enemies.push(e);
    return e;
  }

  spawnChest(cx) {
    const y = this.groundAt(cx);
    const roll = Math.random() < 0.14 + this.floor * 0.01 ? 'gold' : (Math.random() < 0.45 ? 'silver' : 'wood');
    // v9: peti = sprite aset eksklusif 3-frame (itx_chest_*) — kayu/perak/emas.
    const sheetKey = 'itx_chest_' + roll;
    let c;
    if (this.textures.exists(sheetKey)) {
      const animKey = 'itxch_open_' + roll;
      if (!this.anims.exists(animKey)) this.anims.create({ key: animKey, frames: this.anims.generateFrameNumbers(sheetKey, { start: 0, end: 2 }), frameRate: 9, repeat: 0 });
      c = this.physics.add.sprite(cx, y + 2, sheetKey, 0).setOrigin(0.5, 1).setScale(2.0);
      c.openAnim = animKey;
    } else {
      const baseFrames = roll === 'wood' ? 'chest_empty_open_anim' : 'chest_full_open_anim';
      let animKey = null;
      if (atlasHas(this, baseFrames + '_f0')) {
        animKey = 'chestz_open_' + roll;
        if (!this.anims.exists(animKey)) {
          this.anims.create({ key: animKey, frames: ['f0', 'f1', 'f2'].map((f) => ({ key: ATLAS_KEY, frame: baseFrames + '_' + f })), frameRate: 8, repeat: 0 });
        }
      }
      c = this.physics.add.sprite(cx, y + 2, ATLAS_KEY, baseFrames + '_f0').setOrigin(0.5, 1).setScale(2.6);
    }
    c.body.immovable = true;
    c.body.setSize(20, 14, true);
    this.physics.add.collider(c, this.platforms);
    c.opened = false; c.tier = roll;
    if (roll === 'gold') { c.glow = fxAura(this, cx, y - 6, 40, 0xf2c230, -4); }
    else if (roll === 'silver') { c.glow = fxAura(this, cx, y - 6, 30, 0x8ecafc, -4); }
    this.chests.push(c);
    // v9: peti dibuka lewat TOMBOL INTERAKSI / [E] — bukan overlap otomatis.
    this.registerInteract({ x: cx, y: y, top: 30, r: 62, icon: 'chest', label: 'BUKA PETI', obj: c, can: () => !c.opened && c.active, act: () => this.openChest(c) });
    return c;
  }

  spawnMimic(cx) {
    const y = this.groundAt(cx);
    // v9: mimic = sprite aset eksklusif (itx_chest_mimic).
    let c;
    if (this.textures.exists('itx_chest_mimic')) {
      const animKey = 'itxch_mimic_open';
      if (!this.anims.exists(animKey)) this.anims.create({ key: animKey, frames: this.anims.generateFrameNumbers('itx_chest_mimic', { start: 0, end: 2 }), frameRate: 9, repeat: 0 });
      c = this.physics.add.sprite(cx, y + 2, 'itx_chest_mimic', 0).setOrigin(0.5, 1).setScale(2.0);
      c.openAnim = animKey;
    } else {
      c = this.physics.add.sprite(cx, y + 2, ATLAS_KEY, atlasHas(this, 'chest_mimic_open_anim_f0') ? 'chest_mimic_open_anim_f0' : 'chest_full_open_anim_f0').setOrigin(0.5, 1).setScale(2.6);
    }
    c.body.immovable = true;
    c.body.setSize(16, 14, true);
    this.physics.add.collider(c, this.platforms);
    c.revealed = false;
    // v9: menyamar sebagai peti — interaksi = GIGIT (kejutan klasik dungeon).
    this.registerInteract({ x: cx, y: y, top: 30, r: 58, icon: 'chest', label: 'BUKA PETI', obj: c, can: () => !c.revealed && c.active, act: () => { this.revealMimic(c); this.touchEnemy(c); } });
    c.hp = 60 + this.floor * 14; c.hpMax = c.hp;
    c.monster = { id: 'mimic', name: 'Mimic', atk: 14 + this.floor * 2, def: 4, xp: 90 + this.floor * 20, gold: 120 + this.floor * 22, color: 0xb45309 };
    // Peti mimic sedikit "bernapas" — petunjuk halus buat mata tajam.
    this.tweens.add({ targets: c, scaleY: 2.6 * 1.04, duration: R(900, 1400), yoyo: true, repeat: -1 });
    this.mimics.push(c);
    return c;
  }

  revealMimic(c) {
    if (c.revealed) return;
    c.revealed = true;
    Sfx.hit(); shake(this, 5);
    if (c.openAnim && this.anims.exists(c.openAnim)) c.play(c.openAnim);
    else if (this.anims.exists('chestz_open_mimic')) c.play('chestz_open_mimic');
    else if (atlasHas(this, 'chest_mimic_open_anim_f0')) {
      if (!this.anims.exists('chestz_open_mimic')) this.anims.create({ key: 'chestz_open_mimic', frames: ['f0', 'f1', 'f2'].map((f) => ({ key: ATLAS_KEY, frame: 'chest_mimic_open_anim_' + f })), frameRate: 8, repeat: 0 });
      c.play('chestz_open_mimic');
    }
    fxRing(this, c.x, c.y - 14, 0xef4444, 50, 320);
    fxNum(this, c.x, c.y - 56, 'MIMIC!', '#fca5a5', 14, true);
    c.body.immovable = false;
    c.body.setSize(16, 18, true);
    c.state = 'chase'; c.nextAtk = this.time.now + 500;
    c.hpBarBg = uiFill(this, c.x, c.y - c.displayHeight - 10, 40, 5, 0x0b0b12, 0.75).setDepth(850).setVisible(false);
    c.hpBar = uiFill(this, c.x, c.y - c.displayHeight - 10, 36, 3, 0xef4444, 1).setDepth(851).setVisible(false);
    this.enemies.push(c);
    this.physics.add.overlap(this.player, c, () => this.touchEnemy(c));
  }

  ensureCoinsAnim() {
    if (this.anims.exists('coinz_spin')) return;
    if (atlasHas(this, 'coin_anim_f0')) {
      this.anims.create({ key: 'coinz_spin', frames: ['f0', 'f1', 'f2', 'f3'].map((f) => ({ key: ATLAS_KEY, frame: 'coin_anim_' + f })), frameRate: 8, repeat: -1 });
    }
  }
  spawnCoins(x, y, n) {
    ensurePixelTex(this);
    if (this.coins.length > 60) { // jaga jumlah: buang yang tertua
      const old = this.coins.splice(0, this.coins.length - 60);
      old.forEach((c) => { try { c.destroy(); } catch (_) {} });
    }
    for (let i = 0; i < n; i++) {
      const useAtlas = atlasHas(this, 'coin_anim_f0');
      const c = this.add.sprite(x + RF(-14, 14), y + RF(-10, 6), useAtlas ? ATLAS_KEY : 'fxpix', useAtlas ? 'coin_anim_f0' : undefined).setScale(1.8).setDepth(860);
      if (this.anims.exists('coinz_spin')) c.play('coinz_spin');
      c._magnet = false;
      c._magnetOkAt = this.time.now + 480; // busur lemparan dulu, baru magnet
      c._dieAt = this.time.now + 9000;
      c._landY = this.groundAt(c.x) - R(2, 10);
      this.tweens.add({ targets: c, y: c._landY, x: c.x + RF(-34, 34), duration: R(300, 520), ease: 'Quad.easeOut', onComplete: () => {
        this.tweens.add({ targets: c, scaleY: 1.8 * 0.72, duration: 70, yoyo: true });
      } });
      this.coins.push(c);
    }
  }
  /* v8 KOIN MAGNET: koin melayang mendekat ke pemain lalu terserap (juice). */
  updateCoins(now, dt) {
    const p = this.player;
    if (!p) return;
    for (let i = this.coins.length - 1; i >= 0; i--) {
      const c = this.coins[i];
      if (!c.active) { this.coins.splice(i, 1); continue; }
      if (now > (c._dieAt || 0)) {
        this.tweens.add({ targets: c, alpha: 0, duration: 350, onComplete: () => c.destroy() });
        this.coins.splice(i, 1); continue;
      }
      if (this.dead || this.over) continue;
      const dx = p.x - c.x, dy = (p.y - 30) - c.y;
      const d = Math.sqrt(dx * dx + dy * dy);
      if (c._magnet) {
        const k = Math.min(1, dt * 0.013);
        c.x += dx * k; c.y += dy * k;
        if (d < 26) {
          if (this.textures.exists('fx_tex_sparkle')) {
            const sp = this.add.image(c.x, c.y, 'fx_tex_sparkle').setTint(0xfde68a).setScale(0.2).setBlendMode(Phaser.BlendModes.ADD).setDepth(1600);
            this.tweens.add({ targets: sp, alpha: 0, scale: 0.5, duration: 180, onComplete: () => sp.destroy() });
          }
          c.destroy(); this.coins.splice(i, 1); Sfx.coin();
        }
      } else if (d < 150 && now > (c._magnetOkAt || 0)) {
        c._magnet = true;
        this.tweens.add({ targets: c, scaleY: 1.8, duration: 90 });
      }
    }
  }

  /* ---------- HUD & KONTROL ---------- */
  buildDungeonHud() {
    const W = this.W;
    // v9: HUD = aset penuh (frame 9-slice ui/hud + bar tileSprite) — tanpa graphics.
    this.hudG = null;
    this.hudC = this.add.container(0, 0, []).setScrollFactor(0).setDepth(1901);
    this.comboText = this.add.text(W / 2, 92, '', { fontFamily: F_HEAD, fontSize: '13px', color: '#fde68a', stroke: '#0b0b12', strokeThickness: 4 }).setOrigin(0.5).setScrollFactor(0).setDepth(1903).setAlpha(0);
    this.dungeonHpText = this.add.text(15, 13, '', { fontFamily: F_PIX, fontSize: '10px', color: '#e8eefc' }).setScrollFactor(0).setDepth(1902);
    this.floorText = this.add.text(W / 2, 16, '', { fontFamily: F_HEAD, fontSize: '11px', color: '#fde68a', stroke: '#0b0b12', strokeThickness: 3 }).setOrigin(0.5).setScrollFactor(0).setDepth(1902);
    if (this.anims.exists('coinz_spin')) {
      this.goldCoin = this.add.sprite(0, 0, ATLAS_KEY, 'coin_anim_f0').setScale(2.2).play('coinz_spin').setScrollFactor(0).setDepth(1902);
      this.hudC.add(this.goldCoin);
    }
    this.goldText = this.add.text(0, 0, '', { fontFamily: F_PIX, fontSize: '11px', color: '#fde68a' }).setScrollFactor(0).setDepth(1902);
    this.hudC.add(this.goldText);
    const bwH = Math.min(240, W * 0.4);
    this.hudFrame = ssf0(uiSlice(this, 10 + (bwH + 22) / 2, 8 + 40, bwH + 22, 80, 'ui_hud', 0xffffff)).setDepth(1900);
    this.hpBar = ssf0(uiBar(this, 16 + bwH / 2, 42, bwH, 13, 1, 0xef4444)).setDepth(1902);
    this.mpBar = ssf0(uiBar(this, 16 + bwH / 2, 58, bwH, 9, 1, 0x3b82f6)).setDepth(1902);
    this.shieldGlow = ssf0(uiFill(this, 16, 28, bwH, 6, 0xfde68a, 0.25, 0)).setDepth(1901).setVisible(false);
    this.shieldBar = ssf0(uiFill(this, 16, 30, bwH, 4, 0xfde68a, 0.9, 0)).setDepth(1902).setVisible(false);
    this.shieldIcon = iconImage(this, 24, 20, 'shield', { size: 14, color: 0xfde68a }).setScrollFactor(0).setDepth(1902).setVisible(false);
    this._hpTicks = [1, 2, 3].map((q) => ssf0(uiFill(this, 16 + bwH * q * 0.25 - 1, 36, 2, 13, 0x0b0b12, 0.5, 0)).setDepth(1903));
    // Boss bar aset (muncul saat boss hidup).
    this.bossBar = ssf0(uiBar(this, W / 2, this.H - 108, Math.min(420, W - 220), 12, 1, 0xef4444, { frameTint: 0xef4444 })).setDepth(1902).setVisible(false);
    this.bossBarText = this.add.text(W / 2, this.H - 122, '', { fontFamily: F_UI, fontSize: '11px', color: '#fca5a5', fontStyle: 'bold' }).setOrigin(0.5, 1).setScrollFactor(0).setDepth(1903).setVisible(false);
    // v10 ULTIMATE: bar emas + label DI DALAM panel HUD (v9 meluber keluar frame).
    const ubw = Math.min(240, W * 0.4) - 78;
    this.ultBar = ssf0(uiBar(this, 16 + ubw / 2, 76, ubw, 7, 0, 0x92400e, { frameTint: 0xb45309 })).setDepth(1902);
    this.ultLabel = this.add.text(16 + Math.min(240, W * 0.4) - 4, 76, 'ULT [R]', { fontFamily: F_HEAD, fontSize: '8.5px', color: '#fbbf24', stroke: '#0b0b12', strokeThickness: 2 }).setOrigin(1, 0.5).setScrollFactor(0).setDepth(1902);
  }
  renderDungeonHud() {
    if (!this.hudC || !this.hudC.active) return;
    const W = this.W;
    const hp = clamp((this.playerHp == null ? this.maxHp : this.playerHp), 0, this.maxHp);
    const mp = clamp((this.playerMp == null ? this.maxMp : this.playerMp), 0, this.maxMp);
    const bw = Math.min(240, W * 0.4);
    // v9: bar aset — isi tileSprite, presisi pixel saat lebar berubah.
    if (this.hpBar) this.hpBar.setFillRatio(this.maxHp ? hp / this.maxHp : 0);
    if (this.mpBar) this.mpBar.setFillRatio(this.maxMp ? mp / this.maxMp : 0);
    if (this.shieldBar) {
      const sh = this.shieldHp > 0;
      this.shieldBar.setVisible(sh); this.shieldGlow.setVisible(sh); this.shieldIcon.setVisible(sh);
      if (sh) this.shieldBar.displayWidth = Math.max(1, bw * Math.min(1, this.shieldHp / this.maxHp));
    }
    if (this.dungeonHpText && this.dungeonHpText.active) {
      this.dungeonHpText.setText('HP ' + Math.max(0, Math.round(hp)) + (this.shieldHp > 0 ? ' (+' + Math.round(this.shieldHp) + ')' : '') + '   MP ' + Math.max(0, Math.round(mp)) + '/' + this.maxMp);
    }
    if (this.floorText && this.floorText.active) {
      this.floorText.setText('LANTAI ' + this.floor + '/' + this.dungeon.floors + (this.hasChestFloor ? '  •  ADA PETI' : ''));
    }
    if (this.goldText && this.goldText.active) this.goldText.setText(fmt(Data.char.gold) + ' KZC');
    const coinX = W - 16 - (this.goldText.width || 60) - 14;
    if (this.goldCoin && this.goldCoin.active) this.goldCoin.setPosition(coinX, 24);
    if (this.goldText && this.goldText.active) this.goldText.setOrigin(1, 0.5).setPosition(W - 20, 24);
    // v8: bar ULTIMATE + denyut saat penuh (tombol ikut berdenyut).
    if (this.ultBar && this.ultBar.active) {
      const u = clamp((this.ultCharge || 0) / 100, 0, 1);
      this.ultBar.setFillRatio(u);
      if (this.ultBar.__fill) this.ultBar.__fill.setTint(u >= 1 ? 0xf59e0b : 0x92400e);
      if (this.ultLabel && this.ultLabel.active) this.ultLabel.setText(u >= 1 ? 'SIAP! [R]' : 'ULT [R]');
      if (u >= 1 && !this._ultPulse) {
        this._ultPulse = true;
        this.tweens.add({ targets: [this.ultBar, this.ultLabel], alpha: { from: 1, to: 0.4 }, duration: 320, yoyo: true, repeat: -1 });
        if (this.ultBtnRef) this.tweens.add({ targets: this.ultBtnRef, scale: { from: 1, to: 1.14 }, duration: 340, yoyo: true, repeat: -1 });
      } else if (u < 1 && this._ultPulse) {
        this._ultPulse = false;
        try {
          this.tweens.killTweensOf(this.ultBar); this.tweens.killTweensOf(this.ultLabel);
          if (this.ultBtnRef) { this.tweens.killTweensOf(this.ultBtnRef); this.ultBtnRef.setScale(1); }
          if (this.ultBar) this.ultBar.setAlpha(1);
          if (this.ultLabel) this.ultLabel.setAlpha(1);
        } catch (_) {}
      }
    }
    const boss = this.bossRef;
    if (boss && boss.active && boss.hp > 0 && this.bossBar) {
      this.bossBar.setVisible(true); this.bossBarText.setVisible(true);
      this.bossBar.setFillRatio(clamp(boss.hp / boss.hpMax, 0, 1));
      this.bossBarText.setText(boss.monster.name + '  —  BOSS');
    } else if (this.bossBar) {
      this.bossBar.setVisible(false); this.bossBarText.setVisible(false);
    }
  }

  buildDungeonControls() {
    const W = this.W, H = this.H;
    this.dCtrl = [];
    const bs = Math.min(64, W * 0.13);
    const yMain = H - 76;
    const lx = 18 + bs / 2, rx = W - 18 - bs / 2;
    const mk = (x, y, size, iconName, color, cb, extra = {}) => {
      const b = makeButton(this, x, y, size, size, '', { color, onClick: cb, ...extra });
      // HANYA ikon yang boleh dirotasi — area input harus tetap lurus supaya
      // hit-test Phaser tetap akurat.
      const ico = iconImage(this, 0, 0, iconName, { size: size * (extra.small ? 0.42 : 0.5), color: 0xf8fafc });
      if (extra.angle) ico.setAngle(extra.angle);
      b.add(ico);
      // Kontrol layar: HARUS fixed ke kamera (scrollFactor 0), kalau tidak
      // tombolnya "ikut jalan" saat kamera scroll dan tak bisa diketuk.
      // Depth 1905: di atas vignette (899) & dunia, sejajar HUD — tombol di
      // sudut layar tidak pernah tergelapkan efek tepi.
      b.setScrollFactor(0);
      b.setDepth(1905);
      this.dCtrl.push(b);
      return b;
    };
    mk(lx, yMain, bs, 'arrow', 0x334155, null, { angle: 180, onDown: () => { this.holdDirs.add('L'); }, onRelease: () => { this.holdDirs.delete('L'); } });
    mk(lx + bs * 1.15, yMain, bs, 'arrow', 0x334155, null, { onDown: () => { this.holdDirs.add('R'); }, onRelease: () => { this.holdDirs.delete('R'); } });
    const jumpB = mk(lx, yMain - bs * 1.2, bs, 'arrow', 0x2563eb, () => { this.jumpBufUntil = this.time.now + 130; }, { angle: -90 });
    const jumpLabel = this.add.text(0, bs * 0.34, 'LOMPAT', { fontFamily: F_UI, fontSize: '9px', color: '#dbeafe', fontStyle: 'bold' }).setOrigin(0.5).setScrollFactor(0);
    jumpB.add(jumpLabel);
    // Serang (utama) + skill + ramuan + dash.
    mk(rx, yMain - 8, bs * 1.15, Data.char.classKey === 'archer' ? 'bow' : 'sword', 0xdc2626, () => this.attack());
    mk(rx - bs * 1.35, yMain - bs * 1.05, bs * 0.8, 'skill', 0x7c3aed, () => this.useDungeonSkill(), { small: true });
    const potBtn = mk(rx - bs * 0.15, yMain - bs * 1.45, bs * 0.8, 'potion', 0x0ea5e9, () => this.usePotion(), { small: true });
    // Badge jumlah ramuan (heal/mana/eliksir/regen) menempel di tombol.
    this._potBadge = this.add.text(bs * 0.24, -bs * 0.24, '0', { fontFamily: F_HEAD, fontSize: '9px', color: '#0b0b12', backgroundColor: '#7dd3fc', padding: { x: 3, y: 1 } }).setOrigin(0.5).setScrollFactor(0);
    potBtn.add(this._potBadge);
    mk(rx - bs * 1.55, yMain + bs * 0.1, bs * 0.75, 'sparkle', 0x0891b2, () => this.tryDash(0), { small: true });
    // v8: tombol ULTIMATE — ikon bintang aset, berdenyut saat siap.
    this.ultBtnRef = mk(rx - bs * 2.55, yMain - bs * 0.62, bs * 0.8, 'crown', 0xb45309, () => this.castUltimate(), { small: true });
    // Label kecil.
    const addLabel = (x, y, txt) => this.add.text(x, y, txt, { fontFamily: F_UI, fontSize: '8.5px', color: '#cbd5e1', fontStyle: 'bold' }).setOrigin(0.5).setScrollFactor(0).setDepth(1902);
    addLabel(rx - bs * 1.35, yMain - bs * 1.05 + bs * 0.52, 'SKILL');
    addLabel(rx - bs * 0.15, yMain - bs * 1.45 + bs * 0.5, 'RAMUAN');
    addLabel(rx - bs * 1.55, yMain + bs * 0.1 + bs * 0.49, 'DASH');
    addLabel(rx - bs * 2.55, yMain - bs * 0.62 + bs * 0.49, 'ULT');
  }
  onSceneResize() { /* layout kontrol dibiarkan (gameplay tetap ukuran create) */ }
  /* ---------- INTERAKSI: daftar objek + prompt + tombol AKSI ---------- */
  registerInteract(o) {
    o.r = o.r || 64;
    this.interactables.push(o);
    return o;
  }
  buildInteractUI() {
    const W = this.W, H = this.H;
    // Gelembung prompt di atas objek (world-space, ikut kamera dunia).
    this._prompt = this.add.container(0, 0).setDepth(1502).setVisible(false);
    this._promptBg = uiSlice(this, 0, 0, 120, 34, 'ui_prompt', 0xffffff, 16);
    this._prompt.add(this._promptBg);
    this._promptIcon = this.add.image(-34, -5, '__DEFAULT').setDisplaySize(19, 19);
    this._prompt.add(this._promptIcon);
    this._promptLabel = this.add.text(-22, -5, '', { fontFamily: F_PIX, fontSize: '9.5px', color: '#fde68a' }).setOrigin(0, 0.5);
    this._prompt.add(this._promptLabel);
    this._promptKey = this.add.image(46, -5, 'ui_key_e').setDisplaySize(17, 17);
    this._prompt.add(this._promptKey);
    // Tombol AKSI besar (mobile + desktop) — fixed ke kamera.
    this._actBtn = this.add.container(W / 2, H - 138).setScrollFactor(0).setDepth(1906).setVisible(false).setAlpha(0);
    this._actOrb = this.add.image(0, 0, 'ui_orb').setScrollFactor(0).setDisplaySize(68, 68);
    this._actIcon = this.add.image(0, -3, '__DEFAULT').setScrollFactor(0).setDisplaySize(30, 30).setTint(0xfde68a);
    this._actLabel = this.add.text(0, 25, 'AKSI', { fontFamily: F_HEAD, fontSize: '9px', color: '#fde68a', stroke: '#0b0b12', strokeThickness: 2 }).setOrigin(0.5).setScrollFactor(0);
    this._actRing = this.add.image(0, 0, 'fx_tex_ring').setScrollFactor(0).setTint(0xf2c230).setAlpha(0.4).setBlendMode(Phaser.BlendModes.ADD).setScale(68 / 256);
    this._actBtn.add(this._actRing); this._actBtn.add(this._actOrb);
    this._actBtn.add(this._actIcon); this._actBtn.add(this._actLabel);
    const area = makeInteractive(this.add.rectangle(0, 0, 80, 80, 0x000000, 0.001).setScrollFactor(0), { useHandCursor: true });
    this._actBtn.add(area);
    area.on('pointerdown', () => this.doInteract());
    this.tweens.add({ targets: this._actRing, alpha: { from: 0.22, to: 0.55 }, scale: { from: 68 / 256, to: 84 / 256 }, duration: 760, yoyo: true, repeat: -1 });
    // Keyboard E untuk desktop.
    this.input.keyboard.on('keydown-E', () => this.doInteract());
  }
  updateInteract() {
    if (!this.interactables || !this._prompt) return;
    const p = this.player;
    let best = null, bd = 1e9;
    if (p && !this.dead && !this.over) {
      for (const o of this.interactables) {
        if (o.gone) continue;
        if (o.can && !o.can()) continue;
        const ox = o.x != null ? o.x : (o.obj ? o.obj.x : 0);
        const oy = o.y != null ? o.y : (o.obj ? o.obj.y : 0);
        const dx = ox - p.x, dy = (oy - (o.top || 48)) - (p.y - 40);
        const d = Math.sqrt(dx * dx + dy * dy * 0.55);
        if (d < o.r && d < bd) { bd = d; best = o; }
      }
    }
    if (best !== this._interactCur) {
      this._interactCur = best;
      if (best) {
        const oy = best.y != null ? best.y : 0;
        const top = best.top || 60;
        this.tweens.killTweensOf(this._prompt);
        // v12: prompt digeser MENJAUHI pemain — tidak lagi menutupi karakter.
        const awayX = best.x + ((this.player.x < best.x ? 1 : -1) * 30);
        this._prompt.setVisible(true).setPosition(awayX, oy - top - 24).setScale(0.5).setAlpha(1);
        this.tweens.add({ targets: this._prompt, scale: 1, duration: 190, ease: 'Back.easeOut' });
        this.tweens.add({ targets: this._prompt, y: oy - top - 30, duration: 700, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
        const ikey = iconTexture(this, best.icon || 'star', 0xfde68a);
        this._promptIcon.setTexture(ikey).setDisplaySize(19, 19);
        this._promptIcon.clearTint();
        this._promptLabel.setText(best.label || 'INTERAKSI');
        const lw = Math.max(112, this._promptLabel.width + 92);
        this._promptBg.width = lw;
        this._promptIcon.setX(-lw / 2 + 17);
        this._promptLabel.setX(-lw / 2 + 31);
        this._promptKey.setX(lw / 2 - 15);
        this._actIcon.setTexture(ikey).setDisplaySize(30, 30);
        this._actIcon.clearTint();
        this._actBtn.setVisible(true);
        this.tweens.add({ targets: this._actBtn, alpha: 1, duration: 130 });
        this.tweens.add({ targets: this._actBtn, scale: { from: 0.8, to: 1 }, duration: 200, ease: 'Back.easeOut' });
        Sfx.pop();
      } else {
        this._prompt.setVisible(false);
        this.tweens.add({ targets: this._actBtn, alpha: 0, scale: 0.85, duration: 150, onComplete: () => { if (!this._interactCur) this._actBtn.setVisible(false); } });
      }
    }
  }
  doInteract() {
    const o = this._interactCur;
    if (!o || this.dead || this.over) return;
    Sfx.click();
    if (this._actBtn) this.tweens.add({ targets: this._actBtn, scale: { from: 0.9, to: 1 }, duration: 150, ease: 'Back.easeOut' });
    try { o.act(); } catch (_) {}
  }

  floorBanner() {
    const W = this.W, H = this.H;
    const barH = 64;
    // v9: panel banner dari aset putih (tint hitam) — fade in/out sinematik.
    const top = uiFill(this, W / 2, barH / 2, W, barH, 0x000000, 0.75).setScrollFactor(0).setDepth(2100).setAlpha(0);
    const bot = uiFill(this, W / 2, H - barH / 2, W, barH, 0x000000, 0.75).setScrollFactor(0).setDepth(2100).setAlpha(0);
    const t1 = this.add.text(W / 2, H / 2 - 30, 'LANTAI ' + this.floor, { fontFamily: F_HEAD, fontSize: '24px', color: '#fde68a', stroke: '#0b0b12', strokeThickness: 5 }).setOrigin(0.5).setScrollFactor(0).setDepth(2101).setAlpha(0);
    const chestNote = this.hasChestFloor ? 'Ada peti tersembunyi di lantai ini' : 'Lantai ini sunyi — tidak ada peti';
    const t2 = this.add.text(W / 2, H / 2 + 12, this.dungeon.name + '  •  ' + chestNote, { fontFamily: F_UI, fontSize: '14px', color: '#cbd5e1' }).setOrigin(0.5).setScrollFactor(0).setDepth(2101).setAlpha(0);
    const t3 = this.add.text(W / 2, H / 2 + 40, 'Tekan E / tombol AKSI dekat peti, pedagang, altar & pintu keluar', { fontFamily: F_UI, fontSize: '11px', color: '#94a3b8', fontStyle: 'italic' }).setOrigin(0.5).setScrollFactor(0).setDepth(2101).setAlpha(0);
    this.tweens.add({ targets: [t1, t2, t3], alpha: 1, duration: 350, delay: 300 });
    this.tweens.add({ targets: [t1, t2, t3], alpha: 0, y: '-=24', delay: 2100, duration: 400, onComplete: () => { t1.destroy(); t2.destroy(); t3.destroy(); } });
    this.tweens.add({ targets: [top, bot], alpha: 0.75, duration: 350 });
    this.tweens.add({ targets: [top, bot], alpha: 0, delay: 2300, duration: 450, onComplete: () => { top.destroy(); bot.destroy(); } });
  }
  /* ---------- SERANGAN: melee arc (warrior/mage/assassin) atau panah (archer) ---------- */
  attack() {
    const now = this.time.now;
    if (this.dead || this.over || now < this.atkCdUntil) return;
    this.atkCdUntil = now + (Data.char.classKey === 'archer' ? 320 : 380);
    this.atkAnimUntil = now + (Data.char.classKey === 'archer' ? 300 : 340);
    try { this.player.play(this.heroAnim.attack); } catch (_) {}
    if (this.heroGear) this.heroGear.swing();
    const p = this.player;
    // AUTO-AIM MELEE: bila tak ada musuh di arah hadap tapi ada yang dekat di
    // belakang, hadapkan otomatis — serangan terasa responsif, bukan kaku.
    let dir = p.flipX ? -1 : 1;
    let front = false;
    for (const e of this.enemies) {
      if (!e.active || e.hp <= 0 || !e.monster) continue;
      if (Math.sign(e.x - p.x) === dir && Math.abs(e.x - p.x) < 160) { front = true; break; }
    }
    if (!front) {
      let best = null, bd = 160;
      for (const e of this.enemies) {
        if (!e.active || e.hp <= 0 || !e.monster) continue;
        const d = Math.abs(e.x - p.x);
        if (d < bd) { bd = d; best = e; }
      }
      if (best) { dir = Math.sign(best.x - p.x) || 1; p.setFlipX(dir < 0); }
    }
    const atk = (now < this.buffAtkUntil ? 1 + this.buffAtk : 1) * this.baseAtk;
    if (Data.char.classKey === 'mage') {
      // v12 §4: Mage di dungeon = pose cast -> bolt sihir homing. BUKAN melee.
      this.time.delayedCall(110, () => { if (!this.dead && !this.over) this.shootSpellBolt(dir, atk); });
      return;
    }
    if (Data.char.classKey === 'archer') {
      // Pose natarik busur dulu (frame 5->6), panah lepas sesaat kemudian.
      this.time.delayedCall(95, () => { if (!this.dead && !this.over) this.shootArrow(dir, atk); });
      return;
    }
    // Melee: lunge + hitbox depan.
    this.lungeDir = dir; this.lungeUntil = now + 110;
    const hb = { x: p.x + dir * 46, y: p.y - 26 };
    // Slash visual — aset fx/slash (blend ADD, warna class); fallback arc lama.
    const col = (CLASSES[Data.char.classKey] || {}).color || 0xffffff;
    if (this.textures.exists('fx_tex_slash')) {
      const sl = this.add.image(hb.x, hb.y, 'fx_tex_slash').setDepth(879).setTint(col).setBlendMode(Phaser.BlendModes.ADD).setFlipX(dir < 0);
      sl.setScale(0.15); sl.setRotation(dir > 0 ? -0.35 : 0.35);
      this.tweens.add({ targets: sl, scale: 1.2, alpha: 0, duration: 190, ease: 'Quad.easeOut', onComplete: () => sl.destroy() });
    } else {
      // v9: fallback = aset glow diputar (tanpa canvas).
      const sl = this.add.image(hb.x, hb.y, this.textures.exists('fx_tex_glow') ? 'fx_tex_glow' : 'fx_tex_flash').setDepth(880).setTint(col).setBlendMode(Phaser.BlendModes.ADD).setScale(0.18).setFlipX(dir < 0);
      this.tweens.add({ targets: sl, scale: 0.9, alpha: 0, duration: 180, onComplete: () => sl.destroy() });
    }
    // Cleave senjata memperluas jangkauan — reach & band vertikal lebih lega
    // (permintaan: "susah banget buat hit musuh").
    const reach = this.eff.cleave ? 112 : 74;
    let hitAny = false;
    for (const e of this.enemies) {
      if (!e.active || e.hp <= 0 || !e.monster) continue;
      const dx = e.x - p.x, dy = (e.y - e.displayHeight * 0.5) - (p.y - 26);
      if (Math.abs(dx) < reach && Math.abs(dy) < 64 && (dx === 0 || Math.sign(dx) === dir || this.eff.cleave)) {
        const { dmg, crit } = this.damageCalc(atk, e.monster.def || 0);
        this.damageEnemy(e, dmg, dir, crit);
        hitAny = true;
      }
    }
    if (!hitAny) Sfx.dash(); else Sfx.hit();
  }

  /* v12 §4: bolt sihir Mage (dungeon) — homing + spell charge beruntun.
   * 3 cast dalam 4 detik -> bolt diperkuat (lebih besar + AoE + damage x1.4). */
  shootSpellBolt(dir, atk) {
    const p = this.player;
    let target = null, bd = 1e9;
    for (const e of this.enemies) {
      if (!e.active || e.hp <= 0 || !e.monster) continue;
      const dx = e.x - p.x;
      if (Math.sign(dx || dir) !== dir || Math.abs(dx) > 860) continue;
      const d = Math.abs(dx);
      if (d < bd) { bd = d; target = e; }
    }
    const now = this.time.now;
    if (now > (this.mageChargeDUntil || 0)) this.mageChargeD = 0;
    this.mageChargeD = Math.min(3, (this.mageChargeD || 0) + 1);
    this.mageChargeDUntil = now + 4000;
    const empowered = this.mageChargeD >= 3;
    if (empowered) this.mageChargeD = 0;
    const col = empowered ? 0xc084fc : 0x8b5cf6;
    const bolt = this.add.image(p.x + dir * 20, p.y - 38, this.textures.exists('fx_tex_glow') ? 'fx_tex_glow' : 'fx_tex_flash').setDepth(871).setTint(col).setBlendMode(Phaser.BlendModes.ADD).setScale(empowered ? 0.5 : 0.32);
    if (this.textures.exists('fx_tex_glow')) {
      const ch = this.add.image(p.x + dir * 20, p.y - 38, 'fx_tex_glow').setTint(0xffffff).setBlendMode(Phaser.BlendModes.ADD).setScale(0.16).setDepth(870);
      this.tweens.add({ targets: ch, alpha: 0, duration: 180, onComplete: () => ch.destroy() });
    }
    if (empowered) fxNum(this, p.x, p.y - 96, 'MANTRA PENUH', '#c084fc', 11);
    this.spellBolts = this.spellBolts || [];
    this.spellBolts.push({ img: bolt, dir, atk: atk * (empowered ? 1.4 : 1), empowered, target, life: 1500, born: now });
    Sfx.dash();
  }
  updateSpellBolts(now, deltaMs = 16.7) {
    if (!this.spellBolts || !this.spellBolts.length) return;
    const dt = Math.min(50, deltaMs) / 1000;
    const monsterEl = (e) => (e && e.monster) ? (e.monster.element || ((monsterById(e.monster.id) || {}).element) || null) : null;
    for (let i = this.spellBolts.length - 1; i >= 0; i--) {
      const b = this.spellBolts[i];
      const img = b.img;
      if (!img.active || now - b.born > b.life) { if (img.active) img.destroy(); this.spellBolts.splice(i, 1); continue; }
      let vx = b.dir * 620, vy = 0;
      if (b.target && b.target.active && b.target.hp > 0) {
        const tcy = b.target.y - b.target.displayHeight * 0.5;
        vy = clamp((tcy - img.y) * 6, -420, 420);
        if (Math.abs(b.target.x - img.x) < 26 && Math.abs(tcy - img.y) < 46) {
          playVfx(this, 'vfx_arcane', img.x, img.y, { scale: b.empowered ? 1.15 : 0.7, fps: 16, tint: b.empowered ? 0xc084fc : undefined });
          fxSparks(this, img.x, img.y, b.empowered ? 0xc084fc : 0x8b5cf6, b.empowered ? 16 : 8);
          if (b.empowered) { fxRing(this, img.x, img.y, 0xc084fc, 90, 340); shake(this, 4); }
          const hits = [];
          if (b.empowered) { for (const e of this.enemies) { if (!e.active || e.hp <= 0 || !e.monster) continue; if (Math.abs(e.x - img.x) < 96 && Math.abs(e.y - img.y) < 90) hits.push(e); } }
          if (b.target && b.target.active && b.target.hp > 0 && !hits.includes(b.target)) hits.push(b.target);
          for (const e of hits) {
            const em = elemAdvantageInfo(CLASS_ELEM.mage, monsterEl(e));
            const dc = this.damageCalc(b.atk, (e.monster && e.monster.def) || 0);
            this.damageEnemy(e, Math.max(1, Math.round(dc.dmg * em.mult)), Math.sign(e.x - img.x) || 1, dc.crit);
          }
          img.destroy(); this.spellBolts.splice(i, 1); continue;
        }
      }
      img.x += vx * dt; img.y += vy * dt;
      img.setRotation(img.rotation + 0.2);
    }
  }
  shootArrow(dir, atk) {
    const p = this.player;
    // Bidik otomatis: musuh terdekat di arah hadap, TERMASUK yang terbang tinggi.
    let target = null, bd = 1e9;
    for (const e of this.enemies) {
      if (!e.active || e.hp <= 0 || !e.monster) continue;
      const dx = e.x - p.x;
      if (Math.sign(dx || dir) !== dir || Math.abs(dx) > 920) continue;
      const d = Math.abs(dx);
      if (d < bd) { bd = d; target = e; }
    }
    // Kilat moncok busur.
    if (this.textures.exists('fx_tex_glow')) {
      const fl = this.add.image(p.x + dir * 24, p.y - 36, 'fx_tex_glow').setDepth(871).setScale(0.5).setTint(0xfde68a).setBlendMode(Phaser.BlendModes.ADD);
      this.tweens.add({ targets: fl, scale: 0.15, alpha: 0, duration: 140, onComplete: () => fl.destroy() });
    }
    // Panah aset (asset menunjuk KIRI; flip saat menembak ke kanan).
    let img;
    if (this.textures.exists('gear_arrow')) {
      img = this.add.image(p.x + dir * 22, p.y - 36, 'gear_arrow').setDepth(870);
      img.setFlipX(dir > 0).setScale(1.5);
    } else {
      img = uiFill(this, p.x + dir * 20, p.y - 36, 20, 3, 0xe8e0c8).setDepth(870);
    }
    // Bidikan balistik: sudut awal dihitung agar panah MELENGKUNG tepat ke
    // pusat target (musuh terbang tinggi pun tercapai) — homing tinggal koreksi.
    let vy0 = 0;
    if (target) {
      const tcy = target.y - target.displayHeight * 0.5;
      const tta = Math.max(0.14, Math.abs(target.x - p.x) / 880);
      vy0 = clamp((tcy - (p.y - 36)) / tta / 10, -110, 110);
    }
    const a = { img, dir, atk, vx: dir * 880, vy: vy0, target, life: 1500, born: this.time.now, trailAt: 0 };
    this.arrows.push(a);
    Sfx.dash();
  }

  /* Panah diperbarui per-frame: homing ringan + tabrakan inklusif monster terbang. */
  updateArrows(now, deltaMs = 16.7) {
    const dt = Math.min(50, deltaMs) / 1000;
    for (let i = this.arrows.length - 1; i >= 0; i--) {
      const a = this.arrows[i];
      const img = a.img;
      if (!img.active) { this.arrows.splice(i, 1); continue; }
      img.x += a.vx * dt;
      // Homing kuat (pursuit controller): kecepatan vertikal DIAJU menuju titik
      // tumbuk target — pengganti integral lambat lama yang gagal mengejar
      // musuh terbang (panah selalu lewat di bawahnya).
      if (a.target && a.target.active && a.target.hp > 0) {
        const tcy = a.target.y - a.target.displayHeight * 0.5;
        const tta = Math.max(0.09, Math.abs(a.target.x - img.x) / Math.max(240, Math.abs(a.vx)));
        const want = clamp((tcy - img.y) / tta / 10, -26, 26);
        a.vy += clamp((want - a.vy) * 0.38, -10, 10);
      } else {
        a.vy += 0.10 * dt * 60; // tanpa target: melengkung turun natural
      }
      img.y += a.vy * dt * 10;
      img.setAngle(Math.atan2(a.vy * 10, a.vx) * 180 / Math.PI);
      // Jejak cahaya.
      if (this.textures.exists('fx_tex_streak') && now - a.trailAt > 34) {
        a.trailAt = now;
        const tr = this.add.image(img.x, img.y, 'fx_tex_streak').setDepth(869).setScale(0.4, 0.28).setTint(0xfde68a).setAlpha(0.55).setBlendMode(Phaser.BlendModes.ADD).setFlipX(a.dir > 0);
        this.tweens.add({ targets: tr, alpha: 0, scaleX: 0.1, duration: 130, onComplete: () => tr.destroy() });
      }
      // Tabrakan: pita vertikal LEMBUT — monster terbang tetap kena.
      let hit = false;
      for (const e of this.enemies) {
        if (!e.active || e.hp <= 0 || !e.monster) continue;
        const reach = 30 + e.displayWidth * 0.28;
        if (Math.abs(img.x - e.x) > reach) continue;
        const top = e.y - e.displayHeight - 14, bot = e.y + 14;
        if (img.y > top && img.y < bot) {
          const { dmg, crit } = this.damageCalc(a.atk, (e.monster.def || 0) * 0.7);
          this.damageEnemy(e, dmg, a.dir, crit);
          // Impact.
          fxSparks(this, img.x, img.y, crit ? 0xfbbf24 : 0xfde68a, crit ? 16 : 9);
          if (crit && this.textures.exists('fx_tex_glow')) {
            const burst = this.add.image(img.x, img.y, 'fx_tex_glow').setDepth(872).setScale(0.2).setTint(0xfbbf24).setBlendMode(Phaser.BlendModes.ADD);
            this.tweens.add({ targets: burst, scale: 0.9, alpha: 0, duration: 200, onComplete: () => burst.destroy() });
          }
          hit = true;
          break;
        }
      }
      if (hit || now - a.born > a.life || img.x < -60 || img.x > this.worldW + 60 || img.y > this.groundAt(img.x) + 6) {
        if (!hit) { // menancap di tanah sebentar
          img.setAngle(a.dir > 0 ? 8 : -8);
          this.tweens.add({ targets: img, alpha: 0, delay: 260, duration: 300, onComplete: () => img.destroy() });
        } else img.destroy();
        this.arrows.splice(i, 1);
      }
    }
  }

  damageCalc(atk, def) {
    const crit = Math.random() * 100 < this.baseCrit;
    let dmg = Math.max(1, Math.round(atk * RF(0.9, 1.1) - def * 0.4));
    if (crit) dmg = Math.round(dmg * (1.6 + (this.eff.critDmg || 0)));
    if (this.eff.execute && this.lastEnemyHpRatio < 0.3) dmg = Math.round(dmg * (1 + this.eff.execute));
    return { dmg, crit };
  }

  /* ---------- SKILL di dungeon (pakai MP, efek nyata di platformer) ---------- */
  useDungeonSkill() {
    const now = this.time.now;
    if (this.dead || this.over) return;
    const tree = SKILL_TREES[Data.char.classKey] || [];
    const unlocked = tree.filter((s) => s.type === 'active' && SkillState.get(s.id) > 0);
    if (!unlocked.length) { fxNum(this, this.player.x, this.player.y - 90, 'Belum ada skill aktif', '#fca5a5', 11); return; }
    if (this.skillMenu) { this.skillMenu.forEach((o) => o.destroy()); this.skillMenu = null; return; }
    this.skillMenu = [];
    const W = this.W, H = this.H;
    unlocked.slice(0, 4).forEach((s, i) => {
      const lvl = SkillState.get(s.id);
      const eff = skillEffectScaled(s, lvl);
      const b = makeButton(this, W / 2 + (i - Math.min(unlocked.length, 4) / 2 + 0.5) * 180, H - 190, 170, 48, s.name, {
        color: 0x4c1d95, size: 10, icon: skillIconName(s), disabled: this.playerMp < (eff.mp || 0),
        onClick: () => { this.skillMenu.forEach((o) => o.destroy()); this.skillMenu = null; this.castDungeonSkill(s, lvl); },
      });
      b.setScrollFactor(0).setDepth(1950);
      b.add(this.add.text(0, -13, 'Lv' + lvl + '  ' + (eff.mp || 0) + ' MP', { fontFamily: F_UI, fontSize: '9px', color: '#c4b5fd' }).setOrigin(0.5).setScrollFactor(0));
      this.skillMenu.push(b);
    });
    this.time.delayedCall(3500, () => { if (this.skillMenu) { this.skillMenu.forEach((o) => o.destroy()); this.skillMenu = null; } });
  }

  castDungeonSkill(def, lvl) {
    const now = this.time.now;
    const eff = skillEffectScaled(def, lvl);
    if (this.playerMp < (eff.mp || 0)) { fxNum(this, this.player.x, this.player.y - 90, 'MP kurang', '#93c5fd', 11); return; }
    this.playerMp -= eff.mp || 0;
    const p = this.player;
    const color = toColorInt((def.fx && def.fx.color) || '#ffffff', 0xffffff);
    Sfx.skill();
    // v11: pose CAST asli (mage/kelas sihir memakai baris spellcast) + lingkaran
    // sihir menyala di kaki sebelum efek terjadi — terasa seperti game AAA.
    try { this.player.play(this.heroAnim.cast || this.heroAnim.attack); } catch (_) {}
    if ((def.fx && def.fx.kind) || '') {
      const chargeKind = (def.fx && def.fx.kind) || '';
      const isMagic = ['fireball', 'void', 'meteor', 'frost', 'heal', 'bloom', 'manashield', 'poison', 'mark'].includes(chargeKind);
      if (isMagic) playVfx(this, 'vfx_circle', p.x, p.y + 2, { scale: 0.6, fps: 12, depth: 869, tint: color, alpha: 0.9 });
    }
    const atk = (now < this.buffAtkUntil ? 1 + this.buffAtk : 1) * this.baseAtk;
    // Kerusakan AoE/dash.
    if (eff.dmg) {
      const targets = eff.aoe ? this.enemies.filter((e) => e.active && e.hp > 0 && Math.abs(e.x - p.x) < 320 && Math.abs(e.y - p.y) < 200)
                              : this.enemies.filter((e) => e.active && e.hp > 0 && Math.abs(e.x - p.x) < 140 && Math.abs(e.y - p.y) < 120);
      const hits = eff.hits || 1;
      const kind = (def.fx && def.fx.kind) || 'slash';
      // FX per jenis.
      if (kind === 'arrowrain') {
        for (let i = 0; i < 8; i++) {
          const sx = p.x + R(-100, 300) * (p.flipX ? -1 : 1);
          const ar = this.textures.exists('gear_arrow')
            ? this.add.image(sx, p.y - 280, 'gear_arrow').setDepth(870).setScale(1.3).setAngle(90)
            : uiFill(this, sx, p.y - 280, 14, 3, 0xfbbf24).setDepth(870);
          this.tweens.add({ targets: ar, y: p.y - 10, duration: 320 + R(0, 90), onComplete: () => { fxSparks(this, ar.x, ar.y, 0xfbbf24, 5); ar.destroy(); } });
        }
      }
      else if (kind === 'meteor') { this.meteorFx(p.x + 200, p.y - 20, 0xfb923c); playVfx(this, 'vfx_fire', p.x + 200, p.y - 40, { scale: 1.8, fps: 13 }); playExplosion(this, 'orange', p.x + 200, p.y - 34, { scale: 1.4, big: true }); }
      else if (kind === 'spin') { this.tweens.add({ targets: p, angle: 360, duration: 380, onComplete: () => p.setAngle(0) }); }
      else if (kind === 'dash') { const d = p.flipX ? -1 : 1; p.x = clamp(p.x + d * 180, 40, this.worldW - 40); this.slashFxLocal(p.x + d * 40, p.y - 26, color); }
      // v11: peta kind -> VFX aset internet di tiap target kena.
      const KIND_VFX = { fireball: 'vfx_fire', void: 'vfx_arcane', frost: 'vfx_ice', poison: 'vfx_snake', slash: 'vfx_slash', cleave: 'vfx_slash', flurry: 'vfx_slash', execute: 'vfx_slash', dash: 'vfx_slash', arrow: 'vfx_lpc_effects', snipe: 'vfx_lpc_effects', spin: 'vfx_slash' };
      const kv = KIND_VFX[kind];
      for (const t of targets) {
        let total = 0;
        if (kv) playVfx(this, kv, t.x, t.y - t.displayHeight * 0.45, { scale: kind === 'fireball' || kind === 'void' ? 1.15 : 0.85, fps: 16, tint: (kind === 'frost' || kind === 'fireball') ? undefined : color });
        for (let h = 0; h < hits; h++) {
          const { dmg, crit } = this.damageCalc(atk * eff.dmg, (t.monster.def || 0) * (1 - (eff.pierce || 0)));
          this.damageEnemy(t, dmg, Math.sign(t.x - p.x) || 1, crit, true);
          total += dmg;
        }
        if (total > 0) fxNum(this, t.x, t.y - t.displayHeight - 40, def.name.toUpperCase(), hex(color), 11);
      }
      shake(this, 5);
    }
    if (eff.dot) { this.poisonEdge = { pct: eff.dot, until: now + (eff.turns || 3) * 1400 }; fxNum(this, p.x, p.y - 100, 'SENJATA BERACUN', '#a3e635', 11); }
    if (eff.heal || eff.healAoe) {
      const heal = Math.round(atk * (eff.heal || eff.healAoe || 0));
      this.playerHp = Math.min(this.maxHp, this.playerHp + heal);
      playVfx(this, 'vfx_lpc_effects', p.x, p.y - 60, { scale: 1.0, fps: 12, tint: color });
      fxRing(this, p.x, p.y - 34, color, 70, 500);
      fxStar(this, p.x, p.y - 40, color, 0.8);
      fxNum(this, p.x, p.y - 100, '+' + heal + ' HP', '#86efac', 13);
    }
    if (eff.shield) { this.shieldHp += Math.round(this.maxHp * eff.shield); playVfx(this, 'vfx_iceshield', p.x, p.y - 50, { scale: 0.9, fps: 12, tint: 0xfde68a }); fxNum(this, p.x, p.y - 100, 'PERISAI', '#fde68a', 12, true); }
    if (eff.atkBuff) { this.buffAtk = Math.max(this.buffAtk, eff.atkBuff); this.buffAtkUntil = now + (eff.turns || 3) * 1500; playVfx(this, 'vfx_aura_fire', p.x, p.y - 40, { scale: 0.7, fps: 16, tint: color }); fxNum(this, p.x, p.y - 100, 'ATK NAIK', '#fbbf24', 12, true); }
    if (eff.evasion) { this.buffDodge = Math.max(this.buffDodge, eff.evasion); this.buffDodgeUntil = now + (eff.turns || 2) * 1500; }
    if (eff.mark) {
      let best = null, bd = 1e9;
      for (const e of this.enemies) { if (!e.active || e.hp <= 0) continue; const d = dist2(e.x, e.y, p.x, p.y); if (d < bd) { bd = d; best = e; } }
      if (best) { best.markAmp = eff.mark; best.markUntil = now + (eff.turns || 3) * 1500; fxNum(this, best.x, best.y - best.displayHeight - 30, 'TARGET', '#f43f5e', 11); }
    }
    this.renderDungeonHud();
  }
  slashFxLocal(x, y, color) {
    if (this.textures.exists('fx_tex_slash')) {
      const sl = this.add.image(x, y, 'fx_tex_slash').setDepth(880).setTint(color).setBlendMode(Phaser.BlendModes.ADD);
      sl.setScale(0.2);
      this.tweens.add({ targets: sl, scale: 0.85, alpha: 0, duration: 190, ease: 'Quad.easeOut', onComplete: () => sl.destroy() });
      return;
    }
    // v9: fallback = aset glow (tanpa canvas).
    const sl = this.add.image(x, y, this.textures.exists('fx_tex_glow') ? 'fx_tex_glow' : 'fx_tex_flash').setDepth(880).setTint(color).setBlendMode(Phaser.BlendModes.ADD).setScale(0.18);
    this.tweens.add({ targets: sl, scale: 0.85, alpha: 0, duration: 180, onComplete: () => sl.destroy() });
  }

  /* ---------- Damage / kematian musuh ---------- */
  damageEnemy(e, dmg, dir, isCrit, silent = false) {
    if (!e.active || e.hp <= 0) return;
    e.hp -= dmg;
    if (e.hpBarBg) { e.hpBarBg.setVisible(true); e.hpBar.setVisible(true); e.hpBar.displayWidth = Math.max(1, 36 * clamp(e.hp / e.hpMax, 0, 1)); }
    this.lastEnemyHpRatio = e.hp / e.hpMax;
    fxNum(this, e.x + RF(-8, 8), e.y - e.displayHeight - 14, '-' + dmg, isCrit ? '#fbbf24' : '#fca5a5', isCrit ? 20 : 14, isCrit);
    fxSparks(this, e.x - dir * 6, e.y - e.displayHeight * 0.5, isCrit ? 0xfbbf24 : 0xffe08a, isCrit ? 18 : 10);
    e.setTintFill(0xffffff);
    this.time.delayedCall(110, () => { if (e.active) { const def = MONSTER_ASSET[e.monster.id]; e.clearTint(); if (def && def.tint && !e.champion) e.setTint(def.tint); else if (e.champion) e.setTint(0xffe9b0); } });
    // KNOCKBACK beneran: selama jendela _kbUntil AI monster tidak menimpa
    // velocity (dulu ditimpa tiap frame -> knockback nyaris tak terlihat).
    if (e.body && !e.isBoss) {
      e._kbUntil = this.time.now + (isCrit ? 260 : 180);
      e.setVelocityX(dir * (isCrit ? 320 : 210));
      if (e.defFly) e.setVelocityY(-70); else e.setVelocityY(-150);
    }
    if (isCrit && !silent) { fxFlash(this, 0xfff2c2, 70, 0.18); shake(this, 4); fxRing(this, e.x, e.y - e.displayHeight * 0.5, 0xfbbf24, 54, 320); fxStar(this, e.x, e.y - e.displayHeight * 0.5, 0xfbbf24, 0.9); }
    if (!silent) this.hitStop(isCrit ? 85 : 55);
    this.hitCombo++; this.hitComboUntil = this.time.now + 1800;
    this.ultCharge = Math.min(100, (this.ultCharge || 0) + (isCrit ? 6 : 4)); // ULT: pukul = +4/+6
    if (this.hitCombo >= 3 && this.comboText) {
      this.comboText.setText('COMBO x' + this.hitCombo).setAlpha(1);
      this.comboText.setScale(1.3);
      this.tweens.add({ targets: this.comboText, scale: 1, duration: 160 });
      this.comboTextHideAt = this.time.now + 900;
    }
    if (this.eff.lifesteal) {
      const heal = Math.max(1, Math.round(dmg * this.eff.lifesteal));
      this.playerHp = Math.min(this.maxHp, (this.playerHp || this.maxHp) + heal);
    }
    if (this.poisonEdge && this.time.now < this.poisonEdge.until && !e._poisonTick) {
      e._poisonTick = this.time.now;
      e.setTint(0xa3e635);
      this.time.delayedCall(200, () => { if (e.active) { e.clearTint(); const def = MONSTER_ASSET[e.monster.id]; if (def && def.tint && !e.champion) e.setTint(def.tint); } });
      // DoT ringan di platformer.
      const tick = setInterval(() => {
        if (!e.active || e.hp <= 0 || !this.scene.isActive()) { clearInterval(tick); return; }
        e.hp -= Math.round(this.baseAtk * this.poisonEdge.pct * 0.3);
        fxNum(this, e.x, e.y - e.displayHeight - 8, 'racun', '#a3e635', 9);
        if (e.hp <= 0) { clearInterval(tick); this.killEnemy(e); }
      }, 700);
      setTimeout(() => clearInterval(tick), 2500);
    }
    if (e.hp <= 0) this.killEnemy(e);
    this.renderDungeonHud();
  }

  killEnemy(e) {
    if (e.hp > 0 || !e.active || e._dying) return;
    e._dying = true;
    const isMimic = e.monster && e.monster.id === 'mimic';
    stopMonsterAnim(e);
    if (e.aura) e.aura.destroy();
    fxSparks(this, e.x, e.y - e.displayHeight * 0.5, 0xffe08a, 16);
    fxDust(this, e.x, e.y - 6, 4);
    // v13: LEDAKAN aset Craftpix — boss = nuklir, champion = lingkaran, biasa = oranye.
    playExplosion(this, e.isBoss ? 'nuke' : (e.champion ? 'circle' : 'orange'), e.x, e.y - e.displayHeight * 0.42, { scale: e.isBoss ? 1.9 : (e.champion ? 1.25 : 0.85), big: !!e.isBoss });
    // v8: jiwa kecil naik (glow) — sensasi "kill" yang memuaskan.
    if (this.textures.exists('fx_tex_glow')) {
      const soul = this.add.image(e.x, e.y - e.displayHeight * 0.6, 'fx_tex_glow').setTint(0xc4b5fd).setScale(0.35).setAlpha(0.8).setBlendMode(Phaser.BlendModes.ADD).setDepth(1601);
      this.tweens.add({ targets: soul, y: soul.y - 60, alpha: 0, scale: 0.1, duration: 700, onComplete: () => soul.destroy() });
    }
    // v8 FINISHER (kill-cam): musuh terakhir -> slow-mo + zoom punch.
    const aliveLeft = this.enemies.filter((o) => o.active && o.hp > 0 && o.monster && o !== e).length;
    if (aliveLeft === 0 && !this.over) {
      this.physics.world.timeScale = 3.2;
      this.time.delayedCall(320, () => { this.physics.world.timeScale = 1; });
      try { this.cameras.main.zoomTo(1.07, 130, 'Quad.easeOut', () => { this.cameras.main.zoomTo(1, 240, 'Quad.easeInOut'); }); } catch (_) {}
    }
    if (e.hpBarBg) { e.hpBarBg.destroy(); e.hpBar.destroy(); }
    this.tweens.add({ targets: e, alpha: 0, y: e.y + 16, angle: 80, duration: 300, onComplete: () => e.destroy() });
    // KILL STREAK: bunuh beruntun tanpa jeda >4 detik.
    const now = this.time.now;
    if (now - (this._streakAt || 0) < 4000) this._streak = (this._streak || 0) + 1;
    else this._streak = 1;
    this._streakAt = now;
    this.onStreak(this._streak);
    this.ultCharge = Math.min(100, (this.ultCharge || 0) + 8); // ULT: bunuh = +8
    // Reward via Data (server / lokal) + tampilkan.
    Data.dungeonKill({
      monsterId: e.monster.id, floor: this.floor,
      isBoss: !!e.isBoss, isChampion: !!e.champion, isMimic,
    }).then((r) => {
      if (!r) return;
      const cy = e.y - 40;
      this.spawnCoins(e.x, cy, clamp(Math.round((r.gold || 0) / 30) + 2, 3, 9));
      fxNum(this, e.x, cy - 20, '+' + fmt(r.xp || 0) + ' XP', '#c4b5fd', 12);
      fxNum(this, e.x, cy - 2, '+' + fmt(r.gold || 0) + ' KZC', '#fde68a', 12);
      if (r.gems) fxNum(this, e.x + 30, cy - 12, '+' + r.gems + ' Permata', '#7dd3fc', 11);
      for (const d of (r.drops || [])) {
        const it = itemById(d);
        if (!it) continue;
        const ti = tierInfo(it.tier);
        fxNum(this, e.x + RF(-20, 20), cy + 18, it.name, hex(ti.color), 11);
        // Loot beam warna rarity untuk drop item.
        this.lootBeam(e.x + RF(-10, 10), cy + 34, ti.color, tierIndex(it.tier) >= 3);
        const icon = addRarityIcon(this, e.x + RF(-16, 16), cy + 40, d, 30);
        this.tweens.add({ targets: icon, y: cy + 16, alpha: 0, delay: 900, duration: 400, onComplete: () => icon.destroy() });
      }
      Sfx.coin();
    });
    if (isMimic) fxNum(this, e.x, e.y - 70, 'MIMIC DIKALAHKAN', '#fca5a5', 13, true);
    if (e.isBoss || e.champion) { this.lootBeam(e.x, e.y - 30, e.champion ? 0xf2c230 : 0xef4444, true); fxFlash(this, e.champion ? 0xf2c230 : 0xef4444, 300, 0.28); shake(this, 8); }
    this.renderDungeonHud();
  }

  /* Milestone kill streak: banner + bonus MP (aman, tanpa ekonomi server). */
  onStreak(n) {
    const p = this.player;
    if (!p) return;
    if (n === 8) this.bigBanner('RAMPAGE!', 'x8 BERUNTUN', 0xf97316);
    if (n === 15) this.bigBanner('TAK TERBENDUNG!', 'x15 BERUNTUN', 0xef4444);
    if (n === 25) this.bigBanner('LEGENDARIS!', 'x25 BERUNTUN', 0xf2c230);
    if (n >= 3) fxNum(this, p.x, p.y - (p.displayHeight || 84) - 26, 'STREAK x' + n, n >= 10 ? '#fbbf24' : '#fca5a5', n >= 10 ? 15 : 12, n >= 10);
    if (n === 5 || n === 10 || n === 15 || n === 20 || n === 30) {
      const bonus = n >= 2 ? Math.min(30, Math.round(this.maxMp * 0.18)) : 10;
      this.playerMp = Math.min(this.maxMp, this.playerMp + bonus);
      fxNum(this, p.x, p.y - (p.displayHeight || 84) - 48, 'BONUS STREAK +' + bonus + ' MP', '#93c5fd', 13, true);
      fxRing(this, p.x, p.y - 30, 0x93c5fd, 60, 420);
      Sfx.levelup();
      this.renderDungeonHud();
    }
  }

  /* ---------- ALTAR BERKAT: berdoa (interaksi) untuk berkah acak ---------- */
  spawnAltar(ax) {
    const ay = this.groundAt(ax);
    const c = this.add.container(ax, ay).setDepth(6);
    // v9: altar = SPRITE EKSKLUSIF 2-frame (kristal naik-turun).
    let gem = null;
    if (this.textures.exists('itx_altar')) {
      if (!this.anims.exists('itx_altar_glow')) this.anims.create({ key: 'itx_altar_glow', frames: this.anims.generateFrameNumbers('itx_altar', { start: 0, end: 1 }), frameRate: 2, repeat: -1 });
      const a = this.add.sprite(0, 0, 'itx_altar', 0).setOrigin(0.5, 1).setScale(1.25);
      try { a.play('itx_altar_glow'); } catch (_) {}
      c.add(a);
    } else {
      const rockKeys = ['asset_deco_rock1', 'asset_deco_rock2', 'asset_deco_rock3'].filter((k) => this.textures.exists(k));
      if (rockKeys.length) c.add(this.add.image(0, 0, rockKeys[0]).setOrigin(0.5, 1).setScale(1.6));
      gem = this.textures.exists('asset_icon_m_core')
        ? this.add.image(0, -26, 'asset_icon_m_core').setDisplaySize(20, 20)
        : this.add.image(0, -26, 'fx_tex_glow').setTint(0xa5d8ff).setDisplaySize(20, 20);
      c.add(gem);
      this.tweens.add({ targets: gem, y: -34, duration: 1200, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    }
    if (this.textures.exists('fx_tex_glow')) {
      const glow = this.add.image(0, -34, 'fx_tex_glow').setScale(0.85).setTint(0x93c5fd).setAlpha(0.55).setBlendMode(Phaser.BlendModes.ADD);
      c.add(glow);
      this.tweens.add({ targets: glow, alpha: { from: 0.35, to: 0.8 }, scale: { from: 0.75, to: 1.0 }, duration: 1300, yoyo: true, repeat: -1 });
    }
    const label = this.add.text(0, -76, 'ALTAR BERKAT', { fontFamily: F_HEAD, fontSize: '9px', color: '#a5d8ff', stroke: '#0b0b12', strokeThickness: 3 }).setOrigin(0.5);
    c.add(label);
    this.tweens.add({ targets: label, alpha: { from: 0.65, to: 1 }, duration: 900, yoyo: true, repeat: -1 });
    this.altarObj = { c, x: ax, used: false, gem, label };
    // v9: berkah via TOMBOL INTERAKSI / [E].
    this.registerInteract({ x: ax, y: ay, top: 62, r: 68, icon: 'sparkle', label: 'BERDOA', can: () => !!this.altarObj && !this.altarObj.used, act: () => this.tryAltar() });
  }
  tryAltar() {
    const a = this.altarObj;
    if (!a || a.used || this.dead || this.over) return;
    a.used = true;
    const p = this.player;
    const rolls = ['heal', 'atk', 'mp', 'shield'];
    const pickB = pick(rolls);
    if (pickB === 'heal') { this.playerHp = this.maxHp; fxNum(this, p.x, p.y - 100, 'BERKAH: HP PULIH', '#86efac', 14, true); }
    else if (pickB === 'mp') { this.playerMp = this.maxMp; fxNum(this, p.x, p.y - 100, 'BERKAH: MP PENUH', '#93c5fd', 14, true); }
    else if (pickB === 'atk') { this.buffAtk = Math.max(this.buffAtk, 0.35); this.buffAtkUntil = this.time.now + 30000; fxNum(this, p.x, p.y - 100, 'BERKAH: ATK +35%', '#fbbf24', 14, true); }
    else { this.shieldHp += Math.round(this.maxHp * 0.35); fxNum(this, p.x, p.y - 100, 'BERKAH: PERISAI', '#fde68a', 14, true); }
    fxRing(this, a.x, a.y - 40, 0x93c5fd, 90, 620);
    fxFlash(this, 0x93c5fc, 240, 0.2);
    ensurePixelTex(this);
    const em = this.add.particles(a.x, a.y - 34, 'fxpix', { lifespan: 1100, speedY: { min: -140, max: -50 }, speedX: { min: -30, max: 30 }, scale: { start: 1.2, end: 0 }, quantity: 3, frequency: 30, tint: [0x93c5fd, 0xffffff, 0xa5d8ff], blendMode: 'ADD', emitting: false }).setDepth(890);
    em.explode(24);
    this.time.delayedCall(1300, () => em.destroy());
    if (a.gem) a.gem.destroy();
    if (a.label) a.label.destroy();
    Sfx.levelup();
    this.renderDungeonHud();
  }

  /* ---------- RUANG RAHASIA: retakan mencurigakan (interaksi) ---------- */
  spawnSecretDoor(sx) {
    const sy = this.groundAt(sx);
    // v9: retakan = ART EKSKLUSIF (dinding batu + celah menyala samar).
    const c = this.add.container(sx, sy).setDepth(-4);
    if (this.textures.exists('itx_secret_crack')) {
      c.add(this.add.image(0, 0, 'itx_secret_crack').setOrigin(0.5, 1).setScale(1.5));
    } else {
      const rockKeys = ['asset_deco_rock2', 'asset_deco_rock3'].filter((k) => this.textures.exists(k));
      for (let i = 0; i < 3 && rockKeys.length; i++) c.add(this.add.image(0, -i * 26, rockKeys[i % rockKeys.length]).setOrigin(0.5, 1).setScale(1.4).setAlpha(0.96));
    }
    if (this.textures.exists('fx_tex_sparkle')) {
      const sp = this.add.image(0, -44, 'fx_tex_sparkle').setScale(0.4).setTint(0xfde68a).setAlpha(0.8).setBlendMode(Phaser.BlendModes.ADD);
      c.add(sp);
      this.tweens.add({ targets: sp, alpha: { from: 0.25, to: 0.9 }, scale: { from: 0.3, to: 0.5 }, duration: 800, yoyo: true, repeat: -1 });
    }
    this.secretObj = { c, x: sx, opened: false };
    // v9: buka via TOMBOL INTERAKSI / [E].
    this.registerInteract({ x: sx, y: sy, top: 56, r: 66, icon: 'door', label: 'SELIDIKI RETAKAN', can: () => !!this.secretObj && !this.secretObj.opened, act: () => this.trySecret() });
  }
  trySecret() {
    const sec = this.secretObj;
    if (!sec || sec.opened || this.dead || this.over) return;
    sec.opened = true;
    shake(this, 6);
    Sfx.chest();
    fxNum(this, sec.x, sec.y - 110, 'RUANG RAHASIA DITEMUKAN!', '#fde68a', 15, true);
    // Dinding membuka: hancurkan + ganti pintu terbuka.
    this.tweens.add({ targets: sec.c, alpha: 0, y: sec.y + 20, duration: 500, onComplete: () => sec.c.destroy() });
    fxRing(this, sec.x, sec.y - 40, 0xfde68a, 80, 560);
    // Harta bonus: 2-3 peti + pancaran koin.
    const n = R(2, 3);
    for (let i = 0; i < n; i++) {
      const cx = sec.x + (i - (n - 1) / 2) * 74;
      const t = this.time.now + i * 160;
      this.time.delayedCall(t, () => { if (this.scene.isActive()) this.spawnChest(cx); });
    }
    this.spawnCoins(sec.x, sec.y - 40, 10);
  }

  /* ---------- PEDAGANG MISTERIUS: jual ramuan dengan gold ---------- */
  spawnMerchant(mx) {
    const my = this.groundAt(mx);
    const c = this.add.container(mx, my).setDepth(6);
    // v9: pedagang = SPRITE EKSKLUSIF (jubah bertudung + lentera berayun) + kios.
    if (this.textures.exists('itx_merchant_stall')) {
      c.add(this.add.image(-38, -4, 'itx_merchant_stall').setOrigin(0.5, 1).setScale(1.05).setAlpha(0.98));
    }
    let spr = null;
    if (this.textures.exists('itx_merchant')) {
      if (!this.anims.exists('itx_merchant_idle')) this.anims.create({ key: 'itx_merchant_idle', frames: this.anims.generateFrameNumbers('itx_merchant', { start: 0, end: 3 }), frameRate: 4, repeat: -1 });
      spr = this.add.sprite(16, 0, 'itx_merchant', 0).setOrigin(0.5, 1).setScale(1.12);
      try { spr.play('itx_merchant_idle'); } catch (_) {}
      c.add(spr);
    } else if (atlasHas(this, 'imp_idle_anim_f0')) {
      spr = this.add.sprite(0, 0, ATLAS_KEY, 'imp_idle_anim_f0').setOrigin(0.5, 1).setScale(2.4).setTint(0xb8c4d4);
      c.add(spr);
      if (!this.anims.exists('merchant_idle')) this.anims.create({ key: 'merchant_idle', frames: ['f0', 'f1', 'f2'].map((f) => ({ key: ATLAS_KEY, frame: 'imp_idle_anim_' + f })), frameRate: 5, repeat: -1 });
      try { spr.play('merchant_idle'); } catch (_) {}
    }
    if (this.textures.exists('fx_tex_glow')) {
      const lamp = this.add.image(16, -44, 'fx_tex_glow').setScale(0.42).setTint(0xfbbf24).setAlpha(0.75).setBlendMode(Phaser.BlendModes.ADD);
      c.add(lamp);
      this.tweens.add({ targets: lamp, alpha: { from: 0.5, to: 0.95 }, duration: 800, yoyo: true, repeat: -1 });
    }
    if (this.textures.exists('fx_tex_shadow')) {
      c.add(this.add.image(16, -2, 'fx_tex_shadow').setAlpha(0.4).setScale(0.5, 0.28));
    }
    const label = this.add.text(16, -88, 'PEDAGANG MISTERIUS', { fontFamily: F_HEAD, fontSize: '9px', color: '#fde68a', stroke: '#0b0b12', strokeThickness: 3 }).setOrigin(0.5);
    c.add(label);
    this.tweens.add({ targets: label, alpha: { from: 0.75, to: 1 }, duration: 900, yoyo: true, repeat: -1 });
    this.merchantObj = { c, x: mx, open: false };
    // v9: bicara via TOMBOL INTERAKSI / [E].
    this.registerInteract({ x: mx + 16, y: my, top: 66, r: 74, icon: 'bag', label: 'BICARA', can: () => !!this.merchantObj && !this.merchantObj.open, act: () => this.tryMerchant() });
  }
  tryMerchant() {
    const m = this.merchantObj;
    if (!m || m.open || this.dead || this.over) return;
    m.open = true;
    Sfx.coin();
    const W = this.W, H = this.H;
    const bw = Math.min(420, W - 50), bh = 396;
    const panel = this.add.container(W / 2, H / 2).setScrollFactor(0).setDepth(2100);
    // v9: dialog = UI kit aset (panel 9-slice + outline emas + strip judul).
    panel.add(uiFill(this, 3, -bh / 2 + 5, bw, bh, 0x000000, 0.4, 0));
    panel.add(uiSlice(this, 0, 0, bw, bh, 'ui_panel', 0x0d1526));
    panel.add(uiSlice(this, 0, 0, bw - 4, bh - 4, 'ui_outline', 0xfbbf24).setAlpha(0.8));
    panel.add(uiFill(this, -bw / 2 + 2, -bh / 2 + 2, bw - 4, 34, 0x1a1206, 0.9, 0));
    panel.add(this.add.text(0, -bh / 2 + 19, 'PEDAGANG MISTERIUS', { fontFamily: F_HEAD, fontSize: '15px', color: '#fde68a' }).setOrigin(0.5));
    panel.add(this.add.text(0, -bh / 2 + 48, '"Barang aneh, harga jujur. Mungkin."', { fontFamily: F_UI, fontSize: '11px', color: '#94a3b8', fontStyle: 'italic' }).setOrigin(0.5));
    // v10: potret pedagang bertudung (v9 area kosong gelap).
    if (this.textures.exists('itx_merchant')) {
      const mp = this.add.sprite(0, -bh / 2 + 112, 'itx_merchant', 0).setScale(1.7);
      panel.add(mp);
      if (!this.anims.exists('itxz_merchant')) this.anims.create({ key: 'itxz_merchant', frames: this.anims.generateFrameNumbers('itx_merchant', { start: 0, end: 3 }), frameRate: 4, repeat: -1 });
      mp.play('itxz_merchant');
      this.tweens.add({ targets: mp, y: '-=4', duration: 1100, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
      panel.add(this.add.image(0, -bh / 2 + 148, 'fx_tex_shadow').setDisplaySize(72, 18).setAlpha(0.45));
    }
    const offers = ['p_heal_s', 'p_mana', 'p_elixir'];
    const close = () => { panel.destroy(); m.open = false; this.merchantObj = null; };
    offers.forEach((id, i) => {
      // v10 FIX AKAR: ramuan ada di katalog POISONS terpisah — tanpa lookup
      // gabungan ini SEMUA baris jualan pedagang kosong sejak v9.
      const it = itemById(id) || poisonById(id);
      if (!it) return;
      const price = Math.max(5, Math.round((it.price || 50) * 1.25));
      const y = -bh / 2 + 178 + i * 58;
      const row = this.add.container(0, y);
      row.add(uiSlice(this, 0, 0, bw - 50, 52, 'ui_tile', 0x161f33));
      row.add(uiSlice(this, 0, 0, bw - 54, 48, 'ui_outline', 0x334155).setAlpha(0.6));
      const icon = addRarityIcon(this, -bw / 2 + 42, 0, id, 38);
      row.add(icon);
      row.add(this.add.text(-bw / 2 + 72, -10, it.name, { fontFamily: F_UI, fontSize: '12px', color: '#e2e8f0', fontStyle: 'bold' }).setOrigin(0, 0.5));
      row.add(this.add.text(-bw / 2 + 72, 8, (it.desc || '').slice(0, 42), { fontFamily: F_UI, fontSize: '9px', color: '#94a3b8' }).setOrigin(0, 0.5));
      const buyBtn = makeButton(this, bw / 2 - 64, 0, 92, 36, fmt(price) + ' KZC', { color: 0xb45309, size: 11, onClick: async () => {
        const r = await api('/api/rpg/merchant/buy', { method: 'POST', body: { itemId: id } });
        if (r && r.ok) {
          Data.char.inventory[id] = (Data.char.inventory[id] || 0) + 1;
          if (r.wallet) Data.char.gold = r.wallet.gold;
          fxNum(this, this.player.x, this.player.y - 100, it.name + ' dibeli', '#86efac', 12);
          Sfx.coin();
        } else {
          fxNum(this, this.player.x, this.player.y - 100, (r && r.error) || 'Gagal membeli', '#fca5a5', 11);
        }
      } });
      row.add(buyBtn);
      panel.add(row);
    });
    // v9: tombol tutup dari UI kit + SEMUA anak panel fixed ke kamera
    // (tanpa ini area klik tombol bergeser mengikuti scroll kamera dungeon —
    // akar lama "tombol tutup pedagang tidak bisa diklik").
    panel.add(makeButton(this, 0, bh / 2 - 32, 150, 40, 'Tutup', { color: 0x334155, size: 12, onClick: close }));
    ssf0(panel);
  }

  hitStop(ms) {
    if (this._hitStops > 2) return;
    this._hitStops++;
    this.physics.world.timeScale = 4.5;
    this.time.delayedCall(ms, () => { this.physics.world.timeScale = 1; this._hitStops--; });
  }

  /* ---------- BUKA PETI (roll rarity di server / lokal) ---------- */
  async openChest(c) {
    if (c.opened || !c.active) return;
    c.opened = true;
    if (c.glow) c.glow.destroy();
    if (c.openAnim && this.anims.exists(c.openAnim)) c.play(c.openAnim);
    else if (c.tier && this.anims.exists('chestz_open_' + c.tier)) c.play('chestz_open_' + c.tier);
    Sfx.chest();
    const tierBias = c.tier;
    const cy = c.y - 20;
    fxRing(this, c.x, cy, 0xf2c230, 60, 460);
    const loot = await Data.openChest({ floor: this.floor, tier: tierBias });
    if (!loot) { fxNum(this, c.x, cy - 30, 'Peti kosong...', '#94a3b8', 11); return; }
    this.spawnCoins(c.x, cy, clamp(Math.round(loot.gold / 30) + 2, 3, 9));
    const ti = tierInfo(loot.tier);
    // LOOT BEAM: kolom cahaya aset sesuai rarity + percik naik.
    this.lootBeam(c.x, cy, ti.color, tierIndex(loot.tier) >= 3);
    fxNum(this, c.x, cy + 6, '+' + fmt(loot.gold) + ' KZC', '#fde68a', 13);
    if (loot.item) {
      const it = itemById(loot.item) || poisonById(loot.item);
      const card = this.add.container(c.x, cy - 40).setDepth(1650);
      const icon = addRarityIcon(this, 0, 0, loot.item, 46);
      const nameTxt = this.add.text(0, 36, (it || {}).name || loot.item, { fontFamily: F_UI, fontSize: '12px', color: hex(ti.color), fontStyle: 'bold', stroke: '#0b0b12', strokeThickness: 3 }).setOrigin(0.5, 0);
      const tierTxt = this.add.text(0, 54, ti.name.toUpperCase(), { fontFamily: F_HEAD, fontSize: '8px', color: hex(ti.color), stroke: '#0b0b12', strokeThickness: 2 }).setOrigin(0.5, 0);
      card.add([icon, nameTxt, tierTxt]);
      card.setScale(0.5);
      this.tweens.add({ targets: card, scale: 1, y: cy - 66, duration: 260, ease: 'Back.easeOut' });
      this.tweens.add({ targets: card, alpha: 0, y: cy - 96, delay: 1600, duration: 400, onComplete: () => card.destroy() });
      if (tierIndex(loot.tier) >= 3) { fxFlash(this, ti.color, 220, 0.25); shake(this, 5); }
    } else {
      fxNum(this, c.x, cy - 20, 'tidak ada item', '#94a3b8', 10);
    }
    // Pecahan bintang + permata gacha dari peti (pet kini HANYA dari gacha).
    if (loot.shards) {
      fxNum(this, c.x + 26, cy - 8, '+' + loot.shards + ' Pecahan', '#c4b5fd', 12);
      const sh = iconImage(this, c.x + 26, cy - 34, 'star', { size: 22, color: 0xc4b5fd }).setDepth(1651);
      this.tweens.add({ targets: sh, y: cy - 58, alpha: 0, delay: 700, duration: 400, onComplete: () => sh.destroy() });
    }
    if (loot.gems) {
      fxNum(this, c.x - 26, cy - 8, '+' + loot.gems + ' Permata', '#7dd3fc', 12);
      const gm = iconImage(this, c.x - 26, cy - 34, 'sparkle', { size: 22, color: 0x7dd3fc }).setDepth(1651);
      this.tweens.add({ targets: gm, y: cy - 58, alpha: 0, delay: 700, duration: 400, onComplete: () => gm.destroy() });
    }
    this.updatePotionBadge();
    this.renderDungeonHud();
  }

  /* LOOT BEAM: kolom cahaya (aset glow) warna rarity + partikel naik. */
  lootBeam(x, y, color, big) {
    const H = this.H;
    const beam = this.textures.exists('fx_tex_flash')
      ? this.add.image(x, y - H * 0.45, 'fx_tex_flash').setTint(color).setBlendMode(Phaser.BlendModes.ADD).setDepth(889).setAlpha(0).setDisplaySize(big ? 18 : 11, H * 0.9)
      : uiFill(this, x, y - H * 0.45, big ? 16 : 10, H * 0.9, color, big ? 0.42 : 0.3).setBlendMode(Phaser.BlendModes.ADD).setDepth(889).setAlpha(0);
    if (this.textures.exists('fx_tex_glow')) {
      const halo = this.add.image(x, y - 14, 'fx_tex_glow').setDepth(890).setScale(big ? 1.1 : 0.7).setTint(color).setBlendMode(Phaser.BlendModes.ADD).setAlpha(0);
      this.tweens.add({ targets: halo, alpha: 0.8, duration: 200, yoyo: true, onComplete: () => halo.destroy() });
    }
    this.tweens.add({ targets: beam, alpha: { from: 0, to: big ? 0.85 : 0.6 }, scaleY: { from: 0.2, to: 1 }, duration: 240, ease: 'Quad.easeOut' });
    this.tweens.add({ targets: beam, alpha: 0, scaleX: 0.3, delay: 620, duration: 650, onComplete: () => beam.destroy() });
    ensurePixelTex(this);
    const em = this.add.particles(x, y - 6, 'fxpix', {
      lifespan: 900, speedY: { min: -160, max: -70 }, speedX: { min: -18, max: 18 },
      scale: { start: big ? 1.4 : 1, end: 0 }, quantity: big ? 4 : 2, frequency: 40, tint: [color, 0xffffff],
      blendMode: 'ADD', emitting: false,
    }).setDepth(891);
    em.explode(big ? 26 : 14);
    this.time.delayedCall(1200, () => em.destroy());
    if (big) { fxFlash(this, color, 220, 0.22); shake(this, 5); }
  }

  /* ---------- RAMUAN ---------- */
  usePotion() {
    const inv = Data.char.inventory || {};
    const now = this.time.now;
    const hp = this.playerHp == null ? this.maxHp : this.playerHp;
    const mp = this.playerMp == null ? this.maxMp : this.playerMp;
    const usable = Object.keys(inv).filter((id) => poisonById(id) || (itemById(id) && itemById(id).use));
    if (!usable.length) { fxNum(this, this.player.x, this.player.y - 100, 'Tidak ada ramuan', '#fca5a5', 11); return; }
    const infoOf = (id) => {
      const po = poisonById(id);
      if (po) return { id, name: po.name, kind: po.kind, val: po.val, turns: po.turns };
      const it = itemById(id);
      return { id, name: it.name, kind: it.use.kind, val: it.use.val, turns: it.use.turns };
    };
    const pick1 = (kinds) => usable.find((id) => kinds.includes(infoOf(id).kind));
    const potionId =
      (hp < this.maxHp && pick1(['heal', 'elixir', 'regen'])) ||
      (mp < this.maxMp && pick1(['mana', 'elixir', 'manaRegen'])) ||
      pick1(['elixir', 'berserk', 'strength', 'swift', 'shield', 'regen', 'manaRegen', 'heal', 'mana', 'poison', 'venom', 'weaken', 'paralyze']) ||
      usable[0];
    const pz = infoOf(potionId);
    Data.useItem(potionId).then((r) => {
      if (!r.ok) return;
      const hb = 1 + ((this.eff && this.eff.healBoost) || 0);
      const show = (txt, col, crit) => fxNum(this, this.player.x, this.player.y - (this.player.displayHeight || 84) - 12, txt, col, 13, crit);
      switch (pz.kind) {
        case 'elixir': this.playerHp = this.maxHp; this.playerMp = this.maxMp; show('HP & MP PENUH', '#86efac', true); break;
        case 'heal': { const v = Math.round((pz.val || 0) * hb); this.playerHp = Math.min(this.maxHp, hp + v); show('+' + v + ' HP', '#86efac'); break; }
        case 'mana': this.playerMp = Math.min(this.maxMp, mp + (pz.val || 0)); show('+' + pz.val + ' MP', '#93c5fd'); break;
        case 'regen': this.regenHpPotion = pz.val || 0; this.regenHpPotionUntil = now + (pz.turns || 4) * 1000; show('REGEN ' + pz.val + ' HP/s', '#86efac'); break;
        case 'manaRegen': this.regenMpPotion = pz.val || 0; this.regenMpPotionUntil = now + (pz.turns || 4) * 1000; show('FOKUS +' + pz.val + ' MP/s', '#93c5fd'); break;
        case 'strength': case 'berserk': this.buffAtk = Math.max(this.buffAtk, pz.val || 0); this.buffAtkUntil = now + (pz.turns || 3) * 1000; show('ATK +' + Math.round((pz.val || 0) * 100) + '%', '#fbbf24', true); break;
        case 'swift': this.buffDodge = Math.max(this.buffDodge, pz.val || 0); this.buffDodgeUntil = now + (pz.turns || 3) * 1000; show('HINDAR +' + Math.round((pz.val || 0) * 100) + '%', '#93c5fd'); break;
        case 'shield': this.shieldHp += Math.round(this.maxHp * (pz.val || 0)); show('PERISAI', '#fde68a', true); break;
        case 'poison': case 'venom': this.poisonEdge = { pct: 0.12, until: now + (pz.turns || 3) * 1200 }; show('SENJATA BERACUN', '#a3e635'); break;
        case 'weaken': this.weakenVal = pz.val || 0; this.weakenUntil = now + (pz.turns || 3) * 1000; show('MUSUH MELEMAH', '#fca5a5'); break;
        case 'paralyze': {
          let best = null, bd = 1e9;
          for (const e of this.enemies) { if (!e.active || e.hp <= 0) continue; const d = dist2(e.x, e.y, this.player.x, this.player.y); if (d < bd) { bd = d; best = e; } }
          if (best) { best._stunUntil = now + (pz.turns || 2) * 1500; show('MUSUH LUMPUH', '#93c5fd', true); }
          break;
        }
        default: show(pz.name, '#86efac');
      }
      fxRing(this, this.player.x, this.player.y - 30, 0x38bdf8, 58, 420);
      ensurePixelTex(this);
      const p3 = this.add.particles(this.player.x, this.player.y - 30, 'fxpix', {
        speed: { min: 40, max: 120 }, angle: { min: 200, max: 340 }, scale: { start: 1.3, end: 0 },
        alpha: { start: 0.9, end: 0 }, lifespan: 400, quantity: 14, tint: 0x86efac, blendMode: 'ADD', emitting: false,
      }).setDepth(900);
      p3.explode(14);
      this.time.delayedCall(600, () => p3.destroy());
      Sfx.potion();
      this.updatePotionBadge();
      this.renderDungeonHud();
    });
  }
  updatePotionBadge() {
    const inv = Data.char.inventory || {};
    let n = 0;
    for (const id of Object.keys(inv)) {
      // Hanya RAMUAN asli (katalog racun/ramuan) — material edible
      // (jeli slime, ekor tikus, dst) tidak dihitung agar tidak menyesatkan.
      const po = poisonById(id);
      if (po && ['heal', 'mana', 'elixir', 'regen', 'manaRegen'].includes(po.kind)) n += inv[id] || 0;
    }
    if (this._potBadge && this._potBadge.active) this._potBadge.setText(String(n));
  }

  /* ---------- KENA SERANG / MATI ---------- */
  touchEnemy(e) {
    if (e.hp <= 0 || this.dead || this.over || !e.monster) return;
    const now = this.time.now;
    if (now < this.invulnUntil) return;
    this.invulnUntil = now + 900;
    const dodgePct = (this.eff.dodge || 0) + (now < this.buffDodgeUntil ? (this.buffDodge || 0) : 0);
    if (dodgePct > 0 && Math.random() < dodgePct) {
      fxNum(this, this.player.x, this.player.y - (this.player.displayHeight || 84) - 12, 'MENGHINDAR', '#93c5fd', 12);
      Sfx.jump();
      return;
    }
    let dmg = Math.max(1, Math.round(e.monster.atk * RF(0.9, 1.1) - this.baseDef * 0.4));
    if (now < this.weakenUntil) dmg = Math.max(1, Math.round(dmg * (1 - (this.weakenVal || 0))));
    if (this.shieldHp > 0) {
      const absorbed = Math.min(this.shieldHp, dmg);
      this.shieldHp -= absorbed; dmg -= absorbed;
      if (absorbed > 0) fxNum(this, this.player.x, this.player.y - (this.player.displayHeight || 84) - 26, 'TERTAHAN ' + absorbed, '#fde68a', 11);
      if (dmg <= 0) { this.renderDungeonHud(); return; }
    }
    this.player.setTintFill(0xef4444);
    this.time.delayedCall(140, () => { if (this.player.active) this.player.clearTint(); });
    fxNum(this, this.player.x, this.player.y - (this.player.displayHeight || 84) - 12, '-' + dmg, '#fca5a5', 15);
    shake(this, 4); Sfx.hurt();
    fxFlash(this, 0xef4444, 80, 0.15);
    this.playerHp = (this.playerHp == null ? this.maxHp : this.playerHp) - dmg;
    this.ultCharge = Math.min(100, (this.ultCharge || 0) + 10); // ULT: terluka = +10
    const thorns = (this.eff && this.eff.thorns) || 0;
    if (thorns > 0 && e.active && e.hp > 0) {
      const ref = Math.max(1, Math.round(dmg * thorns));
      fxNum(this, e.x, e.y - e.displayHeight - 24, '-' + ref, '#fbbf24', 11);
      e.hp -= ref;
      if (e.hp <= 0) this.killEnemy(e);
    }
    if (this.playerHp <= 0) this.dungeonDeath();
    this.renderDungeonHud();
  }

  dungeonDeath() {
    const rev = (this.eff && this.eff.revive) || 0;
    if (rev > 0 && !this.reviveUsed) {
      this.reviveUsed = true;
      this.playerHp = Math.max(1, Math.round(this.maxHp * rev));
      this.playerMp = Math.max(this.playerMp || 0, Math.round(this.maxMp * 0.3));
      fxRing(this, this.player.x, this.player.y - 30, 0xf97316, 90, 600);
      fxNum(this, this.player.x, this.player.y - (this.player.displayHeight || 84) - 40, 'BANGKIT KEMBALI', '#fb923c', 14, true);
      fxFlash(this, 0xfdbA74, 250, 0.35);
      shake(this, 8); Sfx.levelup();
      this.invulnUntil = this.time.now + 2000;
      this.renderDungeonHud();
      return;
    }
    if (this.dead) return;
    this.dead = true;
    this.physics.pause();
    const W = this.W, H = this.H;
    const bw = Math.min(440, W - 60);
    uiSlice(this, W / 2, H / 2, bw, 230, 'ui_panel', 0x0a0f1c).setAlpha(0.96).setScrollFactor(0).setDepth(2000);
    uiSlice(this, W / 2, H / 2, bw - 4, 226, 'ui_outline', 0xef4444).setScrollFactor(0).setDepth(2000);
    this.add.text(W / 2, H / 2 - 52, 'KALAH', { fontFamily: F_HEAD, fontSize: '26px', color: '#fca5a5' }).setOrigin(0.5).setScrollFactor(0).setDepth(2001);
    this.add.text(W / 2, H / 2 - 6, 'Kamu pingsan di ' + this.dungeon.name + ', Lantai ' + this.floor, { fontFamily: F_UI, fontSize: '13px', color: '#cbd5e1' }).setOrigin(0.5).setScrollFactor(0).setDepth(2001);
    makeButton(this, W / 2, H / 2 + 46, 240, 50, this.towerMode ? 'Coba Lantai Ini Lagi' : 'Coba Lagi', { color: 0x16a34a, size: 15, onClick: () => this.scene.restart({ dungeonId: this.dungeonId, floor: this.floor, mode: this.towerMode ? 'tower' : undefined }) }).setScrollFactor(0).setDepth(2002);
    makeButton(this, W / 2, H / 2 + 104, 240, 44, 'Kembali', { color: 0xdc2626, size: 13, onClick: () => this.scene.start(this.towerMode ? 'Lobby' : 'DungeonSelect') }).setScrollFactor(0).setDepth(2002);
    fxFlash(this, 0xef4444, 200, 0.3);
    Sfx.defeat();
  }

  /* ---------- v8 ULTIMATE: jurus pamungkas per-class (isi: pukul/bunuh/terluka) ---------- */
  castUltimate() {
    const now = this.time.now;
    if (this.dead || this.over) return;
    if ((this.ultCharge || 0) < 100) { fxNum(this, this.player.x, this.player.y - 96, 'ULT belum penuh', '#94a3b8', 11); return; }
    this.ultCharge = 0;
    const cls = Data.char.classKey;
    const p = this.player;
    const atk = (now < this.buffAtkUntil ? 1 + this.buffAtk : 1) * this.baseAtk;
    // Slow-mo sinematik + zoom punch + kilat layar.
    this.physics.world.timeScale = 4;
    this.time.delayedCall(240, () => { this.physics.world.timeScale = 1; });
    try { this.cameras.main.zoomTo(1.05, 120, 'Quad.easeOut', () => { this.cameras.main.zoomTo(1, 200, 'Quad.easeInOut'); }); } catch (_) {}
    fxFlash(this, 0xfff2c2, 180, 0.22);
    shake(this, 7);
    const names = { warrior: 'AMUKAN TOPAN', mage: 'HUJAN METEOR', assassin: 'TARIAN BAYANGAN', archer: 'HUJAN PANAH' };
    this.bigBanner('ULTIMATE!', names[cls] || 'NOVA SUCI', (CLASSES[cls] || {}).color || 0xf2c230);
    Sfx.levelup();
    this.invulnUntil = Math.max(this.invulnUntil || 0, now + 900);
    if (cls === 'warrior') {
      // Badai putaran: 7 gelombang tebasan area selama 1.3 detik.
      const spin = this.time.addEvent({ delay: 180, repeat: 6, callback: () => {
        if (this.dead || this.over) return;
        try { p.setAngle((p.angle || 0) + 120); } catch (_) {}
        fxRing(this, p.x, p.y - 30, 0xf97316, 120, 300);
        this.slashFxLocal(p.x + R(-30, 30), p.y - 30 + R(-16, 16), 0xfbbf24);
        for (const e of this.enemies) {
          if (!e.active || e.hp <= 0 || !e.monster) continue;
          if (Math.abs(e.x - p.x) < 150 && Math.abs(e.y - p.y) < 170) {
            const { dmg, crit } = this.damageCalc(atk * 0.55, (e.monster.def || 0) * 0.5);
            this.damageEnemy(e, dmg, Math.sign(e.x - p.x) || 1, crit, true);
          }
        }
      } });
      this.time.delayedCall(1340, () => { try { spin.remove(); p.setAngle(0); } catch (_) {} });
    } else if (cls === 'mage') {
      // 6 meteor beruntun menghantam musuh hidu.
      const alive = this.enemies.filter((e) => e.active && e.hp > 0 && e.monster);
      for (let i = 0; i < 6; i++) {
        this.time.delayedCall(i * 200, () => {
          if (this.dead || this.over) return;
          const t = alive.length ? alive[i % alive.length] : null;
          const mx = (t ? t.x : p.x + R(-160, 160)) + R(-24, 24);
          const my = this.groundAt(mx);
          this.meteorFx(mx, my - 6, 0xfb923c, () => {
            for (const e of this.enemies) {
              if (!e.active || e.hp <= 0 || !e.monster) continue;
              if (Math.abs(e.x - mx) < 130 && Math.abs(e.y - my) < 190) {
                const { dmg, crit } = this.damageCalc(atk * 0.9, (e.monster.def || 0) * 0.4);
                this.damageEnemy(e, dmg, Math.sign(e.x - mx) || 1, crit);
              }
            }
          });
        });
      }
    } else if (cls === 'assassin') {
      // Tarian bayangan: blink menembus sampai 6 musuh terdekat, crit pasti.
      const targets = this.enemies.filter((e) => e.active && e.hp > 0 && e.monster)
        .map((e) => ({ e, d: Math.abs(e.x - p.x) })).sort((a, b) => a.d - b.d).slice(0, 6).map((o) => o.e);
      if (!targets.length) { fxRing(this, p.x, p.y - 30, 0xa78bfa, 140, 520); fxSparks(this, p.x, p.y - 30, 0xa78bfa, 22); }
      targets.forEach((e, i) => {
        this.time.delayedCall(120 + i * 120, () => {
          if (this.dead || this.over || !e.active || e.hp <= 0) return;
          const gh = this.add.image(p.x, p.y, p.texture.key, p.frame.name).setOrigin(0.5, 1).setScale(p.scaleX, p.scaleY).setFlipX(p.flipX).setDepth(8).setTint(0x7c3aed).setAlpha(0.4);
          this.tweens.add({ targets: gh, alpha: 0, duration: 300, onComplete: () => gh.destroy() });
          p.x = clamp(e.x - (Math.sign(e.x - p.x) || 1) * 34, 40, this.worldW - 40);
          p.setFlipX(e.x > p.x);
          this.slashFxLocal(e.x, e.y - e.displayHeight * 0.4, 0xa78bfa);
          const { dmg } = this.damageCalc(atk * 1.1, (e.monster.def || 0) * 0.3);
          this.damageEnemy(e, Math.round(dmg * 1.5), Math.sign(e.x - p.x) || 1, true);
        });
      });
    } else if (cls === 'archer') {
      // Hujan 14 panah dari langit ke musuh.
      const alive2 = this.enemies.filter((e) => e.active && e.hp > 0 && e.monster);
      for (let i = 0; i < 14; i++) {
        this.time.delayedCall(i * 85, () => {
          if (this.dead || this.over) return;
          const t = alive2.length ? alive2[i % alive2.length] : null;
          const ax = (t ? t.x + R(-26, 26) : p.x + R(-200, 200));
          const ay = t ? t.y - t.displayHeight - 16 : this.groundAt(ax) - 16;
          const ar = this.textures.exists('gear_arrow')
            ? this.add.image(ax + R(-10, 10), ay - 320, 'gear_arrow').setDepth(870).setScale(1.4).setAngle(90)
            : uiFill(this, ax, ay - 320, 16, 3, 0xfbbf24).setDepth(870);
          this.tweens.add({ targets: ar, y: ay, duration: 230, onComplete: () => {
            fxSparks(this, ar.x, ay, 0xfde68a, 7);
            ar.destroy();
            for (const e of this.enemies) {
              if (!e.active || e.hp <= 0 || !e.monster) continue;
              if (Math.abs(e.x - ax) < 56 && Math.abs((e.y - e.displayHeight * 0.5) - ay) < 95) {
                const { dmg, crit } = this.damageCalc(atk * 0.5, (e.monster.def || 0) * 0.6);
                this.damageEnemy(e, dmg, Math.sign(e.x - ax) || 1, crit);
              }
            }
          } });
        });
      }
    } else {
      // Nova suci (default): pulih 35% HP + ledakan area.
      this.playerHp = Math.min(this.maxHp, this.playerHp + Math.round(this.maxHp * 0.35));
      fxRing(this, p.x, p.y - 30, 0xfde68a, 150, 600);
      fxNum(this, p.x, p.y - 110, '+HEAL', '#86efac', 13, true);
      for (const e of this.enemies) {
        if (!e.active || e.hp <= 0 || !e.monster) continue;
        if (Math.abs(e.x - p.x) < 240) {
          const { dmg, crit } = this.damageCalc(atk * 1.2, 0);
          this.damageEnemy(e, dmg, Math.sign(e.x - p.x) || 1, crit);
        }
      }
    }
    this.renderDungeonHud();
  }

  /* Meteor visual (batu aset + jejak api) — onImpact dipanggil saat mendarat. */
  meteorFx(x, groundY, tint, onImpact) {
    const rock = this.add.image(x + 60, groundY - 360, this.textures.exists('asset_deco_rock2') ? 'asset_deco_rock2' : 'fx_tex_flash').setDepth(870).setScale(1.15).setAngle(R(-30, 30));
    const glow = this.textures.exists('fx_tex_glow')
      ? this.add.image(x + 60, groundY - 360, 'fx_tex_glow').setTint(0xfb923c).setScale(0.8).setAlpha(0.75).setBlendMode(Phaser.BlendModes.ADD).setDepth(869)
      : null;
    this.tweens.add({
      targets: [rock, glow].filter(Boolean), x, y: groundY, duration: 380, ease: 'Quad.easeIn',
      onUpdate: () => { if (Math.random() < 0.5) fxSparks(this, rock.x, rock.y, 0xf97316, 2); },
      onComplete: () => {
        if (glow) glow.destroy();
        rock.destroy();
        fxSparks(this, x, groundY - 10, 0xfb923c, 26);
        fxRing(this, x, groundY - 16, 0xf97316, 100, 380);
        fxDust(this, x, groundY - 6, 3);
        shake(this, 8);
        if (onImpact) try { onImpact(x); } catch (_) {}
      },
    });
  }

  /* Banner besar tengah layar (ultimate / milestone streak). */
  bigBanner(l1, l2, color) {
    const W = this.W, H = this.H;
    const t1 = this.add.text(W / 2, H * 0.30, l1, { fontFamily: F_HEAD, fontSize: '30px', color: '#fde68a', stroke: '#0b0b12', strokeThickness: 6 }).setOrigin(0.5).setScrollFactor(0).setDepth(2102).setScale(0.4);
    const t2 = this.add.text(W / 2, H * 0.30 + 30, l2, { fontFamily: F_HEAD, fontSize: '15px', color: hex(color), stroke: '#0b0b12', strokeThickness: 4 }).setOrigin(0.5).setScrollFactor(0).setDepth(2102).setScale(0.4);
    this.tweens.add({ targets: [t1, t2], scale: 1, duration: 240, ease: 'Back.easeOut' });
    this.tweens.add({ targets: [t1, t2], alpha: 0, y: '-=26', delay: 1150, duration: 380, onComplete: () => { t1.destroy(); t2.destroy(); } });
  }

  /* ---------- LANTAI SELESAI: TANPA hadiah (hadiah dari peti & monster) ---------- */
  async completeFloor() {
    if (this.over) return;
    this.over = true;
    Sfx.victory();
    let towerReward = null;
    if (this.towerMode) {
      try {
        const r = await api('/api/rpg/tower/clear', { method: 'POST', body: { floor: this.floor } });
        if (r && r.ok) towerReward = r.rewards;
      } catch (_) {}
      Data.char.towerBest = this.floor;
    } else {
      await Data.completeDungeonFloor(this.dungeonId, this.floor);
    }
    const isLast = this.towerMode ? false : this.floor >= this.dungeon.floors;
    const found = isLast ? Data.maybeDiscoverDungeon(0.30) : null;
    const W = this.W, H = this.H;
    this.physics.pause();
    const bw = Math.min(470, W - 50), bh = 300;
    uiSlice(this, W / 2, H / 2, bw, bh, 'ui_panel', 0x0a0f1c).setAlpha(0.96).setScrollFactor(0).setDepth(2000);
    uiSlice(this, W / 2, H / 2, bw - 4, bh - 4, 'ui_outline', 0xf2c230).setScrollFactor(0).setDepth(2000);
    this.add.text(W / 2, H / 2 - 108, isLast ? 'DUNGEON DITAKLUKKAN' : 'LANTAI ' + this.floor + ' CLEAR', { fontFamily: F_HEAD, fontSize: '16px', color: '#fde68a', align: 'center', wordWrap: { width: bw - 40 } }).setOrigin(0.5).setScrollFactor(0).setDepth(2001);
    iconImage(this, W / 2, H / 2 - 52, 'door', { size: 52, color: 0xf2c230 }).setScrollFactor(0).setDepth(2001);
    this.add.text(W / 2, H / 2 + 8, this.towerMode ? 'Lantai menara ' + this.floor + ' ditaklukkan!' : (isLast ? 'Kamu menaklukkan seluruh dungeon.' : 'Lantai ' + (this.floor + 1) + ' terbuka.'), { fontFamily: F_UI, fontSize: '14px', color: '#e2e8f0' }).setOrigin(0.5).setScrollFactor(0).setDepth(2001);
    const towerTxt = towerReward ? ('Hadiah: +' + fmt(towerReward.gold) + ' KZC, +' + fmt(towerReward.xp) + ' XP, +' + towerReward.gems + ' Permata') : null;
    this.add.text(W / 2, H / 2 + 32, towerTxt || (isLast ? (found ? 'Dungeon baru ditemukan: ' + found.name : 'Cari dungeon lain di daftar.') : 'HP & MP terbawa ke lantai berikutnya.'), { fontFamily: F_UI, fontSize: '12px', color: towerTxt ? '#7dd3fc' : (found ? '#ede9fe' : '#94a3b8'), align: 'center', wordWrap: { width: bw - 60 } }).setOrigin(0.5).setScrollFactor(0).setDepth(2001);
    ensurePixelTex(this);
    const conf = this.add.particles(0, 0, 'fxpix', {
      x: { min: W * 0.2, max: W * 0.8 }, y: -10, speedY: { min: 60, max: 160 }, speedX: { min: -30, max: 30 },
      scale: { min: 0.8, max: 1.6 }, alpha: { start: 1, end: 0.2 }, lifespan: 2600, quantity: 3, frequency: 40,
      tint: [0xfde68a, 0xf2c230, 0x86efac, 0x93c5fd, 0xfca5a5],
    }).setScrollFactor(0).setDepth(1999);
    this.time.delayedCall(2600, () => conf.destroy());
    const backScene = this.towerMode ? 'Lobby' : 'DungeonSelect';
    makeButton(this, W / 2, H / 2 + 96, 250, 52, isLast ? 'Selesai' : (this.towerMode ? 'Naik Lagi' : 'Lantai Berikutnya'), { color: 0x16a34a, icon: 'arrow', size: 14, onClick: () => {
      if (isLast) this.scene.start('DungeonSelect');
      else this.scene.restart({ dungeonId: this.dungeonId, floor: this.floor + 1, hp: Math.max(1, Math.round(this.playerHp)), mp: Math.round(this.playerMp), mode: this.towerMode ? 'tower' : undefined });
    } }).setScrollFactor(0).setDepth(2002);
    const closeBtn = makeButton(this, W / 2 + (bw / 2 - 74), H / 2 + 96, 58, 44, '', { color: 0x1f2937, size: 14, onClick: () => this.scene.start(backScene) }).setScrollFactor(0).setDepth(2002);
    closeBtn.add(iconImage(this, 0, 0, 'exit', { size: 18, color: 0x94a3b8 }));
  }

  /* ---------- LOOP ---------- */
  update(time, delta) {
    if (this.dead || this.over) return;
    this._lastDelta = Math.min(50, delta || 16.7);
    const now = this.time.now;
    // regen MP.
    if (this.playerMp != null && this.maxMp && this.playerMp < this.maxMp) {
      this.playerMp = Math.min(this.maxMp, this.playerMp + 0.06);
      this._hudTick = (this._hudTick || 0) + 1;
      if (this._hudTick % 20 === 0) this.renderDungeonHud();
    }
    if (this.parallax && this.parallax.length) {
      const sx = this.cameras.main.scrollX;
      for (const l of this.parallax) l.obj.tilePositionX = sx * l.factor;
    }
    const p = this.player;
    // Tick regen per detik.
    if (now - this._regenTick >= 1000) {
      this._regenTick = now;
      let hpReg = (this.eff.regen || 0) + (now < this.regenHpPotionUntil ? this.regenHpPotion : 0);
      let mpReg = (this.eff.manaRegen || 0) + (now < this.regenMpPotionUntil ? this.regenMpPotion : 0);
      if (hpReg > 0 && this.playerHp < this.maxHp) { this.playerHp = Math.min(this.maxHp, this.playerHp + hpReg); fxNum(this, p.x + RF(-8, 8), p.y - (p.displayHeight || 60) - 8, '+' + hpReg, '#86efac', 9); }
      if (mpReg > 0 && this.playerMp < this.maxMp) this.playerMp = Math.min(this.maxMp, this.playerMp + mpReg);
      this.renderDungeonHud();
    }
    // Combo text decay.
    if (this.comboText && this.comboTextHideAt && now > this.comboTextHideAt) { this.comboText.setAlpha(0); this.comboTextHideAt = 0; }
    // Gerak.
    const left = this.cursors.left.isDown || this.wasd.A.isDown || this.holdDirs.has('L');
    const right = this.cursors.right.isDown || this.wasd.D.isDown || this.holdDirs.has('R');
    const up = this.cursors.up.isDown || this.wasd.W.isDown || this.space.isDown;
    const airborne = !p.body.blocked.down;
    const atkAnim = now < (this.atkAnimUntil || 0); // animasi serangan tidak dipotong
    // v11: animasi kontekstual — DASH = lari (run), di udara = jump, berhenti
    // dekat musuh = combat idle siaga, selain itu idle/walk biasa.
    const dashing = now < (this.dashUntil || 0);
    let nearEnemy = false;
    for (const e of this.enemies) {
      if (!e.active || e.hp <= 0 || !e.monster) continue;
      if (Math.abs(e.x - p.x) < 190 && Math.abs(e.y - p.y) < 120) { nearEnemy = true; break; }
    }
    if (left) { p.setVelocityX(-245); p.setFlipX(true); }
    else if (right) { p.setVelocityX(245); p.setFlipX(false); }
    else { p.setVelocityX(0); }
    if (!atkAnim) {
      if (airborne) { if (this.heroAnim.jump) p.play(this.heroAnim.jump, true); else p.play(this.heroAnim.walk, true); }
      else if (dashing && this.heroAnim.run) p.play(this.heroAnim.run, true);
      else if (left || right) p.play(this.heroAnim.walk, true);
      else p.play(nearEnemy && this.heroAnim.combat ? this.heroAnim.combat : this.heroAnim.idle, true);
    }
    if (now < (this.lungeUntil || 0)) p.setVelocityX(this.lungeDir * 400);
    if (now < (this.dashUntil || 0)) p.setVelocityX(this.dashDir * 640);
    else if (this._dashGravityOff) { p.body.setAllowGravity(true); this._dashGravityOff = false; }
    if (up && p.body.blocked.down && now > (this.jumpLockUntil || 0)) this.jump();
    if (now < this.jumpBufUntil && p.body.blocked.down) { this.jumpBufUntil = 0; this.jump(); }
    if (p.body.blocked.down) { this.coyoteUntil = now + 120; this.airJumps = 1; }
    // Step assist.
    if (p.body.blocked.down && (p.body.blocked.left || p.body.blocked.right) && now > (this.stepHopUntil || 0) && now >= (this.dashUntil || 0)) {
      const dirB = p.body.blocked.left ? -1 : 1;
      const aheadY = this.groundAt(p.x + dirB * 42);
      if (aheadY < p.y - 12 && aheadY > p.y - 110) { p.setVelocityY(-360); this.stepHopUntil = now + 300; }
    }
    // v8: debu mendarat (aset smoke) + squash — sensasi berat saat mendarat.
    if (this.wasAirborne && !airborne && p.body.velocity.y >= 0) {
      fxDust(this, p.x, p.y - 4, 3);
      this.squash(1.12, 0.88);
    }
    this.wasAirborne = airborne;
    // Bayangan & cahaya ikuti.
    if (this.shadow) this.shadow.setPosition(p.x, this.groundAt(p.x) + 2);
    if (this.playerLight) this.playerLight.setPosition(p.x, p.y - 40);

    // AI musuh + panah archer.
    this.updateEnemies(now);
    this.updateArrows(now, this._lastDelta || 16.7);
    this.updateSpellBolts(now, this._lastDelta || 16.7);
    this.updateCoins(now, this._lastDelta || 16.7);
    // Assassin: jejak bayangan saat bergerak cepat.
    if (Data.char.classKey === 'assassin' && now > this._ghostAt && Math.abs(p.body.velocity.x) > 200) {
      this._ghostAt = now + 110;
      const gh = this.add.image(p.x, p.y, p.texture.key, p.frame.name).setOrigin(0.5, 1).setScale(p.scaleX, p.scaleY).setFlipX(p.flipX).setDepth(8).setTint(0x7c3aed).setAlpha(0.35);
      this.tweens.add({ targets: gh, alpha: 0, duration: 260, onComplete: () => gh.destroy() });
    }
    // v11: Pet menyerang otomatis via PROYEKTIL (damage saat kena) + ULTIMATE
    // evolusi terakhir meledak tiap serangan ke-6 (AoE sinematik).
    if (this.petComp && !this.petComp.dead && now >= this.petNextAttack) {
      let target = null, best = 340 * 340;
      for (const e of this.enemies) {
        if (!e.active || e.hp <= 0 || !e.monster) continue;
        const d2 = (e.x - p.x) * (e.x - p.x) + (e.y - p.y) * (e.y - p.y);
        if (d2 < best) { best = d2; target = e; }
      }
      if (target) {
        const pet = this.petComp.pet;
        const stage = (PetState.stage ? PetState.stage(PetState.active) : 1) || 1;
        const evo = PET_EVOLUTION[pet.id];
        if (this.petDungeonHits == null) this.petDungeonHits = 0;
        this.petDungeonHits++;
        this.petNextAttack = now + 1600;
        this.petComp.attack();
        const pcx = this.petComp.container.x, pcy = this.petComp.container.y;
        // ULTIMATE stage 2: tiap serangan ke-6.
        if (stage >= 2 && evo && evo.ultimate && this.petDungeonHits % 6 === 0) {
          Sfx.ult();
          fxNum(this, pcx, pcy - 64, '★ ' + evo.ultimate.name, pet.color, 12, true);
          petUltimateCinematic(this, pet, pcx, pcy, pet.element, () => {
            const base = this.petAtk * evo.ultimate.power * petSkillScale(PetState.activeLevel || 1);
            for (const e of this.enemies) {
              if (!e.active || e.hp <= 0 || !e.monster) continue;
              if (Math.abs(e.x - pcx) > 340 || Math.abs(e.y - pcy) > 220) continue;
              this.damageEnemy(e, Math.max(6, Math.round(base * RF(0.9, 1.15))), Math.sign(e.x - pcx) || 1, true, true);
            }
          });
        } else {
          // proyektil biasa: ledakan di target = damage di sana (bukan instan).
          const dmg = Math.max(2, Math.round(this.petAtk * RF(0.8, 1.2)));
          fxPetProjectile(this, pcx, pcy, target.x, target.y, pet.element, () => {
            if (!target.active || target.hp <= 0) return;
            this.damageEnemy(target, dmg, Math.sign(target.x - pcx) || 1, false, true);
          });
          if (Math.random() < 0.30) fxNum(this, pcx, pcy - 52, pet.name, pet.color, 9);
        }
      }
    }
    // Mimic reveal saat pemain BENAR-BENAR menempel (kejutan tetap ada).
    for (const m of this.mimics) {
      if (m.revealed || !m.active) continue;
      if (Math.abs(m.x - p.x) < 34 && Math.abs(m.y - p.y) < 60) this.revealMimic(m);
    }
    // v9: sistem interaksi — prompt + tombol AKSI mengikuti objek terdekat.
    this.updateInteract();
  }

  updateEnemies(now) {
    const p = this.player;
    for (const e of this.enemies) {
      if (!e.active || e.hp <= 0 || !e.monster) continue;
      // Bar HP mengikuti musuh.
      if (e.hpBarBg && e.hpBarBg.visible) {
        e.hpBarBg.setPosition(e.x, e.y - e.displayHeight - 10);
        e.hpBar.setPosition(e.x, e.y - e.displayHeight - 10);
      }
      if (e._stunUntil && now < e._stunUntil) { e.setVelocityX(0); continue; }
      // Sedang terpental (knockback): biarkan momentumnya selesai dulu.
      if (e._kbUntil && now < e._kbUntil) continue;
      const dx = p.x - e.x;
      const dist = Math.abs(dx);
      if (e.isBoss) {
        // v8 TELEGRAPH SLAM: tiap ~5 detik boss men-charge serangan area —
        // cincin peringatan merah menyala di posisi pemain, lalu HANTAM.
        if (e._slamPhase === 1 && now >= (e._slamHitAt || 0)) {
          e._slamPhase = 0; e.nextAtk = now + 2200;
          const px2 = e._slamX != null ? e._slamX : e.x;
          fxRing(this, px2, e.y - 14, 0xef4444, 190, 420);
          fxSparks(this, px2, e.y - 16, 0xf97316, 30);
          fxDust(this, px2, e.y - 4, 5);
          shake(this, 9); Sfx.hurt();
          try { this.cameras.main.zoomTo(1.04, 90, 'Quad.easeOut', () => { this.cameras.main.zoomTo(1, 150); }); } catch (_) {}
          if (Math.abs(p.x - px2) < 165 && p.y > e.y - 230) this.touchEnemy(e);
          e.setTintFill(0xffffff);
          this.time.delayedCall(120, () => { if (e.active) { e.clearTint(); const ddef = MONSTER_ASSET[e.monster.id]; if (ddef && ddef.tint) e.setTint(ddef.tint); } });
        } else if (e._slamPhase === 1) {
          e.setVelocityX(0); playMonsterAnim(this, e, e.monster, false);
        } else if ((e._nextSlamAt || 0) && now >= e._nextSlamAt && dist < 460) {
          e._slamPhase = 1; e._slamHitAt = now + 950; e._slamX = p.x; e._nextSlamAt = 0;
          fxNum(this, e.x, e.y - e.displayHeight - 26, '!!', '#ef4444', 20, true);
          if (this.textures.exists('fx_tex_ring')) {
            const warn = this.add.image(p.x, e.y - 12, 'fx_tex_ring').setTint(0xef4444).setAlpha(0.55).setBlendMode(Phaser.BlendModes.ADD).setScale(300 / 256).setDepth(848);
            this.tweens.add({ targets: warn, alpha: { from: 0.25, to: 0.65 }, scale: { from: 300 / 256, to: 345 / 256 }, duration: 200, yoyo: true, repeat: 4, onComplete: () => warn.destroy() });
          }
          Sfx.dash();
        } else {
          if ((e._nextSlamAt || 0) === 0) e._nextSlamAt = now + R(4200, 6500);
          if (dist > 90) { e.setVelocityX(Math.sign(dx) * 95); playMonsterAnim(this, e, e.monster, true); e.setFlipX(dx < 0); }
          else { e.setVelocityX(0); playMonsterAnim(this, e, e.monster, false); }
          if (dist < 120 && now > e.nextAtk) { e.nextAtk = now + 1400; this.touchEnemy(e); fxRing(this, e.x + Math.sign(dx) * 40, e.y - 30, 0xef4444, 50, 300); }
        }
      } else if (e.defFly) {
        // Terbang: melayang menuju pemain.
        const tx = e.homeX + Math.sin(now / 900 + e.homeX) * 140;
        const ty = e.homeY + Math.sin(now / 700 + e.homeX) * 26;
        if (dist < 260) { e.setVelocityX(Math.sign(dx) * 85); e.setVelocityY(Math.sign(p.y - 46 - e.y) * 42); }
        else { e.setVelocityX(Math.sign(tx - e.x) * 40); e.setVelocityY(Math.sign(ty - e.y) * 26); }
        e.setFlipX(dx < 0);
        playMonsterAnim(this, e, e.monster, dist < 260);
      } else {
        // Darat: patroli, kejar bila dekat, serang bila sangat dekat.
        if (dist < 240) {
          e.state = 'chase';
          e.setFlipX(dx < 0);
          if (dist > 44) { e.setVelocityX(Math.sign(dx) * 120); playMonsterAnim(this, e, e.monster, true); }
          else { e.setVelocityX(0); playMonsterAnim(this, e, e.monster, false); }
          if (dist < 70 && now > (e.nextAtk || 0)) { e.nextAtk = now + 1100; this.touchEnemy(e); }
        } else if (e.state === 'chase' && dist > 420) {
          e.state = 'patrol';
        } else if (e.state === 'patrol') {
          if (Math.abs(e.x - e.homeX) > 110) e.dir = -Math.sign(e.x - e.homeX);
          e.setVelocityX(e.dir * 38);
          e.setFlipX(e.dir < 0);
          playMonsterAnim(this, e, e.monster, true);
          if (Math.random() < 0.004) e.dir = -e.dir;
        }
      }
    }
  }

  jump() {
    const p = this.player;
    if (p.body.blocked.down || this.time.now < this.coyoteUntil) {
      p.setVelocityY(-560);
      this.airJumps = 1;
      this.jumpLockUntil = this.time.now + 220;
      this.squash(1.18, 0.82);
      Sfx.jump();
    } else if (this.airJumps > 0) {
      this.airJumps--;
      p.setVelocityY(-500);
      this.squash(1.18, 0.82);
      fxRing(this, p.x, p.y - 6, 0x93c5fd, 34, 280);
      Sfx.jump();
    }
  }
  jumpCut() {
    const p = this.player;
    if (p.body.velocity.y < -180) p.setVelocityY(-180);
  }
  tryDash(dir) {
    const now = this.time.now;
    if (this.dead || this.over || now < this.dashCdUntil) return;
    this.dashCdUntil = now + 900;
    this.dashDir = dir || (this.player.flipX ? -1 : 1);
    this.dashUntil = now + 210;
    this.player.body.setAllowGravity(false);
    this.player.setVelocityY(0);
    this._dashGravityOff = true;
    // v8: after-image = siluet sprite hero ASLI (bukan kotak) + garis kecepatan
    // + i-frame (kebal selama dash) — dash jadi juru selamat beneran.
    for (let i = 0; i < 3; i++) {
      const ghost = this.add.image(this.player.x - this.dashDir * i * 22, this.player.y, this.player.texture.key, this.player.frame.name)
        .setOrigin(0.5, 1).setScale(this.player.scaleX, this.player.scaleY).setFlipX(this.player.flipX)
        .setDepth(8).setTint(0x7dd3fc).setAlpha(0.30 - i * 0.07);
      this.tweens.add({ targets: ghost, alpha: 0, duration: 300, onComplete: () => ghost.destroy() });
    }
    if (this.textures.exists('fx_tex_streak')) {
      for (let i = 0; i < 4; i++) {
        const ln = this.add.image(this.player.x - this.dashDir * R(10, 60), this.player.y - R(18, 58), 'fx_tex_streak')
          .setFlipX(this.dashDir > 0).setScale(R(0.25, 0.5), 0.10).setAlpha(0.5).setBlendMode(Phaser.BlendModes.ADD).setDepth(7);
        this.tweens.add({ targets: ln, alpha: 0, duration: 240, onComplete: () => ln.destroy() });
      }
    }
    this.invulnUntil = Math.max(this.invulnUntil || 0, this.dashUntil);
    Sfx.dash();
  }
  squash(sx, sy) {
    const p = this.player;
    p.setScale(this.baseScale * sx, this.baseScale * sy);
    this.tweens.add({ targets: p, scaleX: this.baseScale, scaleY: this.baseScale, duration: 160, ease: 'Quad.easeOut' });
  }
}
/* ============================================================================
 * 9. SCENE: INVENTORY (grid AAA) / SKILL TREE (AAA) / PANDAI BESI
 * ========================================================================== */
/* ---------- KOLEKSI PET: sahabat kecil penemani perjalanan ---------- */

/* ============================================================ GACHA PERMATA */
class GachaScene extends Phaser.Scene {
  constructor() { super('Gacha'); }
  create() {
    const W = this.scale.width, H = this.scale.height;
    this.bg = buildLobbyBackground(this);
    uiFill(this, W / 2, H / 2, W, H, 0x060a14, 0.86);
    this.add.text(W / 2 + 2, 37, 'GACHA PERMATA', { fontFamily: F_HEAD, fontSize: '24px', color: '#0b0b12' }).setOrigin(0.5);
    this.add.text(W / 2, 34, 'GACHA PERMATA', { fontFamily: F_HEAD, fontSize: '24px', color: '#f5d0fe', stroke: '#0b0b12', strokeThickness: 2 }).setOrigin(0.5);
    this.add.text(W / 2, 60, 'Satu-satunya cara mendapatkan sahabat pet', { fontFamily: F_UI, fontSize: '12.5px', color: '#94a3b8' }).setOrigin(0.5);
    makeButton(this, 54, 34, 72, 40, 'Kembali', { color: 0x334155, icon: 'back', size: 12, onClick: () => this.scene.start('Lobby') });

    this.gems = (Data.char && Data.char.gems) || 0;
    this.shards = (Data.char && Data.char.petShards) || 0;
    this.pity = { epic: 0, legendary: 0, mythic: 0 };
    this.rate = null;

    // Saldo + pity dari server.
    api('/api/rpg/gacha').then((d) => {
      if (d && d.ok) {
        this.gems = d.gems; this.shards = d.petShards; this.pity = d.pity || this.pity; this.rate = d;
        if (Data.char) { Data.char.gems = d.gems; Data.char.petShards = d.petShards; }
        this.refreshTop();
      }
    });

    // Tabel peluang.
    const ratesY = 92;
    const panelW = Math.min(560, W - 24);
    // v9: tabel peluang = panel aset 9-slice.
    uiSlice(this, W / 2, ratesY + 42, panelW, 84, 'ui_panel', 0x0b1220).setAlpha(0.92);
    uiSlice(this, W / 2, ratesY + 42, panelW - 4, 80, 'ui_outline', 0x334155).setAlpha(0.8);
    const rOrder = ['common', 'uncommon', 'rare', 'epic', 'legendary', 'mythic'];
    const rw = panelW / 3;
    rOrder.forEach((r, i) => {
      const col = i % 3, row = Math.floor(i / 3);
      const x = W / 2 - panelW / 2 + col * rw + rw / 2;
      const y = ratesY + 22 + row * 40;
      const info = PET_RARITY_INFO[r];
      this.add.text(x, y, info.name + '  ' + Math.round(GACHA.rates[r] * 1000) / 10 + '%', { fontFamily: F_UI, fontSize: '11px', color: info.color, fontStyle: 'bold' }).setOrigin(0.5);
    });

    // Pity bar.
    const pityY = ratesY + 96;
    this.add.text(W / 2, pityY, 'JAMINAN (pity): Epic+ tiap ' + GACHA.pityEpicAt + '  •  Legendary+ tiap ' + GACHA.pityLegendaryAt + '  •  MYTHIC tiap ' + GACHA.pityMythicAt, { fontFamily: F_UI, fontSize: '10.5px', color: '#94a3b8' }).setOrigin(0.5);
    this.pityBars = [0, 1, 2].map(() => null);
    this.refreshTop();

    // Pratinjau pet berputar.
    this.showcase = this.add.container(W / 2, H * 0.44).setDepth(2);
    this.showcaseIdx = 0;
    this.showPet(PET_ORDER[Math.floor(Math.random() * PET_ORDER.length)]);
    this.time.addEvent({ delay: 2600, loop: true, callback: () => {
      this.showcaseIdx = (this.showcaseIdx + 1) % PET_ORDER.length;
      this.showPet(PET_ORDER[this.showcaseIdx]);
    } });

    // Tombol tarik.
    const by = H * 0.66;
    const btnW = Math.min(225, (W - 40) / 2 - 6);
    const gachaBtn = (x, label, cost, color, icon, fn) => {
      const b = makeButton(this, x, by, btnW, 58, label, { color, icon, size: 13, onClick: fn });
      b.labelText.setY(-9);
      b.add(this.add.text(0, 13, cost, { fontFamily: F_UI, fontSize: '11px', color: '#e9d5ff', fontStyle: 'bold' }).setOrigin(0.5, 0.5));
      return b;
    };
    gachaBtn(W / 2 - (btnW / 2 + 5), 'Tarik 1x', fmt(GACHA.cost) + ' Permata', 0x7c3aed, 'sparkle', () => this.pull(1));
    gachaBtn(W / 2 + (btnW / 2 + 5), 'Tarik 10x', fmt(GACHA.cost10) + ' Permata', 0xbe185d, 'star', () => this.pull(10));
    makeButton(this, W / 2, by + 72, 340, 46, 'Tukar ' + fmt(GACHA.goldToGems.rate) + ' KZC jadi ' + GACHA.goldToGems.gems + ' Permata', { color: 0xb45309, icon: 'coin', size: 10, onClick: async () => {
      const r = await api('/api/rpg/gems/exchange', { method: 'POST', body: { times: 1 } });
      if (r && r.ok) { this.gems = r.gems; if (Data.char) Data.char.gems = r.gems; this.refreshTop(); Sfx.coin(); fxNum(this, W / 2, by - 20, '+' + GACHA.goldToGems.gems + ' Permata', '#7dd3fc', 13, true); }
      else fxNum(this, W / 2, by - 20, (r && r.error) || 'Gagal menukar', '#fca5a5', 11);
    } });
    this.add.text(W / 2, H - 20, 'Duplikat berubah jadi pecahan bintang untuk EVOLUSI pet', { fontFamily: F_UI, fontSize: '10.5px', color: '#64748b' }).setOrigin(0.5);
  }

  refreshTop() {
    if (this.saldoTxt) this.saldoTxt.destroy();
    if (this.shardTxt) this.shardTxt.destroy();
    this.saldoTxt = this.add.container(this.scale.width - 130, 34).setDepth(5);
    this.saldoTxt.add(iconImage(this, -60, 0, 'sparkle', { size: 18, color: 0x7dd3fc }));
    this.saldoTxt.add(this.add.text(-44, 0, fmt(this.gems) + ' Permata', { fontFamily: F_UI, fontSize: '13px', color: '#7dd3fc', fontStyle: 'bold' }).setOrigin(0, 0.5));
    this.shardTxt = this.add.container(this.scale.width - 130, 58).setDepth(5);
    this.shardTxt.add(iconImage(this, -60, 0, 'star', { size: 16, color: 0xc4b5fd }));
    this.shardTxt.add(this.add.text(-44, 0, fmt(this.shards) + ' Pecahan', { fontFamily: F_UI, fontSize: '11px', color: '#c4b5fd' }).setOrigin(0, 0.5));
    // Pity visual — v9: bar aset (frame + isi tileSprite).
    if (this.pityBars) {
      if (this._pityLabels) { this._pityLabels.forEach((t) => t.destroy()); this._pityLabels = []; }
      const W = this.scale.width;
      const bw = 300, bx = W / 2 - bw / 2;
      const draws = [
        { label: 'Epic+', cur: this.pity.epic, max: GACHA.pityEpicAt, color: 0xc084fc },
        { label: 'Leg+', cur: this.pity.legendary, max: GACHA.pityLegendaryAt, color: 0xfacc15 },
        { label: 'MYTHIC', cur: this.pity.mythic, max: GACHA.pityMythicAt, color: 0xf43f5e },
      ];
      draws.forEach((d, i) => {
        const x0 = bx + i * (bw / 3);
        if (this.pityBars[i]) this.pityBars[i].destroy();
        this.pityBars[i] = uiBar(this, x0 + (bw / 3 - 8) / 2, 202, bw / 3 - 8, 8, clamp(d.cur / d.max, 0, 1), d.color, { frameTint: 0x1e293b });
        this.addExistingPityLabel(d, x0, 214);
      });
    }
  }
  addExistingPityLabel(d, x, y) {
    if (!this._pityLabels) this._pityLabels = [];
    const t = this.add.text(x, y, d.label + ' ' + d.cur + '/' + d.max, { fontFamily: F_UI, fontSize: '8.5px', color: '#' + d.color.toString(16).padStart(6, '0') }).setOrigin(0, 0);
    this._pityLabels.push(t);
  }

  showPet(petId) {
    this.showcase.removeAll(true);
    const pet = PETS[petId];
    if (!pet) return;
    const rar = PET_RARITY_INFO[pet.rarity];
    if (petTexExists(this, petId, 1)) {
      const spr = petAddSprite(this, 0, 0, petId, 1).setOrigin(0.5, 1).setScale(2.8);
      this.showcase.add(spr);
      this.tweens.add({ targets: spr, y: '-=8', duration: 900, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    }
    this.showcase.add(this.add.text(0, 34, pet.name + ' — ' + pet.species, { fontFamily: F_UI, fontSize: '13px', color: rar.color, fontStyle: 'bold', stroke: '#0b0b12', strokeThickness: 3 }).setOrigin(0.5));
    this.showcase.add(this.add.text(0, 52, rar.name + '  •  ' + (PET_ELEMENT_INFO[pet.element] || {}).name, { fontFamily: F_UI, fontSize: '11px', color: '#94a3b8' }).setOrigin(0.5));
    this.showcase.setAlpha(0); this.showcase.setScale(0.8);
    this.tweens.add({ targets: this.showcase, alpha: 1, scale: 1, duration: 260, ease: 'Back.easeOut' });
  }

  async pull(count) {
    if (this._pulling) return;
    this._pulling = true;
    let data = null;
    const r = await api('/api/rpg/gacha/pull', { method: 'POST', body: { count } });
    if (r && r.ok) {
      data = r;
      this.gems = r.gems; this.shards = r.petShards; this.pity = r.pity || this.pity;
      if (Data.char) { Data.char.gems = r.gems; Data.char.petShards = r.petShards; }
      PetState.applyGacha(r);
    } else {
      // Fallback lokal (mode tanpa server): roll sendiri.
      const cost = count === 10 ? GACHA.cost10 : GACHA.cost;
      if (this.gems < cost) { fxNum(this, this.scale.width / 2, this.scale.height * 0.6, (r && r.error) || 'Permata tidak cukup', '#fca5a5', 12); this._pulling = false; return; }
      this.gems -= cost;
      const pulls = [];
      for (let i = 0; i < count; i++) {
        let acc = 0; const roll = Math.random(); let rarity = 'common';
        for (const k of ['common', 'uncommon', 'rare', 'epic', 'legendary', 'mythic']) { acc += GACHA.rates[k]; if (roll < acc) { rarity = k; break; } }
        const pool = PET_BY_RARITY[rarity];
        const petId = pool[Math.floor(Math.random() * pool.length)];
        const dupe = !!PetState.owned[petId];
        const shards = dupe ? (GACHA.shardFromDupe[rarity] || 5) : 0;
        if (dupe) this.shards += shards; else PetState.owned[petId] = { level: 1, xp: 0, stage: 1 };
        pulls.push({ petId, rarity, duplicate: dupe, shards, isNew: !dupe });
      }
      data = { ok: true, pulls, gems: this.gems, petShards: this.shards, totalShards: pulls.reduce((a, b) => a + b.shards, 0) };
      if (Data.char) { Data.char.gems = this.gems; Data.char.petShards = this.shards; }
    }
    this.refreshTop();
    this.playReveal(data.pulls, data.totalShards || 0);
  }

  /* Reveal ala game gacha: gelap -> pendar warna rarity terbaik -> kartu flip. */
  playReveal(pulls, totalShards) {
    const W = this.scale.width, H = this.scale.height;
    const best = pulls.reduce((b, p) => {
      const idx = (r) => ['common', 'uncommon', 'rare', 'epic', 'legendary', 'mythic'].indexOf(r);
      return idx(p.rarity) > idx(b) ? p.rarity : b;
    }, 'common');
    const rar = PET_RARITY_INFO[best];
    const veil = uiFill(this, W / 2, H / 2, W, H, 0x000000, 0).setDepth(3000);
    this.tweens.add({ targets: veil, alpha: 0.88, duration: 260 });

    // Orb pendar tengah.
    const orb = this.add.image(W / 2, H * 0.42, 'fx_tex_glow').setTint(rar.glow).setAlpha(0.9).setDepth(3001).setBlendMode(Phaser.BlendModes.ADD).setScale(0);
    this.tweens.add({ targets: orb, scale: 1, duration: 300, ease: 'Back.easeOut' });
    this.tweens.add({ targets: orb, scale: { from: 1, to: 1.25 }, duration: 200, yoyo: true, repeat: 4, onComplete: () => {
      orb.destroy();
      // Ledakan warna.
      ensurePixelTex(this);
      const em = this.add.particles(W / 2, H * 0.42, 'fxpix', { lifespan: 800, speed: { min: 120, max: 320 }, scale: { start: 1.3, end: 0 }, quantity: 6, tint: [rar.glow, 0xffffff], blendMode: 'ADD', emitting: false }).setDepth(3001);
      em.explode(best === 'mythic' ? 60 : 30);
      this.time.delayedCall(1100, () => em.destroy());
      if (best === 'mythic') { fxFlash(this, 0xff9ecb, 500, 0.4); shake(this, 10); this.showMythicBanner(); }
      else if (best === 'legendary') { fxFlash(this, 0xfacc15, 320, 0.3); shake(this, 6); }
      // Deretan kartu hasil.
      this.showCards(pulls, totalShards, veil);
    } });
    // Gemeretak saat mengisi.
    this.tweens.add({ targets: orb, x: W / 2 + R(-6, 6), duration: 60, repeat: 12 });
    Sfx.levelup();
  }

  showMythicBanner() {
    const W = this.scale.width, H = this.scale.height;
    const t = this.add.text(W / 2, H * 0.20, 'M Y T H I C !', { fontFamily: F_HEAD, fontSize: '38px', color: '#f43f5e', stroke: '#ffffff', strokeThickness: 6, fontStyle: 'bold' }).setOrigin(0.5).setDepth(3010).setScale(0.2);
    this.tweens.add({ targets: t, scale: 1, duration: 380, ease: 'Back.easeOut' });
    this.tweens.add({ targets: t, angle: { from: -4, to: 4 }, duration: 700, yoyo: true, repeat: 3 });
    this.time.delayedCall(3200, () => this.tweens.add({ targets: t, alpha: 0, y: H * 0.14, duration: 400, onComplete: () => t.destroy() }));
  }

  showCards(pulls, totalShards, veil) {
    const W = this.scale.width, H = this.scale.height;
    const holder = this.add.container(0, 0).setDepth(3002);
    const cols = pulls.length > 1 ? 5 : 1;
    const cardW = pulls.length > 1 ? Math.min(104, (W - 60) / 5 - 8) : 130;
    const cardH = pulls.length > 1 ? 128 : 160;
    const rowsN = Math.ceil(pulls.length / cols);
    const gridW = pulls.length > 1 ? cols * (cardW + 8) - 8 : cardW;
    const gridH = rowsN * (cardH + 10) - 10;
    pulls.forEach((p, i) => {
      const col = i % cols, row = Math.floor(i / cols);
      const x = W / 2 - gridW / 2 + col * (cardW + 8) + cardW / 2;
      const y = H / 2 - gridH / 2 + row * (cardH + 10) + cardH / 2 - 10;
      const rar = PET_RARITY_INFO[p.rarity];
      const pet = PETS[p.petId];
      const card = this.add.container(x, y);
      // v9: kartu reveal = tile aset + outline rarity.
      card.add(uiSlice(this, 0, 0, cardW, cardH, 'ui_tile', 0x0d1526).setAlpha(0.97));
      card.add(uiSlice(this, 0, 0, cardW - 3, cardH - 3, 'ui_outline', rar.glow).setAlpha(0.95));
      // v12 FIX AKAR: sprite dulu digambar scale 1.8 dari 44px di bawah tepi atas
      // -> luber 67px KELUAR kartu & bertindih kartu sebelah ("dua sprite
      // bertumpuk" di screenshot). Kini seluruh isi kartu di-anchor dari BAWAH.
      const multi = pulls.length > 1;
      if (petTexExists(this, p.petId, 1)) {
        const spr = petAddSprite(this, 0, multi ? cardH / 2 - 44 : cardH / 2 - 58, p.petId, 1).setOrigin(0.5, 1).setScale(multi ? 1.02 : 1.7);
        card.add(spr);
      }
      card.add(this.add.text(0, cardH / 2 - 30, p.isNew ? pet.name : pet.name, { fontFamily: F_UI, fontSize: '10.5px', color: '#e2e8f0', fontStyle: 'bold', wordWrap: { width: cardW - 8 }, align: 'center' }).setOrigin(0.5));
      card.add(this.add.text(0, cardH / 2 - 16, rar.name, { fontFamily: F_UI, fontSize: '9px', color: rar.color, fontStyle: 'bold' }).setOrigin(0.5));
      card.add(this.add.text(0, cardH / 2 - 4, p.isNew ? 'BARU!' : '+' + p.shards + ' pecahan', { fontFamily: F_UI, fontSize: '9px', color: p.isNew ? '#86efac' : '#c4b5fd', fontStyle: 'bold' }).setOrigin(0.5));
      if (p.rarity === 'mythic' || p.rarity === 'legendary') {
        this.tweens.add({ targets: card, angle: { from: -2, to: 2 }, duration: 500, yoyo: true, repeat: -1 });
      }
      holder.add(card);
      // Muncul berurutan (flip-in).
      card.setScale(0);
      this.time.delayedCall(150 + i * 170, () => {
        Sfx.click();
        this.tweens.add({ targets: card, scale: 1, duration: 240, ease: 'Back.easeOut' });
      });
    });
    if (totalShards > 0) {
      holder.add(this.add.text(W / 2, H / 2 + gridH / 2 + 18, 'Total pecahan bintang: +' + totalShards, { fontFamily: F_UI, fontSize: '12px', color: '#c4b5fd', fontStyle: 'bold' }).setOrigin(0.5));
    }
    const newCount = pulls.filter((p) => p.isNew).length;
    if (newCount > 0) holder.add(this.add.text(W / 2, H / 2 + gridH / 2 + 40, newCount + ' sahabat baru bergabung!', { fontFamily: F_UI, fontSize: '11.5px', color: '#86efac' }).setOrigin(0.5));
    const btn = makeButton(this, W / 2, H - 46, 200, 46, 'Lanjut', { color: 0x334155, size: 13, onClick: () => { holder.destroy(); veil.destroy(); btn.destroy(); this._pulling = false; this.refreshTop(); } }).setDepth(3003);
  }
}

/* ============================================================ INFO MENARA */
class TowerInfoScene extends Phaser.Scene {
  constructor() { super('TowerInfo'); }
  create() {
    const W = this.scale.width, H = this.scale.height;
    this.bg = buildLobbyBackground(this);
    uiFill(this, W / 2, H / 2, W, H, 0x060a14, 0.86);
    makeButton(this, 54, 34, 72, 40, 'Kembali', { color: 0x334155, icon: 'back', size: 12, onClick: () => this.scene.start('Lobby') });
    this.add.text(W / 2 + 2, H * 0.24 + 3, 'MENARA TANPA UJUNG', { fontFamily: F_HEAD, fontSize: '22px', color: '#0b0b12' }).setOrigin(0.5);
    this.add.text(W / 2, H * 0.24, 'MENARA TANPA UJUNG', { fontFamily: F_HEAD, fontSize: '22px', color: '#a5b4fc', stroke: '#0b0b12', strokeThickness: 2 }).setOrigin(0.5);
    this.add.text(W / 2, H * 0.24 + 28, 'Lantai bertingkat tanpa akhir — musuh makin ganas, hadiah makin gemuk.', { fontFamily: F_UI, fontSize: '12px', color: '#94a3b8' }).setOrigin(0.5);
    iconImage(this, W / 2, H * 0.44, 'compass', { size: 64, color: 0x818cf8 }).setDepth(2);
    const best = (Data.char && Data.char.towerBest) || 0;
    this.add.text(W / 2, H * 0.56, 'Rekor lantaimu: ' + best, { fontFamily: F_UI, fontSize: '15px', color: '#fde68a', fontStyle: 'bold' }).setOrigin(0.5);
    this.add.text(W / 2, H * 0.56 + 24, 'Permata mengalir deras tiap 5 lantai. Giliran tema berganti setiap lantai.', { fontFamily: F_UI, fontSize: '11px', color: '#64748b' }).setOrigin(0.5);
    makeButton(this, W / 2, H * 0.70, 260, 54, best > 0 ? 'Lanjut ke Lantai ' + (best + 1) : 'Mulai Mendaki', { color: 0x4338ca, icon: 'arrow', size: 14, onClick: () => this.scene.start('Dungeon', { mode: 'tower', floor: best + 1 }) });
  }
}

class PetsScene extends Phaser.Scene {
  constructor() { super('Pets'); }
  create() {
    const W = this.scale.width, H = this.scale.height;
    this.bg = buildLobbyBackground(this);
    uiFill(this, W / 2, H / 2, W, H, 0x060a14, 0.82);

    this.add.text(W / 2 + 2, 37, 'KOLEKSI PET', { fontFamily: F_HEAD, fontSize: '24px', color: '#0b0b12' }).setOrigin(0.5);
    this.add.text(W / 2, 34, 'KOLEKSI PET', { fontFamily: F_HEAD, fontSize: '24px', color: '#fde68a', stroke: '#0b0b12', strokeThickness: 2 }).setOrigin(0.5);
    const owned = PET_ORDER.filter((id) => PetState.owned[id]).length;
    this.add.text(W / 2, 60, owned + ' dari ' + PET_ORDER.length + ' sahabat ditemukan  •  pet aktif: ' + (PetState.activePet ? PetState.activePet.name : 'belum ada'), { fontFamily: F_UI, fontSize: '12.5px', color: '#94a3b8' }).setOrigin(0.5);
    makeButton(this, 54, 34, 72, 40, 'Kembali', { color: 0x334155, icon: 'back', size: 12, onClick: () => this.scene.start('Lobby') });
    // Saldo pecahan + pintasan gacha.
    const shards = (Data.char && Data.char.petShards) || 0;
    this.add.container(W - 148, 34, [
      iconImage(this, -52, 0, 'star', { size: 16, color: 0xc4b5fd }),
      this.add.text(-36, 0, fmt(shards) + ' Pecahan', { fontFamily: F_UI, fontSize: '12px', color: '#c4b5fd', fontStyle: 'bold' }).setOrigin(0, 0.5),
    ]).setDepth(5);
    makeButton(this, W - 74, 34, 92, 40, 'Gacha', { color: 0x7c3aed, icon: 'sparkle', size: 11, onClick: () => this.scene.start('Gacha') }).setDepth(5);

    // Grid kartu pet (atas) + panel detail (bawah).
    const gridY = 92;
    const cardW = Math.min(92, (W - 60) / 7 - 10), cardH = 108;
    const perRow = Math.max(4, Math.min(7, Math.floor((W - 40) / (cardW + 10))));
    this.cards = [];
    this.selectedIndex = PET_ORDER.indexOf(PetState.active) >= 0 ? PET_ORDER.indexOf(PetState.active) : 0;
    const rows = Math.ceil(PET_ORDER.length / perRow);
    for (let i = 0; i < PET_ORDER.length; i++) {
      const petId = PET_ORDER[i];
      const pet = PETS[petId];
      const col = i % perRow, row = Math.floor(i / perRow);
      const totalW = perRow * (cardW + 10) - 10;
      const x = W / 2 - totalW / 2 + col * (cardW + 10) + cardW / 2;
      const y = gridY + row * (cardH + 10) + cardH / 2;
      const card = this.add.container(x, y);
      const isOwned = !!PetState.owned[petId];
      const isActive = PetState.active === petId;
      const rar = PET_RARITY_INFO[pet.rarity];
      // v9: kartu pet = tile aset + outline status.
      card.add(uiSlice(this, 0, 0, cardW, cardH, 'ui_tile', 0x0d1526).setAlpha(0.92));
      card.add(uiSlice(this, 0, 0, cardW - 3, cardH - 3, 'ui_outline', isActive ? 0xf2c230 : (isOwned ? rar.glow : 0x1e293b)).setAlpha(isActive ? 1 : 0.75));
      // Sprite pet (silhouette bila belum dimiliki) — sheet sesuai pangkat evolusi.
      const stage = isOwned ? (PetState.owned[petId].stage || 1) : 1;
      if (petTexExists(this, petId, stage)) {
        const spr = petAddSprite(this, 0, -8, petId, stage).setOrigin(0.5, 1).setScale(stage >= 2 ? 1.9 : 1.7);
        if (!isOwned) spr.setTint(0x0f172a);
        card.add(spr);
        // idle bob mini + animasi frame
        let animT = 0;
        this.tweens.add({ targets: spr, y: '-=3', duration: 900 + (i % 5) * 130, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
        this.time.addEvent({ delay: 300, loop: true, callback: () => { animT++; petSetFrame(spr, petId, stage, animT % 3); } });
      }
      const evoDef = PET_EVOLUTION[petId];
      const dispName = isOwned && stage >= 2 && evoDef ? evoDef.name : pet.name;
      card.add(this.add.text(0, 26, isOwned ? dispName : '???', { fontFamily: F_UI, fontSize: '11.5px', color: isOwned ? (stage >= 2 ? '#fde68a' : '#e2e8f0') : '#475569', fontStyle: 'bold' }).setOrigin(0.5));
      card.add(this.add.text(0, 40, isOwned ? ('Lv.' + (PetState.owned[petId].level || 1) + (stage >= 2 ? ' • EVOLUSI' : '')) : rar.name, { fontFamily: F_UI, fontSize: '9.5px', color: isOwned ? (stage >= 2 ? '#fde68a' : '#94a3b8') : rar.color }).setOrigin(0.5));
      if (isActive) card.add(this.add.text(0, -cardH / 2 + 10, 'AKTIF', { fontFamily: F_UI, fontSize: '8.5px', color: '#fde68a', fontStyle: 'bold' }).setOrigin(0.5).setBackgroundColor('#1a1400'));
      // v12.2: via makeInteractive (validasi + shape eksplisit; Container).
      makeInteractive(card, { w: cardW, h: cardH, useHandCursor: true })
        .on('pointerdown', () => { this.selectedIndex = i; this.refreshDetail(); Sfx.click(); });
      card.setDepth(5);
      this.cards.push(card);
    }

    // Panel detail.
    this.detailY = gridY + rows * (cardH + 10) + 18;
    this.detailPanel = this.add.container(0, this.detailY);
    this.detailPanel.setDepth(6);
    this.refreshDetail();
  }

  refreshDetail() {
    const W = this.scale.width, H = this.scale.height;
    this.detailPanel.removeAll(true);
    const petId = PET_ORDER[this.selectedIndex];
    const pet = PETS[petId];
    if (!pet) return;
    const isOwned = !!PetState.owned[petId];
    const isActive = PetState.active === petId;
    const rar = PET_RARITY_INFO[pet.rarity];
    const lv = isOwned ? (PetState.owned[petId].level || 1) : 1;
    const panelH = Math.max(150, H - this.detailY - 60);
    const pw = Math.min(760, W - 24);
    // v9: panel detail pet = aset 9-slice.
    this.detailPanel.add(uiSlice(this, W / 2, panelH / 2, pw, panelH, 'ui_panel', 0x0b1220).setAlpha(0.95));
    this.detailPanel.add(uiSlice(this, W / 2, panelH / 2, pw - 4, panelH - 4, 'ui_outline', rar.glow).setAlpha(0.5));

    // Sprite besar kiri — sheet sesuai pangkat evolusi.
    const stage = isOwned ? (PetState.owned[petId].stage || 1) : 1;
    const evoDef = PET_EVOLUTION[petId] || null;
    const dispName = isOwned && stage >= 2 && evoDef ? evoDef.name : pet.name;
    const dispSpecies = isOwned && stage >= 2 && evoDef ? evoDef.species : pet.species;
    const leftX = W / 2 - pw / 2 + 86;
    if (petTexExists(this, petId, stage)) {
      const spr = petAddSprite(this, leftX, panelH / 2 + 6, petId, stage).setOrigin(0.5, 1).setScale(stage >= 2 ? 3.8 : 3.4);
      if (!isOwned) spr.setTint(0x0f172a);
      this.detailPanel.add(spr);
      this.tweens.add({ targets: spr, y: '-=5', duration: 1000, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
      this.detailPanel.add(this.add.image(leftX, panelH / 2 + 10, 'fx_tex_shadow').setDisplaySize(80, 18).setAlpha(0.5));
      let animT = 0;
      this.time.addEvent({ delay: 320, loop: true, callback: () => { animT++; petSetFrame(spr, petId, stage, animT % 3); } });
    }

    // Info kanan.
    const infoX = W / 2 - pw / 2 + 176;
    this.detailPanel.add(this.add.text(infoX, 26, (isOwned ? dispName : '???') + '  —  ' + dispSpecies, { fontFamily: F_HEAD, fontSize: '20px', color: isOwned ? (stage >= 2 ? '#fde68a' : '#f8fafc') : '#475569', fontStyle: 'bold' }).setOrigin(0, 0));
    this.detailPanel.add(this.add.text(infoX, 50, rar.name + '  •  ' + (PET_ELEMENT_INFO[pet.element] || {}).name + '  •  ' + (PET_ROLE_INFO[pet.role] || ''), { fontFamily: F_UI, fontSize: '11.5px', color: rar.color }).setOrigin(0, 0));

    // Lore.
    this.detailPanel.add(this.add.text(infoX, 72, '"' + pet.lore + '"', { fontFamily: F_UI, fontSize: '11px', color: '#94a3b8', fontStyle: 'italic', wordWrap: { width: pw - 200 } }).setOrigin(0, 0));

    let y = 100;
    if (isOwned) {
      // Stat pasif + progress XP (dikali multiplier evolusi).
      const pass = petPassiveAt(pet, lv, stage);
      const statTxt = Object.entries(pass).map(([k, v]) => v + ' ' + k.toUpperCase()).join('   ');
      this.detailPanel.add(this.add.text(infoX, y, 'Bonus pasif (Lv.' + lv + '):  ' + statTxt, { fontFamily: F_UI, fontSize: '12px', color: '#7ee2b8', fontStyle: 'bold' }).setOrigin(0, 0));
      y += 20;
      const need = petXpForLevel(Math.min(lv, PET_LEVEL_CAP - 1));
      const cur = PetState.owned[petId].xp || 0;
      const pct = lv >= PET_LEVEL_CAP ? 1 : (need ? cur / need : 0);
      const barW = Math.min(300, pw - 220);
      // v9: bar XP pet = aset.
      this.detailPanel.add(uiBar(this, infoX + barW / 2, y + 5, barW, 10, pct, rar.glow, { frameTint: 0x1e293b }));
      this.detailPanel.add(this.add.text(infoX + barW + 10, y + 5, lv >= PET_LEVEL_CAP ? 'LEVEL MAKS' : (cur + ' / ' + need + ' XP'), { fontFamily: F_UI, fontSize: '10px', color: '#94a3b8' }).setOrigin(0, 0.5));
      y += 24;
    } else {
      this.detailPanel.add(this.add.text(infoX, y, 'Belum ditemukan — tarik GACHA PERMATA untuk mencarinya!', { fontFamily: F_UI, fontSize: '11px', color: '#64748b' }).setOrigin(0, 0));
      y += 24;
    }

    // v11: SKILL 1 & 2 bergantian + ULTIMATE (kunci evolusi terakhir).
    const sk1 = (stage >= 2 && evoDef) ? evoDef.skill : pet.skill;
    const sk2 = (pet.skills && pet.skills[1]) || null;
    this.detailPanel.add(this.add.text(infoX, y, 'Skill 1: ' + sk1.name + '  (tiap ' + sk1.cd + ' giliran)', { fontFamily: F_UI, fontSize: '12px', color: '#fde68a', fontStyle: 'bold' }).setOrigin(0, 0));
    this.detailPanel.add(this.add.text(infoX, y + 16, sk1.effectDesc + '.', { fontFamily: F_UI, fontSize: '10.5px', color: '#cbd5e1', wordWrap: { width: pw - 210 } }).setOrigin(0, 0));
    y += 36;
    if (sk2) {
      this.detailPanel.add(this.add.text(infoX, y, 'Skill 2: ' + sk2.name + '  (tiap ' + sk2.cd + ' giliran)', { fontFamily: F_UI, fontSize: '12px', color: '#93c5fd', fontStyle: 'bold' }).setOrigin(0, 0));
      this.detailPanel.add(this.add.text(infoX, y + 16, sk2.effectDesc + '.', { fontFamily: F_UI, fontSize: '10.5px', color: '#cbd5e1', wordWrap: { width: pw - 210 } }).setOrigin(0, 0));
      y += 36;
    }
    if (evoDef && evoDef.ultimate) {
      const ultOk = stage >= 2;
      this.detailPanel.add(this.add.text(infoX, y, (ultOk ? '★ ULTIMATE: ' : '★ ULTIMATE (terkunci — evolusi terakhir): ') + evoDef.ultimate.name, { fontFamily: F_UI, fontSize: '12px', color: ultOk ? '#f9a8d4' : '#94a3b8', fontStyle: 'bold' }).setOrigin(0, 0));
      this.detailPanel.add(this.add.text(infoX, y + 16, evoDef.ultimate.effectDesc + '.', { fontFamily: F_UI, fontSize: '10.5px', color: ultOk ? '#e2c5e8' : '#7c8598', wordWrap: { width: pw - 210 } }).setOrigin(0, 0));
      y += 38;
    }

    // ---- Bagian EVOLUSI ----
    if (isOwned && evoDef) {
      if (stage < 2) {
        const shards = (Data.char && Data.char.petShards) || 0;
        const okLv = lv >= evoDef.reqLevel, okShard = shards >= evoDef.shards;
        this.detailPanel.add(this.add.text(infoX, y, 'EVOLUSI -> ' + evoDef.name + ' (' + evoDef.species + ')', { fontFamily: F_UI, fontSize: '12px', color: '#fbbf24', fontStyle: 'bold' }).setOrigin(0, 0));
        this.detailPanel.add(this.add.text(infoX, y + 17, 'Syarat: Lv.' + evoDef.reqLevel + (okLv ? ' OK' : ' (kurang)') + '  •  ' + evoDef.shards + ' pecahan' + (okShard ? ' OK' : ' (kurang ' + (evoDef.shards - shards) + ')') + '  •  ' + fmt(evoDef.gold) + ' KZC', { fontFamily: F_UI, fontSize: '10.5px', color: okLv && okShard ? '#86efac' : '#fca5a5' }).setOrigin(0, 0));
        this.detailPanel.add(this.add.text(infoX, y + 34, 'Bonus: stat pasif x' + evoDef.mult + ', skill berubah: ' + evoDef.skill.name, { fontFamily: F_UI, fontSize: '10.5px', color: '#94a3b8' }).setOrigin(0, 0));
        if (okLv && okShard) {
          makeButton(this, W / 2 + pw / 2 - 110, this.detailY + y + 58, 180, 40, 'EVOLUSIKAN', { color: 0xd97706, icon: 'star', size: 12, onClick: async () => {
            const r = await api('/api/rpg/pet/evolve', { method: 'POST', body: { petId } });
            if (r && r.ok) {
              PetState.applyEvolve(petId);
              if (Data.char) Data.char.petShards = r.petShards;
              this.playEvolutionFx(petId);
            } else {
              fxNum(this, W / 2, this.detailY + 40, (r && r.error) || 'Gagal evolusi', '#fca5a5', 12);
            }
          } }).setDepth(7);
        }
      } else {
        this.detailPanel.add(this.add.text(infoX, y, 'BENTUK SEJATI: ' + evoDef.name + ' — stat pasif x' + evoDef.mult, { fontFamily: F_UI, fontSize: '12px', color: '#fde68a', fontStyle: 'bold' }).setOrigin(0, 0));
        this.detailPanel.add(this.add.text(infoX, y + 17, 'Tubuh, animasi, dan skillnya sudah berubah sepenuhnya.', { fontFamily: F_UI, fontSize: '10.5px', color: '#94a3b8' }).setOrigin(0, 0));
      }
    }

    // Tombol aksi.
    if (isOwned && !isActive) {
      makeButton(this, W / 2 + pw / 2 - 110, this.detailY + panelH - 36, 180, 42, 'Aktifkan', { color: 0x16a34a, icon: 'paw', size: 13, onClick: async () => {
        const ok = await PetState.setActive(petId);
        if (ok) { Sfx.levelup(); this.scene.restart(); } else this.scene.restart();
      } }).setDepth(7);
    } else if (isActive) {
      this.detailPanel.add(this.add.text(W / 2 + pw / 2 - 110, panelH - 36, 'SEDANG MENEMANIMU', { fontFamily: F_UI, fontSize: '11px', color: '#fde68a', fontStyle: 'bold' }).setOrigin(0.5, 0));
    } else {
      this.detailPanel.add(this.add.text(W / 2 + pw / 2 - 110, panelH - 36, 'BELUM DIMILIKI', { fontFamily: F_UI, fontSize: '11px', color: '#475569', fontStyle: 'bold' }).setOrigin(0.5, 0));
    }

    // Highlight kartu terpilih.
    this.cards.forEach((c, i) => { c.setScale(i === this.selectedIndex ? 1.06 : 1); });
  }

  /* Cutscene evolusi: kilatan -> sprite lama memudar -> bentuk sejati meledak masuk. */
  playEvolutionFx(petId) {
    const W = this.scale.width, H = this.scale.height;
    Sfx.levelup();
    fxFlash(this, 0xfde68a, 420, 0.42);
    shake(this, 8);
    const veil = uiFill(this, W / 2, H / 2, W, H, 0x000000, 0.7).setDepth(4000);
    const title = this.add.text(W / 2, H * 0.3, 'EVOLUSI!', { fontFamily: F_HEAD, fontSize: '34px', color: '#fde68a', stroke: '#0b0b12', strokeThickness: 6, fontStyle: 'bold' }).setOrigin(0.5).setDepth(4001).setScale(0.2);
    this.tweens.add({ targets: title, scale: 1, duration: 420, ease: 'Back.easeOut' });
    // v12: cutscene 4 babak — kilat -> SILUET bentuk lama (flicker gelap) ->
    // ledakan partikel -> bentuk sejati masuk (siluet -> final, sesuai brief).
    if (petTexExists(this, petId, 1)) {
      const baseSpr = petAddSprite(this, W / 2, H * 0.52, petId, 1).setOrigin(0.5, 1).setScale(4.0).setDepth(4001);
      baseSpr.setTint(0x000000);
      this.tweens.add({ targets: baseSpr, alpha: { from: 1, to: 0.25 }, duration: 130, yoyo: true, repeat: 3, onComplete: () => {
        fxSparks(this, W / 2, H * 0.52 - 40, 0xfde68a, 26);
        baseSpr.destroy();
      } });
    }
    if (petTexExists(this, petId, 2)) {
      const spr = petAddSprite(this, W / 2, H * 0.52, petId, 2).setOrigin(0.5, 1).setScale(4.2).setDepth(4001).setAlpha(0);
      this.tweens.add({ targets: spr, alpha: 1, scale: { from: 2.4, to: 4.2 }, duration: 520, delay: 640, ease: 'Back.easeOut' });
      this.tweens.add({ targets: spr, y: '-=10', duration: 900, yoyo: true, repeat: -1, delay: 1200 });
      let animT = 0;
      this.time.addEvent({ delay: 300, loop: true, callback: () => { animT++; petSetFrame(spr, petId, 2, animT % 3); } });
    }
    const evoDef = PET_EVOLUTION[petId];
    if (evoDef) {
      this.add.text(W / 2, H * 0.66, evoDef.name + ' — ' + evoDef.species, { fontFamily: F_UI, fontSize: '15px', color: '#fbbf24', fontStyle: 'bold', stroke: '#0b0b12', strokeThickness: 4 }).setOrigin(0.5).setDepth(4001);
      this.add.text(W / 2, H * 0.70, 'Skill baru: ' + evoDef.skill.name, { fontFamily: F_UI, fontSize: '12px', color: '#e2e8f0', stroke: '#0b0b12', strokeThickness: 3 }).setOrigin(0.5).setDepth(4001);
    }
    ensurePixelTex(this);
    const em = this.add.particles(W / 2, H * 0.52, 'fxpix', { lifespan: 1300, speed: { min: 80, max: 300 }, scale: { start: 1.5, end: 0 }, quantity: 8, tint: [0xfde68a, 0xfbbf24, 0xffffff], blendMode: 'ADD', emitting: false }).setDepth(4002);
    em.explode(50);
    this.time.delayedCall(3400, () => { this.scene.restart(); });
  }
}


/* ============================================================ WORLD BOSS MINGGUAN */
class WorldBossScene extends Phaser.Scene {
  constructor() { super('WorldBoss'); }
  create() {
    const W = this.scale.width, H = this.scale.height;
    this.bg = buildLivingBackground(this, 'volcano', { animated: true });
    uiFill(this, W / 2, H / 2, W, H, 0x0a0508, 0.55);
    makeButton(this, 54, 34, 72, 40, 'Kembali', { color: 0x334155, icon: 'back', size: 12, onClick: () => this.scene.start('Lobby') });
    this.add.text(W / 2 + 2, 33, 'WORLD BOSS MINGGUAN', { fontFamily: F_HEAD, fontSize: '20px', color: '#0b0b12' }).setOrigin(0.5);
    this.add.text(W / 2, 30, 'WORLD BOSS MINGGUAN', { fontFamily: F_HEAD, fontSize: '20px', color: '#fca5a5', stroke: '#0b0b12', strokeThickness: 2 }).setOrigin(0.5);
    this.bossData = null;
    this.cdUntil = 0;
    this.loadBoss();
    ensureMonsterAnims(this);
  }
  async loadBoss() {
    const W = this.scale.width, H = this.scale.height;
    if (this.holder) this.holder.destroy(true);
    this.holder = this.add.container(0, 0);
    const d = await api('/api/rpg/worldboss');
    if (!d || d.error) {
      this.holder.add(this.add.text(W / 2, H * 0.4, 'World boss belum bisa dimuat.', { fontFamily: F_UI, fontSize: '13px', color: '#fca5a5' }).setOrigin(0.5));
      return;
    }
    this.bossData = d;
    const boss = d.boss;
    // Boss besar di tengah.
    const def = MONSTER_ASSET[boss.sprite] || MONSTER_ASSET.demonlord;
    const spr = this.add.sprite(W / 2, H * 0.40, ATLAS_KEY, firstFrameName(def)).setOrigin(0.5, 1).setScale(def.s * 1.7).setTint(def.tint);
    this.holder.add(spr);
    playMonsterAnim(this, spr, { id: boss.sprite });
    this.holder.add(this.add.image(W / 2, H * 0.40 + 6, 'fx_tex_shadow').setDisplaySize(190, 40).setAlpha(0.55));
    // Aura marah.
    const aura = fxAura(this, W / 2, H * 0.40, 90, 0xef4444, 0);
    this.holder.add(this.add.text(W / 2, H * 0.40 - spr.displayHeight - 16, boss.name, { fontFamily: F_HEAD, fontSize: '17px', color: '#fca5a5', stroke: '#0b0b12', strokeThickness: 4, fontStyle: 'bold' }).setOrigin(0.5));
    this.holder.add(this.add.text(W / 2, H * 0.40 - spr.displayHeight + 6, 'Lv.' + boss.level + '  •  HP bersama seluruh petualang', { fontFamily: F_UI, fontSize: '11px', color: '#94a3b8' }).setOrigin(0.5));
    // Bar HP raksasa.
    const barW = Math.min(560, W - 40), barY = H * 0.56;
    const pct = clamp(boss.hp / boss.maxHp, 0, 1);
    this.holder.add(this.add.text(W / 2, barY - 14, fmt(boss.hp) + ' / ' + fmt(boss.maxHp) + ' HP  (' + (pct * 100).toFixed(1) + '%)', { fontFamily: F_UI, fontSize: '12px', color: '#fecaca', fontStyle: 'bold' }).setOrigin(0.5));
    // v9: bar HP raksasa = aset (frame + isi).
    this.holder.add(uiBar(this, W / 2, barY + 11, barW, 22, pct, 0xdc2626, { frameTint: 0x7f1d1d }));
    // Tombol serang.
    makeButton(this, W / 2, H * 0.56 + 74, 240, 54, 'SERANG BOSS', { color: 0xb91c1c, icon: 'sword', size: 14, onClick: () => this.attack() });
    this.holder.add(this.add.text(W / 2, H * 0.56 + 108, 'Kontribusimu: ' + fmt(d.my.damage) + ' damage dari ' + d.my.hits + ' serangan', { fontFamily: F_UI, fontSize: '11px', color: '#fde68a' }).setOrigin(0.5));
    // Leaderboard kontribusi.
    const boardY = H * 0.56 + 128;
    this.holder.add(this.add.text(W / 2, boardY, 'PENYERANG TERGIGIH MINGGU INI', { fontFamily: F_HEAD, fontSize: '10px', color: '#fca5a5' }).setOrigin(0.5));
    (d.leaderboard || []).slice(0, 5).forEach((b, i) => {
      const y = boardY + 18 + i * 24;
      this.holder.add(this.add.text(W / 2 - 150, y, (i + 1) + '. ' + (b.name || 'Petualang'), { fontFamily: F_UI, fontSize: '11px', color: '#e2e8f0' }).setOrigin(0, 0.5));
      this.holder.add(this.add.text(W / 2 + 150, y, fmt(b.damage) + ' dmg', { fontFamily: F_UI, fontSize: '11px', color: '#94a3b8' }).setOrigin(1, 0.5));
    });
  }
  async attack() {
    const now = this.time.now;
    if (now < this.cdUntil) return;
    this.cdUntil = now + 1400;
    const W = this.scale.width, H = this.scale.height;
    // Hitung damage dari stat lokal (server menjepit ke wajar).
    const st = computeStats(Data.char) || {};
    const dmg = Math.max(10, Math.round((st.atk || 20) * (8 + Math.random() * 6)));
    // Animasi: hero ayun -> ledakan di boss.
    if (this.heroFx) this.heroFx.destroy();
    Sfx.hit();
    shake(this, 5);
    const bossX = W / 2, bossY = H * 0.34;
    fxSparks(this, bossX + RF(-40, 40), bossY, 0xfbbf24, 16);
    fxNum(this, bossX, bossY - 30, '-' + fmt(dmg), '#fbbf24', 20, true);
    const r = await api('/api/rpg/worldboss/attack', { method: 'POST', body: { damage: dmg } });
    if (r && r.ok) {
      if (r.rewards && r.rewards.gems) fxNum(this, W / 2, H * 0.5, '+' + r.rewards.gems + ' Permata', '#7dd3fc', 12, true);
      if (r.rewards) fxNum(this, W / 2, H * 0.5 + 22, '+' + fmt(r.rewards.gold) + ' KZC', '#fde68a', 11);
      if (Data.char && r.rewards && r.rewards.gems) Data.char.gems = (Data.char.gems || 0) + r.rewards.gems;
      this.loadBoss();
    } else {
      fxNum(this, W / 2, H * 0.5, (r && r.error) || 'Serangan gagal', '#fca5a5', 12);
    }
  }
}

/* ============================================================ RUMAH LELANG */
class AuctionScene extends Phaser.Scene {
  constructor() { super('Auction'); }
  create() {
    const W = this.scale.width, H = this.scale.height;
    // v9: latar lelang — pita aset bertingkat (amber -> biru gelap).
    uiFill(this, W / 2, H / 2, W, H, 0x141007);
    uiFill(this, W / 2, H * 0.75, W, H / 2, 0x0b1120, 0.9);
    sceneHeader(this, 'RUMAH LELANG', 'Jual itemmu ke petualang lain — atau rebut barang bagus', { y: H * 0.045, color: '#fde68a' });
    makeButton(this, 54, 34, 72, 40, 'Kembali', { color: 0x334155, icon: 'back', size: 12, onClick: () => this.scene.start('Lobby') });
    makeButton(this, W - 84, 34, 118, 42, 'Jual Item', { color: 0xb45309, icon: 'coin', size: 11, onClick: () => this.openSell() });
    if (!CFG.server) {
      this.add.text(W / 2, H * 0.4, 'Rumah lelang butuh server bot (login Discord).', { fontFamily: F_UI, fontSize: '13px', color: '#fca5a5' }).setOrigin(0.5);
      return;
    }
    this.loadList();
  }
  async loadList() {
    if (this.listG) this.listG.forEach((o) => o.destroy());
    this.listG = [];
    const W = this.scale.width, H = this.scale.height;
    const d = await api('/api/rpg/auctions');
    const list = (d && d.auctions) || [];
    let y = H * 0.12;
    if (!list.length) this.listG.push(this.add.text(W / 2, y + 16, 'Belum ada lelang aktif. Jadilah yang pertama menjual!', { fontFamily: F_UI, fontSize: '12px', color: '#64748b' }).setOrigin(0.5));
    for (const a of list.slice(0, Math.floor((H - y - 70) / 64))) {
      // v9: baris lelang = tile aset + outline.
      this.listG.push(uiSlice(this, 20 + (W - 40) / 2, y + 28, W - 40, 56, 'ui_tile', 0x0f172a).setAlpha(0.95));
      this.listG.push(uiSlice(this, 20 + (W - 40) / 2, y + 28, W - 44, 52, 'ui_outline', a.mine ? 0xb45309 : 0x334155).setAlpha(0.9));
      if (a.item) {
        const icon = addRarityIcon(this, 52, y + 28, a.itemId, 36);
        this.listG.push(icon);
        const ti = tierInfo(a.item.tier);
        this.listG.push(this.add.text(80, y + 16, a.item.name + (a.qty > 1 ? ' x' + a.qty : ''), { fontFamily: F_UI, fontSize: '13px', color: hex(ti.color), fontStyle: 'bold' }).setOrigin(0, 0.5));
        this.listG.push(this.add.text(80, y + 38, (a.item.desc || '').slice(0, 46) + '  •  ' + (a.sellerName || 'petualang'), { fontFamily: F_UI, fontSize: '9.5px', color: '#64748b' }).setOrigin(0, 0.5));
      } else {
        this.listG.push(this.add.text(80, y + 28, a.itemId, { fontFamily: F_UI, fontSize: '12px', color: '#94a3b8' }).setOrigin(0, 0.5));
      }
      if (a.mine) {
        this.listG.push(makeButton(this, W - 90, y + 28, 118, 38, 'Batalkan', { color: 0x7c2d12, size: 11, onClick: async () => {
          const r = await api('/api/rpg/auction/cancel', { method: 'POST', body: { id: a.id } });
          if (r && r.ok) { Sfx.click(); this.loadList(); } 
        } }));
      } else {
        this.listG.push(makeButton(this, W - 90, y + 28, 118, 38, fmt(a.price) + ' KZC', { color: 0xca8a04, icon: 'coin', size: 11, onClick: async () => {
          const r = await api('/api/rpg/auction/buy', { method: 'POST', body: { id: a.id } });
          if (r && r.ok) {
            Sfx.coin(); Toast.show(this, { title: 'Lelang dimenangkan', message: (a.item && a.item.name) || a.itemId, icon: 'coin', color: 0xca8a04 });
            if (r.wallet && Data.char) Data.char.gold = r.wallet.gold;
            this.loadList();
          } else Toast.show(this, { title: 'Gagal membeli', message: (r && r.error) || '', icon: 'cross', color: 0xdc2626 });
        } }));
      }
      y += 64;
    }
  }
  openSell() {
    const W = this.scale.width, H = this.scale.height;
    const inv = (Data.char && Data.char.inventory) || {};
    const sellable = Object.entries(inv).filter(([id, q]) => q > 0 && itemById(id) && itemById(id).category !== 'material')
      .concat(Object.entries(inv).filter(([id, q]) => q > 0 && itemById(id) && itemById(id).category === 'material'));
    if (!sellable.length) { Toast.show(this, { title: 'Tas kosong', message: 'Tidak ada item untuk dijual.', icon: 'bag', color: 0x64748b }); return; }
    const veil = uiFill(this, W / 2, H / 2, W, H, 0x000000, 0.75).setDepth(3000);
    const panelC = this.add.container(W / 2, H / 2).setDepth(3001);
    const pw = Math.min(460, W - 30), ph = Math.min(480, H - 60);
    panelC.add(uiSlice(this, 0, 0, pw, ph, 'ui_panel', 0x0a0f1c).setAlpha(0.98));
    panelC.add(uiSlice(this, 0, 0, pw - 4, ph - 4, 'ui_outline', 0xca8a04).setAlpha(0.8));
    panelC.add(this.add.text(0, -ph / 2 + 24, 'PASANG LELANG', { fontFamily: F_HEAD, fontSize: '15px', color: '#fde68a' }).setOrigin(0.5));
    let sel = null, price = 100;
    const listC = this.add.container(0, 0);
    panelC.add(listC);
    sellable.slice(0, 8).forEach(([id, qty], i) => {
      const it = itemById(id);
      const y = -ph / 2 + 56 + i * 40;
      const row = this.add.container(0, y);
      // v9: baris item jual = tile aset (tint pilihan).
      const rbg = uiSlice(this, 0, 0, pw - 40, 34, 'ui_tile', 0x161f33);
      const rbgOl = uiSlice(this, 0, 0, pw - 44, 30, 'ui_outline', 0x334155).setAlpha(0.6);
      const rbgArea = makeInteractive(this.add.rectangle(0, 0, pw - 40, 34, 0x000000, 0.001), { useHandCursor: true });
      row.add(rbg); row.add(rbgOl); row.add(rbgArea);
      row.add(addRarityIcon(this, -pw / 2 + 34, 0, id, 26));
      row.add(this.add.text(-pw / 2 + 56, 0, (it.name || id).slice(0, 22) + ' x' + qty, { fontFamily: F_UI, fontSize: '11px', color: '#e2e8f0' }).setOrigin(0, 0.5));
      rbgArea.on('pointerdown', () => { sel = id; price = Math.max(10, (it.price || 50) * 2); priceTxt.setText(fmt(price) + ' KZC'); rbg.setTint(0x2a3a5c); listC.list.forEach((o) => { if (o !== rbg && o.setTint && o.__sellRow) o.setTint(0x161f33); }); });
      rbg.__sellRow = true;
      listC.add(row);
    });
    // Kontrol harga.
    const priceY = -ph / 2 + 56 + Math.min(8, sellable.length) * 40 + 26;
    panelC.add(this.add.text(-pw / 2 + 20, priceY, 'Harga:', { fontFamily: F_UI, fontSize: '12px', color: '#8b96ab' }).setOrigin(0, 0.5));
    const priceTxt = this.add.text(0, priceY, 'pilih item dulu', { fontFamily: F_UI, fontSize: '14px', color: '#fde68a', fontStyle: 'bold' }).setOrigin(0.5);
    panelC.add(priceTxt);
    panelC.add(makeButton(this, -110, priceY + 42, 84, 36, '- 100', { color: 0x1f2937, size: 12, onClick: () => { if (sel) { price = Math.max(10, price - 100); priceTxt.setText(fmt(price) + ' KZC'); } } }));
    panelC.add(makeButton(this, 0, priceY + 42, 84, 36, '+ 100', { color: 0x1f2937, size: 12, onClick: () => { if (sel) { price = Math.min(9999999, price + 100); priceTxt.setText(fmt(price) + ' KZC'); } } }));
    panelC.add(makeButton(this, 110, priceY + 42, 120, 36, 'PASANG', { color: 0xb45309, size: 12, onClick: async () => {
      if (!sel) return;
      const it = itemById(sel);
      const r = await api('/api/rpg/auction/list', { method: 'POST', body: { itemId: sel, qty: 1, price } });
      if (r && r.ok) {
        Data.char.inventory[sel] = Math.max(0, (Data.char.inventory[sel] || 0) - 1);
        Sfx.coin(); veil.destroy(); panelC.destroy(); this.loadList();
      } else Toast.show(this, { title: 'Gagal memasang', message: (r && r.error) || '', icon: 'cross', color: 0xdc2626 });
    } }));
    panelC.add(makeButton(this, 0, ph / 2 - 24, 130, 36, 'Tutup', { color: 0x334155, size: 11, onClick: () => { veil.destroy(); panelC.destroy(); } }));
  }
}

class InventoryScene extends Phaser.Scene {
  constructor() { super('Inventory'); }
  create() {
    const W = this.scale.width, H = this.scale.height;
    uiFill(this, W / 2, H / 2, W, H, 0x0b1120);
    uiFill(this, W / 2, H * 0.75, W, H / 2, 0x131b2c, 0.9);
    sceneHeader(this, 'INVENTORI', 'Ketuk item untuk melihat detail', { y: H * 0.05 });

    // PERTAHANKAN pilihan antar scene.restart() (pola Leaderboard/Achievement).
    // Dulu di-reset ke null di sini -> klik item/tab tidak pernah berpengaruh.
    this.selectedId = this.selectedId || null;
    this.category = this.category || 'all';
    this.buildSidebar();
    this.buildCategoryTabs();
    this.buildGrid();
    this.buildDetail(this.selectedId); // bukan null — pilihan bertahan antar restart
    makeButton(this, W - 96, H - 34, 150, 44, 'Tutup', { color: 0x1f2937, icon: 'back', size: 14, onClick: () => this.scene.start('Lobby') });
  }
  buildSidebar() {
    const W = this.scale.width, H = this.scale.height;
    const x = Math.max(16, W * 0.05), y = H * 0.12, w = Math.min(300, W * 0.30), h = H * 0.74;
    panel(this, x, y, w, h, 0x0f172a, 0.97, 12);
    this.add.text(x + 16, y + 16, 'EQUIPMENT', { fontFamily: F_HEAD, fontSize: '10px', color: '#f2c230' }).setOrigin(0, 0.5);
    const slots = [
      { key: 'weapon', label: 'Senjata', icon: 'sword' },
      { key: 'armor', label: 'Zirah', icon: 'shield' },
      { key: 'accessory', label: 'Aksesoris', icon: 'ring' },
    ];
    this.slotBoxes = {};
    slots.forEach((s, i) => {
      const sy = y + 52 + i * 86;
      // v9: slot equip = tile aset + outline.
      uiSlice(this, x + 14 + (w - 28) / 2, sy - 32 + 36, w - 28, 72, 'ui_tile', 0x0d1526).setAlpha(0.9);
      uiSlice(this, x + 14 + (w - 28) / 2, sy - 32 + 36, w - 32, 68, 'ui_outline', 0x334155).setAlpha(0.9);
      iconImage(this, x + 44, sy + 4, s.icon, { size: 22, color: 0x64748b });
      this.add.text(x + 68, sy - 18, s.label, { fontFamily: F_UI, fontSize: '11px', color: '#8b96ab' }).setOrigin(0, 0.5);
      const item = itemById(Data.char.equipped[s.key]);
      if (item) {
        const ti = tierInfo(item.tier);
        this.add.text(x + 68, sy + 2, item.name, { fontFamily: F_UI, fontSize: '12.5px', color: hex(ti.color), fontStyle: 'bold', wordWrap: { width: w - 110 } }).setOrigin(0, 0.5);
        this.add.text(x + 68, sy + 20, ti.name, { fontFamily: F_UI, fontSize: '9.5px', color: '#64748b' }).setOrigin(0, 0.5);
      } else {
        this.add.text(x + 68, sy + 2, 'Kosong', { fontFamily: F_UI, fontSize: '12px', color: '#475569' }).setOrigin(0, 0.5);
      }
      // Tombol lepas.
      if (item) {
        makeButton(this, x + w - 40, sy + 4, 44, 32, '', { color: 0x7c2d12, size: 11, onClick: async () => {
          const r = await Data.unequip(s.key);
          if (r.ok) this.scene.restart();
          else Toast.show(this, { title: 'Gagal melepas', message: r.error || '', icon: 'cross', color: 0xdc2626 });
        } }).add(iconImage(this, 0, 0, 'cross', { size: 14, color: 0xfca5a5 }));
      }
      this.slotBoxes[s.key] = { sy };
    });
    // Stat ringkas.
    const stats = computeStats(Data.char);
    const sy2 = y + 52 + 3 * 86 + 14;
    this.add.text(x + 16, sy2, 'STAT KARAKTER', { fontFamily: F_HEAD, fontSize: '10px', color: '#f2c230' }).setOrigin(0, 0.5);
    const rows = [['HP', stats.hp], ['MP', stats.mp], ['ATK', stats.atk], ['DEF', stats.def], ['SPD', stats.spd], ['CRIT', stats.crit + '%']];
    rows.forEach((r, i) => {
      const ry = sy2 + 24 + i * 24;
      iconImage(this, x + 30, ry, ['heart', 'mana', 'sword', 'shield', 'sparkle', 'eye'][i], { size: 15, color: 0x94a3b8 });
      this.add.text(x + 48, ry, r[0], { fontFamily: F_UI, fontSize: '12px', color: '#8b96ab' }).setOrigin(0, 0.5);
      this.add.text(x + w - 32, ry, String(r[1]), { fontFamily: F_UI, fontSize: '12.5px', color: '#e2e8f0', fontStyle: 'bold' }).setOrigin(1, 0.5);
    });
  }
  buildCategoryTabs() {
    const W = this.scale.width, H = this.scale.height;
    const cats = [
      { key: 'all', name: 'Semua' }, { key: 'weapon', name: 'Senjata' },
      { key: 'armor', name: 'Zirah' }, { key: 'accessory', name: 'Aksesoris' },
      { key: 'potion', name: 'Ramuan' }, { key: 'material', name: 'Bahan' },
    ];
    const gx = this.gridX();
    const tw = 74, gap = 6;
    cats.forEach((c, i) => {
      makeButton(this, gx + i * (tw + gap), H * 0.12 + 12, tw, 34, c.name, {
        color: this.category === c.key ? 0x2563eb : 0x1e293b, size: 11,
        onClick: () => { this.category = c.key; this.scene.restart(); },
      });
    });
  }
  gridX() { return Math.max(16, this.scale.width * 0.05) + Math.min(300, this.scale.width * 0.30) + 20; }
  buildGrid() {
    const W = this.scale.width, H = this.scale.height;
    const gx = this.gridX();
    const gw = W - gx - 20;
    const gh = H * 0.74;
    panel(this, gx, H * 0.12 + 52, gw, gh - 52, 0x0f172a, 0.97, 12);
    const inv = Data.char.inventory || {};
    // Gabung item + ramuan, filter kategori, sort rarity lalu nama.
    let ids = Object.keys(inv).filter((id) => inv[id] > 0);
    if (this.category !== 'all') {
      ids = ids.filter((id) => {
        const it = itemById(id) || poisonById(id);
        const cat = poisonById(id) ? 'potion' : (it ? it.cat : '');
        return cat === this.category;
      });
    }
    ids.sort((a, b) => {
      const ia = itemById(a) || poisonById(a), ib = itemById(b) || poisonById(b);
      return tierIndex(ib.tier) - tierIndex(ia.tier) || (ia.name || '').localeCompare(ib.name || '');
    });
    const cell = Math.min(76, (gw - 40) / 5 - 10);
    const cols = Math.max(3, Math.floor((gw - 40) / (cell + 10)));
    const startY = H * 0.12 + 52 + 22;
    this.itemCells = [];
    if (!ids.length) {
      this.add.text(gx + gw / 2, startY + 60, 'Tas kosong — cari item di dungeon atau quest.', { fontFamily: F_UI, fontSize: '13px', color: '#64748b' }).setOrigin(0.5);
    }
    ids.forEach((id, i) => {
      const row = Math.floor(i / cols), col = i % cols;
      const cx = gx + 26 + col * (cell + 10) + cell / 2;
      const cy = startY + row * (cell + 10) + cell / 2;
      if (cy > H * 0.12 + gh - 20) return;
      const it = itemById(id) || poisonById(id);
      const ti = tierInfo(it.tier);
      const cont = this.add.container(cx, cy);
      // v9: sel item = tile aset + outline rarity.
      cont.add(uiSlice(this, 0, 0, cell, cell, 'ui_tile', 0x0d1526).setAlpha(0.92));
      cont.add(uiSlice(this, 0, 0, cell - 3, cell - 3, 'ui_outline', ti.color).setAlpha(this.selectedId === id ? 1 : 0.55));
      const icon = addItemIcon(this, 0, -6, id, cell - 26);
      cont.add(icon);
      const qtyTxt = this.add.text(cell / 2 - 5, cell / 2 - 5, 'x' + inv[id], { fontFamily: F_UI, fontSize: '10.5px', color: '#e2e8f0', fontStyle: 'bold', stroke: '#0b0b12', strokeThickness: 3 }).setOrigin(1, 1);
      cont.add(qtyTxt);
      const area = makeInteractive(this.add.rectangle(0, 0, cell, cell, 0x000000, 0.001), { useHandCursor: true });
      cont.add(area);
      area.on('pointerup', () => { Sfx.click(); this.selectedId = id; this.scene.restart(); });
      this.itemCells.push(cont);
    });
    this.add.text(gx + 26, H * 0.12 + gh - 6, ids.length + ' jenis item', { fontFamily: F_UI, fontSize: '11px', color: '#475569' }).setOrigin(0, 1);
  }
  buildDetail(id) {
    const W = this.scale.width, H = this.scale.height;
    if (this.detailG) this.detailG.forEach((o) => o.destroy());
    this.detailG = [];
    const y = H * 0.12 + 52;
    const gx = this.gridX();
    const gw = W - gx - 20;
    const dh = 128;
    const panelG = panel(this, gx, H - dh - 56, gw, dh, 0x0b1220, 0.98, 12);
    this.detailG.push(panelG);
    if (id && !((Data.char.inventory || {})[id] > 0)) id = null; // sudah habis terjual
    if (!id) {
      const t = this.add.text(gx + gw / 2, H - dh / 2 - 56, 'Pilih item untuk melihat detail', { fontFamily: F_UI, fontSize: '13px', color: '#64748b' }).setOrigin(0.5);
      this.detailG.push(t);
      return;
    }
    const it = itemById(id) || poisonById(id);
    const inv = Data.char.inventory || {};
    const ti = tierInfo(it.tier);
    const icon = addRarityIcon(this, gx + 44, H - dh / 2 - 56, id, 56);
    this.detailG.push(icon);
    this.detailG.push(this.add.text(gx + 84, H - dh - 56 + 18, it.name, { fontFamily: F_UI, fontSize: '16px', color: hex(ti.color), fontStyle: 'bold' }).setOrigin(0, 0.5));
    this.detailG.push(this.add.text(gx + 84, H - dh - 56 + 40, ti.name + '  •  dimiliki x' + (inv[id] || 0), { fontFamily: F_UI, fontSize: '11px', color: '#8b96ab' }).setOrigin(0, 0.5));
    // Stat & efek.
    const statParts = [];
    if (it.atk) statParts.push('ATK +' + it.atk);
    if (it.def) statParts.push('DEF +' + it.def);
    if (it.hp) statParts.push('HP +' + it.hp);
    if (it.mp) statParts.push('MP +' + it.mp);
    if (it.spd) statParts.push('SPD +' + it.spd);
    if (it.crit) statParts.push('CRIT +' + it.crit);
    this.detailG.push(this.add.text(gx + 84, H - dh - 56 + 62, statParts.join('   ') || it.desc, { fontFamily: F_UI, fontSize: '11.5px', color: '#cbd5e1', wordWrap: { width: gw - 260 } }).setOrigin(0, 0.5));
    const effTxt = poisonById(id) ? it.desc : effectText(it.effect);
    if (effTxt) this.detailG.push(this.add.text(gx + 84, H - dh - 56 + 82, effTxt, { fontFamily: F_UI, fontSize: '10.5px', color: '#fbbf24', wordWrap: { width: gw - 260 } }).setOrigin(0, 0.5));
    // Tombol aksi — grid 2x2 sisi kanan panel detail. Dulu bertumpuk: tombol
    // Pakai & Jual (x1) SATU POSISI saat item bisa dipasang sekaligus dipakai,
    // dan Jual Semua menabrak tombol Tutup di bawah -> "tombol gk bisa dipencet".
    const isEquip = itemById(id) && ['weapon', 'armor', 'accessory'].includes(itemById(id).cat);
    const isUsable = poisonById(id) || (itemById(id) && itemById(id).use);
    const acts = [];
    if (isEquip) acts.push({ label: 'Pasang', color: 0x16a34a, icon: 'check', size: 13, onClick: async () => {
      const r = await Data.equip(id);
      if (r.ok) { Sfx.chest(); this.scene.restart(); }
      else Toast.show(this, { title: 'Tidak bisa dipasang', message: r.error || '', icon: 'cross', color: 0xdc2626 });
    } });
    if (isUsable) acts.push({ label: 'Pakai', color: 0x0ea5e9, icon: 'potion', size: 13, onClick: async () => {
      const r = await Data.useItem(id);
      if (r.ok) { Sfx.potion(); this.scene.restart(); }
      else Toast.show(this, { title: 'Gagal memakai', message: r.error || '', icon: 'cross', color: 0xdc2626 });
    } });
    acts.push({ label: 'Jual (x1)', color: 0x7c2d12, icon: 'coin', size: 12, onClick: async () => {
      const r = await Data.sellItem(id, 1);
      if (r.ok) { Sfx.coin(); Toast.show(this, { title: 'Terjual', message: '+' + fmt(r.gold) + ' KZC', icon: 'coin', color: 0xca8a04 }); this.scene.restart(); }
      else Toast.show(this, { title: 'Gagal menjual', message: r.error || '', icon: 'cross', color: 0xdc2626 });
    } });
    if ((inv[id] || 0) > 1) acts.push({ label: 'Jual Semua', color: 0x431407, icon: 'coin', size: 11, onClick: async () => {
      const r = await Data.sellItem(id, inv[id]);
      if (r.ok) { Sfx.coin(); Toast.show(this, { title: 'Terjual semua', message: '+' + fmt(r.gold) + ' KZC', icon: 'coin', color: 0xca8a04 }); this.scene.restart(); }
    } });
    const bw = Math.min(152, Math.floor((gw - 40) / 2) - 6);
    const xR = gx + gw - bw / 2 - 12;
    const xL = xR - bw - 10;
    const yA = H - dh - 56 + 38;
    const yB = yA + 46;
    acts.forEach((a, i) => {
      this.detailG.push(makeButton(this, i % 2 === 0 ? xR : xL, i < 2 ? yA : yB, bw, 40, a.label, { color: a.color, icon: a.icon, size: a.size, onClick: a.onClick }));
    });
  }
}

/* ---------- SKILL TREE (AAA) ---------- */
class SkillTreeScene extends Phaser.Scene {
  constructor() { super('SkillTree'); }
  init(data) { this.selected = (data && data.classKey) || Data.char.classKey || 'warrior'; }
  create() {
    const W = this.scale.width, H = this.scale.height;
    // v9: latar ungu arcane — pita aset + partikel aset.
    uiFill(this, W / 2, H / 2, W, H, 0x150a2e);
    uiFill(this, W / 2, H * 0.75, W, H / 2, 0x070510, 0.9);
    this.add.particles(0, 0, this.textures.exists('dot') ? 'dot' : 'fx_tex_pixel', { x: { min: 0, max: W }, y: H, lifespan: 5000, speedY: { min: -30, max: -8 }, speedX: { min: -8, max: 8 }, scale: { min: 0.2, max: 0.8 }, quantity: 1, frequency: 380, tint: [0xa78bfa, 0xec4899] });
    sceneHeader(this, 'SKILL TREE', null, { y: H * 0.045 });
    const sp = Data.char.skillPoints || 0;
    this.add.text(W / 2, H * 0.045 + 36, 'Poin skill tersedia: ' + sp + (sp > 0 ? ' — pakai sebelum lupa' : ''), { fontFamily: F_UI, fontSize: '13px', color: sp > 0 ? '#86efac' : '#8b96ab', fontStyle: sp > 0 ? 'bold' : 'normal' }).setOrigin(0.5);

    // Tab class.
    const tabW = 130, tabH = 40, tabGap = 8, tabY = H * 0.115;
    const totalW = CLASS_KEYS.length * tabW + (CLASS_KEYS.length - 1) * tabGap;
    CLASS_KEYS.forEach((k, i) => {
      const x = W / 2 - totalW / 2 + tabW / 2 + i * (tabW + tabGap);
      const cls = CLASSES[k];
      const sel = k === this.selected;
      makeButton(this, x, tabY, tabW, tabH, cls.name, { color: sel ? cls.color : 0x1f2937, size: 13, onClick: () => this.scene.restart({ classKey: k }) });
    });

    // Pohon: 4 tier baris.
    const cls = CLASSES[this.selected] || CLASSES.warrior;
    const tree = SKILL_TREES[this.selected] || [];
    const tiers = [1, 2, 3, 4];
    const treeTop = H * 0.17;
    const treeBottom = H * 0.80;
    const rowH = (treeBottom - treeTop) / 4;
    // Konektor (gambar dulu, di bawah node).
    const nodePos = {};
    tiers.forEach((tier) => {
      const skills = tree.filter((s) => s.tier === tier);
      skills.forEach((s, i) => {
        const x = W / 2 + (i - (skills.length - 1) / 2) * (W / Math.max(skills.length + 0.6, 3.6));
        const y = treeTop + (tier - 1) * rowH + rowH / 2;
        nodePos[s.id] = { x, y };
      });
    });
    // v9: konektor = pita aset tipis dirotasi presisi antar node (nol canvas).
    const linkLine = (x1, y1, x2, y2) => {
      const dx = x2 - x1, dy = y2 - y1;
      const len = Math.hypot(dx, dy);
      const ln = uiFill(this, (x1 + x2) / 2, (y1 + y2) / 2, len, 3, 0x4c1d95, 0.6);
      ln.setRotation(Math.atan2(dy, dx));
    };
    for (const s of tree) {
      for (const req of (s.requires || [])) {
        const a = nodePos[req], b = nodePos[s.id];
        if (a && b) linkLine(a.x, a.y + 26, b.x, b.y - 26);
      }
    }
    // Label tier.
    const tierNames = ['Dasar', 'Menengah', 'Lanjut', 'Puncak'];
    tiers.forEach((t) => {
      this.add.text(24, treeTop + (t - 1) * rowH + rowH / 2, 'T' + t + '\n' + tierNames[t - 1], { fontFamily: F_HEAD, fontSize: '9px', color: '#94a3b8', align: 'center', lineSpacing: 6 }).setOrigin(0, 0.5);
    });
    // Node.
    for (const s of tree) {
      const { x, y } = nodePos[s.id];
      const lvl = SkillState.get(s.id);
      const unlocked = lvl > 0;
      const maxed = lvl >= s.maxLevel;
      const canUnlock = !maxed && Data.char.level >= s.reqLevel && (s.requires || []).every((r) => SkillState.get(r) > 0) && (Data.char.skillPoints || 0) >= s.cost;
      const cont = this.add.container(x, y).setDepth(1);
      // v9: node = aset bulat (badge tint status) + ring glow.
      const R0 = 26;
      if (canUnlock && !maxed) {
        const glow = this.add.image(0, 0, 'fx_tex_glow').setTint(0x22c55e).setAlpha(0.18).setBlendMode(Phaser.BlendModes.ADD).setDisplaySize((R0 + 8) * 2, (R0 + 8) * 2);
        cont.add(glow);
        this.tweens.add({ targets: glow, alpha: { from: 0.1, to: 0.32 }, scale: { from: 0.95, to: 1.12 }, duration: 800, yoyo: true, repeat: -1 });
      }
      cont.add(this.add.image(0, 0, 'ui_badge').setDisplaySize(R0 * 2 + 6, R0 * 2 + 6).setTint(0x0b1220).setAlpha(0.95));
      cont.add(this.add.image(0, 0, 'ui_badge').setDisplaySize(R0 * 2, R0 * 2).setTint(maxed || unlocked ? cls.color : (canUnlock ? 0x22c55e : 0x334155)).setAlpha(maxed || unlocked ? 1 : (canUnlock ? 0.9 : 0.6)));
      cont.add(this.add.image(0, 0, 'ui_badge').setDisplaySize(R0 * 2 - 12, R0 * 2 - 12).setTint(0x0b1220).setAlpha(0.92));
      const nodeIco = iconImage(this, 0, 0, skillIconName(s), { size: 28 });
      if (!unlocked && !canUnlock) nodeIco.setAlpha(0.4); // v10: skill terkunci tampak redup (tint ikon sudah tidak dipakai)
      cont.add(nodeIco);
      // Pips level.
      if (s.maxLevel > 1) {
        for (let l = 0; l < s.maxLevel; l++) {
          const px = (l - (s.maxLevel - 1) / 2) * 9;
          const pip = this.add.image(px, R0 + 10, 'fx_tex_flash').setTint(l < lvl ? cls.color : 0x334155).setDisplaySize(5, 5);
          cont.add(pip);
        }
      }
      cont.add(this.add.text(0, -R0 - 12, s.name, { fontFamily: F_UI, fontSize: '11px', color: unlocked ? '#f8fafc' : '#94a3b8', fontStyle: 'bold', align: 'center', wordWrap: { width: 120 } }).setOrigin(0.5, 1));
      const tag = s.type === 'passive' ? 'PASIF' : 'AKTIF';
      cont.add(this.add.text(0, R0 + 22, maxed ? 'MAX' : 'Lv' + lvl + '/' + s.maxLevel + '  ' + tag, { fontFamily: F_UI, fontSize: '9px', color: maxed ? '#fde68a' : '#64748b' }).setOrigin(0.5));
      // Kunci level.
      if (Data.char.level < s.reqLevel) {
        cont.add(iconImage(this, R0 - 8, -R0 + 8, 'lock', { size: 13, color: 0xfca5a5 }));
        cont.add(this.add.text(R0 - 6, -R0 + 20, 'Lv' + s.reqLevel, { fontFamily: F_UI, fontSize: '8px', color: '#fca5a5' }).setOrigin(0, 0.5));
      }
      const area = makeInteractive(this.add.rectangle(0, 0, R0 * 2 + 20, R0 * 2 + 40, 0x000000, 0.001), { useHandCursor: true });
      cont.add(area);
      area.on('pointerup', () => { Sfx.click(); this.showDetail(s); });
    }
    makeButton(this, W / 2, H - 32, 200, 44, 'Kembali', { color: 0x1f2937, icon: 'back', size: 14, onClick: () => this.scene.start('Lobby') });
  }
  showDetail(s) {
    if (this.detail) this.detail.forEach((o) => o.destroy());
    this.detail = [];
    const W = this.scale.width, H = this.scale.height;
    const cls = CLASSES[this.selected] || CLASSES.warrior;
    const bw = Math.min(430, W - 60), bh = 280;
    const bx = W / 2 - bw / 2, by = H / 2 - bh / 2;
    const dim = makeInteractive(uiFill(this, 0, 0, W, H, 0x000000, 0.55, 0)); // blok klik latar (v12: shape eksplisit)
    const p = panel(this, bx, by, bw, bh, 0x0f172a, 0.99, 14);
    this.detail.push(dim, p);
    this.detail.push(iconImage(this, bx + 44, by + 44, skillIconName(s), { size: 40, color: 0xffffff }));
    this.detail.push(this.add.text(bx + 74, by + 26, s.name, { fontFamily: F_UI, fontSize: '17px', color: '#ffffff', fontStyle: 'bold', wordWrap: { width: bw - 96 } }).setOrigin(0, 0.5));
    const tag = s.type === 'passive' ? 'SKILL PASIF' : 'SKILL AKTIF';
    this.detail.push(this.add.text(bx + 74, by + 50, tag + (s.effect.mp ? '  •  ' + s.effect.mp + ' MP' : ''), { fontFamily: F_UI, fontSize: '11px', color: '#a78bfa' }).setOrigin(0, 0.5));
    // v12: badge elemen skill — strategi segitiga elemen terbaca sejak popup.
    if (s.fx && s.fx.elem && ELEM_GROUP[s.fx.elem]) {
      const gi = ELEM_GROUP_INFO[ELEM_GROUP[s.fx.elem]];
      const ebY = by + 68;
      this.detail.push(uiFill(this, bx + 74 + 52, ebY, 92, 16, 0x0b1220, 0.9, 0));
      this.detail.push(this.add.text(bx + 74, ebY, 'ELEMEN: ' + gi.name, { fontFamily: F_PIX, fontSize: '8px', color: gi.color }).setOrigin(0, 0.5));
    }
    this.detail.push(this.add.text(bx + 22, by + 80, s.desc, { fontFamily: F_UI, fontSize: '12.5px', color: '#cbd5e1', wordWrap: { width: bw - 44 }, lineSpacing: 4 }).setOrigin(0, 0));
    // Persyaratan.
    const lvl = SkillState.get(s.id);
    const reqs = [];
    if (Data.char.level < s.reqLevel) reqs.push('Level ' + s.reqLevel + ' (sekarang ' + Data.char.level + ')');
    for (const r of (s.requires || [])) {
      if (SkillState.get(r) < 1) {
        const rd = skillById(this.selected, r);
        reqs.push('Buka ' + (rd ? rd.name : r) + ' dulu');
      }
    }
    if ((Data.char.skillPoints || 0) < s.cost) reqs.push('Poin skill kurang (' + s.cost + ' dibutuhkan)');
    if (reqs.length) {
      this.detail.push(this.add.text(bx + 22, by + 130, 'Syarat:', { fontFamily: F_UI, fontSize: '11px', color: '#fca5a5', fontStyle: 'bold' }).setOrigin(0, 0.5));
      this.detail.push(this.add.text(bx + 22, by + 148, reqs.join('\n'), { fontFamily: F_UI, fontSize: '11px', color: '#94a3b8', lineSpacing: 3 }).setOrigin(0, 0));
    }
    // Efek ter-scale.
    const eff = skillEffectScaled(s, Math.max(1, lvl));
    const fx = [];
    if (eff.dmg) fx.push('Damage ' + Math.round(eff.dmg * 100) + '% ATK' + (eff.aoe ? ' (semua musuh)' : ''));
    if (eff.hits) fx.push(eff.hits + ' serangan beruntun');
    if (eff.critBonus) fx.push('Crit +' + Math.round(eff.critBonus * 100) + '%');
    if (eff.pierce) fx.push('Menembus ' + Math.round(eff.pierce * 100) + '% DEF');
    if (eff.dot) fx.push('Racun ' + Math.round(eff.dot * 100) + '% ATK/giliran');
    if (eff.heal) fx.push('Pulih ' + Math.round(eff.heal * 100) + '% ATK');
    if (eff.healAoe) fx.push('Pulih tim ' + Math.round(eff.healAoe * 100) + '% ATK');
    if (eff.shield) fx.push('Perisai ' + Math.round(eff.shield * 100) + '% HP');
    if (eff.atkBuff) fx.push('ATK +' + Math.round(eff.atkBuff * 100) + '%');
    if (eff.mark) fx.push('Damage diterima musuh +' + Math.round(eff.mark * 100) + '%');
    if (eff.evasion) fx.push('Hindar ' + Math.round(eff.evasion * 100) + '%');
    this.detail.push(this.add.text(bx + 22, by + 186, fx.join('\n'), { fontFamily: F_UI, fontSize: '11px', color: '#fbbf24', lineSpacing: 3 }).setOrigin(0, 0));
    // Tombol.
    const maxed = lvl >= s.maxLevel;
    this.detail.push(makeButton(this, W / 2 - 94, by + bh - 34, 142, 44, maxed ? 'MAKSIMAL' : (lvl ? 'Upgrade ' + s.cost + ' poin' : 'Buka ' + s.cost + ' poin'), {
      color: maxed ? 0x1f2937 : cls.color, size: 12, disabled: maxed || reqs.length > 0,
      onClick: async () => {
        const r = await Data.unlockSkill(s.id);
        if (r.ok) { Sfx.levelup(); this.scene.restart({ classKey: this.selected }); }
        else Toast.show(this, { title: 'Tidak bisa', message: r.error || '', icon: 'cross', color: 0xdc2626 });
      },
    }));
    this.detail.push(makeButton(this, W / 2 + 94, by + bh - 34, 142, 44, 'Tutup', { color: 0x1f2937, size: 13, onClick: () => { this.detail.forEach((o) => o.destroy()); this.detail = null; } }));
  }
}

/* ---------- PANDAI BESI (forge profesional) ---------- */
class ForgeScene extends Phaser.Scene {
  constructor() { super('Forge'); }
  create() {
    const W = this.scale.width, H = this.scale.height;
    // v9: latar bengkel = aset bg_forge + dim + bara partikel aset.
    if (this.textures.exists('asset_bgx_bg_forge')) {
      const bg = this.add.image(W / 2, H / 2, 'asset_bgx_bg_forge');
      const sc = Math.max(W / bg.width, H / bg.height);
      bg.setDisplaySize(bg.width * sc, bg.height * sc);
      uiFill(this, W / 2, H / 2, W, H, 0x0a0505, 0.38);
    } else {
      uiFill(this, W / 2, H / 2, W, H, 0x1c0a0a);
      uiFill(this, W / 2, H * 0.75, W, H / 2, 0x0a0505, 0.9);
    }
    this.add.particles(0, 0, this.textures.exists('dot') ? 'dot' : 'fx_tex_pixel', { x: { min: 0, max: W }, y: H, lifespan: 5000, speedY: { min: -30, max: -8 }, speedX: { min: -8, max: 8 }, scale: { min: 0.2, max: 0.8 }, quantity: 1, frequency: 380, tint: [0xfbbf24, 0xf59e0b] });

    // ---------- BENGKEL: pandai besi + tungku + paron (digambar) ----------
    const smithBaseX = Math.min(300, W * 0.24), smithBaseY = H * 0.10;
    // v9: bengkel = SPRITE PANDAI BESI aset + tungku lava + paron batu + palu ikon.
    const forgeX = smithBaseX + 120, forgeY = smithBaseY + 60;
    if (this.textures.exists('asset_deco_lavacrack')) this.add.image(forgeX, forgeY + 40, 'asset_deco_lavacrack').setScale(2.1).setDepth(5);
    const fireColors = [0xfbbf24, 0xf97316, 0xef4444];
    const flames = [];
    for (let i = 0; i < 5; i++) {
      const f = this.add.image(forgeX - 26 + i * 13, forgeY + 30, 'fx_tex_flash').setTint(pick(fireColors)).setAlpha(0.9).setDisplaySize(R(10, 18), R(10, 18)).setBlendMode(Phaser.BlendModes.ADD).setDepth(6);
      this.tweens.add({ targets: f, scaleY: { from: 0.7, to: 1.4 }, alpha: { from: 0.6, to: 1 }, duration: R(160, 300), yoyo: true, repeat: -1 });
      flames.push(f);
    }
    const forgeGlow = this.add.image(forgeX, forgeY + 26, 'fx_tex_glow').setTint(0xf97316).setAlpha(0.14).setScale(1.0).setBlendMode(Phaser.BlendModes.ADD).setDepth(5);
    this.tweens.add({ targets: forgeGlow, alpha: { from: 0.09, to: 0.2 }, duration: 700, yoyo: true, repeat: -1 });
    const anvilX = smithBaseX - 20, anvilY = smithBaseY + 66;
    this.add.image(anvilX, anvilY + 12, 'asset_deco_rock2').setTint(0x52525b).setDisplaySize(72, 36).setDepth(5);
    const smithX = anvilX, smithHeadY = smithBaseY - 6;
    if (this.textures.exists('itx_smith')) {
      if (!this.anims.exists('itx_smith_idle')) this.anims.create({ key: 'itx_smith_idle', frames: this.anims.generateFrameNumbers('itx_smith', { start: 0, end: 1 }), frameRate: 2, repeat: -1 });
      const sm = this.add.sprite(smithX - 4, smithHeadY + 64, 'itx_smith', 0).setOrigin(0.5, 1).setScale(1.15).setDepth(7);
      try { sm.play('itx_smith_idle'); } catch (_) {}
    }
    // PALU aset (di tangan kanan) — animasi menempa.
    const hammer = this.add.image(0, 0, iconTexture(this, 'hammer', 0xcbd5e1)).setDisplaySize(34, 34).setDepth(8);
    if (iconTexture(this, 'hammer').indexOf('ui_icon_') === 0) hammer.setTint(0xcbd5e1);
    hammer.setPosition(smithX + 20, smithHeadY + 30);
    this.hammer = hammer;
    this.playSmithIdle();

    // Dialog sang pandai besi.
    const smithName = 'Bang Bara';
    const dlines = [
      'Ada bahan? Aku bisa bikin senjatamu lebih galak.',
      'Tulisumu masih panas. Mau kutempa jadi apa?',
      'Bahan langka bikin barang legendaris. Cari terus.',
    ];
    // v9: dialog pandai besi = aset toast 9-slice.
    uiSlice(this, smithBaseX - 130 + 150, smithBaseY + 108 + 23, 300, 46, 'ui_toast', 0xffffff).setAlpha(0.88);
    uiSlice(this, smithBaseX - 130 + 150, smithBaseY + 108 + 23, 296, 42, 'ui_outline', 0xf2c230).setAlpha(0.4);
    const diaTxt = this.add.text(smithBaseX - 118, smithBaseY + 131, smithName + ': "' + pick(dlines) + '"', { fontFamily: F_UI, fontSize: '11.5px', color: '#f3e3c3', wordWrap: { width: 276 } }).setOrigin(0, 0.5);

    sceneHeader(this, 'PANDAI BESI', 'Tukar material drop monster jadi equipment', { y: H * 0.05, color: '#fde68a' });

    // ---------- TAB KATEGORI ----------
    // Pertahankan tab antar restart (dulu di-reset -> tab penempa tidak bisa ganti).
    this.tab = this.tab || 'weapon';
    const tabs = [
      { key: 'weapon', name: 'Senjata', icon: 'sword' },
      { key: 'armor', name: 'Zirah', icon: 'shield' },
      { key: 'accessory', name: 'Aksesoris', icon: 'ring' },
    ];
    tabs.forEach((t, i) => {
      makeButton(this, W / 2 + (i - 1) * 130, H * 0.115, 120, 38, t.name, {
        color: this.tab === t.key ? 0xb45309 : 0x1f2937, size: 13, icon: t.icon,
        onClick: () => { this.tab = t.key; this.scene.restart(); },
      });
    });

    // ---------- DAFTAR RESEP ----------
    const inv = Data.char.inventory || {};
    const cls = CLASSES[Data.char.classKey] || null;
    const recipes = FORGE_RECIPES.filter((r) => {
      const it = itemById(r.out);
      return it && it.cat === this.tab && (!it.class || !cls || it.class === cls.key);
    });
    const listTop = Math.max(H * 0.24, smithBaseY + 166);
    const cols = W > 1000 ? 4 : 3;
    const gapX = Math.min(196, (W - 70) / cols);
    const cardW = gapX - 18, cardH = 172;
    const startX = W / 2 - ((Math.min(cols, recipes.length) - 1) / 2) * gapX;
    // Center-kan blok kartu vertikal di ruang sisa — fix: dulu baris pertama
    // menumpuk dialog pandai besi & bawah layar kosong melompong saat resep
    // cuma sedikit (mis. class archer).
    const nRows = Math.ceil(recipes.length / cols);
    const availH = (H - 84) - listTop;
    const blockH = nRows * (cardH + 10) - 10;
    const topY = listTop + Math.max(0, (availH - blockH) / 2);
    recipes.forEach((recipe, i) => {
      const it = itemById(recipe.out);
      const row = Math.floor(i / cols), col = i % cols;
      const x = startX + col * gapX, y = topY + row * (cardH + 10) + cardH / 2;
      if (y > H - 60) return;
      const tierCol = tierInfo(it.tier);
      const canCraft = Object.entries(recipe.cost).every(([mid, need]) => (inv[mid] || 0) >= need);
      // v9: kartu resep = tile aset + outline tier.
      uiFill(this, x + 2, y - cardH / 2 + 4, cardW, cardH, 0x000000, 0.35, 0);
      uiSlice(this, x, y, cardW, cardH, 'ui_tile', 0x120d09).setAlpha(0.96);
      uiSlice(this, x, y, cardW - 4, cardH - 4, 'ui_outline', tierCol.color).setAlpha(canCraft ? 0.9 : 0.35);
      uiFill(this, x - cardW / 2, y - cardH / 2, cardW, 5, tierCol.color, 1, 0);
      this.add.image(x, y - cardH / 2 + 34, 'ui_badge').setDisplaySize(46, 46).setTint(tierCol.color).setAlpha(0.14);
      this.add.image(x, y - cardH / 2 + 34, 'ui_outline').setDisplaySize(46, 46).setTint(tierCol.color).setAlpha(0.5);
      addItemIcon(this, x, y - cardH / 2 + 34, it.id, 38);
      this.add.text(x, y - cardH / 2 + 60, it.name, { fontFamily: F_UI, fontSize: '11px', color: '#f8fafc', fontStyle: 'bold', align: 'center', wordWrap: { width: cardW - 12 } }).setOrigin(0.5, 0);
      this.add.text(x, y - cardH / 2 + 80, tierInfo(it.tier).name + (it.atk ? '  •  ATK ' + it.atk : '') + (it.def ? '  •  DEF ' + it.def : ''), { fontFamily: F_UI, fontSize: '9.5px', color: hex(tierCol.color), fontStyle: 'bold' }).setOrigin(0.5, 0);
      const matKeys = Object.keys(recipe.cost);
      const costY = y - cardH / 2 + 104;
      matKeys.forEach((mid, mi) => {
        const need = recipe.cost[mid];
        const have = inv[mid] || 0;
        const ok = have >= need;
        const mxx = x - (matKeys.length - 1) * 24 + mi * 48;
        this.add.image(mxx - 8, costY, 'ui_badge').setDisplaySize(22, 22).setTint(0x0b1220).setAlpha(0.9);
        this.add.image(mxx - 8, costY, 'ui_outline').setDisplaySize(22, 22).setTint(ok ? 0x22c55e : 0xef4444).setAlpha(0.8);
        addItemIcon(this, mxx - 8, costY, mid, 24);
        this.add.text(mxx + 8, costY, have + '/' + need, { fontFamily: F_UI, fontSize: '9px', color: ok ? '#86efac' : '#fca5a5', fontStyle: 'bold' }).setOrigin(0, 0.5);
      });
      makeButton(this, x, y + cardH / 2 - 16, cardW - 24, 26, canCraft ? 'Tempa' : 'Bahan Kurang', { color: canCraft ? 0xd97706 : 0x1f2937, size: 11, icon: 'hammer', disabled: !canCraft, onClick: () => this.craftItem(recipe, it, x, y) });
    });
    if (!recipes.length) this.add.text(W / 2, H * 0.5, 'Belum ada resep yang cocok dengan classmu.', { fontFamily: F_UI, fontSize: '14px', color: '#94a3b8' }).setOrigin(0.5);
    makeButton(this, W - 90, H - 34, 140, 44, 'Kembali', { color: 0x1f2937, icon: 'back', size: 14, onClick: () => this.scene.start('Lobby') });
  }
  playSmithIdle() {
    // Palu mengangkat-menghantam pelan.
    this.hammerAngleTween = this.tweens.add({ targets: this.hammer, rotation: { from: -0.9, to: -0.2 }, duration: 900, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
  }
  craftItem(recipe, it, x, y) {
    if (this.crafting) return;
    this.crafting = true;
    // Animasi menempa: 3 pukulan palu + percikan + kilau rarity.
    if (this.hammerAngleTween) this.hammerAngleTween.remove();
    let strikes = 0;
    const doStrike = () => {
      strikes++;
      this.hammer.setRotation(-1.1);
      this.tweens.add({ targets: this.hammer, rotation: -0.1, duration: 90, ease: 'Quad.easeIn', onComplete: () => {
        Sfx.forge(); shake(this, 2);
        fxSparks(this, this.hammer.x - 20, this.hammer.y + 18, pick([0xfbbf24, 0xf97316, 0xfde68a]), 12);
        if (strikes < 3) setTimeout(doStrike, 320);
        else this.finishCraft(recipe, it, x, y);
      } });
    };
    doStrike();
  }
  finishCraft(recipe, it, x, y) {
    Data.craft(recipe.out).then((r) => {
      this.crafting = false;
      if (!r.ok) {
        Toast.show(this, { title: 'Penempaan gagal', message: r.error || 'Bahan kurang.', icon: 'cross', color: 0xdc2626 });
        this.playSmithIdle();
        return;
      }
      const ti = tierInfo(it.tier);
      Sfx.chest(); Sfx.levelup();
      fxFlash(this, ti.color, 260, 0.3);
      fxRing(this, this.hammer.x - 20, this.hammer.y + 18, ti.color, 80, 500);
      // Kartu hasil.
      const W = this.scale.width, H = this.scale.height;
      const cont = this.add.container(W / 2, H / 2).setScrollFactor(0).setDepth(3000);
      // v9: kartu hasil tempa = aset.
      cont.add(uiSlice(this, 0, 0, 300, 192, 'ui_panel', 0x0b0b12).setAlpha(0.94));
      cont.add(uiSlice(this, 0, 0, 296, 188, 'ui_outline', ti.color));
      cont.add(this.add.text(0, -68, 'PENEMPAAAN SELESAI', { fontFamily: F_HEAD, fontSize: '11px', color: '#fde68a' }).setOrigin(0.5));
      cont.add(addRarityIcon(this, 0, -14, recipe.out, 62));
      cont.add(this.add.text(0, 32, it.name, { fontFamily: F_UI, fontSize: '16px', color: hex(ti.color), fontStyle: 'bold' }).setOrigin(0.5));
      cont.add(this.add.text(0, 54, ti.name.toUpperCase(), { fontFamily: F_HEAD, fontSize: '9px', color: hex(ti.color) }).setOrigin(0.5));
      cont.add(makeButton(this, 0, 78, 140, 38, 'Lanjut tempa', { color: 0x16a34a, size: 12, onClick: () => { cont.destroy(); this.scene.restart(); } }));
      cont.setScale(0.4);
      this.tweens.add({ targets: cont, scale: 1, duration: 260, ease: 'Back.easeOut' });
      this.playSmithIdle();
    });
  }
}
/* ============================================================================
 * 10. SCENE: LEADERBOARD / PROFILE (alokasi stat) / ACHIEVEMENTS
 * ========================================================================== */
class LeaderboardScene extends Phaser.Scene {
  constructor() { super('Leaderboard'); }
  create() {
    const W = this.scale.width, H = this.scale.height;
    uiFill(this, W / 2, H / 2, W, H, 0x0b1120);
    uiFill(this, W / 2, H * 0.75, W, H / 2, 0x1a2540, 0.9);
    sceneHeader(this, 'PAPAN PERINGKAT', 'Posisimu di antara para petualang', { y: H * 0.05 });
    this.category = this.category || 'level';
    const cats = [
      { key: 'level', name: 'Level' }, { key: 'gold', name: 'Kaya' },
      { key: 'wins', name: 'Menang' }, { key: 'reputation', name: 'Reputasi' },
    ];
    cats.forEach((c, i) => {
      makeButton(this, W / 2 + (i - 1.5) * 118, H * 0.11, 108, 36, c.name, {
        color: this.category === c.key ? 0x0ea5e9 : 0x1e293b, size: 12,
        onClick: () => { this.category = c.key; this.scene.restart(); },
      });
    });
    Data.leaderboard(this.category).then((d) => {
      const list = (d && d.list) || [];
      const bw = Math.min(640, W - 40);
      const rowH = 44;
      const topY = H * 0.17;
      if (!list.length) this.add.text(W / 2, H * 0.4, 'Belum ada data peringkat.', { fontFamily: F_UI, fontSize: '14px', color: '#64748b' }).setOrigin(0.5);
      list.slice(0, Math.floor((H - topY - 90) / rowH)).forEach((p, i) => {
        const y = topY + i * rowH + rowH / 2;
        // v9: baris peringkat = tile aset + outline.
        const isMe = p.isMe;
        uiSlice(this, W / 2, y, bw, rowH - 4, 'ui_tile', isMe ? 0x134e4a : 0x0f172a).setAlpha(0.92);
        uiSlice(this, W / 2, y, bw - 4, rowH - 8, 'ui_outline', isMe ? 0x2dd4bf : 0xffffff).setAlpha(isMe ? 0.9 : 0.07);
        // Medali peringkat.
        const medalColors = { 1: 0xfacc15, 2: 0xcbd5e1, 3: 0xb45309 };
        if (medalColors[p.rank]) {
          iconImage(this, W / 2 - bw / 2 + 30, y, 'medal', { size: 26, color: medalColors[p.rank] });
        } else {
          this.add.text(W / 2 - bw / 2 + 30, y, String(p.rank), { fontFamily: F_HEAD, fontSize: '12px', color: '#64748b' }).setOrigin(0.5);
        }
        // Ikon class.
        const clsIcon = { warrior: 'sword', mage: 'fire', assassin: 'dagger', archer: 'bow' }[p.classKey] || 'person';
        iconImage(this, W / 2 - bw / 2 + 62, y, clsIcon, { size: 18, color: (CLASSES[p.classKey] || {}).color || 0x64748b });
        // Nama + title.
        const nameCol = isMe ? '#5eead4' : '#f1f5f9';
        this.add.text(W / 2 - bw / 2 + 84, y - 8, (p.name || 'Petualang') + (p.title ? '  —  ' + p.title : ''), { fontFamily: F_UI, fontSize: '13.5px', color: nameCol, fontStyle: 'bold' }).setOrigin(0, 0.5);
        this.add.text(W / 2 - bw / 2 + 84, y + 9, 'Lv.' + p.level + '  •  ' + ((CLASSES[p.classKey] || {}).name || '—') + '  •  ' + p.rankKey, { fontFamily: F_UI, fontSize: '10.5px', color: '#64748b' }).setOrigin(0, 0.5);
        // Nilai.
        const valTxt = this.category === 'gold' ? fmt(p.value) + ' KZC' : this.category === 'reputation' ? fmt(p.value) + ' rep' : fmt(p.value);
        this.add.text(W / 2 + bw / 2 - 20, y, valTxt, { fontFamily: F_UI, fontSize: '14px', color: '#fde68a', fontStyle: 'bold' }).setOrigin(1, 0.5);
      });
      // Posisi saya.
      if (d && d.myRank) {
        const mr = d.myRank;
        const y = H - 58;
        // v9: panel posisi saya = aset.
        uiSlice(this, W / 2, y + 22, bw, 44, 'ui_tile', 0x134e4a).setAlpha(0.95);
        uiSlice(this, W / 2, y + 22, bw - 4, 40, 'ui_outline', 0x2dd4bf);
        this.add.text(W / 2 - bw / 2 + 24, y + 22, 'POSMU:  #' + (mr.rank || '—'), { fontFamily: F_UI, fontSize: '13px', color: '#5eead4', fontStyle: 'bold' }).setOrigin(0, 0.5);
        this.add.text(W / 2 + bw / 2 - 20, y + 22, this.category === 'gold' ? fmt(mr.value) + ' KZC' : fmt(mr.value), { fontFamily: F_UI, fontSize: '13px', color: '#fde68a', fontStyle: 'bold' }).setOrigin(1, 0.5);
      }
    });
    makeButton(this, W / 2, H - 26, 200, 40, 'Kembali', { color: 0x1f2937, icon: 'back', size: 13, onClick: () => this.scene.start('Lobby') });
  }
}

/* ---------- PROFILE + ALOKASI STAT ---------- */
class ProfileScene extends Phaser.Scene {
  constructor() { super('Profile'); }
  create() {
    const W = this.scale.width, H = this.scale.height;
    const c = Data.char;
    uiFill(this, W / 2, H / 2, W, H, 0x0b1120);
    uiFill(this, W / 2, H * 0.75, W, H / 2, 0x111c33, 0.9);
    sceneHeader(this, 'PROFIL', 'Kartu rank, statistik & alokasi poin', { y: H * 0.045 });

    // Kartu utama kiri.
    const cardW = Math.min(330, W * 0.36), cardH = H * 0.5;
    const cx = Math.max(20, W * 0.05), cy = H * 0.11;
    const rk = rankInfo(c.rankKey);
    const cls = CLASSES[c.classKey];
    // v9: kartu profil = aset 9-slice + outline rank + band.
    uiSlice(this, cx + cardW / 2, cy + cardH / 2, cardW, cardH, 'ui_panel', 0x0f172a).setAlpha(0.98);
    uiSlice(this, cx + cardW / 2, cy + cardH / 2, cardW - 4, cardH - 4, 'ui_outline', rk.color).setAlpha(0.8);
    uiFill(this, cx, cy, cardW, 84, rk.color, 0.2, 0);
    // Hero + nama + title.
    if (c.classKey) {
      const hv = heroVisual(this, c.classKey, c.customization, 3.2);
      const hero = this.add.sprite(cx + cardW / 2, cy + 96, hv.key, hv.frame || 0).setOrigin(0.5, 1).setScale(hv.scale);
      try { hero.play(hv.anim.idle); } catch (_) {}
      this.add.image(cx + cardW / 2, cy + 98, 'fx_tex_shadow').setDisplaySize(70, 16).setAlpha(0.45);
      // Pet aktif tampil di kartu profil.
      if (PetState.active && petTexExists(this, PetState.active, PetState.stage(PetState.active))) {
        const pk = spawnPetCompanion(this, PetState.active, {
          x: cx + cardW - 64, y: cy + 96, depth: 20, scale: 1.5,
          follow: { get: () => ({ x: cx + cardW - 64, y: cy + 96 }) },
        });
        const petInfo = PetState.activePet;
        if (petInfo) this.add.text(cx + cardW - 64, cy + 112, petInfo.name + ' Lv.' + PetState.activeLevel, { fontFamily: F_UI, fontSize: '9.5px', color: PET_RARITY_INFO[petInfo.rarity].color, stroke: '#0b0b12', strokeThickness: 2 }).setOrigin(0.5).setDepth(21);
      }
    }
    this.add.text(cx + cardW / 2, cy + 24, c.name || 'Petualang', { fontFamily: F_UI, fontSize: '20px', color: '#f8fafc', fontStyle: 'bold' }).setOrigin(0.5);
    this.add.text(cx + cardW / 2, cy + 48, (c.title ? '"' + c.title + '"  •  ' : '') + 'Rank ' + rk.key + ' — ' + rk.name, { fontFamily: F_UI, fontSize: '12px', color: hex(rk.color) }).setOrigin(0.5);
    if (cls) this.add.text(cx + cardW / 2, cy + 68, cls.name + '  •  Level ' + c.level, { fontFamily: F_UI, fontSize: '12px', color: '#94a3b8' }).setOrigin(0.5);
    // Friend ID + tombol salin.
    const fid = c.friendId || 'KZ-DEMO';
    // v9: kotak friend ID = aset.
    uiSlice(this, cx + 18 + (cardW - 36) / 2, cy + cardH - 206 + 28, cardW - 36, 56, 'ui_tile', 0x0d1526).setAlpha(0.9);
    uiSlice(this, cx + 18 + (cardW - 36) / 2, cy + cardH - 206 + 28, cardW - 40, 52, 'ui_outline', 0x06b6d4).setAlpha(0.6);
    iconImage(this, cx + 40, cy + cardH - 178, 'friends', { size: 20, color: 0x06b6d4 });
    this.add.text(cx + 58, cy + cardH - 190, 'FRIEND ID', { fontFamily: F_UI, fontSize: '9px', color: '#64748b' }).setOrigin(0, 0.5);
    this.add.text(cx + 58, cy + cardH - 172, fid, { fontFamily: F_HEAD, fontSize: '11px', color: '#67e8f9' }).setOrigin(0, 0.5);
    makeButton(this, cx + cardW - 48, cy + cardH - 178, 52, 34, '', { color: 0x155e75, size: 11, onClick: () => {
      try { navigator.clipboard.writeText(fid); Toast.show(this, { title: 'Friend ID disalin', message: fid, icon: 'copy', color: 0x06b6d4 }); } catch (_) {}
    } }).add(iconImage(this, 0, 0, 'copy', { size: 15, color: 0x67e8f9 }));
    // XP bar.
    const xpPct = clamp((c.xp || 0) / (c.xpForNext || xpNeed(c.level)), 0, 1);
    const xpY = cy + cardH - 130;
    this.add.text(cx + 20, xpY - 10, 'XP', { fontFamily: F_UI, fontSize: '10px', color: '#8b96ab' }).setOrigin(0, 0.5);
    // v9: XP bar = aset.
    uiBar(this, cx + 20 + (cardW - 40) / 2, xpY + 5, cardW - 40, 10, xpPct, 0x7c3aed, { frameTint: 0x1e293b });
    this.add.text(cx + 20, xpY + 20, fmt(c.xp || 0) + ' / ' + fmt(c.xpForNext || xpNeed(c.level)), { fontFamily: F_UI, fontSize: '9.5px', color: '#64748b' }).setOrigin(0, 0.5);
    // Statistik ringkas.
    const counters = [
      ['Monster dibunuh', c.monstersKilled], ['Quest selesai', c.questsCompleted],
      ['Dungeon tuntas', c.dungeonsCleared], ['Lantai dilewati', c.floorsCleared],
      ['Boss kalah', c.bossesDefeated], ['Menang / Kalah', (c.wins || 0) + ' / ' + (c.losses || 0)],
      ['Peti dibuka', c.chestsOpened], ['Item ditempa', c.itemsCrafted],
    ];
    counters.forEach((ct, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = cx + 20 + col * ((cardW - 40) / 2);
      const y = cy + cardH - 88 + row * 26;
      this.add.text(x, y, ct[0], { fontFamily: F_UI, fontSize: '10px', color: '#64748b' }).setOrigin(0, 0.5);
      this.add.text(x + (cardW - 40) / 2 - 8, y, fmt(ct[1] || 0), { fontFamily: F_UI, fontSize: '11px', color: '#e2e8f0', fontStyle: 'bold' }).setOrigin(1, 0.5);
    });

    // ---------- PANEL KANAN: ALOKASI STAT ----------
    const px = cx + cardW + 20, pw = W - px - 20;
    panel(this, px, cy, pw, H * 0.33, 0x0f172a, 0.98, 14);
    this.add.text(px + 18, cy + 20, 'ALOKASI STAT', { fontFamily: F_HEAD, fontSize: '11px', color: '#f2c230' }).setOrigin(0, 0.5);
    const pts = c.statPoints || 0;
    const ptsTxt = this.add.text(px + pw - 18, cy + 20, pts + ' poin tersisa', { fontFamily: F_UI, fontSize: '12px', color: pts > 0 ? '#86efac' : '#64748b', fontStyle: 'bold' }).setOrigin(1, 0.5);
    const stats = computeStats(c);
    const STEP = { hp: 10, mp: 6, atk: 2, def: 2, spd: 1, crit: 1 };
    const rows = [
      { key: 'hp', name: 'HP Maks', icon: 'heart', color: 0xef4444, cur: stats.hp },
      { key: 'mp', name: 'MP Maks', icon: 'mana', color: 0x3b82f6, cur: stats.mp },
      { key: 'atk', name: 'Serangan', icon: 'sword', color: 0xf97316, cur: stats.atk },
      { key: 'def', name: 'Pertahanan', icon: 'shield', color: 0x94a3b8, cur: stats.def },
      { key: 'spd', name: 'Kecepatan', icon: 'sparkle', color: 0x22d3ee, cur: stats.spd },
      { key: 'crit', name: 'Critical', icon: 'eye', color: 0xfacc15, cur: stats.crit },
    ];
    rows.forEach((r, i) => {
      const y = cy + 48 + i * 34;
      iconImage(this, px + 32, y, r.icon, { size: 18, color: r.color });
      this.add.text(px + 50, y - 8, r.name, { fontFamily: F_UI, fontSize: '12px', color: '#cbd5e1' }).setOrigin(0, 0.5);
      this.add.text(px + 50, y + 8, 'sekarang ' + r.cur + (r.key !== 'crit' ? '  (+' + (STEP[r.key] * 1) + '/poin)' : '  (+1%/poin)'), { fontFamily: F_UI, fontSize: '9.5px', color: '#64748b' }).setOrigin(0, 0.5);
      makeButton(this, px + pw - 44, y, 44, 32, '', { color: pts > 0 ? 0x16a34a : 0x1f2937, size: 14, disabled: pts <= 0, onClick: async () => {
        const res = await Data.allocateStat(r.key, 1);
        if (res.ok) { Sfx.levelup(); this.scene.restart(); }
        else Toast.show(this, { title: 'Gagal', message: res.error || '', icon: 'cross', color: 0xdc2626 });
      } }).add(iconImage(this, 0, 0, 'plus', { size: 14, color: pts > 0 ? 0xfde68a : 0x475569 }));
    });

    // ---------- PANEL: nama panggung & title ----------
    panel(this, px, cy + H * 0.33 + 12, pw, H * 0.16, 0x0f172a, 0.98, 14);
    this.add.text(px + 18, cy + H * 0.33 + 30, 'IDENTITAS', { fontFamily: F_HEAD, fontSize: '11px', color: '#f2c230' }).setOrigin(0, 0.5);
    makeButton(this, px + pw - 78, cy + H * 0.33 + 30, 124, 32, 'Ganti Nama', { color: 0x1e40af, icon: 'person', size: 11, onClick: () => {
      const name = prompt('Nama panggung baru (2-16 huruf):', c.name || '');
      if (name && name.trim().length >= 2) Data.saveProfile({ gameName: name.trim().slice(0, 16) }).then(() => this.scene.restart());
    } });
    // Title selector (halaman bergeser tiap klik "lanjut").
    const titles = [''].concat(c.unlockedTitles || []);
    this._titlePage = this._titlePage || 0;
    const perPage = 5;
    const maxPage = Math.max(0, Math.ceil(titles.length / perPage) - 1);
    this._titlePage = Math.min(this._titlePage, maxPage);
    const pageTitles = titles.slice(this._titlePage * perPage, this._titlePage * perPage + perPage);
    this.add.text(px + 18, cy + H * 0.33 + 58, 'Title:', { fontFamily: F_UI, fontSize: '12px', color: '#8b96ab' }).setOrigin(0, 0.5);
    pageTitles.forEach((t, i) => {
      const tx = px + 70 + i * 108;
      makeButton(this, tx, cy + H * 0.33 + 58, 102, 30, t || 'Tanpa title', {
        color: c.title === t ? 0x7c3aed : 0x1f2937, size: 9.5,
        onClick: () => Data.saveProfile({ title: t }).then(() => this.scene.restart()),
      });
    });
    if (maxPage > 0) makeButton(this, px + pw - 40, cy + H * 0.33 + 58, 60, 30, (this._titlePage + 1) + '/' + (maxPage + 1), { color: 0x1e293b, size: 9, onClick: () => { this._titlePage = (this._titlePage + 1) % (maxPage + 1); this.scene.restart(); } });

    // ---------- PANEL: PRESTIGE & PROGRESI MODE ----------
    const presY = cy + H * 0.33 + H * 0.16 + 24;
    panel(this, px, presY - 52, pw, 74, 0x141024, 0.98, 10);
    const presLv = c.prestigeLevel || 0;
    this.add.text(px + 18, presY - 34, 'PRESTIGE ' + (presLv > 0 ? 'Lv.' + presLv + '  •  semua stat dasar +' + (presLv * 10) + '%' : 'belum pernah'), { fontFamily: F_UI, fontSize: '11.5px', color: presLv > 0 ? '#c4b5fd' : '#64748b', fontStyle: 'bold' }).setOrigin(0, 0.5);
    this.add.text(px + pw - 18, presY - 34, 'Menara terbaik: lantai ' + (c.towerBest || 0) + '  •  Combo terbaik: ' + (c.bestCombo || 0), { fontFamily: F_UI, fontSize: '10px', color: '#94a3b8' }).setOrigin(1, 0.5);
    makeButton(this, px + pw - 92, presY - 12, 156, 28, c.level >= 50 ? 'LAKUKAN PRESTIGE' : 'Prestige (Lv.50)', { color: c.level >= 50 ? 0x6d28d9 : 0x1f2937, size: 9, onClick: async () => {
      if (c.level < 50) { Toast.show(this, { title: 'Belum bisa', message: 'Prestige terbuka di level 50.', icon: 'cross', color: 0x64748b }); return; }
      if (!confirm('Prestige: level & skill tree di-reset, tapi item, pet, gold, permata, menara, dan gelar TETAP. Bonus permanen +10% stat per prestige. Lanjut?')) return;
      const r = await api('/api/rpg/prestige', { method: 'POST', body: {} });
      if (r && r.ok) { Sfx.levelup(); Toast.show(this, { title: 'TERLAHIR KEMBALI', message: 'Prestige Lv.' + r.prestigeLevel + (r.title ? ' — gelar: ' + r.title : ''), icon: 'star', color: 0x6d28d9 }); await Data.refresh(); this.scene.start('Lobby'); }
      else Toast.show(this, { title: 'Gagal', message: (r && r.error) || '', icon: 'cross', color: 0xdc2626 });
    } });

    // ---------- PANEL: achievement terbaru ----------
    const achY = cy + H * 0.33 + H * 0.16 + 52;
    panel(this, px, achY, pw, Math.max(110, H - achY - 74), 0x0f172a, 0.98, 14);
    this.add.text(px + 18, achY + 18, 'ACHIEVEMENT TERAKHIR', { fontFamily: F_HEAD, fontSize: '11px', color: '#f2c230' }).setOrigin(0, 0.5);
    makeButton(this, px + pw - 70, achY + 18, 110, 30, 'Lihat semua', { color: 0xca8a04, icon: 'trophy', size: 10, onClick: () => this.scene.start('Achievements') });
    const unlocked = (Data.achievements || []).filter((a) => a.unlocked);
    this.add.text(px + 18, cy + H * 0.33 + H * 0.16 + 66, unlocked.length + ' dari ' + (Data.achievements || []).length + ' terbuka', { fontFamily: F_UI, fontSize: '11px', color: '#8b96ab' }).setOrigin(0, 0.5);
    unlocked.slice(-5).reverse().forEach((a, i) => {
      const y = achY + 66 + i * 32;
      iconImage(this, px + 32, y, a.icon || 'trophy', { size: 18, color: 0xca8a04 });
      this.add.text(px + 50, y - 7, a.name, { fontFamily: F_UI, fontSize: '12px', color: '#e2e8f0', fontStyle: 'bold' }).setOrigin(0, 0.5);
      this.add.text(px + 50, y + 8, a.desc, { fontFamily: F_UI, fontSize: '9.5px', color: '#64748b' }).setOrigin(0, 0.5);
    });

    makeButton(this, W / 2, H - 26, 200, 40, 'Kembali', { color: 0x1f2937, icon: 'back', size: 13, onClick: () => this.scene.start('Lobby') });
    if (!CFG.server) this.add.text(W / 2, H - 52, 'Mode demo — friend ID & achievement tersimpan lokal.', { fontFamily: F_UI, fontSize: '10px', color: '#475569' }).setOrigin(0.5);
  }
}

/* ---------- ACHIEVEMENTS ---------- */
class AchievementsScene extends Phaser.Scene {
  constructor() { super('Achievements'); }
  create() {
    const W = this.scale.width, H = this.scale.height;
    uiFill(this, W / 2, H / 2, W, H, 0x0b1120);
    uiFill(this, W / 2, H * 0.75, W, H / 2, 0x1a1a10, 0.9);
    sceneHeader(this, 'ACHIEVEMENT', null, { y: H * 0.045 });
    const unlocked = (Data.achievements || []).filter((a) => a.unlocked).length;
    const total = (Data.achievements || []).length;
    this.add.text(W / 2, H * 0.045 + 36, unlocked + ' / ' + total + ' terbuka', { fontFamily: F_PIX, fontSize: '11px', color: unlocked ? '#fde68a' : '#8b96ab' }).setOrigin(0.5);
    // Tab kategori.
    this.cat = this.cat || 'all';
    const cats = [{ key: 'all', name: 'Semua' }].concat(Data.achCategories && Data.achCategories.length ? Data.achCategories : [{ key: 'battle', name: 'Pertempuran' }, { key: 'dungeon', name: 'Dungeon' }, { key: 'craft', name: 'Kerajinan' }, { key: 'social', name: 'Sosial' }, { key: 'collect', name: 'Koleksi' }, { key: 'progress', name: 'Progresi' }]);
    const nTabs = Math.min(7, cats.length);
    // v10: tab 2 baris adaptif di layar sempit (v9 luber kanan "KOLEKS...").
    const rows = nTabs > 4 ? 2 : 1;
    const perRow = Math.ceil(nTabs / rows);
    const sp = Math.min(104, (W - 24) / perRow);
    this._claiming = false;
    cats.slice(0, nTabs).forEach((c, i) => {
      const row = Math.floor(i / perRow), col = i % perRow;
      makeButton(this, W / 2 + (col - (perRow - 1) / 2) * sp, H * 0.105 + row * 40, sp - 8, 34, c.name, {
        color: this.cat === c.key ? 0xca8a04 : 0x1e293b, size: 11,
        onClick: () => { this.cat = c.key; this.scene.restart(); },
      });
    });
    Data.refreshAchievements(true).then(() => this.renderList());
    makeButton(this, W / 2, H - 26, 200, 40, 'Kembali', { color: 0x1f2937, icon: 'back', size: 13, onClick: () => this.scene.start('Lobby') });
  }
  renderList() {
    const W = this.scale.width, H = this.scale.height;
    if (this.listG) this.listG.forEach((o) => o.destroy());
    this.listG = [];
    const cats = { battle: 'Pertempuran', dungeon: 'Dungeon', craft: 'Kerajinan', social: 'Sosial', collect: 'Koleksi', progress: 'Progresi' };
    let list = Data.achievements || [];
    if (this.cat !== 'all') list = list.filter((a) => a.cat === this.cat);
    // Sort: bisa diklaim > unlocked > progress.
    list = [...list].sort((a, b) => (b.unlocked && !b.claimed ? 1 : 0) - (a.unlocked && !a.claimed ? 1 : 0) || (b.unlocked ? 1 : 0) - (a.unlocked ? 1 : 0));
    const bw = Math.min(660, W - 40);
    const rowH = 58;
    const topY = H * 0.16;
    const maxRows = Math.floor((H - topY - 76) / rowH);
    list.slice(0, maxRows).forEach((a, i) => {
      const y = topY + i * rowH + rowH / 2;
      // v9: baris achievement = tile aset + outline status.
      const col = a.unlocked ? 0xca8a04 : 0x1f2937;
      this.listG.push(uiSlice(this, W / 2, y, bw, rowH - 6, 'ui_tile', a.unlocked ? 0x1c1608 : 0x0f172a).setAlpha(0.94));
      this.listG.push(uiSlice(this, W / 2, y, bw - 4, rowH - 10, 'ui_outline', col).setAlpha(a.unlocked ? 0.85 : 0.5));
      this.listG.push(iconImage(this, W / 2 - bw / 2 + 30, y, a.icon || 'trophy', { size: 26, color: a.unlocked ? 0xfde68a : 0x475569 }));
      this.listG.push(this.add.text(W / 2 - bw / 2 + 56, y - 10, a.name + (a.claimed ? '  (sudah diambil)' : ''), { fontFamily: F_UI, fontSize: '13px', color: a.unlocked ? '#fde68a' : '#cbd5e1', fontStyle: 'bold' }).setOrigin(0, 0.5));
      this.listG.push(this.add.text(W / 2 - bw / 2 + 56, y + 8, a.desc + '  •  ' + (cats[a.cat] || a.cat), { fontFamily: F_UI, fontSize: '10.5px', color: '#64748b' }).setOrigin(0, 0.5));
      // Progress bar.
      const prog = a.progress || { current: 0, target: 1 };
      const pct = clamp(prog.current / (prog.target || 1), 0, 1);
      // v9: bar progres = aset.
      this.listG.push(uiBar(this, W / 2 - bw / 2 + 56 + 90, y + 20, 180, 5, pct, a.unlocked ? 0xca8a04 : 0x334155, { frameTint: 0x1e293b }));
      this.listG.push(this.add.text(W / 2 - bw / 2 + 246, y + 20, fmt(prog.current) + '/' + fmt(prog.target), { fontFamily: F_UI, fontSize: '9.5px', color: '#64748b' }).setOrigin(0, 0.5));
      // Reward & klaim.
      const rw = [];
      if (a.reward && a.reward.gold) rw.push(fmt(a.reward.gold) + ' KZC');
      if (a.reward && a.reward.xp) rw.push(fmt(a.reward.xp) + ' XP');
      if (a.reward && a.reward.title) rw.push('Title "' + a.reward.title + '"');
      this.listG.push(this.add.text(W / 2 + bw / 2 - 130, y, rw.join('\n'), { fontFamily: F_UI, fontSize: '9.5px', color: '#fbbf24', align: 'right', lineSpacing: 2 }).setOrigin(1, 0.5));
      if (a.unlocked && !a.claimed) {
        this.listG.push(makeButton(this, W / 2 + bw / 2 - 52, y, 92, 36, 'Ambil', {
          color: 0x16a34a, size: 12, icon: 'check',
          onClick: async () => {
            // v10: kunci dobel-klik (klik kedua memicu "sudah diambil" dari server).
            if (this._claiming) return;
            this._claiming = true;
            const r = await Data.claimAchievement(a.id);
            this._claiming = false;
            if (r.ok) { Toast.show(this, { title: 'Reward diterima', message: rw.join(' • ') || 'Selesai.', icon: 'coin', color: 0x16a34a }); this.scene.restart(); }
            else {
              Toast.show(this, { title: 'Gagal', message: r.error || '', icon: 'cross', color: 0xdc2626 });
              // v12: "sudah diambil" = daftar basi (diklaim dari tab lain) -> sinkron ulang.
              if (/sudah/i.test(r.error || '')) this.scene.restart();
            }
          },
        }));
      } else if (a.claimed) {
        this.listG.push(iconImage(this, W / 2 + bw / 2 - 36, y, 'check', { size: 18, color: 0x16a34a }));
      } else {
        this.listG.push(iconImage(this, W / 2 + bw / 2 - 36, y, 'lock', { size: 16, color: 0x475569 }));
      }
    });
  }
}
/* ============================================================================
 * 11. SCENE: TEMAN / LOBBY MULTIPLAYER / CHAT OVERLAY / PARTY RAID
 * ========================================================================== */
class FriendsScene extends Phaser.Scene {
  constructor() { super('Friends'); }
  create() {
    const W = this.scale.width, H = this.scale.height;
    uiFill(this, W / 2, H / 2, W, H, 0x04121a);
    uiFill(this, W / 2, H * 0.75, W, H / 2, 0x0b1120, 0.9);
    sceneHeader(this, 'TEMAN', 'Tambah lewat friend ID, terima permintaan, dan chat langsung', { y: H * 0.045 });

    if (!CFG.server) {
      panel(this, W / 2 - 200, H * 0.4 - 60, 400, 120, 0x0f172a, 0.98, 12);
      this.add.text(W / 2, H * 0.4 - 20, 'Fitur teman butuh server bot', { fontFamily: F_UI, fontSize: '15px', color: '#f8fafc', fontStyle: 'bold' }).setOrigin(0.5);
      this.add.text(W / 2, H * 0.4 + 8, 'Jalankan game lewat dashboard bot (login Discord)\nuntuk menambah teman dan chat.', { fontFamily: F_UI, fontSize: '12px', color: '#8b96ab', align: 'center', lineSpacing: 3 }).setOrigin(0.5);
      makeButton(this, W / 2, H * 0.4 + 46, 160, 40, 'Mengerti', { color: 0x155e75, size: 12, onClick: () => this.scene.start('Lobby') });
      makeButton(this, W / 2, H - 30, 200, 42, 'Kembali', { color: 0x1f2937, icon: 'back', size: 13, onClick: () => this.scene.start('Lobby') });
      return;
    }

    // Bar tambah teman.
    const addY = H * 0.115;
    panel(this, 20, addY - 26, W - 40, 52, 0x0f172a, 0.98, 10);
    // v9: kotak input = aset tile + outline.
    uiSlice(this, 40 + (W - 210) / 2, addY, W - 210, 34, 'ui_tile', 0x0d1526);
    this.addInput = makeInteractive(uiSlice(this, 40 + (W - 210) / 2, addY, W - 214, 30, 'ui_outline', 0x334155).setAlpha(0.6).setOrigin(0.5));
    this.inputText = this.add.text(50, addY, 'Ketuk untuk isi friend ID / nama...', { fontFamily: F_UI, fontSize: '12px', color: '#64748b' }).setOrigin(0, 0.5);
    this.addInput.on('pointerup', () => {
      const q = prompt('Friend ID (contoh KZ-AB12), nama, atau ID Discord:');
      if (q && q.trim()) this.doAdd(q.trim());
    });
    makeButton(this, W - 178, addY, 120, 38, 'Tambah', { color: 0x0891b2, icon: 'plus', size: 11, onClick: () => {
      const q = prompt('Friend ID (contoh KZ-AB12), nama, atau ID Discord:');
      if (q && q.trim()) this.doAdd(q.trim());
    } });
    makeButton(this, W - 52, addY, 82, 38, 'Inbox', { color: 0xbe185d, icon: 'star', size: 10, onClick: () => this.openInbox() });

    this.loadFriends();
    makeButton(this, W / 2, H - 28, 200, 42, 'Kembali', { color: 0x1f2937, icon: 'back', size: 13, onClick: () => this.scene.start('Lobby') });
  }
  async doAdd(q) {
    const r = await api('/api/rpg/friends/add', { method: 'POST', body: { query: q } });
    if (r && !r.error) {
      Toast.show(this, { title: r.status === 'accepted' ? 'Jadi teman!' : 'Permintaan terkirim', message: 'Menunggu balasan mereka.', icon: 'friends', color: 0x0891b2 });
      this.loadFriends();
    } else {
      Toast.show(this, { title: 'Gagal menambah', message: (r && r.error) || 'Pemain tidak ditemukan.', icon: 'cross', color: 0xdc2626 });
    }
  }
  async loadFriends() {
    if (this.listG) this.listG.forEach((o) => o.destroy());
    this.listG = [];
    const W = this.scale.width, H = this.scale.height;
    const r = await api('/api/rpg/friends');
    if (r && r.error) return;
    const friends = (r && r.friends) || [];
    const requests = (r && r.requests) || [];
    let y = H * 0.17;
    if (requests.length) {
      this.listG.push(this.add.text(24, y, 'PERMINTAAN MASUK', { fontFamily: F_HEAD, fontSize: '10px', color: '#f2c230' }).setOrigin(0, 0.5));
      y += 24;
      for (const rq of requests.slice(0, 4)) {
        // v9: baris permintaan = aset.
        this.listG.push(uiSlice(this, 20 + (W - 40) / 2, y + 23, W - 40, 46, 'ui_tile', 0x1c1608).setAlpha(0.9));
        this.listG.push(uiSlice(this, 20 + (W - 40) / 2, y + 23, W - 44, 42, 'ui_outline', 0xca8a04).setAlpha(0.7));
        iconImage(this, 44, y + 23, 'user', { size: 22, color: 0xfde68a });
        this.listG.push(this.add.text(64, y + 15, rq.name + '  •  Lv.' + rq.level, { fontFamily: F_UI, fontSize: '13px', color: '#fde68a', fontStyle: 'bold' }).setOrigin(0, 0.5));
        this.listG.push(this.add.text(64, y + 33, 'mau jadi temanmu', { fontFamily: F_UI, fontSize: '10px', color: '#8b96ab' }).setOrigin(0, 0.5));
        this.listG.push(makeButton(this, W - 150, y + 23, 90, 34, 'Terima', { color: 0x16a34a, icon: 'check', size: 11, onClick: async () => {
          await api('/api/rpg/friends/accept', { method: 'POST', body: { userId: rq.userId } });
          this.loadFriends();
        } }));
        this.listG.push(makeButton(this, W - 52, y + 23, 60, 34, '', { color: 0x7c2d12, size: 11, onClick: async () => {
          await api('/api/rpg/friends/decline', { method: 'POST', body: { userId: rq.userId } });
          this.loadFriends();
        } }).add(iconImage(this, 0, 0, 'cross', { size: 14, color: 0xfca5a5 })));
        y += 56;
      }
      y += 8;
    }
    this.listG.push(this.add.text(24, y, 'DAFTAR TEMAN  (' + friends.length + ')', { fontFamily: F_HEAD, fontSize: '10px', color: '#67e8f9' }).setOrigin(0, 0.5));
    y += 26;
    if (!friends.length) {
      this.listG.push(this.add.text(W / 2, y + 20, 'Belum punya teman. Bagikan friend ID-mu di profil!', { fontFamily: F_UI, fontSize: '13px', color: '#64748b' }).setOrigin(0.5));
    }
    for (const f of friends.slice(0, Math.floor((H - y - 80) / 56))) {
      // v9: baris teman = aset.
      this.listG.push(uiSlice(this, 20 + (W - 40) / 2, y + 24, W - 40, 48, 'ui_tile', 0x0f172a).setAlpha(0.95));
      // Titik status online.
      // v9: titik status online = aset badge (tint).
      this.listG.push(this.add.image(42, y + 24, 'ui_badge').setDisplaySize(17, 17).setTint(f.online ? 0x22c55e : 0x475569));
      this.listG.push(this.add.image(42, y + 24, 'ui_outline').setDisplaySize(17, 17).setTint(f.online ? 0x86efac : 0x334155));
      const clsIcon = { warrior: 'sword', mage: 'fire', assassin: 'sword', archer: 'bow' }[f.classKey] || 'person';
      iconImage(this, 66, y + 24, clsIcon, { size: 18, color: (CLASSES[f.classKey] || {}).color || 0x64748b });
      this.listG.push(this.add.text(86, y + 15, f.name + (f.title ? '  —  ' + f.title : ''), { fontFamily: F_UI, fontSize: '13.5px', color: '#f1f5f9', fontStyle: 'bold' }).setOrigin(0, 0.5));
      this.listG.push(this.add.text(86, y + 34, 'Lv.' + f.level + '  •  ' + ((CLASSES[f.classKey] || {}).name || '—') + '  •  ' + (f.online ? 'online' : 'offline'), { fontFamily: F_UI, fontSize: '10.5px', color: f.online ? '#86efac' : '#64748b' }).setOrigin(0, 0.5));
      this.listG.push(makeButton(this, W - 196, y + 24, 84, 36, 'Hadiah', { color: 0xbe185d, icon: 'star', size: 10, onClick: () => this.openGift(f) }));
      this.listG.push(makeButton(this, W - 106, y + 24, 84, 36, 'Chat', { color: 0x0e7490, icon: 'chat', size: 10, onClick: () => this.scene.start('ChatOverlay', { back: 'Friends', dm: f }) }));
      this.listG.push(makeButton(this, W - 34, y + 24, 44, 36, '', { color: 0x7c2d12, size: 11, onClick: async () => {
        if (confirm('Hapus teman ' + f.name + '?')) { await api('/api/rpg/friends/remove', { method: 'POST', body: { userId: f.userId } }); this.loadFriends(); }
      } }).add(iconImage(this, 0, 0, 'cross', { size: 13, color: 0xfca5a5 })));
      y += 56;
    }
  }
  /* Inbox hadiah: klaim yang belum diambil. */
  async openInbox() {
    const W = this.scale.width, H = this.scale.height;
    const d = await api('/api/rpg/gift/inbox');
    const gifts = (d && d.gifts) || [];
    const veil = uiFill(this, W / 2, H / 2, W, H, 0x000000, 0.78).setDepth(3000);
    const pc = this.add.container(W / 2, H / 2).setDepth(3001);
    const pw = Math.min(430, W - 30), ph = Math.min(430, H - 60);
    pc.add(uiSlice(this, 0, 0, pw, ph, 'ui_panel', 0x0a0f1c).setAlpha(0.98));
    pc.add(uiSlice(this, 0, 0, pw - 4, ph - 4, 'ui_outline', 0xbe185d).setAlpha(0.8));
    pc.add(this.add.text(0, -ph / 2 + 24, 'KOTAK HADIAH', { fontFamily: F_HEAD, fontSize: '15px', color: '#f9a8d4' }).setOrigin(0.5));
    if (!gifts.length) pc.add(this.add.text(0, 0, 'Belum ada hadiah. Kirim sesuatu ke temanmu!', { fontFamily: F_UI, fontSize: '12px', color: '#64748b' }).setOrigin(0.5));
    gifts.slice(0, 6).forEach((g, i) => {
      const y = -ph / 2 + 62 + i * 52;
      const label = g.kind === 'gold' ? (fmt(g.gold) + ' KZC') : g.kind === 'gems' ? (g.gems + ' Permata') : ((g.itemName || g.itemId) + ' x' + g.qty);
      pc.add(this.add.text(-pw / 2 + 24, y - 8, label, { fontFamily: F_UI, fontSize: '12px', color: g.claimed ? '#475569' : '#fde68a', fontStyle: 'bold' }).setOrigin(0, 0.5));
      pc.add(this.add.text(-pw / 2 + 24, y + 10, (g.message || '') + (g.claimed ? '  (sudah diambil)' : ''), { fontFamily: F_UI, fontSize: '9.5px', color: '#64748b' }).setOrigin(0, 0.5));
      if (!g.claimed) {
        pc.add(makeButton(this, pw / 2 - 60, y, 96, 34, 'Ambil', { color: 0x16a34a, icon: 'check', size: 10, onClick: async () => {
          const r = await api('/api/rpg/gift/claim', { method: 'POST', body: { id: g.id } });
          if (r && r.ok) { Sfx.coin(); veil.destroy(); pc.destroy(); this.openInbox(); }
        } }));
      }
    });
    const closeZone = makeButton(this, 0, ph / 2 - 26, 130, 36, 'Tutup', { color: 0x334155, size: 11 });
    pc.add(closeZone);
    pc.add(this.add.text(0, ph / 2 - 26, 'Tutup', { fontFamily: F_UI, fontSize: '11px', color: '#cbd5e1' }).setOrigin(0.5));
    closeZone.on('pointerdown', () => { veil.destroy(); pc.destroy(); });
  }
  /* Kirim hadiah ke teman: gold / permata / item. */
  openGift(f) {
    const W = this.scale.width, H = this.scale.height;
    const veil = uiFill(this, W / 2, H / 2, W, H, 0x000000, 0.75).setDepth(3000);
    const pc = this.add.container(W / 2, H / 2).setDepth(3001);
    const pw = Math.min(430, W - 30), ph = 360;
    pc.add(uiSlice(this, 0, 0, pw, ph, 'ui_panel', 0x0a0f1c).setAlpha(0.98));
    pc.add(uiSlice(this, 0, 0, pw - 4, ph - 4, 'ui_outline', 0xbe185d).setAlpha(0.8));
    pc.add(this.add.text(0, -ph / 2 + 24, 'KIRIM HADIAH KE ' + f.name.toUpperCase(), { fontFamily: F_HEAD, fontSize: '14px', color: '#f9a8d4' }).setOrigin(0.5));
    let kind = 'gold', amount = 100, itemId = null;
    const kinds = [
      { k: 'gold', label: fmt(amount) + ' KZC', color: 0xb45309 },
      { k: 'gems', label: amount + ' Permata', color: 0x7c3aed },
      { k: 'item', label: 'Item dari tas', color: 0x0891b2 },
    ];
    const kindBtns = [];
    kinds.forEach((kk, i) => {
      const b = makeButton(this, (i - 1) * 130, -ph / 2 + 66, 118, 38, kk.label, { color: kk.color, size: 11, onClick: () => {
        kind = kk.k;
        kindBtns.forEach((b2, j) => b2.setScale(j === i ? 1.05 : 1));
      } });
      kindBtns.push(b); pc.add(b);
    });
    pc.add(this.add.text(0, -ph / 2 + 102, 'Jumlah (gold/permata):', { fontFamily: F_UI, fontSize: '11px', color: '#8b96ab' }).setOrigin(0.5));
    const amtTxt = this.add.text(0, -ph / 2 + 126, '100', { fontFamily: F_UI, fontSize: '16px', color: '#fde68a', fontStyle: 'bold' }).setOrigin(0.5);
    pc.add(amtTxt);
    const setAmt = (v) => { amount = Math.max(1, Math.min(100000, v)); amtTxt.setText(fmt(amount)); };
    pc.add(makeButton(this, -110, -ph / 2 + 126, 80, 34, '-100', { color: 0x1f2937, size: 11, onClick: () => setAmt(amount - 100) }));
    pc.add(makeButton(this, 110, -ph / 2 + 126, 80, 34, '+100', { color: 0x1f2937, size: 11, onClick: () => setAmt(amount + 100) }));
    // Pesan singkat.
    pc.add(this.add.text(0, -ph / 2 + 158, 'Pesan (opsional, ketuk untuk isi):', { fontFamily: F_UI, fontSize: '10px', color: '#64748b' }).setOrigin(0.5));
    const msgTxt = makeInteractive(this.add.text(0, -ph / 2 + 182, '"Semoga berguna!"', { fontFamily: F_UI, fontSize: '11px', color: '#e2e8f0', fontStyle: 'italic' }).setOrigin(0.5), { useHandCursor: true });
    msgTxt.on('pointerdown', () => { const m = prompt('Pesan hadiah (maks 120 huruf):'); if (m != null) msgTxt.setText('"' + m.slice(0, 120) + '"'); });
    pc.add(msgTxt);
    // Pilih item bila kind=item.
    const inv = (Data.char && Data.char.inventory) || {};
    const invIds = Object.keys(inv).filter((id) => inv[id] > 0 && itemById(id)).slice(0, 6);
    const itemRow = this.add.container(0, -ph / 2 + 220);
    pc.add(itemRow);
    invIds.forEach((id, i) => {
      // v12 FIX AKAR (§1B): ikon = Container -> setInteractive(config) menghasilkan
      // hitAreaCallback null -> CRASH saat hover. Kini shape eksplisit + validasi.
      const ic = addRarityIcon(this, (i - (invIds.length - 1) / 2) * 58, 0, id, 38);
      makeInteractive(ic, { useHandCursor: true, w: 38, h: 38 });
      ic.on('pointerdown', () => { itemId = id; itemRow.list.forEach((o) => o.setScale(1)); ic.setScale(1.2); });
      itemRow.add(ic);
    });
    const send = async () => {
      const body = { toUserId: f.userId, kind, message: String(msgTxt.text).replace(/"/g, '').slice(0, 120) };
      if (kind === 'item') { if (!itemId) { Toast.show(this, { title: 'Pilih item dulu', message: 'Ketuk salah satu ikon item.', icon: 'bag', color: 0x64748b }); return; } body.itemId = itemId; body.qty = 1; }
      else body.amount = amount;
      const r = await api('/api/rpg/gift/send', { method: 'POST', body });
      if (r && r.ok) {
        Toast.show(this, { title: 'Hadiah terkirim', message: f.name + ' pasti senang.', icon: 'star', color: 0xbe185d });
        Sfx.coin(); veil.destroy(); pc.destroy();
      } else Toast.show(this, { title: 'Gagal mengirim', message: (r && r.error) || '', icon: 'cross', color: 0xdc2626 });
    };
    pc.add(makeButton(this, -80, ph / 2 - 52, 140, 44, 'Kirim', { color: 0xbe185d, icon: 'star', size: 12, onClick: send }));
    const closeZone = makeButton(this, 80, ph / 2 - 52, 140, 44, 'Tutup', { color: 0x334155, size: 11 });
    pc.add(closeZone);
    pc.add(this.add.text(80, ph / 2 - 52, 'Tutup', { fontFamily: F_UI, fontSize: '12px', color: '#cbd5e1' }).setOrigin(0.5));
    closeZone.on('pointerdown', () => { veil.destroy(); pc.destroy(); });
  }
}

/* ---------- LOBBY MULTIPLAYER (karakter terlihat, siap-siap, chat) ---------- */
class MultiplayerLobbyScene extends Phaser.Scene {
  constructor() { super('MultiplayerLobby'); }
  create() {
    const W = this.scale.width, H = this.scale.height;
    // v9: latar kamp malam — pita aset + api unggun & tenda ASET.
    uiFill(this, W / 2, H / 2, W, H, 0x1a1205);
    uiFill(this, W / 2, H * 0.75, W, H / 2, 0x0a0f1c, 0.9);
    const campX = W * 0.5, groundY = H * 0.66;
    this.add.image(campX, groundY + 34, 'fx_tex_shadow').setDisplaySize(240, 48).setAlpha(0.45);
    // batu api unggun + kayu + bara (aset).
    uiFill(this, campX, groundY + 19, 46, 7, 0x5b3a1a, 1);
    uiFill(this, campX - 12, groundY + 10, 7, 20, 0x5b3a1a, 1);
    for (let i = 0; i < 7; i++) this.add.image(campX - 32 + i * 11, groundY + 26 + Math.sin(i) * 3, 'asset_deco_rock2').setTint(pick([0x52525b, 0x3f3f46])).setDisplaySize(12, 10);
    // v10: api unggun = sprite pixel aset 3-frame (v9: glow blur terlihat licin).
    if (this.textures.exists('asset_deco_campfire')) {
      if (!this.anims.exists('campfirez')) {
        this.anims.create({ key: 'campfirez', frames: this.anims.generateFrameNumbers('asset_deco_campfire', { start: 0, end: 2 }), frameRate: 7, repeat: -1 });
      }
      this.add.sprite(campX, groundY + 22, 'asset_deco_campfire', 0).setDepth(3).play('campfirez');
    } else {
      for (let i = 0; i < 4; i++) {
        const f = this.add.image(campX + RF(-14, 14), groundY + 12, 'fx_tex_flash').setTint(pick([0xfbbf24, 0xf97316, 0xef4444])).setAlpha(0.95).setDisplaySize(RF(12, 26), RF(12, 26)).setBlendMode(Phaser.BlendModes.ADD);
        this.tweens.add({ targets: f, scaleY: { from: 0.7, to: 1.5 }, alpha: { from: 0.6, to: 1 }, duration: R(150, 320), yoyo: true, repeat: -1 });
      }
    }
    const glow = this.add.image(campX, groundY + 10, 'fx_tex_glow').setTint(0xf97316).setAlpha(0.1).setScale(1.7).setBlendMode(Phaser.BlendModes.ADD);
    this.tweens.add({ targets: glow, alpha: { from: 0.07, to: 0.16 }, duration: 800, yoyo: true, repeat: -1 });
    // tenda dekoratif (aset pixel-art).
    this.add.image(campX - 270, groundY + 30, 'asset_deco_tent').setOrigin(0.5, 1).setScale(1.9);
    this.add.image(campX + 270, groundY + 30, 'asset_deco_tent').setOrigin(0.5, 1).setScale(1.9).setTint(0x6d7cff);

    sceneHeader(this, 'LOBBY MULTIPLAYER', 'Buat atau gabung party — maksimal 4 petualang', { y: H * 0.045, color: '#fde68a' });

    this.peerSprites = new Map(); // userId -> {container, sprite, nameTag, readyIcon}
    this.lobbyCode = null;
    this.myReady = false;

    if (!CFG.server) {
      panel(this, W / 2 - 210, H * 0.4 - 70, 420, 140, 0x0f172a, 0.98, 12);
      this.add.text(W / 2, H * 0.4 - 28, 'Lobby butuh server bot', { fontFamily: F_UI, fontSize: '15px', color: '#f8fafc', fontStyle: 'bold' }).setOrigin(0.5);
      this.add.text(W / 2, H * 0.4 + 4, 'Multiplayer jalan saat game dibuka lewat dashboard bot.\nDi preview/demo ini kamu tetap bisa main dungeon sendiri.', { fontFamily: F_UI, fontSize: '12px', color: '#8b96ab', align: 'center', lineSpacing: 3 }).setOrigin(0.5);
      makeButton(this, W / 2, H * 0.4 + 44, 160, 40, 'Mengerti', { color: 0x155e75, size: 12, onClick: () => this.scene.start('Lobby') });
      makeButton(this, W / 2, H - 30, 200, 42, 'Kembali', { color: 0x1f2937, icon: 'back', size: 13, onClick: () => this.scene.start('Lobby') });
      return;
    }

    // Kontrol lobby. Klik saat WS terputus -> Toast alasan (bukan diam).
    const cy = H * 0.115;
    const rtNeed = () => {
      if (Rt.connected) return true;
      Toast.show(this, { title: 'Belum tersambung ke server', message: 'Multiplayer butuh koneksi realtime — ' + (Rt.lastError || 'sedang menyambung ulang otomatis') + '.', icon: 'cross', color: 0xdc2626 });
      return false;
    };
    makeButton(this, W / 2 - 180, cy + 14, 160, 42, 'Buat Party', { color: 0xb45309, icon: 'party', size: 12, onClick: () => { if (rtNeed()) Rt.send('lobby.create', { name: (Data.char.name || 'Party') }); } });
    makeButton(this, W / 2, cy + 14, 160, 42, 'Gabung Kode', { color: 0x1d4ed8, icon: 'door', size: 12, onClick: () => {
      if (!rtNeed()) return;
      const code = prompt('Kode lobby (5 huruf):');
      if (code && code.trim()) Rt.send('lobby.join', { code: code.trim() });
    } });
    makeButton(this, W / 2 + 180, cy + 14, 160, 42, 'Refresh', { color: 0x1f2937, icon: 'refresh', size: 12, onClick: () => this.refreshLobbyList() });

    // Chip status koneksi realtime (hijau = aktif) — status SELALU terlihat.
    const rt = Rt.scoped();
    // v12: chip dipindah ke BAWAH baris tombol (dulu menimpa tombol di layar pendek).
    this.rtChip = this.add.text(W / 2, cy + 58, '', { fontFamily: F_UI, fontSize: '10.5px', color: '#94a3b8', stroke: '#0b0b12', strokeThickness: 3 }).setOrigin(0.5);
    const setRtChip = () => {
      if (Rt.state === 'open') this.rtChip.setText('realtime aktif — siap bikin party').setColor('#34d399');
      else if (Rt.state === 'connecting') this.rtChip.setText('menyambungkan ke server...').setColor('#fbbf24');
      else if (Rt.state === 'reconnecting') this.rtChip.setText('koneksi terputus — menyambungkan ulang...').setColor('#fbbf24');
      else this.rtChip.setText('realtime terputus — daftar via server (mode hemat)').setColor('#fca5a5');
    };
    setRtChip();
    rt.on('rt.state', setRtChip);

    // Panel daftar lobby publik.
    this.lobbyListPanel = this.add.container(0, 0);
    this.lobbyInfoText = this.add.text(W / 2, H * 0.20, 'Memuat daftar lobby...', { fontFamily: F_UI, fontSize: '12px', color: '#8b96ab' }).setOrigin(0.5);
    this.refreshLobbyList();

    // Event realtime (ter-scoped: shutdown scene ini TIDAK menghapus listener scene lain).
    rt.on('open', () => this.refreshLobbyList()); // sambungan pulih -> muat ulang daftar
    rt.on('lobby.list', (m) => this.renderLobbyList(m.lobbies || []));
    rt.on('lobby.joined', (m) => { this.lobbyCode = m.code; this.myReady = false; this.lobbyInfoText.setText(''); if (this.lobbyListPanel) this.lobbyListPanel.removeAll(true); Toast.show(this, { title: 'Masuk lobby ' + m.code, message: m.name + ' — ' + m.count + '/' + m.max + ' orang', icon: 'party', color: 0xb45309 }); });
    rt.on('lobby.peers', (m) => this.renderPeers(m));
    rt.on('lobby.chat', (m) => { if (m.from === 'system') Toast.show(this, { title: 'Lobby', message: m.message, icon: 'party', color: 0x64748b }); });
    rt.on('lobby.left', (m) => { });
    rt.on('lobby.closed', () => { this.lobbyCode = null; this.peerSprites.forEach((p) => p.container.destroy()); this.peerSprites.clear(); Toast.show(this, { title: 'Lobby bubar', message: 'Pemilik lobby keluar.', icon: 'exit', color: 0xdc2626 }); });
    rt.on('lobby.error', (m) => Toast.show(this, { title: 'Lobby', message: m.message, icon: 'cross', color: 0xdc2626 }));
    rt.on('lobby.start', (m) => {
      Toast.show(this, { title: 'PARTY RAID DIMULAI', message: 'Semua anggota siap — lawan boss bersama!', icon: 'swords', color: 0xdc2626 });
      this.scene.start('PartyBattle', { code: m.code, seed: m.seed, leader: m.leader });
    });

    // Kontrol dalam lobby (siap / keluar / mulai).
    const by = H - 76;
    this.readyBtn = makeButton(this, W / 2 - 120, by, 170, 46, 'Siap', { color: 0x166534, icon: 'check', size: 13, onClick: () => {
      this.myReady = !this.myReady;
      this.readyBtn.setIcon('check', this.myReady ? 0xfde68a : 0xf8fafc);
      this.readyBtn.labelText.setText(this.myReady ? 'Batal Siap' : 'Siap');
      Rt.send('lobby.ready', { ready: this.myReady });
    } });
    makeButton(this, W / 2 + 60, by, 130, 46, 'Keluar', { color: 0x7c2d12, icon: 'exit', size: 12, onClick: () => { Rt.send('lobby.leave'); this.lobbyCode = null; this.peerSprites.forEach((p) => p.container.destroy()); this.peerSprites.clear(); this.refreshLobbyList(); } });
    this.startBtn = makeButton(this, W / 2 + 220, by, 150, 46, 'Mulai Raid', { color: 0xdc2626, icon: 'swords', size: 12, onClick: () => Rt.send('lobby.start') });

    // Gerak karakter lokal di lobby (kiri/kanan sederhana) + kirim posisi.
    this.keys = this.input.keyboard.addKeys('A,D');
    this.myX = W / 2 - 160;
    this.updatePeerSprite(CFG.userId || 'me', { name: Data.char.name || 'Kamu', classKey: Data.char.classKey, level: Data.char.level }, true);
    this.events.once('shutdown', () => rt.off());

    makeButton(this, W - 60, H - 30, 110, 38, 'Lobby', { color: 0x1f2937, icon: 'chat', size: 11, onClick: () => this.scene.launch('ChatOverlay', { back: 'MultiplayerLobby' }) });
    makeButton(this, 70, H - 30, 120, 38, 'Kembali', { color: 0x1f2937, icon: 'back', size: 11, onClick: () => this.scene.start('Lobby') });
  }
  refreshLobbyList() {
    // v10: WS terputus (hosting tidak meneruskan WebSocket) -> daftar lobby
    // tetap HIDUP lewat REST + polling 6 detik. Toast peringatan cukup SEKALI.
    if (Rt.send('lobby.list')) return;
    if (!CFG.server) return;
    if (!this._rtWarned) {
      this._rtWarned = true;
      Toast.show(this, { title: 'Mode hemat (tanpa realtime)', message: 'Daftar lobby dimuat lewat server dan diperbarui otomatis. Membuat atau bergabung ke party butuh koneksi realtime penuh.', icon: 'refresh', color: 0xb45309 });
    }
    api('/api/rpg/mp/lobbies')
      .then((r) => { if (r && r.ok && this.scene.isActive()) this.renderLobbyList(r.lobbies || []); else if (this.scene.isActive() && this.lobbyInfoText) this.lobbyInfoText.setText('Gagal memuat daftar lobby — ketuk Refresh.'); })
      .catch(() => { if (this.scene && this.scene.isActive() && this.lobbyInfoText) this.lobbyInfoText.setText('Gagal memuat daftar lobby — ketuk Refresh.'); });
    if (!this._lobbyPoll) {
      this._lobbyPoll = this.time.addEvent({ delay: 6000, loop: true, callback: () => {
        if (!this.scene || !this.scene.isActive()) { this._lobbyPoll.remove(); this._lobbyPoll = null; return; }
        if (Rt.connected) { this._lobbyPoll.remove(); this._lobbyPoll = null; return; }
        this.refreshLobbyList();
      } });
    }
  }
  renderLobbyList(lobbies) {
    if (!this.lobbyListPanel) return;
    this.lobbyListPanel.removeAll(true);
    if (this.lobbyCode) return;
    const W = this.scale.width;
    if (!lobbies.length) { this.lobbyInfoText.setText('Belum ada lobby terbuka — buat party pertama!'); return; }
    this.lobbyInfoText.setText('LOBBY TERBUKA');
    lobbies.slice(0, 4).forEach((l, i) => {
      const y = this.scale.height * 0.24 + i * 52;
      // v9: baris lobby = aset.
      this.lobbyListPanel.add(uiSlice(this, W / 2, y + 22, 440, 44, 'ui_tile', 0x0f172a).setAlpha(0.95));
      this.lobbyListPanel.add(uiSlice(this, W / 2, y + 22, 436, 40, 'ui_outline', 0xb45309).setAlpha(0.6));
      this.lobbyListPanel.add(iconImage(this, W / 2 - 196, y + 22, 'party', { size: 20, color: 0xfde68a }));
      this.lobbyListPanel.add(this.add.text(W / 2 - 176, y + 14, l.name, { fontFamily: F_UI, fontSize: '13px', color: '#f1f5f9', fontStyle: 'bold' }).setOrigin(0, 0.5));
      this.lobbyListPanel.add(this.add.text(W / 2 - 176, y + 32, l.count + '/' + l.max + ' petualang', { fontFamily: F_UI, fontSize: '10px', color: '#8b96ab' }).setOrigin(0, 0.5));
      this.lobbyListPanel.add(this.add.text(W / 2 + 120, y + 22, l.code, { fontFamily: F_HEAD, fontSize: '11px', color: '#67e8f9' }).setOrigin(0.5));
      this.lobbyListPanel.add(makeButton(this, W / 2 + 186, y + 22, 62, 34, 'Gabung', { color: l.count >= l.max ? 0x1f2937 : 0x1d4ed8, size: 10, disabled: l.count >= l.max, onClick: () => Rt.send('lobby.join', { code: l.code }) }));
    });
  }
  renderPeers(m) {
    this.lobbyCode = m.code;
    const seen = new Set();
    for (const p of (m.peers || [])) {
      seen.add(p.userId);
      this.updatePeerSprite(p.userId, p, p.userId === (CFG.userId || 'me'));
    }
    for (const [uid, ps] of this.peerSprites) {
      if (!seen.has(uid)) { ps.container.destroy(); this.peerSprites.delete(uid); }
    }
  }
  updatePeerSprite(uid, info, isMe) {
    const W = this.scale.width, H = this.scale.height;
    const groundY = H * 0.66;
    let ps = this.peerSprites.get(uid);
    if (!ps) {
      const container = this.add.container(0, groundY);
      const hv = heroVisual(this, info.classKey || 'warrior', null, 3.0);
      const sprite = this.add.sprite(0, 0, hv.key, hv.frame || 0).setOrigin(0.5, 1).setScale(hv.scale);
      try { sprite.play(hv.anim.idle); } catch (_) {}
      container.add(sprite);
      container.add(this.add.image(0, 2, 'fx_tex_shadow').setDisplaySize(54, 14).setAlpha(0.45));
      const nameTag = this.add.text(0, -sprite.displayHeight - 16, '', { fontFamily: F_UI, fontSize: '11px', color: isMe ? '#5eead4' : '#f1f5f9', fontStyle: 'bold', stroke: '#0b0b12', strokeThickness: 3 }).setOrigin(0.5);
      container.add(nameTag);
      const readyTag = this.add.text(0, -sprite.displayHeight - 32, '', { fontFamily: F_HEAD, fontSize: '8px', color: '#86efac', stroke: '#0b0b12', strokeThickness: 2 }).setOrigin(0.5);
      container.add(readyTag);
      ps = { container, sprite, nameTag, readyTag, petComp: null, petId: null, x: W / 2 + RF(-140, 140), anim: 'idle', flip: false };
      this.peerSprites.set(uid, ps);
      // Susun posisi awal melingkar di sekitar api.
      const idx = this.peerSprites.size - 1;
      const spots = [-200, -110, 110, 200];
      ps.x = W / 2 + (spots[idx % 4] || RF(-160, 160));
    }
    ps.nameTag.setText((info.name || 'Petualang') + '  Lv.' + (info.level || 1));
    ps.readyTag.setText(info.ready ? 'SIAP' : '');
    if (!isMe) {
      ps.container.x = info.x != null ? W / 2 + info.x : ps.container.x;
      if (info.anim === 'walk') { try { ps.sprite.play(this.animKeyFor(info.classKey, 'walk'), true); } catch (_) {} }
      else { try { ps.sprite.play(this.animKeyFor(info.classKey, 'idle'), true); } catch (_) {} }
      ps.sprite.setFlipX(!!info.flip);
    }
    // Pet pemain terlihat di lobby (semua bisa lihat pet masing-masing).
    if (info.petId && info.petId !== ps.petId && petTexExists(this, info.petId, 1)) {
      if (ps.petComp) { ps.petComp.destroy(); ps.petComp = null; }
      ps.petId = info.petId;
      ps.petComp = spawnPetCompanion(this, info.petId, {
        x: ps.container.x + 56, y: groundY + 2, depth: ps.container.depth + 1, scale: 1.6,
        follow: { get: () => ({ x: ps.container.x + 56, y: groundY + 2 }) },
      });
    } else if (!info.petId && ps.petComp) {
      ps.petComp.destroy(); ps.petComp = null; ps.petId = null;
    }
  }
  animKeyFor(classKey, kind) {
    const a = heroAtlasAnims(this, classKey || 'warrior');
    return a ? a[kind] : null;
  }
  update() {
    if (!CFG.server || !this.keys) return;
    // Gerak lokal + broadcast posisi (throttle 100ms).
    const W = this.scale.width;
    let vx = 0;
    if (this.keys.A.isDown) vx = -1;
    else if (this.keys.D.isDown) vx = 1;
    const ps = this.peerSprites.get(CFG.userId || 'me');
    if (ps) {
      if (vx !== 0) {
        this.myX = clamp(this.myX + vx * 3.2, W / 2 - 260, W / 2 + 260);
        ps.anim = 'walk'; ps.flip = vx < 0;
      } else ps.anim = 'idle';
      ps.container.x = this.myX;
      try { ps.sprite.play(this.animKeyFor(Data.char.classKey, ps.anim === 'walk' ? 'walk' : 'idle'), true); } catch (_) {}
      ps.sprite.setFlipX(ps.flip);
      const now = Date.now();
      if (now - (this._lastPos || 0) > 100) {
        this._lastPos = now;
        Rt.send('lobby.state', { x: this.myX - W / 2, y: 0, flip: ps.flip, anim: ps.anim });
      }
    }
  }
}

/* ---------- CHAT OVERLAY (global / teman / lobby) ---------- */
class ChatOverlayScene extends Phaser.Scene {
  constructor() { super('ChatOverlay'); }
  init(data) {
    this.backScene = (data && data.back) || 'Lobby';
    this.dm = (data && data.dm) || null;
    this.tab = this.dm ? 'dm' : (data && data.tab) || 'global';
  }
  create() {
    const W = this.scale.width, H = this.scale.height;
    makeInteractive(uiFill(this, 0, 0, W, H, 0x050810, 0.72, 0));
    const bw = Math.min(560, W - 24), bh = Math.min(640, H - 24);
    const bx = W / 2 - bw / 2, by = H / 2 - bh / 2;
    panel(this, bx, by, bw, bh, 0x0b1220, 0.99, 14);

    // Header.
    this.add.text(bx + 18, by + 20, this.dm ? 'Chat dengan ' + this.dm.name : 'CHAT', { fontFamily: F_UI, fontSize: '16px', color: '#f8fafc', fontStyle: 'bold' }).setOrigin(0, 0.5);
    makeButton(this, bx + bw - 30, by + 22, 44, 36, '', { color: 0x7c2d12, size: 12, onClick: () => { this.scene.stop(); this.scene.resume(this.backScene); } }).add(iconImage(this, 0, 0, 'cross', { size: 14, color: 0xfca5a5 }));

    // Tab.
    if (!this.dm) {
      const tabs = [
        { key: 'global', name: 'Dunia', icon: 'map' },
        { key: 'lobby', name: 'Lobby', icon: 'party' },
        { key: 'dm', name: 'Teman', icon: 'friends' },
      ];
      tabs.forEach((t, i) => {
        makeButton(this, bx + 70 + i * 110, by + 58, 100, 32, t.name, { color: this.tab === t.key ? 0x0e7490 : 0x1e293b, size: 11, icon: t.icon, onClick: () => { this.tab = t.key; this.scene.restart({ back: this.backScene, tab: t.key }); } });
      });
    }

    // Area pesan (scroll sederhana: 20 terakhir).
    this.msgY = by + (this.dm ? 66 : 96);
    this.msgH = bh - (this.dm ? 170 : 200);
    // v9: area pesan = blok aset tipis (bukan canvas).
    this.msgMask = uiFill(this, bx + 12 + (bw - 24) / 2, this.msgY + this.msgH / 2, bw - 24, this.msgH, 0xffffff, 0.02);
    this.msgs = [];

    // Input.
    const inputY = by + bh - 54;
    // v9: kotak ketik chat = aset tile + outline.
    uiSlice(this, bx + 16 + (bw - 130) / 2, inputY, bw - 130, 42, 'ui_tile', 0x0f172a);
    uiSlice(this, bx + 16 + (bw - 130) / 2, inputY, bw - 134, 38, 'ui_outline', 0x334155).setAlpha(0.6);
    makeInteractive(this.add.rectangle(bx + 16, inputY, bw - 130, 42, 0x000000, 0.001).setOrigin(0, 0.5)).on('pointerup', () => this.typeMessage());
    this.inputText = this.add.text(bx + 26, inputY, 'Ketuk untuk menulis pesan...', { fontFamily: F_UI, fontSize: '12px', color: '#64748b' }).setOrigin(0, 0.5);
    makeButton(this, bx + bw - 48, inputY, 64, 42, '', { color: 0x0e7490, size: 12, onClick: () => this.typeMessage() }).add(iconImage(this, 0, 0, 'send', { size: 17, color: 0x67e8f9 }));

    // Muat riwayat + pasang listener realtime (ter-scoped: shutdown overlay
    // TIDAK lagi menghapus listener scene lain — bug lama yang bikin lobby
    // macet "Memuat daftar lobby..." setelah chat ditutup).
    this.loadHistory();
    const rt = Rt.scoped();
    rt.on('chat.global', (m) => { if (this.tab === 'global') this.pushMessage(m.name, m.message, false, m.classKey); });
    rt.on('chat.dm', (m) => {
      if (this.tab !== 'dm') return;
      const fromMe = m.from === CFG.userId;
      const other = fromMe ? m.to : m.from;
      if (this.dmTarget && other !== this.dmTarget.userId) return; // hanya percakapan aktif
      this.pushMessage(m.name, m.message, fromMe, null);
    });
    rt.on('lobby.chat', (m) => { if (this.tab === 'lobby' && m.from !== 'system') this.pushMessage(m.name, m.message, m.from === CFG.userId, null); });
    rt.on('chat.reject', (m) => Toast.show(this, { title: 'Pesan ditolak', message: m.reason || '', icon: 'cross', color: 0xdc2626 }));
    // Status koneksi realtime — chat TIDAK PERNAH gagal diam-diam lagi.
    this.applyRtStatus();
    rt.on('rt.state', () => this.applyRtStatus());
    this.events.once('shutdown', () => { rt.off(); this.stopPolling(); });
  }

  /* Chip status koneksi + mode hemat (poll REST 5 detik) saat WS terputus. */
  applyRtStatus() {
    if (this._rtChip) { this._rtChip.forEach((o) => o.destroy()); this._rtChip = null; }
    if (!CFG.server) return; // demo: loadHistory sudah menampilkan pesan sistem
    const W = this.scale.width, bw = Math.min(560, W - 24), bx = W / 2 - bw / 2;
    if (Rt.state === 'open') {
      this.stopPolling();
      this._rtChip = [this.add.text(bx + bw - 16, this.msgY - 12, 'realtime aktif', { fontFamily: F_UI, fontSize: '9.5px', color: '#34d399' }).setOrigin(1, 0.5)];
    } else if (Rt.state === 'connecting' || Rt.state === 'reconnecting') {
      this.startPolling();
      this._rtChip = [this.add.text(bx + bw - 16, this.msgY - 12, Rt.state === 'reconnecting' ? 'menyambung ulang...' : 'menyambungkan...', { fontFamily: F_UI, fontSize: '9.5px', color: '#fbbf24' }).setOrigin(1, 0.5)];
    } else {
      this.startPolling();
      this._rtChip = [this.add.text(bx + bw - 16, this.msgY - 12, 'terputus — mode hemat', { fontFamily: F_UI, fontSize: '10px', color: '#fca5a5', stroke: '#0b0b12', strokeThickness: 2 }).setOrigin(1, 0.5)];
      // v10: pesan sistem cukup SEKALI per sesi chat (v9: tiap flap WS numpuk).
      if (!this._rtSysShown) { this._rtSysShown = true; this.pushMessage('Sistem', 'Koneksi realtime terputus — pesan tetap terkirim lewat server, daftar dimuat ulang tiap 5 detik.', false, null); }
    }
  }
  startPolling() {
    if (!CFG.server || Rt.connected) return;
    if (this.tab !== 'global' && !(this.tab === 'dm' && this.dmTarget)) return;
    this.stopPolling();
    this._poll = setInterval(() => {
      try {
        if (!this.scene || !this.scene.isActive()) return;
        this._lines = [];
        this.loadHistory();
      } catch (_) {}
    }, 5000);
  }
  stopPolling() { if (this._poll) { clearInterval(this._poll); this._poll = null; } }
  async loadHistory() {
    if (this.tab === 'global') {
      if (!CFG.server) { this.pushMessage('Sistem', 'Mode demo — chat dunia hanya jalan di web resmi bot (login Discord).', false, null); return; }
      const r = await api('/api/rpg/chat/global');
      if (r && r.messages) for (const m of r.messages.slice(-18)) this.pushMessage(m.name, m.message, m.from === CFG.userId, m.classKey);
    } else if (this.tab === 'dm') {
      if (!CFG.server) { this.pushMessage('Sistem', 'Chat teman butuh server bot.', false, null); return; }
      if (this.dm) {
        this.dmTarget = this.dm;
        const r = await api('/api/rpg/chat/dm?with=' + encodeURIComponent(this.dm.userId));
        if (r && r.messages) for (const m of r.messages.slice(-18)) this.pushMessage(m.name, m.message, m.from === CFG.userId, null);
      } else {
        // Pilih teman dulu.
        const fr = await api('/api/rpg/friends');
        this.msgs.forEach((o) => o.destroy()); this.msgs = [];
        if (fr && fr.friends && fr.friends.length) {
          this.pushMessage('Pilih teman di halaman Teman untuk mulai chat.', '', false, null);
          this.dmList = fr.friends.slice(0, 6);
          this.dmList.forEach((f, i) => {
            const bx = this.scale.width / 2 - 200, y = this.msgY + 40 + i * 52;
            this.msgs.push(uiSlice(this, bx + 200, y + 22, 400, 44, 'ui_tile', 0x0f172a).setAlpha(0.95));
            this.msgs.push(iconImage(this, bx + 26, y + 22, 'user', { size: 20, color: f.online ? 0x22c55e : 0x475569 }));
            this.msgs.push(this.add.text(bx + 48, y + 22, f.name + '  •  ' + (f.online ? 'online' : 'offline'), { fontFamily: F_UI, fontSize: '12px', color: '#f1f5f9' }).setOrigin(0, 0.5));
            this.msgs.push(makeButton(this, bx + 344, y + 22, 90, 34, 'Buka', { color: 0x0e7490, size: 11, onClick: () => this.scene.restart({ back: this.backScene, dm: f, tab: 'dm' }) }));
          });
        } else {
          this.pushMessage('Belum punya teman.', 'Tambah lewat halaman Teman.', false, null);
        }
      }
    } else if (this.tab === 'lobby') {
      // v12: cukup SEKALI per sesi overlay (dulu tiap polling menambah lagi).
      if (!this._lobbyWelcomeShown) { this._lobbyWelcomeShown = true; this.pushMessage('Sistem', 'Pesan lobby terkirim real-time ke anggota party.', false, null); }
    }
  }
  async typeMessage() {
    const text = prompt('Tulis pesan:');
    if (!text || !text.trim()) return;
    const msg = text.trim().slice(0, 300);
    // 1) Realtime (paling cepat, langsung siar).
    if (this.tab === 'lobby') {
      if (!Rt.send('lobby.chat', { message: msg })) Toast.show(this, { title: 'Tidak terkirim', message: 'Chat lobby butuh koneksi realtime — ' + (Rt.lastError || 'belum tersambung') + '.', icon: 'cross', color: 0xdc2626 });
      return;
    }
    if (Rt.connected && Rt.send(this.tab === 'dm' ? 'chat.dm' : 'chat.global', this.tab === 'dm' ? { to: this.dmTarget && this.dmTarget.userId, message: msg } : { message: msg })) return;
    // 2) Mode demo: jelaskan, jangan diam.
    if (!CFG.server) { Toast.show(this, { title: 'Mode demo', message: 'Chat hanya jalan di web resmi bot (login Discord).', icon: 'cross', color: 0xb45309 }); return; }
    if (this.tab === 'dm' && !this.dmTarget) return;
    // 3) Fallback REST: WS diblokir proxy / belum tersambung — pesan TETAP sampai.
    const r = await api('/api/rpg/chat/' + (this.tab === 'dm' ? 'dm' : 'global'), {
      method: 'POST',
      body: this.tab === 'dm' ? { to: this.dmTarget.userId, message: msg } : { message: msg },
    });
    if (!r || r.error) { Toast.show(this, { title: 'Gagal mengirim', message: (r && r.error) || 'Server tidak merespons.', icon: 'cross', color: 0xdc2626 }); return; }
    this.pushMessage(r.name || (Data.char && Data.char.name) || 'Aku', r.message || msg, true, r.classKey);
  }
  pushMessage(name, message, isMe, classKey) {
    if (!message && message !== '') return;
    const bx = this.scale.width / 2 - Math.min(560, this.scale.width - 24) / 2;
    const bw = Math.min(560, this.scale.width - 24);
    // Render ulang seluruh daftar (maks 18) supaya rapi.
    if (this._lines == null) this._lines = [];
    // v12: dedup — pesan identik beruntun (race realtime vs polling) tidak dobel.
    const lastLine = this._lines[this._lines.length - 1];
    const nowMs = Date.now();
    if (lastLine && lastLine.name === name && lastLine.message === message && nowMs - (lastLine._t || 0) < 2500) return;
    this._lines.push({ name, message, isMe, classKey, _t: nowMs });
    if (this._lines.length > 18) this._lines = this._lines.slice(-18);
    this.msgs.forEach((o) => o.destroy());
    this.msgs = [];
    // v12: tinggi gelembung DINAMIS — pesan panjang membungkus rapi, tidak
    // lagi luber keluar gelembung 24px (akar bug screenshot chat).
    const meas = this.add.text(0, 0, '', { fontFamily: F_UI, fontSize: '11.5px', wordWrap: { width: 262 } }).setVisible(false);
    const hs = this._lines.map((line) => {
      if (line.message === '' && line.name.startsWith('Pilih')) return 20;
      meas.setText((line.name || '?') + ': ' + line.message);
      return Math.max(24, Math.ceil(meas.height) + 12);
    });
    meas.destroy();
    let yy = this.msgY + this.msgH - hs.reduce((a, b) => a + b + 4, 0);
    this._lines.forEach((line, i) => {
      if (line.message === '' && line.name.startsWith('Pilih')) {
        this.msgs.push(this.add.text(bx + bw / 2, this.msgY + 20, line.name, { fontFamily: F_UI, fontSize: '12px', color: '#8b96ab' }).setOrigin(0.5));
        return;
      }
      // v9: gelembung chat = aset tile (tint sisi); v12 tinggi adaptif.
      const isRight = !!line.isMe;
      const bh2 = hs[i];
      this.msgs.push(uiSlice(this, (isRight ? bx + bw - 24 - 150 : bx + 24 + 150), yy + bh2 / 2, 300, bh2, 'ui_tile', isRight ? 0x134e4a : 0x1e293b).setAlpha(0.92));
      const cls = line.classKey ? (CLASSES[line.classKey] || {}).color : null;
      this.msgs.push(this.add.text(isRight ? bx + bw - 34 : bx + 34, yy + bh2 / 2, (line.name || '?') + ': ' + line.message, {
        fontFamily: F_UI, fontSize: '11.5px', color: isRight ? '#5eead4' : '#e2e8f0',
        wordWrap: { width: 262 },
      }).setOrigin(isRight ? 1 : 0, 0.5));
      yy += bh2 + 4;
    });
  }
}

/* ---------- PARTY RAID (battle co-op turn-based, host authoritative) ---------- */
class PartyBattleScene extends Phaser.Scene {
  constructor() { super('PartyBattle'); }
  init(data) {
    this.code = data.code;
    this.seed = data.seed || 1;
    this.leader = data.leader;
    this.isHost = this.leader === (CFG.userId || 'me');
  }
  create() {
    const W = this.scale.width, H = this.scale.height;
    this.bg = buildLivingBackground(this, 'cave', { animated: true });
    sceneHeader(this, 'PARTY RAID', null, { y: H * 0.05, color: '#fca5a5', accent: 0xdc2626 });
    this.add.text(W / 2, H * 0.05 + 34, 'Lobby ' + this.code + (this.isHost ? ' — kamu pemegang giliran' : ' — menunggu pemimpin'), { fontFamily: F_UI, fontSize: '12.5px', color: '#94a3b8' }).setOrigin(0.5);

    // Boss acak (seeded).
    const rng = mulberry32(this.seed);
    const bosses = ['minotaur', 'yeti', 'dragon', 'demonlord'];
    const bossId = bosses[Math.floor(rng() * bosses.length)];
    const b = monsterById(bossId);
    this.boss = { ...b, hp: Math.round(b.hp * 0.5), hpMax: Math.round(b.hp * 0.5) };

    // Render boss di kanan.
    const def = MONSTER_ASSET[bossId];
    let sp;
    if (def && atlasHas(this, firstFrameName(def))) {
      sp = this.add.sprite(W * 0.72, this.bg.groundY, ATLAS_KEY, firstFrameName(def)).setOrigin(0.5, 1).setScale(def.s * 1.4).setTint(def.tint);
    } else {
      sp = this.add.sprite(W * 0.72, this.bg.groundY - 40, monsterTexture(this, this.boss)).setScale(monsterScale(this, this.boss) * 1.4).setOrigin(0.5, 0.8);
    }
    playMonsterAnim(this, sp, this.boss);
    this.bossSprite = sp;
    this.add.image(W * 0.72, this.bg.groundY + 4, 'fx_tex_shadow').setDisplaySize(90, 20).setAlpha(0.45);
    fxAura(this, sp.x, sp.y - 10, 60, 0xef4444, -4);

    // Pemain sendiri (kiri) + HP.
    const hv = heroVisual(this, Data.char.classKey, Data.char.customization, 4.0);
    this.heroSprite = this.add.sprite(W * 0.22, this.bg.groundY, hv.key, hv.frame || 0).setOrigin(0.5, 1).setScale(hv.scale);
    this.time.delayedCall(50, () => { const spr = this.heroSprite || this.hero || null; if (spr) this.partyGear = createHeroGear(this, spr, Data.char.classKey, Data.char.equipped || {}, { scale: 1.25, depth: 12, handOffset: { x: hv.lpc ? 21 : 18, y: hv.lpc ? -55 : -46 } }); });
    try { this.heroSprite.play(hv.anim.idle); } catch (_) {}
    const stats = computeStats(Data.char);
    this.myHp = stats.hp; this.myHpMax = stats.hp; this.myMp = stats.mp; this.myMpMax = stats.mp;
    this.busy = false;

    // Anggota lain (posisi baris) — dummy sampai party.state datang.
    this.members = [];

    // HUD boss.
    // v9: bar boss party = aset.
    this.bossBar = uiBar(this, W / 2, H - 120, Math.min(460, W - 200), 14, 1, 0xef4444, { frameTint: 0xef4444 });
    this.bossBarText = this.add.text(W / 2, H - 136, this.boss.name, { fontFamily: F_UI, fontSize: '12px', color: '#fca5a5', fontStyle: 'bold' }).setOrigin(0.5, 1);

    // Aksi: serang / skill / ramuan.
    const y = H - 64;
    makeButton(this, W / 2 - 170, y, 150, 48, 'Serang', { color: 0xdc2626, icon: 'sword', size: 13, onClick: () => this.act('attack') });
    makeButton(this, W / 2, y, 150, 48, 'Skill', { color: 0x7c3aed, icon: 'skill', size: 13, onClick: () => this.pickSkill() });
    makeButton(this, W / 2 + 170, y, 150, 48, 'Ramuan', { color: 0x0ea5e9, icon: 'potion', size: 13, onClick: () => this.act('potion') });
    makeButton(this, W - 60, H - 30, 100, 36, 'Keluar', { color: 0x7c2d12, icon: 'exit', size: 11, onClick: () => { Rt.send('lobby.leave'); this.scene.start('MultiplayerLobby'); } });

    // Relay host: terima aksi anggota, kirim state.
    const rt = Rt.scoped();
    rt.on('party.action', (m) => { if (this.isHost) this.hostApplyAction(m); });
    rt.on('party.state', (m) => { if (!this.isHost) this.applyState(m.state); });
    this.events.once('shutdown', () => rt.off());

    if (this.isHost) {
      // State awal host.
      this.hostState = {
        bossHp: this.boss.hp, bossHpMax: this.boss.hpMax,
        players: [{ userId: CFG.userId || 'me', name: Data.char.name || 'Aku', classKey: Data.char.classKey, hp: this.myHp, hpMax: this.myHpMax }],
        log: ['Party raid dimulai!'],
        over: false, result: null,
      };
      this.pushHostState();
    }
    this.renderOwn();
  }
  pickSkill() {
    const tree = SKILL_TREES[Data.char.classKey] || [];
    const unlocked = tree.filter((s) => s.type === 'active' && SkillState.get(s.id) > 0);
    if (!unlocked.length) { Toast.show(this, { title: 'Belum ada skill', message: 'Buka dulu di Skill Tree.', icon: 'skill', color: 0x7c3aed }); return; }
    if (this.skillMenu) { this.skillMenu.forEach((o) => o.destroy()); this.skillMenu = null; return; }
    this.skillMenu = [];
    const W = this.scale.width;
    unlocked.slice(0, 5).forEach((s, i) => {
      const eff = skillEffectScaled(s, SkillState.get(s.id));
      const b = makeButton(this, W / 2 + (i - Math.min(unlocked.length, 5) / 2 + 0.5) * 168, this.scale.height - 130, 158, 44, s.name, {
        color: 0x4c1d95, size: 10, icon: skillIconName(s), disabled: this.myMp < (eff.mp || 0),
        onClick: () => { this.skillMenu.forEach((o) => o.destroy()); this.skillMenu = null; this.act('skill', s.id); },
      });
      this.skillMenu.push(b);
    });
  }
  act(action, skillId) {
    if (this.busy) return;
    this.busy = true;
    setTimeout(() => this.busy = false, 900);
    if (this.isHost) this.hostApplyAction({ from: CFG.userId || 'me', action, arg: skillId });
    else Rt.send('party.action', { action, arg: skillId });
  }
  hostApplyAction(m) {
    const st = this.hostState;
    if (!st || st.over) return;
    const stats = computeStats(Data.char);
    let dmg = 0;
    if (m.action === 'attack') dmg = Math.round(stats.atk * RF(0.9, 1.3));
    else if (m.action === 'skill' && m.arg) {
      const def = skillById(Data.char.classKey, m.arg);
      if (def) {
        const eff = skillEffectScaled(def, SkillState.get(def.id));
        if (this.myMp >= (eff.mp || 0)) { this.myMp -= eff.mp || 0; dmg = Math.round(stats.atk * (eff.dmg || 1.2) * RF(0.9, 1.2) * (eff.hits || 1)); }
      }
    } else if (m.action === 'potion') {
      const inv = Data.char.inventory || {};
      const pid = Object.keys(inv).find((id) => poisonById(id) && ['heal', 'elixir'].includes(poisonById(id).kind));
      if (pid) {
        Data.useItem(pid);
        const pz = poisonById(pid);
        if (pz.kind === 'elixir') this.myHp = this.myHpMax; else this.myHp = Math.min(this.myHpMax, this.myHp + pz.val);
        floatText(this, this.heroSprite.x, this.heroSprite.y - 90, '+' + (pz.val || 'penuh') + ' HP', '#86efac', 14);
      }
      this.pushHostState();
      return;
    }
    if (dmg > 0) {
      st.bossHp = Math.max(0, st.bossHp - dmg);
      floatText(this, this.bossSprite.x, this.bossSprite.y - this.bossSprite.displayHeight - 30, '-' + dmg, '#fbbf24', 18, true);
      fxSparks(this, this.bossSprite.x, this.bossSprite.y - this.bossSprite.displayHeight * 0.5, 0xffe08a, 12);
      this.bossSprite.setTintFill(0xffffff);
      this.time.delayedCall(100, () => { if (this.bossSprite.active) { this.bossSprite.clearTint(); if (MONSTER_ASSET[this.boss.id] && MONSTER_ASSET[this.boss.id].tint) this.bossSprite.setTint(MONSTER_ASSET[this.boss.id].tint); } });
      Sfx.hit();
    }
    // Serangan balik boss (jika masih hidup).
    if (st.bossHp > 0) {
      const dmgIn = Math.max(1, Math.round(this.boss.atk * 0.35 * RF(0.8, 1.2) - stats.def * 0.4));
      this.myHp = Math.max(0, this.myHp - dmgIn);
      st.players[0].hp = this.myHp;
      floatText(this, this.heroSprite.x, this.heroSprite.y - 90, '-' + dmgIn, '#fca5a5', 14);
      this.heroSprite.setTintFill(0xef4444);
      this.time.delayedCall(120, () => { if (this.heroSprite.active) this.heroSprite.clearTint(); });
      Sfx.hurt();
    } else {
      st.over = true; st.result = 'win';
    }
    if (this.myHp <= 0) { st.over = true; st.result = 'lose'; }
    this.pushHostState();
    if (st.over) this.finishRaid(st.result);
  }
  pushHostState() {
    const st = this.hostState;
    st.players[0].hp = this.myHp;
    this.applyState(st);
    Rt.send('party.state', { state: { bossHp: st.bossHp, bossHpMax: st.bossHpMax, players: st.players, log: st.log, over: st.over, result: st.result } });
  }
  applyState(st) {
    if (!st) return;
    if (this.bossBar) this.bossBar.setFillRatio(clamp(st.bossHp / (st.bossHpMax || 1), 0, 1));
    if (st.over && !this.ended) this.finishRaid(st.result);
  }
  renderOwn() {
    if (this.hpText) this.hpText.destroy();
    this.hpText = this.add.text(16, 14, 'HP ' + Math.max(0, Math.round(this.myHp)) + '/' + this.myHpMax + '   MP ' + Math.max(0, Math.round(this.myMp)) + '/' + this.myMpMax, { fontFamily: F_UI, fontSize: '13px', color: '#f8fafc', fontStyle: 'bold' });
  }
  finishRaid(result) {
    if (this.ended) return;
    this.ended = true;
    const W = this.scale.width, H = this.scale.height;
    if (this.isHost) Rt.send('party.state', { state: this.hostState, raidEnd: true });
    const win = result === 'win';
    if (win) Sfx.victory(); else Sfx.defeat();
    const bw = Math.min(420, W - 50);
    uiSlice(this, W / 2, H / 2, bw, 190, 'ui_panel', 0x0a0f1c).setAlpha(0.96).setDepth(2000);
    uiSlice(this, W / 2, H / 2, bw - 4, 186, 'ui_outline', win ? 0x16a34a : 0xdc2626).setDepth(2000);
    this.add.text(W / 2, H / 2 - 48, win ? 'RAID BERHASIL' : 'PARTI TUMBANG', { fontFamily: F_HEAD, fontSize: '20px', color: win ? '#86efac' : '#fca5a5' }).setOrigin(0.5).setDepth(2001);
    this.add.text(W / 2, H / 2 - 6, win ? 'Boss tumbang berkat kerja tim.' : 'Coba lagi dengan party yang lebih siap.', { fontFamily: F_UI, fontSize: '13px', color: '#94a3b8' }).setOrigin(0.5).setDepth(2001);
    makeButton(this, W / 2, H / 2 + 54, 220, 48, 'Kembali ke Lobby', { color: 0x16a34a, size: 13, onClick: () => this.scene.start('MultiplayerLobby') }).setDepth(2002);
  }
}
function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* ============================================================================
 * 12. KONFIG GAME + ERROR HANDLER
 * ========================================================================== */
installSceneTransitions();
let __kzGameBooted = false;
let __kzRendererPref = null; // 'webgl' | 'canvas' hasil probe pre-flight
/* v12 §1A: PRE-FLIGHT WEBGL — uji KEMAMPUAN framebuffer persis seperti yang
 * dibutuhkan Phaser 3.85 saat boot (3 render target seukuran game, masing-
 * masing dengan color + depth-stencil). GPU WebGL1/low-end bisa menolak
 * kombinasi NPOT + DEPTH_STENCIL -> "Framebuffer status: Framebuffer
 * Unsupported". Dengan probe ini kita turun ke CANVAS SECARA AMAN sebelum
 * Phaser dibuat, alih-alih crash di layar judul. */
function kzWebGLProbe() {
  try {
    const portrait = window.innerHeight > window.innerWidth;
    const gw = portrait ? 720 : 1280, gh = portrait ? 1280 : 720;
    const c = document.createElement('canvas');
    const gl = c.getContext('webgl2') || c.getContext('webgl') || c.getContext('experimental-webgl');
    if (!gl) return 'canvas';
    const maxTex = gl.getParameter(gl.MAX_TEXTURE_SIZE) || 4096;
    if (maxTex < Math.max(gw, gh)) return 'canvas';
    const test = (withDepth) => {
      const tex = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gw, gh, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
      const fb = gl.createFramebuffer();
      gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
      if (withDepth) {
        const rb = gl.createRenderbuffer();
        gl.bindRenderbuffer(gl.RENDERBUFFER, rb);
        gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_STENCIL, gw, gh); // identik dgn wrapper Phaser
        gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_STENCIL_ATTACHMENT, gl.RENDERBUFFER, rb);
      }
      const ok = gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE;
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      return ok;
    };
    const okPlain = test(false);
    const okDepth = test(true);
    const lose = gl.getExtension('WEBGL_lose_context');
    if (lose) lose.loseContext();
    return (okPlain && okDepth) ? 'webgl' : 'canvas';
  } catch (_) { return 'canvas'; }
}
/* v12 §1A: PEMULIHAN ANGGRUN — bila framebuffer gagal saat RUNTIME (kasus
 * umum: context WebGL hilang karena memori lalu dipulihkan, dan pembuatan
 * ulang FBO ditolak GPU), halaman dimuat ulang sekali ke mode aman canvas.
 * Tanpa ini: Uncaught Error -> layar "Terjadi Error" permanen. */
window.addEventListener('kz-fbo-fail', (ev) => {
  if (window.__kzRebooting) return;
  window.__kzRebooting = true;
  console.warn('[kz] framebuffer runtime gagal — muat ulang mode aman (canvas)');
  try { sessionStorage.setItem('kzFboDebug', JSON.stringify((ev && ev.detail) || {})); } catch (_) {}
  try {
    const el = document.getElementById('boot');
    if (el) {
      if (window.kzSplashShow) window.kzSplashShow();
      else { el.classList.remove('hidden'); el.style.display = ''; }
      el.innerHTML = '<div class="logo">KIZHOO ADVENTURE</div>' +
        '<div style="color:#fbbf24;font-size:13px;line-height:1.6;margin:14px;text-align:center;font-family:ui-monospace,monospace">Grafis direset oleh perangkat.<br>Memuat ulang dalam mode aman...</div>' +
        '<div class="bar"><i style="width:72%"></i></div>';
    }
  } catch (_) {}
  setTimeout(() => {
    try { sessionStorage.setItem('kzSafeMode', '1'); } catch (_) {}
    location.reload();
  }, 900);
});
function bootGame() {
  if (__kzGameBooted) return;
  __kzGameBooted = true;
  // v10: boot DITUNDA sampai font pixel siap (max 2.5s) — tanpa ini teks
  // terukur pakai font fallback yang lebih lebar -> label tombol luber.
  (window.__kzFontsReady || Promise.resolve()).then(() => {
  window.__kzData = Data; // hook QA (debug state karakter)
  // v12 §1A: pilih renderer dari probe; sesi yang pernah gagal FBO -> canvas.
  let kzSafe = false;
  try { kzSafe = sessionStorage.getItem('kzSafeMode') === '1'; } catch (_) {}
  if (!kzSafe && !__kzRendererPref) __kzRendererPref = kzWebGLProbe();
  const renderType = (kzSafe || __kzRendererPref === 'canvas') ? Phaser.CANVAS : Phaser.AUTO;
  window.__kzRenderer = renderType === Phaser.CANVAS ? 'canvas' : 'webgl';
  window.__game = new Phaser.Game({
    type: renderType,
    parent: 'game',
    backgroundColor: '#0a0f1c',
    pixelArt: true,
    roundPixels: true,
    scale: (() => {
      const portrait = window.innerHeight > window.innerWidth;
      return { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH, width: portrait ? 720 : 1280, height: portrait ? 1280 : 720 };
    })(),
    physics: { default: 'arcade', arcade: { gravity: { y: 900 }, debug: false } },
    // Dekorator withSceneFX: setiap scene otomatis fade-in + dolly sinematik
    // saat datang dari scene lain (bukan saat restart tab — itu tetap instan).
    scene: [
      BootScene, LoginScene, LobbyScene, ClassSelectScene, QuestBoardScene, QuestBattleScene,
      DungeonSelectScene, DungeonScene, InventoryScene, SkillTreeScene, ForgeScene, PetsScene,
      LeaderboardScene, ProfileScene, AchievementsScene, FriendsScene,
      MultiplayerLobbyScene, ChatOverlayScene, PartyBattleScene,
      GachaScene, TowerInfoScene, WorldBossScene, AuctionScene,
    ].map(withSceneFX),
  });
  });
}
(function () {
  // GATE FONT PIXEL: game hanya dibuat SETELAH Press Start 2P & Silkscreen
  // siap (atau timeout 2.2s bila font lambat/terblokir) supaya teks pertama
  // tidak pernah ter-render dengan font fallback sistem yang jelek. Splash
  // loading DOM tetap tampil selama menunggu — transisi mulus bagi pemain.
  const go = () => bootGame();
  try {
    if (document.fonts && document.fonts.load) {
      Promise.all([
        document.fonts.load('16px "Press Start 2P"'),
        document.fonts.load('16px "Silkscreen"'),
      ]).then(go, go);
      setTimeout(go, 2200);
      return;
    }
  } catch (_) {}
  go();
})();

function showFatal(title, detail) {
  try {
    const el = document.getElementById('boot');
    if (!el) return;
    if (window.kzSplashShow) window.kzSplashShow();
    else { el.classList.remove('hidden'); el.style.display = ''; }
    // Escape semua teks sebelum masuk innerHTML (defense-in-depth anti XSS).
    const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    el.classList.remove('hidden');
    el.innerHTML = '<div class="logo">KIZHOO ADVENTURE</div>' +
      '<div style="color:#fca5a5;font-size:13px;line-height:1.6;max-width:86%;text-align:center;font-family:ui-monospace,monospace;padding:16px">' +
      '<b>' + esc(title) + '</b><br><span style="opacity:.9">' + esc(detail).replace(/&lt;(br|small|b)&gt;/gi, (m) => ({ '&lt;br&gt;': '<br>', '&lt;small&gt;': '<small>', '&lt;/small&gt;': '</small>', '&lt;b&gt;': '<b>', '&lt;/b&gt;': '</b>' }[m.toLowerCase()])) + '</span></div>' +
      '<button id="bootRetry" style="display:block" onclick="location.reload()">Coba Lagi</button>';
  } catch (_) {}
}
window.addEventListener('error', (e) => {
  const stack = (e.error && e.error.stack) ? String(e.error.stack).split('\n').slice(0, 4).join('<br>') : '';
  showFatal('Terjadi Error', (e.message || 'Unknown') + (stack ? '<br><br><small style="opacity:.8">' + stack + '</small>' : ''));
});
window.addEventListener('unhandledrejection', (e) => {
  const r = e && e.reason;
  showFatal('Koneksi Bermasalah', (r && (r.message || r)) || 'Promise ditolak tanpa pesan.');
});