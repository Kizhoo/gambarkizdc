const { SlashCommandBuilder, version: djsVersion, PermissionsBitField } = require('discord.js');
const { baseEmbed } = require('../../utils/embeds');
const { safeDefer } = require('../../utils/interactionHelpers');
const { t, guildLang } = require('../../utils/i18n');

function formatUptime(ms, lang = 'id') {
  const s = Math.floor(ms / 1000) % 60;
  const m = Math.floor(ms / 60000) % 60;
  const h = Math.floor(ms / 3600000) % 24;
  const d = Math.floor(ms / 86400000);
  return t(lang, 'info.uptime', { d, h, m, s });
}

const { runNetDiagnostics } = require('../../utils/netDiagnostics');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('info')
    .setDescription('Info seputar bot ini')
    .addSubcommand(sub => sub.setName('bot').setDescription('Lihat informasi teknis tentang bot ini'))
    .addSubcommand(sub => sub.setName('invite').setDescription('Dapatkan link untuk invite bot ini ke server lain'))
    .addSubcommand(sub => sub.setName('uptime').setDescription('Lihat berapa lama bot sudah online'))
    .addSubcommand(sub => sub.setName('stats').setDescription('Lihat statistik penggunaan resource bot'))
    .addSubcommand(sub => sub.setName('nettest').setDescription('Tes koneksi server ke Discord dan layanan eksternal yang dipakai bot')),

  async execute(interaction, client) {
    const lang = guildLang(interaction);
    const sub = interaction.options.getSubcommand();

    if (sub === 'bot') {
      const embed = baseEmbed()
        .setTitle(t(lang, 'info.title', { bot: client.user.username }))
        .setThumbnail(client.user.displayAvatarURL())
        .addFields(
          { name: t(lang, 'info.servers'), value: `${client.guilds.cache.size}`, inline: true },
          { name: t(lang, 'info.commands'), value: `${client.commands.size}`, inline: true },
          { name: t(lang, 'info.categories'), value: `${client.categories.length}`, inline: true },
          { name: t(lang, 'info.uptime'), value: formatUptime(client.uptime, lang), inline: true },
          { name: t(lang, 'info.ping'), value: `${Math.round(client.ws.ping)}ms`, inline: true },
          { name: 'discord.js', value: `v${djsVersion}`, inline: true },
          { name: 'Node.js', value: process.version, inline: true },
        );
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'invite') {
      const permissions = new PermissionsBitField([
        'ViewChannel', 'SendMessages', 'EmbedLinks', 'AttachFiles', 'ReadMessageHistory',
        'ManageMessages', 'ManageChannels', 'ManageRoles', 'KickMembers', 'BanMembers', 'ModerateMembers',
        'Connect', 'Speak',
      ]);
      const link = `https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=${permissions.bitfield}&scope=bot%20applications.commands`;
      const embed = baseEmbed().setTitle(t(lang, 'info.invite_title')).setDescription(t(lang, 'info.invite_desc', { bot: client.user.username, link }));
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'uptime') {
      const startTimestamp = Date.now() - client.uptime;
      const embed = baseEmbed().setTitle(t(lang, 'info.uptime_title')).setDescription(t(lang, 'info.uptime_desc', { ts: Math.floor(startTimestamp / 1000) }));
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'stats') {
      const memUsage = process.memoryUsage();
      const embed = baseEmbed()
        .setTitle(t(lang, 'info.stats_title'))
        .addFields(
          { name: t(lang, 'info.ram'), value: `${(memUsage.heapUsed / 1024 / 1024).toFixed(2)} MB`, inline: true },
          { name: t(lang, 'info.total_servers'), value: `${client.guilds.cache.size}`, inline: true },
          { name: t(lang, 'info.total_users'), value: `${client.users.cache.size}`, inline: true },
          { name: t(lang, 'info.total_channels'), value: `${client.channels.cache.size}`, inline: true },
          { name: t(lang, 'info.shard'), value: `${client.shard ? client.shard.count : 1}`, inline: true },
        );
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'nettest') {
      if (!(await safeDefer(interaction))) return;

      const embed = await runNetDiagnostics(client, interaction);
      return interaction.editReply({ embeds: [embed] });
    }
  },
};
