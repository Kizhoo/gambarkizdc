const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { updateGuildConfig } = require('../../database/db');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Kelola sistem ticket support')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addSubcommand(sub => sub.setName('setup').setDescription('Setup sistem ticket dan kirim panel di channel ini')
      .addChannelOption(o => o.setName('kategori').setDescription('Kategori tempat channel ticket dibuat').addChannelTypes(ChannelType.GuildCategory).setRequired(true))
      .addChannelOption(o => o.setName('log_channel').setDescription('Channel untuk log ticket yang ditutup').addChannelTypes(ChannelType.GuildText)))
    .addSubcommand(sub => sub.setName('add').setDescription('Tambah user ke ticket ini (dipakai di dalam channel ticket)')
      .addUserOption(o => o.setName('user').setDescription('User yang akan ditambahkan').setRequired(true)))
    .addSubcommand(sub => sub.setName('remove').setDescription('Keluarkan user dari ticket ini (dipakai di dalam channel ticket)')
      .addUserOption(o => o.setName('user').setDescription('User yang akan dikeluarkan').setRequired(true))),

  async execute(interaction) {
    const lang = guildLang(interaction);
    const sub = interaction.options.getSubcommand();

    if (sub === 'setup') {
      const category = interaction.options.getChannel('kategori');
      const logChannel = interaction.options.getChannel('log_channel');

      updateGuildConfig(interaction.guild.id, { ticketCategoryId: category.id, ticketLogChannel: logChannel ? logChannel.id : null });

      const embed = new EmbedBuilder()
        .setColor('#2b2d31')
        .setTitle(t(lang, 'ticket.title'))
        .setDescription(t(lang, 'ticket.desc'));

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('ticket_create').setLabel(t(lang, 'ticket.create')).setStyle(ButtonStyle.Primary)
      );

      await interaction.channel.send({ embeds: [embed], components: [row] });
      return interaction.reply({ embeds: [successEmbed(t(lang, 'ticket.setup_ok'))], ephemeral: true });
    }

    if (sub === 'add' || sub === 'remove') {
      if (!interaction.channel.topic?.startsWith('ticket-owner-')) {
        return interaction.reply({ embeds: [errorEmbed(t(lang, 'ticket.only_in_ticket'))], ephemeral: true });
      }
      const user = interaction.options.getUser('user');

      if (sub === 'add') {
        await interaction.channel.permissionOverwrites.edit(user.id, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true });
        return interaction.reply({ embeds: [successEmbed(t(lang, 'ticket.added', { user: `${user}` }))] });
      } else {
        await interaction.channel.permissionOverwrites.delete(user.id);
        return interaction.reply({ embeds: [successEmbed(t(lang, 'ticket.removed', { user: `${user}` }))] });
      }
    }
  },
};
