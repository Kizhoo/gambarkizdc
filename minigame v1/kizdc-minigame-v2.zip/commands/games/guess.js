const { errorEmbed } = require('../../utils/embeds');
const { fetchJson, randomItem } = require('../../utils/publicApi');
const { startQuiz } = require('../../utils/quizSession');
const { t, guildLang } = require('../../utils/i18n');

const API_URL = 'https://raw.githubusercontent.com/nazedev/database/refs/heads/master/games/tebakgambar.json';

module.exports = {
  subcommandOf: 'games',
  async execute(interaction) {
    const lang = guildLang(interaction);
    try {
      const puzzles = await fetchJson(API_URL, { ttl: 15 * 60 * 1000, timeout: 12000 });
      const puzzle = randomItem(puzzles?.filter(item => item.img && item.jawaban));
      if (!puzzle) throw new Error('dataset kosong atau format API berubah');
      return startQuiz(interaction, {
        title: t(lang, 'guess.title'),
        prompt: t(lang, 'guess.prompt'),
        image: puzzle.img,
        answer: puzzle.jawaban,
        hint: puzzle.deskripsi || undefined,
        reward: 100,
        source: 'NazeDev Database API',
      });
    } catch (error) {
      console.error('[games tebakgambar]', error);
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'guess.fail', { err: error.message }))], ephemeral: true }).catch(() => {});
    }
  },
};
