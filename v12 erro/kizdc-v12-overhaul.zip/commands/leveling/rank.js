const { SlashCommandBuilder, AttachmentBuilder } = require('discord.js');
const { getEconomy, getUserProfile } = require('../../database/db');
const rpgEngine = require('../../utils/rpgEngine');
const rpgDb = require('../../database/rpgDb');
const D = require('../../utils/rpgData');
const { baseEmbed } = require('../../utils/embeds');
const { renderProfileRpgCard } = require('../../utils/rpgCard');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rank')
    .setDescription('Lihat level, XP progress bar, dan kartu rank kamu')
    .addUserOption(o => o.setName('target').setDescription('User yang ingin dicek levelnya')),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const target = interaction.options.getUser('target') || interaction.user;
    const char = rpgDb.getCharacter(target.id);
    if (!char) {
      return interaction.reply({ embeds: [baseEmbed().setDescription(t(lang, 'rpg.user_no_char', { u: target.username }))], ephemeral: true });
    }
    // Gold digabung dari saldo /economy (sumber kebenaran tunggal), seperti /rpg profil lama.
    const wallet = rpgDb.getWallet(target.id, interaction.guild.id);
    char.gold = wallet.gold;
    char.silver = wallet.silver;
    char.copper = wallet.copper;

    const stats = rpgEngine.computeStats({ ...char, userId: target.id });
    const xpForNext = D.xpForLevel(char.level);
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    const prof = getUserProfile(target.id) || {};
    const accent = prof.color || D.getRank(char.rankKey).color;

    try {
      let app = {};
      try { app = JSON.parse(char.appearance || '{}'); } catch (_) {}
      const png = await renderProfileRpgCard({
        user: { username: target.username, displayName: member?.displayName || target.username, avatarURL: target.displayAvatarURL({ extension: 'png', size: 256 }) },
        char, stats, xpForNext, promoText: '',
        cardBg: app.cardBg || null, cardBgUrl: app.cardBgUrl || null,
      });
      const file = new AttachmentBuilder(png, { name: 'rank.png' });
      const embed = baseEmbed().setColor(accent).setImage('attachment://rank.png');
      return interaction.reply({ embeds: [embed], files: [file] });
    } catch (e) {
      // Fallback teks (kalau canvas gagal di host).
      const econ = getEconomy(interaction.guild.id, target.id);
      const pct = Math.min(100, Math.floor((char.xp / (xpForNext || 1)) * 100));
      const len = 15;
      const filled = Math.round((pct / 100) * len);
      const bar = '█'.repeat(filled) + '░'.repeat(len - filled);
      const embed = baseEmbed()
        .setAuthor({ name: `${target.username} — Level ${char.level}`, iconURL: target.displayAvatarURL() })
        .setColor(accent)
        .setDescription(`${bar}\n**${char.xp}/${xpForNext === Infinity ? 'MAX' : xpForNext} XP** (${pct}%)\n🪙 ${econ.balance.toLocaleString('id-ID')} KZC • 🏦 ${econ.bank.toLocaleString('id-ID')} KZC`);
      return interaction.reply({ embeds: [embed] });
    }
  },
};
