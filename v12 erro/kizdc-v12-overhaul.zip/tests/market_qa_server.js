// Mini server QA visual market: route yang dibutuhkan market.js dengan data asli.
process.env.KIZHOO_DB_PATH = '/tmp/kiz_market_qa.sqlite';
require('fs').rmSync('/tmp/kiz_market_qa.sqlite', { force: true });
const express = require('express');
const path = require('path');
const rpgDb = require('../database/rpgDb');
const shopManager = require('../utils/shopManager');
const econDb = require('../database/economyDb');

const app = express();
app.use(express.json());
app.use((req, res, next) => { res.setHeader('Cache-Control', 'no-store'); next(); });
app.use(express.static(path.join(__dirname, '..', 'dashboard', 'public')));

const sessions = {};
app.use((req, res, next) => {
  const sid = String(req.headers.cookie || '').replace(/.*kz_sid=([^;]*).*/, '$1');
  if (sessions[sid]) req.session = sessions[sid];
  next();
});
app.get('/api/me', (req, res) => res.json({ userId: '42', username: 'penguji', avatar: null, guilds: [] }));
app.get('/api/guilds', (req, res) => res.json([{ id: 'g1', name: 'Server Uji' }]));

app.get('/api/market/items', (req, res) => {
  const guildId = 'g1';
  const rpgItems = require('../utils/rpgItems');
  const { items, state } = shopManager.listMarket(guildId);
  const q = String(req.query.q || '').toLowerCase();
  const cat = String(req.query.category || '');
  let all = items.filter(i => i.id !== 'bank_stock');
  if (cat) all = all.filter(i => i.category === cat);
  if (q) all = all.filter(i => (i.name || '').toLowerCase().includes(q));
  const out = all.slice(0, 12).map(i => {
    const st = econDb.getItemStats(guildId, i.id);
    const full = rpgItems.getItem(i.id) || {};
    return { id: i.id, name: i.name, category: i.category, price: i.price, demand: i.demand, trend: i.trend, desc: i.desc, change24hPct: st.change24hPct, volume24h: st.volume24h, tier: i.tier, class: i.class, effect: i.effect, stats: full.stats || null, wtype: full.wtype || full.atype || null, use: full.use || null };
  });
  const categories = Object.entries(shopManager.CATEGORIES || {}).map(([key, v]) => ({ key, label: v.label }));
  res.json({ items: out, page: 1, perPage: 12, totalPages: 3, total: all.length, categories, state: { priceIndex: state.priceIndex } });
});
app.get('/api/trade/:g/portfolio', (req, res) => res.json({ userId: '42', balance: 12500, bank: 0, total: 12500, holdings: [], openOrders: [], trades: [] }));
app.post('/api/market/buy', (req, res) => res.json({ ok: true, total: 100, qty: 1, item: { id: 'x', name: 'Uji', price: 100 } }));

const PORT = 8898;
app.listen(PORT, '127.0.0.1', () => {
  console.log('market QA server di http://127.0.0.1:' + PORT + '/market.html');
  // Seed session
  sessions['qasid'] = { userId: '42', username: 'penguji' };
  rpgDb.saveSession('qasid', sessions['qasid']);
});
