// ============================================================================
// INSTRUMEN TRADING KZC — definisi instrumen sintetis web trading.
// ----------------------------------------------------------------------------
// Harga DASAR tiap instrumen diturunkan dari kondisi ekonomi internal
// (inflation, suku bunga, priceIndex, siklus) lewat economyEngine.summary().
// Pergerakan harga SELANJUTNYA ditangani utils/marketEngine.js (bukan di sini).
//
// Instrumen ini BUKAN cryptocurrency sungguhan dan TIDAK terhubung ke Binance.
// ============================================================================
const economyEngine = require('./economyEngine');

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, Number(v) || 0));

const BANK_STOCK_ID = 'bank_kizaria';

// base(s) = harga jangkar (anchor) saat ekonomi dalam kondisi `s` (summary).
// marketEngine memakai ini sebagai titik awal + target mean-reversion.
const INSTRUMENTS = [
  { id: 'kzc_usd', name: 'Kizco / Dolar', ticker: 'KZC/USD', kind: 'forex', base: (s) => Math.max(100, Math.round(1000 * (1 + clamp((s.inflationPct || 0) / 100, -0.8, 0.8)))) },
  { id: 'kzc_xau', name: 'Kizco / Emas', ticker: 'KZC/XAU', kind: 'forex', base: (s) => Math.round(50000 * (1 + clamp((s.inflationPct || 0) / 100, -0.5, 1))) },
  { id: 'kzc_cry', name: 'Kizco / Crypto', ticker: 'KZC/CRYPTO', kind: 'crypto', base: (s) => Math.round(2500 * (1 + clamp((s.policyRate || 3) / 20, -0.5, 1.5) + Math.sin((s.cycle || 0) / 5) * 0.2)) },
  { id: 'kzc_idx', name: 'Indeks Kizco', ticker: 'KZC.IDX', kind: 'index', base: (s) => Math.max(1, Math.round(1000 * Math.log10(Math.max(10, s.priceIndex || 100)))) },
  { id: 'bank_kizaria', name: 'Saham Bank Kizaria', ticker: 'BKZ', kind: 'stock', base: (s) => Math.round(100000 * (1 + (s.bankInterestRatePct || 2) / 100 + clamp((s.inflationPct || 0) / 100, -0.5, 0.5) * 2)) },
];

function instrumentById(id) { return INSTRUMENTS.find(i => i.id === id) || null; }

function instrumentBase(guildId, id) {
  const inst = instrumentById(id);
  if (!inst) return null;
  return Math.max(1, Math.round(inst.base(economyEngine.summary(guildId))));
}

module.exports = { INSTRUMENTS, BANK_STOCK_ID, instrumentById, instrumentBase };
