const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { addReactionRole, removeReactionRole } = require('../../database/db');
const { parseEmojiKey } = require('../../utils/emojiUtil');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { t, guildLang } = require('../../utils/i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('reactionrole')
    .setDescription('Kelola reaction role di sebuah pesan')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addSubcommand(sub => sub.setName('add').setDescription('Setup reaction role di sebuah pesan')
      .addStringOption(o => o.setName('message_id').setDescription('ID pesan yang akan ditambah reaction role').setRequired(true))
      .addStringOption(o => o.setName('emoji').setDescription('Emoji (unicode atau custom emoji server)').setRequired(true))
      .addRoleOption(o => o.setName('role').setDescription('Role yang akan diberikan').setRequired(true))
      .addChannelOption(o => o.setName('channel').setDescription('Channel tempat pesan berada (default: channel ini)').addChannelTypes(ChannelType.GuildText)))
    .addSubcommand(sub => sub.setName('remove').setDescription('Hapus reaction role dari sebuah pesan')
      .addStringOption(o => o.setName('message_id').setDescription('ID pesan reaction role').setRequired(true))
      .addStringOption(o => o.setName('emoji').setDescription('Emoji yang ingin dihapus mappingnya').setRequired(true))),

  async execute(interaction) {
    const lang = guildLang(interaction);
    const sub = interaction.options.getSubcommand();
    const messageId = interaction.options.getString('message_id');
    const emojiInput = interaction.options.getString('emoji');

    if (sub === 'add') {
      const role = interaction.options.getRole('role');
      const channel = interaction.options.getChannel('channel') || interaction.channel;

      const message = await channel.messages.fetch(messageId).catch(() => null);
      if (!message) return interaction.reply({ embeds: [errorEmbed(t(lang, 'rr.not_found'))], ephemeral: true });

      try {
        await message.react(emojiInput);
      } catch (err) {
        return interaction.reply({ embeds: [errorEmbed(t(lang, 'rr.bad_emoji'))], ephemeral: true });
      }

      const key = parseEmojiKey(emojiInput);
      addReactionRole(interaction.guild.id, messageId, key, role.id);
      return interaction.reply({ embeds: [successEmbed(t(lang, 'rr.added', { emoji: emojiInput, role: `${role}` }))], ephemeral: true });
    }

    if (sub === 'remove') {
      const key = parseEmojiKey(emojiInput);
      const removed = removeReactionRole(interaction.guild.id, messageId, key);
      if (!removed) return interaction.reply({ embeds: [errorEmbed(t(lang, 'rr.map_not_found'))], ephemeral: true });
      return interaction.reply({ embeds: [successEmbed(t(lang, 'rr.removed'))], ephemeral: true });
    }
  },
};
