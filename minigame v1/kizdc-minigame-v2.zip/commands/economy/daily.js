const { SlashCommandBuilder } = require('discord.js');
const { getEconomy, setLastAction } = require('../../database/db');
const engine = require('../../utils/economyEngine');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const kizco = require('../../utils/kizco');
const config = require('../../config.json');
const { t, guildLang } = require('../../utils/i18n');

const DAY_MS = 24 * 60 * 60 * 1000;

module.exports = {
  data: new SlashCommandBuilder().setName('daily').setDescription('Klaim Kizco harian gratis (dikenai pajak)'),
  async execute(interaction) {
    const lang = guildLang(interaction);
    const eco = getEconomy(interaction.guild.id, interaction.user.id);
    const now = Date.now();

    if (now - eco.lastDaily < DAY_MS) {
      const remaining = DAY_MS - (now - eco.lastDaily);
      const hours = Math.floor(remaining / 3600000);
      const minutes = Math.floor((remaining % 3600000) / 60000);
      return interaction.reply({ embeds: [errorEmbed(t(lang, 'daily.cooldown', { h: hours, m: minutes }))], ephemeral: true });
    }

    const base = config.dailyAmount;
    const { gross, tax, net } = engine.creditPlayer(interaction.guild.id, interaction.user.id, base, { type: 'daily', note: 'Klaim daily' });
    setLastAction(interaction.guild.id, interaction.user.id, 'lastDaily', now);

    const taxNote = tax > 0 ? t(lang, 'common.tax', { amount: kizco.format(tax) }) : '';
    return interaction.reply({ embeds: [successEmbed(t(lang, 'daily.success', { amount: kizco.format(net), tax: taxNote }))] });
  },
};
