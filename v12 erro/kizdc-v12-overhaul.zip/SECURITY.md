# Keamanan & Anti-Cloning — KizhooBot / Kizhoo Adventure

Dokumen ini menjelaskan sistem keamanan berlapis yang terpasang di dashboard web,
API RPG, WebSocket, dan klien game. Semua lapisan aktif otomatis saat bot jalan —
tidak perlu setup tambahan.

---

## Ringkasan Lapisan

| # | Lapisan | File | Fungsi |
|---|---------|------|--------|
| 1 | Security Headers | `utils/security.js` | CSP, X-Frame-Options DENY, nosniff, Referrer-Policy, Permissions-Policy, COOP/CORP, HSTS (https) |
| 2 | Host Guard | `utils/security.js` | **ANTI-KLON**: hanya domain terdaftar yang bisa meng-host situs |
| 3 | Origin Guard | `utils/security.js` | **ANTI-CSRF + ANTI-KLON**: mutasi (POST/PUT/DELETE) dari domain asing ditolak |
| 4 | Hotlink Guard | `utils/security.js` | Aset (`/assets/*`) tidak bisa dimuat dari halaman domain lain |
| 5 | Scanner Guard + Honeypot | `utils/security.js` | URL jebakan (`.env`, `wp-admin`, dll) & user-agent scanner (sqlmap, nikto) → ban otomatis |
| 6 | WAF Lite | `utils/security.js` | Query berbahaya (path traversal, union select, tag script) ditolak |
| 7 | Rate Limit | `utils/security.js` | 600 req/menit per IP + lockout brute-force login (8 gagal → ban 15 menit) |
| 8 | Blocklist & Strike | `utils/security.js` | Pelanggaran bertumpuk (5 strike / 10 menit) → ban otomatis 15 menit |
| 9 | Audit Log | `database/rpgDb.js` (tabel `rpg_security_log`) | Semua kejadian mencurigakan tercatat, bisa dilihat owner |
| 10 | Session Hardening | `dashboard/server.js` | Session ID 256-bit, cookie `HttpOnly; SameSite=Lax; Secure` (di https), perbandingan token timing-safe |
| 11 | WebSocket Guard | `utils/rpgRealtime.js`, `dashboard/server.js` | Origin check saat handshake, rate limit 240 pesan/10 detik, payload maks 8 KB |
| 12 | Scrub Body | `utils/security.js` | Prototype-pollution (`__proto__`/`constructor`) dibersihkan dari semua body JSON |
| 13 | CSP Nonce | `utils/rpgServer.js` | Halaman `/rpg` disajikan dengan nonce acak — script suntikan pihak lain tidak jalan |
| 14 | Security Lock (client) | `dashboard/public/security-lock.js` | **ANTI-KLON sisi browser**: verifikasi domain, frame-busting, blokir `file://` |
| 15 | Security Gate (client) | `dashboard/public/rpg.js` (paling atas) | Game menolak boot bila domain tidak resmi — terikat dengan #14 |
| 16 | Minifikasi | `scripts/build-client.js` → `rpg.min.js` | Kode game dipadatkan dengan terser (standar industri, ramah ToS hosting) |

---

## Cara Kerja Anti-Cloning

### 1. Sisi Server
Saat ada orang menyalin seluruh situsmu (HTTrack / save-page-as / curl) lalu
meng-hostingnya di domain mereka sendiri:

- **Host Guard** — permintaan dengan `Host: domain-kloner.com` ditolak `403`
  sebelum menyentuh rute mana pun. Domain yang diizinkan:
  - `localhost`, `127.0.0.1`, IP LAN pribadi (10.x / 192.168.x / 172.16-31.x) —
    untuk pengembangan & main dari perangkat lain di jaringan rumah
  - `*.trycloudflare.com` — tunnel bawaan bot (`ENABLE_TUNNEL=true`)
  - `*.space-z.ai` — sandbox preview
  - domainmu sendiri dari `DASHBOARD_REDIRECT_URL` dan `ALLOWED_DOMAINS`
- **Origin Guard** — kloner yang mencoba memanggil API-mu (`/api/rpg/*`) dari
  situs mereka ditolak karena header `Origin` tidak cocok.
- **Hotlink Guard** — kloner yang hanya menautkan aset (sprite, ikon, background)
  dari domain mereka mendapat `403`.

### 2. Sisi Browser (client)
`security-lock.js` dimuat paling awal di `rpg.html`:

- Memeriksa `location.hostname` terhadap daftar domain resmi yang
  **disuntik langsung oleh server asli** (`/security-lock.js` dinamis +
  `window.__KZ_SEC_BAKE` di halaman `/rpg`). Salinan statis milik kloner tidak
  punya suntikan ini.
- Bila tidak resmi (termasuk dibuka via `file://` hasil "Save Page As"):
  - seluruh halaman diganti overlay **"SITUS TIDAK RESMI"** + peringatan data
    akun tidak aman + tombol menuju situs resmi,
  - overlay dipasang ulang otomatis tiap 2 detik bila dihapus,
  - `window.__kzSecGate()` mengembalikan `false`.
- **Security Gate** di dalam `rpg.js` (ter-minify) memanggil gate itu saat
  boot — game **menolak jalan** bila gate tidak ada / false. Menghapus
  `security-lock.js` saja tidak cukup; gate di kode game tetap
  menahan lewat `__KZ_SEC_BAKE` yang hanya bisa disuntik server asli.

### 3. Minifikasi Standar (bukan obfuscation)
`npm run build:client` mengubah `rpg.js` (477 KB, terbaca manusia) menjadi
`rpg.min.js` (330 KB) memakai **terser** — minifikasi standar industri yang
dipakai hampir semua situs web. `rpg.html` otomatis memakai `rpg.min.js`;
kalau file itu belum dibangun, otomatis fallback ke `rpg.js` (mode develop).

> **Catatan penting:** sebelumnya build memakai `javascript-obfuscator`
> (stringArray base64, nama hexadecimal, self-defending). Praktik itu SAH,
> tetapi scanner ToS banyak shared hosting menandainya sebagai
> `OBFUSCATED_CODE` (pola yang identik dengan malware) dan akun bisa
> ter-ban otomatis. Sejak itu build dikembalikan ke minifikasi standar —
> proteksi anti-klon sepenuhnya TIDAK bergantung pada obfuscation, melainkan
> pada domain lock server + security gate client (lapisan 3, 5, 14, 15).

> Setiap selesai mengedit `rpg.js`, jalankan `npm run build:client`.

---

## Variabel Lingkungan (.env)

| Variabel | Wajib | Keterangan |
|----------|-------|------------|
| `DASHBOARD_TOKEN` | ya | token login dashboard (sudah ada sebelumnya) |
| `DASHBOARD_REDIRECT_URL` | disarankan | `https://domainmu.com/auth/callback` — domainnya otomatis masuk allowlist |
| `ALLOWED_DOMAINS` | opsional | tambahan domain resmi, pisah koma. Contoh: `kizdc.com,www.kizdc.com,game.kizdc.com` |
| `OFFICIAL_URL` | opsional | URL resmi untuk tombol "Buka Situs Resmi" di overlay anti-pirasi |
| `SECURITY_SECRET` | opsional | secret HMAC manifest (otomatis diturunkan bila kosong) |
| `OWNER_ID` | opsional | Discord ID kamu — dipakai endpoint status keamanan |

**PENTING**: setelah mengisi domain di `.env`, TIDAK perlu build ulang apa pun —
allowlist server dan suntikan client membaca env secara langsung saat serve.

---

## Endpoint Keamanan

| Endpoint | Akses | Fungsi |
|----------|-------|--------|
| `GET /api/security/manifest` | publik | daftar domain resmi (dibaca security-lock) |
| `GET /security-lock.js` | publik | script lock dengan config tersuntik |
| `GET /api/security/status` | owner (`OWNER_ID` / Bearer token) | ringkasan serangan 24 jam: jenis, jumlah, IP, rincian terbaru |

Contoh cek status:
```bash
curl -H "Authorization: Bearer $DASHBOARD_TOKEN" https://domainmu.com/api/security/status
```

---

## Test Suite

```bash
node tests/security_test.js   # 34 test: host/origin/WAF/hotlink/honeypot/rate/audit/gate
node tests/api_test.js        # 66 test API RPG (termasuk WS)
node tests/battle_test.js     # 7 test engine battle
```

Semua harus **0 gagal**. `api_test` dan `security_test` memakai server sungguhan
di port acak dan keluar secara bersih (tanpa `process.exit`).

---

## Catatan Teknis Penting

1. **Phaser self-hosted** — `rpg.html` memuat Phaser dari
   `/assets/vendor/phaser.min.js` (bukan CDN). Ini menghilangkan risiko
   supply-chain dari CDN pihak ketiga dan membuat CSP bisa ketat.
2. **gzip** — middleware `compression` dipasang; `rpg.min.js` 1,1 MB turun
   jadi sekitar 300 KB di jaringan.
3. **better-sqlite3 v12.11.1** — upgrade dari v11 karena kombinasi v11 +
   Node 24 memicu crash native saat keluar proses. v12 mendukung Node 20-26.
4. **Session cookie** — `kz_sid` kini 64 karakter hex (256-bit), flag `Secure`
   otomatis saat di belakang HTTPS/proxy.
5. **Body JSON dibatasi 256 KB** — sebelumnya 1 MB.
6. **XSS** — chat game dirender via Phaser text (bukan DOM, aman); nama guild/
   channel di panel di-escape; `showFatal` meng-escape semua teks.
7. Keputusan disengaja: rate limit global 600/menit per IP cukup longgar untuk
   pemain normal (game memuat ~200 aset kecil sekali jalan, ter-cache 7 hari),
   tetapi memotong scanner yang biasanya ribuan request per menit.
