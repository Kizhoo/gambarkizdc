const { sendLog } = require('../utils/serverLog');
const config = require('../config.json');

module.exports = {
  name: 'roleCreate',
  async execute(role) {
    sendLog(role.guild, {
      title: 'Role Dibuat',
      color: config.successColor,
      fields: [{ name: 'Role', value: `${role} (${role.name})` }],
      footer: `Role ID: ${role.id}`,
    });
  },
};
