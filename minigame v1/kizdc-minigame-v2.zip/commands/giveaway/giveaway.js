const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { createGiveaway, getGiveaway } = require('../../database/db');
const { finishGiveaway } = require('../../utils/giveawayUtil');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const config = require('../../config.json');
const { t, guildLang } = require('../../utils/i18n');

function parseDuration(input) {
  const match = input.match(/^(\d+)(d|h|m|s)$/i);
  if (!match) return null;
  const value = parseInt(match[1]);
  const unit = match[2].toLowerCase();
  const multipliers = { s: 1000, m: 60000, h: 3600000, d: 86400000 };
  return value * multipliers[unit];
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('giveaway')
    .setDescription('Kelola giveaway di server ini')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub => sub.setName('start').setDescription('Mulai giveaway baru')
      .addStringOption(o => o.setName('durasi').setDescription('Contoh: 10m, 1h, 1d').setRequired(true))
      .addStringOption(o => o.setName('hadiah').setDescription('Nama hadiah').setRequired(true))
      .addIntegerOption(o => o.setName('pemenang').setDescription('Jumlah pemenang (default 1)').setMinValue(1).setMaxValue(20)))
    .addSubcommand(sub => sub.setName('end').setDescription('Akhiri giveaway lebih cepat')
      .addStringOption(o => o.setName('message_id').setDescription('Message ID giveaway yang ingin diakhiri').setRequired(true)))
    .addSubcommand(sub => sub.setName('reroll').setDescription('Undi ulang pemenang giveaway yang sudah selesai')
      .addStringOption(o => o.setName('message_id').setDescription('Message ID giveaway').setRequired(true))),

  async execute(interaction, client) {
    const lang = guildLang(interaction);
    const sub = interaction.options.getSubcommand();

    if (sub === 'start') {
      const durationInput = interaction.options.getString('durasi');
      const prize = interaction.options.getString('hadiah');
      const winnerCount = interaction.options.getInteger('pemenang') || 1;
      const ms = parseDuration(durationInput);

      if (!ms || ms <= 0) return interaction.reply({ embeds: [errorEmbed(t(lang, 'gw.invalid'))], ephemeral: true });

      const endTime = Date.now() + ms;
      const embed = new EmbedBuilder()
        .setColor(config.embedColor)
        .setTitle('🎉 GIVEAWAY 🎉')
        .setDescription(t(lang, 'gw.desc', { prize, ts: Math.floor(endTime / 1000), count: winnerCount, host: `${interaction.user}` }))
        .setTimestamp(endTime);

      await interaction.reply({ embeds: [embed] });
      const sent = await interaction.fetchReply();
      await sent.react('🎉');

      createGiveaway({ messageId: sent.id, guildId: interaction.guild.id, channelId: interaction.channel.id, prize, winnerCount, endTime, hostId: interaction.user.id });
      return;
    }

    if (sub === 'end') {
      const messageId = interaction.options.getString('message_id');
      const giveaway = getGiveaway(messageId);
      if (!giveaway || giveaway.ended) return interaction.reply({ embeds: [errorEmbed(t(lang, 'gw.not_found'))], ephemeral: true });

      await finishGiveaway(client, giveaway);
      return interaction.reply({ embeds: [successEmbed(t(lang, 'gw.ended'))], ephemeral: true });
    }

    if (sub === 'reroll') {
      const messageId = interaction.options.getString('message_id');
      const message = await interaction.channel.messages.fetch(messageId).catch(() => null);
      if (!message) return interaction.reply({ embeds: [errorEmbed(t(lang, 'gw.msg_not_found'))], ephemeral: true });

      const reaction = message.reactions.cache.get('🎉');
      if (!reaction) return interaction.reply({ embeds: [errorEmbed(t(lang, 'gw.no_reaction'))], ephemeral: true });

      const users = await reaction.users.fetch();
      const participants = users.filter(u => !u.bot).map(u => u.id);
      if (participants.length === 0) return interaction.reply({ embeds: [errorEmbed(t(lang, 'gw.no_participants'))], ephemeral: true });

      const winner = participants[Math.floor(Math.random() * participants.length)];
      return interaction.reply({ embeds: [successEmbed(t(lang, 'gw.reroll', { w: winner }))] });
    }
  },
};
