// ============================================================================
// TOMBOL INTERAKTIF EKONOMI & MARKET
// ----------------------------------------------------------------------------
// Panel /economy dan /market jadi navigasi pakai TOMBOL (bukan cuma subcommand).
// Semua fungsi render di sini dipakai bareng oleh slash command (reply awal)
// dan button handler (interaction.update) supaya tampilan konsisten. Semua teks
// dilokalisasi lewat utils/i18n mengikuti bahasa server.
// ============================================================================
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, AttachmentBuilder } = require('discord.js');
const engine = require('./economyEngine');
const economist = require('./economistAI');
const shop = require('./shopManager');
const econ = require('../database/economyDb');
const { renderPriceChart, renderItemChart: renderItemChartPng } = require('./economyChart');
const kizco = require('./kizco');
const config = require('../config.json');
const { baseEmbed, errorEmbed } = require('./embeds');
const { getEconomy } = require('../database/db');
const { t, guildLang } = require('./i18n');

const PHASE_EMOJI = { expansion: '📈', peak: '🔥', recession: '📉', recovery: '🌱' };

// Jumlah barang per halaman kategori market. Dibatasi karena satu kategori bisa
// berisi ratusan item (dari itemGenerator) dan description embed Discord cuma
// muat 4096 karakter — kalau tidak dipaginasi, tombol kategori bakal error
// "Gagal memproses tombol" setiap kali diklik.
const MARKET_PAGE_SIZE = 8;

// Resolve bahasa dari guildId + helper label dinamis (fase & inflasi).
function langOf(guildId) { return guildLang({ id: guildId }); }
function phaseName(lang, phase) { return t(lang, 'phase.' + phase) || phase; }
function inflationName(lang, pct) {
  const p = Number(pct) || 0;
  if (p >= 50) return t(lang, 'inflation.hyper');
  if (p >= 10) return t(lang, 'inflation.extreme');
  if (p >= 3) return t(lang, 'inflation.high');
  if (p >= 0.5) return t(lang, 'inflation.moderate');
  if (p > -0.5) return t(lang, 'inflation.stable');
  if (p > -3) return t(lang, 'inflation.deflation');
  return t(lang, 'inflation.deep');
}

// ---------------- EKONOMI ----------------
function economyNavRow(active, lang) {
  const btn = (id, label, emoji) => new ButtonBuilder().setCustomId(id).setLabel(label).setStyle(active === id ? ButtonStyle.Primary : ButtonStyle.Secondary).setEmoji(emoji);
  return new ActionRowBuilder().addComponents(
    btn('econ:status', t(lang, 'btn.status'), '📊'),
    btn('econ:chart', t(lang, 'btn.chart'), '📈'),
    btn('econ:report', t(lang, 'btn.report'), '📰'),
    btn('econ:history', t(lang, 'btn.history'), '🕘'),
    btn('econ:channel', t(lang, 'btn.notif'), '🔔'),
  );
}

function statusEmbed(guildId, lang) {
  const s = engine.summary(guildId);
  const phase = phaseName(lang, s.phase);
  return baseEmbed()
    .setTitle(t(lang, 'eco.status_title', { phase }))
    .setDescription(t(lang, 'eco.status_desc', { emoji: PHASE_EMOJI[s.phase] || '', phase, health: s.health }))
    .addFields(
      { name: t(lang, 'eco.cpi'), value: `${s.priceIndex}`, inline: true },
      { name: t(lang, 'eco.inflation'), value: `**${inflationName(lang, s.inflationPct)}** ${kizco.pct(s.inflationPct)}/${t(lang, 'eco.cycle')}`, inline: true },
      { name: t(lang, 'eco.money_supply'), value: kizco.format(s.moneySupply), inline: true },
      { name: t(lang, 'eco.reward_mult'), value: `${s.rewardMultiplier.toFixed(2)}x`, inline: true },
      { name: t(lang, 'eco.income_tax'), value: `${s.taxRatePct}%`, inline: true },
      { name: t(lang, 'eco.bank_interest'), value: `${s.bankInterestRatePct}%/${t(lang, 'eco.cycle')}`, inline: true },
      { name: t(lang, 'eco.policy_rate'), value: `${Number(s.policyRate).toFixed(2)}%`, inline: true },
    )
    .setFooter({ text: `${config.footer} • ${t(lang, 'eco.cycle')} #${s.cycle}${s.lastTickAt ? ` • ${t(lang, 'eco.updated')} <t:${Math.floor(s.lastTickAt / 1000)}:R>` : ''}` });
}

function renderStatus(guildId) {
  const lang = langOf(guildId);
  return { embeds: [statusEmbed(guildId, lang)], components: [economyNavRow('econ:status', lang)] };
}

function renderChart(guildId) {
  const lang = langOf(guildId);
  const points = engine.getPriceHistory(guildId, 96);
  if (points.length < 2) {
    return { embeds: [errorEmbed(t(lang, 'eco.chart_no_data'))], components: [economyNavRow('econ:chart', lang)] };
  }
  const png = renderPriceChart(points, { title: t(lang, 'eco.chart_title') });
  const file = new AttachmentBuilder(png, { name: 'kizco-chart.png' });
  const last = points[points.length - 1];
  const embed = baseEmbed()
    .setTitle(t(lang, 'eco.chart_title'))
    .setDescription(t(lang, 'eco.chart_desc', { price: Number(last.priceIndex).toFixed(2), money: kizco.format(last.moneySupply) }))
    .setImage('attachment://kizco-chart.png')
    .setFooter({ text: t(lang, 'eco.chart_footer', { footer: config.footer }) });
  return { embeds: [embed], files: [file], components: [economyNavRow('econ:chart', lang)] };
}

function renderReport(guildId) {
  const lang = langOf(guildId);
  const logs = engine.getAiLog(guildId, 5);
  const nav = [economyNavRow('econ:report', lang)];
  if (!logs.length) {
    return { embeds: [errorEmbed(t(lang, 'eco.report_no_data'))], components: nav };
  }
  const latest = logs[0];
  const s = engine.summary(guildId);
  const embed = baseEmbed()
    .setTitle(t(lang, 'eco.report_title'))
    .setDescription(latest.decision)
    .addFields(
      { name: t(lang, 'eco.price_index'), value: `${s.priceIndex}`, inline: true },
      { name: t(lang, 'eco.inflation_short'), value: `${kizco.pct(s.inflationPct)}`, inline: true },
      { name: t(lang, 'eco.phase'), value: phaseName(lang, s.phase), inline: true },
    )
    .setFooter({ text: `${config.footer} • <t:${Math.floor(latest.timestamp / 1000)}:R>` });
  return { embeds: [embed], components: nav };
}

function renderHistory(guildId) {
  const lang = langOf(guildId);
  const txs = engine.getTransactions(guildId, 15);
  const nav = [economyNavRow('econ:history', lang)];
  if (!txs.length) return { embeds: [errorEmbed(t(lang, 'eco.history_no_data'))], components: nav };
  const ICON = { daily: '📅', work: '💼', quest: '📜', hunt: '⚔️', levelup: '⭐', pay: '💸', rob: '🥷', fine: '🚨', bank: '🏦', purchase: '🛒', sell: '🏷️', trade: '🤝', tax: '🧾', interest: '💰', qe: '🏛️', reward: '🎁' };
  const lines = txs.map(tx => {
    const sign = tx.amount >= 0 ? '+' : '';
    const actor = tx.actorId ? `<@${tx.actorId}>` : t(lang, 'eco.system');
    return `${ICON[tx.type] || '•'} ${actor} — \`${sign}${kizco.format(tx.amount)}\` _(${tx.type})_`;
  }).join('\n');
  return { embeds: [baseEmbed().setTitle(t(lang, 'eco.history_title')).setDescription(lines)], components: nav };
}

function renderChannelConfig(guildId) {
  const lang = langOf(guildId);
  const cfg = require('../database/db').getGuildConfig(guildId);
  const embed = baseEmbed()
    .setTitle(t(lang, 'eco.channel_title'))
    .setDescription(
      t(lang, 'eco.channel_desc', {
        status: cfg.econNotifyEnabled ? t(lang, 'eco.on') : t(lang, 'eco.off'),
        channel: cfg.econChannelId ? `<#${cfg.econChannelId}>` : t(lang, 'eco.not_set'),
      })
    );
  return { embeds: [embed], components: [economyNavRow('econ:channel', lang)] };
}

// ---------------- MARKET ----------------
function marketCategoryRow(active, lang) {
  const cats = [
    ['weapon', '🗡️'], ['armor', '🛡️'], ['accessory', '💍'], ['potion', '🧪'], ['consumable', '📦'],
    ['material', '🪨'], ['artifact', '🔮'], ['collectible', '🪙'], ['cosmetic', '🎩'], ['food', '🍖'],
  ];
  const rows = [];
  for (let i = 0; i < cats.length; i += 5) {
    const row = new ActionRowBuilder();
    cats.slice(i, i + 5).forEach(([key, emoji]) => {
      row.addComponents(new ButtonBuilder().setCustomId(`market:cat:${key}`).setLabel(t(lang, 'cat.' + key)).setStyle(active === key ? ButtonStyle.Primary : ButtonStyle.Secondary).setEmoji(emoji));
    });
    rows.push(row);
  }
  return rows;
}
function marketNavRow(lang) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('market:trends').setLabel(t(lang, 'btn.trends')).setStyle(ButtonStyle.Secondary).setEmoji('📊'),
    new ButtonBuilder().setCustomId('market:home').setLabel(t(lang, 'btn.home')).setStyle(ButtonStyle.Secondary).setEmoji('🏠'),
  );
}

function renderMarketHome(guildId) {
  const lang = langOf(guildId);
  const { state, totalListed } = shop.listMarket(guildId);
  const embed = baseEmbed()
    .setTitle(t(lang, 'market.home_title'))
    .setDescription(t(lang, 'market.home_desc', { price: state.priceIndex, inflation: `${inflationName(lang, state.inflationPct)} ${kizco.pct(state.inflationPct)}`, total: totalListed }));
  return { embeds: [embed], components: [...marketCategoryRow(null, lang), marketNavRow(lang)] };
}

function renderMarketCategory(guildId, cat, page = 0) {
  const lang = langOf(guildId);
  let { items } = shop.listMarket(guildId);
  items = items.filter(i => i.category === cat);
  const components = [...marketCategoryRow(cat, lang)];

  if (!items.length) {
    return { embeds: [errorEmbed(t(lang, 'market.cat_empty'))], components: [...components, marketNavRow(lang)] };
  }

  const totalPages = Math.ceil(items.length / MARKET_PAGE_SIZE);
  page = Math.max(0, Math.min(totalPages - 1, Number(page) || 0));
  const slice = items.slice(page * MARKET_PAGE_SIZE, page * MARKET_PAGE_SIZE + MARKET_PAGE_SIZE);

  const desc = slice.map(it =>
    `**${it.name}** \`${it.id}\` — **${kizco.format(it.price)}** ${it.trend !== 'stabil' ? `_(${it.trend})_` : ''}`
  ).join('\n');

  // Tombol beli untuk halaman ini (maks 5 per baris).
  const buyRow = new ActionRowBuilder();
  slice.slice(0, 5).forEach(it => {
    buyRow.addComponents(new ButtonBuilder().setCustomId(`market:buy:${it.id}`).setLabel(`${t(lang, 'btn.buy_prefix')} ${String(it.name).slice(0, 24)}`).setStyle(ButtonStyle.Success).setEmoji('🛒'));
  });

  // Navigasi halaman (muncul cuma kalau kategorinya lebih dari satu halaman).
  if (totalPages > 1) {
    const pageRow = new ActionRowBuilder();
    if (page > 0) pageRow.addComponents(new ButtonBuilder().setCustomId(`market:page:${cat}:${page - 1}`).setLabel(t(lang, 'btn.prev')).setStyle(ButtonStyle.Secondary).setEmoji('◀️'));
    pageRow.addComponents(new ButtonBuilder().setCustomId('market:page:info').setLabel(t(lang, 'page.info', { page: page + 1, total: totalPages })).setStyle(ButtonStyle.Secondary).setDisabled(true));
    if (page < totalPages - 1) pageRow.addComponents(new ButtonBuilder().setCustomId(`market:page:${cat}:${page + 1}`).setLabel(t(lang, 'btn.next')).setStyle(ButtonStyle.Secondary).setEmoji('▶️'));
    components.push(pageRow);
  }

  components.push(buyRow, marketNavRow(lang));
  const embed = baseEmbed()
    .setTitle(t(lang, 'market.cat_title', { cat: t(lang, 'cat.' + cat) || cat }))
    .setDescription(desc)
    .setFooter({ text: t(lang, 'market.cat_footer', { n: items.length }) });
  return { embeds: [embed], components };
}

function renderMarketTrends(guildId) {
  const lang = langOf(guildId);
  const { signals, items } = shop.listMarket(guildId);
  const hot = items.filter(i => i.demand >= 3).sort((a, b) => b.demand - a.demand).slice(0, 5);
  const hotText = hot.length
    ? t(lang, 'market.trends_hot', { items: hot.map(i => `\`${i.id}\` ${i.name} — ${kizco.format(i.price)}`).join('\n') })
    : t(lang, 'market.trends_balanced');
  const embed = baseEmbed()
    .setTitle(t(lang, 'market.trends_title'))
    .setDescription(
      t(lang, 'market.trends_desc', { hunt: signals.hunt, quest: signals.quest, leveling: signals.leveling, trade: signals.trade, purchase: signals.purchase, hot: hotText })
    )
    .setFooter({ text: t(lang, 'market.trends_footer') });
  return { embeds: [embed], components: [...marketCategoryRow(null, lang), marketNavRow(lang)] };
}

function renderItemChart(guildId, itemId) {
  const lang = langOf(guildId);
  const item = shop.getItem(itemId);
  const points = econ.getItemPriceHistory(guildId, itemId, 100);
  const backRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`market:cat:${item?.category || 'consumable'}`).setLabel(t(lang, 'btn.back')).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('market:home').setLabel(t(lang, 'btn.home')).setStyle(ButtonStyle.Secondary).setEmoji('🏠'),
  );
  if (!item) return { embeds: [errorEmbed(t(lang, 'market.unknown2'))], components: [backRow] };
  if (points.length < 2) {
    return { embeds: [baseEmbed().setTitle(t(lang, 'market.chart_title', { item: item.name })).setDescription(t(lang, 'market.chart_no_data'))], components: [backRow] };
  }
  const png = renderItemChartPng(points, { title: t(lang, 'market.chart_title', { item: item.name }) });
  const file = new AttachmentBuilder(png, { name: 'item-chart.png' });
  const embed = baseEmbed().setTitle(t(lang, 'market.chart_title', { item: item.name })).setImage('attachment://item-chart.png');
  return { embeds: [embed], files: [file], components: [backRow] };
}

// Render ulang menu dari customId — dipakai buat bangkit dari interaksi yang
// kedaluwarsa (kirim menu baru sebagai pesan segar).
function renderForId(guildId, id) {
  if (id === 'econ:status') return renderStatus(guildId);
  if (id === 'econ:chart') return renderChart(guildId);
  if (id === 'econ:report') return renderReport(guildId);
  if (id === 'econ:history') return renderHistory(guildId);
  if (id === 'econ:channel') return renderChannelConfig(guildId);
  if (id === 'market:home') return renderMarketHome(guildId);
  if (id === 'market:trends') return renderMarketTrends(guildId);
  if (id.startsWith('market:cat:')) return renderMarketCategory(guildId, id.slice('market:cat:'.length));
  if (id.startsWith('market:page:')) {
    const parts = id.split(':');
    return renderMarketCategory(guildId, parts[2], Number(parts[3]) || 0);
  }
  return null;
}

// ---------------- BUTTON HANDLER ----------------
async function handleButton(interaction) {
  const id = interaction.customId;
  const guildId = interaction.guild.id;
  const lang = guildLang(interaction);

  try {
    if (id === 'econ:status') return await interaction.update(renderStatus(guildId));
    if (id === 'econ:chart') return await interaction.update(renderChart(guildId));
    if (id === 'econ:report') {
      // On-demand: jalankan analisis AI segar supaya laporan selalu ter-update.
      await interaction.deferUpdate();
      await economist.runNow(guildId);
      return await interaction.editReply(renderReport(guildId));
    }
    if (id === 'econ:history') return await interaction.update(renderHistory(guildId));
    if (id === 'econ:channel') return await interaction.update(renderChannelConfig(guildId));

    if (id === 'market:home') return await interaction.update(renderMarketHome(guildId));
    if (id === 'market:trends') return await interaction.update(renderMarketTrends(guildId));
    if (id.startsWith('market:cat:')) return await interaction.update(renderMarketCategory(guildId, id.slice('market:cat:'.length)));
    if (id.startsWith('market:page:')) {
      const parts = id.split(':');
      return await interaction.update(renderMarketCategory(guildId, parts[2], Number(parts[3]) || 0));
    }
    if (id.startsWith('market:chart:')) return await interaction.update(renderItemChart(guildId, id.slice('market:chart:'.length)));

    if (id.startsWith('market:buy:')) {
      const itemId = id.slice('market:buy:'.length);
      const item = shop.getItem(itemId);
      if (!item) return await interaction.reply({ embeds: [errorEmbed(t(lang, 'market.unknown2'))], ephemeral: true });
      const price = shop.buyPrice(guildId, itemId);
      const eco = getEconomy(guildId, interaction.user.id);
      if (eco.balance < price) {
        return await interaction.reply({ embeds: [errorEmbed(t(lang, 'market.no_funds', { need: kizco.format(price), have: kizco.format(eco.balance) }))], ephemeral: true });
      }
      engine.debitPlayer(guildId, interaction.user.id, price, { type: 'purchase', note: `Beli 1x ${item.name}` });
      require('../database/rpgDb').addItem(interaction.user.id, itemId, 1);
      econ.bumpDemand(guildId, itemId, 1);
      econ.recordItemPrice(guildId, itemId, price);
      const { successEmbed } = require('./embeds');
      return await interaction.reply({ embeds: [successEmbed(t(lang, 'market.buy_ok', { qty: 1, item: item.name, price: kizco.format(price) }))], ephemeral: true });
    }
  } catch (e) {
    // Interaksi Discord kedaluwarsa setelah ~15 menit. Jangan lempar error
    // "Gagal memproses tombol" — kirim ulang menu sebagai pesan baru.
    if (e?.code === 10062 || e?.status === 404 || e?.code === 40060) {
      const menu = renderForId(guildId, id);
      if (menu) {
        try { await interaction.channel.send(menu); } catch (_) {}
      }
      return;
    }
    console.error('[economyButtons] error:', e.message);
    const payload = { embeds: [errorEmbed(t(lang, 'btn.failed'))], ephemeral: true };
    if (interaction.replied || interaction.deferred) return interaction.followUp(payload).catch(() => {});
    return interaction.reply(payload).catch(() => {});
  }
}

module.exports = {
  handleButton,
  renderStatus, renderChart, renderReport, renderHistory, renderChannelConfig,
  renderMarketHome, renderMarketCategory, renderMarketTrends, renderItemChart,
};
