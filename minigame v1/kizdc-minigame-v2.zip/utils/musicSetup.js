const { Connectors } = require('shoukaku');
const { Kazagumo } = require('kazagumo');
const { buildNowPlayingPayload, startLiveUpdate, stopLiveUpdate, getTrackedMessage } = require('./nowPlayingCard');
const { markConnected, markDisconnected } = require('./nodeHealthMonitor');
const settings = require('./settings');

// Node Lavalink dibaca dari config.json -> music.nodes. Kelola lewat command
// /node (add/remove/list/discover) yang hot-update tanpa restart. Kalau semua node
// mati, utils/nodeHealthMonitor.js otomatis cari node online baru dari internet.
function initMusic(client) {
  const NODES = settings.get('music.nodes', []);
  const errorLogThrottle = new Map();
  const kazagumo = new Kazagumo(
    {
      defaultSearchEngine: settings.get('music.defaultSearchEngine', 'youtube'),
      send: (guildId, payload) => {
        const guild = client.guilds.cache.get(guildId);
        if (guild) guild.shard.send(payload);
      },
    },
    new Connectors.DiscordJS(client),
    NODES,
    {
      resumable: true,
      resumableTimeout: 60,
      reconnectTries: 3,
      reconnectInterval: 10,
      moveOnDisconnect: true,
      restTimeout: 15,
      // Node "prioritas" dipilih owner lewat tombol "Pakai Node Ini" di panel (Backup & Node ->
      // klik salah satu node).
      //
      // BUG YANG PERNAH KEJADIAN (penting, jangan diulang): versi awal fungsi ini return
      // `undefined` kalau node prioritas lagi mati/belum konek, dengan asumsi Shoukaku bakal
      // otomatis balik ke pemilihan default (least-load) sendiri. Ternyata asumsi itu SALAH -
      // begitu preferredNode diset ke node yang mati, SEMUA pemutaran musik ikut gagal dengan
      // "No node found" walaupun ada node LAIN yang beneran hidup & konek (kebukti dari log:
      // node lain sempat "Terhubung ke node Lavalink" sukses, tapi /play abis itu tetap gagal
      // "No node found" karena nodeResolver ini return undefined dan Kazagumo TIDAK fallback
      // otomatis seperti yang dikira). Makanya sekarang fungsi ini SELALU pilih & return node
      // yang beneran hidup sendiri (tidak pernah return undefined selama `nodes` tidak kosong) -
      // gak gantung ke asumsi soal perilaku fallback Kazagumo yang ternyata tidak terverifikasi.
      nodeResolver: (nodes) => {
        if (!nodes || nodes.size === 0) return undefined; // memang beneran tidak ada node hidup sama sekali
        const preferredName = settings.get('music.preferredNode', null);
        if (preferredName && nodes.has(preferredName)) return nodes.get(preferredName);
        // Node prioritas tidak ada di daftar yang hidup (mati/belum diset) - JANGAN return
        // undefined, pilih sendiri node paling ringan bebannya dari yang tersedia.
        return [...nodes.values()].sort((a, b) => (a.stats?.players ?? 0) - (b.stats?.players ?? 0))[0];
      },
    },
  );

  kazagumo.shoukaku.on('ready', (name) => {
    markConnected(name);
    console.log(`[Music] Terhubung ke node Lavalink: ${name}`);
  });

  kazagumo.shoukaku.on('error', (name, error) => {
    // Throttle: error identik dari node yang sama tidak di-spam ke log (mis. ECONNREFUSED
    // berulang dari node mati). Hanya 1 log per node per 30 detik.
    const key = `${name}:${(error?.message || error || '').slice(0, 40)}`;
    const now = Date.now();
    if (errorLogThrottle.get(key) && now - errorLogThrottle.get(key) < 30000) return;
    errorLogThrottle.set(key, now);
    const msg = error?.message || String(error);
    console.error(`[Music] Error dari node ${name}:`, msg);
    // "wrong version number" dari OpenSSL itu BUKAN "node mati" biasa - itu tandanya bot nyoba
    // ngomong TLS/SSL ke server yang sebenernya plain (non-SSL), atau sebaliknya. Beda akar
    // masalah dari ECONNREFUSED/timeout (yang beneran node-nya gak nyala/gak nyampe), jadi kasih
    // diagnosis yang beda biar owner gak salah kira "node mati" padahal settingnya yang keliru.
    if (msg.includes('wrong version number') || msg.includes('EPROTO')) {
      console.error(`[Music] ^ Ini kemungkinan besar setting SSL/secure node "${name}" KELIRU (bukan node mati) - coba cek apakah node ini beneran jalan pakai HTTPS/WSS atau HTTP/WS biasa, lalu sesuaikan flag "secure" di config node-nya lewat Panel atau /node.`);
    }
  });

  kazagumo.shoukaku.on('close', (name, code, reason) => {
    markDisconnected(name);
    console.warn(`[Music] Node ${name} tertutup. Code: ${code}, alasan: ${reason || 'tidak diketahui'}`);
  });

  kazagumo.shoukaku.on('disconnect', (name) => {
    markDisconnected(name);
    console.warn(`[Music] Node ${name} terputus. Player yang aktif akan otomatis dipindah ke node lain yang sehat (moveOnDisconnect aktif).`);
  });

  kazagumo.on('playerStart', async (player, track) => {
    // Simpan referensi pesan "Sedang Memutar" lagu SEBELUMNYA (kalau ada) sebelum ke-timpa sama
    // yang baru - begitu lagu baru ini mulai, pesan punya lagu yang udah lewat itu DIHAPUS (bukan
    // cuma dibiarkan basi nangkring di channel).
    const previousMessage = getTrackedMessage(player);

    const channel = client.channels.cache.get(player.textId);
    if (!channel) return;
    try {
      const payload = await buildNowPlayingPayload(player, track);
      const message = await channel.send(payload);
      startLiveUpdate(player, message, track);
      if (previousMessage && previousMessage.id !== message.id) {
        await previousMessage.delete().catch(() => {}); // abaikan kalau sudah kehapus/gak ada izin
      }
    } catch (err) {
      console.error(`[Music] Gagal kirim kartu "Sedang Memutar" di guild ${player.guildId}:`, err.message);
    }
  });

  kazagumo.on('playerEnd', (player) => {
    // Trigger tiap satu lagu selesai. Notifikasi antrian selanjutnya sudah dihandle playerStart,
    // yang juga akan mulai live-update baru - hentikan ticker punya lagu SEBELUMNYA dulu di sini
    // biar tidak ada 2 interval nyala bareng buat player yang sama.
    stopLiveUpdate(player);
  });

  // SEBELUM INI TIDAK ADA HANDLER buat 2 event ini sama sekali - kalau sebuah track gagal
  // dimuat/macet, player cuma diam tanpa penjelasan apa pun ke user (beda dari bug node-timeout
  // yang sudah diperbaiki - ini soal 1 track SPESIFIK yang bermasalah, bukan node-nya mati total).
  //
  // CATATAN: bentuk PASTI argumen event playerException/playerStuck ternyata beda dari dugaan
  // awal (kebukti dari log produksi: title & message-nya kosong/"undefined"). Daripada nebak 1
  // struktur yang belum tentu benar, di sini dicoba beberapa kemungkinan bentuk data SEKALIGUS,
  // dan title track selalu ada fallback ke player.queue.current (state player sendiri, tidak
  // bergantung sama bentuk argumen event sama sekali) biar minimal judulnya selalu benar.
  kazagumo.on('playerException', (player, track, payload) => {
    const title = track?.title || track?.track?.title || payload?.track?.title || player.queue?.current?.title || 'lagu ini';
    const excSrc = payload?.exception || track?.exception || payload;
    const message = (excSrc && typeof excSrc === 'object' ? excSrc.message : excSrc) || 'error tidak diketahui';
    console.error(`[Music] Track error di guild ${player.guildId}: ${title} - ${message}`);
    const channel = client.channels.cache.get(player.textId);
    if (channel) channel.send(`⚠️ Gagal memutar **${title}** (${String(message).slice(0, 100)}), lanjut ke lagu berikutnya.`).catch(() => {});
  });
  kazagumo.on('playerStuck', (player, track) => {
    const title = track?.title || track?.track?.title || player.queue?.current?.title || 'lagu ini';
    console.warn(`[Music] Track macet di guild ${player.guildId}: ${title}`);
    const channel = client.channels.cache.get(player.textId);
    if (channel) channel.send(`⚠️ **${title}** macet, lanjut ke lagu berikutnya.`).catch(() => {});
  });

  kazagumo.on('playerEmpty', (player) => {
    stopLiveUpdate(player); // gak ada yang diputar lagi, hentikan auto-refresh kartu
    const lastMessage = getTrackedMessage(player);
    const channel = client.channels.cache.get(player.textId);
    if (channel) {
      channel.send('Antrian musik sudah habis, aku keluar dari voice channel.').catch(() => {});
    }
    // Pesan "Sedang Memutar" lagu terakhir dihapus juga (bukan dibiarkan basi), lalu langsung
    // keluar - TIDAK ada jeda 5 menit, balik ke perilaku semula: kosong = langsung keluar.
    (async () => {
      if (lastMessage) await lastMessage.delete().catch(() => {});
      await player.destroy().catch((err) => console.error(`[Music] Gagal destroy player kosong di guild ${player.guildId}:`, err.message));
    })();
  });

  return kazagumo;
}

module.exports = { initMusic };
