// ============================================================================
// ANALITIK — hitung penggunaan command (in-memory, reset saat restart)
// ----------------------------------------------------------------------------
// Dipakai dashboard buat lihat command apa yang paling sering dipakai.
// Dipanggil dari events/interactionCreate.js (trackCommand) dan dashboard.
// ============================================================================
const counts = new Map();
let totalExecuted = 0;

function trackCommand(name) {
  counts.set(name, (counts.get(name) || 0) + 1);
  totalExecuted++;
}

// Mengembalikan array [nama, jumlah] terurut dari yang paling banyak.
function getCommandCounts(limit = 50) {
  return [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, limit);
}

function getTotalExecuted() {
  return totalExecuted;
}

module.exports = { trackCommand, getCommandCounts, getTotalExecuted };
