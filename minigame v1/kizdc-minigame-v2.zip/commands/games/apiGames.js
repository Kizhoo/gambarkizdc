const { errorEmbed } = require('../../utils/embeds');
const { fetchJson, randomItem } = require('../../utils/publicApi');
const { startQuiz } = require('../../utils/quizSession');
const COUNTRIES = require('../../utils/countryData');

function html(value) {
  return String(value || '').replace(/&quot;/g, '"').replace(/&#039;/g, "'")
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
}

async function pokemonQuiz(kind) {
  const id = 1 + Math.floor(Math.random() * 1025);
  const data = await fetchJson(`https://pokeapi.co/api/v2/${kind}/${id}`, { timeout: 12000 });
  const image = kind === 'pokemon'
    ? data.sprites?.other?.['official-artwork']?.front_default || data.sprites?.front_default
    : data.sprites?.default;
  return {
    title: kind === 'pokemon' ? '🔴 Tebak Pokémon' : '🎒 Tebak Item Pokémon',
    prompt: 'Kenali gambar dari PokéAPI lalu ketik namanya.', image,
    answer: data.name.replace(/-/g, ' '), source: 'PokéAPI', reward: 90,
    hint: kind === 'pokemon' ? `Tipe: ${data.types.map(x => x.type.name).join(', ')}` : `Kategori: ${data.category?.name?.replace(/-/g, ' ') || 'item'}`,
  };
}

async function buildQuiz(sub) {
  if (sub === 'tebakpokemon') return pokemonQuiz('pokemon');
  if (sub === 'tebakitempokemon') return pokemonQuiz('item');

  if (sub === 'tebakbendera' || sub === 'tebakibukota') {
    const country = randomItem(COUNTRIES);
    if (sub === 'tebakbendera') return {
      title: '🏳️ Tebak Bendera', prompt: 'Bendera negara apakah ini?', image: `https://flagcdn.com/w320/${country.code.toLowerCase()}.png`,
      answer: country.name, source: 'flagcdn.com', reward: 85,
      hint: `Wilayah: ${country.region} • Kode negara: ${country.code}`,
    };
    return {
      title: '🌍 Tebak Ibu Kota', prompt: `Apa ibu kota **${country.name}**?`,
      answer: country.capital, source: 'Data negara', reward: 80,
      hint: `Wilayah: ${country.region}`,
    };
  }

  if (sub === 'tebakanime') {
    let anime;
    for (let i = 0; i < 5; i++) {
      const offset = Math.floor(Math.random() * 15000);
      anime = (await fetchJson(`https://kitsu.io/api/edge/anime?page[limit]=1&page[offset]=${offset}`, { timeout: 15000, headers: { Accept: 'application/vnd.api+json' } })).data?.[0]?.attributes;
      if (anime?.posterImage?.large && anime.canonicalTitle && anime.ageRating !== 'R18') break;
    }
    if (!anime?.posterImage?.large) throw new Error('Kitsu tidak mengembalikan poster anime');
    return {
      title: '🎌 Tebak Anime', prompt: 'Tebak judul anime dari poster ini.', image: anime.posterImage.large,
      answer: anime.canonicalTitle, aliases: Object.values(anime.titles || {}).filter(Boolean), source: 'Kitsu API', reward: 100,
      hint: `Mulai: ${anime.startDate || '—'} • Rating usia: ${anime.ageRating || '—'}`,
    };
  }

  if (sub === 'tebakkarakter') {
    let character;
    for (let i = 0; i < 5; i++) {
      const offset = Math.floor(Math.random() * 50000);
      character = (await fetchJson(`https://kitsu.io/api/edge/characters?page[limit]=1&page[offset]=${offset}`, { timeout: 15000, headers: { Accept: 'application/vnd.api+json' } })).data?.[0]?.attributes;
      if (character?.image?.original && character.canonicalName) break;
    }
    if (!character?.image?.original) throw new Error('Kitsu tidak mengembalikan gambar karakter');
    return {
      title: '👤 Tebak Karakter Anime', prompt: 'Siapa nama karakter pada gambar?', image: character.image.original,
      answer: character.canonicalName, aliases: [...Object.values(character.names || {}), ...(character.otherNames || [])].filter(Boolean), source: 'Kitsu API', reward: 100,
      hint: character.description ? `${character.description.slice(0, 180)}…` : undefined,
    };
  }

  if (sub === 'tebakrasanjing') {
    const dog = await fetchJson('https://dog.ceo/api/breeds/image/random', { timeout: 12000 });
    const match = dog.message?.match(/\/breeds\/([^/]+)\//);
    if (!match) throw new Error('format Dog CEO API berubah');
    const raw = match[1];
    const words = raw.split('-');
    const answers = [raw.replace(/-/g, ' '), [...words].reverse().join(' ')];
    return {
      title: '🐕 Tebak Ras Anjing', prompt: 'Tebak ras anjing dari foto asli berikut.', image: dog.message,
      answer: answers[0], aliases: answers, source: 'Dog CEO API', reward: 90,
      hint: `${answers[0].replace(/\s/g, '').length} huruf`,
    };
  }

  if (sub === 'tebakraskucing') {
    let breedName = null, imageUrl = null;
    for (let i = 0; i < 5; i++) {
      const res = await fetchJson('https://api.thecatapi.com/v1/images/search?has_breeds=1&limit=1', { timeout: 12000 });
      const entry = res?.[0];
      if (entry?.url && entry.breeds?.[0]?.name) { breedName = entry.breeds[0].name; imageUrl = entry.url; break; }
    }
    if (!breedName) throw new Error('TheCatAPI tidak mengembalikan foto kucing berikut rasnya');
    const words = breedName.toLowerCase().split(/\s+/);
    const answers = [breedName.toLowerCase(), words[words.length - 1], words.join(' ')];
    return {
      title: '🐈 Tebak Ras Kucing', prompt: 'Tebak ras kucing dari foto asli berikut.', image: imageUrl,
      answer: answers[0], aliases: [...new Set(answers)], source: 'TheCatAPI', reward: 90,
      hint: `${breedName.replace(/\s/g, '').length} huruf`,
    };
  }

  if (sub === 'benar-salah') {
    const result = (await fetchJson('https://opentdb.com/api.php?amount=1&type=boolean&encode=url3986', { timeout: 12000 })).results?.[0];
    if (!result) throw new Error('Open Trivia DB tidak mengembalikan soal');
    return {
      title: '✅❌ Benar atau Salah', prompt: `${decodeURIComponent(result.question)}\n\nJawab: **benar** atau **salah**.`,
      answer: decodeURIComponent(result.correct_answer).toLowerCase() === 'true' ? 'benar' : 'salah',
      aliases: decodeURIComponent(result.correct_answer).toLowerCase() === 'true' ? ['true', 'b'] : ['false', 's'],
      source: 'Open Trivia DB API', reward: 70,
      hint: `Kategori: ${decodeURIComponent(result.category)} • Kesulitan: ${result.difficulty}`,
    };
  }

  throw new Error('subcommand game API tidak dikenal');
}

module.exports = {
  subcommandOf: 'games',
  async execute(interaction) {
    try {
      const quiz = await buildQuiz(interaction.options.getSubcommand());
      return startQuiz(interaction, quiz);
    } catch (error) {
      console.error('[api game]', error);
      const method = interaction.deferred || interaction.replied ? 'followUp' : 'reply';
      return interaction[method]({ embeds: [errorEmbed(`Game API gagal dimuat: ${error.message}`)], ephemeral: true }).catch(() => {});
    }
  },
};
